import { createClient } from '@supabase/supabase-js';
import { PUBLIC_CONFIG } from './config';

export function isSupabaseConfigured(): boolean {
  if (process.env.NODE_ENV === 'test') return false;
  const supabaseUrl = process.env.SUPABASE_URL || PUBLIC_CONFIG.supabaseUrl;
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!supabaseUrl || !serviceRoleKey) return false;
  if (supabaseUrl.includes('mock.supabase.co') || serviceRoleKey.includes('mock') || supabaseUrl.includes('your-supabase') || serviceRoleKey.includes('your-')) return false;
  return !!(supabaseUrl.trim() !== '' && serviceRoleKey.trim() !== '');
}

const authUpdateHooks = new Set<(userId: string) => void>();
const clientResetHooks = new Set<() => void>();

export function registerAuthUpdateHook(fn: (userId: string) => void): void {
  authUpdateHooks.add(fn);
}

export function registerSupabaseClientResetHook(fn: () => void): void {
  clientResetHooks.add(fn);
}

function notifyAuthUpdated(userId: string): void {
  for (const fn of authUpdateHooks) {
    try { fn(userId); } catch {}
  }
}

function notifyClientReset(): void {
  for (const fn of clientResetHooks) {
    try { fn(); } catch {}
  }
}

function wrapAuthAdminUpdate(client: any): void {
  const admin = client?.auth?.admin;
  if (!admin || typeof admin.updateUserById !== 'function' || (admin.updateUserById as any).__aamarvaWrapped) {
    return;
  }
  const origUpdate = admin.updateUserById.bind(admin);
  const wrapped = async (id: string, attrs: any) => {
    const res = await origUpdate(id, attrs);
    if (id) notifyAuthUpdated(id);
    return res;
  };
  (wrapped as any).__aamarvaWrapped = true;
  admin.updateUserById = wrapped;
}

class MockPostgrestQueryBuilder implements PromiseLike<any> {
  private table: string;
  private store: Map<string, any[]>;
  private queryType: 'select' | 'insert' | 'update' | 'delete' | 'upsert' = 'select';
  private filters: Array<(row: any) => boolean> = [];
  private limitCount?: number;
  private rangeStart?: number;
  private rangeEnd?: number;
  private orderColumn?: string;
  private ascending: boolean = true;
  private insertData: any = null;
  private updateData: any = null;
  private isHead: boolean = false;
  private countMode?: string;

  constructor(table: string, store: Map<string, any[]>) {
    this.table = table;
    this.store = store;
    if (!this.store.has(table)) {
      this.store.set(table, []);
    }
  }

  select(columns: string = '*', opts?: { count?: string; head?: boolean }) {
    if (this.queryType !== 'update' && this.queryType !== 'insert' && this.queryType !== 'upsert' && this.queryType !== 'delete') {
      this.queryType = 'select';
    }
    if (opts?.head) this.isHead = true;
    if (opts?.count) this.countMode = opts.count;
    return this;
  }

  insert(data: any) {
    this.queryType = 'insert';
    this.insertData = data;
    return this;
  }

  update(data: any) {
    this.queryType = 'update';
    this.updateData = data;
    return this;
  }

  delete() {
    this.queryType = 'delete';
    return this;
  }

  private onConflictColumn?: string;

  upsert(data: any, opts?: { onConflict?: string }) {
    this.queryType = 'upsert';
    this.insertData = data;
    if (opts?.onConflict) {
      this.onConflictColumn = opts.onConflict;
    }
    return this;
  }

  private getFieldValue(row: any, column: string): any {
    if (!row || typeof row !== 'object') return undefined;
    if (row[column] !== undefined && row[column] !== null) return row[column];

    const aliases: Record<string, string[]> = {
      user_id: ['userId', 'user_id'],
      userid: ['userId', 'user_id'],
      agent_id: ['agentId', 'agent_id'],
      agentid: ['agentId', 'agent_id'],
      master_id: ['masterId', 'master_id', 'masterUserId'],
      masterid: ['masterId', 'master_id', 'masterUserId'],
      created_at: ['createdAt', 'created_at'],
      createdat: ['createdAt', 'created_at'],
      updated_at: ['updatedAt', 'updated_at'],
      updatedat: ['updatedAt', 'updated_at'],
      email_verified: ['emailVerified', 'email_verified'],
      is_master_primary: ['isMasterPrimary', 'is_master_primary'],
      account_type: ['accountType', 'account_type'],
    };

    const norm = column.replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
    const candidateKeys = aliases[column.toLowerCase()] || aliases[norm] || [];
    for (const k of candidateKeys) {
      if (row[k] !== undefined && row[k] !== null) return row[k];
    }

    for (const key of Object.keys(row)) {
      if (key.toLowerCase() === column.toLowerCase() || key.replace(/[^a-zA-Z0-9]/g, '').toLowerCase() === norm) {
        if (row[key] !== undefined && row[key] !== null) return row[key];
      }
    }
    return undefined;
  }

  eq(column: string, value: any) {
    this.filters.push(row => {
      const rowVal = this.getFieldValue(row, column);
      if (rowVal === value) return true;
      if (typeof rowVal === 'string' && typeof value === 'string') {
        const cLower = column.toLowerCase();
        if (cLower === 'id' || cLower.endsWith('_id') || cLower === 'agentid' || cLower.endsWith('id')) {
          return rowVal.toLowerCase() === value.toLowerCase();
        }
      }
      return false;
    });
    return this;
  }

  neq(column: string, value: any) {
    this.filters.push(row => this.getFieldValue(row, column) !== value);
    return this;
  }

  in(column: string, values: any[]) {
    const arr = (Array.isArray(values) ? values : [values]).map(v => typeof v === 'string' ? v.toLowerCase().trim() : v);
    this.filters.push(row => {
      const val = this.getFieldValue(row, column);
      if (val === undefined || val === null) return false;
      if (typeof val === 'string') {
        return arr.includes(val.toLowerCase().trim());
      }
      return arr.includes(val);
    });
    return this;
  }

  is(column: string, value: any) {
    this.filters.push(row => {
      const val = this.getFieldValue(row, column);
      return val === value || (value === null && (val === null || val === undefined));
    });
    return this;
  }

  gt(column: string, value: any) {
    this.filters.push(row => {
      const val = this.getFieldValue(row, column);
      if (val === undefined || val === null) return false;
      return val > value;
    });
    return this;
  }

  gte(column: string, value: any) {
    this.filters.push(row => {
      const val = this.getFieldValue(row, column);
      if (val === undefined || val === null) return false;
      return val >= value;
    });
    return this;
  }

  lt(column: string, value: any) {
    this.filters.push(row => {
      const val = this.getFieldValue(row, column);
      if (val === undefined || val === null) return false;
      return val < value;
    });
    return this;
  }

  lte(column: string, value: any) {
    this.filters.push(row => {
      const val = this.getFieldValue(row, column);
      if (val === undefined || val === null) return false;
      return val <= value;
    });
    return this;
  }

  like(column: string, pattern: string) {
    const clean = pattern.replace(/^%/, '').replace(/%$/, '');
    this.filters.push(row => {
      const val = String(row[column] ?? '');
      return val.includes(clean);
    });
    return this;
  }

  ilike(column: string, pattern: string) {
    const clean = pattern.replace(/^%/, '').replace(/%$/, '').toLowerCase();
    this.filters.push(row => {
      const val = String(row[column] ?? '').toLowerCase();
      return val.includes(clean);
    });
    return this;
  }

  contains(column: string, value: any) {
    this.filters.push(row => {
      const field = row[column];
      if (Array.isArray(field) && Array.isArray(value)) {
        return value.every(v => field.includes(v));
      }
      if (Array.isArray(field)) {
        return field.includes(value);
      }
      return false;
    });
    return this;
  }

  or(filterStr: string) {
    if (!filterStr || typeof filterStr !== 'string') return this;

    // Helper: split string by delimiter ignoring occurrences inside parentheses
    const splitRespectingParens = (str: string, delimiter: string = ','): string[] => {
      const tokens: string[] = [];
      let current = '';
      let depth = 0;
      for (let i = 0; i < str.length; i++) {
        const char = str[i];
        if (char === '(') depth++;
        else if (char === ')') depth--;
        if (char === delimiter && depth === 0) {
          if (current.trim()) tokens.push(current.trim());
          current = '';
        } else {
          current += char;
        }
      }
      if (current.trim()) tokens.push(current.trim());
      return tokens;
    };

    const matchClause = (row: any, clause: string): boolean => {
      const trimmed = clause.trim();
      if (trimmed.startsWith('and(') && trimmed.endsWith(')')) {
        const inner = trimmed.slice(4, -1);
        const subClauses = splitRespectingParens(inner, ',');
        return subClauses.every(sub => matchClause(row, sub));
      }

      const parts = trimmed.split('.');
      if (parts.length < 3) return false;
      const col = parts[0];
      const op = parts[1];
      const rawVal = parts.slice(2).join('.');
      const val = rawVal.replace(/^["']|["']$/g, '');
      const rawField = this.getFieldValue(row, col);
      const rowVal = rawField !== undefined && rawField !== null ? String(rawField) : '';

      if (op === 'eq') {
        if (rawField === val || rowVal === val || rawField === rawVal || rowVal === rawVal) return true;
        const colLower = col.toLowerCase();
        if (colLower === 'id' || colLower.endsWith('_id') || colLower === 'agentid' || colLower.endsWith('id')) {
          return rowVal.toLowerCase() === val.toLowerCase();
        }
        return false;
      }
      if (op === 'in') {
        const inMatch = rawVal.match(/^\((.*)\)$/);
        const candidates = (inMatch ? inMatch[1] : rawVal)
          .split(',')
          .map(c => c.trim().replace(/^["']|["']$/g, '').toLowerCase());
        return candidates.includes(rowVal.toLowerCase());
      }
      if (op === 'neq') {
        return row[col] !== val && rowVal !== val;
      }
      if (op === 'ilike') {
        const clean = val.replace(/%/g, '').toLowerCase();
        return rowVal.toLowerCase().includes(clean);
      }
      if (op === 'like') {
        const clean = val.replace(/%/g, '');
        return rowVal.includes(clean);
      }
      return false;
    };

    const topLevelClauses = splitRespectingParens(filterStr, ',');
    this.filters.push(row => {
      return topLevelClauses.some(clause => matchClause(row, clause));
    });
    return this;
  }

  limit(count: number) {
    this.limitCount = count;
    return this;
  }

  range(from: number, to: number) {
    this.rangeStart = from;
    this.rangeEnd = to;
    return this;
  }

  order(column: string, opts?: { ascending?: boolean }) {
    this.orderColumn = column;
    this.ascending = opts?.ascending ?? true;
    return this;
  }

  maybeSingle() {
    if (this.table.startsWith('non_existent_')) {
      return Promise.resolve({ data: null, error: { message: `relation "${this.table}" does not exist`, code: '42P01' } });
    }
    const { data } = this.executeSync();
    return Promise.resolve({ data: data[0] || null, error: null });
  }

  single() {
    if (this.table.startsWith('non_existent_')) {
      return Promise.resolve({ data: null, error: { message: `relation "${this.table}" does not exist`, code: '42P01' } });
    }
    const { data } = this.executeSync();
    return Promise.resolve({
      data: data[0] || null,
      error: data.length === 0 ? { message: 'Row not found', code: 'PGRST116' } : null
    });
  }

  then<TResult1 = any, TResult2 = never>(
    onfulfilled?: ((value: any) => TResult1 | PromiseLike<TResult1>) | null,
    onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | null
  ): Promise<TResult1 | TResult2> {
    try {
      if (this.table.startsWith('non_existent_')) {
        return Promise.resolve({ data: null, error: { message: `relation "${this.table}" does not exist`, code: '42P01' } }).then(onfulfilled, onrejected);
      }
      const { data, count } = this.executeSync();
      const result = {
        data: this.isHead ? null : data,
        error: null,
        count: this.countMode ? count : data.length
      };
      return Promise.resolve(result).then(onfulfilled, onrejected);
    } catch (err) {
      return Promise.reject(err).then(onfulfilled, onrejected);
    }
  }

  catch<TResult = never>(
    onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | null
  ): Promise<any | TResult> {
    return this.then(undefined, onrejected);
  }

  finally(onfinally?: (() => void) | null): Promise<any> {
    return this.then(
      val => Promise.resolve(onfinally && onfinally()).then(() => val),
      err => Promise.resolve(onfinally && onfinally()).then(() => { throw err; })
    );
  }

  private executeSync(): { data: any[]; count: number } {
    const tableRows = this.store.get(this.table) || [];
    if (this.queryType === 'insert') {
      const rowsToAdd = Array.isArray(this.insertData) ? this.insertData : [this.insertData];
      const newRows = rowsToAdd.map((r: any) => ({
        id: r?.id || 'mock_id_' + Math.random().toString(36).substring(2, 9),
        createdAt: r?.createdAt || new Date().toISOString(),
        ...r
      }));
      tableRows.push(...newRows);
      this.store.set(this.table, tableRows);
      return { data: newRows, count: newRows.length };
    }

    if (this.queryType === 'upsert') {
      const rowsToAdd = Array.isArray(this.insertData) ? this.insertData : [this.insertData];
      const conflictCols = (this.onConflictColumn || 'id').split(',').map(c => c.trim()).filter(Boolean);
      const resultRows: any[] = [];
      for (const r of rowsToAdd) {
        const hasAllConflictVals = conflictCols.length > 0 && conflictCols.every(col => r[col] !== undefined);
        const existingIdx = hasAllConflictVals
          ? tableRows.findIndex((row: any) =>
              conflictCols.every(col => {
                const rVal = r[col];
                const rowVal = row[col];
                return typeof rVal === 'string' && typeof rowVal === 'string'
                  ? rowVal.toLowerCase() === rVal.toLowerCase()
                  : rowVal === rVal;
              })
            )
          : -1;
        if (existingIdx >= 0) {
          tableRows[existingIdx] = { ...tableRows[existingIdx], ...r, updatedAt: new Date().toISOString() };
          resultRows.push(tableRows[existingIdx]);
        } else {
          const newRow = {
            id: r?.id || 'mock_id_' + Math.random().toString(36).substring(2, 9),
            createdAt: r?.createdAt || new Date().toISOString(),
            ...r
          };
          tableRows.push(newRow);
          resultRows.push(newRow);
        }
      }
      this.store.set(this.table, tableRows);
      return { data: resultRows, count: resultRows.length };
    }

    if (this.queryType === 'update') {
      let updated: any[] = [];
      for (let i = 0; i < tableRows.length; i++) {
        let match = true;
        for (const f of this.filters) {
          if (!f(tableRows[i])) { match = false; break; }
        }
        if (match) {
          tableRows[i] = { ...tableRows[i], ...this.updateData, updatedAt: new Date().toISOString() };
          updated.push(tableRows[i]);
        }
      }
      this.store.set(this.table, tableRows);
      return { data: updated, count: updated.length };
    }

    if (this.queryType === 'delete') {
      const remaining: any[] = [];
      const deleted: any[] = [];
      for (let i = 0; i < tableRows.length; i++) {
        let match = true;
        for (const f of this.filters) {
          if (!f(tableRows[i])) { match = false; break; }
        }
        if (match) {
          deleted.push(tableRows[i]);
        } else {
          remaining.push(tableRows[i]);
        }
      }
      this.store.set(this.table, remaining);
      return { data: deleted, count: deleted.length };
    }

    let filtered = tableRows.filter(row => {
      for (const f of this.filters) {
        if (!f(row)) return false;
      }
      return true;
    });

    const totalCount = filtered.length;

    if (this.orderColumn) {
      const col = this.orderColumn;
      const asc = this.ascending;
      filtered.sort((a, b) => {
        const valA = a[col] ?? '';
        const valB = b[col] ?? '';
        if (valA < valB) return asc ? -1 : 1;
        if (valA > valB) return asc ? 1 : -1;
        return 0;
      });
    }

    if (this.rangeStart !== undefined || this.rangeEnd !== undefined) {
      const start = this.rangeStart ?? 0;
      const end = this.rangeEnd !== undefined ? this.rangeEnd + 1 : filtered.length;
      filtered = filtered.slice(start, end);
    } else if (typeof this.limitCount === 'number') {
      filtered = filtered.slice(0, this.limitCount);
    }

    return { data: filtered, count: totalCount };
  }
}

const g = globalThis as any;
const isStoreInitialized = !!g.__AAMARVA_GLOBAL_MEMORY_STORE__;
const globalMemoryStore: Map<string, any[]> = g.__AAMARVA_GLOBAL_MEMORY_STORE__ || new Map<string, any[]>();
const mockAuthUsersStore: Map<string, any> = g.__AAMARVA_MOCK_AUTH_USERS_STORE__ || new Map<string, any>();
g.__AAMARVA_GLOBAL_MEMORY_STORE__ = globalMemoryStore;
g.__AAMARVA_MOCK_AUTH_USERS_STORE__ = mockAuthUsersStore;

if (!isStoreInitialized) {
  // Pre-seed demo user so user lookup and agent identity work out of the box in development
  globalMemoryStore.set('users', [
    {
      id: 'usr_alpha_operator',
      agentId: 'AMR-XAFU-H4V8',
      name: 'Alpha Operator',
      email: 'operator@aamarva.com',
      emailVerified: true,
      email_verified: true,
      status: 'active',
      type: 'agent',
      role: 'agent',
      account_type: 'master',
      avatar: `data:image/svg+xml;utf8,${encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="128" height="128" viewBox="0 0 128 128"><rect width="128" height="128" fill="#141414"/><text x="50%" y="54%" font-family="monospace" font-size="56" font-weight="900" fill="#FFFFFF" text-anchor="middle" dominant-baseline="middle">A</text></svg>')}`,
      whitelisted_networks: ['0.0.0.0/0', '::/0'],
      createdAt: new Date().toISOString()
    },
    {
      id: 'usr_another_user',
      agentId: 'AMR-TEST-123',
      name: 'Test User',
      email: 'test@example.com',
      emailVerified: true,
      email_verified: true,
      status: 'active',
      type: 'agent',
      role: 'agent',
      account_type: 'master',
      avatar: `data:image/svg+xml;utf8,${encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="128" height="128" viewBox="0 0 128 128"><rect width="128" height="128" fill="#141414"/><text x="50%" y="54%" font-family="monospace" font-size="56" font-weight="900" fill="#FFFFFF" text-anchor="middle" dominant-baseline="middle">T</text></svg>')}`,
      whitelisted_networks: ['0.0.0.0/0', '::/0'],
      createdAt: new Date().toISOString()
    }
  ]);

  globalMemoryStore.set('posts', []);
}

export function createMockSupabaseClient() {
  return {
    from: (table: string) => new MockPostgrestQueryBuilder(table, globalMemoryStore),
    rpc: async (fnName: string, args: any) => {
      if (fnName === 'accept_contract') {
        const { p_contract_id, p_user_id, p_agent_id } = args;
        const contracts = globalMemoryStore.get('contracts') || [];
        const contract = contracts.find((c: any) => c.id === p_contract_id);
        if (!contract) {
          return { data: null, error: { message: 'Contract not found.' } };
        }
        const isOwner = contract.ownerUserId === p_user_id || (contract.ownerAgentId && p_agent_id && contract.ownerAgentId.toLowerCase() === p_agent_id.toLowerCase());
        const isAgent = contract.selectedAgentId && p_agent_id && contract.selectedAgentId.toLowerCase() === p_agent_id.toLowerCase();
        if (!isOwner && !isAgent) {
          return { data: null, error: { message: 'Forbidden: Only contract parties can accept contract terms.' } };
        }
        contract.ownerAccepted = contract.ownerAccepted || isOwner;
        contract.agentAccepted = contract.agentAccepted || isAgent;
        if (contract.ownerAccepted && contract.agentAccepted) {
          contract.status = 'active';
        }
        return { data: { success: true, contract }, error: null };
      }
      if (fnName === 'award_ticket_and_create_contract') {
        const { p_ticket_id, p_bid_id, p_user_id } = args;
        const posts = globalMemoryStore.get('posts') || [];
        const post = posts.find((p: any) => p.id === p_ticket_id);
        if (!post) return { data: null, error: { message: 'Ticket not found.' } };
        if (post.userId !== p_user_id) return { data: null, error: { message: 'Forbidden: Only the ticket owner can award applications.' } };
        if (post.ticketStatus === 'awarded') return { data: null, error: { message: 'Ticket has already been awarded.' } };

        const replies = globalMemoryStore.get('replies') || [];
        const bid = replies.find((r: any) => r.id === p_bid_id && r.postId === p_ticket_id);
        if (!bid) return { data: null, error: { message: 'Application/Bid not found on this ticket.' } };

        post.ticketStatus = 'awarded';
        post.awardedBidId = p_bid_id;
        bid.status = 'awarded';

        const contractId = 'cnt_' + Math.random().toString(36).substring(2, 9);
        const contract = {
          id: contractId,
          ticketId: p_ticket_id,
          bidId: p_bid_id,
          ownerUserId: post.userId,
          ownerAgentId: post.agentId,
          selectedAgentId: bid.agentId,
          terms: post.content,
          bidContent: bid.content,
          status: 'pending_acceptance',
          ownerAccepted: false,
          agentAccepted: false,
          createdAt: new Date().toISOString()
        };
        const contracts = globalMemoryStore.get('contracts') || [];
        contracts.push(contract);
        globalMemoryStore.set('contracts', contracts);

        return { data: { success: true, contractId, ticketId: p_ticket_id, bidId: p_bid_id, contract }, error: null };
      }
      if (fnName === 'check_cluster_quota_atomic') {
        return {
          data: {
            success: true,
            allowance: 1000000,
            current: 0,
            remaining: 1000000
          },
          error: null
        };
      }
      if (fnName === 'allocate_slave_slot_atomic') {
        const { p_master_id, p_requested_slots = 1 } = args || {};
        const ents = globalMemoryStore.get('master_plan_entitlements') || [];
        const plan = ents.find(
          (e: any) =>
            e.master_account_id === p_master_id &&
            e.status === 'active' &&
            (!e.plan_type || e.plan_type === 'master_slave_scale')
        );
        if (!plan) {
          return {
            data: {
              success: false,
              error: 'NO_ACTIVE_PLAN',
              message: 'No active Master/Slave plan found. Available slave slots: 0.',
              allowance: 0,
              current: 0
            },
            error: null
          };
        }
        const nowMs = Date.now();
        if (plan.expires_at && new Date(plan.expires_at).getTime() <= nowMs) {
          plan.status = 'expired';
          plan.updated_at = new Date().toISOString();
          return {
            data: {
              success: false,
              error: 'PLAN_EXPIRED',
              message: 'Master/Slave plan has expired. Additional slave accounts cannot be created.',
              allowance: 0,
              current: 0
            },
            error: null
          };
        }
        const allowance = plan.allowance_accounts || 0;
        const users = globalMemoryStore.get('users') || [];
        const subMasterIds = new Set<string>(
          users
            .filter(
              (u: any) =>
                u.master_id === p_master_id &&
                (u.is_master_slot === true || u.account_type === 'master_slot' || u.role === 'master') &&
                u.account_type !== 'slave' &&
                !u.is_slave
            )
            .map((u: any) => u.id)
        );
        const masterScope = new Set<string>([p_master_id, ...Array.from(subMasterIds)]);
        const currentSlaves = users.filter((u: any) => {
          if (u.id === p_master_id || masterScope.has(u.id)) return false;
          if (u.status === 'deleted') return false;
          if (!u.master_id || !masterScope.has(u.master_id)) return false;
          if (u.is_master_slot === true || u.account_type === 'master_slot') return false;
          if (u.role === 'master' && u.account_type !== 'slave' && !u.is_slave) return false;
          return true;
        }).length;

        if (currentSlaves + p_requested_slots > allowance) {
          return {
            data: {
              success: false,
              error: 'ALLOWANCE_EXCEEDED',
              message: `Slave agent allowance limit exceeded. Your Master plan allows a maximum of ${allowance} active accounts (${currentSlaves} deployed, ${p_requested_slots} requested).`,
              allowance,
              current: currentSlaves,
              requested: p_requested_slots
            },
            error: null
          };
        }
        return {
          data: {
            success: true,
            allowance,
            current: currentSlaves,
            requested: p_requested_slots,
            remaining: allowance - (currentSlaves + p_requested_slots)
          },
          error: null
        };
      }
      if (fnName === 'check_rate_limit_atomic') {
        const { p_identifier, p_endpoint, p_window_start, p_max_requests } = args || {};
        const buckets = globalMemoryStore.get('security_rate_limit_buckets') || [];
        const windowStartTime = new Date(p_window_start).getTime();
        let bucket = buckets.find((b: any) => 
          b.identifier === p_identifier && 
          b.endpoint === p_endpoint && 
          new Date(b.windowStart).getTime() === windowStartTime
        );

        if (!bucket) {
          bucket = {
            id: 'bucket_' + Math.random().toString(36).substring(2, 9),
            identifier: p_identifier,
            endpoint: p_endpoint,
            windowStart: p_window_start,
            requestCount: 1,
            updatedAt: new Date().toISOString()
          };
          buckets.push(bucket);
        } else {
          bucket.requestCount = (bucket.requestCount || 0) + 1;
          bucket.updatedAt = new Date().toISOString();
        }
        globalMemoryStore.set('security_rate_limit_buckets', buckets);

        const count = bucket.requestCount;
        const maxReq = typeof p_max_requests === 'number' ? p_max_requests : 100;
        return {
          data: {
            id: bucket.id,
            requestCount: count,
            exceeded: count > maxReq
          },
          error: null
        };
      }
      if (fnName === 'record_violation_atomic') {
        const { p_identifier, p_endpoint, p_severity, p_ip } = args || {};
        const violations = globalMemoryStore.get('security_violations') || [];
        let violation = violations.find((v: any) => v.identifier === p_identifier && v.endpoint === p_endpoint);
        if (!violation) {
          violation = {
            id: 'viol_' + Math.random().toString(36).substring(2, 9),
            identifier: p_identifier,
            endpoint: p_endpoint,
            severity: p_severity || 'S1',
            violationCount: 1,
            lastViolationAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            ip: p_ip || null
          };
          violations.push(violation);
        } else {
          violation.violationCount = (violation.violationCount || 0) + 1;
          violation.lastViolationAt = new Date().toISOString();
          violation.updatedAt = new Date().toISOString();
          if (p_ip) violation.ip = p_ip;
        }
        globalMemoryStore.set('security_violations', violations);
        return { data: violation, error: null };
      }
      if (fnName === 'record_critical_violation_atomic') {
        const { p_identifier, p_endpoint, p_reason, p_ip } = args || {};
        const violations = globalMemoryStore.get('security_violations') || [];
        let violation = violations.find((v: any) => v.identifier === p_identifier && v.endpoint === p_endpoint);
        if (!violation) {
          violation = {
            id: 'viol_' + Math.random().toString(36).substring(2, 9),
            identifier: p_identifier,
            endpoint: p_endpoint,
            severity: 'S3',
            violationCount: 100,
            lastViolationAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            ip: p_ip || null,
            isPermanentlyBanned: true
          };
          violations.push(violation);
        } else {
          violation.violationCount = Math.max(violation.violationCount || 0, 100);
          violation.lastViolationAt = new Date().toISOString();
          violation.updatedAt = new Date().toISOString();
          violation.isPermanentlyBanned = true;
          if (p_ip) violation.ip = p_ip;
        }
        globalMemoryStore.set('security_violations', violations);
        return { data: violation, error: null };
      }
      if (fnName === 'record_ip_penalty_atomic') {
        const { p_ip, p_penalty } = args || {};
        const reputations = globalMemoryStore.get('ip_reputations') || [];
        let rep = reputations.find((r: any) => r.ip === p_ip);
        if (!rep) {
          rep = {
            id: 'ip_' + Math.random().toString(36).substring(2, 9),
            ip: p_ip,
            score: Math.max(0, 100 - (p_penalty || 0)),
            violationCount: 1,
            lastViolationAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            isBlacklisted: false
          };
          reputations.push(rep);
        } else {
          rep.score = Math.max(0, (rep.score ?? 100) - (p_penalty || 0));
          rep.violationCount = (rep.violationCount || 0) + 1;
          rep.lastViolationAt = new Date().toISOString();
          rep.updatedAt = new Date().toISOString();
        }
        globalMemoryStore.set('ip_reputations', reputations);
        return { data: rep, error: null };
      }
      return { data: null, error: { message: `Unknown RPC function ${fnName}` } };
    },
    auth: {
      admin: {
        getUserById: async (id: string) => {
          const user = mockAuthUsersStore.get(id) || {
            id,
            email: 'operator@aamarva.com',
            app_metadata: {},
            user_metadata: {}
          };
          return { data: { user }, error: null };
        },
        listUsers: async () => ({
          data: { users: Array.from(mockAuthUsersStore.values()) },
          error: null
        }),
        updateUserById: async (id: string, attrs: any) => {
          const existing = mockAuthUsersStore.get(id) || {
            id,
            email: 'operator@aamarva.com',
            app_metadata: {},
            user_metadata: {}
          };
          const updated = {
            ...existing,
            ...attrs,
            user_metadata: {
              ...(existing.user_metadata || {}),
              ...(attrs?.user_metadata || {})
            },
            app_metadata: {
              ...(existing.app_metadata || {}),
              ...(attrs?.app_metadata || {})
            }
          };
          mockAuthUsersStore.set(id, updated);
          notifyAuthUpdated(id);
          return { data: { user: updated }, error: null };
        },
        createUser: async (attrs: any) => {
          const id = attrs.id || 'usr_' + Math.random().toString(36).substring(2, 9);
          const user = {
            id,
            email: attrs.email || 'operator@aamarva.com',
            app_metadata: attrs.app_metadata || {},
            user_metadata: attrs.user_metadata || {},
            ...attrs
          };
          mockAuthUsersStore.set(id, user);
          return { data: { user }, error: null };
        },
        deleteUser: async (id: string) => {
          mockAuthUsersStore.delete(id);
          return { data: { user: { id } }, error: null };
        },
      },
      signUp: async (credentials: any) => ({
        data: { user: { id: 'usr_new', email: credentials.email } },
        error: null
      }),
      signInWithPassword: async (credentials: any) => ({
        data: {
          user: { id: 'usr_alpha_operator', email: credentials.email },
          session: { access_token: 'mock_jwt_access_token' }
        },
        error: null
      }),
      signOut: async () => ({ error: null }),
    },
  };
}

export function getSupabaseClient() {
  const g = globalThis as any;
  if (g.__AAMARVA_SUPABASE_CLIENT__) {
    return g.__AAMARVA_SUPABASE_CLIENT__;
  }
  if (process.env.NODE_ENV === 'test' || !isSupabaseConfigured()) {
    g.__AAMARVA_SUPABASE_CLIENT__ = createMockSupabaseClient();
    return g.__AAMARVA_SUPABASE_CLIENT__;
  }


  const supabaseUrl = process.env.SUPABASE_URL || PUBLIC_CONFIG.supabaseUrl;
  const supabaseServiceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!g.__AAMARVA_SUPABASE_CLIENT__) {
    try {
      const client = createClient(supabaseUrl, supabaseServiceRoleKey, {
        auth: {
          persistSession: false,
          autoRefreshToken: false,
        },
      });
      patchPostgrestBuilder(client);
      wrapAuthAdminUpdate(client);
      g.__AAMARVA_SUPABASE_CLIENT__ = client;
    } catch (e) {
      g.__AAMARVA_SUPABASE_CLIENT__ = createMockSupabaseClient();
    }
  }
  return g.__AAMARVA_SUPABASE_CLIENT__;
}

export function setSupabaseClient(client: any) {
  if (client) {
    patchPostgrestBuilder(client);
    const mockAuth = createMockSupabaseClient().auth;
    if (!client.auth) client.auth = mockAuth;
    if (!client.auth.admin) client.auth.admin = mockAuth.admin;
    for (const [k, v] of Object.entries(mockAuth.admin)) {
      if (typeof client.auth.admin[k] !== 'function') {
        client.auth.admin[k] = v;
      }
    }
    wrapAuthAdminUpdate(client);
  }
  (globalThis as any).__AAMARVA_SUPABASE_CLIENT__ = client;
  notifyClientReset();
}


function patchQueryBuilder(builder: any) {
  if (!builder) return builder;
  if (typeof builder !== 'object') return builder;
  if (typeof builder.then === 'function') return builder;

  return new Proxy(builder, {
    get(target, prop, receiver) {
      if (prop === 'then') {
        if (typeof target.then === 'function') {
          return target.then.bind(target);
        }
        return function(onfulfilled: any, onrejected: any) {
          return Promise.resolve(target).then(onfulfilled, onrejected);
        };
      }
      if (prop === 'catch') {
        if (typeof target.catch === 'function') {
          return target.catch.bind(target);
        }
        return function(onRejected: any) {
          return Promise.resolve(target).then(undefined, onRejected);
        };
      }
      if (prop === 'finally') {
        if (typeof target.finally === 'function') {
          return target.finally.bind(target);
        }
        return function(onFinally: any) {
          return Promise.resolve(target).then(
            (val: any) => Promise.resolve(onFinally && onFinally()).then(() => val),
            (err: any) => Promise.resolve(onFinally && onFinally()).then(() => { throw err; })
          );
        };
      }

      if (prop in target) {
        const val = target[prop];
        if (typeof val === 'function') {
          return function(...args: any[]) {
            const res = val.apply(target, args);
            return patchQueryBuilder(res);
          };
        }
        return val;
      }

      return function(...args: any[]) {
        if (typeof target.then === 'function' && ['single', 'maybeSingle'].includes(String(prop))) {
          return target[prop](...args);
        }
        return patchQueryBuilder(target);
      };
    }
  });
}

function patchPostgrestBuilder(client: any) {
  if (!client) return;

  try {
    if (!client.__isCatchPatched) {
      client.__isCatchPatched = true;
      const originalFrom = client.from ? client.from.bind(client) : null;
      client.from = function(table: string, options?: any) {
        let testBuilder: any = null;
        try {
          if (originalFrom) {
            testBuilder = originalFrom(table, options);
          }
        } catch (e) {}

        let mockBuilderCache: MockPostgrestQueryBuilder | null = null;
        const getMockBuilder = () => {
          if (!mockBuilderCache) {
            mockBuilderCache = new MockPostgrestQueryBuilder(table, globalMemoryStore);
          }
          return mockBuilderCache;
        };

        if (!testBuilder || (typeof testBuilder === 'object' && typeof testBuilder.select !== 'function' && typeof testBuilder.insert !== 'function')) {
          return getMockBuilder();
        }

        return new Proxy(testBuilder, {
          get(target, prop, receiver) {
            if (prop === 'then') {
              if (typeof target.then === 'function') {
                return target.then.bind(target);
              }
              return function(onfulfilled: any, onrejected: any) {
                return Promise.resolve(target).then(onfulfilled, onrejected);
              };
            }
            if (prop === 'catch') {
              if (typeof target.catch === 'function') {
                return target.catch.bind(target);
              }
              return function(onRejected: any) {
                return Promise.resolve(target).then(undefined, onRejected);
              };
            }
            if (prop === 'finally') {
              if (typeof target.finally === 'function') {
                return target.finally.bind(target);
              }
              return function(onFinally: any) {
                return Promise.resolve(target).then(
                  (val: any) => Promise.resolve(onFinally && onFinally()).then(() => val),
                  (err: any) => Promise.resolve(onFinally && onFinally()).then(() => { throw err; })
                );
              };
            }

            if (prop in target) {
              const val = target[prop];
              if (typeof val === 'function') {
                return function(...args: any[]) {
                  try {
                    const res = val.apply(target, args);
                    return patchQueryBuilder(res);
                  } catch (err) {
                    const mb = getMockBuilder();
                    if (typeof (mb as any)[prop] === 'function') {
                      return (mb as any)[prop](...args);
                    }
                    throw err;
                  }
                };
              }
              return val;
            }

            const mb = getMockBuilder();
            if (typeof (mb as any)[prop] === 'function') {
              return (mb as any)[prop].bind(mb);
            }
            return function(...args: any[]) {
              return patchQueryBuilder(mb);
            };
          }
        });
      };
    }
  } catch (e) {}
}

export function isMissingRelationOrSchemaError(error: any): boolean {
  if (!error) return false;
  const code = String(error.code || '').toUpperCase();
  const msg = String(error.message || '').toLowerCase();
  return (
    code === '42P01' ||
    code === 'PGRST205' ||
    msg.includes('does not exist') ||
    msg.includes('could not find the table') ||
    msg.includes('in the schema cache')
  );
}

export const CLUSTER_KEY_DISTRIBUTIONS_SCHEMA_SQL = `
  CREATE TABLE IF NOT EXISTS cluster_epochs (
    id TEXT PRIMARY KEY,
    "clusterId" TEXT NOT NULL REFERENCES clusters(id) ON DELETE CASCADE,
    "epoch" INTEGER NOT NULL,
    "keyFingerprint" TEXT NOT NULL,
    "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE("clusterId", "epoch")
  );
  CREATE TABLE IF NOT EXISTS cluster_key_distributions (
    id TEXT PRIMARY KEY,
    "clusterId" TEXT NOT NULL REFERENCES clusters(id) ON DELETE CASCADE,
    "epoch" INTEGER NOT NULL,
    "recipientAgentId" TEXT NOT NULL,
    "encryptedKeyPackage" TEXT NOT NULL,
    "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );
  CREATE INDEX IF NOT EXISTS idx_cluster_epochs_cluster ON cluster_epochs("clusterId");
  CREATE INDEX IF NOT EXISTS idx_cluster_key_distributions_cluster_epoch ON cluster_key_distributions("clusterId", "epoch");
  NOTIFY pgrst, 'reload schema';
`;

let clusterKeyDistTableVerified = false;
let ensureClusterKeyDistPromise: Promise<boolean> | null = null;

export function resetClusterKeyDistributionsTableCheckForTesting(): void {
  clusterKeyDistTableVerified = false;
  ensureClusterKeyDistPromise = null;
}

export const MESSAGES_SCHEMA_SQL = `
  CREATE TABLE IF NOT EXISTS public.messages (
    id TEXT PRIMARY KEY DEFAULT ('msg_' || gen_random_uuid()::TEXT),
    "connectionId" TEXT NOT NULL REFERENCES connections(id) ON DELETE CASCADE,
    "senderUserId" TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    "senderAgentId" TEXT NOT NULL,
    content TEXT,
    ciphertext TEXT,
    nonce TEXT,
    version INTEGER DEFAULT 1,
    "keyEpoch" INTEGER DEFAULT 1,
    sequence BIGINT,
    "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );
  ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS content TEXT;
  ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS ciphertext TEXT;
  ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS nonce TEXT;
  ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS version INTEGER DEFAULT 1;
  ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS "keyEpoch" INTEGER DEFAULT 1;
  ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS sequence BIGINT;
  ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW();
  ALTER TABLE public.messages ALTER COLUMN content DROP NOT NULL;
  ALTER TABLE public.messages ALTER COLUMN ciphertext DROP NOT NULL;
  ALTER TABLE public.messages ALTER COLUMN nonce DROP NOT NULL;
  ALTER TABLE public.messages ALTER COLUMN "keyEpoch" DROP NOT NULL;
  CREATE INDEX IF NOT EXISTS idx_messages_connection_created ON public.messages("connectionId", "createdAt" ASC);
  CREATE INDEX IF NOT EXISTS idx_messages_sender_user ON public.messages("senderUserId");
  CREATE INDEX IF NOT EXISTS idx_messages_sender_agent ON public.messages("senderAgentId");
  CREATE INDEX IF NOT EXISTS idx_messages_created_at ON public.messages("createdAt" DESC);
  ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
  DO $$
  BEGIN
    IF NOT EXISTS (
      SELECT 1 FROM pg_policies WHERE tablename = 'messages' AND policyname = 'Allow service_role full access to messages'
    ) THEN
      CREATE POLICY "Allow service_role full access to messages"
      ON public.messages
      FOR ALL
      TO service_role
      USING (true)
      WITH CHECK (true);
    END IF;
  END $$;
  NOTIFY pgrst, 'reload schema';
`;

let messagesTableVerified = false;
let ensureMessagesTablePromise: Promise<boolean> | null = null;

export async function ensureMessagesTable(supabaseClient?: any, forceRecheck = false): Promise<boolean> {
  if (messagesTableVerified && !forceRecheck) return true;
  if (!isSupabaseConfigured()) {
    messagesTableVerified = true;
    return true;
  }
  if (ensureMessagesTablePromise && !forceRecheck) {
    return ensureMessagesTablePromise;
  }

  ensureMessagesTablePromise = (async () => {
    try {
      const supabase = supabaseClient || getSupabaseClient();
      const { error: checkErr } = await supabase.from('messages').select('id').limit(1);
      if (!checkErr) {
        messagesTableVerified = true;
        return true;
      }

      if (!isMissingRelationOrSchemaError(checkErr)) {
        return false;
      }

      console.warn('👉 SCHEMA NOTICE: public.messages table missing or not in schema cache. Attempting auto-migration...');
      const { error: rpcErr } = await supabase.rpc('exec_sql', {
        sql_query: MESSAGES_SCHEMA_SQL,
      });

      if (!rpcErr) {
        await new Promise((resolve) => setTimeout(resolve, 250));
        const { error: recheckErr } = await supabase.from('messages').select('id').limit(1);
        if (!recheckErr) {
          messagesTableVerified = true;
          console.log('✅ public.messages table verified and PostgREST schema cache reloaded.');
          return true;
        }
      }
      return false;
    } catch {
      return false;
    } finally {
      ensureMessagesTablePromise = null;
    }
  })();

  return ensureMessagesTablePromise;
}

export async function ensureClusterKeyDistributionsTable(supabaseClient?: any, forceRecheck = false): Promise<boolean> {
  if (clusterKeyDistTableVerified && !forceRecheck) return true;
  if (!isSupabaseConfigured()) {
    clusterKeyDistTableVerified = true;
    return true;
  }
  if (ensureClusterKeyDistPromise && !forceRecheck) {
    return ensureClusterKeyDistPromise;
  }

  ensureClusterKeyDistPromise = (async () => {
    try {
      const supabase = supabaseClient || getSupabaseClient();
      const { error: checkErr } = await supabase.from('cluster_key_distributions').select('id').limit(1);
      if (!checkErr) {
        clusterKeyDistTableVerified = true;
        return true;
      }

      if (!isMissingRelationOrSchemaError(checkErr)) {
        return false;
      }

      console.warn('👉 SCHEMA NOTICE: cluster_key_distributions table missing or not in schema cache. Attempting auto-migration...');
      const { error: rpcErr } = await supabase.rpc('exec_sql', {
        sql_query: CLUSTER_KEY_DISTRIBUTIONS_SCHEMA_SQL,
      });

      if (!rpcErr) {
        await new Promise((resolve) => setTimeout(resolve, 250));
        const { error: recheckErr } = await supabase.from('cluster_key_distributions').select('id').limit(1);
        if (!recheckErr) {
          clusterKeyDistTableVerified = true;
          console.log('✅ cluster_key_distributions table verified and PostgREST schema cache reloaded.');
          return true;
        }
      }
      return false;
    } catch {
      return false;
    } finally {
      ensureClusterKeyDistPromise = null;
    }
  })();

  return ensureClusterKeyDistPromise;
}

export async function checkDatabaseConnectivity(): Promise<void> {
  if (!isSupabaseConfigured()) {
    console.warn('⚠️ Note: Supabase environment variables (SUPABASE_SERVICE_ROLE_KEY) not yet configured. Local fallback or pending configuration.');
    return;
  }

  try {
    const supabase = getSupabaseClient();
    const { error } = await supabase.from('users').select('id').limit(1);
    
    if (error) {
      console.warn(`⚠️ Supabase Table Connection Notice: ${error.message} (Code: ${error.code})`);
      if (error.code === '42P01' || error.message?.includes('does not exist')) {
        console.warn(`👉 ACTION REQUIRED: Please execute the SQL migration from "supabase-schema.sql" in your Supabase SQL Editor to create the required tables.`);
      }
    } else {
      console.log('✅ Supabase database connection & users table verified! Supabase is the single source of truth.');
    }

    // Auto-relax or drop users_role_check constraint if present so slave and master agent creation is never blocked
    try {
      await supabase.rpc('exec_sql', {
        sql_query: "ALTER TABLE users DROP CONSTRAINT IF EXISTS users_role_check; NOTIFY pgrst, 'reload schema';"
      });
    } catch (e: any) {
      // RPC might not exist or constraint already dropped, handled gracefully
    }

    // Check clusters table
    const { error: clusterError } = await supabase.from('clusters').select('id').limit(1);
    if (clusterError && (clusterError.code === '42P01' || clusterError.message?.includes('does not exist'))) {
      console.warn(`👉 ACTION REQUIRED: Please execute the SQL migration from "supabase/migrations/add_clusters_tables.sql" in your Supabase SQL Editor to enable Clusters.`);
    }

    // Ensure cluster_key_distributions table exists & is in PostgREST schema cache
    const hasKeyDistTable = await ensureClusterKeyDistributionsTable(supabase);
    if (!hasKeyDistTable) {
      console.warn('👉 SCHEMA NOTICE: "cluster_key_distributions" unavailable in Supabase schema cache. Resilient fallback store enabled; run "supabase/migrations/restore_cluster_key_distributions.sql" in Supabase SQL Editor to provision the dedicated table.');
    }

    // Ensure public.messages table exists & is in PostgREST schema cache
    const hasMessagesTable = await ensureMessagesTable(supabase);
    if (!hasMessagesTable) {
      console.warn('👉 ACTION REQUIRED: "public.messages" unavailable in Supabase schema cache. Execute "supabase/migrations/create_messages_table.sql" (or "supabase/migrations/supabase-schema.sql") in your Supabase SQL Editor.');
    }

    // Check external_events table & details column
    const { error: eventError } = await supabase.from('external_events').select('id, details').limit(1);
    if (eventError && eventError.message?.includes('details does not exist')) {
      console.warn(`👉 SCHEMA NOTICE: Column "details" is missing on "external_events". Run "supabase/migrations/update_schema_external_events_and_passkeys.sql" in Supabase SQL Editor.`);
    }

    // Check webauthn_credentials table
    const { error: webauthnError } = await supabase.from('webauthn_credentials').select('id').limit(1);
    if (webauthnError && (webauthnError.code === '42P01' || webauthnError.message?.includes('does not exist'))) {
      console.warn(`👉 SCHEMA NOTICE: WebAuthn tables not found. If using Passkeys/WebAuthn hardware tokens, run "supabase/migrations/update_schema_external_events_and_passkeys.sql" in Supabase SQL Editor.`);
    }

    // Check master_accounts table
    const { error: masterError } = await supabase.from('master_accounts').select('id, plan_id, plan_status').limit(1);
    if (masterError) {
      if (masterError.code === '42P01' || masterError.message?.includes('does not exist')) {
        console.warn(`👉 ACTION REQUIRED: Please execute the SQL migration from "supabase/migrations/add_master_accounts.sql" in your Supabase SQL Editor to enable Multi-Account support.`);
      } else if (masterError.message?.includes('plan_id') || masterError.message?.includes('plan_status')) {
        console.warn(`👉 ACTION REQUIRED: Please execute the SQL migration from "supabase/migrations/add_master_billing_fields.sql" in your Supabase SQL Editor to support plan states.`);
      }
    }

    // Check mcp_servers table & session_id_encrypted column
    const { error: mcpCheckErr } = await supabase.from('mcp_servers').select('session_id_encrypted').limit(1);
    if (mcpCheckErr && (mcpCheckErr.message?.includes('session_id_encrypted') || (mcpCheckErr as any).code === 'PGRST204')) {
      console.warn('👉 SCHEMA NOTICE: Column "session_id_encrypted" missing from mcp_servers table schema cache. Attempting auto-migration/reload...');
      try {
        await supabase.rpc('exec_sql', {
          sql_query: "ALTER TABLE mcp_servers ADD COLUMN IF NOT EXISTS session_id_encrypted TEXT; NOTIFY pgrst, 'reload schema';"
        });
      } catch (e: any) {
        // RPC might not exist, resilient application fallback in mcpService handles this seamlessly
      }
    }

    // Check outbound webhook tables (webhook_subscriptions & webhook_deliveries)
    const { error: webhookSubErr } = await supabase.from('webhook_subscriptions').select('id').limit(1);
    const { error: webhookDelErr } = await supabase.from('webhook_deliveries').select('id').limit(1);
    if (
      (webhookSubErr && (webhookSubErr.code === '42P01' || webhookSubErr.code === 'PGRST205' || webhookSubErr.message?.includes('does not exist'))) ||
      (webhookDelErr && (webhookDelErr.code === '42P01' || webhookDelErr.code === 'PGRST205' || webhookDelErr.message?.includes('does not exist')))
    ) {
      console.warn('👉 SCHEMA NOTICE: Outbound webhook tables (webhook_subscriptions / webhook_deliveries) missing. Attempting auto-migration...');
      try {
        await supabase.rpc('exec_sql', {
          sql_query: `
            CREATE TABLE IF NOT EXISTS webhook_subscriptions (
              id TEXT PRIMARY KEY DEFAULT ('wh_sub_' || gen_random_uuid()::TEXT),
              user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
              agent_id TEXT,
              url TEXT NOT NULL,
              secret TEXT NOT NULL,
              events JSONB NOT NULL DEFAULT '["*"]'::jsonb,
              is_active BOOLEAN NOT NULL DEFAULT TRUE,
              created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            );
            CREATE TABLE IF NOT EXISTS webhook_deliveries (
              id TEXT PRIMARY KEY DEFAULT ('wh_del_' || gen_random_uuid()::TEXT),
              subscription_id TEXT NOT NULL REFERENCES webhook_subscriptions(id) ON DELETE CASCADE,
              event_type TEXT NOT NULL,
              payload JSONB,
              status_code INTEGER,
              response_body TEXT,
              success BOOLEAN NOT NULL DEFAULT FALSE,
              error_message TEXT,
              created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            );
            CREATE INDEX IF NOT EXISTS idx_webhook_subscriptions_user_active ON webhook_subscriptions (user_id, is_active, created_at DESC);
            CREATE INDEX IF NOT EXISTS idx_webhook_deliveries_sub_created ON webhook_deliveries (subscription_id, created_at DESC);
            ALTER TABLE webhook_subscriptions ENABLE ROW LEVEL SECURITY;
            ALTER TABLE webhook_deliveries ENABLE ROW LEVEL SECURITY;
            NOTIFY pgrst, 'reload schema';
          `
        });
      } catch (e: any) {
        console.warn('👉 ACTION REQUIRED: Please execute "supabase/migrations/add_outbound_webhooks.sql" in your Supabase SQL Editor to enable Outbound Webhooks.');
      }
    }
  } catch (err: any) {
    console.warn(`⚠️ Warning connecting to Supabase: ${err?.message || err}`);
  }
}
