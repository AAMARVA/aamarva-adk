import { Response } from 'express';
import crypto from 'crypto';
import { getSupabaseClient } from '../supabase.js';
import { realtimeService } from './realtimeService.js';
import { getClusterSymbol } from '../lib/clusterSymbols.js';

export interface WatchtowerActivityRecord {
  id: string;
  activityKey?: string;
  entityId?: string;
  agentId: string;
  agentName: string;
  avatar?: string;
  emailVerified?: boolean;
  text: string;
  type: string;
  category?: 'connection' | 'account' | 'cluster' | 'plan' | 'security' | 'tool' | 'general';
  peerName?: string;
  peerAgentId?: string;
  peerAvatar?: string;
  peerUserId?: string;
  actorRole?: 'master' | 'slave' | 'agent';
  peerRole?: 'master' | 'slave' | 'agent';
  outcome?: 'success' | 'failed' | 'pending' | 'info';
  status?: string;
  cluster?: any;
  post?: any;
  planDetails?: {
    planName?: string;
    actionType?: string;
    accounts?: number;
    slaveAccountsAdded?: number;
    masterSlotsAdded?: number;
    masterSlotsTotal?: number;
    amount?: number;
    currency?: string;
    validityDays?: number;
    targetAccountIds?: string[];
    fleetIds?: string[];
    registeredEmails?: string[];
  };
  details?: any;
  technicalDetails?: any;
  createdAt: string;
  actorUserId?: string;
  masterId?: string;
  peerMasterId?: string;
  isMasterOnly?: boolean;
}

export type FloorActivityRecord = WatchtowerActivityRecord;

export interface WatchtowerViewerContext {
  userId: string;
  agentId?: string;
  masterId?: string;
  isMaster: boolean;
}

/**
 * Strips all sensitive credentials, secret tokens, password hashes, and private keys.
 */
export function sanitizeStructuredDetails(obj: any): any {
  if (!obj || typeof obj !== 'object') return obj;
  if (Array.isArray(obj)) return obj.map(sanitizeStructuredDetails);

  const sensitiveKeywords = [
    'password', 'passwordhash', 'apikey', 'apikeyhash', 'apikeyfingerprint',
    'secret', 'token', 'refreshtoken', 'privatekey', 'recoverykey',
    'seed', 'credential', 'authheader', 'hash', 'signature'
  ];

  const sanitized: Record<string, any> = {};
  for (const [key, value] of Object.entries(obj)) {
    const lowerKey = key.toLowerCase();
    if (sensitiveKeywords.some((s) => lowerKey.includes(s))) {
      continue;
    }
    if (typeof value === 'object' && value !== null) {
      sanitized[key] = sanitizeStructuredDetails(value);
    } else {
      sanitized[key] = value;
    }
  }
  return sanitized;
}

export function stripAllPrefixes(id?: string): string {
  if (!id || typeof id !== 'string') return '';
  let current = id.trim();
  let changed = true;
  while (changed) {
    changed = false;
    const stripped = current.replace(/^(fp_|wt_cap_|wt_plan_(?!box_)|wt_|sf_|evt_|conn_|recip_|inv_|act_)/i, '');
    if (stripped !== current) {
      current = stripped;
      changed = true;
    }
  }
  return current.toLowerCase();
}

/**
 * Builds a deterministic canonical key for activity deduplication across live & historical sources.
 */
export function buildCanonicalKey(
  type: string,
  actor: string,
  peer: string | undefined,
  createdAt: string,
  explicitId?: string
): string {
  const normType = (type || 'activity').toLowerCase().trim();
  const normActor = (actor || 'agent').replace(/^@+/, '').toLowerCase().trim();
  const normPeer = (peer || '').replace(/^@+/, '').toLowerCase().trim();

  const cleanId = explicitId ? stripAllPrefixes(explicitId) : '';

  // If an explicit clean business ID exists (>= 6 chars, not client random), it serves as the definitive key
  if (cleanId && cleanId.length >= 6 && !cleanId.startsWith('0.') && !cleanId.includes('math')) {
    return `act_canon:${cleanId}`;
  }

  const pair = [normActor, normPeer].filter(Boolean).sort().join('<->');

  if (normType.includes('connection')) {
    const action = normType.includes('dissolv') || normType.includes('remov') ? 'dissolved' : 'established';
    return `conn_canon:${pair}:${action}`;
  }

  if (normType.includes('cluster')) {
    const targetCluster = normPeer || 'cluster';
    return `cluster_canon:${normActor}:${normType}:${targetCluster}`;
  }

  if (normType.includes('capability') || normType.includes('plan')) {
    return `plan_canon:${normActor}:${normType}:${cleanId || createdAt || 'single'}`;
  }

  if (normType.includes('slave') || normType.includes('registered')) {
    const target = normPeer || normActor;
    return `account_canon:${target}:${normType}`;
  }

  return `act_canon:${normActor}:${normType}:${normPeer}:${cleanId || 'single'}`;
}

class WatchtowerActivityService {
  private recentActivities: WatchtowerActivityRecord[] = [];
  private sseClients: Map<Response, WatchtowerViewerContext> = new Map();
  private ssePingIntervals: Map<Response, ReturnType<typeof setInterval>> = new Map();
  private readonly maxActivities = 200;
  private agentMasterCache: Map<string, string> = new Map();

  /**
   * Checks whether a specific activity record is authorized to be viewed by a given viewer.
   * Strict fleet-level isolation:
   * - Master viewer: Can see their own activity and activities within their own fleet of slave agents.
   *   Can NEVER see another master's fleet activity.
   * - Slave viewer: Can ONLY see their own authorized activity and events involving their own node.
   *   Can NEVER see other slaves' private activity or master-only administrative events.
   */
  public isRecordAuthorizedForViewer(record: WatchtowerActivityRecord, viewer?: WatchtowerViewerContext): boolean {
    if (!viewer || !viewer.userId) {
      return false;
    }

    const vUserId = viewer.userId.toLowerCase().trim();
    const vAgentId = viewer.agentId ? viewer.agentId.replace(/^@+/, '').toLowerCase().trim() : '';
    const vMasterId = (viewer.masterId || viewer.userId).toLowerCase().trim();

    const rAgentId = (record.agentId || '').replace(/^@+/, '').toLowerCase().trim();
    const rActorUserId = (record.actorUserId || '').toLowerCase().trim();
    const rMasterId = (record.masterId || '').toLowerCase().trim();
    const rPeerAgentId = (record.peerAgentId || '').replace(/^@+/, '').toLowerCase().trim();
    const rPeerUserId = (record.peerUserId || '').toLowerCase().trim();
    const rPeerMasterId = (record.peerMasterId || '').toLowerCase().trim();

    // 1. If viewer is a Master Account
    if (viewer.isMaster) {
      // Direct match on masterId
      if (rMasterId && rMasterId === vMasterId) {
        return true;
      }

      // Can see any event where actor is this master or a slave/slot in this master's fleet
      if (rActorUserId && (rActorUserId === vUserId || rActorUserId === vMasterId)) {
        return true;
      }
      if (vAgentId && rAgentId === vAgentId) {
        return true;
      }
      if (rActorUserId) {
        const cachedActor = this.agentMasterCache.get(rActorUserId);
        if (cachedActor === vMasterId || (cachedActor && cachedActor === this.agentMasterCache.get(vMasterId))) {
          return true;
        }
      }
      if (rAgentId) {
        const cachedAgent = this.agentMasterCache.get(rAgentId);
        if (cachedAgent === vMasterId || (cachedAgent && cachedAgent === this.agentMasterCache.get(vMasterId))) {
          return true;
        }
      }

      // Inbound event handling: recipient fleet sees MESSAGE_RECEIVED/ATTACHMENT_RECEIVED; sender sees MESSAGE_SENT/ATTACHMENT_SENT
      const upperRecType = (record.type || '').toUpperCase();
      const isOutboundSentEvent = upperRecType === 'MESSAGE_SENT' || upperRecType === 'ATTACHMENT_SENT';
      const isInboundReceivedEvent = upperRecType === 'MESSAGE_RECEIVED' || upperRecType === 'ATTACHMENT_RECEIVED';

      if (isInboundReceivedEvent) {
        // Only recipient fleet sees MESSAGE_RECEIVED/ATTACHMENT_RECEIVED. The peer (sender) must NOT see it.
        if (rMasterId && rMasterId === vMasterId) return true;
        if (rActorUserId && (rActorUserId === vUserId || rActorUserId === vMasterId)) return true;
        if (vAgentId && rAgentId === vAgentId) return true;
        if ((rActorUserId && this.agentMasterCache.get(rActorUserId) === vMasterId) ||
            (rAgentId && this.agentMasterCache.get(rAgentId) === vMasterId)) {
          return true;
        }
        return false;
      }

      if (!isOutboundSentEvent) {
        if (rPeerMasterId && rPeerMasterId === vMasterId) {
          return true;
        }
        if (rPeerUserId && (rPeerUserId === vUserId || rPeerUserId === vMasterId)) {
          return true;
        }
        if (vAgentId && rPeerAgentId === vAgentId) {
          return true;
        }
        if ((rPeerUserId && this.agentMasterCache.get(rPeerUserId) === vMasterId) ||
            (rPeerAgentId && this.agentMasterCache.get(rPeerAgentId) === vMasterId)) {
          return true;
        }
      }

      // Cluster membership check for master
      if (record.cluster && (record.cluster.memberAgentIds || record.cluster.members)) {
        const members: string[] = (record.cluster.memberAgentIds || record.cluster.members || []).map((m: any) =>
          String(typeof m === 'string' ? m : (m.agentId || m.id || '')).replace(/^@+/, '').toLowerCase().trim()
        );
        if ((vAgentId && members.includes(vAgentId)) || (vUserId && members.includes(vUserId)) || (vMasterId && members.includes(vMasterId))) {
          return true;
        }
      }

      // Strict isolation: if rMasterId belongs to another master and there is no peer/cluster link, deny
      if (rMasterId && rMasterId !== vMasterId) {
        const cachedR = this.agentMasterCache.get(rMasterId);
        const cachedV = this.agentMasterCache.get(vMasterId);
        if (cachedR && cachedV && cachedR !== cachedV && cachedR !== vMasterId && cachedV !== rMasterId) {
          return false;
        }
      }

      // Fail closed if no master/actor/peer/cluster relationship matches this viewer's fleet
      return false;
    }

    // 2. If viewer is a Slave Agent Account
    if (record.isMasterOnly) {
      return false;
    }

    if (rActorUserId === vUserId || (vAgentId && rAgentId === vAgentId)) {
      return true;
    }

    if (rPeerUserId === vUserId || (vAgentId && rPeerAgentId === vAgentId)) {
      return true;
    }

    if (record.cluster && (record.cluster.memberAgentIds || record.cluster.members)) {
      const members: string[] = (record.cluster.memberAgentIds || record.cluster.members || []).map((m: any) =>
        String(typeof m === 'string' ? m : (m.agentId || m.id || '')).replace(/^@+/, '').toLowerCase().trim()
      );
      if (vAgentId && members.includes(vAgentId)) {
        return true;
      }
    }

    return false;
  }

  /**
   * Resolves the master ID for an agent or user ID with in-memory caching.
   */
  public async resolveMasterIdForActor(agentOrUserId: string): Promise<string | null> {
    if (!agentOrUserId) return null;
    const clean = agentOrUserId.replace(/^@+/, '').toLowerCase().trim();
    if (this.agentMasterCache.has(clean)) {
      return this.agentMasterCache.get(clean)!;
    }

    try {
      const supabase = getSupabaseClient();
      let data: any = null;
      const { data: byId } = await supabase.from('users').select('*').eq('id', clean).maybeSingle();
      if (byId) {
        data = byId;
      } else {
        const { data: byAgentId } = await supabase.from('users').select('*').ilike('agentId', clean).maybeSingle();
        if (byAgentId) {
          data = byAgentId;
        } else {
          const { data: byPrefixed } = await supabase.from('users').select('*').ilike('agentId', `@${clean}`).maybeSingle();
          data = byPrefixed;
        }
      }

      if (data) {
        let currId = (data.master_id && !data.is_master_primary) ? data.master_id : data.id;
        for (let depth = 0; depth < 5; depth++) {
          const { data: uRec } = await supabase
            .from('users')
            .select('id, master_id, is_master_primary, account_type')
            .eq('id', currId)
            .maybeSingle();
          if (uRec?.master_id && uRec.master_id !== currId && uRec.is_master_primary !== true) {
            currId = uRec.master_id;
          } else {
            break;
          }
        }
        this.agentMasterCache.set(clean, currId);
        if (data.id) this.agentMasterCache.set(data.id.toLowerCase().trim(), currId);
        if (data.agentId) this.agentMasterCache.set(data.agentId.replace(/^@+/, '').toLowerCase().trim(), currId);
        return currId;
      }
    } catch {}

    return null;
  }

  /**
   * Converts any raw event or database row into a structured, human-readable WatchtowerActivityRecord.
   */
  public formatStructuredRecord(
    raw: any,
    agentProfileMap: Record<string, any> = {},
    source: 'live' | 'footprint' | 'external_event' | 'connection' = 'live'
  ): WatchtowerActivityRecord | null {
    if (!raw) return null;

    const id = raw.id || `wt_${crypto.randomUUID()}`;
    const createdAt = raw.createdAt || raw.created_at || new Date().toISOString();
    const rawType = (raw.type || raw.action || 'activity').toUpperCase();

    // Parse details safely
    let parsedDetails: any = raw.details;
    if (typeof parsedDetails === 'string') {
      const trimmed = parsedDetails.trim();
      if ((trimmed.startsWith('{') && trimmed.endsWith('}')) || (trimmed.startsWith('[') && trimmed.endsWith(']'))) {
        try {
          parsedDetails = JSON.parse(trimmed);
        } catch {}
      }
    }

    const actorUserId = raw.actorUserId || raw.user_id || raw.userId;
    const masterId = raw.masterId || raw.master_id || actorUserId;

    const prof = (actorUserId ? agentProfileMap[actorUserId] : undefined) ||
                 (masterId ? agentProfileMap[masterId] : undefined) ||
                 (raw.agentId ? agentProfileMap[raw.agentId.toLowerCase()] : undefined) ||
                 (raw.agentName ? agentProfileMap[raw.agentName.toLowerCase()] : undefined);

    let agentId = raw.agentId || raw.agent_id || prof?.agentId || (actorUserId ? agentProfileMap[actorUserId]?.agentId : undefined) || 'AGENT';
    if (prof?.agentId && (agentId === 'AGENT' || agentId === 'Master')) {
      agentId = prof.agentId;
    }
    agentId = agentId.replace(/^@+/, '');

    let agentName = prof?.name;
    if (!agentName) {
      if (raw.agentName && raw.agentName !== 'AGENT' && raw.agentName !== 'Master Account') {
        agentName = raw.agentName;
      } else if (raw.agent_name && raw.agent_name !== 'AGENT' && raw.agent_name !== 'Master Account') {
        agentName = raw.agent_name;
      } else {
        agentName = agentId;
      }
    }

    let avatar = prof?.avatar || (raw.avatar && raw.avatar !== '🤖' && raw.avatar !== '👾' ? raw.avatar : undefined);
    if (!avatar || avatar === '🤖' || avatar === '👾') {
      avatar = `https://robohash.org/${encodeURIComponent((agentId || agentName || 'agent').toLowerCase())}.png?size=150x150`;
    }
    const emailVerified = prof?.emailVerified ?? Boolean(raw.emailVerified);

    let peerAgentId = (raw.peerAgentId || raw.peer_agent_id || raw.target || '').replace(/^@+/, '') || undefined;
    let peerUserId = raw.peerUserId || raw.peer_user_id || undefined;
    const peerProf = peerAgentId ? (agentProfileMap[peerAgentId.toLowerCase()] || agentProfileMap[peerUserId] || (raw.peerName ? agentProfileMap[raw.peerName.toLowerCase()] : undefined)) : undefined;
    let peerName = peerProf?.name || raw.peerName || raw.peer_name || peerAgentId || undefined;
    let peerAvatar = peerProf?.avatar || raw.peerAvatar || raw.peer_avatar;
    if (!peerAvatar || peerAvatar === '🤖' || peerAvatar === '👾') {
      peerAvatar = peerAgentId ? `https://robohash.org/${encodeURIComponent(peerAgentId.toLowerCase())}.png?size=150x150` : undefined;
    }

    if (!peerAgentId && typeof raw.details === 'string' && !raw.details.trim().startsWith('{') && !rawType.includes('PLAN') && !rawType.includes('CAPABILITY')) {
      const matchPeer = raw.details.match(/(?:^|\s)@([a-zA-Z0-9_-]+)/);
      if (matchPeer) {
        peerAgentId = matchPeer[1];
      }
    }
    if (!raw.activityKey && typeof raw.details === 'string') {
      const keyMatch = raw.details.match(/\[key:([^\]]+)\]/);
      if (keyMatch) {
        raw.activityKey = keyMatch[1];
      }
    }

    let category: WatchtowerActivityRecord['category'] = 'general';
    let outcome: WatchtowerActivityRecord['outcome'] = 'info';
    let text = typeof raw.text === 'string' && raw.text.trim() ? raw.text.trim() : '';
    if (!text && parsedDetails && typeof parsedDetails === 'object' && parsedDetails._text) {
      text = parsedDetails._text;
    }
    if (!text && typeof raw.details === 'string' && raw.details.trim() && !raw.details.trim().startsWith('{')) {
      text = raw.details.trim();
    }
    let planDetails: WatchtowerActivityRecord['planDetails'] = raw.planDetails;
    let cluster = raw.cluster;

    // Detect if text is a raw serialized JSON dump (e.g. from external_events)
    const isTextRawJson = text.startsWith('{') && text.endsWith('}') && (text.includes('master_id') || text.includes('validity_days') || text.includes('batch_id'));
    if (isTextRawJson && !parsedDetails) {
      try {
        parsedDetails = JSON.parse(text);
      } catch {}
      text = '';
    }

    // Suppress child per-slave capability rows that belong to a batch (batch row is the canonical entry)
    if (rawType === 'SLAVE_CAPABILITY_ACTIVATED' && parsedDetails?.batch_id) {
      return null;
    }

    // Filter out legacy phantom middleware rows emitted by previous buy-plan middleware fallback
    // which had text "activated Capability Increment Plan" with zero capability metadata.
    const cleanLowerText = text.toLowerCase().replace(/^@\S+\s+/, '').trim();
    const isPhantomMiddlewareCapabilityRow =
      rawType === 'SLAVE_CAPABILITY_BATCH_ACTIVATED' &&
      (cleanLowerText === 'activated capability increment plan' || cleanLowerText.startsWith('activated capability increment plan (')) &&
      !parsedDetails?.batch_id &&
      !parsedDetails?.validity_days &&
      !parsedDetails?.validity_days_extended &&
      !parsedDetails?.accounts_count &&
      !(Array.isArray(parsedDetails?.target_account_ids) && parsedDetails.target_account_ids.length > 0) &&
      !(Array.isArray(parsedDetails?.target_accounts) && parsedDetails.target_accounts.length > 0) &&
      !parsedDetails?.metadata?.validity_days_extended &&
      !raw.planDetails?.validityDays;

    if (isPhantomMiddlewareCapabilityRow) {
      return null;
    }

    // Determine category, outcome, and human-readable text
    if (rawType.includes('CAPABILITY_BATCH') || rawType === 'SLAVE_CAPABILITY_BATCH_ACTIVATED') {
      category = 'plan';
      outcome = 'success';
      const hasStructuredCap = Boolean(
        raw.planDetails?.accounts ||
        raw.planDetails?.validityDays ||
        parsedDetails?.batch_id ||
        parsedDetails?.accounts_count ||
        parsedDetails?.validity_days ||
        parsedDetails?.validity_days_extended ||
        parsedDetails?.metadata?.validity_days_extended ||
        parsedDetails?.metadata?.accounts_in_transaction ||
        (Array.isArray(parsedDetails?.target_account_ids) && parsedDetails.target_account_ids.length > 0)
      );
      const count =
        raw.planDetails?.accounts ||
        parsedDetails?.accounts_count ||
        (Array.isArray(parsedDetails?.target_account_ids) ? parsedDetails.target_account_ids.length : 0) ||
        parsedDetails?.metadata?.accounts_in_transaction ||
        1;
      const days =
        raw.planDetails?.validityDays ||
        parsedDetails?.validity_days ||
        parsedDetails?.validity_days_extended ||
        parsedDetails?.metadata?.validity_days_extended ||
        30;
      if (!text || hasStructuredCap || text.startsWith('Master ')) {
        text = `activated Capability Increment Plan (+${days} Days) for ${count} slave account${count === 1 ? '' : 's'}`;
      }
      planDetails = {
        planName: 'Capability Increment Plan',
        actionType: 'capability_increment',
        accounts: count,
        validityDays: days,
        targetAccountIds: raw.planDetails?.targetAccountIds || parsedDetails?.target_account_ids || []
      };
    } else if (rawType.includes('CAPABILITY') || rawType === 'SLAVE_CAPABILITY_ACTIVATED') {
      category = 'plan';
      outcome = 'success';
      const days =
        raw.planDetails?.validityDays ||
        parsedDetails?.validity_days ||
        parsedDetails?.validity_days_extended ||
        parsedDetails?.metadata?.validity_days_extended ||
        30;
      const targetAccount = (peerAgentId || parsedDetails?.agent_id || parsedDetails?.user_id || agentId).replace(/^@+/, '');
      const hasStructuredSingleCap = Boolean(
        raw.planDetails?.validityDays ||
        parsedDetails?.validity_days ||
        parsedDetails?.validity_days_extended ||
        parsedDetails?.metadata?.validity_days_extended ||
        parsedDetails?.agent_id
      );
      if (!text || hasStructuredSingleCap || /^activated capability increment/i.test(text)) {
        text = `activated Capability Increment Plan (+${days} Days) for @${targetAccount}`;
      }
      planDetails = {
        planName: 'Capability Increment Plan',
        actionType: 'capability_increment',
        accounts: raw.planDetails?.accounts || 1,
        validityDays: days,
        ...(raw.planDetails?.targetAccountIds ? { targetAccountIds: raw.planDetails.targetAccountIds } : {})
      };
    } else if (rawType.includes('PLAN_ENTITLEMENT') || rawType === 'PLAN_ENTITLEMENT_ACTIVATED' || rawType === 'CAPACITY_UPDATED' || rawType.includes('CAPACITY')) {
      category = 'plan';
      outcome = 'success';
      const blocks = Array.isArray(parsedDetails?.metadata?.blocks) ? parsedDetails.metadata.blocks : [];
      const txId =
        parsedDetails?.tx_id ||
        parsedDetails?.latest_transaction_id ||
        parsedDetails?.metadata?.latest_transaction_id;
      const matchedBlock = txId ? blocks.find((b: any) => b?.id === txId) : null;
      const fallbackBlock = !matchedBlock && blocks.length > 0 ? blocks[blocks.length - 1] : null;
      const txBlock = matchedBlock || (fallbackBlock && fallbackBlock.action_type ? fallbackBlock : null);

      const legacyMatch = text.match(/Master expanded fleet capacity\s*\(\+?(\d+)\s+Accounts?,\s*(\d+)\s+total\)/i);
      const legacyAdded = legacyMatch ? Number(legacyMatch[1]) : undefined;
      const legacyTotal = legacyMatch ? Number(legacyMatch[2]) : undefined;

      const hasExplicitStructuredAdded =
        raw.planDetails?.slaveAccountsAdded !== undefined ||
        matchedBlock?.allowance !== undefined ||
        parsedDetails?.added_accounts !== undefined ||
        parsedDetails?.metadata?.added_accounts !== undefined ||
        parsedDetails?.metadata?.accounts_bought !== undefined ||
        parsedDetails?.metadata?.accounts_in_transaction !== undefined ||
        parsedDetails?.added !== undefined ||
        txBlock?.allowance !== undefined;

      const allowance = Number(
        parsedDetails?.allowance_accounts ??
        parsedDetails?.total ??
        raw.planDetails?.accounts ??
        legacyTotal ??
        10
      );

      let addedSlaves = Number(
        raw.planDetails?.slaveAccountsAdded ??
        matchedBlock?.allowance ??
        parsedDetails?.added_accounts ??
        parsedDetails?.metadata?.added_accounts ??
        parsedDetails?.metadata?.accounts_bought ??
        parsedDetails?.metadata?.accounts_in_transaction ??
        parsedDetails?.added ??
        txBlock?.allowance ??
        (legacyAdded !== undefined ? legacyAdded : 0)
      );
      if (isNaN(addedSlaves) || addedSlaves < 0) addedSlaves = 0;

      const prevAllowance = parsedDetails?.metadata?.previous_allowance !== undefined
        ? Number(parsedDetails.metadata.previous_allowance)
        : undefined;

      let addedMasterSlots = Number(
        raw.planDetails?.masterSlotsAdded ??
        matchedBlock?.master_slots_added ??
        parsedDetails?.master_slots_added ??
        parsedDetails?.metadata?.master_slots_added ??
        txBlock?.master_slots_added ??
        0
      );
      if (isNaN(addedMasterSlots) || addedMasterSlots < 0) addedMasterSlots = 0;

      const totalMasterSlots = Number(
        raw.planDetails?.masterSlotsTotal ??
        parsedDetails?.master_slots ??
        parsedDetails?.metadata?.master_slots ??
        (addedMasterSlots > 0 ? addedMasterSlots + 1 : 1)
      );

      let actionType =
        raw.planDetails?.actionType ||
        parsedDetails?.action_type ||
        matchedBlock?.action_type ||
        parsedDetails?.metadata?.action_type ||
        txBlock?.action_type ||
        'activation';

      // Infer add_accounts when legacy CAPACITY_UPDATED / plan records omit action_type
      if (actionType === 'activation' || (actionType === 'new_plan' && prevAllowance !== undefined && prevAllowance > 0)) {
        if (prevAllowance !== undefined && prevAllowance > 0 && prevAllowance === allowance && addedMasterSlots > 0 && addedSlaves === 0) {
          actionType = 'add_accounts';
        } else if (actionType === 'activation' && addedSlaves > 0 && allowance > addedSlaves) {
          actionType = 'add_accounts';
        } else if (actionType === 'activation' && addedMasterSlots > 0 && prevAllowance && prevAllowance > 0) {
          actionType = 'add_accounts';
        } else if (actionType === 'activation' && legacyAdded !== undefined && legacyTotal !== undefined && legacyAdded < legacyTotal) {
          actionType = 'add_accounts';
        }
      }

      const txAmount =
        raw.planDetails?.amount ??
        matchedBlock?.amount ??
        txBlock?.amount ??
        parsedDetails?.amount ??
        parsedDetails?.metadata?.amount;
      const fleetIds =
        raw.planDetails?.fleetIds ||
        parsedDetails?.fleet_ids ||
        matchedBlock?.fleet_ids ||
        txBlock?.fleet_ids ||
        (matchedBlock?.fleet_id ? [matchedBlock.fleet_id] : (txBlock?.fleet_id ? [txBlock.fleet_id] : undefined)) ||
        parsedDetails?.metadata?.new_fleet_ids;
      const registeredEmails =
        raw.planDetails?.registeredEmails ||
        parsedDetails?.registered_emails ||
        matchedBlock?.registered_emails ||
        txBlock?.registered_emails;

      const isExplicitNewPlan =
        actionType === 'new_plan' &&
        !(prevAllowance !== undefined && prevAllowance > 0 && prevAllowance === allowance && addedMasterSlots > 0 && addedSlaves === 0);
      const isMasterSlotOnly =
        actionType === 'add_master_slot' ||
        (!isExplicitNewPlan && addedMasterSlots > 0 && addedSlaves === 0);
      const isCombinedAddOn =
        !isExplicitNewPlan &&
        addedMasterSlots > 0 &&
        addedSlaves > 0;
      const isSlaveAddOnOnly =
        !isExplicitNewPlan &&
        addedSlaves > 0 &&
        addedMasterSlots === 0 &&
        (actionType === 'add_accounts' || allowance > addedSlaves);

      const derivedPlanName =
        isMasterSlotOnly
          ? 'Master Account Slot Plan'
          : isCombinedAddOn
          ? 'Master & Slave Capacity Expansion'
          : isSlaveAddOnOnly
          ? 'Slave Capacity Add-On Plan'
          : (raw.planDetails?.planName || parsedDetails?.plan_name || 'Master & Slave Agent Plan');

      const hasStructuredPlanData = Boolean(
        raw.planDetails ||
        hasExplicitStructuredAdded ||
        parsedDetails?.allowance_accounts !== undefined ||
        parsedDetails?.total !== undefined ||
        parsedDetails?.master_slots_added !== undefined ||
        parsedDetails?.metadata?.master_slots_added !== undefined ||
        parsedDetails?.action_type ||
        parsedDetails?.metadata?.action_type ||
        blocks.length > 0 ||
        legacyMatch !== null
      );

      const hasStalePlanWording = Boolean(
        text &&
        (
          text.startsWith('Master expanded ') ||
          text.startsWith('Master purchased ') ||
          text.startsWith('Master activated ')
        )
      );

      if (!text || hasStructuredPlanData || hasStalePlanWording) {
        if (isMasterSlotOnly) {
          text = `purchased +${addedMasterSlots} Master Account Slot${addedMasterSlots === 1 ? '' : 's'} (${totalMasterSlots} total master slots)`;
        } else if (isCombinedAddOn) {
          text = `purchased +${addedSlaves} Slave Account Slot${addedSlaves === 1 ? '' : 's'} and +${addedMasterSlots} Master Account Slot${addedMasterSlots === 1 ? '' : 's'} (${allowance} total slave slots, ${totalMasterSlots} total master slots)`;
        } else if (isSlaveAddOnOnly) {
          text = `purchased +${addedSlaves} Slave Account Slot${addedSlaves === 1 ? '' : 's'} on Slave Capacity Add-On Plan (${allowance} total slave slots)`;
        } else {
          text = `activated ${derivedPlanName} (${allowance} Slave Account Slot${allowance === 1 ? '' : 's'}${addedMasterSlots > 0 ? `, +${addedMasterSlots} Master Account Slot${addedMasterSlots === 1 ? '' : 's'}` : ''})`;
        }
      }

      planDetails = {
        planName: derivedPlanName,
        actionType: isMasterSlotOnly ? 'add_master_slot' : (isCombinedAddOn || isSlaveAddOnOnly ? 'add_accounts' : 'new_plan'),
        ...(!isMasterSlotOnly ? { accounts: allowance } : {}),
        ...(addedSlaves > 0 && !isMasterSlotOnly ? { slaveAccountsAdded: addedSlaves } : {}),
        ...(addedMasterSlots > 0 ? { masterSlotsAdded: addedMasterSlots, masterSlotsTotal: totalMasterSlots } : {}),
        ...(txAmount !== undefined ? { amount: txAmount } : {}),
        currency: 'USD',
        ...(Array.isArray(fleetIds) && fleetIds.length > 0 ? { fleetIds } : {}),
        ...(Array.isArray(registeredEmails) && registeredEmails.length > 0 ? { registeredEmails } : {})
      };
    } else if (rawType.includes('SLAVE_UI_MESSAGING') || rawType === 'SLAVE_UI_MESSAGING_DISABLED') {
      category = 'security';
      outcome = 'failed';
      if (!text) text = `@${agentId} attempted UI messaging [BLOCKED: 403 Forbidden - Slave UI messaging disabled]`;
    } else if (rawType === 'SLAVE_TO_SLAVE_CONNECTION_BLOCKED' || rawType === 'CONNECTION_BLOCKED' || rawType.includes('BLOCKED')) {
      category = 'security';
      outcome = 'failed';
      const peer = peerAgentId || raw.target || 'peer';
      const cleanPeer = peer.replace(/^@+/, '');
      peerAgentId = cleanPeer;
      if (!text) text = `@${agentId} attempted connection with peer @${cleanPeer} [BLOCKED: 403 Forbidden - Slave-to-slave links prohibited]`;
    } else if (rawType === 'RATE_LIMIT_EXCEEDED' || rawType.includes('RATE_LIMIT')) {
      category = 'security';
      outcome = 'failed';
      if (!text) text = `@${agentId} exceeded endpoint rate limit on API`;
    } else if (rawType === 'GLOBAL_LOGOUT' || rawType === 'GLOBAL_LOGOUT_EXECUTED' || rawType === 'SESSION_REVOKED') {
      category = 'security';
      outcome = 'info';
      if (!text) text = `@${agentId} executed global security logout across fleet`;
    } else if (rawType.includes('WEBAUTHN') || rawType === 'PASSKEY_REGISTERED') {
      category = 'security';
      outcome = 'success';
      if (!text) text = `@${agentId} registered WebAuthn passkey hardware security token`;
    } else if (rawType.includes('DECRYPTION_FAILED') || rawType === 'E2EE_DECRYPTION_FAILED') {
      category = 'security';
      outcome = 'failed';
      const reason = parsedDetails?.reason || parsedDetails?.code || 'AUTHENTICATION_TAG_FAILED';
      if (!text) text = `@${agentId} failed E2EE message decryption [${reason}]`;
    } else if (rawType === 'CONNECTION_ESTABLISHED' || rawType === 'CONNECTION_ACCEPTED_BY_TARGET' || rawType === 'CONNECTION' || rawType === 'CONNECTION_CREATED' || rawType === 'CONNECTION_FORMED') {
      const peer = peerAgentId || raw.target || parsedDetails?.sender_id || parsedDetails?.peerAgentId || 'peer';
      const cleanPeer = peer.replace(/^@+/, '');
      peerAgentId = cleanPeer;

      const prof = agentProfileMap[agentId.toLowerCase()] || (raw.actorUserId ? agentProfileMap[raw.actorUserId] : undefined);
      const peerProf = cleanPeer ? (agentProfileMap[cleanPeer.toLowerCase()] || (raw.peerUserId ? agentProfileMap[raw.peerUserId] : undefined)) : undefined;

      const isActorSlave = prof?.role === 'slave' || raw.actorRole === 'slave';
      const isPeerSlave = peerProf?.role === 'slave' || raw.peerRole === 'slave';

      if (isActorSlave && isPeerSlave) {
        category = 'security';
        outcome = 'failed';
        text = `@${agentId} attempted connection with peer @${cleanPeer} [BLOCKED: 403 Forbidden - Slave-to-slave links prohibited]`;
      } else {
        category = 'connection';
        outcome = 'success';
        if (!text) text = `@${agentId} formed a connection with peer @${cleanPeer}`;
      }
    } else if (rawType === 'CONNECTION_REMOVED' || rawType === 'CONNECTION_DISSOLVED') {
      category = 'connection';
      outcome = 'info';
      const peer = peerAgentId || raw.target || parsedDetails?.sender_id || parsedDetails?.peerAgentId || 'peer';
      if (!text) text = `@${agentId} removed its connection with @${peer.replace(/^@+/, '')}`;
      peerAgentId = peer.replace(/^@+/, '');
    } else if (rawType === 'CONNECTION_REQUEST_SENT') {
      category = 'connection';
      outcome = 'pending';
      const peer = peerAgentId || raw.target || 'peer';
      if (!text) text = `@${agentId} sent a connection request to @${peer.replace(/^@+/, '')}`;
      peerAgentId = peer.replace(/^@+/, '');
    } else if (rawType === 'SLAVE_CREATED' || rawType === 'SLAVE_DEPLOYED') {
      category = 'account';
      outcome = 'success';
      if (!text) {
        if (peerAgentId && peerAgentId !== agentId) {
          text = `Master deployed slave account @${peerAgentId.replace(/^@+/, '')}`;
        } else if (raw.isMasterOnly || raw.masterId) {
          text = `Master deployed slave account @${agentId}`;
        } else {
          text = `@${agentId} registered a slave account`;
        }
      }
    } else if (rawType === 'AGENT_REGISTERED') {
      category = 'account';
      outcome = 'success';
      if (!text) text = `@${agentId} registered`;
    } else if (rawType === 'SLAVE_UNDEPLOYED' || rawType === 'SLAVE_DELETED') {
      category = 'account';
      outcome = 'info';
      const targetAccount = peerAgentId || agentId;
      if (!text) text = `Master undeployed slave account @${targetAccount.replace(/^@+/, '')}`;
    } else if (rawType.includes('SUSPENDED') || rawType.includes('FROZEN') || rawType.includes('DELETED')) {
      category = 'account';
      outcome = 'info';
      const targetAccount = peerAgentId || agentId;
      if (!text) text = `Account status updated for @${targetAccount.replace(/^@+/, '')}`;
    } else if (rawType.includes('EMAIL')) {
      category = 'account';
      outcome = 'success';
      const targetAccount = peerAgentId || agentId;
      if (!text) text = `Email settings updated for @${targetAccount.replace(/^@+/, '')}`;
    } else if (rawType.includes('PASSWORD')) {
      category = 'security';
      outcome = 'success';
      const targetAccount = peerAgentId || agentId;
      if (!text) text = `Security credentials updated for @${targetAccount.replace(/^@+/, '')}`;
    } else if (rawType === 'API_KEY_ROTATED' || rawType === 'API_KEY_ROTATION_REQUESTED') {
      category = 'security';
      outcome = 'success';
      const targetAccount = peerAgentId || agentId;
      if (!text) text = `API key rotated for @${targetAccount.replace(/^@+/, '')}`;
    } else if (rawType === 'E2EE_KEYS_UPDATED' || rawType === 'INITIALIZE_SLAVE_E2EE') {
      category = 'security';
      outcome = 'success';
      const targetAccount = peerAgentId || agentId;
      if (!text) text = `@${targetAccount.replace(/^@+/, '')} updated encryption identity`;
    } else if (rawType === 'WHITELIST_UPDATED') {
      category = 'security';
      outcome = 'success';
      const count = parsedDetails?.networksCount || (Array.isArray(parsedDetails?.whitelisted_networks) ? parsedDetails.whitelisted_networks.length : undefined);
      if (!text) text = count ? `Updated network access perimeter (${count} networks configured)` : `Updated network access perimeter`;
    } else if (rawType === 'CLUSTER_CREATED' || rawType === 'CLUSTER') {
      category = 'cluster';
      outcome = 'success';
      const cName = cluster?.name || parsedDetails?.name || 'Cluster';
      if (!text) text = `@${agentId} created cluster "${cName}"`;
    } else if (rawType === 'CLUSTER_MEMBER_ADDED' || rawType === 'CLUSTER_JOINED' || rawType === 'MEMBER_ADDED') {
      category = 'cluster';
      outcome = 'success';
      const cName = cluster?.name || parsedDetails?.name || 'Cluster';
      if (!text) {
        if (peerAgentId && peerAgentId !== agentId) {
          text = `@${agentId} added @${peerAgentId.replace(/^@+/, '')} to cluster "${cName}"`;
        } else {
          text = `@${agentId} joined cluster "${cName}"`;
        }
      }
    } else if (rawType === 'CLUSTER_MEMBER_REMOVED' || rawType === 'CLUSTER_LEFT' || rawType === 'CLUSTER_DISBANDED' || rawType === 'MEMBER_REMOVED') {
      category = 'cluster';
      outcome = 'info';
      const cName = cluster?.name || parsedDetails?.name || 'Cluster';
      if (!text) {
        if (rawType === 'CLUSTER_DISBANDED') {
          text = `@${agentId} disbanded cluster "${cName}"`;
        } else if (peerAgentId && peerAgentId !== agentId) {
          text = `@${agentId} removed @${peerAgentId.replace(/^@+/, '')} from cluster "${cName}"`;
        } else {
          text = `@${agentId} left cluster "${cName}"`;
        }
      }
    } else if (rawType.includes('CLUSTER_KEY')) {
      category = 'cluster';
      outcome = 'success';
      const cName = cluster?.name || parsedDetails?.name || 'Cluster';
      if (!text) text = `@${agentId} distributed group key for cluster "${cName}"`;
    } else if (rawType === 'CLUSTER_MESSAGE_SENT' || rawType === 'CLUSTER_MESSAGE_RECEIVED') {
      category = 'cluster';
      outcome = 'success';
      const cName = cluster?.name || parsedDetails?.name || 'Cluster';
      if (!text) text = `@${agentId} sent a message in cluster "${cName}"`;
    } else if (rawType === 'ATTACHMENT_SENT') {
      category = 'general';
      outcome = 'success';
      const peer = peerAgentId || 'peer';
      if (!text) text = `@${agentId} transmitted encrypted attachment to @${peer.replace(/^@+/, '')}`;
    } else if (rawType === 'ATTACHMENT_DELETED') {
      category = 'general';
      outcome = 'info';
      if (!text) text = `@${agentId} deleted encrypted attachment`;
    } else if (rawType === 'MESSAGE_SENT' || rawType === 'MESSAGE_RECEIVED') {
      category = 'general';
      outcome = 'success';
      const peer = peerAgentId || 'peer';
      if (!text) {
        text = rawType === 'MESSAGE_SENT'
          ? `@${agentId} transmitted encrypted message to @${peer.replace(/^@+/, '')}`
          : `@${agentId} received encrypted message from @${peer.replace(/^@+/, '')}`;
      }
    } else if (rawType.includes('WEBHOOK') || rawType.includes('INBOUND')) {
      category = 'general';
      outcome = 'info';
    } else if (rawType === 'PROFILE_UPDATED' || rawType === 'AGENT_PROFILE_UPDATED') {
      category = 'account';
      outcome = 'success';
      if (!text) {
        text = parsedDetails?.updatedName
          ? `@${agentId} updated profile name to "${parsedDetails.updatedName}"`
          : `@${agentId} updated its profile`;
      }
    } else if (rawType.includes('TOOL') || rawType.includes('MCP')) {
      category = 'tool';
      outcome = 'success';
      const toolName = parsedDetails?.toolName || parsedDetails?.toolId || 'Tool';
      if (!text) text = `@${agentId} invoked tool "${toolName}"`;
    } else if (!text) {
      if (parsedDetails && typeof parsedDetails === 'object') {
        const actionLabel = parsedDetails.action || parsedDetails.event || rawType.replace(/_/g, ' ').toLowerCase();
        text = `@${agentId} completed ${actionLabel}`;
      } else {
        text = `@${agentId} executed ${rawType.replace(/_/g, ' ').toLowerCase()}`;
      }
    }

    // Clean any lingering technical brackets, deduplication keys, or serialized JSON in text
    text = text.replace(/\s*\[key:[^\]]+\]\s*/g, '').trim();
    if (text.startsWith('{') && text.endsWith('}')) {
      text = `@${agentId} performed fleet operation (${rawType.toLowerCase()})`;
    }

    const activityKey = raw.activityKey || buildCanonicalKey(rawType, agentId, peerAgentId, createdAt, raw.id);
    const cleanDetails = (typeof parsedDetails === 'object' && parsedDetails !== null)
      ? (() => { const { _text, ...rest } = parsedDetails; return rest; })()
      : undefined;
    const sanitizedTechDetails = sanitizeStructuredDetails(cleanDetails);

    return {
      id,
      activityKey,
      entityId: raw.entityId,
      agentId,
      agentName,
      avatar,
      emailVerified,
      text,
      type: rawType,
      category,
      peerName,
      peerAgentId,
      peerAvatar,
      peerUserId,
      actorRole: raw.actorRole,
      peerRole: raw.peerRole,
      outcome,
      status: raw.status || (outcome === 'success' ? 'ACTIVE' : undefined),
      cluster,
      post: raw.post,
      planDetails,
      details: sanitizedTechDetails,
      technicalDetails: sanitizedTechDetails,
      createdAt,
      actorUserId,
      masterId: raw.masterId,
      peerMasterId: raw.peerMasterId,
      isMasterOnly: raw.isMasterOnly !== undefined
        ? Boolean(raw.isMasterOnly)
        : (rawType.includes('PLAN_ENTITLEMENT') || rawType === 'SLAVE_CAPABILITY_BATCH_ACTIVATED')
    };
  }

  /**
   * Records a new activity on Watchtower and broadcasts it via SSE to all authorized clients.
   */
  public async recordWatchtowerActivity(
    activity: Partial<WatchtowerActivityRecord> & { text: string; skipFootprintInsert?: boolean; endpoint?: string }
  ): Promise<WatchtowerActivityRecord> {
    if (!activity || typeof activity !== 'object' || (!activity.text && !activity.type)) {
      throw new Error('Watchtower activity requires valid text or operation type');
    }

    const skipFootprintInsert = Boolean(activity.skipFootprintInsert);
    const id = activity.id || (activity.activityKey ? `wt_${activity.activityKey}` : `wt_${crypto.randomUUID()}`);
    const createdAt = activity.createdAt || new Date().toISOString();

    let actorUserId = activity.actorUserId;
    let agentId = activity.agentId;
    let masterId = activity.masterId;
    let peerMasterId = activity.peerMasterId;

    // Resolve missing or placeholder actorUserId, masterId, agentName, and avatar from database
    const needsResolution = !actorUserId || !masterId || 
      !activity.agentName || activity.agentName === 'AGENT' || activity.agentName === 'Master' || activity.agentName === 'Master Account' ||
      !activity.avatar || activity.avatar === '🤖' || activity.avatar === '👾' ||
      !agentId || agentId === 'AGENT' || agentId === 'Master';

    if (needsResolution) {
      const lookupKey = actorUserId || masterId || agentId || activity.agentName;
      if (lookupKey) {
        try {
          const supabase = getSupabaseClient();
          const cleanKey = String(lookupKey).replace(/^@+/, '').trim();
          if (cleanKey) {
            let data: any = null;
            const { data: byId } = await supabase.from('users').select('*').eq('id', cleanKey).maybeSingle();
            if (byId) {
              data = byId;
            } else {
              const { data: byAgentId } = await supabase.from('users').select('*').ilike('agentId', cleanKey).maybeSingle();
              if (byAgentId) {
                data = byAgentId;
              } else {
                const { data: byPrefixed } = await supabase.from('users').select('*').ilike('agentId', `@${cleanKey}`).maybeSingle();
                data = byPrefixed;
              }
            }

            if (data) {
              if (!actorUserId) actorUserId = data.id;
              if (data.agentId && (!agentId || agentId === 'AGENT' || agentId === 'Master' || agentId.length > 30)) {
                agentId = data.agentId;
              }
              if (data.name && (!activity.agentName || activity.agentName === 'AGENT' || activity.agentName === 'Master' || activity.agentName === 'Master Account')) {
                activity.agentName = data.name;
              }
              if (data.avatar && (!activity.avatar || activity.avatar === '🤖' || activity.avatar === '👾')) {
                activity.avatar = data.avatar;
              }
              if (activity.emailVerified === undefined) {
                activity.emailVerified = Boolean(data.emailVerified);
              }
              if (!masterId) {
                masterId = (data.master_id && !data.is_master_primary) ? data.master_id : data.id;
              }
            }
          }
        } catch {}
      }
    }

    if (!peerMasterId && (activity.peerUserId || activity.peerAgentId)) {
      peerMasterId = await this.resolveMasterIdForActor(activity.peerUserId || activity.peerAgentId || '') || undefined;
    }

    if (actorUserId) {
      const resolvedMaster = await this.resolveMasterIdForActor(actorUserId);
      if (resolvedMaster) {
        masterId = resolvedMaster;
      } else if (!masterId) {
        masterId = actorUserId;
      }
    }
    if (!actorUserId && masterId) {
      actorUserId = masterId;
    }

    const record = this.formatStructuredRecord({
      ...activity,
      id,
      agentId,
      actorUserId,
      masterId,
      peerMasterId,
      createdAt
    })!;

    // 1. Persist in agent_footprints FIRST (idempotent upsert) unless caller already logged an authoritative footprint
    const targetUserId = record.actorUserId || record.masterId || actorUserId || masterId;
    if (targetUserId && !skipFootprintInsert) {
      try {
        const supabase = getSupabaseClient();
        const stableFpId = record.id.startsWith('fp_') ? record.id : `fp_${record.id}`;
        const serializedDetails = (record.details && typeof record.details === 'object' && Object.keys(record.details).length > 0)
          ? JSON.stringify({ ...record.details, _text: record.text, activityKey: record.activityKey })
          : (record.activityKey ? JSON.stringify({ activityKey: record.activityKey, _text: record.text }) : record.text);

        const minimalFpPayload: Record<string, any> = {
          id: stableFpId,
          user_id: targetUserId,
          agent_id: record.agentId || 'AGENT',
          action: record.type.toUpperCase(),
          details: serializedDetails,
          target: record.peerAgentId || record.entityId || null,
          created_at: record.createdAt,
        };

        const fpPayload: Record<string, any> = {
          ...minimalFpPayload,
          userId: targetUserId,
          agentId: record.agentId || 'AGENT',
        };

        let { error: dbErr } = await supabase.from('agent_footprints').upsert(fpPayload, { onConflict: 'id' });
        if (dbErr) {
          const errCode = String((dbErr as any).code || '');
          const errMsg = String(dbErr.message || '').toLowerCase();
          const isMissingCamelCol = errCode === '42703' || errCode === 'PGRST204' || errMsg.includes('userid') || errMsg.includes('agentid') || errMsg.includes('column');
          if (isMissingCamelCol) {
            const { error: minUpsertErr } = await supabase.from('agent_footprints').upsert(minimalFpPayload, { onConflict: 'id' });
            dbErr = minUpsertErr;
            if (dbErr) {
              const { error: minInsErr } = await supabase.from('agent_footprints').insert(minimalFpPayload);
              if (!minInsErr) dbErr = null;
            }
          } else {
            const { error: insErr } = await supabase.from('agent_footprints').insert(fpPayload);
            if (!insErr) {
              dbErr = null;
            }
          }
        }

        if (dbErr) {
          console.warn(`[WatchtowerPersistenceNotice] Persistence issue for event ${record.id}:`, dbErr?.message || dbErr);
        }
      } catch (err: any) {
        console.warn(`[WatchtowerPersistenceNotice] Exception during DB persistence for event ${record.id}:`, err?.message || err);
      }
    }

    // 2. Only after DB persistence succeeds: store in ring buffer, deduplicating if identical activityKey exists
    const existingIndex = this.recentActivities.findIndex(
      (a) => (a.activityKey && a.activityKey === record.activityKey) || a.id === record.id
    );

    if (existingIndex >= 0) {
      this.recentActivities[existingIndex] = record;
    } else {
      this.recentActivities.unshift(record);
      if (this.recentActivities.length > this.maxActivities) {
        this.recentActivities.pop();
      }
    }

    // 3. Broadcast SSE event to all connected watchtower stream clients that are authorized to view it
    const payloadWatchtower = `event: watchtower_activity\ndata: ${JSON.stringify(record)}\n\n`;

    for (const [client, viewer] of Array.from(this.sseClients.entries())) {
      try {
        if (this.isRecordAuthorizedForViewer(record, viewer)) {
          client.write(payloadWatchtower);
        }
      } catch (err) {
        this.cleanupStreamClient(client);
      }
    }

    // Notify realtime service cleanly with outbound footprint category for the acting account.
    // Inbound external events & outbound webhook dispatches are emitted solely via auditService.logExternalEvent.
    if (!skipFootprintInsert) {
      try {
        const notifyTarget = record.actorUserId || record.agentId;
        if (notifyTarget) {
          realtimeService.notifyAccount(notifyTarget, {
            id: record.id,
            type: record.type,
            category: 'footprint',
            actorId: record.peerAgentId || record.agentId,
            accountId: notifyTarget,
            targetId: record.entityId || record.peerAgentId || undefined,
            entityId: record.entityId,
            endpoint: activity.endpoint || undefined,
            details: record.text,
            timestamp: createdAt,
          });
        }
      } catch (e) {}
    }

    return record;
  }

  public async recordFloorActivity(activity: Partial<WatchtowerActivityRecord> & { text: string }): Promise<WatchtowerActivityRecord> {
    return this.recordWatchtowerActivity(activity);
  }

  /**
   * Fetches persistent historical activities for an authenticated viewer from Supabase,
   * merges with in-memory activities, deduplicates, and returns the sorted list.
   */
  public async fetchWatchtowerActivitiesForViewer(
    viewer?: WatchtowerViewerContext,
    options?: { limit?: number; before?: string }
  ): Promise<WatchtowerActivityRecord[]> {
    if (!viewer || !viewer.userId) {
      return [];
    }

    const supabase = getSupabaseClient();
    const vUserId = viewer.userId;
    const vMasterId = viewer.masterId || viewer.userId;
    const isMaster = viewer.isMaster;

    // 1. Resolve fleet user IDs and agent IDs
    const fleetUserIds = [vUserId];
    if (vMasterId && !fleetUserIds.includes(vMasterId)) {
      fleetUserIds.push(vMasterId);
    }
    const fleetAgentIds = viewer.agentId ? [viewer.agentId] : [];
    const slaveUserIds: string[] = [];
    const agentProfileMap: Record<string, { name: string; avatar?: string; agentId?: string; emailVerified?: boolean; role?: 'master' | 'slave' }> = {};

    this.agentMasterCache.set(vUserId.toLowerCase().trim(), vMasterId);
    this.agentMasterCache.set(vMasterId.toLowerCase().trim(), vMasterId);
    if (viewer.agentId) {
      this.agentMasterCache.set(viewer.agentId.replace(/^@+/, '').toLowerCase().trim(), vMasterId);
    }

    let viewerUser: any = null;

    try {
      if (isMaster) {
        let pioneerMasterId = vMasterId;
        for (let d = 0; d < 5; d++) {
          const { data: pRec } = await supabase
            .from('users')
            .select('*')
            .eq('id', pioneerMasterId)
            .maybeSingle();
          if (pRec?.master_id && pRec.master_id !== pioneerMasterId && pRec.is_master_primary !== true) {
            pioneerMasterId = pRec.master_id;
          } else {
            break;
          }
        }

        const slotIds = [vMasterId];
        if (pioneerMasterId && !slotIds.includes(pioneerMasterId)) {
          slotIds.push(pioneerMasterId);
        }
        if (vUserId && !slotIds.includes(vUserId)) {
          slotIds.push(vUserId);
        }

        // 1. Query all master slots under vMasterId, pioneerMasterId, or vUserId
        const { data: masterSlots } = await supabase
          .from('users')
          .select('*')
          .in('master_id', slotIds);

        if (masterSlots && Array.isArray(masterSlots)) {
          masterSlots.forEach((slot: any) => {
            if (slot.id && !slotIds.includes(slot.id)) {
              slotIds.push(slot.id);
            }
          });
        }

        // 2. Fetch all users whose master_id is in slotIds, or whose id is in slotIds
        const [byMasterRes, byIdRes] = await Promise.all([
          supabase.from('users').select('*').in('master_id', slotIds),
          supabase.from('users').select('*').in('id', slotIds),
        ]);

        const combinedUsers = [
          ...(byMasterRes.data || []),
          ...(byIdRes.data || [])
        ];

        // 3. Also check if there are users linked by fleet_id from master entitlements
        try {
          const { data: ents } = await supabase
            .from('master_plan_entitlements')
            .select('*')
            .in('master_account_id', slotIds);

          const fleetIds: string[] = [];
          if (Array.isArray(ents)) {
            ents.forEach((ent: any) => {
              if (ent?.fleet_id) fleetIds.push(ent.fleet_id);
              if (Array.isArray(ent?.metadata?.fleet_ids)) {
                ent.metadata.fleet_ids.forEach((f: any) => f && fleetIds.push(String(f)));
              }
            });
          }
          if (fleetIds.length > 0) {
            const { data: fleetUsers } = await supabase
              .from('users')
              .select('*')
              .in('fleet_id', fleetIds);
            if (fleetUsers && Array.isArray(fleetUsers)) {
              combinedUsers.push(...fleetUsers);
            }
          }
        } catch {}

        // Deduplicate users by id
        const uniqueFleetUsersMap = new Map<string, any>();
        for (const u of combinedUsers) {
          if (u && u.id) {
            uniqueFleetUsersMap.set(u.id, u);
          }
        }

        uniqueFleetUsersMap.forEach((s) => {
          if (s.id) {
            if (!fleetUserIds.includes(s.id)) fleetUserIds.push(s.id);
            if (s.id !== vMasterId) slaveUserIds.push(s.id);
            this.agentMasterCache.set(s.id.toLowerCase().trim(), vMasterId);
          }
          if (s.agentId) {
            if (!fleetAgentIds.includes(s.agentId)) fleetAgentIds.push(s.agentId);
            this.agentMasterCache.set(s.agentId.replace(/^@+/, '').toLowerCase().trim(), vMasterId);
          }
          const cleanId = (s.agentId || s.name || 'agent').replace(/^@+/, '');
          const fallbackAvatar = `https://robohash.org/${encodeURIComponent(cleanId.toLowerCase())}.png?size=150x150`;
          const entry = {
            name: s.name || s.agentId || 'Fleet Agent',
            avatar: (s.avatar && s.avatar !== '🤖' && s.avatar !== '👾') ? s.avatar : fallbackAvatar,
            agentId: s.agentId,
            emailVerified: Boolean(s.emailVerified),
            role: (s.account_type === 'master_slot' || s.role === 'master' || s.id === vMasterId) ? ('master' as const) : ('slave' as const)
          };
          agentProfileMap[s.id] = entry;
          if (s.agentId) {
            agentProfileMap[s.agentId.toLowerCase()] = entry;
            agentProfileMap[cleanId.toLowerCase()] = entry;
          }
          if (s.name) {
            agentProfileMap[s.name.toLowerCase()] = entry;
          }
        });
      }

      // Viewer user profile
      const { data } = await supabase
        .from('users')
        .select('id, agentId, name, avatar, emailVerified, account_type, is_master_primary, created_at')
        .eq('id', vUserId)
        .maybeSingle();
      viewerUser = data;

      if (viewerUser) {
        const cleanVId = (viewerUser.agentId || viewerUser.name || 'agent').replace(/^@+/, '');
        const entry = {
          name: viewerUser.name || viewerUser.agentId || (isMaster ? 'Master Account' : 'Operator'),
          avatar: viewerUser.avatar,
          agentId: viewerUser.agentId,
          emailVerified: Boolean(viewerUser.emailVerified),
          role: isMaster ? ('master' as const) : ('slave' as const)
        };
        agentProfileMap[viewerUser.id] = entry;
        if (viewerUser.agentId) {
          agentProfileMap[viewerUser.agentId.toLowerCase()] = entry;
          agentProfileMap[cleanVId.toLowerCase()] = entry;
        }
        if (viewerUser.name) {
          agentProfileMap[viewerUser.name.toLowerCase()] = entry;
        }
      }

      // Ensure Master user profile is mapped
      if (vMasterId && !agentProfileMap[vMasterId]) {
        const { data: masterData } = await supabase
          .from('users')
          .select('id, agentId, name, avatar, emailVerified')
          .eq('id', vMasterId)
          .maybeSingle();

        if (masterData) {
          const cleanMId = (masterData.agentId || masterData.name || 'master').replace(/^@+/, '');
          const entry = {
            name: masterData.name || masterData.agentId || 'Master Account',
            avatar: masterData.avatar,
            agentId: masterData.agentId,
            emailVerified: Boolean(masterData.emailVerified),
            role: 'master' as const
          };
          agentProfileMap[masterData.id] = entry;
          if (masterData.agentId) {
            agentProfileMap[masterData.agentId.toLowerCase()] = entry;
            agentProfileMap[cleanMId.toLowerCase()] = entry;
          }
          if (masterData.name) {
            agentProfileMap[masterData.name.toLowerCase()] = entry;
          }
        }
      }
    } catch (e) {}

    const historicalRecords: WatchtowerActivityRecord[] = [];

    let beforeTimestamp: string | undefined = undefined;
    let beforeId: string | undefined = undefined;

    if (options?.before) {
      const rawBefore = String(options.before).trim();
      if (rawBefore.includes('::')) {
        const parts = rawBefore.split('::');
        beforeTimestamp = parts[0];
        beforeId = parts[1];
      } else {
        const matchPrefix = rawBefore.match(/^(.*?)_((?:wt|fp|sf|evt|conn)_[A-Za-z0-9_-]+)$/);
        if (matchPrefix) {
          beforeTimestamp = matchPrefix[1];
          beforeId = matchPrefix[2];
        } else {
          beforeTimestamp = rawBefore;
        }
      }
    }

    const beforeTimeMs = beforeTimestamp ? new Date(beforeTimestamp).getTime() : NaN;
    const cleanBeforeId = beforeId ? stripAllPrefixes(beforeId) : '';

    // 2. Query persistent agent_footprints (Single canonical source of truth)
    try {
      let fpQuery = supabase.from('agent_footprints').select('*');
      if (isMaster) {
        if (fleetUserIds.length === 1) {
          fpQuery = fpQuery.eq('user_id', fleetUserIds[0]);
        } else {
          fpQuery = fpQuery.in('user_id', fleetUserIds);
        }
      } else {
        fpQuery = fpQuery.eq('user_id', vUserId);
      }

      if (beforeTimestamp) {
        fpQuery = fpQuery.lte('created_at', beforeTimestamp);
      }

      const limit = options?.limit || 100;
      const { data: footprints, error: fpErr } = await fpQuery
        .order('created_at', { ascending: false })
        .order('id', { ascending: false })
        .limit(limit * 2);

      if (fpErr) {
        console.error('[WatchtowerDBError] Failed to fetch agent_footprints for viewer:', {
          viewerUserId: vUserId,
          viewerMasterId: vMasterId,
          error: fpErr
        });
        throw new Error(`Watchtower database query failed on agent_footprints: ${fpErr.message || JSON.stringify(fpErr)}`);
      }

      if (footprints && Array.isArray(footprints)) {
        for (const fp of footprints) {
          if (!fp || !fp.id) continue;
          const formatted = this.formatStructuredRecord(
            {
              ...fp,
              masterId: vMasterId,
              actorUserId: fp.user_id || fp.userId,
              peerAgentId: fp.target,
              type: fp.action
            },
            agentProfileMap,
            'footprint'
          );
          if (formatted) {
            historicalRecords.push(formatted);
          }
        }
      }
    } catch (e: any) {
      console.error('[WatchtowerDBError] Exception querying agent_footprints:', e);
      throw e;
    }

    // 3. Query persistent external_events (for plan/capability audit records, excluding redundant messages/connections)
    try {
      let evtQuery = supabase.from('external_events').select('*');
      if (isMaster) {
        if (fleetUserIds.length === 1) {
          evtQuery = evtQuery.eq('user_id', fleetUserIds[0]);
        } else {
          evtQuery = evtQuery.in('user_id', fleetUserIds);
        }
      } else {
        evtQuery = evtQuery.eq('user_id', vUserId);
      }

      if (beforeTimestamp) {
        evtQuery = evtQuery.lte('created_at', beforeTimestamp);
      }

      const extLimit = Math.max(200, (options?.limit || 100) * 3);
      const { data: extEvents, error: evtErr } = await evtQuery
        .order('created_at', { ascending: false })
        .order('id', { ascending: false })
        .limit(extLimit);

      if (evtErr) {
        console.warn('[WatchtowerDBWarning] Failed to fetch external_events for viewer:', {
          viewerUserId: vUserId,
          viewerMasterId: vMasterId,
          error: evtErr
        });
      }

      if (!evtErr && extEvents && Array.isArray(extEvents)) {
        for (const ev of extEvents) {
          const rawType = (ev.type || ev.event_type || ev.action || '').toUpperCase();
          // Exclude redundant message & connection events from external_events to prevent duplicate counting
          if (rawType.includes('MESSAGE') || rawType.includes('CONNECTION') || rawType.includes('STREAM_CONNECTED')) {
            continue;
          }

          // Skip per-slave child rows when they belong to a capability batch (the batch row is the single canonical entry)
          if (rawType === 'SLAVE_CAPABILITY_ACTIVATED') {
            let evDetails: any = ev.details;
            if (typeof evDetails === 'string') {
              try { evDetails = JSON.parse(evDetails); } catch {}
            }
            if (evDetails && typeof evDetails === 'object' && evDetails.batch_id) {
              continue;
            }
          }

          const uId = ev.user_id || ev.userId;
          const formatted = this.formatStructuredRecord(
            {
              ...ev,
              masterId: vMasterId,
              actorUserId: uId,
              peerAgentId: ev.sender_id || ev.senderId,
              type: rawType
            },
            agentProfileMap,
            'external_event'
          );
          if (formatted) {
            historicalRecords.push(formatted);
          }
        }
      }
    } catch (e: any) {
      console.warn('[WatchtowerDBWarning] Exception querying external_events:', e);
    }

    // 4. Merge in-memory recent activities with historical records
    let inMemoryFiltered = this.recentActivities.filter((a) => this.isRecordAuthorizedForViewer(a, viewer));

    // Combine and deduplicate
    let combined = [...inMemoryFiltered, ...historicalRecords];

    if (!isNaN(beforeTimeMs)) {
      combined = combined.filter((a) => {
        const aTime = new Date(a.createdAt || 0).getTime();
        if (aTime < beforeTimeMs) return true;
        if (aTime === beforeTimeMs && cleanBeforeId) {
          return stripAllPrefixes(a.id) < cleanBeforeId;
        }
        return false;
      });
    }

    combined.sort((a, b) => {
      const timeA = new Date(a.createdAt || 0).getTime();
      const timeB = new Date(b.createdAt || 0).getTime();
      if (timeA !== timeB) return timeB - timeA;

      const typeA = (a.type || '').toUpperCase();
      const typeB = (b.type || '').toUpperCase();
      const isSentA = typeA.includes('SENT') || typeA.includes('DEPLOYED') || typeA.includes('CREATED');
      const isSentB = typeB.includes('SENT') || typeB.includes('DEPLOYED') || typeB.includes('CREATED');
      if (isSentA && !isSentB) return -1;
      if (!isSentA && isSentB) return 1;

      const detailsA = (a.planDetails || (a.details && typeof a.details === 'object' && Object.keys(a.details).length > 0)) ? 1 : 0;
      const detailsB = (b.planDetails || (b.details && typeof b.details === 'object' && Object.keys(b.details).length > 0)) ? 1 : 0;
      if (detailsA !== detailsB) return detailsB - detailsA;

      return (b.id || '').localeCompare(a.id || '');
    });

    // Build batch coverage windows to suppress legacy standalone SLAVE_CAPABILITY_ACTIVATED child duplicates
    const batchCoverage = combined
      .filter((item) => item && item.type === 'SLAVE_CAPABILITY_BATCH_ACTIVATED')
      .map((b) => {
        const ts = new Date(b.createdAt || 0).getTime();
        const targets = new Set<string>(
          (b.planDetails?.targetAccountIds || b.details?.target_account_ids || [])
            .map((t: any) => String(t || '').replace(/^@+/, '').toLowerCase().trim())
            .filter(Boolean)
        );
        return { ts, targets };
      });

    const seenKeys = new Set<string>();
    const seenIds = new Set<string>();
    const seenPlanTxIds = new Set<string>();
    const seenPlanSignatures: Array<{ signature: string; ts: number; txId: string }> = [];
    const deduplicated: WatchtowerActivityRecord[] = [];

    for (const item of combined) {
      if (!item || !item.text) continue;

      if (item.type === 'SLAVE_CAPABILITY_ACTIVATED') {
        if (item.details?.batch_id) continue;
        const itemTs = new Date(item.createdAt || 0).getTime();
        const targetCand = String(item.peerAgentId || item.details?.agent_id || item.actorUserId || '').replace(/^@+/, '').toLowerCase().trim();
        const covered = batchCoverage.some((bc) => {
          if (Math.abs(bc.ts - itemTs) > 30_000) return false;
          return !targetCand || bc.targets.size === 0 || bc.targets.has(targetCand);
        });
        if (covered) continue;
      }

      const cleanId = item.id ? stripAllPrefixes(item.id) : '';
      const canonicalKey = buildCanonicalKey(item.type, item.agentId, item.peerAgentId, item.createdAt, item.id);
      const customKey = item.activityKey ? item.activityKey.toLowerCase() : '';

      const explicitPlanTxId = String(
        item.details?.batch_id ||
        item.details?.tx_id ||
        item.details?.latest_transaction_id ||
        item.details?.metadata?.latest_transaction_id ||
        ''
      ).toLowerCase().trim();

      if (cleanId && cleanId.length >= 6 && seenIds.has(cleanId)) {
        continue;
      }
      if (explicitPlanTxId && seenPlanTxIds.has(explicitPlanTxId)) {
        continue;
      }
      if (customKey && seenKeys.has(customKey)) {
        continue;
      }
      if (canonicalKey && seenKeys.has(canonicalKey)) {
        continue;
      }

      let planSignatureKey = '';
      let itemTs = new Date(item.createdAt || 0).getTime();
      if (item.category === 'plan') {
        const actorNorm = (item.agentId || '').replace(/^@+/, '').toLowerCase().trim();
        const pd = item.planDetails || {};
        const groupType = String(item.type || '').includes('CAPABILITY') ? 'cap' : 'entitlement';
        planSignatureKey = [
          actorNorm,
          groupType,
          pd.actionType || '',
          pd.accounts ?? '',
          pd.slaveAccountsAdded ?? 0,
          pd.masterSlotsAdded ?? 0,
          pd.masterSlotsTotal ?? '',
          pd.validityDays ?? ''
        ].join('|');

        const isLegacyDuplicatePlan = seenPlanSignatures.some((prev) => {
          if (prev.signature !== planSignatureKey) return false;
          if (Math.abs(prev.ts - itemTs) > 15_000) return false;
          // If both rows have distinct explicit transaction IDs, they are separate purchases
          if (explicitPlanTxId && prev.txId && explicitPlanTxId !== prev.txId) return false;
          return true;
        });
        if (isLegacyDuplicatePlan) {
          continue;
        }
      }

      if (cleanId && cleanId.length >= 6) {
        seenIds.add(cleanId);
      }
      if (explicitPlanTxId) {
        seenPlanTxIds.add(explicitPlanTxId);
      }
      if (planSignatureKey) {
        seenPlanSignatures.push({ signature: planSignatureKey, ts: itemTs, txId: explicitPlanTxId });
      }
      if (customKey) {
        seenKeys.add(customKey);
      }
      if (canonicalKey) {
        seenKeys.add(canonicalKey);
      }

      if (this.isRecordAuthorizedForViewer(item, viewer)) {
        deduplicated.push(item);
      }
    }

    // Sort chronologically descending with secondary id key
    deduplicated.sort((a, b) => {
      const timeA = new Date(a.createdAt || 0).getTime();
      const timeB = new Date(b.createdAt || 0).getTime();
      if (timeA !== timeB) return timeB - timeA;
      return (b.id || '').localeCompare(a.id || '');
    });

    // Update recent ring buffer with newly formatted unique records
    for (const d of deduplicated.slice(0, this.maxActivities)) {
      const idx = this.recentActivities.findIndex(
        (a) => (a.activityKey && a.activityKey === d.activityKey) || a.id === d.id
      );
      if (idx === -1) {
        this.recentActivities.push(d);
      }
    }
    this.recentActivities.sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
    if (this.recentActivities.length > this.maxActivities) {
      this.recentActivities.splice(this.maxActivities);
    }

    const finalLimit = options?.limit || 100;
    return deduplicated.slice(0, finalLimit);
  }

  /**
   * Returns a scoped copy of recent watchtower activities for an authenticated viewer.
   */
  public getRecentWatchtowerActivity(viewer?: WatchtowerViewerContext): WatchtowerActivityRecord[] {
    if (!viewer || !viewer.userId) {
      return [];
    }
    return this.recentActivities.filter((a) => this.isRecordAuthorizedForViewer(a, viewer));
  }

  public getRecentFloorActivity(viewer?: WatchtowerViewerContext): WatchtowerActivityRecord[] {
    return this.getRecentWatchtowerActivity(viewer);
  }

  private cleanupStreamClient(res: Response): void {
    const ping = this.ssePingIntervals.get(res);
    if (ping) {
      clearInterval(ping);
      this.ssePingIntervals.delete(res);
    }
    this.sseClients.delete(res);
  }

  /**
   * Registers an authenticated client for Server-Sent Events (SSE).
   */
  public registerWatchtowerStreamClient(res: Response, viewer: WatchtowerViewerContext): void {
    this.sseClients.set(res, viewer);

    try {
      const authorizedRecent = this.getRecentWatchtowerActivity(viewer).slice(0, 50);
      const handshake = `event: handshake\ndata: ${JSON.stringify({
        status: 'CONNECTED',
        recent: authorizedRecent,
      })}\n\n`;
      res.write(handshake);
    } catch (err) {
      this.cleanupStreamClient(res);
      return;
    }

    // Heartbeat every 15s to keep persistent Render/Cloudflare SSE connections alive
    const pingInterval = setInterval(() => {
      try {
        res.write(':ping\n\n');
      } catch {
        this.cleanupStreamClient(res);
      }
    }, 15000);
    if (typeof (pingInterval as any).unref === 'function') {
      (pingInterval as any).unref();
    }
    this.ssePingIntervals.set(res, pingInterval);

    res.on('close', () => {
      this.cleanupStreamClient(res);
    });

    res.on('error', () => {
      this.cleanupStreamClient(res);
    });
  }

  public registerFloorStreamClient(res: Response, viewer?: WatchtowerViewerContext): void {
    if (viewer) {
      return this.registerWatchtowerStreamClient(res, viewer);
    }
  }

  /**
   * Terminates any active SSE streams for a specific user ID upon session revocation or logout.
   */
  public invalidateStreamsForUser(userId: string): void {
    if (!userId) return;
    const clean = userId.toLowerCase().trim();
    for (const [client, viewer] of Array.from(this.sseClients.entries())) {
      if (viewer.userId.toLowerCase().trim() === clean || (viewer.masterId && viewer.masterId.toLowerCase().trim() === clean)) {
        try {
          client.write(`event: stream_revoked\ndata: {"status":"REVOKED","message":"Session revoked"}\n\n`);
          client.end();
        } catch {}
        this.cleanupStreamClient(client);
      }
    }
  }

  /**
   * Resolves agent metadata (name, avatar, emailVerified) by agentId or userId.
   */
  public async resolveAgentMeta(identifier: string): Promise<{ name?: string; avatar?: string; emailVerified?: boolean } | null> {
    if (!identifier) return null;
    try {
      const supabase = getSupabaseClient();
      const cleanId = identifier.trim().replace(/^@/, '');
      let data: any = null;
      const { data: byId } = await supabase.from('users').select('*').eq('id', cleanId).maybeSingle();
      if (byId) {
        data = byId;
      } else {
        const { data: byAgentId } = await supabase.from('users').select('*').ilike('agentId', cleanId).maybeSingle();
        if (byAgentId) {
          data = byAgentId;
        } else {
          const { data: byPrefixed } = await supabase.from('users').select('*').ilike('agentId', `@${cleanId}`).maybeSingle();
          data = byPrefixed;
        }
      }

      if (data) {
        return {
          name: data.name,
          avatar: data.avatar,
          emailVerified: Boolean(data.emailVerified),
        };
      }
    } catch (e) {}
    return null;
  }

  private streamTickets: Map<string, { viewer: WatchtowerViewerContext; expiresAt: number }> = new Map();

  public createStreamTicket(viewer: WatchtowerViewerContext): string {
    const ticket = crypto.randomUUID();
    const expiresAt = Date.now() + 60 * 1000; // 60s TTL
    this.streamTickets.set(ticket, { viewer, expiresAt });
    return ticket;
  }

  public redeemStreamTicket(ticket: string): WatchtowerViewerContext | null {
    if (!ticket || typeof ticket !== 'string') return null;
    const clean = ticket.trim();
    const entry = this.streamTickets.get(clean);
    if (!entry) return null;
    this.streamTickets.delete(clean);
    if (Date.now() > entry.expiresAt) return null;
    return entry.viewer;
  }
}

export const watchtowerActivityService = new WatchtowerActivityService();
export const floorActivityService = watchtowerActivityService;
export { WatchtowerActivityService as FloorActivityService };
