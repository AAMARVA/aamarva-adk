import crypto from 'crypto';
import { getSupabaseClient, isSupabaseConfigured } from '../supabase.js';
import { registerExternalAuthCacheInvalidator } from '../authService.js';

export interface MasterAccountRecord {
  id: string;
  plan_status: 'ACTIVE' | 'INACTIVE' | 'EXPIRED';
  plan_expires_at?: string;
  tier?: string;
  max_sub_agents: number;
}

export interface MasterPlanEntitlement {
  id: string;
  master_account_id: string;
  plan_type: string;
  plan_name: string;
  status: 'active' | 'inactive' | 'expired' | 'canceled';
  allowance_accounts: number;
  tier: string;
  created_at: string;
  updated_at: string;
  expires_at?: string | null;
  metadata?: Record<string, any>;
}

export interface UserAccountMetadata {
  id: string;
  master_id?: string;
  is_master_primary?: boolean;
  apiKeyHash?: string;
}

export class MasterAccountService {
  private static instance: MasterAccountService;
  private metadataCache = new Map<string, UserAccountMetadata>();
  private fingerprintCache = new Map<string, UserAccountMetadata>();
  private masterAccountCache = new Map<string, MasterAccountRecord>();
  private masterPlanCache = new Map<string, MasterPlanEntitlement>();
  
  private masterPlanCacheTimestamps = new Map<string, number>();
  private rootMasterCache = new Map<string, { rootId: string; ts: number }>();
  private inFlightRootMaster = new Map<string, Promise<string>>();
  private inFlightMasterPlan = new Map<string, Promise<MasterPlanEntitlement | null>>();
  private readonly CACHE_TTL_MS = 60_000;
  
  // Mutex lock map to serialize concurrent purchase/activation requests per master account
  private locks = new Map<string, Promise<void>>();
  // Active in-flight slot reservations to prevent race conditions during concurrent slave creation
  private inFlightReservations = new Map<string, number>();

  public static getInstance(): MasterAccountService {
    if (!MasterAccountService.instance) {
      const instance = new MasterAccountService();
      MasterAccountService.instance = instance;
      registerExternalAuthCacheInvalidator((userId?: string) => {
        if (!userId) {
          instance.metadataCache.clear();
          instance.fingerprintCache.clear();
          instance.rootMasterCache.clear();
          instance.inFlightRootMaster.clear();
          instance.inFlightMasterPlan.clear();
        } else {
          instance.metadataCache.delete(userId);
          instance.rootMasterCache.delete(userId);
          instance.inFlightRootMaster.delete(userId);
          instance.inFlightMasterPlan.delete(userId);
        }
      });
    }
    return MasterAccountService.instance;
  }

  /**
   * Concurrency helper: acquires a per-master lock to serialize activations
   */
  private async acquireLock(masterId: string): Promise<() => void> {
    while (this.locks.has(masterId)) {
      await this.locks.get(masterId);
    }
    let resolveLock!: () => void;
    const lockPromise = new Promise<void>((resolve) => {
      resolveLock = resolve;
    });
    this.locks.set(masterId, lockPromise);

    return () => {
      this.locks.delete(masterId);
      resolveLock();
    };
  }

  /**
   * Walks up master_id (max 5 hops) to resolve the pioneer Master Account ID for add-on master slots.
   */
  public async resolveRootMasterId(sb: any, accountId: string): Promise<string> {
    if (!accountId) return accountId;
    const now = Date.now();
    const cached = this.rootMasterCache.get(accountId);
    if (cached && (now - cached.ts) < this.CACHE_TTL_MS) {
      return cached.rootId;
    }

    const inFlight = this.inFlightRootMaster.get(accountId);
    if (inFlight) {
      return inFlight;
    }

    const lookupPromise = (async () => {
      let currId = accountId;
      for (let depth = 0; depth < 5; depth++) {
        const hopCached = this.rootMasterCache.get(currId);
        if (hopCached && (Date.now() - hopCached.ts) < this.CACHE_TTL_MS) {
          currId = hopCached.rootId;
          break;
        }
        const { data: uRec } = await sb
          .from('users')
          .select('id, master_id, is_master_primary')
          .eq('id', currId)
          .maybeSingle();
        if (uRec?.master_id && uRec.master_id !== currId && uRec.is_master_primary !== true) {
          currId = uRec.master_id;
        } else {
          break;
        }
      }
      if (this.rootMasterCache.size > 2000) this.rootMasterCache.clear();
      this.rootMasterCache.set(accountId, { rootId: currId, ts: Date.now() });
      return currId;
    })().finally(() => {
      this.inFlightRootMaster.delete(accountId);
    });

    this.inFlightRootMaster.set(accountId, lookupPromise);
    return lookupPromise;
  }

  /**
   * Retrieves authoritative active plan entitlement for a given master account from database.
   * Authoritative: Never manufactures fallback entitlements for inactive/free accounts.
   * If a plan has reached its expires_at, it is treated as expired and returns null for active capacity.
   */
  public async getMasterPlan(masterId: string, bypassCache = false): Promise<MasterPlanEntitlement | null> {
    if (!masterId) return null;

    if (!bypassCache) {
      const directCached = this.masterPlanCache.get(masterId);
      const directCachedAt = this.masterPlanCacheTimestamps.get(masterId) || 0;
      if (directCached && (Date.now() - directCachedAt) < this.CACHE_TTL_MS) {
        if (directCached.status === 'active' && directCached.expires_at && new Date(directCached.expires_at).getTime() <= Date.now()) {
          directCached.status = 'expired';
          this.invalidateMasterPlanCache(masterId);
          return null;
        }
        return directCached.status === 'active' ? directCached : null;
      }

      const existingFlight = this.inFlightMasterPlan.get(masterId);
      if (existingFlight) {
        return existingFlight;
      }
    }

    const fetchPromise = (async (): Promise<MasterPlanEntitlement | null> => {
      const sb = getSupabaseClient();
      let targetMasterId = masterId;
      try {
        targetMasterId = await this.resolveRootMasterId(sb, masterId);
      } catch {}

      if (!bypassCache && targetMasterId !== masterId) {
        const cached = this.masterPlanCache.get(targetMasterId);
        const cachedAt = this.masterPlanCacheTimestamps.get(targetMasterId) || 0;
        if (cached && (Date.now() - cachedAt) < this.CACHE_TTL_MS) {
          if (cached.status === 'active' && cached.expires_at && new Date(cached.expires_at).getTime() <= Date.now()) {
            cached.status = 'expired';
            this.invalidateMasterPlanCache(targetMasterId);
            this.invalidateMasterPlanCache(masterId);
            return null;
          }
          if (cached.status === 'active') {
            this.setMasterPlanCache(masterId, cached);
            return cached;
          }
          return null;
        }
      }

      try {
        // Primary storage: master_plan_entitlements table (plan_type = 'master_slave_scale')
        const { data: entRecords } = await sb
          .from('master_plan_entitlements')
          .select('*')
          .eq('master_account_id', targetMasterId)
          .eq('plan_type', 'master_slave_scale')
          .order('updated_at', { ascending: false });

        let entRecord = (entRecords && entRecords.length > 0) ? entRecords[0] : null;

        if (!entRecord && targetMasterId !== masterId) {
          const { data: directRecords } = await sb
            .from('master_plan_entitlements')
            .select('*')
            .eq('master_account_id', masterId)
            .eq('plan_type', 'master_slave_scale')
            .order('updated_at', { ascending: false });
          if (directRecords && directRecords.length > 0) {
            entRecord = directRecords[0];
            targetMasterId = masterId;
          }
        }

        // Legacy/test rows fallback where plan_type was omitted/null (never 'slave_capability')
        if (!entRecord) {
          const { data: allEnts } = await sb
            .from('master_plan_entitlements')
            .select('*')
            .eq('master_account_id', targetMasterId)
            .order('updated_at', { ascending: false });
          const legacyRow = (allEnts || []).find((r: any) => !r.plan_type || r.plan_type === 'master_slave_scale');
          if (legacyRow) {
            entRecord = legacyRow;
          }
        }

        if (!entRecord) {
          this.invalidateMasterPlanCache(targetMasterId);
          this.invalidateMasterPlanCache(masterId);
          return null;
        }

        if (entRecord.status !== 'active') {
          this.invalidateMasterPlanCache(targetMasterId);
          this.invalidateMasterPlanCache(masterId);
          return null;
        }

        if (entRecord.expires_at && new Date(entRecord.expires_at).getTime() <= Date.now()) {
          try {
            await sb
              .from('master_plan_entitlements')
              .update({ status: 'expired', updated_at: new Date().toISOString() })
              .eq('id', entRecord.id);
          } catch {}
          this.invalidateMasterPlanCache(targetMasterId);
          this.invalidateMasterPlanCache(masterId);
          return null;
        }

        const metadata = entRecord.metadata || {};
        const entitlement: MasterPlanEntitlement = {
          id: entRecord.id,
          master_account_id: entRecord.master_account_id,
          plan_type: entRecord.plan_type || 'master_slave_scale',
          plan_name: entRecord.plan_name || 'Master & Slave Agent Plan',
          status: 'active',
          allowance_accounts: typeof entRecord.allowance_accounts === 'number' ? entRecord.allowance_accounts : 0,
          tier: entRecord.tier || 'scale',
          created_at: entRecord.created_at || new Date().toISOString(),
          updated_at: entRecord.updated_at || new Date().toISOString(),
          expires_at: entRecord.expires_at || '9999-12-31T23:59:59.999Z',
          metadata: metadata
        };
        this.setMasterPlanCache(targetMasterId, entitlement);
        if (masterId !== targetMasterId) {
          this.setMasterPlanCache(masterId, entitlement);
        }
        return entitlement;
      } catch (err: any) {
        console.warn(`[MasterAccountService] Warning resolving master plan for ${masterId}:`, err?.message || err);
        return null;
      }
    })();

    if (!bypassCache) {
      this.inFlightMasterPlan.set(masterId, fetchPromise);
      fetchPromise.finally(() => {
        if (this.inFlightMasterPlan.get(masterId) === fetchPromise) {
          this.inFlightMasterPlan.delete(masterId);
        }
      });
    }

    return fetchPromise;
  }

  /**
   * Invalidates cached Master plan and account records for a specific master.
   * Does not alter unrelated accounts.
   */
  public invalidateMasterPlanCache(masterId: string): void {
    if (!masterId) return;
    this.masterPlanCache.delete(masterId);
    this.masterPlanCacheTimestamps.delete(masterId);
    this.masterAccountCache.delete(masterId);
    this.rootMasterCache.delete(masterId);
    this.inFlightMasterPlan.delete(masterId);
  }

  public setMasterPlanCache(masterId: string, entitlement: MasterPlanEntitlement): void {
    if (!masterId || !entitlement) return;
    this.masterPlanCache.set(masterId, entitlement);
    this.masterPlanCacheTimestamps.set(masterId, Date.now());
    this.masterAccountCache.set(masterId, {
      id: masterId,
      plan_status: entitlement.status === 'active' ? 'ACTIVE' : 'INACTIVE',
      tier: entitlement.tier || 'scale',
      max_sub_agents: entitlement.allowance_accounts || 0
    });
  }

  /**
   * Atomically verifies and allocates Slave account slots for a Master Account.
   * Prevents race conditions using DB RPC (FOR UPDATE) or per-master mutex lock.
   */
  public async allocateSlaveSlotsAtomic(
    masterId: string, 
    requestedSlots: number = 1
  ): Promise<{ success: boolean; allowance: number; current: number; remaining: number; release?: () => void }> {
    if (!masterId) {
      throw new Error('Master Account ID is required for slave allocation.');
    }
    if (requestedSlots < 1) {
      throw new Error('Requested slave slots must be at least 1.');
    }

    const sb = getSupabaseClient();
    const targetMasterId = await this.resolveRootMasterId(sb, masterId);

    // 1. Concurrency-safe in-memory mutex to serialize slot checks & in-flight reservations
    const releaseLock = await this.acquireLock(targetMasterId);
    try {
      // 2. Authoritative check: Get active Master Plan
      const plan = await this.getMasterPlan(targetMasterId, true);
      if (!plan || plan.status !== 'active' || (plan.allowance_accounts || 0) <= 0) {
        throw new Error('No active Master/Slave plan found (or plan expired). Available slave slots: 0.');
      }

      // 3. When live Supabase is configured, also enforce atomic DB row lock via RPC
      if (isSupabaseConfigured()) {
        try {
          const { data: rpcData, error: rpcErr } = await sb.rpc('allocate_slave_slot_atomic', {
            p_master_id: targetMasterId,
            p_requested_slots: requestedSlots
          });
          if (!rpcErr && rpcData) {
            if (!rpcData.success) {
              if (rpcData.code === 'NO_ACTIVE_PLAN' || rpcData.code === 'PLAN_EXPIRED') {
                throw new Error(rpcData.error || 'No active Master/Slave plan found (or plan expired).');
              }
              throw new Error(rpcData.error || `Slave agent allowance limit exceeded.`);
            }
            const inFlight = this.inFlightReservations.get(targetMasterId) || 0;
            if (rpcData.current + inFlight + requestedSlots > rpcData.allowance) {
              throw new Error(`Slave agent allowance limit exceeded. Your Master plan allows a maximum of ${rpcData.allowance} accounts (${rpcData.current + inFlight} deployed/reserved, ${requestedSlots} requested).`);
            }
            this.inFlightReservations.set(targetMasterId, inFlight + requestedSlots);
            return {
              success: true,
              allowance: rpcData.allowance,
              current: rpcData.current,
              remaining: Math.max(0, rpcData.allowance - (rpcData.current + inFlight + requestedSlots)),
              release: () => {
                const cur = this.inFlightReservations.get(targetMasterId) || 0;
                this.inFlightReservations.set(targetMasterId, Math.max(0, cur - requestedSlots));
              }
            };
          }
          // Only fall back to local query if RPC function doesn't exist in DB
          if (rpcErr && !String(rpcErr.message || '').toLowerCase().includes('does not exist') && !String(rpcErr.code || '').includes('42883')) {
            console.warn('[MasterAccountService] allocate_slave_slot_atomic RPC warning:', rpcErr.message);
          }
        } catch (rpcException: any) {
          if (rpcException?.message?.includes('allowance limit exceeded') || rpcException?.message?.includes('No active Master/Slave plan') || rpcException?.message?.includes('expired')) {
            throw rpcException;
          }
        }
      }

      const effectiveAllowance = plan.allowance_accounts;

      // 4. Count currently deployed slave accounts under primary master and actual add-on master slots (excluding master slots & deleted users)
      const { data: rawChildren } = await sb
        .from('users')
        .select('id, account_type, role, is_slave, is_master_slot, is_master_primary, status')
        .eq('master_id', targetMasterId);

      const subMasterIds = (rawChildren || [])
        .filter((s: any) => {
          const isSlaveFlag = s.account_type === 'slave' || s.role === 'slave' || s.is_slave === true;
          return !isSlaveFlag && (s.is_master_slot === true || s.account_type === 'master_slot' || s.role === 'master');
        })
        .map((s: any) => s.id)
        .filter(Boolean);

      const allMasterIds = Array.from(new Set([targetMasterId, ...subMasterIds]));
      const { data: subAgents } = await sb
        .from('users')
        .select('id, account_type, role, is_slave, is_master_slot, is_master_primary, status')
        .in('master_id', allMasterIds);

      const currentCount = (subAgents && Array.isArray(subAgents))
        ? subAgents.filter((u: any) => {
            if (allMasterIds.includes(u.id)) return false;
            if (u.is_master_slot === true || u.account_type === 'master_slot' || u.is_master_primary === true) return false;
            if (u.status === 'deleted') return false;
            return true;
          }).length
        : 0;

      const inFlight = this.inFlightReservations.get(targetMasterId) || 0;
      const effectiveCount = currentCount + inFlight;

      if (effectiveCount + requestedSlots > effectiveAllowance) {
        throw new Error(`Slave agent allowance limit exceeded. Your Master plan allows a maximum of ${effectiveAllowance} accounts (${effectiveCount} deployed/reserved, ${requestedSlots} requested).`);
      }

      this.inFlightReservations.set(targetMasterId, inFlight + requestedSlots);

      return {
        success: true,
        allowance: effectiveAllowance,
        current: currentCount,
        remaining: Math.max(0, effectiveAllowance - effectiveCount - requestedSlots),
        release: () => {
          const cur = this.inFlightReservations.get(targetMasterId) || 0;
          this.inFlightReservations.set(targetMasterId, Math.max(0, cur - requestedSlots));
        }
      };
    } finally {
      releaseLock();
    }
  }


  /**
   * Releases in-flight slot reservation for a master account.
   */
  public releaseInFlightSlots(masterId: string, count: number = 1): void {
    if (!masterId || count <= 0) return;
    const cur = this.inFlightReservations.get(masterId) || 0;
    this.inFlightReservations.set(masterId, Math.max(0, cur - count));
  }

  /**
   * Safely and idempotently activates or updates a Master Account's plan entitlement.
   * Atomic operation with concurrency mutex protection.
   */
  public async activateMasterPlan(
    masterId: string, 
    requestedAllowance: number = 10,
    options?: {
      actionType?: 'new_plan' | 'add_accounts';
      addOnAccounts?: number;
      masterSlots?: number;
      masterRegistrationEmail?: string;
      masterRegistrationEmails?: string[];
      validityDays?: number;
      extendAccountsCount?: number;
      capabilityIncrement?: boolean;
    }
  ): Promise<MasterPlanEntitlement> {
    if (!masterId) {
      throw new Error('Master Account ID is required for plan activation.');
    }

    // Acquire mutex lock to serialize concurrent requests for this masterId
    const releaseLock = await this.acquireLock(masterId);

    try {
      const sb = getSupabaseClient();

      // 1. Authoritative Validation: verify Master Account exists and is active in database
      const { data: masterUser, error: masterErr } = await sb
        .from('users')
        .select('id, email, status, plan')
        .eq('id', masterId)
        .maybeSingle();

      if (masterErr || !masterUser) {
        throw new Error('Master user not found in authoritative database.');
      }

      if (masterUser.status !== 'active') {
        throw new Error(`Master user is ${masterUser.status}. Plan activation refused.`);
      }

      // 2. Fetch existing plan
      const existingPlan = await this.getMasterPlan(masterId, true);
      const isCurrentlyActive = existingPlan && existingPlan.status === 'active';
      const currentAllowance = existingPlan?.allowance_accounts || 0;
      const masterSlotsAdded = Math.max(0, Math.floor(options?.masterSlots || 0));
      const existingBlocksForSlots = Array.isArray(existingPlan?.metadata?.blocks) ? existingPlan.metadata.blocks : [];
      const blocksMasterSlotsSum = existingBlocksForSlots.reduce(
        (sum: number, b: any) => sum + Math.max(0, Number(b?.master_slots_added || 0)),
        0
      );
      const currentMasterSlots = typeof existingPlan?.metadata?.master_slots === 'number'
        ? existingPlan.metadata.master_slots
        : (1 + blocksMasterSlotsSum);
      const totalMasterSlots = currentMasterSlots + masterSlotsAdded;

      // Idempotency: If already active with requested allowance and no explicit actionType, return existing plan
      if (!options?.actionType && masterSlotsAdded === 0 && isCurrentlyActive && currentAllowance === Math.max(10, Math.min(1000, requestedAllowance))) {
        return existingPlan;
      }

      // 3. Compute final allowance & accounts bought in this transaction
      const actionType = options?.actionType || (isCurrentlyActive ? 'add_accounts' : 'new_plan');
      let accountsBoughtThisTransaction = 0;
      let sanitizedAllowance = currentAllowance;

      if (actionType === 'add_accounts') {
        accountsBoughtThisTransaction = options?.addOnAccounts !== undefined
          ? Math.max(0, Math.floor(options.addOnAccounts))
          : Math.max(0, Math.floor(requestedAllowance > currentAllowance ? requestedAllowance - currentAllowance : requestedAllowance));
        if (accountsBoughtThisTransaction <= 0 && masterSlotsAdded <= 0) {
          throw new Error('Must specify at least 1 slave account or 1 master slot to purchase.');
        }
        sanitizedAllowance = Math.min(1000, currentAllowance + accountsBoughtThisTransaction);
      } else {
        // Direct allowance specification or 'new_plan' (clamped between 10 and 1000)
        accountsBoughtThisTransaction = Math.min(1000, Math.max(10, Math.floor(requestedAllowance)));
        sanitizedAllowance = accountsBoughtThisTransaction;
      }

      // Check strict idempotency for standard repeat activation without actionType
      if (!options?.actionType && masterSlotsAdded === 0 && isCurrentlyActive && existingPlan.allowance_accounts === sanitizedAllowance && (!options?.capabilityIncrement || existingPlan.metadata?.capabilityIncrement)) {
        return existingPlan;
      }

      // Compute capacity blocks & forever expiration dates (slots remain forever)
      const now = new Date();
      const foreverIso = '9999-12-31T23:59:59.999Z';
      let blocks = existingPlan?.metadata?.blocks || [];
      if (!Array.isArray(blocks) || blocks.length === 0) {
        if (existingPlan && currentAllowance > 0) {
          blocks = [{
            allowance: currentAllowance,
            created_at: existingPlan.created_at || now.toISOString(),
            expires_at: existingPlan.expires_at || foreverIso
          }];
        } else {
          blocks = [];
        }
      }

      // Retain unexpired blocks
      blocks = blocks.filter((b: any) => !b.expires_at || new Date(b.expires_at).getTime() > now.getTime());

      const nextPlanNumber = blocks.length + 1;

      // Generate unique Fleet ID(s)
      const existingFleetIds: string[] = Array.isArray(existingPlan?.metadata?.fleet_ids)
        ? existingPlan.metadata.fleet_ids.filter(Boolean)
        : (existingPlan?.metadata?.fleet_id ? [existingPlan.metadata.fleet_id] : []);

      const generatedFleetIds: string[] = [];
      const slotsToGenerate = masterSlotsAdded > 0 ? masterSlotsAdded : (existingFleetIds.length === 0 ? 1 : 0);
      for (let i = 0; i < slotsToGenerate; i++) {
        const seg1 = crypto.randomBytes(2).toString('hex').toUpperCase();
        const seg2 = crypto.randomBytes(2).toString('hex').toUpperCase();
        generatedFleetIds.push(`FLT-${seg1}-${seg2}`);
      }

      const allFleetIds = [...existingFleetIds, ...(masterSlotsAdded > 0 ? generatedFleetIds : (existingFleetIds.length === 0 ? generatedFleetIds : []))];
      const primaryFleetId = allFleetIds[0] || `FLT-${crypto.randomBytes(2).toString('hex').toUpperCase()}-${crypto.randomBytes(2).toString('hex').toUpperCase()}`;
      const latestFleetId = generatedFleetIds.length > 0 ? generatedFleetIds[generatedFleetIds.length - 1] : primaryFleetId;

      const requestedRegEmails = (
        options?.masterRegistrationEmails && options.masterRegistrationEmails.length > 0
          ? options.masterRegistrationEmails
          : (options?.masterRegistrationEmail ? [options.masterRegistrationEmail] : [])
      ).map(e => String(e).trim().toLowerCase()).filter(Boolean);

      let transactionAmount = 0;
      let latestTxId: string = crypto.randomUUID();
      if (actionType === 'new_plan') {
        transactionAmount = Number((500 + Math.max(0, accountsBoughtThisTransaction - 10) * 100 + masterSlotsAdded * 200).toFixed(2));
        latestTxId = `plan_box_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;
        const newPlanBlock = {
          id: latestTxId,
          plan_number: nextPlanNumber,
          plan_name: `Master & Slave Agent Plan (Box #${nextPlanNumber})`,
          plan_subtitle: `Base Fleet Plan (${accountsBoughtThisTransaction} Slave Agents${masterSlotsAdded > 0 ? `, +${masterSlotsAdded} Master ${masterSlotsAdded === 1 ? 'Slot' : 'Slots'}` : ''})`,
          plan_type: 'master_slave_scale',
          action_type: 'new_plan',
          allowance: accountsBoughtThisTransaction,
          master_slots_added: masterSlotsAdded,
          fleet_id: latestFleetId,
          fleet_ids: masterSlotsAdded > 0 ? generatedFleetIds : [primaryFleetId],
          registered_email: requestedRegEmails[0] || options?.masterRegistrationEmail,
          registered_emails: requestedRegEmails,
          created_at: now.toISOString(),
          expires_at: foreverIso,
          amount: transactionAmount,
          currency: 'USD',
          status: 'active'
        };
        blocks.push(newPlanBlock);
      } else if (actionType === 'add_accounts') {
        transactionAmount = Number((accountsBoughtThisTransaction * 100 + masterSlotsAdded * 200).toFixed(2));
        const isMasterSlotOnly = accountsBoughtThisTransaction === 0 && masterSlotsAdded > 0;
        const isCombined = accountsBoughtThisTransaction > 0 && masterSlotsAdded > 0;
        latestTxId = `plan_box_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;
        const addOnBlock = {
          id: latestTxId,
          plan_number: nextPlanNumber,
          plan_name: isMasterSlotOnly
            ? `Master Account Slot Plan (Box #${nextPlanNumber})`
            : isCombined
            ? `Master & Slave Capacity Expansion (Box #${nextPlanNumber})`
            : `Slave Capacity Add-On Plan (Box #${nextPlanNumber})`,
          plan_subtitle: isMasterSlotOnly
            ? `Master Account Expansion (+${masterSlotsAdded} Master ${masterSlotsAdded === 1 ? 'Slot' : 'Slots'})`
            : `Capacity Expansion (+${accountsBoughtThisTransaction} Slave ${accountsBoughtThisTransaction === 1 ? 'Agent' : 'Agents'}${masterSlotsAdded > 0 ? `, +${masterSlotsAdded} Master ${masterSlotsAdded === 1 ? 'Slot' : 'Slots'}` : ''})`,
          plan_type: 'master_slave_scale',
          action_type: 'add_accounts',
          allowance: accountsBoughtThisTransaction,
          master_slots_added: masterSlotsAdded,
          fleet_id: latestFleetId,
          fleet_ids: masterSlotsAdded > 0 ? generatedFleetIds : (existingFleetIds.length > 0 ? existingFleetIds : [primaryFleetId]),
          registered_email: requestedRegEmails[0] || options?.masterRegistrationEmail,
          registered_emails: requestedRegEmails,
          created_at: now.toISOString(),
          expires_at: foreverIso,
          amount: transactionAmount,
          currency: 'USD',
          status: 'active'
        };
        blocks.push(addOnBlock);
      }

      const totalAllowance = Math.min(1000, blocks.reduce((sum: number, b: any) => sum + (b.allowance || 0), 0));
      sanitizedAllowance = totalAllowance;

      const maxExpiry = blocks.length > 0
        ? blocks.reduce((latest: string, b: any) => new Date(b.expires_at) > new Date(latest) ? b.expires_at : latest, blocks[0].expires_at)
        : foreverIso;

      const expiresAt: string | null = maxExpiry;

      // 4. Construct complete entitlement record (reuse existing row id even if previously expired/canceled)
      const nowIso = now.toISOString();
      let existingRowId = existingPlan?.id;
      if (!existingRowId) {
        try {
          const { data: anyExistingRow } = await sb
            .from('master_plan_entitlements')
            .select('id')
            .eq('master_account_id', masterId)
            .eq('plan_type', 'master_slave_scale')
            .maybeSingle();
          if (anyExistingRow?.id) {
            existingRowId = anyExistingRow.id;
          }
        } catch {}
      }
      const entitlementId = existingRowId || crypto.randomUUID();
      const previousInvitations = Array.isArray(existingPlan?.metadata?.fleet_slot_invitations)
        ? existingPlan.metadata.fleet_slot_invitations
        : [];
      const newInvitations = [...previousInvitations];
      for (let i = 0; i < requestedRegEmails.length; i++) {
        const invEmail = requestedRegEmails[i];
        const pairedFleetId = generatedFleetIds[i] || latestFleetId;
        newInvitations.push({
          fleet_id: pairedFleetId,
          email: invEmail,
          invite_token: crypto.randomBytes(16).toString('hex'),
          master_id: masterId,
          status: 'pending',
          allocated_at: nowIso
        });
      }

      const entitlement: MasterPlanEntitlement = {
        id: entitlementId,
        master_account_id: masterId,
        plan_type: 'master_slave_scale',
        plan_name: 'Master & Slave Agent Plan',
        status: 'active',
        allowance_accounts: sanitizedAllowance,
        tier: 'scale',
        created_at: existingPlan?.created_at || nowIso,
        updated_at: nowIso,
        expires_at: expiresAt,
        metadata: {
          ...(existingPlan?.metadata || {}),
          source: 'aamarva_internal_entitlement',
          latest_transaction_id: latestTxId,
          previous_allowance: currentAllowance,
          activated_by_master_id: masterId,
          action_type: actionType,
          accounts_bought: accountsBoughtThisTransaction,
          accounts_in_transaction: accountsBoughtThisTransaction,
          added_accounts: accountsBoughtThisTransaction,
          amount: transactionAmount,
          fleet_id: primaryFleetId,
          latest_fleet_id: latestFleetId,
          new_fleet_ids: generatedFleetIds,
          fleet_ids: allFleetIds,
          master_slots: totalMasterSlots,
          master_slots_added: masterSlotsAdded,
          registered_email: requestedRegEmails[0] || options?.masterRegistrationEmail,
          registered_emails: Array.from(new Set([
            ...((existingPlan?.metadata?.registered_emails as string[]) || []).map((e: string) => String(e).toLowerCase().trim()),
            ...requestedRegEmails
          ].filter(Boolean))),
          fleet_slot_invitations: newInvitations,
          blocks: blocks,
          created_at: nowIso,
          expires_at: expiresAt
        }
      };

      // 5. Atomic database persistence
      const upsertPayload = {
        id: entitlement.id,
        master_account_id: entitlement.master_account_id,
        plan_type: entitlement.plan_type,
        plan_name: entitlement.plan_name,
        status: entitlement.status,
        allowance_accounts: entitlement.allowance_accounts,
        tier: entitlement.tier,
        created_at: entitlement.created_at,
        updated_at: entitlement.updated_at,
        expires_at: entitlement.expires_at,
        metadata: entitlement.metadata
      };

      let mpeWriteErr: any = null;
      try {
        const resUpsert = await sb
          .from('master_plan_entitlements')
          .upsert(upsertPayload, { onConflict: 'master_account_id,plan_type' });
        if (resUpsert?.error) {
          mpeWriteErr = resUpsert.error;
          const { id: _omitId, ...updatePayload } = upsertPayload;
          const resUpdate = await sb
            .from('master_plan_entitlements')
            .update(updatePayload)
            .eq('master_account_id', masterId)
            .eq('plan_type', entitlement.plan_type);

          if (resUpdate?.error) {
            const resInsert = await sb.from('master_plan_entitlements').insert(upsertPayload);
            if (!resInsert?.error) {
              mpeWriteErr = null;
            } else {
              mpeWriteErr = resInsert.error;
            }
          } else {
            mpeWriteErr = null;
          }
        }
      } catch (upsertErr: any) {
        mpeWriteErr = upsertErr;
      }

      if (mpeWriteErr) {
        console.error('[MasterAccountService] Error persisting master_plan_entitlements:', mpeWriteErr?.message || mpeWriteErr);
        if (isSupabaseConfigured()) {
          throw new Error(`Failed to persist Master Plan entitlement: ${mpeWriteErr?.message || 'Database error'}`);
        }
      }

      // Step B: Update users table plan column (guaranteed database column)
      const { error: userUpdateErr } = await sb
        .from('users')
        .update({
          plan: 'master_slave_scale'
        })
        .eq('id', masterId);

      if (userUpdateErr) {
        console.warn('[MasterAccountService] Warning updating user plan:', userUpdateErr.message);
      }

      // Step C: Log persistent audit record in external_events table sharing latestTxId for Watchtower dedup
      const { error: eventErr } = await sb
        .from('external_events')
        .insert({
          id: latestTxId,
          user_id: masterId,
          type: 'PLAN_ENTITLEMENT_ACTIVATED',
          details: JSON.stringify(entitlement),
          created_at: nowIso
        });

      if (eventErr) {
        console.warn('[MasterAccountService] Warning writing external_events audit log:', eventErr.message);
      }

      // 6. Update in-memory caches
      this.setMasterPlanCache(masterId, entitlement);

      return entitlement;
    } finally {
      releaseLock();
    }
  }

  public async getMasterAccount(masterId: string): Promise<MasterAccountRecord | null> {
    // Check database (via 60s TTL cache) for active master plan entitlement
    const plan = await this.getMasterPlan(masterId);
    if (plan && plan.status === 'active') {
      const record: MasterAccountRecord = {
        id: masterId,
        plan_status: 'ACTIVE',
        tier: plan.tier || 'scale',
        max_sub_agents: plan.allowance_accounts || 0
      };
      this.masterAccountCache.set(masterId, record);
      return record;
    }

    // Genuinely inactive: 0 slave slots when no master plan is purchased or active
    const inactiveRecord: MasterAccountRecord = {
      id: masterId,
      plan_status: 'INACTIVE',
      tier: 'free',
      max_sub_agents: 0
    };
    this.masterAccountCache.delete(masterId);
    return inactiveRecord;
  }

  public getUserByFingerprint(fingerprint: string): UserAccountMetadata | null {
    return this.fingerprintCache.get(fingerprint) || null;
  }

  public getUserMetadata(userId: string): UserAccountMetadata | null {
    return this.metadataCache.get(userId) || null;
  }

  public async refreshUserMetadata(userId: string): Promise<UserAccountMetadata | null> {
    try {
      const sb = getSupabaseClient();
      const { data, error } = await sb
        .from('users')
        .select('id, agentId, master_id, is_master_primary')
        .or(`id.eq.${userId},agentId.eq.${userId}`)
        .maybeSingle();
      if (data && !error) {
        const meta: UserAccountMetadata = {
          id: data.id,
          master_id: data.master_id,
          is_master_primary: data.is_master_primary === true
        };
        this.metadataCache.set(userId, meta);
        this.metadataCache.set(data.id, meta);
        if (data.agentId) {
          this.metadataCache.set(data.agentId, meta);
        }
        return meta;
      }
    } catch (e) {}
    return this.metadataCache.get(userId) || null;
  }

  public async getMasterPlanHistory(masterId: string): Promise<any[]> {
    if (!masterId) return [];
    try {
      const sb = getSupabaseClient();
      const rootMasterId = await this.resolveRootMasterId(sb, masterId);
      
      // 1. Get master's own plan entitlement events
      const { data, error } = await sb
        .from('external_events')
        .select('*')
        .eq('user_id', rootMasterId)
        .eq('type', 'PLAN_ENTITLEMENT_ACTIVATED')
        .order('created_at', { ascending: false });

      if (error) {
        console.warn('[MasterAccountService] Error fetching plan events:', error.message);
      }

      // 2. Get all users in fleet (pioneer master, sub-masters, and subordinate slaves)
      const { data: directChildren } = await sb
        .from('users')
        .select('id, agentId, name, avatar, status, account_type, role, is_slave, is_master_slot')
        .eq('master_id', rootMasterId);

      const subMasterIds = (directChildren || [])
        .filter((u: any) => !u.is_slave && u.account_type !== 'slave' && u.role !== 'slave' && (u.is_master_slot === true || u.account_type === 'master_slot' || u.role === 'master'))
        .map((u: any) => u.id);
      const allMasterIds = Array.from(new Set([rootMasterId, masterId, ...subMasterIds]));

      const { data: fleetUsers } = await sb
        .from('users')
        .select('id, agentId, name, avatar, status')
        .or(`id.in.(${allMasterIds.join(',')}),master_id.in.(${allMasterIds.join(',')})`);

      const userLookupMap = new Map<string, any>();
      for (const u of (fleetUsers || [])) {
        if (u.id) userLookupMap.set(String(u.id).toLowerCase(), u);
        if (u.agentId) userLookupMap.set(String(u.agentId).toLowerCase(), u);
        if (u.name) userLookupMap.set(String(u.name).toLowerCase(), u);
      }

      const slaveIds = (fleetUsers || []).filter((u: any) => !allMasterIds.includes(u.id)).map((s: any) => s.id);

      // Get batch capability activation events scoped to fleet masters
      const { data: batchEvs } = await sb
        .from('external_events')
        .select('*')
        .eq('type', 'SLAVE_CAPABILITY_BATCH_ACTIVATED')
        .in('user_id', allMasterIds)
        .order('created_at', { ascending: false });

      const masterBatches = (batchEvs || []).filter((ev: any) => {
        let details = ev.details;
        if (typeof details === 'string') {
          try { details = JSON.parse(details); } catch (e) {}
        }
        return allMasterIds.includes(details?.master_id) || allMasterIds.includes(ev.user_id);
      });

      let formattedCapabilities: any[] = [];
      const seenBatchIds = new Set<string>();

      for (const ev of masterBatches) {
        if (seenBatchIds.has(ev.id)) continue;
        seenBatchIds.add(ev.id);

        let details = ev.details;
        if (typeof details === 'string') {
          try { details = JSON.parse(details); } catch (e) {}
        }
        const validityDays = details?.validity_days || details?.metadata?.validity_days_extended || 30;
        const rawTargetIds = details?.target_account_ids || (details?.target_slave_id ? [details.target_slave_id] : (details?.agent_id ? [details.agent_id] : []));
        const targetAccountIds: string[] = (Array.isArray(rawTargetIds) ? rawTargetIds : [rawTargetIds])
          .map((id: any) => String(id || '').trim())
          .filter((id: string) => id && id.toLowerCase() !== 'master' && id !== masterId);
        const count = details?.accounts_count || targetAccountIds.length || (details?.target_accounts?.length || 1);
        const createdMs = ev.created_at ? new Date(ev.created_at).getTime() : Date.now();
        const resolvedExpiresAt = details?.expires_at || details?.metadata?.expires_at || new Date(createdMs + validityDays * 24 * 60 * 60 * 1000).toISOString();
        const isEvActive = new Date(resolvedExpiresAt).getTime() > Date.now();

        // Resolve exact target_accounts objects (strictly for slave agents, never the master)
        let resolvedTargetAccounts: any[] = [];
        if (Array.isArray(details?.target_accounts) && details.target_accounts.length > 0) {
          resolvedTargetAccounts = details.target_accounts.filter((a: any) => a.id !== masterId && a.agent_id !== masterId);
        } else {
          resolvedTargetAccounts = targetAccountIds.map((targetId: string, tIdx: number) => {
            const trimmed = String(targetId).trim().toLowerCase();
            const found = userLookupMap.get(trimmed);
            if (found && found.id !== masterId) {
              return {
                id: found.id,
                agent_id: found.agentId || found.id,
                name: found.name || found.agentId || 'Slave Agent',
                avatar: found.avatar,
                isDeployed: true,
                status: found.status || 'active'
              };
            }
            return {
              id: targetId,
              agent_id: targetId,
              name: targetId.startsWith('usr_') ? `Slave Agent #${tIdx + 1}` : targetId,
              isDeployed: true,
              status: 'active'
            };
          }).filter((a: any) => a.id !== masterId && a.agent_id !== masterId);
        }

        const effectiveCount = resolvedTargetAccounts.length > 0 ? resolvedTargetAccounts.length : (targetAccountIds.length > 0 ? targetAccountIds.length : count);

        formattedCapabilities.push({
          id: ev.id,
          plan_name: 'Capability Increment Plan',
          plan_subtitle: `Rate-Limit Increment (${effectiveCount} ${effectiveCount === 1 ? 'Account' : 'Accounts'} in Transaction, +${validityDays} Days)`,
          plan_type: 'slave_capability',
          action_type: 'capability_increment',
          allowance_accounts: effectiveCount,
          accounts_in_transaction: effectiveCount,
          target_account_ids: targetAccountIds,
          target_accounts: resolvedTargetAccounts,
          amount: 100 * effectiveCount,
          currency: 'USD',
          created_at: ev.created_at,
          expires_at: resolvedExpiresAt,
          status: isEvActive ? 'active' : 'expired',
          is_active: isEvActive,
          is_batch: true
        });
      }

      // Also include direct individual capability events if any exist and not already in batch
      const { data: capEvs } = await sb
        .from('external_events')
        .select('*')
        .eq('type', 'SLAVE_CAPABILITY_ACTIVATED')
        .order('created_at', { ascending: false });

      const capabilityEvents = (capEvs || []).filter((ev: any) => {
        let details = ev.details;
        if (typeof details === 'string') {
          try { details = JSON.parse(details); } catch (e) {}
        }
        const targetId = details?.target_slave_id || details?.agent_id || (ev.user_id !== masterId ? ev.user_id : null) || (details?.user_id !== masterId ? details?.user_id : null);
        if (!targetId || targetId === masterId) return false;
        return slaveIds.includes(targetId) || details?.master_id === masterId;
      });

      const batchMetaList = formattedCapabilities.map((b) => {
        const startMs = b.created_at ? new Date(b.created_at).getTime() : 0;
        const expMs = b.expires_at ? new Date(b.expires_at).getTime() : 0;
        const valDays = b.target_accounts?.length ? Math.round((expMs - startMs) / (24 * 60 * 60 * 1000)) || 30 : 30;
        const inferredEndMs = expMs ? expMs - valDays * 24 * 60 * 60 * 1000 : startMs;
        const windowEndMs = Math.max(startMs + 120_000, inferredEndMs + 15_000, startMs + (b.accounts_in_transaction || 1) * 5_000);
        const memberKeys = new Set<string>();
        for (const tid of (b.target_account_ids || [])) {
          if (tid) memberKeys.add(String(tid).trim().toLowerCase());
        }
        for (const acc of (b.target_accounts || [])) {
          if (acc?.id) memberKeys.add(String(acc.id).trim().toLowerCase());
          if (acc?.agent_id) memberKeys.add(String(acc.agent_id).trim().toLowerCase());
        }
        return { id: b.id, startMs, expMs, windowEndMs, memberKeys };
      });

      const seenIndiv = new Set<string>();
      const seenStandaloneKeys = new Set<string>();
      for (const ev of capabilityEvents) {
        if (seenIndiv.has(ev.id) || seenBatchIds.has(ev.id)) continue;
        seenIndiv.add(ev.id);

        let details = ev.details;
        if (typeof details === 'string') {
          try { details = JSON.parse(details); } catch (e) {}
        }

        // Skip if this event was part of an already included batch
        if (details?.batch_id && seenBatchIds.has(details.batch_id)) continue;

        const targetId = details?.target_slave_id || details?.agent_id || (ev.user_id !== masterId ? ev.user_id : null) || (details?.user_id !== masterId ? details?.user_id : null);
        if (!targetId || targetId === masterId) continue;

        const targetUserFound = userLookupMap.get(String(targetId || '').trim().toLowerCase());
        const candidateKeys = [
          String(targetId || '').trim().toLowerCase(),
          String(details?.agent_id || '').trim().toLowerCase(),
          String(targetUserFound?.id || '').trim().toLowerCase(),
          String(targetUserFound?.agentId || '').trim().toLowerCase()
        ].filter(Boolean);

        const validityDays = details?.metadata?.validity_days_extended || details?.validity_days || 30;
        const createdMs = ev.created_at ? new Date(ev.created_at).getTime() : Date.now();
        const resolvedExpiresAt = details?.expires_at || details?.metadata?.expires_at || new Date(createdMs + validityDays * 24 * 60 * 60 * 1000).toISOString();
        const indivExpMs = new Date(resolvedExpiresAt).getTime();

        const belongsToBatch = batchMetaList.some((bm) => {
          const matchesTarget = candidateKeys.some((k) => bm.memberKeys.has(k));
          if (!matchesTarget) return false;
          const withinCreationWindow = createdMs >= (bm.startMs - 10_000) && createdMs <= bm.windowEndMs;
          const withinExpiryWindow = bm.expMs > 0 && indivExpMs > 0 && Math.abs(bm.expMs - indivExpMs) <= 120_000;
          return withinCreationWindow || withinExpiryWindow;
        });
        if (belongsToBatch) continue;

        const standaloneKey = `${targetUserFound?.id || targetId}:${Math.floor(createdMs / 15_000)}`;
        if (seenStandaloneKeys.has(standaloneKey)) continue;
        seenStandaloneKeys.add(standaloneKey);

        const isEvActive = indivExpMs > Date.now();
        const targetName = details?.metadata?.target_slave_name || targetUserFound?.name || details?.agent_id || 'Slave Agent';

        const indivTargetAccount = {
          id: targetUserFound?.id || targetId,
          agent_id: targetUserFound?.agentId || details?.agent_id || targetId,
          name: targetName,
          avatar: targetUserFound?.avatar,
          isDeployed: true,
          status: targetUserFound?.status || 'active'
        };

        formattedCapabilities.push({
          id: ev.id,
          plan_name: 'Capability Increment Plan',
          plan_subtitle: `Rate-Limit Increment for ${targetName} (+${validityDays} Days)`,
          plan_type: 'slave_capability',
          action_type: 'capability_increment',
          allowance_accounts: 1,
          accounts_in_transaction: 1,
          target_account_ids: [targetId],
          target_accounts: [indivTargetAccount],
          amount: 100,
          currency: 'USD',
          created_at: ev.created_at,
          expires_at: resolvedExpiresAt,
          status: isEvActive ? (details?.status || 'active') : 'expired',
          is_active: isEvActive,
          is_direct: true,
          target_slave_id: targetId
        });
      }

      const eventsList = (data && Array.isArray(data)) ? data : [];

      // If no history events found but master plan exists, synthesize base / add-on events
      const foreverIso = '9999-12-31T23:59:59.999Z';
      let masterHistory: any[] = [];
      if (eventsList.length === 0) {
        const plan = await this.getMasterPlan(masterId);
        if (plan && plan.status === 'active') {
          const allowance = plan.allowance_accounts || 10;
          const planCreated = plan.created_at || new Date().toISOString();
          const planExpires = plan.expires_at || foreverIso;
          const isActive = !planExpires || new Date(planExpires).getTime() > Date.now();
          const masterSlotsTotal = typeof plan.metadata?.master_slots === 'number' ? plan.metadata.master_slots : 1;
          const masterSlotsAdded = Math.max(0, masterSlotsTotal - 1);

          const synthesized: any[] = [];
          const addOnCount = Math.max(0, allowance - 10);
          synthesized.push({
            id: `plan_${plan.id}`,
            plan_name: 'Master & Slave Agent Plan',
            plan_subtitle: addOnCount > 0 || masterSlotsAdded > 0
              ? `Fleet Roster (${allowance} Slave Agents${masterSlotsAdded > 0 ? `, +${masterSlotsAdded} Master ${masterSlotsAdded === 1 ? 'Slot' : 'Slots'}` : ''})`
              : `Base Fleet Roster (10 Slave Agents)`,
            plan_type: 'master_slave_scale',
            action_type: addOnCount > 0 ? 'add_accounts' : 'new_plan',
            allowance_accounts: allowance,
            accounts_in_transaction: allowance,
            added_accounts: allowance,
            master_slots_added: masterSlotsAdded,
            tier: 'scale',
            status: isActive ? 'active' : 'expired',
            is_active: isActive,
            amount: 500 + addOnCount * 100 + masterSlotsAdded * 200,
            currency: 'USD',
            created_at: planCreated,
            expires_at: planExpires,
            metadata: { action_type: addOnCount > 0 ? 'add_accounts' : 'new_plan', allowance, addOnCount, master_slots_added: masterSlotsAdded }
          });

          masterHistory = synthesized;
        }
      } else {
        // Group events that occur within 5 seconds of each other into the same transaction
        const groups: Array<{ keyTimestamp: string; events: any[] }> = [];
        for (const ev of eventsList) {
          const evTime = new Date(ev.created_at).getTime();
          const existingGroup = groups.find(g => Math.abs(new Date(g.keyTimestamp).getTime() - evTime) < 5000);
          if (existingGroup) {
            existingGroup.events.push(ev);
          } else {
            groups.push({ keyTimestamp: ev.created_at, events: [ev] });
          }
        }

        masterHistory = groups.map(({ keyTimestamp: timestamp, events }) => {
          const combinedDetails = events.reduce((acc, ev) => {
            let details = ev.details;
            if (typeof details === 'string') {
              try { details = JSON.parse(details); } catch (e) {}
            }
            return { ...acc, ...details };
          }, {});

          const allowance = combinedDetails?.allowance_accounts || 10;
          const meta = combinedDetails?.metadata || {};
          const actionType = meta.action_type || (allowance > 10 ? 'add_accounts' : 'new_plan');
          const masterSlotsAdded = Math.max(0, Number(combinedDetails?.master_slots_added ?? meta?.master_slots_added ?? 0));

          const rawAccountsInTx = combinedDetails?.accounts_in_transaction
            ?? meta?.accounts_in_transaction
            ?? meta?.accounts_bought
            ?? meta?.added_accounts;
          const accountsInTx = rawAccountsInTx !== undefined && rawAccountsInTx !== null
            ? Number(rawAccountsInTx)
            : (actionType === 'new_plan' ? allowance : Math.max(0, allowance - (meta?.previous_allowance || 10)));

          const isMasterSlotOnly = actionType === 'add_accounts' && accountsInTx === 0 && masterSlotsAdded > 0;
          const planTitle = isMasterSlotOnly ? 'Master Slot Expansion' : 'Master & Slave Agent Plan';
          let planSubtitle = `Base Fleet Plan (${accountsInTx} Slave Agents)`;
          let amount = 500;

          if (actionType === 'add_accounts') {
            if (isMasterSlotOnly) {
              planSubtitle = `Master Account Expansion (+${masterSlotsAdded} Master ${masterSlotsAdded === 1 ? 'Slot' : 'Slots'})`;
            } else if (masterSlotsAdded > 0) {
              planSubtitle = `Capacity Expansion (+${accountsInTx} Slave ${accountsInTx === 1 ? 'Agent' : 'Agents'}, +${masterSlotsAdded} Master ${masterSlotsAdded === 1 ? 'Slot' : 'Slots'})`;
            } else {
              planSubtitle = `Capacity Expansion (+${accountsInTx} Slave ${accountsInTx === 1 ? 'Agent' : 'Agents'})`;
            }
            amount = meta.amount ?? combinedDetails.amount ?? Number((accountsInTx * 100 + masterSlotsAdded * 200).toFixed(2));
          } else {
            planSubtitle = masterSlotsAdded > 0
              ? `Base Fleet Plan (${accountsInTx} Slave Agents, +${masterSlotsAdded} Master ${masterSlotsAdded === 1 ? 'Slot' : 'Slots'})`
              : `Base Fleet Plan (${accountsInTx} Slave Agents)`;
            amount = meta.amount ?? combinedDetails.amount ?? Number((500 + Math.max(0, accountsInTx - 10) * 100 + masterSlotsAdded * 200).toFixed(2));
          }

          const txExpiresAt = (meta.expires_at || combinedDetails?.expires_at)
            ? new Date(meta.expires_at || combinedDetails.expires_at).toISOString()
            : foreverIso;
          const isCurrentlyActive = !txExpiresAt || new Date(txExpiresAt).getTime() > Date.now();

          return {
            id: events[0].id,
            plan_name: planTitle,
            plan_subtitle: planSubtitle,
            plan_type: combinedDetails?.plan_type || 'master_slave_scale',
            action_type: actionType,
            allowance_accounts: allowance,
            accounts_in_transaction: accountsInTx,
            added_accounts: accountsInTx,
            master_slots_added: masterSlotsAdded,
            tier: combinedDetails?.tier || 'scale',
            status: isCurrentlyActive ? 'active' : 'expired',
            is_active: isCurrentlyActive,
            amount: amount,
            currency: 'USD',
            created_at: timestamp,
            expires_at: txExpiresAt,
            metadata: meta
          };
        });
      }

      return [...formattedCapabilities, ...masterHistory];
    } catch (e) {
      console.warn('[MasterAccountService] Error fetching plan history:', e);
      return [];
    }
  }

  private expiredRegistrationLinkCache = new Map<string, { valid: false; expired: true; reason: string; message: string }>();

  private markRegistrationLinkExpiredInCache(
    params: { email?: string; fleetId?: string; slotToken?: string },
    result: { valid: false; expired: true; reason: string; message: string }
  ): void {
    const cleanEmail = (params.email || '').trim().toLowerCase();
    const cleanFleetId = (params.fleetId || '').trim().replace(/^@/, '').toUpperCase();
    const cleanToken = (params.slotToken || '').trim();
    if (this.expiredRegistrationLinkCache.size > 5000) {
      this.expiredRegistrationLinkCache.clear();
    }
    if (cleanToken) this.expiredRegistrationLinkCache.set(`token:${cleanToken}`, result);
    if (cleanFleetId) this.expiredRegistrationLinkCache.set(`fleet:${cleanFleetId}`, result);
    if (cleanEmail) this.expiredRegistrationLinkCache.set(`email:${cleanEmail}`, result);
  }

  /**
   * Checks whether a registration / fleet slot invitation link is still valid or has expired because registration already completed through it.
   */
  public async checkRegistrationLinkStatus(params: {
    email?: string;
    fleetId?: string;
    slotToken?: string;
  }): Promise<{
    valid: boolean;
    expired: boolean;
    reason?: string;
    message?: string;
  }> {
    try {
      const sb = getSupabaseClient();
      const cleanEmail = (params.email || '').trim().toLowerCase();
      const cleanFleetId = (params.fleetId || '').trim().replace(/^@/, '').toUpperCase();
      const cleanToken = (params.slotToken || '').trim();

      if (!cleanEmail && !cleanFleetId && !cleanToken) {
        return { valid: true, expired: false };
      }

      // Fast <1ms in-memory check (expired links never become valid again)
      const cachedHit =
        (cleanToken ? this.expiredRegistrationLinkCache.get(`token:${cleanToken}`) : undefined) ||
        (cleanFleetId ? this.expiredRegistrationLinkCache.get(`fleet:${cleanFleetId}`) : undefined) ||
        (cleanEmail ? this.expiredRegistrationLinkCache.get(`email:${cleanEmail}`) : undefined);
      if (cachedHit) {
        return cachedHit;
      }

      // Run user email check and active entitlements check in parallel
      const [userRes, entRes] = await Promise.all([
        cleanEmail
          ? sb.from('users').select('id').ilike('email', cleanEmail).limit(1)
          : Promise.resolve({ data: null }),
        (cleanFleetId || cleanToken || cleanEmail)
          ? sb.from('master_plan_entitlements').select('id, metadata, master_account_id').eq('status', 'active')
          : Promise.resolve({ data: null }),
      ]);

      // 1. Check if email is already registered in users table
      if (Array.isArray(userRes?.data) && userRes.data.length > 0) {
        const res = {
          valid: false as const,
          expired: true as const,
          reason: 'EMAIL_ALREADY_REGISTERED',
          message: 'This registration link has expired because an account with this email has already been registered.'
        };
        this.markRegistrationLinkExpiredInCache({ email: cleanEmail, fleetId: cleanFleetId, slotToken: cleanToken }, res);
        return res;
      }

      // 2. Check active master_plan_entitlements for fleet_slot_invitations / blocks
      const entitlements = entRes?.data;
      if (Array.isArray(entitlements)) {
        for (const ent of entitlements) {
          const meta = ent.metadata || {};
          const invitations: any[] = Array.isArray(meta.fleet_slot_invitations) ? meta.fleet_slot_invitations : [];

          const matchedInv = invitations.find((inv: any) => {
            const invToken = String(inv?.invite_token || '').trim();
            const invFid = String(inv?.fleet_id || '').replace(/^@/, '').toUpperCase();
            const invEmail = String(inv?.email || '').trim().toLowerCase();
            if (cleanToken && invToken && invToken === cleanToken) return true;
            if (cleanFleetId && invFid && invFid === cleanFleetId) return true;
            if (!cleanFleetId && !cleanToken && cleanEmail && invEmail === cleanEmail) return true;
            return false;
          });

          if (matchedInv) {
            const isClaimed =
              matchedInv.status === 'registered' ||
              Boolean(matchedInv.claimed_by_user_id) ||
              Boolean(matchedInv.claimed_at);

            if (isClaimed) {
              const res = {
                valid: false as const,
                expired: true as const,
                reason: 'INVITATION_ALREADY_USED',
                message: 'This registration link has expired because it has already been used to complete registration.'
              };
              this.markRegistrationLinkExpiredInCache({ email: matchedInv.email || cleanEmail, fleetId: matchedInv.fleet_id || cleanFleetId, slotToken: matchedInv.invite_token || cleanToken }, res);
              return res;
            }

            const invEmail = String(matchedInv.email || '').trim().toLowerCase();
            if (invEmail && invEmail !== cleanEmail) {
              const { data: boundUser } = await sb
                .from('users')
                .select('id')
                .ilike('email', invEmail)
                .limit(1);
              if (Array.isArray(boundUser) && boundUser.length > 0) {
                const res = {
                  valid: false as const,
                  expired: true as const,
                  reason: 'EMAIL_ALREADY_REGISTERED',
                  message: 'This registration link has expired because this assigned slot has already been registered.'
                };
                this.markRegistrationLinkExpiredInCache({ email: invEmail, fleetId: matchedInv.fleet_id || cleanFleetId, slotToken: matchedInv.invite_token || cleanToken }, res);
                return res;
              }
            }

            const maxSlots = typeof meta.master_slots === 'number' ? meta.master_slots : 1;
            const maxAddonSlots = Math.max(0, maxSlots - 1);
            const currentDeployed = typeof meta.deployed_master_slots === 'number' ? meta.deployed_master_slots : 0;
            if (currentDeployed >= maxAddonSlots) {
              const res = {
                valid: false as const,
                expired: true as const,
                reason: 'NO_SLOTS_LEFT',
                message: 'This registration link has expired because no master slots remain available.'
              };
              this.markRegistrationLinkExpiredInCache({ fleetId: cleanFleetId, slotToken: cleanToken }, res);
              return res;
            }

            return { valid: true, expired: false };
          }

          // Check block metadata as fallback if invitation entry matched a claimed block
          if (cleanFleetId && Array.isArray(meta.blocks)) {
            const matchedBlock = meta.blocks.find((b: any) =>
              String(b?.fleet_id || '').replace(/^@/, '').toUpperCase() === cleanFleetId
            );
            if (matchedBlock && (matchedBlock.claimed_by_user_id || matchedBlock.claimed_at)) {
              const res = {
                valid: false as const,
                expired: true as const,
                reason: 'INVITATION_ALREADY_USED',
                message: 'This registration link has expired because this fleet slot has already been claimed.'
              };
              this.markRegistrationLinkExpiredInCache({ fleetId: cleanFleetId, email: matchedBlock.claimed_email || cleanEmail }, res);
              return res;
            }
          }
        }
      }

      return { valid: true, expired: false };
    } catch (err) {
      console.error('[MasterAccountService] checkRegistrationLinkStatus error:', err);
      return { valid: true, expired: false };
    }
  }

  /**
   * Claims an allocated Master slot in a fleet when an invited user registers with their email and fleetId.
   */
  public async claimMasterSlotByFleetId(
    fleetId: string, 
    email: string, 
    newUserId: string
  ): Promise<{ success: boolean; masterUserId?: string; fleetId?: string; error?: string } | null> {
    try {
      const sb = getSupabaseClient();
      const rawFleetInput = (fleetId || '').trim();
      const cleanFleetId = rawFleetInput.replace(/^@/, '').toUpperCase();
      const cleanEmail = (email || '').trim().toLowerCase();

      if (!cleanFleetId && !cleanEmail) return null;

      // 1. Search active master_plan_entitlements for matching fleet ID or email invitation
      const { data: entitlements } = await sb
        .from('master_plan_entitlements')
        .select('*')
        .eq('status', 'active');

      if (entitlements && entitlements.length > 0) {
        for (const ent of entitlements) {
          const meta = ent.metadata || {};
          const fleetIds: string[] = [];
          if (meta.fleet_id) fleetIds.push(String(meta.fleet_id).replace(/^@/, '').toUpperCase());
          if (meta.latest_fleet_id) fleetIds.push(String(meta.latest_fleet_id).replace(/^@/, '').toUpperCase());
          if (Array.isArray(meta.fleet_ids)) {
            meta.fleet_ids.forEach((f: any) => f && fleetIds.push(String(f).replace(/^@/, '').toUpperCase()));
          }
          if (Array.isArray(meta.new_fleet_ids)) {
            meta.new_fleet_ids.forEach((f: any) => f && fleetIds.push(String(f).replace(/^@/, '').toUpperCase()));
          }
          if (Array.isArray(meta.blocks)) {
            meta.blocks.forEach((b: any) => {
              if (b.fleet_id) fleetIds.push(String(b.fleet_id).replace(/^@/, '').toUpperCase());
            });
          }

          const invitations: any[] = Array.isArray(meta.fleet_slot_invitations) ? meta.fleet_slot_invitations : [];
          const registeredEmails: string[] = Array.isArray(meta.registered_emails) 
            ? meta.registered_emails.map((e: string) => String(e).toLowerCase()) 
            : (meta.registered_email ? [String(meta.registered_email).toLowerCase()] : []);

          const masterAccountId = String(ent.master_account_id).replace(/^@/, '').toUpperCase();

          const matchesFleet = cleanFleetId && (
            fleetIds.includes(cleanFleetId) || 
            invitations.some((inv: any) => String(inv.fleet_id || '').replace(/^@/, '').toUpperCase() === cleanFleetId) ||
            masterAccountId === cleanFleetId
          );

          const matchesEmail = cleanEmail && (
            registeredEmails.includes(cleanEmail) || 
            invitations.some((inv: any) => String(inv.email || '').toLowerCase() === cleanEmail)
          );

          if (matchesFleet || matchesEmail) {
            const resolvedFleetId = rawFleetInput || fleetIds[0] || meta.fleet_id || `FLT-${ent.master_account_id.slice(0, 8).toUpperCase()}`;

            // Serialize slot checks & writes per master to prevent concurrent race over the last Master slot
            const releaseSlotLock = await this.acquireLock(`claim:${ent.master_account_id}`);
            try {
              // Re-read authoritative entitlement inside the lock when live mutating
              const { data: freshEnts } = await sb
                .from('master_plan_entitlements')
                .select('*')
                .eq('id', ent.id)
                .maybeSingle();
              const freshEnt = freshEnts || ent;
              const freshMeta = freshEnt.metadata || {};
              const freshInvitations: any[] = Array.isArray(freshMeta.fleet_slot_invitations) ? freshMeta.fleet_slot_invitations : [];
              const freshRegisteredEmails: string[] = Array.isArray(freshMeta.registered_emails)
                ? freshMeta.registered_emails.map((e: string) => String(e).toLowerCase())
                : (freshMeta.registered_email ? [String(freshMeta.registered_email).toLowerCase()] : []);

              const matchedByFleet = cleanFleetId
                ? freshInvitations.find((inv: any) => String(inv.fleet_id || '').replace(/^@/, '').toUpperCase() === cleanFleetId)
                : undefined;
              const matchedByEmail = cleanEmail
                ? freshInvitations.find((inv: any) => String(inv.email || '').toLowerCase() === cleanEmail)
                : undefined;
              const matchedInvitation = matchedByFleet || matchedByEmail;

              if (
                matchedInvitation &&
                (matchedInvitation.status === 'registered' ||
                  Boolean(matchedInvitation.claimed_by_user_id) ||
                  Boolean(matchedInvitation.claimed_at))
              ) {
                return {
                  success: false,
                  error: 'This invitation link has already been used and has expired.'
                };
              }

              if (
                matchedByFleet &&
                matchedByFleet.email &&
                cleanEmail &&
                String(matchedByFleet.email).toLowerCase() !== cleanEmail
              ) {
                return {
                  success: false,
                  error: 'This Fleet ID invitation is assigned to a different email address.'
                };
              }

              const maxSlots = typeof freshMeta.master_slots === 'number' ? freshMeta.master_slots : 1;
              const maxAddonSlots = Math.max(0, maxSlots - 1);
              const currentDeployed = typeof freshMeta.deployed_master_slots === 'number' ? freshMeta.deployed_master_slots : 0;
              const alreadyRegistered = freshInvitations.some((inv: any) =>
                (inv.status === 'registered' || inv.claimed_by_user_id) && String(inv.email || '').toLowerCase() === cleanEmail
              );

              if (alreadyRegistered) {
                return {
                  success: false,
                  error: 'This invitation link has already been used and has expired.'
                };
              }

              if (currentDeployed >= maxAddonSlots) {
                return {
                  success: false,
                  error: 'No master slots left'
                };
              }

              if (newUserId !== 'preview') {
                let invitationClaimed = false;
                const updatedInvitations = freshInvitations.map((inv: any) => {
                  const invFid = String(inv.fleet_id || '').replace(/^@/, '').toUpperCase();
                  const invEmail = String(inv.email || '').toLowerCase();
                  if ((cleanFleetId && invFid === cleanFleetId) || (cleanEmail && invEmail === cleanEmail)) {
                    invitationClaimed = true;
                    return {
                      ...inv,
                      status: 'registered',
                      claimed_by_user_id: newUserId,
                      claimed_email: cleanEmail,
                      claimed_at: new Date().toISOString()
                    };
                  }
                  return inv;
                });

                if (!invitationClaimed && cleanFleetId) {
                  updatedInvitations.push({
                    fleet_id: cleanFleetId,
                    email: cleanEmail,
                    status: 'registered',
                    claimed_by_user_id: newUserId,
                    claimed_email: cleanEmail,
                    claimed_at: new Date().toISOString()
                  });
                }

                const blocks = Array.isArray(freshMeta.blocks) ? freshMeta.blocks.map((b: any) => {
                  const bFid = String(b.fleet_id || '').replace(/^@/, '').toUpperCase();
                  const bEmail = String(b.registered_email || '').toLowerCase();
                  if ((cleanFleetId && bFid === cleanFleetId) || (cleanEmail && bEmail === cleanEmail)) {
                    return {
                      ...b,
                      claimed_by_user_id: newUserId,
                      claimed_email: cleanEmail,
                      claimed_at: new Date().toISOString()
                    };
                  }
                  return b;
                }) : [];

                const updatedMeta = {
                  ...freshMeta,
                  blocks,
                  fleet_slot_invitations: updatedInvitations,
                  registered_emails: Array.from(new Set([...freshRegisteredEmails, cleanEmail].filter(Boolean))),
                  deployed_master_slots: alreadyRegistered ? currentDeployed : currentDeployed + 1
                };

                try {
                  await sb.from('master_plan_entitlements').update({
                    metadata: updatedMeta,
                    updated_at: new Date().toISOString()
                  }).eq('id', freshEnt.id);
                } catch (e) {
                  console.warn('[MasterAccountService] Warning updating claimed slot metadata:', e);
                }

                this.masterPlanCache.delete(freshEnt.master_account_id);
                this.masterAccountCache.delete(freshEnt.master_account_id);
                this.markRegistrationLinkExpiredInCache(
                  { email: cleanEmail, fleetId: cleanFleetId || resolvedFleetId, slotToken: matchedInvitation?.invite_token },
                  {
                    valid: false,
                    expired: true,
                    reason: 'INVITATION_ALREADY_USED',
                    message: 'This registration link has expired because it has already been used to complete registration.'
                  }
                );
              }

              return {
                success: true,
                masterUserId: freshEnt.master_account_id,
                fleetId: resolvedFleetId
              };
            } finally {
              releaseSlotLock();
            }
          }
        }
      }

      // 2. Fallback strictly when an explicit Fleet ID was provided (never auto-claim normal solo signups by email alone or self-match)
      if (cleanFleetId) {
        const { data: usersList } = await sb.from('users').select('*');
        if (usersList && usersList.length > 0) {
          const matchedMaster = usersList.find((u: any) => {
            if (u.id === newUserId) return false;
            const uId = String(u.id || '').replace(/^@/, '').toUpperCase();
            const uAgentId = String(u.agentId || u.agent_id || '').replace(/^@/, '').toUpperCase();
            const uFleetId = String(u.fleet_id || u.fleetId || '').replace(/^@/, '').toUpperCase();

            const isMasterCandidate = u.is_master_primary === true || u.account_type === 'master' || u.role === 'master' || !u.master_id || u.master_id === u.id;

            if (!isMasterCandidate) return false;

            return (uFleetId === cleanFleetId || uAgentId === cleanFleetId || uId === cleanFleetId);
          });

          if (matchedMaster) {
            const masterPlan = await this.getMasterPlan(matchedMaster.id, true);
            const maxSlots = typeof masterPlan?.metadata?.master_slots === 'number' ? masterPlan.metadata.master_slots : 1;
            const maxAddonSlots = Math.max(0, maxSlots - 1);
            const currentDeployed = typeof masterPlan?.metadata?.deployed_master_slots === 'number' ? masterPlan.metadata.deployed_master_slots : 0;
            if (maxAddonSlots <= 0 || currentDeployed >= maxAddonSlots) {
              return {
                success: false,
                error: 'No master slots left'
              };
            }
            const resolvedFleetId = rawFleetInput || matchedMaster.fleet_id || `FLT-${matchedMaster.id.slice(0, 8).toUpperCase()}`;
            return {
              success: true,
              masterUserId: matchedMaster.id,
              fleetId: resolvedFleetId
            };
          }
        }
      }

      return null;
    } catch (claimErr) {
      console.error('[MasterAccountService] claimMasterSlotByFleetId error:', claimErr);
      return null;
    }
  }
}