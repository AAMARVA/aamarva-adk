import crypto from 'crypto';
import { getSupabaseClient } from '../supabase';
import { ssrfSafeFetch, validateEndpointUrl } from './mcpService';

export interface WebhookSubscription {
  id: string;
  user_id: string;
  agent_id?: string;
  url: string;
  secret: string;
  events: string[];
  is_active: boolean;
  created_at: string;
}

export interface WebhookDelivery {
  id: string;
  subscription_id: string;
  subscription_url?: string;
  event_type: string;
  payload: any;
  status_code?: number;
  response_body?: string;
  success: boolean;
  error_message?: string;
  created_at: string;
}

const EVENT_MATCH_ALIASES: Record<string, string[]> = {
  CONNECTION_ACCEPTED_BY_TARGET: ['CONNECTION_ESTABLISHED'],
  CONNECTION_ESTABLISHED: ['CONNECTION_ACCEPTED_BY_TARGET'],
  DIRECT_ENCRYPTED_MESSAGE_RECEIVED: ['MESSAGE_RECEIVED'],
};

const CATEGORY_WILDCARDS: Record<string, string[]> = {
  'MESSAGE_*': [
    'MESSAGE_RECEIVED',
    'DIRECT_ENCRYPTED_MESSAGE_RECEIVED',
    'ATTACHMENT_RECEIVED',
  ],
  'CONNECTION_*': [
    'CONNECTION_REQUEST_RECEIVED',
    'CONNECTION_ACCEPTED_BY_TARGET',
    'CONNECTION_ESTABLISHED',
    'CONNECTION_REJECTED',
    'CONNECTION_DISSOLVED',
    'PEER_REVIEW_RECEIVED',
  ],
  'CLUSTER_*': [
    'CLUSTER_MESSAGE_RECEIVED',
    'CLUSTER_MEMBER_JOINED',
    'CLUSTER_MEMBER_LEFT',
    'CLUSTER_MEMBER_REMOVED',
    'CLUSTER_ROLE_UPDATED',
    'CLUSTER_DISBANDED',
    'CLUSTER_KEY_DISTRIBUTED',
    'CLUSTER_KEY_ROTATED',
  ],
  'TOOL_*': [
    'TOOL_APPROVED',
    'TOOL_DENIED',
  ],
  'CAPABILITY_*': [
    'SLAVE_CAPABILITY_ACTIVATED',
    'SLAVE_CAPABILITY_BATCH_ACTIVATED',
  ],
};

function isMissingTableError(error: any): boolean {
  if (!error) return false;
  const code = String(error.code || '');
  const msg = String(error.message || '').toLowerCase();
  return (
    code === '42P01' ||
    code === 'PGRST205' ||
    msg.includes('does not exist') ||
    msg.includes('could not find the table')
  );
}

export class WebhookDeliveryService {
  private static instance: WebhookDeliveryService;
  private recentDispatchKeys = new Map<string, number>();

  public static getInstance(): WebhookDeliveryService {
    if (!WebhookDeliveryService.instance) {
      WebhookDeliveryService.instance = new WebhookDeliveryService();
    }
    return WebhookDeliveryService.instance;
  }

  private normalizeEvents(events?: string[]): string[] {
    if (!Array.isArray(events) || events.length === 0) return ['*'];
    const cleaned = Array.from(
      new Set(
        events
          .map((e) => (typeof e === 'string' ? e.trim().toUpperCase() : ''))
          .filter(Boolean)
      )
    );
    if (cleaned.length === 0 || cleaned.includes('*')) return ['*'];
    return cleaned;
  }

  private parseEventsField(raw: any): string[] {
    if (Array.isArray(raw)) {
      return this.normalizeEvents(raw);
    }
    if (typeof raw === 'string') {
      try {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return this.normalizeEvents(parsed);
      } catch {
        // Ignore invalid JSON string
      }
    }
    return ['*'];
  }

  public async validateWebhookUrl(rawUrl: string): Promise<{ valid: boolean; normalizedUrl?: string; error?: string }> {
    if (!rawUrl || typeof rawUrl !== 'string') {
      return { valid: false, error: 'A valid HTTP/HTTPS webhook URL is required.' };
    }
    const trimmed = rawUrl.trim();
    if (trimmed.toLowerCase().startsWith('mock://') || trimmed.toLowerCase().includes('mock-mcp.internal')) {
      return { valid: false, error: 'Mock webhook URLs are not permitted.' };
    }
    const check = await validateEndpointUrl(trimmed, 'none', false);
    if (!check.valid) {
      return { valid: false, error: check.error || 'Webhook URL failed security validation.' };
    }
    return { valid: true, normalizedUrl: trimmed };
  }

  /**
   * Register a new outbound webhook subscription
   */
  public async createSubscription(
    userId: string,
    agentId: string | undefined,
    url: string,
    secret?: string,
    events: string[] = ['*']
  ): Promise<WebhookSubscription> {
    const urlCheck = await this.validateWebhookUrl(url);
    if (!urlCheck.valid || !urlCheck.normalizedUrl) {
      const err: any = new Error(urlCheck.error || 'Invalid webhook URL.');
      err.statusCode = 400;
      throw err;
    }

    const supabase = getSupabaseClient();
    const subId = `wh_sub_${crypto.randomUUID()}`;
    const generatedSecret = secret && secret.trim() ? secret.trim() : crypto.randomBytes(24).toString('hex');
    const normalizedEvents = this.normalizeEvents(events);
    const now = new Date().toISOString();

    const record: WebhookSubscription = {
      id: subId,
      user_id: userId,
      agent_id: agentId || undefined,
      url: urlCheck.normalizedUrl,
      secret: generatedSecret,
      events: normalizedEvents,
      is_active: true,
      created_at: now
    };

    const { error } = await supabase.from('webhook_subscriptions').insert({
      id: record.id,
      user_id: record.user_id,
      agent_id: record.agent_id || null,
      url: record.url,
      secret: record.secret,
      events: record.events,
      is_active: record.is_active,
      created_at: record.created_at
    });

    if (error) {
      if (isMissingTableError(error)) {
        const schemaErr: any = new Error(
          'Outbound webhook tables are not provisioned in Supabase. Execute supabase/migrations/add_outbound_webhooks.sql first.'
        );
        schemaErr.statusCode = 503;
        throw schemaErr;
      }
      throw new Error(error.message || 'Failed to persist outbound webhook subscription.');
    }

    return record;
  }

  /**
   * Get subscriptions for a user/agent (or multiple fleet user IDs)
   */
  public async getSubscriptions(userIds: string | string[]): Promise<WebhookSubscription[]> {
    const idList = Array.from(
      new Set((Array.isArray(userIds) ? userIds : [userIds]).filter((id): id is string => Boolean(id && typeof id === 'string')))
    );
    if (idList.length === 0) return [];

    const supabase = getSupabaseClient();
    const query = supabase
      .from('webhook_subscriptions')
      .select('*')
      .order('created_at', { ascending: false });

    const { data, error } = idList.length === 1
      ? await query.eq('user_id', idList[0])
      : await query.in('user_id', idList);

    if (error) {
      if (isMissingTableError(error)) {
        const schemaErr: any = new Error(
          'Outbound webhook tables are not provisioned in Supabase. Execute supabase/migrations/add_outbound_webhooks.sql first.'
        );
        schemaErr.statusCode = 503;
        throw schemaErr;
      }
      throw new Error(error.message || 'Failed to query webhook subscriptions.');
    }

    if (!data) return [];
    return data.map((row: any) => ({
      ...row,
      events: this.parseEventsField(row.events),
      is_active: row.is_active !== false
    }));
  }

  /**
   * Delete a subscription (verifying at least one owned row was deleted)
   */
  public async deleteSubscription(subId: string, userId: string): Promise<boolean> {
    const supabase = getSupabaseClient();
    const { data, error } = await supabase
      .from('webhook_subscriptions')
      .delete()
      .eq('id', subId)
      .eq('user_id', userId)
      .select('id');

    if (error) {
      if (isMissingTableError(error)) {
        const schemaErr: any = new Error(
          'Outbound webhook tables are not provisioned in Supabase. Execute supabase/migrations/add_outbound_webhooks.sql first.'
        );
        schemaErr.statusCode = 503;
        throw schemaErr;
      }
      throw new Error(error.message || 'Failed to delete webhook subscription.');
    }

    return Array.isArray(data) && data.length > 0;
  }

  private async resolveFleetOwnerIds(userIds: string | string[]): Promise<string[]> {
    const baseIds = Array.from(
      new Set((Array.isArray(userIds) ? userIds : [userIds]).filter((id): id is string => Boolean(id && typeof id === 'string')))
    );
    if (baseIds.length === 0) return [];

    const expanded = new Set<string>(baseIds);
    try {
      const supabase = getSupabaseClient();
      const { data } = await supabase
        .from('users')
        .select('id, master_id, is_master_primary')
        .in('id', baseIds);
      if (Array.isArray(data)) {
        for (const row of data) {
          if (row?.master_id && !row?.is_master_primary) {
            expanded.add(row.master_id);
          }
        }
      }
    } catch {
      // Best-effort master expansion
    }
    return Array.from(expanded);
  }

  private subscriptionMatchesEvent(subEvents: string[], canonicalEventType: string): boolean {
    if (!subEvents || subEvents.length === 0) return false;
    if (subEvents.includes('*')) return true;
    if (subEvents.includes(canonicalEventType)) return true;

    const aliases = EVENT_MATCH_ALIASES[canonicalEventType] || [];
    if (aliases.some((alias) => subEvents.includes(alias))) {
      return true;
    }

    for (const pattern of subEvents) {
      const catList = CATEGORY_WILDCARDS[pattern];
      if (catList) {
        if (catList.includes(canonicalEventType) || aliases.some((a) => catList.includes(a))) {
          return true;
        }
        continue;
      }
      if (pattern.endsWith('*')) {
        const prefix = pattern.slice(0, -1);
        if (prefix && canonicalEventType.startsWith(prefix)) {
          return true;
        }
      }
    }

    return false;
  }

  private markAndCheckDuplicate(dedupKey?: string): boolean {
    if (!dedupKey) return false;
    const now = Date.now();
    // Prune stale entries older than 60s
    if (this.recentDispatchKeys.size > 500) {
      for (const [k, ts] of this.recentDispatchKeys.entries()) {
        if (now - ts > 60_000) this.recentDispatchKeys.delete(k);
      }
    }
    const prev = this.recentDispatchKeys.get(dedupKey);
    if (prev !== undefined && now - prev < 60_000) {
      return true;
    }
    this.recentDispatchKeys.set(dedupKey, now);
    return false;
  }

  /**
   * Dispatch an event to all matching active outbound webhook subscriptions
   * (including the Master fleet owner when a Slave account performs an action).
   */
  public async dispatchEvent(
    userIds: string | string[],
    eventType: string,
    payload: any,
    dedupKey?: string
  ): Promise<void> {
    try {
      const canonicalEventType = String(eventType || 'EVENT').trim().toUpperCase();
      const targetUserIds = await this.resolveFleetOwnerIds(userIds);
      if (targetUserIds.length === 0) return;

      const subs = await this.getSubscriptions(targetUserIds);
      const activeSubs = subs.filter(
        (s) => s.is_active && this.subscriptionMatchesEvent(s.events, canonicalEventType)
      );
      if (activeSubs.length === 0) return;

      const eventBody = {
        id: `wh_evt_${crypto.randomUUID()}`,
        event: canonicalEventType,
        timestamp: new Date().toISOString(),
        data: payload
      };

      for (const sub of activeSubs) {
        if (this.markAndCheckDuplicate(dedupKey ? `${sub.id}:${canonicalEventType}:${dedupKey}` : undefined)) {
          continue;
        }
        this.deliverToSubscription(sub, canonicalEventType, eventBody).catch((err: any) => {
          console.warn('[WebhookDeliveryService] Delivery error:', err?.message || err);
        });
      }
    } catch (err: any) {
      console.warn('[WebhookDeliveryService] Event dispatch error:', err?.message || err);
    }
  }

  private async deliverToSubscription(
    sub: WebhookSubscription,
    eventType: string,
    eventBody: Record<string, any>
  ): Promise<{ deliveryId: string; success: boolean; statusCode?: number; error?: string }> {
    const deliveryId = `wh_del_${crypto.randomUUID()}`;
    const now = new Date().toISOString();
    const bodyStr = JSON.stringify(eventBody);
    const signature = crypto.createHmac('sha256', sub.secret).update(bodyStr).digest('hex');

    let statusCode: number | undefined;
    let responseBody: string | undefined;
    let success = false;
    let errorMessage: string | undefined;

    try {
      const urlCheck = await this.validateWebhookUrl(sub.url);
      if (!urlCheck.valid) {
        throw new Error(urlCheck.error || 'Webhook target blocked by SSRF policy.');
      }

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 8000);

      try {
        const res = await ssrfSafeFetch(sub.url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'User-Agent': 'Aamarva-Webhook-Dispatcher/1.0',
            'X-Aamarva-Event': eventType,
            'X-Aamarva-Delivery': deliveryId,
            'X-Aamarva-Signature': `sha256=${signature}`
          },
          body: bodyStr,
          signal: controller.signal
        });

        statusCode = res.status;
        responseBody = await res.text().catch(() => '');
        success = res.ok || (statusCode >= 200 && statusCode < 300);
        if (!success) {
          errorMessage = `HTTP status ${statusCode}`;
        }
      } finally {
        clearTimeout(timeoutId);
      }
    } catch (err: any) {
      success = false;
      errorMessage = err?.name === 'AbortError'
        ? 'Request timed out after 8000ms'
        : (err?.message || 'Network error');
    }

    // Record delivery attempt in webhook_deliveries
    try {
      const supabase = getSupabaseClient();
      const { error: insertErr } = await supabase.from('webhook_deliveries').insert({
        id: deliveryId,
        subscription_id: sub.id,
        event_type: eventType,
        payload: eventBody,
        status_code: statusCode || null,
        response_body: responseBody ? responseBody.slice(0, 1000) : null,
        success,
        error_message: errorMessage || null,
        created_at: now
      });
      if (insertErr) {
        console.warn('[WebhookDeliveryService] Failed to persist delivery log:', insertErr.message);
      }
    } catch (e: any) {
      console.warn('[WebhookDeliveryService] Exception persisting delivery log:', e?.message || e);
    }

    return { deliveryId, success, statusCode, error: errorMessage };
  }

  /**
   * Test dispatch a ping webhook and record the delivery attempt
   */
  public async testSubscription(
    subId: string,
    userId: string
  ): Promise<{ found: boolean; success: boolean; statusCode?: number; error?: string; deliveryId?: string }> {
    const subs = await this.getSubscriptions(userId);
    const sub = subs.find((s) => s.id === subId);
    if (!sub) {
      return { found: false, success: false, error: 'Subscription not found' };
    }

    const testBody = {
      id: `wh_test_${crypto.randomUUID()}`,
      event: 'PING_TEST',
      timestamp: new Date().toISOString(),
      data: { message: 'Aamarva outbound webhook test dispatch.' }
    };

    const result = await this.deliverToSubscription(sub, 'PING_TEST', testBody);
    return {
      found: true,
      success: result.success,
      statusCode: result.statusCode,
      error: result.error,
      deliveryId: result.deliveryId
    };
  }

  /**
   * Get recent delivery logs
   */
  public async getDeliveries(userId: string): Promise<WebhookDelivery[]> {
    const supabase = getSupabaseClient();
    const subs = await this.getSubscriptions(userId);
    const subIds = subs.map((s) => s.id);
    if (subIds.length === 0) return [];

    const { data, error } = await supabase
      .from('webhook_deliveries')
      .select('*')
      .in('subscription_id', subIds)
      .order('created_at', { ascending: false })
      .limit(50);

    if (error) {
      if (isMissingTableError(error)) {
        const schemaErr: any = new Error(
          'Outbound webhook tables are not provisioned in Supabase. Execute supabase/migrations/add_outbound_webhooks.sql first.'
        );
        schemaErr.statusCode = 503;
        throw schemaErr;
      }
      throw new Error(error.message || 'Failed to fetch webhook deliveries.');
    }

    const subUrlMap = new Map<string, string>(subs.map((s) => [s.id, s.url]));
    return (data || []).map((row: any) => ({
      ...row,
      subscription_url: subUrlMap.get(row.subscription_id) || undefined,
    }));
  }
}

export const webhookDeliveryService = WebhookDeliveryService.getInstance();
