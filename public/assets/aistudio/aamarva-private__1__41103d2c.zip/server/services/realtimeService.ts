import crypto from 'crypto';
import { Response } from 'express';
import EventEmitter from 'events';

export interface RealtimeStreamViewer {
  userId: string;
  agentId: string;
}

export interface RealtimeEvent {
  id: string;
  type: string;
  category: 'footprint' | 'event' | 'system';
  accountId: string; // The user_id of the account owning this notification
  actorId?: string; // agentId or userId of actor
  targetId?: string; // agentId or userId or entityId of target
  entityId?: string;
  endpoint?: string;
  details?: any;
  timestamp: string;
}

class RealtimeService extends EventEmitter {
  // Map of accountId (user_id) -> Set of active Express Response SSE streams
  private clients: Map<string, Set<Response>> = new Map();

  constructor() {
    super();
    this.setMaxListeners(200);
  }

  /**
   * Registers a client SSE connection for an authenticated account.
   */
  public registerClient(accountId: string, res: Response, agentId?: string) {
    const idsToRegister = new Set<string>();
    if (accountId && typeof accountId === 'string' && accountId.trim()) {
      const rawAcc = accountId.trim();
      const cleanAcc = rawAcc.replace(/^@+/, '');
      idsToRegister.add(rawAcc);
      idsToRegister.add(cleanAcc);
      idsToRegister.add(`@${cleanAcc}`);
      idsToRegister.add(cleanAcc.toLowerCase());
      idsToRegister.add(cleanAcc.toUpperCase());
    }
    if (agentId && typeof agentId === 'string' && agentId.trim()) {
      const rawAgent = agentId.trim();
      const cleanAgentId = rawAgent.replace(/^@+/, '');
      idsToRegister.add(rawAgent);
      idsToRegister.add(cleanAgentId);
      idsToRegister.add(`@${cleanAgentId}`);
      idsToRegister.add(cleanAgentId.toLowerCase());
      idsToRegister.add(cleanAgentId.toUpperCase());
    }

    for (const id of idsToRegister) {
      if (!this.clients.has(id)) {
        this.clients.set(id, new Set());
      }
      this.clients.get(id)!.add(res);
    }

    // Initial connection handshake
    const handshake: RealtimeEvent = {
      id: `rt_init_${Date.now()}`,
      type: 'STREAM_CONNECTED',
      category: 'system',
      accountId,
      details: { message: 'Realtime synchronized stream established.' },
      timestamp: new Date().toISOString()
    };
    this.sendToResponse(res, handshake);

    // Heartbeat every 15s to keep HTTP connection alive and prevent proxy timeouts
    const pingInterval = setInterval(() => {
      try {
        res.write(':ping\n\n');
      } catch (e) {
        clearInterval(pingInterval);
      }
    }, 15000);

    res.on('close', () => {
      clearInterval(pingInterval);
      this.recentDispatchedEvents.delete(res);
      for (const id of idsToRegister) {
        const userClients = this.clients.get(id);
        if (userClients) {
          userClients.delete(res);
          if (userClients.size === 0) {
            this.clients.delete(id);
          }
        }
      }
    });
  }

  // Prevent sending duplicate message events to the same SSE response stream
  private recentDispatchedEvents = new Map<Response, Set<string>>();

  /**
   * Broadcasts a real-time notification strictly to the authenticated account's active connections.
   */
  public notifyAccount(accountId: string, event: RealtimeEvent) {
    if (!accountId) return;

    // 1. Emit on internal EventEmitter for local subscribers/tests
    this.emit(`account:${accountId}`, event);
    this.emit('event', event);

    // 2. Deliver SSE to all active connections for this account across casing/formatting variants
    const rawAcc = String(accountId).trim();
    const cleanAcc = rawAcc.replace(/^@+/, '');
    const variants = [
      rawAcc,
      cleanAcc,
      `@${cleanAcc}`,
      cleanAcc.toLowerCase(),
      cleanAcc.toUpperCase(),
      `@${cleanAcc.toLowerCase()}`,
      `@${cleanAcc.toUpperCase()}`
    ];

    const targetClients = new Set<Response>();
    for (const v of variants) {
      const matched = this.clients.get(v);
      if (matched && matched.size > 0) {
        matched.forEach((res) => targetClients.add(res));
      }
    }

    targetClients.forEach((res) => {
      this.sendToResponse(res, event);
    });
  }

  private sendToResponse(res: Response, event: RealtimeEvent) {
    try {
      const msgId = event.details?.messageId || event.details?.id || (event.targetId && event.targetId.startsWith('msg_') ? event.targetId : null) || event.id;
      if (msgId) {
        let sentSet = this.recentDispatchedEvents.get(res);
        if (!sentSet) {
          sentSet = new Set();
          this.recentDispatchedEvents.set(res, sentSet);
        }
        const cleanMsgId = String(msgId).replace(/^evt_msg_/, '').replace(/^evt_clu_/, '').replace(/^evt_/, '');
        if (sentSet.has(cleanMsgId)) {
          return; // Duplicate event already dispatched to this SSE client
        }
        sentSet.add(cleanMsgId);
        setTimeout(() => {
          const current = this.recentDispatchedEvents.get(res);
          if (current) current.delete(cleanMsgId);
        }, 30000);
      }
      res.write(`id: ${event.id}\n`);
      res.write(`data: ${JSON.stringify(event)}\n\n`);
    } catch (e) {
      // client disconnected
    }
  }

  public getConnectedClientCount(accountId?: string): number {
    if (accountId) {
      return this.clients.get(accountId)?.size || 0;
    }
    let total = 0;
    this.clients.forEach((set) => {
      total += set.size;
    });
    return total;
  }

  private streamTickets = new Map<string, { viewer: RealtimeStreamViewer; expiresAt: number }>();

  public createStreamTicket(viewer: RealtimeStreamViewer): string {
    const now = Date.now();
    for (const [k, v] of this.streamTickets.entries()) {
      if (v.expiresAt <= now) this.streamTickets.delete(k);
    }
    const ticket = crypto.randomUUID();
    this.streamTickets.set(ticket, { viewer, expiresAt: now + 60_000 });
    return ticket;
  }

  public redeemStreamTicket(ticket: string): RealtimeStreamViewer | null {
    if (!ticket || typeof ticket !== 'string') return null;
    const clean = ticket.trim();
    const entry = this.streamTickets.get(clean);
    if (!entry) return null;
    this.streamTickets.delete(clean);
    if (Date.now() > entry.expiresAt) return null;
    return entry.viewer;
  }
}

export const realtimeService = new RealtimeService();
