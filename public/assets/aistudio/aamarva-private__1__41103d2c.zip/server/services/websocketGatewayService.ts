import { Server as HTTPServer } from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import { realtimeService, RealtimeEvent } from './realtimeService.js';
import { normalizeAgentId } from '../../src/lib/e2ee.js';
import { getSupabaseClient } from '../supabase.js';
import crypto from 'crypto';

export interface WSMessagePayload {
  type: string;
  id?: string;
  connectionId?: string;
  clusterId?: string;
  recipientAgentId?: string;
  recipientAgentIds?: string[];
  ciphertext?: string;
  nonce?: string;
  version?: number;
  keyEpoch?: number;
  sequence?: number;
  authId?: string;
  senderAgentId?: string;
}

class WebSocketGatewayService {
  private wss: WebSocketServer | null = null;
  private clients: Map<string, Set<WebSocket>> = new Map();

  public attach(server: HTTPServer): void {
    if (this.wss) return;

    this.wss = new WebSocketServer({ noServer: true });

    server.on('upgrade', (request, socket, head) => {
      const url = request.url || '';
      if (url.startsWith('/api/realtime/ws') || url.startsWith('/api/ws') || url.startsWith('/ws')) {
        this.wss!.handleUpgrade(request, socket, head, (ws) => {
          this.wss!.emit('connection', ws, request);
        });
      }
    });

    this.wss.on('connection', (ws: WebSocket, req) => {
      this.handleConnection(ws, req);
    });

    realtimeService.on('event', (event: RealtimeEvent) => {
      if (event && event.accountId) {
        this.notifyClient(event.accountId, event);
      }
    });

    console.log('[AAMARVA Realtime] Native Zero-Knowledge E2EE WebSocket Gateway attached.');
  }

  private handleConnection(ws: WebSocket, req: any): void {
    const urlParams = new URLSearchParams((req.url || '').split('?')[1] || '');
    const accountId = urlParams.get('accountId') || urlParams.get('userId') || 'anonymous';
    const agentId = urlParams.get('agentId') || '';

    const registeredIds = new Set<string>();
    if (accountId) registeredIds.add(accountId);
    if (agentId) {
      const norm = normalizeAgentId(agentId);
      registeredIds.add(agentId);
      if (norm) registeredIds.add(norm);
    }

    registeredIds.forEach((id) => {
      if (!this.clients.has(id)) {
        this.clients.set(id, new Set());
      }
      this.clients.get(id)!.add(ws);
    });

    this.sendToSocket(ws, {
      type: 'WS_CONNECTED',
      id: `ws_conn_${Date.now()}`,
      timestamp: new Date().toISOString(),
      details: {
        message: 'AAMARVA Zero-Knowledge E2EE WebSocket Session Active.',
        registeredIds: Array.from(registeredIds)
      }
    });

    ws.on('message', (data: any) => {
      try {
        const payload: WSMessagePayload = JSON.parse(String(data));
        this.handleSocketMessage(ws, payload, accountId, agentId);
      } catch {
        this.sendToSocket(ws, {
          type: 'ERROR',
          error: { code: 'MALFORMED_FRAME', message: 'Invalid JSON payload format.' }
        });
      }
    });

    ws.on('close', () => {
      registeredIds.forEach((id) => {
        const set = this.clients.get(id);
        if (set) {
          set.delete(ws);
          if (set.size === 0) this.clients.delete(id);
        }
      });
    });
  }

  private async handleSocketMessage(
    ws: WebSocket,
    payload: WSMessagePayload,
    senderAccountId: string,
    senderAgentId: string
  ): Promise<void> {
    const startTime = performance.now();

    if (payload.type === 'PING') {
      this.sendToSocket(ws, { type: 'PONG', timestamp: new Date().toISOString() });
      return;
    }

    if (payload.type === 'REGISTER_AGENT') {
      if (payload.senderAgentId) {
        const norm = normalizeAgentId(payload.senderAgentId);
        [payload.senderAgentId, norm].forEach((id) => {
          if (id) {
            if (!this.clients.has(id)) this.clients.set(id, new Set());
            this.clients.get(id)!.add(ws);
          }
        });
      }
      this.sendToSocket(ws, { type: 'REGISTER_ACK', agentId: payload.senderAgentId });
      return;
    }

    if (payload.type === 'SEND_CONNECTION_MESSAGE') {
      const { connectionId, ciphertext, nonce, version = 2, keyEpoch = 1, sequence, recipientAgentId } = payload;
      if (!connectionId || !ciphertext || !nonce) {
        this.sendToSocket(ws, {
          type: 'ERROR',
          error: { code: 'INVALID_PAYLOAD', message: 'Missing required connection message fields.' }
        });
        return;
      }

      const messageId = payload.id || `msg_${crypto.randomUUID()}`;
      const now = new Date().toISOString();

      const eventPayload: RealtimeEvent = {
        id: `rt_${messageId}`,
        type: 'MESSAGE_RECEIVED',
        category: 'event',
        accountId: senderAccountId,
        actorId: senderAgentId,
        targetId: recipientAgentId,
        entityId: messageId,
        details: {
          id: messageId,
          connectionId,
          ciphertext,
          nonce,
          version,
          keyEpoch,
          sequence: sequence !== undefined ? sequence : null,
          senderAgentId,
          createdAt: now
        },
        timestamp: now
      };

      // 1. Instant Memory Fan-out for UI Responsiveness
      if (recipientAgentId) {
        const normRec = normalizeAgentId(recipientAgentId);
        this.notifyClient(recipientAgentId, eventPayload);
        if (normRec) this.notifyClient(normRec, eventPayload);
      }
      this.notifyClient(senderAccountId, eventPayload);

      // 2. Durable Persistence (Rule 9: Never acknowledge durable acceptance before durable persistence)
      try {
        const supabase = getSupabaseClient();
        const { error: dbErr } = await supabase.from('connection_messages').insert({
          id: messageId,
          connection_id: connectionId,
          sender_agent_id: senderAgentId,
          ciphertext,
          nonce,
          version,
          key_epoch: keyEpoch,
          sequence: sequence !== undefined ? sequence : null,
          created_at: now
        });

        if (dbErr) {
          throw new Error(`Durable persistence failed: ${dbErr.message}`);
        }

        const durationMs = Number((performance.now() - startTime).toFixed(3));
        this.sendToSocket(ws, {
          type: 'MESSAGE_ACK',
          id: messageId,
          connectionId,
          durationMs,
          createdAt: now
        });
      } catch (persistErr: any) {
        this.sendToSocket(ws, {
          type: 'ERROR',
          error: { code: 'DURABLE_PERSISTENCE_FAILED', message: persistErr?.message || 'Failed to durably persist encrypted payload.' }
        });
      }
      return;
    }

    if (payload.type === 'SEND_CLUSTER_MESSAGE') {
      const { clusterId, ciphertext, nonce, version = 2, keyEpoch = 1, sequence, recipientAgentIds = [] } = payload;
      if (!clusterId || !ciphertext || !nonce) {
        this.sendToSocket(ws, {
          type: 'ERROR',
          error: { code: 'INVALID_PAYLOAD', message: 'Missing required cluster message fields.' }
        });
        return;
      }

      const messageId = payload.id || `msg_${crypto.randomUUID()}`;
      const now = new Date().toISOString();

      const eventPayload: RealtimeEvent = {
        id: `rt_clu_${messageId}`,
        type: 'CLUSTER_MESSAGE_RECEIVED',
        category: 'event',
        accountId: senderAccountId,
        actorId: senderAgentId,
        entityId: messageId,
        details: {
          id: messageId,
          clusterId,
          ciphertext,
          nonce,
          version,
          keyEpoch,
          sequence: sequence !== undefined ? sequence : null,
          senderAgentId,
          createdAt: now
        },
        timestamp: now
      };

      // 1. Instant Memory Fan-out for UI Responsiveness
      recipientAgentIds.forEach((rId) => {
        if (rId) {
          const normR = normalizeAgentId(rId);
          this.notifyClient(rId, eventPayload);
          if (normR) this.notifyClient(normR, eventPayload);
        }
      });
      this.notifyClient(senderAccountId, eventPayload);

      // 2. Durable Persistence (Rule 9)
      try {
        const supabase = getSupabaseClient();
        const { error: dbErr } = await supabase.from('cluster_messages').insert({
          id: messageId,
          cluster_id: clusterId,
          sender_agent_id: senderAgentId,
          ciphertext,
          nonce,
          version,
          key_epoch: keyEpoch,
          sequence: sequence !== undefined ? sequence : null,
          created_at: now
        });

        if (dbErr) {
          throw new Error(`Cluster durable persistence failed: ${dbErr.message}`);
        }

        const durationMs = Number((performance.now() - startTime).toFixed(3));
        this.sendToSocket(ws, {
          type: 'CLUSTER_MESSAGE_ACK',
          id: messageId,
          clusterId,
          durationMs,
          createdAt: now
        });
      } catch (persistErr: any) {
        this.sendToSocket(ws, {
          type: 'ERROR',
          error: { code: 'DURABLE_PERSISTENCE_FAILED', message: persistErr?.message || 'Failed to durably persist cluster encrypted payload.' }
        });
      }
      return;
    }
  }

  public notifyClient(targetId: string, data: any): void {
    if (!targetId) return;
    const socketSet = this.clients.get(targetId);
    if (socketSet && socketSet.size > 0) {
      socketSet.forEach((ws) => {
        this.sendToSocket(ws, data);
      });
    }
  }

  private sendToSocket(ws: WebSocket, payload: any): void {
    if (ws.readyState === WebSocket.OPEN) {
      try {
        ws.send(JSON.stringify(payload));
      } catch {}
    }
  }
}

export const websocketGatewayService = new WebSocketGatewayService();
