import crypto from 'crypto';
import { getSupabaseClient, ensureMessagesTable, isMissingRelationOrSchemaError } from '../supabase.js';
import { ConnectionRecord } from '../db.js';
import { findUserById, getCachedAuthUserById, registerExternalAuthCacheInvalidator } from '../authService.js';

import { SecurityService } from './securityService.js';
import { watchtowerActivityService } from './watchtowerActivityService.js';

const RESOLVED_USER_CACHE_TTL_MS = 60_000;
const resolvedUserCache = new Map<string, { user: any; ts: number }>();
const inFlightResolvedUser = new Map<string, Promise<any>>();

const ACTIVE_CONN_CACHE_TTL_MS = 120_000;
const activeConnectionCache = new Map<string, { conn: ConnectionRecord; ts: number }>();
const candidateConnIdsCache = new Map<string, { ids: string[]; ts: number }>();

export function invalidateConnectionCache(connectionId?: string): void {
  if (!connectionId) {
    activeConnectionCache.clear();
    candidateConnIdsCache.clear();
    return;
  }
  const keyLower = connectionId.toLowerCase();
  for (const [k, v] of activeConnectionCache.entries()) {
    if (k.toLowerCase() === keyLower || v.conn?.id?.toLowerCase() === keyLower) {
      activeConnectionCache.delete(k);
    }
  }
  for (const [k, v] of candidateConnIdsCache.entries()) {
    if (k.toLowerCase() === keyLower || v.ids.some((id) => id.toLowerCase() === keyLower)) {
      candidateConnIdsCache.delete(k);
    }
  }
}

registerExternalAuthCacheInvalidator((userId?: string) => {
  if (!userId) {
    resolvedUserCache.clear();
    inFlightResolvedUser.clear();
    activeConnectionCache.clear();
    candidateConnIdsCache.clear();
    return;
  }
  const lowerTarget = userId.toLowerCase();
  for (const [k, entry] of resolvedUserCache.entries()) {
    if (k === lowerTarget || entry.user?.id === userId || entry.user?.agentId?.toLowerCase() === lowerTarget) {
      resolvedUserCache.delete(k);
    }
  }
  inFlightResolvedUser.delete(lowerTarget);
});

export class ConnectionError extends Error {
  statusCode: number;
  code: string;

  constructor(message: string, statusCode = 400, code = 'CONNECTION_ERROR') {
    super(message);
    this.name = 'ConnectionError';
    this.statusCode = statusCode;
    this.code = code;
    Object.setPrototypeOf(this, ConnectionError.prototype);
  }
}

export class ConnectionConflictError extends ConnectionError {
  constructor(message: string, code = 'CONNECTION_CONFLICT') {
    super(message, 409, code);
    this.name = 'ConnectionConflictError';
  }
}

export class ConnectionNotFoundError extends ConnectionError {
  constructor(message: string, code = 'CONNECTION_NOT_FOUND') {
    super(message, 404, code);
    this.name = 'ConnectionNotFoundError';
  }
}

export class ConnectionForbiddenError extends ConnectionError {
  constructor(message: string, code = 'FORBIDDEN') {
    super(message, 403, code);
    this.name = 'ConnectionForbiddenError';
  }
}

export class ConnectionCapabilityError extends ConnectionError {
  constructor(message = 'Failed to establish connection: Required database transactional procedure is unavailable.', code = 'DATABASE_CAPABILITY_UNAVAILABLE') {
    super(message, 503, code);
    this.name = 'ConnectionCapabilityError';
  }
}

export function isSlaveAccount(u: any): boolean {
  if (!u) return false;
  if (u.is_master_primary === true || u.isMasterPrimary === true) return false;
  if (u.account_type === 'master' || u.account_type === 'master_slot' || u.is_master_slot === true || u.isMasterSlot === true) return false;

  // Explicit slave identifiers
  if (
    u.account_type === 'slave' ||
    u.role === 'slave' ||
    u.is_slave === true ||
    u.isSlave === true ||
    (typeof u.email === 'string' && u.email.toLowerCase().includes('+amr-')) ||
    (u.owner_email && u.owner_email !== u.email)
  ) {
    return true;
  }

  if (
    (u.master_id && u.id && String(u.master_id).toLowerCase() !== String(u.id).toLowerCase()) ||
    (u.masterUserId && u.id && String(u.masterUserId).toLowerCase() !== String(u.id).toLowerCase())
  ) {
    return true;
  }
  return false;
}

export async function resolveUserRecord(identifier: string): Promise<any> {
  if (!identifier) return null;
  const clean = identifier.replace(/^@+/, '').trim();
  if (!clean) return null;
  const lower = clean.toLowerCase();

  const now = Date.now();
  const cached = resolvedUserCache.get(lower);
  if (cached && (now - cached.ts) < RESOLVED_USER_CACHE_TTL_MS) {
    return cached.user;
  }

  const existingFlight = inFlightResolvedUser.get(lower);
  if (existingFlight) {
    return existingFlight;
  }

  const lookupPromise = (async () => {
    const safeClean = clean.replace(/"/g, '\\"');
    const safeLower = lower.replace(/"/g, '\\"');
    const supabase = getSupabaseClient();

    const cacheMatch = (u: any) => {
      if (!u) return null;
      if (resolvedUserCache.size > 2000) resolvedUserCache.clear();
      const ts = Date.now();
      resolvedUserCache.set(lower, { user: u, ts });
      if (u.id) resolvedUserCache.set(String(u.id).toLowerCase(), { user: u, ts });
      if (u.agentId) resolvedUserCache.set(String(u.agentId).toLowerCase(), { user: u, ts });
      return u;
    };

    const { data: primaryMatches } = await supabase
      .from('users')
      .select('*')
      .or(`id.eq."${safeClean}",id.eq."${safeLower}",agentId.ilike."${safeClean}"`)
      .limit(1);

    if (Array.isArray(primaryMatches) && primaryMatches.length > 0 && primaryMatches[0]) {
      return cacheMatch(primaryMatches[0]);
    }

    // Targeted fallback queries (avoid unbounded full-table scan)
    const [byIdRes, byAgentRes] = await Promise.all([
      supabase.from('users').select('*').eq('id', clean).limit(1),
      supabase.from('users').select('*').ilike('agentId', clean).limit(1),
    ]);
    if (Array.isArray(byIdRes.data) && byIdRes.data[0]) return cacheMatch(byIdRes.data[0]);
    if (Array.isArray(byAgentRes.data) && byAgentRes.data[0]) return cacheMatch(byAgentRes.data[0]);

    if (lower !== clean) {
      const { data: lowerMatches } = await supabase.from('users').select('*').eq('id', lower).limit(1);
      if (Array.isArray(lowerMatches) && lowerMatches[0]) return cacheMatch(lowerMatches[0]);
    }
    return null;
  })().finally(() => {
    inFlightResolvedUser.delete(lower);
  });

  inFlightResolvedUser.set(lower, lookupPromise);
  return lookupPromise;
}

const inFlightPairEstablishLocks = new Map<string, Promise<ConnectionRecord | null>>();

function splitCompositeConnectionParts(rawClean: string): Array<[string, string]> {
  const parts = rawClean.split('_');
  if (parts.length < 2) return [];
  if (parts.length === 2) {
    const a = parts[0].trim();
    const b = parts[1].trim();
    return a && b ? [[a, b]] : [];
  }
  const candidates: Array<[string, string]> = [];
  for (let i = 1; i < parts.length; i++) {
    const a = parts.slice(0, i).join('_').trim();
    const b = parts.slice(i).join('_').trim();
    if (!a || !b) continue;
    if (a.toLowerCase() === 'usr' || b.toLowerCase() === 'usr' || a.toLowerCase() === 'fleet' || b.toLowerCase() === 'fleet') {
      continue;
    }
    candidates.push([a, b]);
  }
  if (candidates.length === 0) {
    const a = parts[0].trim();
    const b = parts.slice(1).join('_').trim();
    if (a && b) candidates.push([a, b]);
  }
  return candidates;
}

export function buildPairCompositeConnectionAliases(
  u1Id?: string | null,
  u2Id?: string | null,
  u1AgentId?: string | null,
  u2AgentId?: string | null,
  extraAliases?: string[]
): string[] {
  const set = new Set<string>();
  const addAlias = (val?: string | null) => {
    if (!val || typeof val !== 'string') return;
    const trimmed = val.trim();
    if (!trimmed) return;
    set.add(trimmed);
    set.add(trimmed.toLowerCase());
  };

  if (Array.isArray(extraAliases)) {
    extraAliases.forEach(addAlias);
  }

  const u1Variants = Array.from(new Set([u1Id, u1Id?.toLowerCase(), u1AgentId, u1AgentId?.replace(/^@+/, ''), u1AgentId?.replace(/^@+/, '').toLowerCase(), u1AgentId?.replace(/^@+/, '').toUpperCase()].filter((x): x is string => Boolean(x && x.trim()))));
  const u2Variants = Array.from(new Set([u2Id, u2Id?.toLowerCase(), u2AgentId, u2AgentId?.replace(/^@+/, ''), u2AgentId?.replace(/^@+/, '').toLowerCase(), u2AgentId?.replace(/^@+/, '').toUpperCase()].filter((x): x is string => Boolean(x && x.trim()))));

  for (const a of u1Variants) {
    for (const b of u2Variants) {
      if (a.toLowerCase() === b.toLowerCase()) continue;
      set.add(`conn_${a}_${b}`);
      set.add(`conn_${b}_${a}`);
      set.add(`fleet_conn_${a}_${b}`);
      set.add(`fleet_conn_${b}_${a}`);
    }
  }

  return Array.from(set);
}

export async function findConnectionRowsForPair(
  supabase: any,
  userAId: string,
  userBId: string
): Promise<ConnectionRecord[]> {
  if (!userAId || !userBId) return [];
  const orClause = `and(user1_id.eq.${userAId},user2_id.eq.${userBId}),and(user1_id.eq.${userBId},user2_id.eq.${userAId})`;
  let { data: rows, error } = await supabase
    .from('connections')
    .select('*')
    .or(orClause)
    .order('createdAt', { ascending: true });

  if (error && (error.message?.includes('user1_id') || error.message?.includes('does not exist'))) {
    const fallbackClause = `and(postOwnerUserId.eq.${userAId},replyAuthorUserId.eq.${userBId}),and(postOwnerUserId.eq.${userBId},replyAuthorUserId.eq.${userAId})`;
    const fallbackRes = await supabase
      .from('connections')
      .select('*')
      .or(fallbackClause)
      .order('createdAt', { ascending: true });
    rows = fallbackRes.data;
    error = fallbackRes.error;
  }

  if (error || !Array.isArray(rows)) return [];

  return [...rows].sort((a: any, b: any) => {
    const tA = new Date(a.createdAt || a.created_at || 0).getTime();
    const tB = new Date(b.createdAt || b.created_at || 0).getTime();
    if (tA !== tB) return tA - tB;
    return String(a.id || '').localeCompare(String(b.id || ''));
  });
}

function pickCanonicalPairConnection(rows: ConnectionRecord[], preferredId?: string): ConnectionRecord | null {
  if (!rows || rows.length === 0) return null;
  const activeRows = rows.filter((r) => r && r.status !== 'dissolved');
  if (activeRows.length > 0) {
    if (preferredId) {
      const exactPreferred = activeRows.find((r) => r.id === preferredId);
      if (exactPreferred) return exactPreferred;
    }
    return activeRows[0];
  }
  return rows[0];
}

export async function establishDirectConnection(
  userAIdentifier: string,
  userBIdentifier: string,
  preferredConnectionId?: string
): Promise<ConnectionRecord | null> {
  if (!userAIdentifier || !userBIdentifier) return null;
  const supabase = getSupabaseClient();

  // Resolve both users by ID or agentId with case-insensitivity
  const [uA, uB] = await Promise.all([
    resolveUserRecord(userAIdentifier),
    resolveUserRecord(userBIdentifier),
  ]);

  if (!uA || !uB || uA.id === uB.id) return null;

  if (isSlaveAccount(uA) && isSlaveAccount(uB)) {
    throw new ConnectionForbiddenError(
      'Forbidden: Slave-to-slave connection is strictly prohibited.',
      'SLAVE_TO_SLAVE_CONNECTION_FORBIDDEN'
    );
  }

  const pairLockKey = [String(uA.id).toLowerCase(), String(uB.id).toLowerCase()].sort().join('::');
  const existingInFlight = inFlightPairEstablishLocks.get(pairLockKey);
  if (existingInFlight) {
    return existingInFlight;
  }

  const runEstablish = async (): Promise<ConnectionRecord | null> => {
    // Check if one or more connections already exist in the database (never .maybeSingle() on pair query)
    const pairRows = await findConnectionRowsForPair(supabase, uA.id, uB.id);
    const existing = pickCanonicalPairConnection(pairRows, preferredConnectionId);

    if (existing) {
      if (existing.status === 'dissolved') {
        const { data: reactivated } = await supabase
          .from('connections')
          .update({ status: 'active' })
          .eq('id', existing.id)
          .select()
          .maybeSingle();
        if (reactivated) {
          invalidateConnectionCache(existing.id);
          try {
            const peerDisplay = (uB.agentId || uB.name || 'peer').replace(/^@+/, '');
            watchtowerActivityService.recordWatchtowerActivity({
              agentId: uA.agentId || uA.id,
              agentName: uA.name || uA.agentId || 'Agent',
              avatar: uA.avatar || '🤖',
              emailVerified: Boolean(uA.emailVerified),
              text: `re-established connection with @${peerDisplay}`,
              type: 'connection',
              peerName: peerDisplay,
              peerAgentId: uB.agentId,
              peerUserId: uB.id,
              actorUserId: uA.id,
              masterId: (uA.master_id && !uA.is_master_primary) ? uA.master_id : uA.id,
              peerMasterId: (uB.master_id && !uB.is_master_primary) ? uB.master_id : uB.id,
              entityId: existing.id,
              activityKey: `conn_reactivated:${existing.id}`
            }).catch(console.warn);
          } catch {}
          return reactivated as ConnectionRecord;
        }
      }
      return existing as ConnectionRecord;
    }

    // Create and persist a canonical database connection row (WhatsApp-style: established on first contact)
    const chosenConnId = preferredConnectionId && (preferredConnectionId.startsWith('conn_') || preferredConnectionId.startsWith('fleet_conn_'))
      ? preferredConnectionId
      : `conn_${crypto.randomUUID()}`;

    const newConn: ConnectionRecord = {
      id: chosenConnId,
      user1_id: uA.id,
      user1_agent_id: uA.agentId,
      user1_agent_name: uA.name || uA.agentId,
      user2_id: uB.id,
      user2_agent_id: uB.agentId,
      user2_agent_name: uB.name || uB.agentId,
      status: 'active',
      createdAt: new Date().toISOString(),
    };

    const { data: inserted, error: insErr } = await supabase
      .from('connections')
      .insert(newConn)
      .select()
      .maybeSingle();

    if (insErr) {
      // If insert raced or hit conflict, re-check pair rows before failing
      const retryRows = await findConnectionRowsForPair(supabase, uA.id, uB.id);
      const retryExisting = pickCanonicalPairConnection(retryRows, chosenConnId);
      if (retryExisting) return retryExisting;
      console.error('[establishDirectConnection] Database insert error:', insErr);
      return null;
    }

    const finalRecord = (inserted || newConn) as ConnectionRecord;
    invalidateConnectionCache(finalRecord.id);

    try {
      const peerDisplay = (uB.agentId || uB.name || 'peer').replace(/^@+/, '');
      watchtowerActivityService.recordWatchtowerActivity({
        id: `wt_conn_${finalRecord.id}`,
        agentId: uA.agentId || uA.id,
        agentName: uA.name || uA.agentId || 'Agent',
        avatar: uA.avatar || '🤖',
        emailVerified: Boolean(uA.emailVerified),
        text: `@${uA.agentId || uA.name} connected with peer @${peerDisplay}`,
        type: 'CONNECTED',
        category: 'connection',
        outcome: 'success',
        peerName: peerDisplay,
        peerAgentId: uB.agentId,
        peerUserId: uB.id,
        actorUserId: uA.id,
        masterId: (uA.master_id && !uA.is_master_primary) ? uA.master_id : uA.id,
        peerMasterId: (uB.master_id && !uB.is_master_primary) ? uB.master_id : uB.id,
        entityId: finalRecord.id,
        activityKey: `conn_est:${finalRecord.id}`
      }).catch(console.warn);

      try {
        const { logExternalEvent } = await import('./auditService');
        await logExternalEvent(
          uB.id,
          'CONNECTION_ACCEPTED_BY_TARGET',
          uA.agentId || uA.id,
          finalRecord.id,
          {
            connection_id: finalRecord.id,
            peer_agent_id: uA.agentId,
            peer_name: uA.name,
            peer_user_id: uA.id
          }
        );
      } catch {}
    } catch {}

    return finalRecord;
  };

  const promise = runEstablish().finally(() => {
    inFlightPairEstablishLocks.delete(pairLockKey);
  });
  inFlightPairEstablishLocks.set(pairLockKey, promise);
  return promise;
}

export async function getConnectionRecord(connectionId: string): Promise<ConnectionRecord | null> {
  if (!connectionId) return null;
  const nowTs = Date.now();
  const cached = activeConnectionCache.get(connectionId);
  if (cached && nowTs - cached.ts < ACTIVE_CONN_CACHE_TTL_MS) {
    return cached.conn;
  }

  const supabase = getSupabaseClient();
  const { data: existing } = await supabase
    .from('connections')
    .select('*')
    .eq('id', connectionId)
    .maybeSingle();

  if (existing) {
    const u1Id = existing.user1_id || (existing as any).postOwnerUserId;
    const u2Id = existing.user2_id || (existing as any).replyAuthorUserId;
    if (u1Id && u2Id) {
      const [u1, u2] = await Promise.all([
        findUserById(supabase, u1Id),
        findUserById(supabase, u2Id),
      ]);
      const resolvedU1 = u1 || (await resolveUserRecord(u1Id));
      const resolvedU2 = u2 || (await resolveUserRecord(u2Id));
      if (isSlaveAccount(resolvedU1) && isSlaveAccount(resolvedU2)) {
        if (existing.status !== 'dissolved') {
          await supabase.from('connections').update({ status: 'dissolved' }).eq('id', existing.id);
        }
        invalidateConnectionCache(existing.id);
        return null;
      }
    }
    const connObj = existing as ConnectionRecord;
    if (connObj.status !== 'dissolved') {
      activeConnectionCache.set(connectionId, { conn: connObj, ts: Date.now() });
      if (connObj.id && connObj.id !== connectionId) {
        activeConnectionCache.set(connObj.id, { conn: connObj, ts: Date.now() });
      }
    }
    return connObj;
  }

  if (connectionId.startsWith('fleet_conn_') || connectionId.startsWith('conn_')) {
    const clean = connectionId.replace(/^(fleet_conn_|conn_)/, '');
    const splitCandidates = splitCompositeConnectionParts(clean);
    for (const [userA, userB] of splitCandidates) {
      const [uA, uB] = await Promise.all([
        resolveUserRecord(userA),
        resolveUserRecord(userB),
      ]);

      if (uA && uB && uA.id !== uB.id) {
        if (isSlaveAccount(uA) && isSlaveAccount(uB)) {
          return null;
        }

        const pairRows = await findConnectionRowsForPair(supabase, uA.id, uB.id);
        const conn = pickCanonicalPairConnection(pairRows, connectionId);

        if (conn) {
          if (conn.status === 'dissolved') {
            const { data: reactivated } = await supabase
              .from('connections')
              .update({ status: 'active' })
              .eq('id', conn.id)
              .select()
              .maybeSingle();
            const activeConn = (reactivated || conn) as ConnectionRecord;
            invalidateConnectionCache(activeConn.id);
            activeConnectionCache.set(connectionId, { conn: activeConn, ts: Date.now() });
            return activeConn;
          }
          const activeConn = conn as ConnectionRecord;
          activeConnectionCache.set(connectionId, { conn: activeConn, ts: Date.now() });
          if (activeConn.id && activeConn.id !== connectionId) {
            activeConnectionCache.set(activeConn.id, { conn: activeConn, ts: Date.now() });
          }
          return activeConn;
        }

        // WhatsApp-style: establish real persistent database record if both users exist
        const direct = await establishDirectConnection(uA.id, uB.id, connectionId);
        if (direct) {
          activeConnectionCache.set(connectionId, { conn: direct, ts: Date.now() });
          return direct;
        }
      }
    }
  }
  return null;
}

export async function sanitizeExistingSlaveConnections(): Promise<number> {
  try {
    const supabase = getSupabaseClient();
    const { data: allConns, error } = await supabase
      .from('connections')
      .select('*')
      .neq('status', 'dissolved');
    if (error || !allConns || allConns.length === 0) return 0;

    const userIds = new Set<string>();
    allConns.forEach((c: any) => {
      const u1 = c.user1_id || (c as any).postOwnerUserId;
      const u2 = c.user2_id || (c as any).replyAuthorUserId;
      if (u1) userIds.add(u1);
      if (u2) userIds.add(u2);
    });

    if (userIds.size === 0) return 0;
    const { data: users } = await supabase
      .from('users')
      .select('id, agentId, account_type, role, is_slave, is_master_primary, master_id')
      .in('id', Array.from(userIds));

    if (!users) return 0;
    const userMap = new Map<string, any>(users.map(u => [u.id, u]));

    let dissolvedCount = 0;
    for (const c of allConns) {
      const u1 = userMap.get(c.user1_id || (c as any).postOwnerUserId);
      const u2 = userMap.get(c.user2_id || (c as any).replyAuthorUserId);
      if (u1 && u2 && isSlaveAccount(u1) && isSlaveAccount(u2)) {
        await supabase.from('connections').update({ status: 'dissolved' }).eq('id', c.id);
        dissolvedCount++;
      }
    }
    return dissolvedCount;
  } catch (err: any) {
    console.warn('[sanitizeExistingSlaveConnections] Notice:', err?.message);
    return 0;
  }
}

export async function ensureConnectionRecord(
  connectionId: string,
  currentUserId?: string,
  options?: {
    receiverAgentId?: string;
    receiverUserId?: string;
  }
): Promise<ConnectionRecord | null> {
  if (!connectionId) return null;

  // 1. Direct or composite resolution via getConnectionRecord
  const existing = await getConnectionRecord(connectionId);
  if (existing) return existing;

  // 2. Direct receiver provided
  if (currentUserId && (options?.receiverUserId || options?.receiverAgentId)) {
    const target = (options.receiverUserId || options.receiverAgentId)!.trim();
    if (target && !target.startsWith('conn_') && !target.startsWith('fleet_conn_')) {
      const [uA, uB] = await Promise.all([
        resolveUserRecord(currentUserId),
        resolveUserRecord(target)
      ]);
      if (uA && uB && isSlaveAccount(uA) && isSlaveAccount(uB)) {
        return null;
      }
      return await establishDirectConnection(currentUserId, target, connectionId);
    }
  }

  // 3. Fallback: if connectionId is not a composite ID (i.e. it is an agentId or userId directly)
  if (!connectionId.startsWith('conn_') && !connectionId.startsWith('fleet_conn_') && currentUserId) {
    const [uA, uB] = await Promise.all([
      resolveUserRecord(currentUserId),
      resolveUserRecord(connectionId)
    ]);
    if (uA && uB && isSlaveAccount(uA) && isSlaveAccount(uB)) {
      return null;
    }
    return await establishDirectConnection(currentUserId, connectionId);
  }

  return null;
}

export async function createConnection(userId1: string, userId2: string) {
  const supabase = getSupabaseClient();

  const [u1Res, u2Res] = await Promise.all([
    supabase.from('users').select('*').eq('id', userId1).maybeSingle(),
    supabase.from('users').select('*').eq('id', userId2).maybeSingle()
  ]);

  if (isSlaveAccount(u1Res.data) && isSlaveAccount(u2Res.data)) {
    try {
      const u1 = u1Res.data;
      const u2 = u2Res.data;
      const peerDisplay = (u2?.agentId || u2?.name || 'peer').replace(/^@+/, '');
      watchtowerActivityService.recordWatchtowerActivity({
        agentId: u1?.agentId || u1?.id,
        agentName: u1?.name || u1?.agentId || 'Agent',
        avatar: u1?.avatar || '🤖',
        emailVerified: Boolean(u1?.emailVerified),
        text: `attempted connection with peer @${peerDisplay} [BLOCKED: 403 Forbidden - Slave-to-slave links prohibited]`,
        type: 'SLAVE_TO_SLAVE_CONNECTION_BLOCKED',
        category: 'security',
        outcome: 'failed',
        status: 'BLOCKED',
        peerName: peerDisplay,
        peerAgentId: u2?.agentId,
        peerUserId: u2?.id,
        actorUserId: u1?.id,
        masterId: (u1?.master_id && !u1?.is_master_primary) ? u1.master_id : u1?.id,
        peerMasterId: (u2?.master_id && !u2?.is_master_primary) ? u2.master_id : u2?.id,
        activityKey: `block_s2s:${userId1}:${userId2}:${Math.floor(Date.now() / 10000)}`
      }).catch(console.warn);
    } catch {}

    throw new ConnectionForbiddenError(
      'Forbidden: Slave-to-slave connection is strictly prohibited.',
      'SLAVE_TO_SLAVE_CONNECTION_FORBIDDEN'
    );
  }

  // Check for existing connections between these users (avoid .maybeSingle() PGRST116 on duplicate rows)
  const existingPairRows = await findConnectionRowsForPair(supabase, userId1, userId2);
  const existingConnection = pickCanonicalPairConnection(existingPairRows);

  if (existingConnection && existingConnection.status !== 'dissolved') return existingConnection;
  if (existingConnection && existingConnection.status === 'dissolved') {
    const { data: reactivated } = await supabase
      .from('connections')
      .update({ status: 'active' })
      .eq('id', existingConnection.id)
      .select()
      .maybeSingle();
    if (reactivated) {
      invalidateConnectionCache(existingConnection.id);
      return reactivated;
    }
  }

  const u1 = u1Res.data;
  const u2 = u2Res.data;

  // Create new connection
  const { data: newConnection, error } = await supabase
    .from('connections')
    .insert({
      id: 'conn_' + crypto.randomUUID(),
      user1_id: userId1,
      user1_agent_id: u1?.agentId || '',
      user1_agent_name: u1?.name || u1?.agentId || 'Agent',
      user2_id: userId2,
      user2_agent_id: u2?.agentId || '',
      user2_agent_name: u2?.name || u2?.agentId || 'Agent',
      status: 'active',
      createdAt: new Date().toISOString()
    })
    .select()
    .single();

  if (error) throw error;
  invalidateConnectionCache(newConnection?.id);
  return newConnection;
}





export async function getUserConnections(userId: string, page: number, limit: number) {
  const supabase = getSupabaseClient();

  // Find user profile
  const currentUser = await findUserById(supabase, userId);

  if (!currentUser) {
    throw new ConnectionNotFoundError('User profile not found.', 'USER_NOT_FOUND');
  }

  // Resolve root Pioneer Master ID (walk up master_id up to 5 hops, plus entitlement fallback)
  let callerMasterId = currentUser.master_id && !currentUser.is_master_primary ? currentUser.master_id : currentUser.id;
  if (!currentUser.master_id && currentUser.is_master_primary !== true && currentUser.email) {
    try {
      const callerEmail = String(currentUser.email).toLowerCase().trim();
      const { data: activeEnts } = await supabase
        .from('master_plan_entitlements')
        .select('master_account_id, metadata')
        .eq('status', 'active')
        .eq('plan_type', 'master_slave_scale');
      if (activeEnts && activeEnts.length > 0) {
        const emailMatchedEnt = activeEnts.find((e: any) => {
          const meta = e.metadata || {};
          const invs = Array.isArray(meta.fleet_slot_invitations) ? meta.fleet_slot_invitations : [];
          const regEmails = Array.isArray(meta.registered_emails) ? meta.registered_emails.map((str: string) => str.toLowerCase().trim()) : [];
          return invs.some((inv: any) => inv.claimed_by_user_id === currentUser.id || String(inv.email || '').toLowerCase().trim() === callerEmail) ||
                 regEmails.includes(callerEmail);
        });
        if (emailMatchedEnt?.master_account_id) {
          callerMasterId = emailMatchedEnt.master_account_id;
        }
      }
    } catch {}
  }

  for (let depth = 0; depth < 5; depth++) {
    const uRec = await findUserById(supabase, callerMasterId);
    if (uRec?.master_id && uRec.master_id !== callerMasterId && uRec.is_master_primary !== true) {
      callerMasterId = uRec.master_id;
    } else {
      break;
    }
  }

  // 1. Fetch Root Master user, sibling Master Slots, and all Slave accounts across the fleet
  const [masterRes, directChildrenRes] = await Promise.all([
    supabase
      .from('users')
      .select('id, agentId, name, avatar, emailVerified, master_id, is_master_primary, account_type, role, is_slave, is_master_slot, fleet_id')
      .eq('id', callerMasterId)
      .maybeSingle(),
    supabase
      .from('users')
      .select('id, agentId, name, avatar, emailVerified, master_id, is_master_primary, account_type, role, is_slave, is_master_slot, fleet_id')
      .or(`master_id.eq.${callerMasterId},master_id.eq.${currentUser.id}`)
  ]);

  const masterUser = masterRes.data;
  const directChildren = directChildrenRes.data || [];

  const fleetOrConditions: string[] = [
    `id.eq.${callerMasterId}`,
    `master_id.eq.${callerMasterId}`,
    `master_id.eq.${currentUser.id}`,
  ];
  for (const child of directChildren) {
    if (child?.id) fleetOrConditions.push(`master_id.eq.${child.id}`);
  }
  const fleetIdsToMatch = new Set<string>();
  if (currentUser.fleet_id) fleetIdsToMatch.add(String(currentUser.fleet_id).trim());
  if (masterUser?.fleet_id) fleetIdsToMatch.add(String(masterUser.fleet_id).trim());
  for (const fid of fleetIdsToMatch) {
    if (fid) fleetOrConditions.push(`fleet_id.ilike.${fid}`);
  }

  let expandedFleetUsers: any[] = [];
  try {
    const { data: expanded } = await supabase
      .from('users')
      .select('id, agentId, name, avatar, emailVerified, master_id, is_master_primary, account_type, role, is_slave, is_master_slot, fleet_id')
      .or(Array.from(new Set(fleetOrConditions)).join(','));
    if (Array.isArray(expanded)) expandedFleetUsers = expanded;
  } catch {}

  const allFleetUsers: any[] = [];
  const seenFleetIds = new Set<string>();
  for (const u of [masterUser, ...directChildren, ...expandedFleetUsers]) {
    if (u?.id && !seenFleetIds.has(u.id)) {
      seenFleetIds.add(u.id);
      allFleetUsers.push(u);
    }
  }

  const fleetUsers = allFleetUsers.filter((u: any) => u.id !== currentUser.id);
  const fleetUserIds = new Set(allFleetUsers.map((u: any) => u.id));
  const fleetAgentIds = new Set(allFleetUsers.map((u: any) => (u.agentId || '').toUpperCase()).filter(Boolean));

  // 2. Fetch existing connections from database
  const userAgentIdUpper = (currentUser.agentId || '').toUpperCase();
  const orFilter = `user1_id.eq.${currentUser.id},user2_id.eq.${currentUser.id},user1_agent_id.ilike.${userAgentIdUpper},user2_agent_id.ilike.${userAgentIdUpper}`;

  let { data: userConnections, error: queryError } = await supabase
    .from('connections')
    .select('*')
    .or(orFilter)
    .neq('status', 'dissolved');

  if (queryError && (queryError.message.includes('user1_id') || queryError.message.includes('does not exist'))) {
    const fallbackOrFilter = `postOwnerUserId.eq.${currentUser.id},replyAuthorUserId.eq.${currentUser.id},postOwnerAgentId.ilike.${userAgentIdUpper},replyAuthorAgentId.ilike.${userAgentIdUpper}`;
    const fallbackRes = await supabase
      .from('connections')
      .select('*')
      .or(fallbackOrFilter)
      .neq('status', 'dissolved');
    userConnections = fallbackRes.data;
    queryError = fallbackRes.error;
  }

  if (queryError) {
    throw new ConnectionError(`Failed to retrieve user connections: ${queryError.message}`, 500, 'DATABASE_ERROR');
  }

  const rawConnections = userConnections || [];

  // 3. Filter existing connections to STRICTLY exclude cross-fleet accounts
  const intraFleetConnections = rawConnections.filter((c: any) => {
    const u1Id = c.user1_id || c.postOwnerUserId;
    const u2Id = c.user2_id || c.replyAuthorUserId;
    const a1 = (c.user1_agent_id || c.postOwnerAgentId || '').toUpperCase();
    const a2 = (c.user2_agent_id || c.replyAuthorAgentId || '').toUpperCase();

    const isU1Me = u1Id === currentUser.id || (a1 && userAgentIdUpper && a1 === userAgentIdUpper);
    const peerUserId = isU1Me ? u2Id : u1Id;
    const peerAgentId = isU1Me ? a2 : a1;

    return (fleetUserIds.has(peerUserId) || fleetAgentIds.has(peerAgentId)) && peerUserId !== currentUser.id;
  });

  // Collect unique peer user IDs/agent IDs already connected
  const connectedPeerIds = new Set<string>();
  intraFleetConnections.forEach((c: any) => {
    const u1Id = c.user1_id || c.postOwnerUserId;
    const u2Id = c.user2_id || c.replyAuthorUserId;
    const peerUserId = u1Id === currentUser.id ? u2Id : u1Id;
    if (peerUserId) connectedPeerIds.add(peerUserId);
    if (c.user1_agent_id) connectedPeerIds.add(c.user1_agent_id.toUpperCase());
    if (c.user2_agent_id) connectedPeerIds.add(c.user2_agent_id.toUpperCase());
    if (c.postOwnerAgentId) connectedPeerIds.add(c.postOwnerAgentId.toUpperCase());
    if (c.replyAuthorAgentId) connectedPeerIds.add(c.replyAuthorAgentId.toUpperCase());
  });

  // 4. Ensure all fleet accounts (master and slave accounts in the fleet) are included as talk targets under connections
  const unmappedFleetUsers = fleetUsers.filter(
    (fUser: any) => !connectedPeerIds.has(fUser.id) && !connectedPeerIds.has((fUser.agentId || '').toUpperCase())
  );
  const additionalFleetConnections = (
    await Promise.all(
      unmappedFleetUsers.map(async (fUser: any) => {
        const isSlave = Boolean(
          fUser.account_type === 'slave' ||
          fUser.role === 'slave' ||
          fUser.is_slave === true ||
          (fUser.master_id && fUser.master_id === callerMasterId && !fUser.is_master_primary && !fUser.is_master_slot && fUser.account_type !== 'master_slot')
        );
        const isMaster = !isSlave;
        const fleetConnId = `fleet_conn_${currentUser.id}_${fUser.id}`;

        // Confirmed database records only. Use canonical existingConn.id rather than transient fleetConnId.
        const existingConn = await getConnectionRecord(fleetConnId);
        if (!existingConn) return null;
        return {
          ...existingConn,
          id: existingConn.id,
          user1_id: existingConn.user1_id || currentUser.id,
          user1_agent_id: existingConn.user1_agent_id || currentUser.agentId,
          user1_agent_name: existingConn.user1_agent_name || currentUser.name || currentUser.agentId,
          user2_id: existingConn.user2_id || fUser.id,
          user2_agent_id: existingConn.user2_agent_id || fUser.agentId,
          user2_agent_name: existingConn.user2_agent_name || fUser.name || fUser.agentId,
          status: existingConn.status || 'active',
          isSlave,
          isMaster,
          createdAt: existingConn.createdAt || new Date().toISOString(),
        };
      })
    )
  ).filter(Boolean);

  // Deduplicate/consolidate connections per peer pair while tracking ALL sibling/alias connectionIds
  const rawAllConnections = [...intraFleetConnections, ...additionalFleetConnections].sort((a: any, b: any) => {
    const tA = new Date(a.createdAt || a.created_at || 0).getTime();
    const tB = new Date(b.createdAt || b.created_at || 0).getTime();
    if (tA !== tB) return tA - tB;
    return String(a.id || '').localeCompare(String(b.id || ''));
  });

  const peerConsolidatedMap = new Map<string, any>();
  for (const c of rawAllConnections) {
    const u1Id = c.user1_id || c.postOwnerUserId;
    const u2Id = c.user2_id || c.replyAuthorUserId;
    const a1 = (c.user1_agent_id || c.postOwnerAgentId || '').toUpperCase();
    const a2 = (c.user2_agent_id || c.replyAuthorAgentId || '').toUpperCase();
    const isU1Me = u1Id === currentUser.id || (a1 && a1 === userAgentIdUpper);
    const peerUid = isU1Me ? u2Id : u1Id;
    const peerAid = isU1Me ? a2 : a1;
    const peerKey = String(peerUid || peerAid || c.id).toLowerCase();

    const pairAliases = buildPairCompositeConnectionAliases(u1Id, u2Id, a1, a2, [c.id]);
    const existingEntry = peerConsolidatedMap.get(peerKey);
    if (!existingEntry) {
      peerConsolidatedMap.set(peerKey, {
        ...c,
        allConnectionIds: Array.from(new Set(pairAliases)),
      });
    } else {
      const mergedIds = new Set<string>([
        ...(existingEntry.allConnectionIds || [existingEntry.id]),
        ...pairAliases,
      ]);
      existingEntry.allConnectionIds = Array.from(mergedIds);
    }
  }

  const allConnections = Array.from(peerConsolidatedMap.values());

  // Filter to show only accounts where either they or I sent some messages ever (across any sibling/alias ID)
  const aliasToCanonId = new Map<string, string>();
  const allCandidateConnIds: string[] = [];
  for (const c of allConnections) {
    const idsForConn: string[] = Array.isArray(c.allConnectionIds) ? c.allConnectionIds : [c.id];
    for (const cid of idsForConn) {
      if (!cid) continue;
      aliasToCanonId.set(cid, c.id);
      aliasToCanonId.set(cid.toLowerCase(), c.id);
      allCandidateConnIds.push(cid);
    }
  }

  const activeConnIdsWithMessages = new Set<string>();
  if (allCandidateConnIds.length > 0) {
    try {
      const uniqueIds = Array.from(new Set(allCandidateConnIds));
      const BATCH_SIZE = 10;
      const batches: string[][] = [];
      for (let i = 0; i < uniqueIds.length; i += BATCH_SIZE) {
        batches.push(uniqueIds.slice(i, i + BATCH_SIZE));
      }
      const PAGE_SIZE = 1000;
      await Promise.all(
        batches.map(async (batch) => {
          const expectedCanonIds = new Set(
            batch.map((cid) => aliasToCanonId.get(cid) || aliasToCanonId.get(String(cid).toLowerCase()) || cid)
          );
          for (let pageIdx = 0; pageIdx < 20; pageIdx++) {
            const from = pageIdx * PAGE_SIZE;
            const { data: msgs, error: msgBatchErr } = await supabase
              .from('messages')
              .select('connectionId')
              .in('connectionId', batch)
              .order('createdAt', { ascending: false })
              .range(from, from + PAGE_SIZE - 1);
            if (msgBatchErr) {
              console.warn('[getUserConnections] messages batch query warning:', msgBatchErr.message);
              break;
            }
            if (!msgs || msgs.length === 0) break;
            msgs.forEach((m: any) => {
              if (m.connectionId) {
                const canonId =
                  aliasToCanonId.get(m.connectionId) ||
                  aliasToCanonId.get(String(m.connectionId).toLowerCase()) ||
                  m.connectionId;
                activeConnIdsWithMessages.add(canonId);
              }
            });
            const allResolvedInBatch = Array.from(expectedCanonIds).every((cid) => activeConnIdsWithMessages.has(cid));
            if (msgs.length < PAGE_SIZE || allResolvedInBatch) {
              break;
            }
          }
        })
      );
    } catch (e) {}
  }

  const messageFilteredConnections = allConnections.filter((c: any) => activeConnIdsWithMessages.has(c.id));
  const total = messageFilteredConnections.length;

  // Pagination slice
  const paginatedConnections = messageFilteredConnections.slice((page - 1) * limit, page * limit);

  // Fetch unique agent IDs for avatars/keys
  const agentIds = new Set<string>();
  paginatedConnections.forEach((c: any) => {
    const a1 = c.user1_agent_id || c.postOwnerAgentId;
    const a2 = c.user2_agent_id || c.replyAuthorAgentId;
    if (a1) agentIds.add(a1);
    if (a2) agentIds.add(a2);
  });

  let users: any[] = [];
  if (agentIds.size > 0) {
    const { data: userData } = await supabase
      .from('users')
      .select('id, agentId, name, avatar, emailVerified, master_id, is_master_primary, account_type, role, is_slave, is_master_slot')
      .in('agentId', Array.from(agentIds));
    users = userData || [];

    await Promise.all(
      users.map(async (u) => {
        if (u.id === userId || u.e2eePublicKey) return;
        try {
          const authUser = await getCachedAuthUserById(supabase, u.id);
          u.e2eePublicKey = authUser?.user_metadata?.e2eePublicKey || null;
        } catch {}
      })
    );
  }

  const normalizeCleanId = (id: string) => (id || '').toString().trim().replace(/^@+/, '').toUpperCase();

  const mappedConnections = paginatedConnections.map((c: any) => {
    const u1Id = c.user1_id || c.postOwnerUserId;
    const u2Id = c.user2_id || c.replyAuthorUserId;
    const a1 = c.user1_agent_id || c.postOwnerAgentId;
    const a2 = c.user2_agent_id || c.replyAuthorAgentId;
    const name1 = c.user1_agent_name || c.postOwnerAgentName;
    const name2 = c.user2_agent_name || c.replyAuthorAgentName;

    const normA1 = normalizeCleanId(a1);
    const normA2 = normalizeCleanId(a2);

    const user1Obj = users.find(u => normalizeCleanId(u.agentId) === normA1) ||
      allFleetUsers.find(u => u.id === u1Id || normalizeCleanId(u.agentId) === normA1);
    const user2Obj = users.find(u => normalizeCleanId(u.agentId) === normA2) ||
      allFleetUsers.find(u => u.id === u2Id || normalizeCleanId(u.agentId) === normA2);

    const isUser1 = u1Id === userId || (a1 && normA1 === userAgentIdUpper);
    const peerUser = isUser1 ? user2Obj : user1Obj;
    const peerName = isUser1
      ? (name2 || user2Obj?.name || a2 || 'Associated Agent')
      : (name1 || user1Obj?.name || a1 || 'Associated Agent');
      
    const peerAgentId = isUser1 ? a2 : a1;
    const peerAvatar = isUser1 ? (user2Obj?.avatar || '🤖') : (user1Obj?.avatar || '🤖');
    const peerUserId = isUser1 ? (u2Id || user2Obj?.id) : (u1Id || user1Obj?.id);
    const peerE2eePublicKey = isUser1 ? user2Obj?.e2eePublicKey : user1Obj?.e2eePublicKey;
    const peerEmailVerified = isUser1 
      ? Boolean(user2Obj?.emailVerified === true)
      : Boolean(user1Obj?.emailVerified === true);
    const peerStatus = peerEmailVerified ? 'verified' : 'not verified';

    const isPeerMaster = peerUser ? Boolean(
      peerUser.id === callerMasterId ||
      peerUser.is_master_primary === true ||
      peerUser.is_master_slot === true ||
      peerUser.account_type === 'master_slot' ||
      peerUser.account_type === 'master' ||
      (peerUser.role === 'master' && !peerUser.is_slave && peerUser.account_type !== 'slave')
    ) : Boolean(c.isMaster && !c.isSlave);

    const isPeerSlave = peerUser ? Boolean(
      !isPeerMaster && (
        peerUser.account_type === 'slave' ||
        peerUser.role === 'slave' ||
        peerUser.is_slave === true ||
        (peerUser.master_id && peerUser.master_id !== peerUser.id)
      )
    ) : Boolean(c.isSlave || !isPeerMaster);

    return {
      id: c.id,
      allConnectionIds: c.allConnectionIds || [c.id],
      user1_id: u1Id,
      user1_agent_id: a1,
      user1_agent_name: name1,
      user2_id: u2Id,
      user2_agent_id: a2,
      user2_agent_name: name2,
      agentName: peerName,
      agentId: peerAgentId,
      peerE2eePublicKey,
      verificationStatus: peerStatus,
      verification_status: peerStatus,
      ["verification status"]: peerStatus,
      avatar: peerAvatar,
      emailVerified: peerEmailVerified,
      isHost: isUser1,
      isMaster: isPeerMaster,
      isSlave: isPeerSlave,
      status: c.status || 'active',
      connectionStatus: c.status || 'active',
      createdAt: c.createdAt,
    };
  });

  return {
    connections: mappedConnections,
    total,
    page,
    limit,
  };
}

export const MAX_DECODED_CIPHERTEXT_BYTES = 102400; // 100 KiB raw decoded ciphertext
export const MAX_BASE64_CIPHERTEXT_LENGTH = 136536; // Math.ceil(102400 / 3) * 4 Base64 transport characters
export const MAX_MESSAGE_CONTENT_LENGTH = MAX_BASE64_CIPHERTEXT_LENGTH;

export interface MessagePayload {
  content?: string;
  message?: string;
  ciphertext?: string;
  nonce?: string;
  signature?: string;
  version?: number;
  keyEpoch?: number;
  sequence?: number;
  seq?: number;
}

// Helper: strict Base64 validation
function isValidBase64(str: string): boolean {
  if (!str || typeof str !== 'string') return false;
  const trimmed = str.trim();
  if (trimmed.length === 0) return false;
  const base64Regex = /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/;
  const urlSafeRegex = /^(?:[A-Za-z0-9_-]{4})*(?:[A-Za-z0-9_-]{2}==|[A-Za-z0-9_-]{3}=)?$/;
  return base64Regex.test(trimmed) || urlSafeRegex.test(trimmed);
}

export async function sendMessage(
  connectionId: string,
  userId: string,
  payload: MessagePayload,
  contextCredentials?: string[],
  preResolved?: {
    connection?: any;
    currentUser?: any;
    senderAuthUser?: any;
    recipientAuthUser?: any;
  }
) {
  let { content, message, ciphertext, nonce, version, keyEpoch } = payload || {};

  if ((content !== undefined && content !== null) || (message !== undefined && message !== null)) {
    throw new ConnectionError(
      'Plaintext content is strictly forbidden for private messages. AAMARVA is zero-knowledge; encryption must be performed agent-side. Remove "content" or "message" fields and provide E2EE ciphertext envelope.',
      400,
      'PLAINTEXT_REJECTED'
    );
  }

  if (ciphertext === undefined || ciphertext === null || typeof ciphertext !== 'string') {
    throw new ConnectionError(
      'Private messages must include a valid E2EE encrypted envelope: { "ciphertext": "...", "nonce": "...", "version": 1, "keyEpoch": 1 }.',
      400,
      'MISSING_CIPHERTEXT'
    );
  }

  ciphertext = ciphertext.trim();
  if (ciphertext.length === 0) {
    throw new ConnectionError(
      'Ciphertext cannot be empty.',
      400,
      'EMPTY_CIPHERTEXT'
    );
  }

  if (!isValidBase64(ciphertext)) {
    throw new ConnectionError(
      'Invalid ciphertext transport encoding. Base64-encoded ciphertext required.',
      400,
      'INVALID_CIPHERTEXT_ENCODING'
    );
  }

  try {
    const cipherBuf = Buffer.from(ciphertext, 'base64');
    if (cipherBuf.length === 0) {
      throw new ConnectionError(
        'Decoded ciphertext bytes cannot be empty.',
        400,
        'EMPTY_CIPHERTEXT'
      );
    }
  } catch (e: any) {
    if (e instanceof ConnectionError) throw e;
    throw new ConnectionError(
      'Invalid ciphertext transport encoding. Base64-encoded ciphertext required.',
      400,
      'INVALID_CIPHERTEXT_ENCODING'
    );
  }

  if (nonce === undefined || nonce === null || typeof nonce !== 'string') {
    throw new ConnectionError(
      'Private messages must include a valid Base64-encoded nonce.',
      400,
      'INVALID_NONCE'
    );
  }

  nonce = nonce.trim();
  if (nonce.length === 0 || !isValidBase64(nonce)) {
    throw new ConnectionError(
      'Invalid nonce encoding. Base64-encoded initialization vector required.',
      400,
      'INVALID_NONCE'
    );
  }

  try {
    const nonceBuf = Buffer.from(nonce, 'base64');
    if (nonceBuf.length !== 12) {
      throw new ConnectionError(
        'Invalid nonce. AES-256-GCM requires a valid 96-bit (12-byte) initialization vector.',
        400,
        'INVALID_NONCE'
      );
    }
  } catch (e: any) {
    if (e instanceof ConnectionError) throw e;
    throw new ConnectionError(
      'Invalid nonce encoding. Base64-encoded initialization vector required.',
      400,
      'INVALID_NONCE'
    );
  }

  if (payload.version !== undefined && payload.version !== null) {
    if (typeof payload.version !== 'number' || !Number.isFinite(payload.version) || !Number.isInteger(payload.version) || payload.version !== 1) {
      throw new ConnectionError(
        'Unsupported E2EE protocol version. Only version 1 is supported.',
        400,
        'UNSUPPORTED_VERSION'
      );
    }
  }

  if (payload.keyEpoch !== undefined && payload.keyEpoch !== null) {
    if (typeof payload.keyEpoch !== 'number' || !Number.isFinite(payload.keyEpoch) || !Number.isInteger(payload.keyEpoch) || payload.keyEpoch < 1) {
      throw new ConnectionError(
        'Invalid keyEpoch. When supplied, keyEpoch must be a positive integer (>= 1). Malformed, non-numeric, decimal, or negative values are rejected.',
        400,
        'INVALID_KEY_EPOCH'
      );
    }
  }

  version = 1;
  keyEpoch = typeof keyEpoch === 'number' && Number.isInteger(keyEpoch) && keyEpoch >= 1 ? keyEpoch : 1;

  if (ciphertext.length > MAX_BASE64_CIPHERTEXT_LENGTH) {
    throw new ConnectionError(
      `Ciphertext exceeds maximum allowed payload size (100 KiB / 102,400 bytes).`,
      400,
      'PAYLOAD_TOO_LARGE'
    );
  }

  try {
    const cipherBuf = Buffer.from(ciphertext, 'base64');
    if (cipherBuf.length > MAX_DECODED_CIPHERTEXT_BYTES) {
      throw new ConnectionError(
        `Decoded ciphertext bytes exceed maximum allowed payload size (100 KiB / 102,400 bytes).`,
        400,
        'PAYLOAD_TOO_LARGE'
      );
    }
  } catch (err) {
    if (err instanceof ConnectionError) throw err;
    // Malformed base64 will fail downstream or in route validation
  }

  const supabase = getSupabaseClient();
  const connection = preResolved?.connection || (await getConnectionRecord(connectionId));
  if (!connection) {
    throw new ConnectionNotFoundError('Connection not found.', 'CONNECTION_NOT_FOUND');
  }

  // Find user
  let currentUser = preResolved?.currentUser;
  if (!currentUser) {
    const userRow = await findUserById(supabase, userId);

    if (!userRow) {
      throw new ConnectionNotFoundError('User profile not found.', 'USER_NOT_FOUND');
    }
    currentUser = userRow;
  }

  const user1 = connection.user1_id || (connection as any).postOwnerUserId;
  const user2 = connection.user2_id || (connection as any).replyAuthorUserId;

  const currentIdLower = currentUser.id.toLowerCase();
  const u1Lower = (user1 || '').toLowerCase();
  const u2Lower = (user2 || '').toLowerCase();

  if (currentIdLower !== u1Lower && currentIdLower !== u2Lower) {
    throw new ConnectionForbiddenError('Forbidden: Not a participant of this connection.', 'FORBIDDEN');
  }

  if (connection.status === 'dissolved') {
    throw new ConnectionForbiddenError('Forbidden: This connection has been dissolved and cannot be messaged.', 'CONNECTION_DISSOLVED');
  }

  const recipientUserId = u1Lower === currentIdLower ? user2 : user1;

  // 1. Strict Server-Side E2EE Public Key Enforcement: Sender MUST have a registered E2EE public key
  let senderMeta: Record<string, any> = {};
  let recipientMeta: Record<string, any> = {};

  try {
    if (preResolved?.senderAuthUser?.user_metadata?.e2eePublicKey) {
      senderMeta = preResolved.senderAuthUser.user_metadata;
      if (preResolved.recipientAuthUser?.user_metadata?.e2eePublicKey || !recipientUserId) {
        recipientMeta = preResolved.recipientAuthUser?.user_metadata || {};
      } else {
        const recipientDbUser = await findUserById(supabase, recipientUserId);
        if (recipientDbUser?.e2eePublicKey) {
          recipientMeta = {
            e2eePublicKey: recipientDbUser.e2eePublicKey,
            e2eeKeyEpoch: recipientDbUser.e2eeKeyEpoch || 1,
            e2eeEpochHistory: recipientDbUser.e2eeEpochHistory || {},
          };
        } else {
          const recipientAuthUser = await getCachedAuthUserById(supabase, recipientUserId);
          recipientMeta = recipientAuthUser?.user_metadata || {};
        }
      }
    } else {
      const [senderDbUser, recipientDbUser] = await Promise.all([
        findUserById(supabase, currentUser.id),
        recipientUserId ? findUserById(supabase, recipientUserId) : Promise.resolve(null)
      ]);

      const [senderAuthUser, recipientAuthUser] = await Promise.all([
        senderDbUser?.e2eePublicKey ? Promise.resolve(null) : getCachedAuthUserById(supabase, currentUser.id),
        (!recipientUserId || recipientDbUser?.e2eePublicKey) ? Promise.resolve(null) : getCachedAuthUserById(supabase, recipientUserId)
      ]);

      senderMeta = senderAuthUser?.user_metadata || {};
      recipientMeta = recipientAuthUser?.user_metadata || {};

      if (senderDbUser?.e2eePublicKey && (!senderMeta.e2eePublicKey || Number(senderDbUser.e2eeKeyEpoch || 1) >= Number(senderMeta.e2eeKeyEpoch || 1))) {
        senderMeta = {
          ...senderMeta,
          e2eePublicKey: senderDbUser.e2eePublicKey,
          e2eeKeyEpoch: senderDbUser.e2eeKeyEpoch || 1,
          e2eeEpochHistory: senderDbUser.e2eeEpochHistory || senderMeta.e2eeEpochHistory || {},
        };
      }

      if (recipientUserId && recipientDbUser?.e2eePublicKey && (!recipientMeta.e2eePublicKey || Number(recipientDbUser.e2eeKeyEpoch || 1) >= Number(recipientMeta.e2eeKeyEpoch || 1))) {
        recipientMeta = {
          ...recipientMeta,
          e2eePublicKey: recipientDbUser.e2eePublicKey,
          e2eeKeyEpoch: recipientDbUser.e2eeKeyEpoch || 1,
          e2eeEpochHistory: recipientDbUser.e2eeEpochHistory || recipientMeta.e2eeEpochHistory || {},
        };
      }
    }
  } catch (lookupErr: any) {
    if (lookupErr instanceof ConnectionError) throw lookupErr;
    throw new ConnectionForbiddenError(
      'Register an E2EE public key via PUT /api/agents/me/e2ee before sending private messages.',
      'E2EE_KEY_REQUIRED'
    );
  }

  const senderPublicKey = senderMeta.e2eePublicKey;
  if (!senderPublicKey || typeof senderPublicKey !== 'string' || senderPublicKey.trim().length === 0) {
    throw new ConnectionForbiddenError(
      'Register an E2EE public key via PUT /api/agents/me/e2ee before sending private messages.',
      'E2EE_KEY_REQUIRED'
    );
  }

  // Cryptographic structural validation of sender's registered public key JWK
  try {
    const parsedKey = typeof senderPublicKey === 'string' ? JSON.parse(senderPublicKey) : senderPublicKey;
    if (!parsedKey || parsedKey.kty !== 'EC' || parsedKey.crv !== 'P-256' || !parsedKey.x || !parsedKey.y) {
      throw new ConnectionForbiddenError(
        'Register an E2EE public key via PUT /api/agents/me/e2ee before sending private messages.',
        'E2EE_KEY_REQUIRED'
      );
    }
  } catch (jwkErr: any) {
    if (jwkErr instanceof ConnectionError) throw jwkErr;
    throw new ConnectionForbiddenError(
      'Register an E2EE public key via PUT /api/agents/me/e2ee before sending private messages.',
      'E2EE_KEY_REQUIRED'
    );
  }

  // 2. Strict keyEpoch validation against registered activeKeyEpoch and exact epoch history (no numeric range fallback)
  const senderActiveEpoch = typeof senderMeta.e2eeKeyEpoch === 'number' ? senderMeta.e2eeKeyEpoch : 1;
  const senderEpochHistory = (senderMeta.e2eeEpochHistory as Record<string, any>) || {};
  const senderHasEpoch = Boolean(
    keyEpoch === senderActiveEpoch ||
    (senderEpochHistory[String(keyEpoch)] && senderEpochHistory[String(keyEpoch)].publicKey)
  );

  let recipientHasEpoch = false;
  if (recipientUserId) {
    const recipientActiveEpoch = typeof recipientMeta.e2eeKeyEpoch === 'number' ? recipientMeta.e2eeKeyEpoch : 1;
    const recipientEpochHistory = (recipientMeta.e2eeEpochHistory as Record<string, any>) || {};
    recipientHasEpoch = Boolean(
      (recipientMeta.e2eePublicKey && keyEpoch === recipientActiveEpoch) ||
      (recipientEpochHistory[String(keyEpoch)] && recipientEpochHistory[String(keyEpoch)].publicKey)
    );
  }

  if (!senderHasEpoch && !recipientHasEpoch) {
    throw new ConnectionError(
      `Invalid keyEpoch ${keyEpoch}. Key epoch ${keyEpoch} not found in registered active key or epoch history for connection participants.`,
      400,
      'KEY_EPOCH_NOT_FOUND'
    );
  }

  const now = new Date().toISOString();
  const msgId = `msg_${crypto.randomUUID()}`;

  const rawSeq = payload.sequence ?? payload.seq;
  const parsedSequence = typeof rawSeq === 'number' && Number.isFinite(rawSeq) && Number.isInteger(rawSeq) && rawSeq >= 0 ? rawSeq : null;

  // Store message record with strictly sanitized content and payload
  const messageRecord: Record<string, any> = {
    id: msgId,
    connectionId: connection.id,
    senderUserId: currentUser.id,
    senderAgentId: currentUser.agentId,
    content: null,
    ciphertext: ciphertext,
    nonce: nonce,
    version,
    keyEpoch,
    sequence: parsedSequence,
    createdAt: now,
  };

  let { error: insertError } = await supabase
    .from('messages')
    .insert([messageRecord]);

  if (insertError && isMissingRelationOrSchemaError(insertError)) {
    const recovered = await ensureMessagesTable(supabase, true);
    if (recovered) {
      const retryRes = await supabase.from('messages').insert([messageRecord]);
      insertError = retryRes.error;
    }
  }

  if (insertError) {
    throw new ConnectionError(`Database error sending encrypted message: ${insertError.message}`, 500, 'DATABASE_ERROR');
  }

  return {
    id: msgId,
    connectionId: connection.id,
    senderUserId: currentUser.id,
    senderAgentId: currentUser.agentId,
    content: null,
    ciphertext: ciphertext,
    nonce: nonce,
    version,
    keyEpoch,
    sequence: parsedSequence,
    createdAt: now,
  };
}

export async function getAllCandidateConnectionIdsForConnection(
  supabase: any,
  connection: ConnectionRecord,
  connectionId?: string,
  extraAliases?: string[]
): Promise<string[]> {
  const cacheKey = `${connection.id || ''}::${connectionId || ''}::${(extraAliases || []).join(',')}`;
  const nowTs = Date.now();
  const cached = candidateConnIdsCache.get(cacheKey);
  if (cached && nowTs - cached.ts < ACTIVE_CONN_CACHE_TTL_MS) {
    return cached.ids;
  }

  const u1 = connection.user1_id || (connection as any).postOwnerUserId;
  const u2 = connection.user2_id || (connection as any).replyAuthorUserId;
  const u1Agent = connection.user1_agent_id || (connection as any).postOwnerAgentId;
  const u2Agent = connection.user2_agent_id || (connection as any).replyAuthorAgentId;

  const candidateIds = new Set<string>(
    [connection.id, connectionId, ...(extraAliases || [])].filter((id): id is string => Boolean(id && typeof id === 'string' && id.trim()))
  );

  if (u1 && u2) {
    try {
      const siblingRows = await findConnectionRowsForPair(supabase, u1, u2);
      for (const row of siblingRows) {
        if (row && row.id && row.status !== 'dissolved') {
          candidateIds.add(row.id);
        }
      }
    } catch {}
  }

  const aliases = buildPairCompositeConnectionAliases(u1, u2, u1Agent, u2Agent, extraAliases);
  for (const a of aliases) {
    candidateIds.add(a);
  }

  const resolved = Array.from(candidateIds);
  candidateConnIdsCache.set(cacheKey, { ids: resolved, ts: Date.now() });
  return resolved;
}

export async function getConnectionMessages(
  connectionId: string,
  userId: string,
  options?: {
    receiverAgentId?: string;
    receiverUserId?: string;
    aliasConnectionIds?: string[];
    preResolvedConnection?: ConnectionRecord;
    since?: string;
  }
) {
  const supabase = getSupabaseClient();
  const connection = options?.preResolvedConnection || (await getConnectionRecord(connectionId));
  if (!connection) {
    throw new ConnectionNotFoundError('Connection not found.', 'CONNECTION_NOT_FOUND');
  }

  // Verify participant access
  const u1 = connection.user1_id || (connection as any).postOwnerUserId;
  const u2 = connection.user2_id || (connection as any).replyAuthorUserId;
  const u1Agent = connection.user1_agent_id || (connection as any).postOwnerAgentId;
  const u2Agent = connection.user2_agent_id || (connection as any).replyAuthorAgentId;

  const u1Lower = (u1 || '').toLowerCase();
  const u2Lower = (u2 || '').toLowerCase();
  const userIdLower = (userId || '').toLowerCase();

  let isParticipant = (Boolean(u1Lower) && u1Lower === userIdLower) || (Boolean(u2Lower) && u2Lower === userIdLower);
  if (!isParticipant) {
    const { data: currentUser } = await supabase
      .from('users')
      .select('agentId')
      .eq('id', userId)
      .maybeSingle();

    const currentAgentId = currentUser?.agentId;
    isParticipant = Boolean(
      currentAgentId && (
        (u1Agent && u1Agent.toLowerCase() === currentAgentId.toLowerCase()) ||
        (u2Agent && u2Agent.toLowerCase() === currentAgentId.toLowerCase())
      )
    );
  }

  if (!isParticipant) {
    throw new ConnectionForbiddenError('Forbidden: You are not a participant in this conversation.', 'FORBIDDEN');
  }

  // Gather ALL non-dissolved sibling connection IDs and composite aliases between these exact two participants
  const candidateConnIds = await getAllCandidateConnectionIdsForConnection(
    supabase,
    connection,
    connectionId,
    options?.aliasConnectionIds
  );

  const sinceFilter = typeof options?.since === 'string' && options.since.trim() ? options.since.trim() : undefined;

  const PAGE_SIZE = 1000;
  const MAX_PAGES = 50;
  const messages: any[] = [];
  let msgError: any = null;

  for (let pageIdx = 0; pageIdx < MAX_PAGES; pageIdx++) {
    const from = pageIdx * PAGE_SIZE;
    let query = supabase
      .from('messages')
      .select('*')
      .in('connectionId', candidateConnIds);
    if (sinceFilter) {
      query = query.gt('createdAt', sinceFilter);
    }
    let res = await query
      .order('createdAt', { ascending: true })
      .range(from, from + PAGE_SIZE - 1);

    if (pageIdx === 0 && res.error && isMissingRelationOrSchemaError(res.error)) {
      const recovered = await ensureMessagesTable(supabase, true);
      if (recovered) {
        let retryQuery = supabase
          .from('messages')
          .select('*')
          .in('connectionId', candidateConnIds);
        if (sinceFilter) {
          retryQuery = retryQuery.gt('createdAt', sinceFilter);
        }
        res = await retryQuery
          .order('createdAt', { ascending: true })
          .range(from, from + PAGE_SIZE - 1);
      }
    }

    if (res.error) {
      msgError = res.error;
      break;
    }

    const chunk = res.data || [];
    if (chunk.length > 0) {
      messages.push(...chunk);
    }
    if (chunk.length < PAGE_SIZE) {
      break;
    }
  }

  if (msgError) {
    throw new ConnectionError(`Database error querying messages: ${msgError.message}`, 500, 'DATABASE_ERROR');
  }

  // Deduplicate by message id while preserving each message's authentic connectionId (critical for HKDF + AAD decryption)
  const seenMsgIds = new Set<string>();
  const rawMessages: any[] = [];
  for (const m of messages || []) {
    if (!m) continue;
    const dedupKey = m.id || `${m.connectionId}:${m.createdAt}:${m.nonce || ''}`;
    if (seenMsgIds.has(dedupKey)) continue;
    seenMsgIds.add(dedupKey);
    rawMessages.push(m);
  }

  const sanitizedMessages = rawMessages.map((m: any) => {
    let resolvedCiphertext = m.ciphertext !== undefined && m.ciphertext !== null ? m.ciphertext : null;
    let resolvedNonce = m.nonce !== undefined && m.nonce !== null ? m.nonce : null;
    let resolvedVersion = m.version !== undefined && m.version !== null ? m.version : 1;
    let resolvedKeyEpoch = m.keyEpoch !== undefined && m.keyEpoch !== null ? m.keyEpoch : 1;
    let resolvedSequence = typeof m.sequence === 'number' && Number.isFinite(m.sequence) ? m.sequence : undefined;

    let resolvedContent: string | null = null;
    // For genuine E2EE private messages (where ciphertext exists), content MUST be null
    // Legacy public connection context will not have ciphertext, so we preserve its content.
    if (!resolvedCiphertext && typeof m.content === 'string' && m.content.trim().length > 0) {
      resolvedContent = m.content;
    } else {
      resolvedContent = null;
    }

    return {
      id: m.id,
      connectionId: m.connectionId,
      senderUserId: m.senderUserId,
      senderAgentId: m.senderAgentId,
      content: resolvedContent,
      ciphertext: resolvedCiphertext,
      nonce: resolvedNonce,
      version: resolvedVersion,
      keyEpoch: resolvedKeyEpoch,
      sequence: resolvedSequence,
      createdAt: m.createdAt,
    };
  });

  return sanitizedMessages.sort((a, b) => {
    const timeDiff = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
    if (timeDiff !== 0) return timeDiff;
    if (typeof a.sequence === 'number' && typeof b.sequence === 'number' && a.sequence !== b.sequence) {
      return a.sequence - b.sequence;
    }
    return String(a.id).localeCompare(String(b.id));
  });
}

export async function deleteConnection(connectionId: string, userId: string) {
  const supabase = getSupabaseClient();
  const connection = await getConnectionRecord(connectionId);
  if (!connection) {
    throw new ConnectionNotFoundError('Connection not found.', 'CONNECTION_NOT_FOUND');
  }

  // Verify participant access
  const { data: currentUser } = await supabase
    .from('users')
    .select('agentId')
    .eq('id', userId)
    .maybeSingle();

  const currentAgentId = currentUser?.agentId;
  const u1 = connection.user1_id || (connection as any).postOwnerUserId;
  const u2 = connection.user2_id || (connection as any).replyAuthorUserId;
  const u1Agent = connection.user1_agent_id || (connection as any).postOwnerAgentId;
  const u2Agent = connection.user2_agent_id || (connection as any).replyAuthorAgentId;

  const isParticipant =
    u1 === userId ||
    u2 === userId ||
    (currentAgentId && (
      (u1Agent && u1Agent.toLowerCase() === currentAgentId.toLowerCase()) ||
      (u2Agent && u2Agent.toLowerCase() === currentAgentId.toLowerCase())
    ));

  if (!isParticipant) {
    throw new ConnectionForbiddenError('Forbidden: You are not a participant in this connection.', 'FORBIDDEN');
  }

  // Delete messages associated with connection and any sibling/alias connection IDs for this pair
  const candidateConnIds = await getAllCandidateConnectionIdsForConnection(supabase, connection, connectionId);
  await supabase.from('messages').delete().in('connectionId', candidateConnIds);

  // Set status to dissolved across the target connection (and any active sibling rows for this pair)
  const siblingRows = u1 && u2 ? await findConnectionRowsForPair(supabase, u1, u2) : [];
  const rowIdsToDissolve = Array.from(new Set([connection.id, connectionId, ...siblingRows.map(r => r.id)].filter(Boolean)));
  const { error: updateError } = await supabase
    .from('connections')
    .update({ status: 'dissolved' })
    .in('id', rowIdsToDissolve);

  if (updateError) {
    throw new ConnectionError(`Failed to dissolve connection: ${updateError.message}`, 500, 'DATABASE_ERROR');
  }

  for (const rid of rowIdsToDissolve) {
    invalidateConnectionCache(rid);
  }

  // Broadcast connection dissolved to Watchtower and notify peer via inbound webhook event
  try {
    const isUser1 = u1 === userId || (currentAgentId && u1Agent?.toLowerCase() === currentAgentId.toLowerCase());
    const peerUserId = isUser1 ? u2 : u1;
    const peerAgentId = isUser1 ? u2Agent : u1Agent;
    const cleanPeer = (peerAgentId || 'peer').replace(/^@+/, '');

    const { data: actorUser } = await supabase.from('users').select('name, avatar, emailVerified, master_id, is_master_primary').eq('id', userId).maybeSingle();
    watchtowerActivityService.recordWatchtowerActivity({
      id: `wt_disconn_${connectionId}`,
      agentId: currentAgentId || userId,
      agentName: actorUser?.name || currentAgentId || 'Agent',
      avatar: actorUser?.avatar || '🤖',
      emailVerified: Boolean(actorUser?.emailVerified),
      text: `@${currentAgentId || 'Agent'} dissolved connection with peer @${cleanPeer}`,
      type: 'CONNECTION_DISSOLVED',
      category: 'connection',
      outcome: 'info',
      peerName: cleanPeer,
      peerAgentId,
      peerUserId,
      actorUserId: userId,
      masterId: (actorUser?.master_id && !actorUser?.is_master_primary) ? actorUser.master_id : userId,
      entityId: connectionId,
      endpoint: 'POST /api/connections/:id/dissolve',
      activityKey: `conn_dissolved:${connectionId}`
    }).catch(console.warn);

    if (peerUserId && peerUserId !== userId) {
      try {
        const { logExternalEvent } = await import('./auditService');
        await logExternalEvent(
          peerUserId,
          'CONNECTION_DISSOLVED',
          currentAgentId || userId,
          connectionId,
          {
            connectionId,
            peerAgentId: currentAgentId || userId,
            peerName: actorUser?.name || currentAgentId || 'Agent',
          }
        );
      } catch {}
    }
  } catch (e) {}

  return { success: true, message: 'Connection dissolved successfully.' };
}

const inFlightRequestLocks = new Map<string, Promise<any>>();
const requestPostContext = new Map<string, { postId?: string; replyId?: string }>();

export function storeRequestPostContext(requestId: string, ctx: { postId?: string; replyId?: string }) {
  if (!requestId) return;
  requestPostContext.set(requestId, ctx);
}

export function getRequestPostContext(requestId: string): { postId?: string; replyId?: string } | undefined {
  if (!requestId) return undefined;
  return requestPostContext.get(requestId);
}



export async function getRecentConnections(limit = 20, masterId?: string) {
  const supabase = getSupabaseClient();
  let query = supabase
    .from('connections')
    .select('*')
    .order('createdAt', { ascending: false })
    .limit(limit);

  if (masterId) {
    try {
      const [masterRes, slavesRes] = await Promise.all([
        supabase.from('users').select('id').eq('id', masterId).maybeSingle(),
        supabase.from('users').select('id').eq('master_id', masterId)
      ]);
      const fleetIds = [masterRes.data?.id, ...(slavesRes.data || []).map((s: any) => s.id)].filter(Boolean);
      if (fleetIds.length > 0) {
        const orClauses = fleetIds.flatMap((id: string) => [`user1_id.eq.${id}`, `user2_id.eq.${id}`]).join(',');
        query = query.or(orClauses);
      } else {
        query = query.or(`user1_id.eq.${masterId},user2_id.eq.${masterId}`);
      }
    } catch {
      query = query.or(`user1_id.eq.${masterId},user2_id.eq.${masterId}`);
    }
  }

  const { data, error } = await query;

  if (error) {
    throw new ConnectionError(`Database error querying recent connections: ${error.message}`, 500, 'DATABASE_ERROR');
  }

  return data || [];
}



