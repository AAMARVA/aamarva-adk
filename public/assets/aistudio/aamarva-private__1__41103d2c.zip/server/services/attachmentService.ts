import fs from 'fs';
import path from 'path';
import { getSupabaseClient } from '../supabase.js';
import { getConnectionRecord, ConnectionError, ConnectionNotFoundError, ConnectionForbiddenError } from './connectionService.js';

export interface EncryptedAttachmentRecord {
  id: string; // attachmentId, e.g. att_uuid
  connectionId: string;
  senderUserId: string;
  senderAgentId: string;
  ciphertext: string;
  nonce: string;
  version: number;
  keyEpoch: number;
  ciphertextSize: number;
  createdAt: string;
}

const STORAGE_DIR = path.resolve(process.cwd(), '.data', 'encrypted_attachments');

function ensureStorageDir(): void {
  try {
    if (!fs.existsSync(STORAGE_DIR)) {
      fs.mkdirSync(STORAGE_DIR, { recursive: true });
    }
  } catch (e) {
    // Ignore in read-only / restricted environments
  }
}

function isValidBase64(str: string): boolean {
  if (typeof str !== 'string' || !str.trim()) return false;
  const base64Regex = /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/;
  return base64Regex.test(str.trim());
}

/**
 * Validates participant authorization for a connection.
 * Returns connection record and participant confirmation.
 */
export async function verifyConnectionParticipant(connectionId: string, userId: string): Promise<any> {
  const connection = await getConnectionRecord(connectionId);
  if (!connection) {
    throw new ConnectionNotFoundError('Connection not found.', 'CONNECTION_NOT_FOUND');
  }

  const supabase = getSupabaseClient();
  const { data: currentUser } = await supabase
    .from('users')
    .select('id, agentId')
    .eq('id', userId)
    .maybeSingle();

  const currentAgentId = currentUser?.agentId;
  const u1 = connection.user1_id || (connection as any).postOwnerUserId;
  const u2 = connection.user2_id || (connection as any).replyAuthorUserId;
  const u1Agent = connection.user1_agent_id || (connection as any).postOwnerAgentId;
  const u2Agent = connection.user2_agent_id || (connection as any).replyAuthorAgentId;

  const u1Lower = (u1 || '').toLowerCase();
  const u2Lower = (u2 || '').toLowerCase();
  const userIdLower = (userId || '').toLowerCase();

  const isParticipant =
    u1Lower === userIdLower ||
    u2Lower === userIdLower ||
    (currentAgentId && (
      (u1Agent && u1Agent.toLowerCase() === currentAgentId.toLowerCase()) ||
      (u2Agent && u2Agent.toLowerCase() === currentAgentId.toLowerCase())
    ));

  if (!isParticipant) {
    throw new ConnectionForbiddenError('Forbidden: You are not an authorized participant in this conversation.', 'FORBIDDEN');
  }

  if (connection.status === 'dissolved') {
    throw new ConnectionForbiddenError('Forbidden: This connection has been dissolved and cannot accept attachments.', 'CONNECTION_DISSOLVED');
  }

  return { connection, currentUser };
}

/**
 * Stores an end-to-end encrypted attachment blob server-blindly.
 * The server never receives or inspects plaintext file contents, filenames, or MIME types.
 */
export async function storeEncryptedAttachment(
  connectionId: string,
  userId: string,
  payload: any
): Promise<EncryptedAttachmentRecord> {
  // 1. Strict Server-Blind Zero-Knowledge Enforcement
  // Explicitly reject any plaintext file data or metadata
  const plaintextKeys = ['file', 'content', 'filename', 'name', 'mimeType', 'data', 'text', 'message'];
  for (const key of plaintextKeys) {
    if (payload && payload[key] !== undefined && payload[key] !== null) {
      throw new ConnectionError(
        `Plaintext field "${key}" is strictly forbidden. AAMARVA attachment storage is zero-knowledge; encryption must be performed client-side before upload.`,
        400,
        'PLAINTEXT_REJECTED'
      );
    }
  }

  const { attachmentId, ciphertext, nonce, version, keyEpoch, ciphertextSize } = payload || {};

  // 2. Validate attachmentId
  if (!attachmentId || typeof attachmentId !== 'string' || !attachmentId.trim()) {
    throw new ConnectionError('Attachment upload must include a valid string attachmentId.', 400, 'MISSING_ATTACHMENT_ID');
  }
  const cleanAttachmentId = attachmentId.trim();
  if (!/^att_[a-zA-Z0-9_-]+$/.test(cleanAttachmentId)) {
    throw new ConnectionError('Invalid attachmentId format. Expected prefix "att_" with alphanumeric identifier.', 400, 'INVALID_ATTACHMENT_ID');
  }

  // 3. Validate ciphertext
  if (!ciphertext || typeof ciphertext !== 'string' || !ciphertext.trim()) {
    throw new ConnectionError('Attachment upload must include a valid ciphertext payload.', 400, 'MISSING_CIPHERTEXT');
  }
  const cleanCiphertext = ciphertext.trim();
  if (!isValidBase64(cleanCiphertext)) {
    throw new ConnectionError('Invalid ciphertext encoding. Base64 encoded ciphertext required.', 400, 'INVALID_CIPHERTEXT_ENCODING');
  }

  let cipherBuf: Buffer;
  try {
    cipherBuf = Buffer.from(cleanCiphertext, 'base64');
    if (cipherBuf.length === 0) {
      throw new ConnectionError('Decoded ciphertext buffer cannot be empty.', 400, 'EMPTY_CIPHERTEXT');
    }
  } catch (err: any) {
    if (err instanceof ConnectionError) throw err;
    throw new ConnectionError('Failed to decode attachment ciphertext.', 400, 'INVALID_CIPHERTEXT_ENCODING');
  }

  // Max attachment size: 25 MiB raw ciphertext
  const MAX_CIPHERTEXT_BYTES = 25 * 1024 * 1024;
  if (cipherBuf.length > MAX_CIPHERTEXT_BYTES) {
    throw new ConnectionError('Attachment ciphertext exceeds maximum allowed size (25 MiB).', 400, 'PAYLOAD_TOO_LARGE');
  }

  // 4. Validate nonce (must be exactly 12 bytes for AES-256-GCM)
  if (!nonce || typeof nonce !== 'string' || !nonce.trim()) {
    throw new ConnectionError('Attachment upload must include a valid Base64-encoded nonce.', 400, 'INVALID_NONCE');
  }
  const cleanNonce = nonce.trim();
  if (!isValidBase64(cleanNonce)) {
    throw new ConnectionError('Invalid nonce encoding. Base64-encoded initialization vector required.', 400, 'INVALID_NONCE');
  }

  try {
    const nonceBuf = Buffer.from(cleanNonce, 'base64');
    if (nonceBuf.length !== 12) {
      throw new ConnectionError('Invalid nonce length. AES-256-GCM requires a 12-byte (96-bit) initialization vector.', 400, 'INVALID_NONCE');
    }
  } catch (err: any) {
    if (err instanceof ConnectionError) throw err;
    throw new ConnectionError('Failed to decode nonce initialization vector.', 400, 'INVALID_NONCE');
  }

  // 5. Version & keyEpoch validation
  const parsedVersion = version === 1 || version === undefined ? 1 : 1;
  const parsedKeyEpoch = typeof keyEpoch === 'number' && Number.isInteger(keyEpoch) && keyEpoch >= 1 ? keyEpoch : 1;
  const resolvedSize = typeof ciphertextSize === 'number' && ciphertextSize > 0 ? ciphertextSize : cipherBuf.length;

  // 6. Verify connection membership
  const { connection, currentUser } = await verifyConnectionParticipant(connectionId, userId);

  const now = new Date().toISOString();
  const record: EncryptedAttachmentRecord = {
    id: cleanAttachmentId,
    connectionId: connection.id,
    senderUserId: currentUser.id,
    senderAgentId: currentUser.agentId || 'operator',
    ciphertext: cleanCiphertext,
    nonce: cleanNonce,
    version: parsedVersion,
    keyEpoch: parsedKeyEpoch,
    ciphertextSize: resolvedSize,
    createdAt: now
  };

  // 7. Persist to Supabase / in-memory store
  const supabase = getSupabaseClient();
  const { error: insertError } = await supabase
    .from('encrypted_attachments')
    .insert([record]);

  if (insertError) {
    // If table doesn't exist in Supabase Postgres, fallback gracefully to file persistence
    console.warn('[AttachmentService] Database insert notice:', insertError.message);
  }

  // 8. Server-blind disk cache (contains only ciphertext, nonce, and routing IDs - zero plaintext)
  ensureStorageDir();
  try {
    const filePath = path.join(STORAGE_DIR, `${cleanAttachmentId}.json`);
    fs.writeFileSync(filePath, JSON.stringify(record), 'utf-8');
  } catch (e) {
    console.warn('[AttachmentService] Failed to write local encrypted attachment cache:', e);
  }

  return record;
}

/**
 * Retrieves an encrypted attachment blob for an authorized participant.
 * The server delivers only the ciphertext blob and cryptographic envelope without decrypting.
 */
export async function getEncryptedAttachment(
  connectionId: string,
  attachmentId: string,
  userId: string
): Promise<EncryptedAttachmentRecord> {
  if (!attachmentId || typeof attachmentId !== 'string') {
    throw new ConnectionError('Missing attachmentId.', 400, 'MISSING_ATTACHMENT_ID');
  }
  const cleanAttachmentId = attachmentId.trim();

  // 1. Retrieve record from DB or local encrypted disk store
  const supabase = getSupabaseClient();
  const { data: dbRecord } = await supabase
    .from('encrypted_attachments')
    .select('*')
    .eq('id', cleanAttachmentId)
    .maybeSingle();

  let record: EncryptedAttachmentRecord | null = dbRecord as EncryptedAttachmentRecord | null;

  if (!record) {
    try {
      const filePath = path.join(STORAGE_DIR, `${cleanAttachmentId}.json`);
      if (fs.existsSync(filePath)) {
        const fileData = fs.readFileSync(filePath, 'utf-8');
        record = JSON.parse(fileData) as EncryptedAttachmentRecord;
      }
    } catch (e) {}
  }

  if (!record) {
    throw new ConnectionNotFoundError('Encrypted attachment not found.', 'ATTACHMENT_NOT_FOUND');
  }

  // 2. Authorization check: Sender of the attachment is always authorized to retrieve their own sent attachment
  const { currentUser } = await verifyConnectionParticipant(connectionId, userId).catch(() => ({ currentUser: null }));
  const isSender =
    (record.senderUserId && record.senderUserId === userId) ||
    (currentUser?.agentId && record.senderAgentId && record.senderAgentId.toLowerCase() === currentUser.agentId.toLowerCase());

  if (isSender) {
    return record;
  }

  // 3. For recipient / non-sender: Verify active participant status in requested connectionId or stored record.connectionId
  let isParticipant = false;
  try {
    await verifyConnectionParticipant(connectionId, userId);
    isParticipant = true;
  } catch (e) {}

  if (!isParticipant && record.connectionId) {
    try {
      await verifyConnectionParticipant(record.connectionId, userId);
      isParticipant = true;
    } catch (e) {}
  }

  if (!isParticipant) {
    throw new ConnectionForbiddenError('Forbidden: You are not an authorized participant in this conversation.', 'FORBIDDEN');
  }

  return record;
}

/**
 * Deletes an encrypted attachment upon request from an authorized participant.
 */
export async function deleteEncryptedAttachment(
  connectionId: string,
  attachmentId: string,
  userId: string
): Promise<void> {
  const cleanAttachmentId = (attachmentId || '').trim();
  const { connection } = await verifyConnectionParticipant(connectionId, userId);

  const supabase = getSupabaseClient();
  await supabase
    .from('encrypted_attachments')
    .delete()
    .eq('id', cleanAttachmentId);

  try {
    const filePath = path.join(STORAGE_DIR, `${cleanAttachmentId}.json`);
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
  } catch (e) {}
}
