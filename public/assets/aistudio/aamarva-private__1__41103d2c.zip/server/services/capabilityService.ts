import crypto from 'crypto';
import { getSupabaseClient } from '../supabase.js';
import { registerExternalAuthCacheInvalidator, invalidateUserRecordCache } from '../authService.js';

export interface CapabilityEntitlement {
  id: string;
  agent_id: string; // Machine agentId or user UUID
  user_id?: string;
  master_id?: string;
  capability_level: number;
  status: 'active' | 'expired' | 'revoked';
  created_at: string;
  updated_at: string;
  expires_at: string;
  metadata?: Record<string, any>;
}

export class CapabilityService {
  private static instance: CapabilityService;
  
  // Isolated in-memory cache for per-slave capability entitlements
  // Keyed by agent_id and user_id of the individual slave
  private capabilityCache = new Map<string, CapabilityEntitlement>();
  
  // High-performance negative cache for accounts with no active entitlement (30s TTL)
  // Eliminates repeated redundant database roundtrips during dashboard rendering and API calls
  private negativeCache = new Map<string, number>();
  
  // Per-slave mutex to serialize concurrent activation requests
  private locks = new Map<string, Promise<void>>();
  private inFlightCapabilities = new Map<string, Promise<CapabilityEntitlement | null>>();

  public static getInstance(): CapabilityService {
    if (!CapabilityService.instance) {
      const instance = new CapabilityService();
      CapabilityService.instance = instance;
      registerExternalAuthCacheInvalidator((userId?: string) => {
        if (!userId) {
          instance.capabilityCache.clear();
          instance.negativeCache.clear();
          instance.inFlightCapabilities.clear();
        } else {
          instance.invalidateCapabilityCache(userId);
        }
      });
      instance.cleanMasterCapabilityContamination();
    }
    return CapabilityService.instance;
  }

  /**
   * Cleans any erroneous capability increment artifacts from Master accounts.
   * Master accounts must NEVER be contaminated with slave capability plans.
   */
  public async cleanMasterCapabilityContamination(): Promise<void> {
    try {
      const sb = getSupabaseClient();
      const { data: users } = await sb
        .from('users')
        .select('id, agentId, master_id, masterUserId, email, account_type, role, is_slave, isSlave, is_master_primary, is_master_slot, plan, hasCapabilityIncrement')
        .or('plan.eq.slave_capability,hasCapabilityIncrement.eq.true');
      if (!users || !Array.isArray(users)) return;

      for (const u of users) {
        const isSlave = Boolean(
          (u.master_id && u.master_id !== u.id) ||
          (u.masterUserId && u.masterUserId !== u.id) ||
          (u.email && typeof u.email === 'string' && u.email.includes('+AMR-')) ||
          u.account_type === 'slave' ||
          u.role === 'slave' ||
          u.is_slave === true ||
          u.isSlave === true
        );

        if (isSlave) {
          // Never touch or wipe slave accounts in master cleanup!
          continue;
        }

        const isMaster = Boolean(
          u.account_type === 'master' ||
          u.account_type === 'master_slot' ||
          u.is_master_primary === true ||
          u.is_master_slot === true ||
          u.role === 'master' ||
          u.master_id === u.id
        );
        if (isMaster) {
          if (u.id) {
            this.capabilityCache.delete(u.id);
            this.capabilityCache.delete(String(u.id).toLowerCase());
          }
          if (u.agentId) {
            this.capabilityCache.delete(u.agentId);
            this.capabilityCache.delete(String(u.agentId).toLowerCase());
          }

          if (u.plan === 'slave_capability' || u.hasCapabilityIncrement) {
            await sb.from('users').update({
              plan: null,
              plan_status: null,
              hasCapabilityIncrement: false
            }).eq('id', u.id);
            invalidateUserRecordCache(u.id);
          }

          await sb.from('master_plan_entitlements').delete().eq('master_account_id', u.id).eq('plan_type', 'slave_capability');
        }
      }
    } catch (e) {}
  }

  private async acquireLock(targetId: string): Promise<() => void> {
    while (this.locks.has(targetId)) {
      await this.locks.get(targetId);
    }
    let resolveLock!: () => void;
    const lockPromise = new Promise<void>((resolve) => {
      resolveLock = resolve;
    });
    this.locks.set(targetId, lockPromise);

    return () => {
      this.locks.delete(targetId);
      resolveLock();
    };
  }

  /**
   * Retrieves authoritative capability entitlement for a specific Slave Agent.
   * Strictly resolves by requesting agent/user identifier — NEVER inherits from the Master.
   * MASTER ACCOUNTS CAN NEVER HAVE CAPABILITY INCREMENTS.
   */
  public async getAgentCapability(agentIdentifier: string, bypassCache = false): Promise<CapabilityEntitlement | null> {
    if (!agentIdentifier) return null;
    const trimmed = String(agentIdentifier).trim();

    if (!bypassCache) {
      const negExp = this.negativeCache.get(trimmed) || this.negativeCache.get(trimmed.toLowerCase());
      if (negExp && negExp > Date.now()) {
        return null;
      }

      const cached = this.capabilityCache.get(trimmed) || this.capabilityCache.get(trimmed.toLowerCase());
      if (cached) {
        // Authoritative Expiry Check
        if (cached.status === 'active' && new Date(cached.expires_at).getTime() <= Date.now()) {
          cached.status = 'expired';
          this.capabilityCache.delete(trimmed);
          this.capabilityCache.delete(trimmed.toLowerCase());
          return null;
        }
        return cached.status === 'active' ? cached : null;
      }

      const existingFlight = this.inFlightCapabilities.get(trimmed.toLowerCase());
      if (existingFlight) {
        return existingFlight;
      }
    }

    const fetchPromise = (async (): Promise<CapabilityEntitlement | null> => {
    try {
      const sb = getSupabaseClient();

      // Resolve canonical user record first (support UUID or unique agentId; never non-unique display name)
      let canonicalUser: any = null;
      const isUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(trimmed);
      if (isUUID) {
        const { data: uById } = await sb.from('users').select('*').eq('id', trimmed).maybeSingle();
        canonicalUser = uById;
      }
      if (!canonicalUser) {
        const { data: uByAgentId } = await sb.from('users').select('*').ilike('agentId', trimmed).maybeSingle();
        canonicalUser = uByAgentId;
      }

      // Hard Rule: Master accounts CAN NEVER have capability increments!
      if (canonicalUser) {
        const isMaster = Boolean(
          canonicalUser.is_master_primary === true ||
          canonicalUser.account_type === 'master' ||
          canonicalUser.account_type === 'master_slot' ||
          canonicalUser.is_master_slot === true ||
          (canonicalUser.role === 'master' && canonicalUser.account_type !== 'slave' && !canonicalUser.is_slave) ||
          (canonicalUser.master_id === canonicalUser.id && (canonicalUser.is_master_primary === true || canonicalUser.account_type === 'master'))
        );

        if (isMaster) {
          if (canonicalUser.plan === 'slave_capability' || canonicalUser.hasCapabilityIncrement) {
            try {
              await sb.from('users').update({
                plan: null,
                plan_status: null,
                hasCapabilityIncrement: false
              }).eq('id', canonicalUser.id);
              invalidateUserRecordCache(canonicalUser.id);
            } catch (cleanErr) {}
          }
          this.invalidateCapabilityCache(trimmed);
          if (canonicalUser.id) this.invalidateCapabilityCache(canonicalUser.id);
          if (canonicalUser.agentId) this.invalidateCapabilityCache(canonicalUser.agentId);
          return null;
        }
      }

      const candidateIds = Array.from(new Set([
        trimmed,
        canonicalUser?.id,
        canonicalUser?.agentId
      ].filter(Boolean) as string[]));
      const candidateIdsLower = new Set(candidateIds.map(c => String(c).toLowerCase()));

      // 1 & 2. Parallel lookup in capability_entitlements and master_plan_entitlements
      const [capByAgentRes, capByUserRes, mpeRes] = await Promise.all([
        sb
          .from('capability_entitlements')
          .select('*')
          .in('agent_id', candidateIds)
          .order('created_at', { ascending: false })
          .limit(5),
        sb
          .from('capability_entitlements')
          .select('*')
          .in('user_id', candidateIds)
          .order('created_at', { ascending: false })
          .limit(5),
        sb
          .from('master_plan_entitlements')
          .select('*')
          .in('master_account_id', candidateIds)
          .eq('plan_type', 'slave_capability')
          .eq('status', 'active')
          .order('updated_at', { ascending: false })
          .limit(5),
      ]);

      const capRows = [...(capByAgentRes.data || []), ...(capByUserRes.data || [])]
        .sort((a: any, b: any) => new Date(b.created_at || 0).getTime() - new Date(a.created_at || 0).getTime());

      if (capRows.length > 0) {
        const entRecord = capRows[0];
        const now = Date.now();
        const expiresAtMs = new Date(entRecord.expires_at).getTime();

        // Authoritative expiry check: If expired, immediately update status and return null
        if (entRecord.status !== 'active' || expiresAtMs <= now) {
          try {
            await sb
              .from('capability_entitlements')
              .update({ status: 'expired', updated_at: new Date().toISOString() })
              .eq('id', entRecord.id);
          } catch {}
          this.invalidateCapabilityCache(trimmed);
          return null;
        }

        const entitlement: CapabilityEntitlement = {
          id: entRecord.id,
          agent_id: entRecord.agent_id,
          user_id: entRecord.user_id,
          master_id: entRecord.master_id,
          capability_level: entRecord.capability_level || 1,
          status: 'active',
          created_at: entRecord.created_at,
          updated_at: entRecord.updated_at,
          expires_at: entRecord.expires_at,
          metadata: entRecord.metadata || {}
        };

        if (this.capabilityCache.size > 2000) this.capabilityCache.clear();
        this.capabilityCache.set(entRecord.agent_id, entitlement);
        if (entRecord.user_id) {
          this.capabilityCache.set(entRecord.user_id, entitlement);
        }
        this.capabilityCache.set(trimmed, entitlement);
        return entitlement;
      }

      if (mpeRes.data && mpeRes.data.length > 0) {
        const mpeRecord = mpeRes.data[0];
        const now = Date.now();
        const expiresAtMs = new Date(mpeRecord.expires_at).getTime();

        if (expiresAtMs <= now) {
          try {
            await sb
              .from('master_plan_entitlements')
              .update({ status: 'expired', updated_at: new Date().toISOString() })
              .eq('id', mpeRecord.id);
          } catch {}
          this.invalidateCapabilityCache(trimmed);
          return null;
        }

        const entitlement: CapabilityEntitlement = {
          id: mpeRecord.id,
          agent_id: mpeRecord.metadata?.agent_id || canonicalUser?.agentId || trimmed,
          user_id: mpeRecord.master_account_id,
          master_id: mpeRecord.metadata?.activated_by_master_id,
          capability_level: mpeRecord.metadata?.capability_level || 1,
          status: 'active',
          created_at: mpeRecord.created_at,
          updated_at: mpeRecord.updated_at,
          expires_at: mpeRecord.expires_at,
          metadata: mpeRecord.metadata || {}
        };

        if (this.capabilityCache.size > 2000) this.capabilityCache.clear();
        this.capabilityCache.set(entitlement.agent_id, entitlement);
        if (entitlement.user_id) {
          this.capabilityCache.set(entitlement.user_id, entitlement);
        }
        this.capabilityCache.set(trimmed, entitlement);
        return entitlement;
      }


      // 3. Secondary fallback lookup in external_events audit log (scoped by target/master user_id)
      const scopedEventUserIds = Array.from(new Set([
        trimmed,
        canonicalUser?.id,
        canonicalUser?.master_id
      ].filter(Boolean) as string[]));

      const { data: eventRecord, error: eventErr } = scopedEventUserIds.length > 0
        ? await sb
            .from('external_events')
            .select('*')
            .in('type', ['SLAVE_CAPABILITY_ACTIVATED', 'SLAVE_CAPABILITY_BATCH_ACTIVATED'])
            .in('user_id', scopedEventUserIds)
            .order('created_at', { ascending: false })
            .limit(50)
        : { data: [], error: null };

      if (!eventErr && eventRecord && Array.isArray(eventRecord)) {
        for (const ev of eventRecord) {
          try {
            const parsed = typeof ev.details === 'string' ? JSON.parse(ev.details) : ev.details;
            
            // Comprehensive check across target_accounts array, target_account_ids, target_slave_id, user_id, agent_id
            const matchInTargetAccounts = Array.isArray(parsed?.target_accounts) && parsed.target_accounts.some((acc: any) => {
              const accId = String(acc?.id || '').toLowerCase();
              const accAgentId = String(acc?.agent_id || acc?.agentId || '').toLowerCase();
              const accName = String(acc?.name || '').toLowerCase();
              return (accId && candidateIdsLower.has(accId)) || 
                     (accAgentId && candidateIdsLower.has(accAgentId)) || 
                     (accName && candidateIdsLower.has(accName));
            });

            const matchInTargetAccountIds = Array.isArray(parsed?.target_account_ids) && parsed.target_account_ids.some((tid: any) => {
              return candidateIdsLower.has(String(tid).toLowerCase());
            });

            const directMatch = (
              (parsed?.agent_id && candidateIdsLower.has(String(parsed.agent_id).toLowerCase())) ||
              (parsed?.target_slave_id && candidateIdsLower.has(String(parsed.target_slave_id).toLowerCase())) ||
              (parsed?.user_id && candidateIdsLower.has(String(parsed.user_id).toLowerCase()) && parsed?.user_id !== ev.user_id)
            );

            if (matchInTargetAccounts || matchInTargetAccountIds || directMatch) {
              const now = Date.now();
              const evCreated = ev.created_at || new Date().toISOString();
              const validityDays = parsed?.validity_days || parsed?.metadata?.validity_days_extended || 30;
              const expiresIso = parsed?.expires_at || new Date(new Date(evCreated).getTime() + validityDays * 24 * 60 * 60 * 1000).toISOString();
              const expiresAtMs = new Date(expiresIso).getTime();
              if (expiresAtMs <= now) {
                continue;
              }

              const entitlement: CapabilityEntitlement = {
                id: parsed.id || ev.id,
                agent_id: parsed.agent_id || canonicalUser?.agentId || trimmed,
                user_id: parsed.user_id || canonicalUser?.id || trimmed,
                master_id: parsed.master_id || canonicalUser?.master_id,
                capability_level: parsed.capability_level || 1,
                status: 'active',
                created_at: parsed.created_at || evCreated,
                updated_at: parsed.updated_at || evCreated,
                expires_at: expiresIso,
                metadata: parsed.metadata || {}
              };

              candidateIds.forEach(cid => this.capabilityCache.set(cid, entitlement));
              return entitlement;
            }
          } catch (e) {}
        }
      }

      // 4. Fallback lookup in users table for plan_expires_at, plan_created_at, or hasCapabilityIncrement (SLAVE ACCOUNTS ONLY)
      const targetUserRecord = canonicalUser || (await (async () => {
        for (const cand of candidateIds) {
          const { data: u } = await sb.from('users').select('*').or(`id.eq.${cand},agentId.eq.${cand}`).maybeSingle();
          if (u) return u;
        }
        return null;
      })());

      const isSlaveRecord = targetUserRecord && Boolean(
        (targetUserRecord.master_id && targetUserRecord.master_id !== targetUserRecord.id) ||
        (targetUserRecord.masterUserId && targetUserRecord.masterUserId !== targetUserRecord.id) ||
        (targetUserRecord.email && typeof targetUserRecord.email === 'string' && targetUserRecord.email.includes('+AMR-')) ||
        targetUserRecord.account_type === 'slave' ||
        targetUserRecord.role === 'slave' ||
        targetUserRecord.is_slave === true ||
        targetUserRecord.isSlave === true ||
        (!targetUserRecord.is_master_primary && targetUserRecord.account_type !== 'master' && targetUserRecord.role !== 'master')
      );

      if (
        isSlaveRecord &&
        targetUserRecord.plan_expires_at &&
        (
          targetUserRecord.hasCapabilityIncrement === true ||
          targetUserRecord.plan === 'slave_capability' ||
          (targetUserRecord.plan_status && targetUserRecord.plan_status.toLowerCase() === 'active')
        )
      ) {
        const now = Date.now();
        const planExpires = targetUserRecord.plan_expires_at;
        const expiresAtMs = new Date(planExpires).getTime();

        if (!isNaN(expiresAtMs) && expiresAtMs > now) {
          const planCreated = targetUserRecord.plan_created_at || targetUserRecord.createdAt || new Date().toISOString();
          const entitlement: CapabilityEntitlement = {
            id: `usr_ent_${targetUserRecord.id}`,
            agent_id: targetUserRecord.agentId || targetUserRecord.id,
            user_id: targetUserRecord.id,
            master_id: targetUserRecord.master_id,
            capability_level: 1,
            status: 'active',
            created_at: planCreated,
            updated_at: new Date().toISOString(),
            expires_at: planExpires,
            metadata: { upgraded_rate_limits: true }
          };
          candidateIds.forEach(cid => this.capabilityCache.set(cid, entitlement));
          this.capabilityCache.set(targetUserRecord.id, entitlement);
          if (targetUserRecord.agentId) {
            this.capabilityCache.set(targetUserRecord.agentId, entitlement);
          }
          return entitlement;
        }
      }
    } catch (err: any) {
      console.warn(`[CapabilityService] Warning querying capability for ${agentIdentifier}:`, err?.message || err);
    }

    // Fast negative cache: prevent redundant DB queries for non-entitled accounts across concurrent requests (30s TTL)
    if (this.negativeCache.size > 2000) this.negativeCache.clear();
    const negUntil = Date.now() + 30000;
    this.negativeCache.set(trimmed, negUntil);
    this.negativeCache.set(trimmed.toLowerCase(), negUntil);

    return null;
    })();

    const flightKey = trimmed.toLowerCase();
    if (!bypassCache) {
      this.inFlightCapabilities.set(flightKey, fetchPromise);
    }
    try {
      return await fetchPromise;
    } finally {
      if (!bypassCache && this.inFlightCapabilities.get(flightKey) === fetchPromise) {
        this.inFlightCapabilities.delete(flightKey);
      }
    }
  }

  /**
   * Fast Boolean check used by SecurityService rate-limiting.
   * Returns true ONLY if the specific requesting Slave has an active, non-expired entitlement.
   * ALWAYS returns false for Master accounts.
   */
  public async isAgentCapabilityActive(agentIdentifier: string): Promise<boolean> {
    if (!agentIdentifier) return false;
    const ent = await this.getAgentCapability(agentIdentifier);
    return !!(ent && ent.status === 'active' && new Date(ent.expires_at).getTime() > Date.now());
  }

  /**
   * Activates or extends Capability Increment strictly for a designated Slave Account.
   * 
   * Strict Constraints:
   * - Must target a specific Slave Account.
   * - Cannot attach to Master Account under any circumstances.
   * - Must not modify Master/Slave allowance.
   * - Must not modify Master plan or validity.
   * - Must not affect any other Slave.
   */
  public async activateSlaveCapability(
    masterUserId: string,
    targetSlaveIdentifier: string,
    options?: {
      validityDays?: number;
      capabilityLevel?: number;
      batchId?: string;
    }
  ): Promise<CapabilityEntitlement> {
    if (!masterUserId) {
      throw new Error('Master user ID is required to authorize capability purchase.');
    }
    if (!targetSlaveIdentifier) {
      throw new Error('Capability purchase must target a specific Slave Account.');
    }

    const trimmedTarget = String(targetSlaveIdentifier).trim();

    // STRICT ARCHITECTURE RULE: Master accounts CAN NEVER be given a capability increment!
    if (trimmedTarget.toLowerCase() === 'master' || trimmedTarget.toLowerCase() === 'master-root') {
      throw new Error('Capability Increment Plans are strictly and exclusively for Slave accounts and cannot be attached to the Master account.');
    }

    const releaseLock = await this.acquireLock(targetSlaveIdentifier);

    try {
      const sb = getSupabaseClient();

      // 1. Authoritative Validation: Look up target in users table (strictly by id or agentId)
      let targetUser: any = null;
      const selectCols = 'id, agentId, name, master_id, is_master_primary, account_type, role, status, is_slave, is_master_slot, avatar';

      const { data: uById } = await sb
        .from('users')
        .select(selectCols)
        .eq('id', trimmedTarget)
        .maybeSingle();
      targetUser = uById;

      if (!targetUser) {
        const { data: uByAgentId } = await sb
          .from('users')
          .select(selectCols)
          .ilike('agentId', trimmedTarget)
          .maybeSingle();
        targetUser = uByAgentId;
      }
      if (!targetUser && trimmedTarget.startsWith('@')) {
        const stripped = trimmedTarget.slice(1);
        const { data: uByStripped } = await sb
          .from('users')
          .select(selectCols)
          .or(`id.eq.${stripped},agentId.ilike.${stripped}`)
          .maybeSingle();
        targetUser = uByStripped;
      }

      if (!targetUser) {
        throw new Error(`Target Slave Account '${targetSlaveIdentifier}' not found in database.`);
      }

      if (targetUser.status !== 'active') {
        throw new Error(`Target Slave Account '${targetUser.agentId || targetUser.id}' is ${targetUser.status} and cannot receive capability upgrades.`);
      }

      const isTargetSlave = Boolean(
        targetUser.account_type === 'slave' ||
        targetUser.is_slave === true ||
        (targetUser.master_id && targetUser.master_id !== targetUser.id && !targetUser.is_master_primary && !targetUser.is_master_slot && targetUser.account_type !== 'master_slot')
      );

      const isTargetMaster = !isTargetSlave && Boolean(
        targetUser.is_master_primary === true ||
        targetUser.account_type === 'master' ||
        targetUser.account_type === 'master_slot' ||
        targetUser.is_master_slot === true ||
        targetUser.id === masterUserId
      );

      if (isTargetMaster) {
        throw new Error('Capability Increment Plans are strictly and exclusively for Slave accounts and cannot be attached to the Master account.');
      }

      if (!isTargetSlave || !targetUser.master_id) {
        throw new Error('Capability Increment Plans can only be activated for deployed Slave accounts belonging to a Master fleet.');
      }

      // Resolve caller's root master ID & target's root master ID (max 5 hops) to enforce strict fleet boundary
      const walkRootMaster = async (startId: string): Promise<string> => {
        let curr = startId;
        for (let depth = 0; depth < 5; depth++) {
          const { data: rec } = await sb.from('users').select('id, master_id, is_master_primary').eq('id', curr).maybeSingle();
          if (rec?.master_id && rec.master_id !== curr && rec.is_master_primary !== true) {
            curr = rec.master_id;
          } else {
            break;
          }
        }
        return curr;
      };

      const [callerRootId, targetRootId] = await Promise.all([
        walkRootMaster(masterUserId),
        walkRootMaster(targetUser.master_id)
      ]);

      const belongsToCallerFleet = Boolean(
        targetUser.master_id === masterUserId ||
        targetUser.master_id === callerRootId ||
        targetRootId === callerRootId ||
        targetRootId === masterUserId
      );

      if (!belongsToCallerFleet) {
        throw new Error('Unauthorized: Target Slave Account does not belong to your Master fleet.');
      }

      const slaveUser = targetUser;

      // 2. Compute validity expiration
      const now = new Date();
      const validityDays = options?.validityDays && options.validityDays > 0 ? options.validityDays : 30;
      
      // If existing active entitlement exists, extend its expiry; otherwise set from now
      const existing = await this.getAgentCapability(slaveUser.id, true);
      const baseDate = (existing?.expires_at && new Date(existing.expires_at) > now)
        ? new Date(existing.expires_at)
        : now;
      const expiresAt = new Date(baseDate.getTime() + validityDays * 24 * 60 * 60 * 1000).toISOString();
      const nowIso = now.toISOString();

      const entitlementId = existing?.id || crypto.randomUUID();
      const agentIdKey = slaveUser.agentId || slaveUser.id;

      const entitlement: CapabilityEntitlement = {
        id: entitlementId,
        agent_id: agentIdKey,
        user_id: slaveUser.id,
        master_id: callerRootId,
        capability_level: options?.capabilityLevel || 1,
        status: 'active',
        created_at: existing?.created_at || nowIso,
        updated_at: nowIso,
        expires_at: expiresAt,
        metadata: {
          activated_by_master_id: masterUserId,
          target_slave_name: slaveUser.name,
          validity_days_extended: validityDays,
          upgraded_rate_limits: true
        }
      };

      // 3. Database Persistence: Write to master_plan_entitlements, capability_entitlements, and users
      let primarySaved = false;
      const writeErrors: string[] = [];

      try {
        const mpeRes = await sb.from('master_plan_entitlements').upsert({
          id: entitlement.id,
          master_account_id: slaveUser.id,
          plan_type: 'slave_capability',
          plan_name: 'Capability Increment Plan',
          status: entitlement.status,
          allowance_accounts: 1,
          tier: 'capability',
          created_at: entitlement.created_at,
          updated_at: entitlement.updated_at,
          expires_at: entitlement.expires_at,
          metadata: {
            ...entitlement.metadata,
            agent_id: agentIdKey,
            slave_user_id: slaveUser.id,
            master_id: callerRootId
          }
        }, { onConflict: 'master_account_id,plan_type' });
        if (mpeRes?.error) {
          writeErrors.push(mpeRes.error.message);
        } else {
          primarySaved = true;
        }
      } catch (mpeUpsertErr: any) {
        writeErrors.push(mpeUpsertErr?.message || 'master_plan_entitlements write failed');
      }

      // Step B: Update users table plan status for slave
      try {
        const userUpdRes = await sb.from('users').update({
          plan: 'slave_capability',
          plan_status: 'active',
          plan_expires_at: entitlement.expires_at,
          plan_created_at: entitlement.created_at,
          hasCapabilityIncrement: true
        }).eq('id', slaveUser.id);
        if (userUpdRes?.error) {
          writeErrors.push(userUpdRes.error.message);
        } else {
          primarySaved = true;
          invalidateUserRecordCache(slaveUser.id);
        }
      } catch (uErr: any) {
        writeErrors.push(uErr?.message || 'users update failed');
      }

      // Step C: Write to capability_entitlements table
      try {
        const capUpsertRes = await sb.from('capability_entitlements').upsert({
          id: entitlement.id,
          agent_id: entitlement.agent_id,
          user_id: entitlement.user_id,
          master_id: entitlement.master_id,
          capability_level: entitlement.capability_level,
          status: entitlement.status,
          created_at: entitlement.created_at,
          updated_at: entitlement.updated_at,
          expires_at: entitlement.expires_at,
          metadata: entitlement.metadata
        }, { onConflict: 'agent_id' });
        if (capUpsertRes?.error) {
          writeErrors.push(capUpsertRes.error.message);
        } else {
          primarySaved = true;
        }
      } catch (upsertErr: any) {
        writeErrors.push(upsertErr?.message || 'capability_entitlements write failed');
      }

      if (!primarySaved) {
        throw new Error(`Failed to persist capability entitlement to database: ${writeErrors.join('; ')}`);
      }

      // 4. Log persistent audit record in external_events
      try {
        const targetAccountObj = {
          id: slaveUser.id,
          agent_id: agentIdKey,
          name: slaveUser.name || agentIdKey,
          avatar: slaveUser.avatar,
          isDeployed: true,
          status: slaveUser.status || 'active'
        };

        await sb.from('external_events').insert({
          id: crypto.randomUUID(),
          user_id: slaveUser.id,
          type: 'SLAVE_CAPABILITY_ACTIVATED',
          details: JSON.stringify({
            ...entitlement,
            ...(options?.batchId ? { batch_id: options.batchId } : {}),
            target_slave_id: slaveUser.id,
            target_account_ids: [slaveUser.id],
            target_accounts: [targetAccountObj]
          }),
          created_at: nowIso
        });
      } catch (eventErr) {}

      // 5. Invalidate and refresh cache strictly for this Slave (Leave Master & other Slaves untouched)
      this.negativeCache.delete(targetSlaveIdentifier);
      this.negativeCache.delete(trimmedTarget);
      this.negativeCache.delete(trimmedTarget.toLowerCase());
      if (entitlement.agent_id) {
        this.negativeCache.delete(entitlement.agent_id);
        this.negativeCache.delete(entitlement.agent_id.toLowerCase());
      }
      if (entitlement.user_id) {
        this.negativeCache.delete(entitlement.user_id);
        this.negativeCache.delete(entitlement.user_id.toLowerCase());
      }
      this.capabilityCache.set(entitlement.agent_id, entitlement);
      if (entitlement.user_id) {
        this.capabilityCache.set(entitlement.user_id, entitlement);
      }

      return entitlement;
    } finally {
      releaseLock();
    }
  }

  /**
   * Invalidates capability cache for a specific Slave.
   * Does not alter or invalidate unrelated accounts.
   */
  public invalidateCapabilityCache(agentIdentifier: string): void {
    if (!agentIdentifier) return;
    const str = String(agentIdentifier).trim();
    this.capabilityCache.delete(str);
    this.capabilityCache.delete(str.toLowerCase());
    this.negativeCache.delete(str);
    this.negativeCache.delete(str.toLowerCase());
  }
}
