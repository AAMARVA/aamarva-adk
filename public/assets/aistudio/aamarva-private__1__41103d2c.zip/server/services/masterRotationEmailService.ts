import dns from 'node:dns';
import https from 'node:https';
import crypto from 'node:crypto';
import { config } from '../config.js';

try {
  dns.setDefaultResultOrder('ipv4first');
} catch {}

const masterBrevoHttpsAgent = new https.Agent({
  keepAlive: true,
  keepAliveMsecs: 15000,
  maxSockets: 16,
  maxFreeSockets: 4,
});

function postMasterBrevoApiOnce(apiKey: string, body: string): Promise<{ status: number; bodyText: string }> {
  return new Promise((resolve, reject) => {
    const req = https.request(
      {
        hostname: 'api.brevo.com',
        port: 443,
        path: '/v3/smtp/email',
        method: 'POST',
        agent: masterBrevoHttpsAgent,
        family: 4,
        timeout: 10000,
        headers: {
          'accept': 'application/json',
          'content-type': 'application/json',
          'content-length': Buffer.byteLength(body),
          'api-key': apiKey,
        },
      },
      (res) => {
        const chunks: Buffer[] = [];
        res.on('data', (chunk) => chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)));
        res.on('end', () => {
          resolve({
            status: res.statusCode || 500,
            bodyText: Buffer.concat(chunks).toString('utf8'),
          });
        });
      }
    );

    req.on('timeout', () => {
      req.destroy(new Error('Master Rotation Email Brevo API request timed out after 10000ms'));
    });
    req.on('error', (err) => reject(err));
    req.write(body);
    req.end();
  });
}

async function postMasterBrevoApi(apiKey: string, payload: Record<string, any>): Promise<{ status: number; bodyText: string }> {
  const body = JSON.stringify(payload);
  try {
    return await postMasterBrevoApiOnce(apiKey, body);
  } catch (err: any) {
    const code = String(err?.code || '');
    const msg = String(err?.message || '').toLowerCase();
    if (code === 'ECONNRESET' || code === 'EPIPE' || msg.includes('socket hang up')) {
      return await postMasterBrevoApiOnce(apiKey, body);
    }
    throw err;
  }
}

export interface CascadeRotationSlaveTarget {
  id: string;
  agentId: string;
  name: string;
}

export interface RotatedSlaveCredential {
  id?: string;
  agentId: string;
  name: string;
  apiKey: string;
}

function escapeHtml(value: string): string {
  return String(value || '').replace(/[&<>"']/g, (ch) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;',
  }[ch] || ch));
}

function parseAddress(formatted: string, defaultName?: string): { name?: string; email: string } {
  if (!formatted) return { name: defaultName, email: '' };
  const match = formatted.match(/^(?:"?([^"]*)"?\s+)?<([^>]+)>$/);
  if (match) {
    const name = match[1]?.trim() || defaultName;
    const email = match[2]?.trim();
    return name ? { name, email } : { email };
  }
  const email = formatted.trim();
  return defaultName ? { name: defaultName, email } : { email };
}

function resolveTransportConfig(): { apiKey: string; from: string; replyTo: string } {
  const apiKey = process.env.BREVO_API_KEY || config.brevoApiKey;
  const from = process.env.EMAIL_FROM || config.emailFrom || 'AAMARVA <no-reply@aamarva.com>';
  const replyTo = process.env.EMAIL_REPLY_TO || config.emailReplyTo || 'AAMARVA Support <support@aamarva.com>';

  if (!apiKey || !apiKey.trim()) {
    console.error('[MASTER_ROTATION_EMAIL_SERVICE] Missing BREVO_API_KEY configuration.');
    throw new Error('BREVO_API_KEY environment variable is not configured.');
  }

  return {
    apiKey: apiKey.trim(),
    from: from.trim(),
    replyTo: replyTo.trim(),
  };
}

async function dispatchMasterRotationEmail(params: {
  toEmail: string;
  toName?: string;
  subject: string;
  html: string;
}): Promise<{ messageId?: string }> {
  const { apiKey, from, replyTo } = resolveTransportConfig();
  const startedAt = Date.now();

  const senderObj = parseAddress(from, 'AAMARVA');
  const replyToObj = parseAddress(replyTo, 'AAMARVA Support');
  const cleanToEmail = String(params.toEmail || '').trim();
  const recipientObj: { email: string; name?: string } = { email: cleanToEmail };
  if (params.toName?.trim()) {
    recipientObj.name = params.toName.trim();
  }

  const payload = {
    sender: senderObj,
    to: [recipientObj],
    replyTo: replyToObj,
    subject: params.subject,
    htmlContent: params.html,
    textContent: params.html ? params.html.replace(/<[^>]*>?/gm, ' ').replace(/\s+/g, ' ').trim() : '',
    tags: ['transactional', 'copy_master_rotation'],
    headers: {
      'X-Entity-Ref-ID': crypto.randomUUID(),
      'X-Priority': '1',
      'Importance': 'High',
    },
  };

  console.log(`[MASTER_ROTATION_EMAIL_SERVICE] Dispatching Master Copy Rotation email to ${cleanToEmail} | Subject: ${params.subject}`);

  const { status, bodyText } = await postMasterBrevoApi(apiKey, payload);

  if (status < 200 || status >= 300) {
    let errorDetails = bodyText;
    try {
      errorDetails = JSON.stringify(JSON.parse(bodyText));
    } catch {}
    console.error(`[MASTER_ROTATION_EMAIL_SERVICE] Brevo API error HTTP ${status} (${Date.now() - startedAt}ms):`, errorDetails);
    throw new Error(`Master Rotation Email dispatch failed (HTTP ${status}): ${errorDetails}`);
  }

  let result: { messageId?: string } = {};
  try {
    result = JSON.parse(bodyText) as { messageId?: string };
  } catch {}
  console.log(`[MASTER_ROTATION_EMAIL_SERVICE] Dispatched email in ${Date.now() - startedAt}ms to ${cleanToEmail} | messageId=${result?.messageId || 'ok'}`);
  return result;
}

/**
 * Dedicated Copy Master API Key Rotation verification email.
 * Sends ONE single email to the Pioneer Master using the identical confirmation link + passkey workflow,
 * while listing every selected Slave account queued for cascade API key rotation upon confirmation.
 */
export async function sendMasterCascadeRotationVerificationEmail(params: {
  toEmail: string;
  toName?: string;
  masterAgentId?: string;
  token: string;
  appUrl: string;
  syncPolicy?: string | null;
  cascadeSlaves: CascadeRotationSlaveTarget[];
}): Promise<{ messageId?: string }> {
  const baseUrl = String(params.appUrl || 'https://aamarva.com').replace(/\/+$/, '');
  const confirmLink = `${baseUrl}/confirm-api-key-rotation?token=${encodeURIComponent(params.token)}`;
  const policyLabel = params.syncPolicy === 'one_time' ? 'ONE-TIME COPY' : 'COPY FOREVER';
  const safeMasterName = escapeHtml(params.toName || params.masterAgentId || 'Master Account');
  const safeMasterHandle = params.masterAgentId ? `@${escapeHtml(params.masterAgentId.replace(/^@/, ''))}` : '';

  const hasMoreThanTenQueued = params.cascadeSlaves.length > 10;

  const slaveRowsHtml = params.cascadeSlaves
    .map((slave, idx) => {
      const cleanHandle = escapeHtml(String(slave.agentId || '').replace(/^@/, ''));
      const cleanName = escapeHtml(slave.name || slave.agentId || `Slave ${idx + 1}`);
      const cleanAccountId = escapeHtml(slave.id || '');
      return `
        <tr>
          <td style="padding: 8px 10px; border-bottom: 1px solid #141414; font-size: 11px; line-height: 18px; font-weight: bold; white-space: nowrap;">#${idx + 1}</td>
          <td style="padding: 8px 10px; border-bottom: 1px solid #141414; font-size: 11px; line-height: 18px; font-weight: bold; white-space: nowrap;">${cleanName}</td>
          <td style="padding: 8px 10px; border-bottom: 1px solid #141414; font-size: 11px; line-height: 18px; font-family: monospace; white-space: nowrap;">@${cleanHandle}</td>
          <td style="padding: 8px 10px; border-bottom: 1px solid #141414; font-size: 10px; line-height: 18px; font-family: monospace; color: #444; white-space: nowrap;">${cleanAccountId}</td>
        </tr>
      `;
    })
    .join('');

  const queuedTableScrollStyle = hasMoreThanTenQueued
    ? 'max-height: 382px; overflow-y: auto; overflow-x: auto;'
    : 'overflow-x: auto;';

  const html = `
    <div style="font-family: monospace, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #141414; max-width: 640px; margin: 0 auto; border: 4px solid #141414; padding: 28px; background: #ffffff; box-shadow: 8px 8px 0px 0px #141414;">
      <div style="border-bottom: 2px solid #141414; padding-bottom: 12px; margin-bottom: 18px;">
        <span style="display: inline-block; background: #141414; color: #ffffff; font-size: 10px; font-weight: bold; padding: 3px 8px; text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 8px;">
          COPY MASTER CASCADE // ${policyLabel}
        </span>
        <h2 style="text-transform: uppercase; letter-spacing: 0.08em; margin: 0; color: #141414; font-size: 18px;">
          CONFIRM MASTER &amp; SLAVE API KEY ROTATION
        </h2>
      </div>

      <p style="font-size: 13px;">Hello <strong>${safeMasterName}</strong>${safeMasterHandle ? ` (${safeMasterHandle})` : ''},</p>
      <p style="font-size: 13px;">
        A request was initiated to revoke and rotate API keys on your Pioneer Master account (<strong>${escapeHtml(params.toEmail)}</strong>). Because <strong>Copy Master &rarr; API Key Rotation</strong> is active, confirming this verification link will trigger cascade key revocation and reissue for all <strong>${params.cascadeSlaves.length}</strong> selected slave account${params.cascadeSlaves.length === 1 ? '' : 's'} listed below.
      </p>

      <div style="border: 2px solid #141414; margin: 18px 0; background: #ffffff;">
        <div style="background: #141414; color: #ffffff; padding: 8px 12px; font-size: 11px; font-weight: bold; text-transform: uppercase; letter-spacing: 0.06em;">
          Slave Accounts Queued for Cascade Rotation (${params.cascadeSlaves.length})
        </div>
        <div style="${queuedTableScrollStyle}">
          <table style="width: 100%; border-collapse: collapse; text-align: left;">
            <thead>
              <tr style="background: #F4F3F0; border-bottom: 2px solid #141414;">
                <th style="padding: 7px 10px; font-size: 10px; line-height: 16px; text-transform: uppercase; white-space: nowrap; position: sticky; top: 0; background: #F4F3F0;">#</th>
                <th style="padding: 7px 10px; font-size: 10px; line-height: 16px; text-transform: uppercase; white-space: nowrap; position: sticky; top: 0; background: #F4F3F0;">Account Name</th>
                <th style="padding: 7px 10px; font-size: 10px; line-height: 16px; text-transform: uppercase; white-space: nowrap; position: sticky; top: 0; background: #F4F3F0;">Agent ID</th>
                <th style="padding: 7px 10px; font-size: 10px; line-height: 16px; text-transform: uppercase; white-space: nowrap; position: sticky; top: 0; background: #F4F3F0;">Account UUID</th>
              </tr>
            </thead>
            <tbody>
              ${slaveRowsHtml}
            </tbody>
          </table>
        </div>
      </div>

      <div style="border: 2px solid #141414; padding: 16px; margin: 20px 0; background: #F4F3F0;">
        <h3 style="margin-top: 0; text-transform: uppercase; font-size: 13px; color: #141414;">AUTHORIZE CASCADE KEY REVOCATION &amp; ROTATION</h3>
        <p style="font-size: 12px; margin-bottom: 14px; color: #141414;">
          Click below to verify via passkey and immediately revoke prior keys and issue fresh credentials for all ${params.cascadeSlaves.length} queued slave account${params.cascadeSlaves.length === 1 ? '' : 's'}:
        </p>
        <div style="text-align: center;">
          <a href="${confirmLink}" style="display: inline-block; padding: 12px 24px; background-color: #141414; color: #ffffff; font-size: 13px; font-weight: bold; text-decoration: none; text-transform: uppercase; border: 2px solid #141414; box-shadow: 3px 3px 0px 0px #141414;">
            Confirm Cascade API Key Rotation
          </a>
        </div>
      </div>

      <p style="font-size: 12px; color: #555;">If the button above does not work, copy and paste this verification URL into your browser:</p>
      <p style="font-size: 11px; word-break: break-all; background: #f4f4f4; padding: 8px; border: 1px solid #141414; margin: 8px 0;">
        ${confirmLink}
      </p>
      <p style="font-size: 11px; color: #777;">
        This single-use verification link expires in 30 minutes and requires hardware passkey verification. If you did not authorize this revocation, ignore this email and all slave keys will remain untouched.
      </p>
      <hr style="border: none; border-top: 2px solid #141414; margin: 20px 0;" />
      <p style="font-size: 11px; color: #141414; text-transform: uppercase; margin: 0;">AAMARVA | Autonomous Agent Command Protocol &amp; Infrastructure</p>
    </div>
  `;

  return await dispatchMasterRotationEmail({
    toEmail: params.toEmail,
    toName: params.toName,
    subject: `Confirm Cascade API Key Rotation (${params.cascadeSlaves.length} Slave${params.cascadeSlaves.length === 1 ? '' : 's'}) [Ref: ${Date.now().toString().slice(-6)}]`,
    html,
  });
}

/**
 * Dedicated post-confirmation credentials email for Copy Master Cascade API Key Rotation.
 * Includes Account Name, Account ID (agentId), and newly issued API Key for each rotated agent.
 */
export async function sendMasterCascadeRotatedCredentialsEmail(params: {
  toEmail: string;
  toName?: string;
  masterAgentId?: string;
  rotatedSlaves: RotatedSlaveCredential[];
}): Promise<{ messageId?: string } | void> {
  if (!Array.isArray(params.rotatedSlaves) || params.rotatedSlaves.length === 0) return;

  const safeMasterName = escapeHtml(params.toName || params.masterAgentId || 'Master Account');
  const hasMoreThanTenRotated = params.rotatedSlaves.length > 10;

  const cardsHtml = params.rotatedSlaves
    .map((slave, idx) => {
      const cleanName = escapeHtml(slave.name || slave.agentId || `Slave ${idx + 1}`);
      const cleanAgentId = escapeHtml(slave.agentId || '');
      const cleanApiKey = escapeHtml(slave.apiKey || '');
      return `
        <div style="border: 2px solid #141414; padding: 10px 12px; margin-bottom: 8px; background: #F8F7F4;">
          <div style="font-size: 11px; line-height: 16px; font-weight: bold; text-transform: uppercase; color: #141414; margin-bottom: 6px; border-bottom: 1px solid #141414; padding-bottom: 4px;">
            #${idx + 1} &mdash; ${cleanName}
          </div>
          <div style="margin-bottom: 6px;">
            <div style="font-size: 9px; line-height: 13px; font-weight: bold; text-transform: uppercase; color: #555; margin-bottom: 2px;">Account ID (Agent ID)</div>
            <div style="font-size: 11px; line-height: 16px; font-family: monospace; font-weight: bold; background: #ffffff; border: 1px solid #141414; padding: 5px 8px; word-break: break-all;">
              ${cleanAgentId}
            </div>
          </div>
          <div>
            <div style="font-size: 9px; line-height: 13px; font-weight: bold; text-transform: uppercase; color: #555; margin-bottom: 2px;">New API Key (Secret)</div>
            <div style="font-size: 11px; line-height: 16px; font-family: monospace; font-weight: bold; background: #141414; color: #ffffff; padding: 6px 8px; word-break: break-all;">
              ${cleanApiKey}
            </div>
          </div>
        </div>
      `;
    })
    .join('');

  const rotatedScrollStyle = hasMoreThanTenRotated
    ? 'max-height: 1410px; overflow-y: auto; padding: 10px;'
    : 'padding: 10px;';

  const rotatedScrollNoticeHtml = hasMoreThanTenRotated
    ? `<div style="background: #F4F3F0; border-top: 2px solid #141414; padding: 6px 12px; font-size: 10px; font-weight: bold; text-transform: uppercase; letter-spacing: 0.05em; color: #141414;">
         Showing 10 slave accounts &mdash; Scroll inside box to view all ${params.rotatedSlaves.length} rotated credentials
       </div>`
    : '';

  const html = `
    <div style="font-family: monospace, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #141414; max-width: 640px; margin: 0 auto; border: 4px solid #141414; padding: 28px; background: #ffffff; box-shadow: 8px 8px 0px 0px #141414;">
      <h2 style="text-transform: uppercase; letter-spacing: 0.08em; margin-top: 0; border-bottom: 2px solid #141414; padding-bottom: 12px; color: #141414; font-size: 18px;">
        CASCADE API KEY ROTATION COMPLETE
      </h2>
      <p style="font-size: 13px;">Hello <strong>${safeMasterName}</strong>,</p>
      <p style="font-size: 13px;">
        Your Master cascade API key revocation and rotation protocol succeeded. New credentials (Account ID &amp; API Key) have been issued for all <strong>${params.rotatedSlaves.length}</strong> slave account${params.rotatedSlaves.length === 1 ? '' : 's'} below:
      </p>

      <div style="border: 2px solid #141414; margin: 18px 0; background: #ffffff;">
        <div style="background: #141414; color: #ffffff; padding: 8px 12px; font-size: 11px; font-weight: bold; text-transform: uppercase; letter-spacing: 0.06em;">
          Rotated Slave Credentials (${params.rotatedSlaves.length})
        </div>
        <div style="${rotatedScrollStyle}">
          ${cardsHtml}
        </div>
        ${rotatedScrollNoticeHtml}
      </div>

      <p style="font-size: 11px; color: #555;">
        Store these credentials securely. All previous API keys for the agents listed above have been permanently revoked.
      </p>
      <hr style="border: none; border-top: 2px solid #141414; margin: 20px 0;" />
      <p style="font-size: 11px; color: #141414; text-transform: uppercase; margin: 0;">AAMARVA | Autonomous Agent Command Protocol &amp; Infrastructure</p>
    </div>
  `;

  return await dispatchMasterRotationEmail({
    toEmail: params.toEmail,
    toName: params.toName,
    subject: `Cascade API Keys Rotated (${params.rotatedSlaves.length} Slave Account${params.rotatedSlaves.length === 1 ? '' : 's'}) [Ref: ${Date.now().toString().slice(-6)}]`,
    html,
  });
}

