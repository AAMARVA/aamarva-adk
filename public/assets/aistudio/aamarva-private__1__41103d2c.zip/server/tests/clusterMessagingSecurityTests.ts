import express from 'express';
import http from 'http';
import cookieParser from 'cookie-parser';
import crypto from 'crypto';
import clusterRouter, { getClusterTables } from '../routes/clusterRoutes';
import aamarvaRouter from '../routes/aamarvaRoutes';
import { getSupabaseClient } from '../supabase';
import { registerUser, createHumanSession } from '../authService';
import { generateE2EEKeyPair, generateAgentCryptoIdentity } from '../../src/lib/e2ee';
import {
  generateClusterGroupKey,
  encryptClusterMessage,
  decryptClusterMessage,
  wrapClusterGroupKeyForMember,
  unwrapClusterGroupKeyFromPackage,
  computeClusterRosterHash,
  computeClusterAudienceHash,
  signClusterMessageEnvelope
} from '../../src/lib/clusterCrypto';

export async function runClusterMessagingSecurityTests(): Promise<Record<string, { status: 'PASSED' | 'FAILED'; reason?: string }>> {
  console.log('\n=== AAMARVA SHARED GROUP-KEY CLUSTER MESSAGING SECURITY SUITE ===\n');
  const results: Record<string, { status: 'PASSED' | 'FAILED'; reason?: string }> = {};

  const recordResult = (id: string, success: boolean, reason?: string) => {
    results[id] = { status: success ? 'PASSED' : 'FAILED', reason };
    console.log(`[${success ? 'PASSED' : 'FAILED'}] ${id}${reason ? `: ${reason}` : ''}`);
  };

  try {
    // -------------------------------------------------------------------------
    // SECTION 1: Pure Cryptographic Shared Group-Key E2EE Verification
    // -------------------------------------------------------------------------
    const ownerPair = await generateE2EEKeyPair();
    const recipientAPair = await generateE2EEKeyPair();
    const clusterId = 'test-cluster-group-key';
    const epoch = 1;

    // 1. Generate shared group key
    const groupKeyData = await generateClusterGroupKey();
    recordResult('test_generate_group_key', Boolean(groupKeyData.key && groupKeyData.rawKey), 'Generated 256-bit AES-GCM group key');

    // 2. Encrypt once using shared group key
    const plaintext = 'Secret cluster shared message';
    const envelope = await encryptClusterMessage(
      plaintext,
      groupKeyData.key,
      'AMR-OWNER',
      clusterId,
      epoch
    );
    recordResult('test_encrypt_cluster_message', Boolean(envelope.ciphertext && envelope.nonce), 'Encrypted cluster message once with shared group key');

    // 3. Authorized Member Decryption
    const decryptedA = await decryptClusterMessage(
      envelope.ciphertext,
      envelope.nonce,
      groupKeyData.key,
      'AMR-OWNER',
      clusterId,
      epoch,
      envelope.version
    );
    recordResult('test_authorized_decryption_success', decryptedA === plaintext, 'Authorized member decrypted cluster message successfully');

    // 4. Key Distribution Wrapping & Unwrapping
    const wrappedPackage = await wrapClusterGroupKeyForMember(
      groupKeyData.rawKey,
      ownerPair.privateKey,
      recipientAPair.publicKey,
      clusterId,
      epoch
    );
    recordResult('test_wrap_group_key', Boolean(wrappedPackage.key && wrappedPackage.iv), 'Wrapped group key for member');

    const unwrapped = await unwrapClusterGroupKeyFromPackage(
      wrappedPackage,
      recipientAPair.privateKey,
      ownerPair.publicKey,
      clusterId,
      epoch
    );
    recordResult('test_unwrap_group_key', Boolean(unwrapped.groupKey), 'Unwrapped group key successfully');

    // 5. Decrypt using unwrapped key
    const decryptedWrapped = await decryptClusterMessage(
      envelope.ciphertext,
      envelope.nonce,
      unwrapped.groupKey,
      'AMR-OWNER',
      clusterId,
      epoch,
      envelope.version
    );
    recordResult('test_decrypted_with_unwrapped_key', decryptedWrapped === plaintext, 'Decrypted cluster message using unwrapped group key');

    // 6. Unauthorized Member Rejection (Wrong Group Key)
    const wrongGroupKeyData = await generateClusterGroupKey();
    let wrongKeyFailed = false;
    try {
      await decryptClusterMessage(
        envelope.ciphertext,
        envelope.nonce,
        wrongGroupKeyData.key,
        'AMR-OWNER',
        clusterId,
        epoch,
        envelope.version
      );
    } catch {
      wrongKeyFailed = true;
    }
    recordResult('test_unauthorized_group_key_rejection', wrongKeyFailed, 'Unauthorized user without group key strictly rejected');

    // 7. Invalid Ciphertext Rejection
    let invalidCiphertextFailed = false;
    try {
      await decryptClusterMessage(
        'not-valid-ciphertext',
        envelope.nonce,
        groupKeyData.key,
        'AMR-OWNER',
        clusterId,
        epoch,
        envelope.version
      );
    } catch {
      invalidCiphertextFailed = true;
    }
    recordResult('test_invalid_ciphertext_rejection', invalidCiphertextFailed, 'Invalid ciphertext strictly rejected');

    // -------------------------------------------------------------------------
    // SECTION 2: Endpoint Enforcement Verification (HTTP Protocol & Authorization)
    // -------------------------------------------------------------------------
    const app = express();
    app.use(cookieParser());
    app.use(express.json());
    app.use('/api', aamarvaRouter);
    app.use('/api', clusterRouter);

    const server = http.createServer(app);
    await new Promise<void>((resolve) => server.listen(0, resolve));
    const port = (server.address() as any).port;
    const baseUrl = `http://127.0.0.1:${port}`;

    const helperFetch = async (endpoint: string, options: any = {}) => {
      const res = await fetch(`${baseUrl}${endpoint}`, {
        ...options,
        headers: {
          'Content-Type': 'application/json',
          ...(options.headers || {})
        }
      });
      const text = await res.text();
      let json: any = null;
      try {
        json = JSON.parse(text);
      } catch {}
      return { status: res.status, json, text };
    };

    const ts = Date.now();
    const supabase = getSupabaseClient();
    const tables = await getClusterTables(supabase);

    // Register test cluster owner and an active peer member
    const regOwner = await registerUser({ email: `msg_owner_${ts}@aamarva.test`, password: 'Password123!', agentName: 'Msg Owner' });
    const ownerUser = regOwner.user;
    const ownerSession = await createHumanSession(ownerUser.id);
    const ownerCookie = `aamarva_human_session=${ownerSession}`;

    // Set owner's registered E2EE public key and fingerprint
    const ownerECKey = await generateE2EEKeyPair();
    await supabase.auth.admin.updateUserById(ownerUser.id, {
      user_metadata: {
        e2eePublicKey: ownerECKey.publicKey,
        e2eePublicKeyFingerprint: ownerECKey.fingerprint
      }
    });

    const regPeer = await registerUser({ email: `msg_peer_${ts}@aamarva.test`, password: 'Password123!', agentName: 'Msg Peer' });
    const peerUser = regPeer.user;
    const peerECKey = await generateE2EEKeyPair();
    await supabase.auth.admin.updateUserById(peerUser.id, {
      user_metadata: {
        e2eePublicKey: peerECKey.publicKey,
        e2eePublicKeyFingerprint: peerECKey.fingerprint
      }
    });

    // Create a test cluster
    const clusterRowId = `cluster_${crypto.randomUUID()}`;
    await supabase.from(tables.clusters).insert({
      id: clusterRowId,
      name: 'Security Test Cluster',
      ownerUserId: ownerUser.id,
      ownerAgentId: ownerUser.agentId,
      status: 'active',
      createdAt: new Date().toISOString()
    });

    // Add owner as active member
    await supabase.from(tables.members).insert({
      id: `mem_${crypto.randomUUID()}`,
      clusterId: clusterRowId,
      userId: ownerUser.id,
      agentId: ownerUser.agentId,
      role: 'owner',
      status: 'active'
    });

    // Add peer as active member
    await supabase.from(tables.members).insert({
      id: `mem_${crypto.randomUUID()}`,
      clusterId: clusterRowId,
      userId: peerUser.id,
      agentId: peerUser.agentId,
      role: 'member',
      status: 'active'
    });

    // 8. Endpoint rejects version !== 2
    const resV1 = await helperFetch(`/api/clusters/${clusterRowId}/messages`, {
      method: 'POST',
      headers: { Cookie: ownerCookie },
      body: JSON.stringify({
        ciphertext: envelope.ciphertext,
        nonce: envelope.nonce,
        version: 1,
        keyEpoch: 1
      })
    });
    recordResult('endpoint_rejects_version_1', resV1.status === 400 && resV1.json?.error?.code === 'UNSUPPORTED_VERSION', `Status: ${resV1.status}, code: ${resV1.json?.error?.code}`);

    // 9. Endpoint accepts valid shared-key message with recipients
    const resValidMsg = await helperFetch(`/api/clusters/${clusterRowId}/messages`, {
      method: 'POST',
      headers: { Cookie: ownerCookie },
      body: JSON.stringify({
        ciphertext: envelope.ciphertext,
        nonce: envelope.nonce,
        version: 2,
        keyEpoch: 1,
        recipientAgentIds: [peerUser.agentId]
      })
    });
    recordResult('endpoint_accepts_valid_shared_key_message', resValidMsg.status === 201 && resValidMsg.json?.success === true, `Status: ${resValidMsg.status}, id: ${resValidMsg.json?.data?.id}`);

    // 10. Verify GET messages returns recipients for each message
    const resGetMsgs = await helperFetch(`/api/clusters/${clusterRowId}/messages`, {
      method: 'GET',
      headers: { Cookie: ownerCookie }
    });
    const fetchedMsgs = resGetMsgs.json?.data || [];
    const hasRecipientsField = fetchedMsgs.length > 0 && fetchedMsgs.every((m: any) => Array.isArray(m.recipients));
    recordResult(
      'endpoint_returns_recipients_for_each_message',
      resGetMsgs.status === 200 && hasRecipientsField,
      `Status: ${resGetMsgs.status}, messages count: ${fetchedMsgs.length}`
    );

    // 11. Key distribution and rotation endpoints test
    const resDist = await helperFetch(`/api/clusters/${clusterRowId}/key-distribution`, {
      method: 'POST',
      headers: { Cookie: ownerCookie },
      body: JSON.stringify({
        epoch: 1,
        keyFingerprint: groupKeyData.fingerprint,
        distributions: [
          {
            recipientAgentId: peerUser.agentId,
            encryptedKeyPackage: wrappedPackage
          }
        ]
      })
    });
    recordResult('endpoint_key_distribution_success', resDist.status === 201 && resDist.json?.success === true, `Status: ${resDist.status}`);

    const resRotate = await helperFetch(`/api/clusters/${clusterRowId}/rotate-key`, {
      method: 'POST',
      headers: { Cookie: ownerCookie },
      body: JSON.stringify({
        nextEpoch: 2,
        keyFingerprint: 'ROTATED_FP',
        distributions: [
          {
            recipientAgentId: peerUser.agentId,
            encryptedKeyPackage: wrappedPackage
          }
        ]
      })
    });
    recordResult('endpoint_rotate_key_success', resRotate.status === 200 && resRotate.json?.success === true, `Status: ${resRotate.status}`);

    // -------------------------------------------------------------------------
    // SECTION 3: Hardened Pre-Flight Gate, Epoch Immutability & O(1) Subgroup Isolation
    // -------------------------------------------------------------------------
    // Setup 3-member cluster: owner + peerA + peerB
    const ownerFullId = await generateAgentCryptoIdentity(ownerUser.agentId);
    await supabase.auth.admin.updateUserById(ownerUser.id, {
      user_metadata: {
        e2eePublicKey: ownerFullId.e2eePublicKey,
        e2eePublicKeyFingerprint: ownerFullId.fingerprint,
        e2eeIdentityKey: ownerFullId.identityPublicKey,
        e2eeKeyEpoch: 1
      }
    });

    const regPeerB = await registerUser({ email: `msg_peer_b_${ts}@aamarva.test`, password: 'Password123!', agentName: 'Peer B Excluded' });
    const peerBUser = regPeerB.user;
    const peerBFullId = await generateAgentCryptoIdentity(peerBUser.agentId);
    await supabase.auth.admin.updateUserById(peerBUser.id, {
      user_metadata: {
        e2eePublicKey: peerBFullId.e2eePublicKey,
        e2eePublicKeyFingerprint: peerBFullId.fingerprint,
        e2eeIdentityKey: peerBFullId.identityPublicKey,
        e2eeKeyEpoch: 1
      }
    });

    const peerAFullId = await generateAgentCryptoIdentity(peerUser.agentId);
    await supabase.auth.admin.updateUserById(peerUser.id, {
      user_metadata: {
        e2eePublicKey: peerAFullId.e2eePublicKey,
        e2eePublicKeyFingerprint: peerAFullId.fingerprint,
        e2eeIdentityKey: peerAFullId.identityPublicKey,
        e2eeKeyEpoch: 1
      }
    });
    const peerACookie = `aamarva_human_session=${await createHumanSession(peerUser.id)}`;
    const peerBCookie = `aamarva_human_session=${await createHumanSession(peerBUser.id)}`;

    const hardenedClusterId = `cluster_hardened_${crypto.randomUUID()}`;
    await supabase.from(tables.clusters).insert({
      id: hardenedClusterId,
      name: 'Hardened Cluster',
      ownerUserId: ownerUser.id,
      ownerAgentId: ownerUser.agentId,
      status: 'active',
      createdAt: new Date().toISOString()
    });
    await supabase.from(tables.members).insert([
      { id: `mem_${crypto.randomUUID()}`, clusterId: hardenedClusterId, userId: ownerUser.id, agentId: ownerUser.agentId, role: 'owner', status: 'active' },
      { id: `mem_${crypto.randomUUID()}`, clusterId: hardenedClusterId, userId: peerUser.id, agentId: peerUser.agentId, role: 'member', status: 'active' },
      { id: `mem_${crypto.randomUUID()}`, clusterId: hardenedClusterId, userId: peerBUser.id, agentId: peerBUser.agentId, role: 'member', status: 'active' }
    ]);

    const all3Ids = [ownerUser.agentId, peerUser.agentId, peerBUser.agentId];
    const rosterHash3 = await computeClusterRosterHash(all3Ids);
    const allGroupKey = await generateClusterGroupKey();

    // 12. Seal Epoch 1 with cluster-wide key for ALL 3 members
    const allDistPackages = await Promise.all([
      { user: ownerUser, fp: ownerFullId.fingerprint, pub: ownerFullId.e2eePublicKey },
      { user: peerUser, fp: peerAFullId.fingerprint, pub: peerAFullId.e2eePublicKey },
      { user: peerBUser, fp: peerBFullId.fingerprint, pub: peerBFullId.e2eePublicKey }
    ].map(async (m) => ({
      recipientAgentId: m.user.agentId,
      senderAgentId: ownerUser.agentId,
      senderPublicKey: ownerFullId.e2eePublicKey,
      recipientKeyEpoch: 1,
      encryptedKeyPackage: await wrapClusterGroupKeyForMember(
        allGroupKey.rawKey,
        ownerFullId.e2eePrivateKey,
        m.pub,
        hardenedClusterId,
        1,
        {
          audienceHash: 'ALL',
          keyFingerprint: allGroupKey.fingerprint,
          rosterHash: rosterHash3,
          senderAgentId: ownerUser.agentId,
          senderPublicKey: ownerFullId.e2eePublicKey,
          recipientAgentId: m.user.agentId,
          recipientKeyFingerprint: m.fp,
          recipientKeyEpoch: 1
        }
      )
    })));

    const resSealEpoch1 = await helperFetch(`/api/clusters/${hardenedClusterId}/key-distribution`, {
      method: 'POST',
      headers: { Cookie: ownerCookie },
      body: JSON.stringify({
        epoch: 1,
        audienceHash: 'ALL',
        rosterHash: rosterHash3,
        keyFingerprint: allGroupKey.fingerprint,
        distributions: allDistPackages
      })
    });
    recordResult('hardened_seal_epoch1_success', resSealEpoch1.status === 201, `Status: ${resSealEpoch1.status}`);

    // 13. Sealed Epoch Immutability: overwriting epoch 1 with a different keyFingerprint must fail with 409 EPOCH_KEY_ALREADY_SEALED
    const rogueKey = await generateClusterGroupKey();
    const resOverwriteSealed = await helperFetch(`/api/clusters/${hardenedClusterId}/key-distribution`, {
      method: 'POST',
      headers: { Cookie: ownerCookie },
      body: JSON.stringify({
        epoch: 1,
        audienceHash: 'ALL',
        rosterHash: rosterHash3,
        keyFingerprint: rogueKey.fingerprint,
        distributions: allDistPackages
      })
    });
    recordResult(
      'sealed_epoch_immutability_enforced',
      resOverwriteSealed.status === 409 && resOverwriteSealed.json?.error?.code === 'EPOCH_KEY_ALREADY_SEALED',
      `Status: ${resOverwriteSealed.status}, code: ${resOverwriteSealed.json?.error?.code}`
    );

    // 14. Pre-Flight Reject Gate tests BEFORE message DB insert
    const validBroadcastEnv = await encryptClusterMessage('Broadcast msg', allGroupKey.key, ownerUser.agentId, hardenedClusterId, 1, 'ALL');
    const validBroadcastSig = await signClusterMessageEnvelope(ownerFullId.identityPrivateKey, {
      clusterId: hardenedClusterId,
      keyEpoch: 1,
      senderAgentId: ownerUser.agentId,
      audienceHash: 'ALL',
      rosterHash: rosterHash3,
      sequence: null,
      keyFingerprint: allGroupKey.fingerprint,
      nonce: validBroadcastEnv.nonce,
      ciphertext: validBroadcastEnv.ciphertext
    });

    // 14a. Stale epoch rejected (409 EPOCH_STALE)
    const resStaleEpoch = await helperFetch(`/api/clusters/${hardenedClusterId}/messages`, {
      method: 'POST',
      headers: { Cookie: ownerCookie },
      body: JSON.stringify({
        ciphertext: validBroadcastEnv.ciphertext,
        nonce: validBroadcastEnv.nonce,
        version: 2,
        keyEpoch: 99,
        strictPreflight: true
      })
    });
    recordResult(
      'preflight_rejects_stale_epoch',
      resStaleEpoch.status === 409 && resStaleEpoch.json?.error?.code === 'EPOCH_STALE',
      `Status: ${resStaleEpoch.status}, code: ${resStaleEpoch.json?.error?.code}`
    );

    // 14b. Stale rosterHash rejected (409 ROSTER_STALE)
    const resStaleRoster = await helperFetch(`/api/clusters/${hardenedClusterId}/messages`, {
      method: 'POST',
      headers: { Cookie: ownerCookie },
      body: JSON.stringify({
        ciphertext: validBroadcastEnv.ciphertext,
        nonce: validBroadcastEnv.nonce,
        version: 2,
        keyEpoch: 1,
        rosterHash: 'RST:00000000000000000000000000000000',
        strictPreflight: true
      })
    });
    recordResult(
      'preflight_rejects_stale_roster',
      resStaleRoster.status === 409 && resStaleRoster.json?.error?.code === 'ROSTER_STALE',
      `Status: ${resStaleRoster.status}, code: ${resStaleRoster.json?.error?.code}`
    );

    // 14c. Key fingerprint mismatch rejected (409 KEY_MISMATCH)
    const resKeyMismatch = await helperFetch(`/api/clusters/${hardenedClusterId}/messages`, {
      method: 'POST',
      headers: { Cookie: ownerCookie },
      body: JSON.stringify({
        ciphertext: validBroadcastEnv.ciphertext,
        nonce: validBroadcastEnv.nonce,
        version: 2,
        keyEpoch: 1,
        keyFingerprint: rogueKey.fingerprint,
        strictPreflight: true
      })
    });
    recordResult(
      'preflight_rejects_key_mismatch',
      resKeyMismatch.status === 409 && resKeyMismatch.json?.error?.code === 'KEY_MISMATCH',
      `Status: ${resKeyMismatch.status}, code: ${resKeyMismatch.json?.error?.code}`
    );

    // 14d. Invalid ECDSA signature rejected (401 INVALID_SIGNATURE)
    const resInvalidSig = await helperFetch(`/api/clusters/${hardenedClusterId}/messages`, {
      method: 'POST',
      headers: { Cookie: ownerCookie },
      body: JSON.stringify({
        ciphertext: validBroadcastEnv.ciphertext,
        nonce: validBroadcastEnv.nonce,
        version: 2,
        keyEpoch: 1,
        audienceHash: 'ALL',
        rosterHash: rosterHash3,
        keyFingerprint: allGroupKey.fingerprint,
        signature: Buffer.from(new Uint8Array(64).fill(1)).toString('base64'),
        strictPreflight: true
      })
    });
    recordResult(
      'preflight_rejects_invalid_signature',
      resInvalidSig.status === 401 && resInvalidSig.json?.error?.code === 'INVALID_SIGNATURE',
      `Status: ${resInvalidSig.status}, code: ${resInvalidSig.json?.error?.code}`
    );

    // 14e. Valid signed broadcast message accepted (201)
    const resValidSigned = await helperFetch(`/api/clusters/${hardenedClusterId}/messages`, {
      method: 'POST',
      headers: { Cookie: ownerCookie },
      body: JSON.stringify({
        ciphertext: validBroadcastEnv.ciphertext,
        nonce: validBroadcastEnv.nonce,
        version: 2,
        keyEpoch: 1,
        audienceHash: 'ALL',
        rosterHash: rosterHash3,
        keyFingerprint: allGroupKey.fingerprint,
        signature: validBroadcastSig,
        strictPreflight: true
      })
    });
    recordResult(
      'preflight_accepts_valid_signed_broadcast',
      resValidSigned.status === 201 && resValidSigned.json?.success === true,
      `Status: ${resValidSigned.status}`
    );

    // 15. Cryptographic O(1) Subset Key Isolation (Owner + PeerA ONLY; PeerB excluded)
    const subsetRecipients = [ownerUser.agentId, peerUser.agentId];
    const subsetAudHash = await computeClusterAudienceHash(subsetRecipients, all3Ids);
    const subsetKey = await generateClusterGroupKey();
    const subsetSecretText = 'Top secret subset message ONLY for Owner & PeerA';
    const subsetEnv = await encryptClusterMessage(subsetSecretText, subsetKey.key, ownerUser.agentId, hardenedClusterId, 1, subsetAudHash);

    // 15a. Pre-flight rejects subset message BEFORE subset key is distributed (422 MISSING_RECIPIENT_KEYS)
    const resMissingSubKey = await helperFetch(`/api/clusters/${hardenedClusterId}/messages`, {
      method: 'POST',
      headers: { Cookie: ownerCookie },
      body: JSON.stringify({
        ciphertext: subsetEnv.ciphertext,
        nonce: subsetEnv.nonce,
        version: 2,
        keyEpoch: 1,
        audienceHash: subsetAudHash,
        rosterHash: rosterHash3,
        keyFingerprint: subsetKey.fingerprint,
        recipientAgentIds: [peerUser.agentId],
        strictPreflight: true
      })
    });
    recordResult(
      'preflight_rejects_missing_subset_keys',
      resMissingSubKey.status === 422 && resMissingSubKey.json?.error?.code === 'MISSING_RECIPIENT_KEYS',
      `Status: ${resMissingSubKey.status}, code: ${resMissingSubKey.json?.error?.code}`
    );

    // 15b. Distribute subgroup key ONLY to owner & peerA (NEVER PeerB)
    const subsetDistPackages = await Promise.all([
      { user: ownerUser, fp: ownerFullId.fingerprint, pub: ownerFullId.e2eePublicKey },
      { user: peerUser, fp: peerAFullId.fingerprint, pub: peerAFullId.e2eePublicKey }
    ].map(async (m) => ({
      recipientAgentId: m.user.agentId,
      senderAgentId: ownerUser.agentId,
      senderPublicKey: ownerFullId.e2eePublicKey,
      recipientKeyEpoch: 1,
      encryptedKeyPackage: await wrapClusterGroupKeyForMember(
        subsetKey.rawKey,
        ownerFullId.e2eePrivateKey,
        m.pub,
        hardenedClusterId,
        1,
        {
          audienceHash: subsetAudHash,
          keyFingerprint: subsetKey.fingerprint,
          rosterHash: rosterHash3,
          senderAgentId: ownerUser.agentId,
          senderPublicKey: ownerFullId.e2eePublicKey,
          recipientAgentId: m.user.agentId,
          recipientKeyFingerprint: m.fp,
          recipientKeyEpoch: 1
        }
      )
    })));

    const resSubDist = await helperFetch(`/api/clusters/${hardenedClusterId}/key-distribution`, {
      method: 'POST',
      headers: { Cookie: ownerCookie },
      body: JSON.stringify({
        epoch: 1,
        audienceHash: subsetAudHash,
        rosterHash: rosterHash3,
        keyFingerprint: subsetKey.fingerprint,
        distributions: subsetDistPackages
      })
    });
    recordResult('subgroup_key_distribution_success', resSubDist.status === 201, `Status: ${resSubDist.status}, aud: ${subsetAudHash}`);

    // 15c. Send signed subset message (allowed now that subset key packages exist for owner + peerA)
    const subsetSig = await signClusterMessageEnvelope(ownerFullId.identityPrivateKey, {
      clusterId: hardenedClusterId,
      keyEpoch: 1,
      senderAgentId: ownerUser.agentId,
      audienceHash: subsetAudHash,
      rosterHash: rosterHash3,
      sequence: null,
      keyFingerprint: subsetKey.fingerprint,
      nonce: subsetEnv.nonce,
      ciphertext: subsetEnv.ciphertext
    });
    const resSubsetSend = await helperFetch(`/api/clusters/${hardenedClusterId}/messages`, {
      method: 'POST',
      headers: { Cookie: ownerCookie },
      body: JSON.stringify({
        ciphertext: subsetEnv.ciphertext,
        nonce: subsetEnv.nonce,
        version: 2,
        keyEpoch: 1,
        audienceHash: subsetAudHash,
        rosterHash: rosterHash3,
        keyFingerprint: subsetKey.fingerprint,
        signature: subsetSig,
        recipientAgentIds: [peerUser.agentId],
        strictPreflight: true
      })
    });
    recordResult('subgroup_message_send_success', resSubsetSend.status === 201, `Status: ${resSubsetSend.status}`);

    // 15d. Verify PeerA receives & unwraps subgroup key and decrypts; PeerB gets NO subgroup key, NO message, NO external event, and CANNOT decrypt with broadcast key
    const resPeerASubDist = await helperFetch(`/api/clusters/${hardenedClusterId}/key-distribution?epoch=1&audienceHash=${encodeURIComponent(subsetAudHash)}`, {
      method: 'GET',
      headers: { Cookie: peerACookie }
    });
    const peerAUnwrapped = await unwrapClusterGroupKeyFromPackage(
      resPeerASubDist.json.data.encryptedKeyPackage,
      peerAFullId.e2eePrivateKey,
      ownerFullId.e2eePublicKey,
      hardenedClusterId,
      1,
      subsetAudHash
    );
    const peerADecryptedSubset = await decryptClusterMessage(
      subsetEnv.ciphertext,
      subsetEnv.nonce,
      peerAUnwrapped.groupKey,
      ownerUser.agentId,
      hardenedClusterId,
      1,
      2,
      undefined,
      undefined,
      subsetAudHash
    );
    recordResult('subgroup_peerA_decrypts_cleanly', peerADecryptedSubset === subsetSecretText, 'PeerA unwrapped AUD key and decrypted subset message');

    const resPeerBSubDist = await helperFetch(`/api/clusters/${hardenedClusterId}/key-distribution?epoch=1&audienceHash=${encodeURIComponent(subsetAudHash)}`, {
      method: 'GET',
      headers: { Cookie: peerBCookie }
    });
    const resPeerBMsgs = await helperFetch(`/api/clusters/${hardenedClusterId}/messages`, {
      method: 'GET',
      headers: { Cookie: peerBCookie }
    });
    const peerBSawSubsetMsg = (resPeerBMsgs.json?.data || []).some((m: any) => m.id === resSubsetSend.json?.data?.id);

    let peerBCannotDecryptWithAllKey = false;
    try {
      await decryptClusterMessage(subsetEnv.ciphertext, subsetEnv.nonce, allGroupKey.key, ownerUser.agentId, hardenedClusterId, 1, 2, undefined, undefined, subsetAudHash);
    } catch {
      peerBCannotDecryptWithAllKey = true;
    }

    const { data: peerBSubsetEvents } = await supabase
      .from('external_events')
      .select('*')
      .eq('user_id', peerBUser.id)
      .eq('target_id', hardenedClusterId);
    const peerBGotNoSubsetNotif = !(peerBSubsetEvents || []).some((e: any) => {
      const det = typeof e.details === 'string' ? JSON.parse(e.details) : e.details;
      return det?.message_id === resSubsetSend.json?.data?.id || det?.messageId === resSubsetSend.json?.data?.id;
    });

    recordResult(
      'excluded_member_cryptographically_and_event_isolated',
      !resPeerBSubDist.json?.success && !peerBSawSubsetMsg && peerBCannotDecryptWithAllKey && peerBGotNoSubsetNotif,
      `subDistSuccess=${resPeerBSubDist.json?.success}, sawMsg=${peerBSawSubsetMsg}, cryptoBlocked=${peerBCannotDecryptWithAllKey}, noEventLeak=${peerBGotNoSubsetNotif}`
    );

    // 16. Verify ALL-cluster key at epoch 1 is still intact alongside AUD subgroup key & recipient personal key rotation detection
    const peerANewFullId = await generateAgentCryptoIdentity(peerUser.agentId);
    await supabase.auth.admin.updateUserById(peerUser.id, {
      user_metadata: {
        e2eePublicKey: peerANewFullId.e2eePublicKey,
        e2eePublicKeyFingerprint: peerANewFullId.fingerprint,
        e2eeIdentityKey: peerANewFullId.identityPublicKey,
        e2eeKeyEpoch: 2
      }
    });
    const resRecipRotated = await helperFetch(`/api/clusters/${hardenedClusterId}/messages`, {
      method: 'POST',
      headers: { Cookie: ownerCookie },
      body: JSON.stringify({
        ciphertext: validBroadcastEnv.ciphertext,
        nonce: validBroadcastEnv.nonce,
        version: 2,
        keyEpoch: 1,
        audienceHash: 'ALL',
        rosterHash: rosterHash3,
        keyFingerprint: allGroupKey.fingerprint,
        signature: validBroadcastSig,
        strictPreflight: true
      })
    });
    recordResult(
      'preflight_detects_recipient_personal_key_rotation',
      resRecipRotated.status === 422 && resRecipRotated.json?.error?.code === 'MISSING_RECIPIENT_KEYS' && Array.isArray(resRecipRotated.json?.error?.staleKeyRecipients),
      `Status: ${resRecipRotated.status}, stale: ${JSON.stringify(resRecipRotated.json?.error?.staleKeyRecipients)}`
    );

    // 17. Leaving cluster via DELETE /leave triggers EPOCH_ROTATION_REQUIRED on subsequent send until admin rotates key
    const resLeave = await helperFetch(`/api/clusters/${hardenedClusterId}/leave`, {
      method: 'DELETE',
      headers: { Cookie: peerBCookie }
    });
    const resSendAfterLeave = await helperFetch(`/api/clusters/${hardenedClusterId}/messages`, {
      method: 'POST',
      headers: { Cookie: ownerCookie },
      body: JSON.stringify({
        ciphertext: validBroadcastEnv.ciphertext,
        nonce: validBroadcastEnv.nonce,
        version: 2,
        keyEpoch: 2,
        strictPreflight: true
      })
    });
    recordResult(
      'leave_triggers_epoch_rotation_required',
      resLeave.status === 200 && resSendAfterLeave.status === 409 && resSendAfterLeave.json?.error?.code === 'EPOCH_ROTATION_REQUIRED',
      `leaveStatus=${resLeave.status}, postLeaveSendStatus=${resSendAfterLeave.status}, code=${resSendAfterLeave.json?.error?.code}`
    );

    server.close();
  } catch (err: any) {
    console.error('Test suite error:', err);
    recordResult('Test Suite Execution', false, err?.message);
  }

  return results;
}

if (import.meta.url.endsWith(process.argv[1]) || process.argv[1]?.includes('clusterMessagingSecurityTests')) {
  runClusterMessagingSecurityTests().then(results => {
    const hasFailures = Object.values(results).some(r => r.status === 'FAILED');
    if (hasFailures) {
      process.exit(1);
    } else {
      process.exit(0);
    }
  }).catch(err => {
    console.error('Fatal error:', err);
    process.exit(1);
  });
}
