import { establishDirectConnection } from '../services/connectionService.ts';
import { getSupabaseClient } from '../supabase.ts';
import { watchtowerActivityService } from '../services/watchtowerActivityService.ts';

export async function runDirectConnectionAndClusterTests(): Promise<Record<string, { status: 'PASSED' | 'FAILED'; reason?: string }>> {
  console.log('\n=== AAMARVA DIRECT CONNECTION & CLUSTER MEMBERSHIP TEST SUITE ===\n');
  const results: Record<string, { status: 'PASSED' | 'FAILED'; reason?: string }> = {};

  const recordResult = (id: string, success: boolean, reason?: string) => {
    results[id] = { status: success ? 'PASSED' : 'FAILED', reason };
    console.log(`[${success ? 'PASSED' : 'FAILED'}] ${id}${reason ? `: ${reason}` : ''}`);
  };

  try {
    const supabase = getSupabaseClient();
    const testMasterId = `usr_test_master_${Date.now()}`;
    const testSlaveId = `usr_test_slave_${Date.now()}`;
    const testPeerMasterId = `usr_test_peer_${Date.now()}`;
    const testSlavePeerId = `usr_test_slave_peer_${Date.now()}`;

    // Seed test users in Supabase / mock store
    await supabase.from('users').insert([
      { id: testMasterId, agentId: `agent_m_${Date.now()}`, name: 'Test Master', account_type: 'master', is_master_primary: true },
      { id: testSlaveId, agentId: `agent_s_${Date.now()}`, name: 'Test Slave', account_type: 'slave', master_id: testMasterId },
      { id: testPeerMasterId, agentId: `agent_pm_${Date.now()}`, name: 'Test Peer Master', account_type: 'master', is_master_primary: true },
      { id: testSlavePeerId, agentId: `agent_sp_${Date.now()}`, name: 'Test Slave Peer', account_type: 'slave', master_id: testPeerMasterId },
    ]);

    // Scenario 1: Master → Master (Allowed)
    try {
      const connMM = await establishDirectConnection(testMasterId, testPeerMasterId);
      if (connMM && connMM.id && connMM.status === 'active') {
        recordResult('connection_master_to_master_allowed', true, `Master-to-Master connection established: ${connMM.id}`);
      } else {
        recordResult('connection_master_to_master_allowed', false, 'Master-to-Master did not return active connection');
      }
    } catch (e: any) {
      recordResult('connection_master_to_master_allowed', false, e?.message);
    }

    // Scenario 2: Master → Slave (Allowed)
    try {
      const connMS = await establishDirectConnection(testMasterId, testSlavePeerId);
      if (connMS && connMS.id && connMS.status === 'active') {
        recordResult('connection_master_to_slave_allowed', true, `Master-to-Slave connection established: ${connMS.id}`);
      } else {
        recordResult('connection_master_to_slave_allowed', false, 'Master-to-Slave did not return active connection');
      }
    } catch (e: any) {
      recordResult('connection_master_to_slave_allowed', false, e?.message);
    }

    // Scenario 3: Slave → Master (Allowed)
    try {
      const connSM = await establishDirectConnection(testSlaveId, testPeerMasterId);
      if (connSM && connSM.id && connSM.status === 'active') {
        recordResult('connection_slave_to_master_allowed', true, `Slave-to-Master connection established: ${connSM.id}`);
      } else {
        recordResult('connection_slave_to_master_allowed', false, 'Slave-to-Master did not return active connection');
      }
    } catch (e: any) {
      recordResult('connection_slave_to_master_allowed', false, e?.message);
    }

    // Scenario 4: Slave → Slave (Blocked)
    try {
      await establishDirectConnection(testSlaveId, testSlavePeerId);
      recordResult('unauthorized_slave_to_slave_blocked', false, 'Expected slave-to-slave connection to be forbidden');
    } catch (e: any) {
      if (e?.statusCode === 403 || e?.code === 'SLAVE_TO_SLAVE_CONNECTION_FORBIDDEN' || e?.message?.includes('prohibited')) {
        recordResult('unauthorized_slave_to_slave_blocked', true, 'Slave-to-slave connection successfully blocked (403)');
      } else {
        recordResult('unauthorized_slave_to_slave_blocked', false, `Unexpected error: ${e?.message}`);
      }
    }

    // Scenario 5: Slave accepts Slave (Blocked)
    try {
      const { getConnectionRecord } = await import('../services/connectionService.ts');
      // Create a dummy record directly in DB as if created before restriction
      const legacySlaveConnId = `conn_legacy_ss_${Date.now()}`;
      await supabase.from('connections').insert({
        id: legacySlaveConnId,
        user1_id: testSlaveId,
        user1_agent_id: 'agent_s',
        user2_id: testSlavePeerId,
        user2_agent_id: 'agent_sp',
        status: 'pending'
      });

      // Attempting to resolve/accept this connection via getConnectionRecord or acceptance logic
      const rec = await getConnectionRecord(legacySlaveConnId);
      if (rec === null) {
        recordResult('slave_accepts_slave_blocked', true, 'Slave accepting slave connection successfully blocked and dissolved');
      } else {
        recordResult('slave_accepts_slave_blocked', false, 'Expected slave-to-slave connection record to be dissolved and nullified');
      }
    } catch (e: any) {
      recordResult('slave_accepts_slave_blocked', true, `Blocked with: ${e?.message}`);
    }

    // Test 3: Direct cluster member addition and removal without invitation
    const clusterId = `cls_${Date.now()}`;
    const { error: clusterErr } = await supabase.from('clusters').insert([
      { id: clusterId, name: 'Direct Cluster', ownerUserId: testMasterId, isPublic: true }
    ]);
    if (clusterErr) {
      recordResult('direct_cluster_operations', false, `Failed to create cluster: ${clusterErr.message}`);
    } else {
      // Add member directly without invitation
      const { error: memberErr } = await supabase.from('cluster_members').insert([
        { clusterId, userId: testPeerMasterId, role: 'member', joinedAt: new Date().toISOString() }
      ]);
      if (memberErr) {
        recordResult('direct_cluster_operations', false, `Failed to add member directly: ${memberErr.message}`);
      } else {
        // Verify member exists
        const { data: memberRec } = await supabase.from('cluster_members').select('*').eq('clusterId', clusterId).eq('userId', testPeerMasterId).maybeSingle();
        if (memberRec) {
          // Remove member directly
          await supabase.from('cluster_members').delete().eq('clusterId', clusterId).eq('userId', testPeerMasterId);
          const { data: removedRec } = await supabase.from('cluster_members').select('*').eq('clusterId', clusterId).eq('userId', testPeerMasterId).maybeSingle();
          if (!removedRec) {
            recordResult('direct_cluster_operations', true, 'Direct member addition and removal succeeded without invitation');
          } else {
            recordResult('direct_cluster_operations', false, 'Failed to remove member');
          }
        } else {
          recordResult('direct_cluster_operations', false, 'Member record not found after direct addition');
        }
      }
    }

    // Test 4: Watchtower records real state change exactly once and no retired events
    const activityKey = `test_watchtower_${Date.now()}`;
    await watchtowerActivityService.recordWatchtowerActivity({
      agentId: 'agent_m_test',
      agentName: 'Test Agent',
      avatar: '🤖',
      emailVerified: true,
      text: 'formed a connection with peer',
      type: 'connection',
      activityKey,
      actorUserId: testMasterId,
      masterId: testMasterId,
      createdAt: new Date().toISOString()
    });

    const activities = watchtowerActivityService.getRecentWatchtowerActivity({ userId: testMasterId, isMaster: true });
    const matched = (activities || []).filter((a: any) => a.activityKey === activityKey);
    if (matched.length === 1) {
      recordResult('watchtower_records_state_change_once', true, 'Recorded state change exactly once');
    } else {
      recordResult('watchtower_records_state_change_once', false, `Recorded count: ${matched.length}`);
    }

    // Test 5: Historical messages across duplicate/alias connection IDs & concurrent establishDirectConnection
    try {
      const { getConnectionRecord, getConnectionMessages, getUserConnections, sendMessage } = await import('../services/connectionService.ts');
      const { generateAgentCryptoIdentity, encryptMessage, decryptMessage } = await import('../../src/lib/e2ee.js');

      const u1Id = testMasterId;
      const u2Id = testSlaveId;
      const u1AgentId = `agent_m_hist_${Date.now()}`;
      const u2AgentId = `agent_s_hist_${Date.now()}`;
      await supabase.from('users').update({ agentId: u1AgentId }).eq('id', u1Id);
      await supabase.from('users').update({ agentId: u2AgentId }).eq('id', u2Id);

      const ident1 = await generateAgentCryptoIdentity(u1AgentId);
      const ident2 = await generateAgentCryptoIdentity(u2AgentId);
      await supabase.auth.admin.updateUserById(u1Id, {
        user_metadata: { e2eePublicKey: ident1.e2eePublicKey, e2eeKeyEpoch: 1, e2eeEpochHistory: { '1': { publicKey: ident1.e2eePublicKey, keyEpoch: 1 } } }
      });
      await supabase.auth.admin.updateUserById(u2Id, {
        user_metadata: { e2eePublicKey: ident2.e2eePublicKey, e2eeKeyEpoch: 1, e2eeEpochHistory: { '1': { publicKey: ident2.e2eePublicKey, keyEpoch: 1 } } }
      });

      // Remove prior pair rows for clean concurrency test
      await supabase.from('connections').delete().or(`and(user1_id.eq.${u1Id},user2_id.eq.${u2Id}),and(user1_id.eq.${u2Id},user2_id.eq.${u1Id})`);

      // Concurrent establishDirectConnection calls must produce the same single row
      const [cA, cB] = await Promise.all([
        establishDirectConnection(u1Id, u2Id),
        establishDirectConnection(u2Id, u1Id),
      ]);
      const { data: rowsAfterConcurrent } = await supabase
        .from('connections')
        .select('*')
        .or(`and(user1_id.eq.${u1Id},user2_id.eq.${u2Id}),and(user1_id.eq.${u2Id},user2_id.eq.${u1Id})`);

      // Simulate pre-existing duplicate row + legacy composite alias messages
      const dupConnId = `conn_dup_${Date.now()}`;
      const aliasFleetConnId = `fleet_conn_${u1Id}_${u2Id}`;
      await supabase.from('connections').insert({
        id: dupConnId,
        user1_id: u1Id,
        user1_agent_id: u1AgentId,
        user1_agent_name: 'Test Master',
        user2_id: u2Id,
        user2_agent_id: u2AgentId,
        user2_agent_name: 'Test Peer Master',
        status: 'active',
        createdAt: new Date(Date.now() - 60000).toISOString(),
      });

      const oldText = 'Older historical encrypted payload';
      const aliasText = 'Fleet alias historical encrypted payload';
      const newText = 'Newest encrypted payload';

      const oldEnv = await encryptMessage(oldText, ident1.e2eePrivateKey, ident2.e2eePublicKey, dupConnId, u1AgentId, 1);
      const aliasEnv = await encryptMessage(aliasText, ident2.e2eePrivateKey, ident1.e2eePublicKey, aliasFleetConnId, u2AgentId, 1);
      const newEnv = await encryptMessage(newText, ident1.e2eePrivateKey, ident2.e2eePublicKey, cA!.id, u1AgentId, 1);

      await supabase.from('messages').insert([
        {
          id: `msg_old_${Date.now()}`,
          connectionId: dupConnId,
          senderUserId: u1Id,
          senderAgentId: u1AgentId,
          content: null,
          ciphertext: oldEnv.ciphertext,
          nonce: oldEnv.nonce,
          version: 1,
          keyEpoch: 1,
          sequence: 1,
          createdAt: new Date(Date.now() - 50000).toISOString(),
        },
        {
          id: `msg_alias_${Date.now()}`,
          connectionId: aliasFleetConnId,
          senderUserId: u2Id,
          senderAgentId: u2AgentId,
          content: null,
          ciphertext: aliasEnv.ciphertext,
          nonce: aliasEnv.nonce,
          version: 1,
          keyEpoch: 1,
          sequence: 1,
          createdAt: new Date(Date.now() - 30000).toISOString(),
        },
      ]);
      await sendMessage(cA!.id, u1Id, {
        ciphertext: newEnv.ciphertext,
        nonce: newEnv.nonce,
        version: 1,
        keyEpoch: 1,
        sequence: 1,
      });

      const resolvedByNew = await getConnectionRecord(cA!.id);
      const msgsFromNew = await getConnectionMessages(cA!.id, u2Id, { aliasConnectionIds: [aliasFleetConnId] });
      const msgsFromComposite = await getConnectionMessages(aliasFleetConnId, u1Id, { aliasConnectionIds: [aliasFleetConnId] });
      const userConns = await getUserConnections(u1Id, 1, 20);
      const matchingPeers = (userConns.connections || []).filter((c: any) => c.agentId === u2AgentId);

      // Verify all 3 messages decrypt cleanly using their preserved m.connectionId
      const dec0 = await decryptMessage({ ciphertext: msgsFromNew[0].ciphertext, nonce: msgsFromNew[0].nonce, version: 1, keyEpoch: 1 }, ident2.e2eePrivateKey, ident1.e2eePublicKey, msgsFromNew[0].connectionId, u1AgentId);
      const dec1 = await decryptMessage({ ciphertext: msgsFromNew[1].ciphertext, nonce: msgsFromNew[1].nonce, version: 1, keyEpoch: 1 }, ident1.e2eePrivateKey, ident2.e2eePublicKey, msgsFromNew[1].connectionId, u2AgentId);
      const dec2 = await decryptMessage({ ciphertext: msgsFromNew[2].ciphertext, nonce: msgsFromNew[2].nonce, version: 1, keyEpoch: 1 }, ident2.e2eePrivateKey, ident1.e2eePublicKey, msgsFromNew[2].connectionId, u1AgentId);

      const historyOk =
        Boolean(cA && cB && cA.id === cB.id) &&
        (rowsAfterConcurrent || []).length === 1 &&
        Boolean(resolvedByNew) &&
        msgsFromNew.length === 3 &&
        msgsFromComposite.length === 3 &&
        matchingPeers.length === 1 &&
        dec0 === oldText &&
        dec1 === aliasText &&
        dec2 === newText;

      recordResult(
        'historical_messages_across_duplicate_and_alias_connections',
        historyOk,
        historyOk
          ? `Retrieved and decrypted all ${msgsFromNew.length} chronological messages across duplicate/alias connection IDs`
          : `Mismatch: concurrentRows=${rowsAfterConcurrent?.length}, msgsNew=${msgsFromNew.length}, msgsComp=${msgsFromComposite.length}, peers=${matchingPeers.length}`
      );
    } catch (histErr: any) {
      recordResult('historical_messages_across_duplicate_and_alias_connections', false, histErr?.message || String(histErr));
    }

    // Cleanup test data
    await supabase.from('users').delete().in('id', [testMasterId, testSlaveId, testPeerMasterId, testSlavePeerId]);
    await supabase.from('clusters').delete().eq('id', clusterId);
    await supabase.from('connections').delete().or(`user1_id.eq.${testMasterId},user2_id.eq.${testMasterId}`);

  } catch (err: any) {
    recordResult('direct_connection_and_cluster_suite', false, err?.message || String(err));
  }

  return results;
}
