import express from 'express';
import http from 'http';
import cookieParser from 'cookie-parser';
import crypto from 'crypto';
import clusterRouter, { getClusterTables } from '../routes/clusterRoutes';
import aamarvaRouter from '../routes/aamarvaRoutes';
import { getSupabaseClient } from '../supabase';
import { registerUser, createHumanSession, switchHumanSessionToken, generateAgentAccessToken } from '../authService';
import { generateE2EEKeyPair } from '../../src/lib/e2ee';
import { generateClusterGroupKey, encryptClusterMessage } from '../../src/lib/clusterCrypto';

export async function runClusterMasterAccountAuthorizationTests(): Promise<Record<string, { status: 'PASSED' | 'FAILED'; reason?: string }>> {
  console.log('\n=== AAMARVA MASTER ACCOUNT CLUSTER MESSAGING AUTHORIZATION TEST SUITE ===\n');
  const results: Record<string, { status: 'PASSED' | 'FAILED'; reason?: string }> = {};

  const recordResult = (id: string, success: boolean, reason?: string) => {
    results[id] = { status: success ? 'PASSED' : 'FAILED', reason };
    console.log(`[${success ? 'PASSED' : 'FAILED'}] ${id}${reason ? `: ${reason}` : ''}`);
  };

  const app = express();
  app.use(cookieParser());
  app.use(express.json());
  app.use('/api', aamarvaRouter);
  app.use('/api', clusterRouter);

  const server = http.createServer(app);
  await new Promise<void>((resolve) => server.listen(0, resolve));
  const port = (server.address() as any).port;
  const baseUrl = `http://127.0.0.1:${port}`;

  const helperFetch = async (endpoint: string, options: any = {}) => {
    const res = await fetch(`${baseUrl}${endpoint}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(options.headers || {})
      }
    });
    const text = await res.text();
    let json: any = null;
    try {
      json = JSON.parse(text);
    } catch {}
    return { status: res.status, json, text };
  };

  const ts = Date.now();
  const supabase = getSupabaseClient();
  const tables = await getClusterTables(supabase);

  try {
    // -------------------------------------------------------------------------
    // 1. SETUP IDENTITIES
    // -------------------------------------------------------------------------
    // A. Pioneer Master Account
    const regPioneer = await registerUser({
      email: `pioneer_${ts}@aamarva.test`,
      password: 'PioneerPassword123!',
      agentName: 'Pioneer Master'
    });
    const pioneerUser = regPioneer.user;
    const pioneerSession = await createHumanSession(pioneerUser.id);
    const pioneerCookie = `aamarva_human_session=${pioneerSession}`;

    const pioneerKeys = await generateE2EEKeyPair();
    await supabase.auth.admin.updateUserById(pioneerUser.id, {
      user_metadata: {
        e2eePublicKey: pioneerKeys.publicKey,
        e2eePublicKeyFingerprint: pioneerKeys.fingerprint
      }
    });
    await supabase.from('users').update({
      is_master_primary: true,
      account_type: 'master',
      role: 'master',
      is_slave: false,
      e2eePublicKey: pioneerKeys.publicKey,
      e2eePublicKeyFingerprint: pioneerKeys.fingerprint
    }).eq('id', pioneerUser.id);

    // B. Add-on Master Account (Master slot belonging to the master fleet)
    const addOnEmail = `addon_master_${ts}@aamarva.test`;
    const regAddOn = await registerUser({
      email: addOnEmail,
      password: 'AddonPassword123!',
      agentName: 'Addon Master Slot'
    });
    const addOnUser = regAddOn.user;
    const addOnKeys = await generateE2EEKeyPair();

    await supabase.auth.admin.updateUserById(addOnUser.id, {
      user_metadata: {
        e2eePublicKey: addOnKeys.publicKey,
        e2eePublicKeyFingerprint: addOnKeys.fingerprint
      }
    });
    await supabase.from('users').update({
      master_id: pioneerUser.id,
      is_master_primary: false,
      is_master_slot: true,
      account_type: 'master_slot',
      role: 'master',
      is_slave: false,
      e2eePublicKey: addOnKeys.publicKey,
      e2eePublicKeyFingerprint: addOnKeys.fingerprint
    }).eq('id', addOnUser.id);

    // Human session created directly for Add-on Master
    const addOnSession = await createHumanSession(addOnUser.id);
    const addOnCookie = `aamarva_human_session=${addOnSession}`;

    // C. Slave Account (Sub-agent of Pioneer Master)
    const slaveEmail = `slave_${ts}+AMR-AGENT@aamarva.test`;
    const regSlave = await registerUser({
      email: slaveEmail,
      password: 'SlavePassword123!',
      agentName: 'Autonomous Slave Agent'
    });
    const slaveUser = regSlave.user;
    const slaveKeys = await generateE2EEKeyPair();

    await supabase.auth.admin.updateUserById(slaveUser.id, {
      user_metadata: {
        e2eePublicKey: slaveKeys.publicKey,
        e2eePublicKeyFingerprint: slaveKeys.fingerprint
      }
    });
    await supabase.from('users').update({
      master_id: pioneerUser.id,
      is_master_primary: false,
      is_master_slot: false,
      account_type: 'slave',
      role: 'slave',
      is_slave: true,
      e2eePublicKey: slaveKeys.publicKey,
      e2eePublicKeyFingerprint: slaveKeys.fingerprint
    }).eq('id', slaveUser.id);

    const slaveHumanSession = await createHumanSession(slaveUser.id);
    const slaveCookie = `aamarva_human_session=${slaveHumanSession}`;
    const slaveRuntimeToken = generateAgentAccessToken(slaveUser);

    // D. Recipient Member User
    const regMember = await registerUser({
      email: `recipient_${ts}@aamarva.test`,
      password: 'RecipientPassword123!',
      agentName: 'Recipient Agent'
    });
    const memberUser = regMember.user;
    const memberKeys = await generateE2EEKeyPair();
    await supabase.auth.admin.updateUserById(memberUser.id, {
      user_metadata: {
        e2eePublicKey: memberKeys.publicKey,
        e2eePublicKeyFingerprint: memberKeys.fingerprint
      }
    });
    await supabase.from('users').update({
      e2eePublicKey: memberKeys.publicKey,
      e2eePublicKeyFingerprint: memberKeys.fingerprint
    }).eq('id', memberUser.id);

    // E. Setup Cluster with members
    const clusterId = `cluster_${crypto.randomUUID()}`;
    await supabase.from(tables.clusters).insert({
      id: clusterId,
      name: 'Master Authorization Test Cluster',
      ownerUserId: pioneerUser.id,
      ownerAgentId: pioneerUser.agentId,
      status: 'active',
      createdAt: new Date().toISOString()
    });

    // Add Pioneer, AddOn, Slave, and Member to cluster members
    await supabase.from(tables.members).insert([
      { id: `mem_${crypto.randomUUID()}`, clusterId, userId: pioneerUser.id, agentId: pioneerUser.agentId, role: 'owner', status: 'active' },
      { id: `mem_${crypto.randomUUID()}`, clusterId, userId: addOnUser.id, agentId: addOnUser.agentId, role: 'member', status: 'active' },
      { id: `mem_${crypto.randomUUID()}`, clusterId, userId: slaveUser.id, agentId: slaveUser.agentId, role: 'member', status: 'active' },
      { id: `mem_${crypto.randomUUID()}`, clusterId, userId: memberUser.id, agentId: memberUser.agentId, role: 'member', status: 'active' }
    ]);

    // Prepare valid E2EE envelope
    const groupKeyData = await generateClusterGroupKey();
    const envelope = await encryptClusterMessage(
      'Authorized cluster announcement',
      groupKeyData.key,
      pioneerUser.agentId,
      clusterId,
      1
    );

    // -------------------------------------------------------------------------
    // TEST 1: Pioneer master sends a cluster message through the UI (human session)
    // -------------------------------------------------------------------------
    const res1 = await helperFetch(`/api/clusters/${clusterId}/messages`, {
      method: 'POST',
      headers: { Cookie: pioneerCookie },
      body: JSON.stringify({
        ciphertext: envelope.ciphertext,
        nonce: envelope.nonce,
        version: 2,
        keyEpoch: 1,
        recipients: [memberUser.agentId]
      })
    });
    recordResult(
      '1_pioneer_master_sends_cluster_message_via_ui',
      (res1.status === 200 || res1.status === 201) && res1.json?.success === true,
      `HTTP ${res1.status}, response: ${JSON.stringify(res1.json?.error || res1.json?.data?.id || 'ok')}`
    );

    // -------------------------------------------------------------------------
    // TEST 2: Add-on master sends a cluster message through the UI (CRITICAL FIX)
    // -------------------------------------------------------------------------
    const addOnEnvelope = await encryptClusterMessage(
      'Message from add-on master account',
      groupKeyData.key,
      addOnUser.agentId,
      clusterId,
      1
    );
    const res2 = await helperFetch(`/api/clusters/${clusterId}/messages`, {
      method: 'POST',
      headers: { Cookie: addOnCookie },
      body: JSON.stringify({
        ciphertext: addOnEnvelope.ciphertext,
        nonce: addOnEnvelope.nonce,
        version: 2,
        keyEpoch: 1,
        recipients: [memberUser.agentId]
      })
    });
    recordResult(
      '2_addon_master_sends_cluster_message_via_ui',
      (res2.status === 200 || res2.status === 201) && res2.json?.success === true,
      `HTTP ${res2.status}, response: ${JSON.stringify(res2.json?.error || res2.json?.data?.id || 'ok')}`
    );

    // -------------------------------------------------------------------------
    // TEST 3: Slave account attempts UI messaging and is strictly rejected
    // -------------------------------------------------------------------------
    const slaveEnvelope = await encryptClusterMessage(
      'Unauthorized slave UI message',
      groupKeyData.key,
      slaveUser.agentId,
      clusterId,
      1
    );
    const res3 = await helperFetch(`/api/clusters/${clusterId}/messages`, {
      method: 'POST',
      headers: { Cookie: slaveCookie },
      body: JSON.stringify({
        ciphertext: slaveEnvelope.ciphertext,
        nonce: slaveEnvelope.nonce,
        version: 2,
        keyEpoch: 1,
        recipients: [memberUser.agentId]
      })
    });
    recordResult(
      '3_slave_ui_messaging_strictly_rejected',
      res3.status === 403 && res3.json?.error?.code === 'SLAVE_UI_MESSAGING_DISABLED',
      `HTTP ${res3.status}, code: ${res3.json?.error?.code}, message: ${res3.json?.error?.message}`
    );

    // -------------------------------------------------------------------------
    // TEST 4: Slave agent sends through the authorized runtime API
    // -------------------------------------------------------------------------
    const res4 = await helperFetch(`/api/clusters/${clusterId}/messages`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${slaveRuntimeToken}` },
      body: JSON.stringify({
        ciphertext: slaveEnvelope.ciphertext,
        nonce: slaveEnvelope.nonce,
        version: 2,
        keyEpoch: 1,
        recipients: [memberUser.agentId]
      })
    });
    recordResult(
      '4_slave_agent_runtime_api_messaging_allowed',
      (res4.status === 200 || res4.status === 201) && res4.json?.success === true,
      `HTTP ${res4.status}, response: ${JSON.stringify(res4.json?.error || res4.json?.data?.id || 'ok')}`
    );

    // -------------------------------------------------------------------------
    // TEST 5 & 6: Account switching consistency
    // Pioneer -> Add-on Master -> Pioneer
    // -------------------------------------------------------------------------
    // Switch Pioneer session to Add-on Master
    const switchedToAddOnToken = switchHumanSessionToken(pioneerSession, addOnUser.id, addOnUser.agentId, {
      returnMasterId: pioneerUser.id
    });
    const switchedToAddOnCookie = `aamarva_human_session=${switchedToAddOnToken}`;

    const res5 = await helperFetch(`/api/clusters/${clusterId}/messages`, {
      method: 'POST',
      headers: { Cookie: switchedToAddOnCookie },
      body: JSON.stringify({
        ciphertext: addOnEnvelope.ciphertext,
        nonce: addOnEnvelope.nonce,
        version: 2,
        keyEpoch: 1,
        recipients: [memberUser.agentId]
      })
    });
    recordResult(
      '5_pioneer_switched_to_addon_master_sends_successfully',
      (res5.status === 200 || res5.status === 201) && res5.json?.success === true,
      `HTTP ${res5.status}, response: ${JSON.stringify(res5.json?.error || res5.json?.data?.id || 'ok')}`
    );

    // Switch back from Add-on Master to Pioneer Master
    const returnedToPioneerToken = switchHumanSessionToken(switchedToAddOnToken, pioneerUser.id, pioneerUser.agentId, {
      returnMasterId: null
    });
    const returnedToPioneerCookie = `aamarva_human_session=${returnedToPioneerToken}`;

    const res6 = await helperFetch(`/api/clusters/${clusterId}/messages`, {
      method: 'POST',
      headers: { Cookie: returnedToPioneerCookie },
      body: JSON.stringify({
        ciphertext: envelope.ciphertext,
        nonce: envelope.nonce,
        version: 2,
        keyEpoch: 1,
        recipients: [memberUser.agentId]
      })
    });
    recordResult(
      '6_addon_master_switched_to_pioneer_master_sends_successfully',
      (res6.status === 200 || res6.status === 201) && res6.json?.success === true,
      `HTTP ${res6.status}, response: ${JSON.stringify(res6.json?.error || res6.json?.data?.id || 'ok')}`
    );

    // -------------------------------------------------------------------------
    // TEST 7: Impersonation protection: client-supplied ID is ignored, server session identity enforced
    // -------------------------------------------------------------------------
    // Attacker tries to pass body fields spoofing another sender
    const res7 = await helperFetch(`/api/clusters/${clusterId}/messages`, {
      method: 'POST',
      headers: { Cookie: addOnCookie },
      body: JSON.stringify({
        ciphertext: addOnEnvelope.ciphertext,
        nonce: addOnEnvelope.nonce,
        version: 2,
        keyEpoch: 1,
        senderUserId: pioneerUser.id,
        senderAgentId: pioneerUser.agentId,
        recipients: [memberUser.agentId]
      })
    });
    // Verify that the saved message in the database has senderUserId = addOnUser.id, NOT spoofed pioneerUser.id
    const sentMsgId = res7.json?.data?.id || res7.json?.id;
    const { data: dbMsg } = await supabase.from(tables.messages).select('senderUserId, senderAgentId').eq('id', sentMsgId).maybeSingle();
    const impersonationBlocked = dbMsg && dbMsg.senderUserId === addOnUser.id && dbMsg.senderAgentId === addOnUser.agentId;
    recordResult(
      '7_master_cannot_impersonate_another_account_via_client_id',
      Boolean((res7.status === 200 || res7.status === 201) && impersonationBlocked),
      `Stored senderUserId: ${dbMsg?.senderUserId} (expected: ${addOnUser.id})`
    );

    // -------------------------------------------------------------------------
    // TEST 8: Master cannot send to unauthorized recipients
    // -------------------------------------------------------------------------
    const res8 = await helperFetch(`/api/clusters/${clusterId}/messages`, {
      method: 'POST',
      headers: { Cookie: addOnCookie },
      body: JSON.stringify({
        ciphertext: addOnEnvelope.ciphertext,
        nonce: addOnEnvelope.nonce,
        version: 2,
        keyEpoch: 1,
        recipients: ['AMR-NON-MEMBER-UNKNOWN-XYZ']
      })
    });
    recordResult(
      '8_master_cannot_send_to_unauthorized_recipients',
      res8.status === 500 || res8.status === 400 || (res8.json && res8.json.success === false),
      `HTTP ${res8.status}, error: ${JSON.stringify(res8.json?.error || res8.text)}`
    );

    // -------------------------------------------------------------------------
    // TEST 9: Existing recipient-selection restrictions remain intact
    // -------------------------------------------------------------------------
    // Both active member and owner receive the message
    const res9 = await helperFetch(`/api/clusters/${clusterId}/messages`, {
      method: 'POST',
      headers: { Cookie: addOnCookie },
      body: JSON.stringify({
        ciphertext: addOnEnvelope.ciphertext,
        nonce: addOnEnvelope.nonce,
        version: 2,
        keyEpoch: 1,
        recipients: [memberUser.agentId, pioneerUser.agentId]
      })
    });
    const msg9Id = res9.json?.data?.id || res9.json?.id;
    const { data: recips } = await supabase.from(tables.recipients).select('recipientAgentId').eq('messageId', msg9Id);
    const recipAgents = recips?.map(r => r.recipientAgentId) || [];
    const hasRecipient = recipAgents.includes(memberUser.agentId) || recipAgents.includes(pioneerUser.agentId);
    recordResult(
      '9_recipient_selection_restrictions_intact',
      (res9.status === 200 || res9.status === 201) && hasRecipient,
      `HTTP ${res9.status}, recipient count: ${recipAgents.length}`
    );

    // -------------------------------------------------------------------------
    // TEST 10: Cluster messaging works after refreshing session and reopening modal
    // -------------------------------------------------------------------------
    // Re-verify session fresh from cookie
    const restoredSession = await createHumanSession(addOnUser.id);
    const restoredCookie = `aamarva_human_session=${restoredSession}`;

    const res10 = await helperFetch(`/api/clusters/${clusterId}/messages`, {
      method: 'POST',
      headers: { Cookie: restoredCookie },
      body: JSON.stringify({
        ciphertext: addOnEnvelope.ciphertext,
        nonce: addOnEnvelope.nonce,
        version: 2,
        keyEpoch: 1,
        recipients: [memberUser.agentId]
      })
    });
    recordResult(
      '10_cluster_messaging_works_after_refresh_and_reopen',
      (res10.status === 200 || res10.status === 201) && res10.json?.success === true,
      `HTTP ${res10.status}, messageId: ${res10.json?.data?.id || res10.json?.id}`
    );

  } finally {
    await new Promise<void>((resolve) => server.close(() => resolve()));
  }

  return results;
}

// Self-executing runner
if (process.argv[1]?.endsWith('clusterMasterAccountAuthorizationTests.ts')) {
  runClusterMasterAccountAuthorizationTests()
    .then((results) => {
      const failed = Object.entries(results).filter(([_, r]) => r.status === 'FAILED');
      if (failed.length > 0) {
        console.error(`\nTest suite FAILED with ${failed.length} failure(s):`);
        failed.forEach(([id, r]) => console.error(`  - ${id}: ${r.reason}`));
        process.exit(1);
      } else {
        console.log('\nAll 10 cluster master account authorization tests PASSED successfully!\n');
        process.exit(0);
      }
    })
    .catch((err) => {
      console.error('\nTest suite execution crashed:', err);
      process.exit(1);
    });
}
