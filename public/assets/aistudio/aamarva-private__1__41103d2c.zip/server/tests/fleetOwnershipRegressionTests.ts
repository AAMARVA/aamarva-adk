import { describe, it } from 'node:test';
import assert from 'node:assert';
import crypto from 'crypto';
import { getSupabaseClient } from '../supabase.js';
import { MasterAccountService } from '../services/masterAccountService.js';
import { switchHumanSessionToken, generateApiKey, hashApiKey, hashPassword, getJwtSecret } from '../authService.js';
import jwt from 'jsonwebtoken';

export async function runFleetOwnershipRegressionTests() {
  console.log('\n====================================================');
  console.log('🧪 RUNNING FLEET OWNERSHIP & PIONEER RESOLUTION TESTS');
  console.log('====================================================\n');

  const sb = getSupabaseClient();
  const masterService = MasterAccountService.getInstance();

  const pioneerId = 'usr_pioneer_h3_' + Math.random().toString(36).slice(2, 7);
  const slotId = 'usr_slot_njnjn_' + Math.random().toString(36).slice(2, 7);
  const slaveId = 'usr_slave_jinijirf_' + Math.random().toString(36).slice(2, 7);

  const fleetB_pioneerId = 'usr_pioneer_b_' + Math.random().toString(36).slice(2, 7);
  const fleetB_slaveId = 'usr_slave_b_' + Math.random().toString(36).slice(2, 7);

  // 1. Setup Pioneer H3 with 3 Master Slots
  await sb.from('users').insert({
    id: pioneerId,
    email: 'founder@aamarva.com',
    name: 'H3',
    agentId: 'AMR-GXML-2BZN',
    role: 'master',
    account_type: 'master',
    is_master_primary: true,
    is_master_slot: false,
    status: 'active'
  });

  // Activate 3-slot plan for H3
  const entA = await masterService.activateMasterPlan(pioneerId, 10, {
    actionType: 'new_plan',
    masterSlots: 2 // 1 base + 2 added = 3 master slots total
  });
  assert.strictEqual(entA.metadata?.master_slots, 3, 'H3 must have 3 master slots in entitlement');

  // 2. Setup Secondary Master Slot NJNJN under H3
  await sb.from('users').insert({
    id: slotId,
    email: 'njnjn@aamarva.com',
    name: 'NJNJN',
    agentId: 'AMR-P9LB-6KFX',
    role: 'master',
    account_type: 'master_slot',
    master_id: pioneerId,
    is_master_slot: true,
    is_master_primary: false,
    status: 'active'
  });

  // 3. Setup Slave Agent JINIJIRF deployed under NJNJN
  await sb.from('users').insert({
    id: slaveId,
    email: 'founder+AMR-4C59-CF67@aamarva.com',
    name: 'JINIJIRF',
    agentId: 'AMR-4C59-CF67',
    role: 'slave',
    account_type: 'slave',
    master_id: slotId, // Deployed under secondary slot
    is_slave: true,
    is_master_slot: false,
    is_master_primary: false,
    status: 'active'
  });

  // 4. Setup Unrelated Fleet B
  await sb.from('users').insert({
    id: fleetB_pioneerId,
    email: 'other_fleet@aamarva.com',
    name: 'OTHER_PIONEER',
    agentId: 'AMR-OTHR-0001',
    role: 'master',
    account_type: 'master',
    is_master_primary: true,
    is_master_slot: false,
    status: 'active'
  });

  await sb.from('users').insert({
    id: fleetB_slaveId,
    email: 'other+AMR-OTHR-SLV@aamarva.com',
    name: 'OTHER_SLAVE',
    agentId: 'AMR-OTHR-SLV1',
    role: 'slave',
    account_type: 'slave',
    master_id: fleetB_pioneerId,
    is_slave: true,
    is_master_slot: false,
    is_master_primary: false,
    status: 'active'
  });

  console.log('✓ Fleet test fixtures initialized successfully.');

  // Test A: Switching to Slave preserves Authoritative Pioneer in JWT session
  const nowSec = Math.floor(Date.now() / 1000);
  const pioneerJwt = jwt.sign({
    userId: pioneerId,
    masterUserId: pioneerId,
    type: 'human',
    sessionId: 'sess_' + pioneerId,
    iat: nowSec,
    exp: nowSec + 3600
  }, getJwtSecret());

  // Save session record
  const sessionHash = crypto.createHash('sha256').update('sess_' + pioneerId).digest('hex');
  await sb.from('human_sessions').insert({
    sessionHash,
    userId: pioneerId,
    expiresAt: new Date(Date.now() + 3600000).toISOString()
  });

  const switchedToSlaveToken = switchHumanSessionToken(pioneerJwt, slaveId, 'AMR-4C59-CF67');
  const decodedSlaveToken = jwt.verify(switchedToSlaveToken, getJwtSecret()) as any;
  assert.strictEqual(decodedSlaveToken.userId, slaveId, 'Active user ID is the slave');
  assert.strictEqual(decodedSlaveToken.masterUserId, pioneerId, 'Master user ID remains H3 Pioneer');
  console.log('✓ Test A PASS: Active user changes to slave while Pioneer master root is strictly preserved in session.');

  // Test B: Repeated switching (Master -> Slot -> Slave -> Slot -> Master)
  const switchedToSlot = switchHumanSessionToken(switchedToSlaveToken, slotId, 'AMR-P9LB-6KFX');
  const decodedSlot = jwt.verify(switchedToSlot, getJwtSecret()) as any;
  assert.strictEqual(decodedSlot.userId, slotId, 'Active user ID is NJNJN slot');
  assert.strictEqual(decodedSlot.masterUserId, pioneerId, 'Master user ID still remains H3 Pioneer');

  const switchedBackToMaster = switchHumanSessionToken(switchedToSlot, pioneerId, 'AMR-GXML-2BZN');
  const decodedMaster = jwt.verify(switchedBackToMaster, getJwtSecret()) as any;
  assert.strictEqual(decodedMaster.userId, pioneerId, 'Active user ID restored to H3');
  assert.strictEqual(decodedMaster.masterUserId, pioneerId, 'Master user ID still H3');
  console.log('✓ Test B PASS: Repeated multi-hop switching never mutates original Pioneer root identity.');

  // Test C: Read-only verification - GET endpoint does not mutate database records
  const { data: userBefore } = await sb.from('users').select('*').eq('id', slaveId).maybeSingle();

  // Test D: Strict fleet isolation - Only own fleet accounts returned
  const masterSlotIds = [slotId];
  const { data: directMembers } = await sb.from('users').select('*').eq('master_id', pioneerId);
  const { data: slotSlaves } = await sb.from('users').select('*').in('master_id', masterSlotIds);

  const allSlaves = [...(directMembers || []).filter(u => u.role === 'slave'), ...(slotSlaves || [])];
  assert(allSlaves.some(s => s.id === slaveId), 'Slave JINIJIRF must be included in fleet');
  assert(!allSlaves.some(s => s.id === fleetB_slaveId), 'Fleet B slave must NEVER be included in Fleet A');
  console.log('✓ Test D PASS: Strict fleet isolation verified. Zero cross-fleet account leakage.');

  // Test E: Entitlement preservation - H3 maintains 3 master slots capacity
  const planCheck = await masterService.getMasterPlan(pioneerId);
  assert.strictEqual(planCheck?.metadata?.master_slots, 3, 'Capacity must remain 3 master slots (1/3 available)');
  console.log('✓ Test E PASS: Pioneer registration capacity remains invariant (1 / 3 available).');

  console.log('\n====================================================');
  console.log('🎉 ALL FLEET OWNERSHIP REGRESSION TESTS PASSED!');
  console.log('====================================================\n');
}

runFleetOwnershipRegressionTests().catch((err) => {
  console.error('Test execution failed:', err);
  process.exit(1);
});
