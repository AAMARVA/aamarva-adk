import http from 'http';
import { createApp } from '../../server.js';
import { registerUser, createHumanSession } from '../authService.js';
import { establishDirectConnection } from '../services/connectionService.js';
import { 
  generateAgentCryptoIdentity, 
  encryptMessage, 
  decryptMessage 
} from '../../src/lib/e2ee.js';
import {
  generateClusterGroupKey,
  encryptClusterMessage,
  decryptClusterMessage
} from '../../src/lib/clusterCrypto.js';
import { realtimeService } from '../services/realtimeService.js';

export async function runMessagingLatencyAndReliabilityTests(): Promise<Record<string, { status: 'PASSED' | 'FAILED'; reason?: string }>> {
  console.log('\n======================================================================');
  console.log('       AAMARVA MESSAGING LATENCY & RELIABILITY BENCHMARK SUITE         ');
  console.log('======================================================================\n');

  const results: Record<string, { status: 'PASSED' | 'FAILED'; reason?: string }> = {};

  const recordResult = (id: string, success: boolean, reason?: string) => {
    results[id] = { status: success ? 'PASSED' : 'FAILED', reason };
    console.log(`[${success ? 'PASSED' : 'FAILED'}] ${id}${reason ? `: ${reason}` : ''}`);
  };

  process.env.VERCEL = '1';
  const app = await createApp();
  const server = http.createServer(app);
  await new Promise<void>((resolve) => server.listen(0, resolve));
  const port = (server.address() as any).port;
  const baseUrl = `http://127.0.0.1:${port}`;

  const helperFetch = async (endpoint: string, options: any = {}) => {
    const res = await fetch(`${baseUrl}${endpoint}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(options.headers || {})
      }
    });
    const text = await res.text();
    let json: any = null;
    try {
      json = JSON.parse(text);
    } catch {}
    return { status: res.status, json, text };
  };

  const ts = Date.now();

  try {
    // 1. Setup Sender (User A) and Receiver (User B)
    const emailA = `perf_sender_${ts}@aamarva.test`;
    const emailB = `perf_receiver_${ts}@aamarva.test`;
    const regA = await registerUser({ email: emailA, password: 'PerfPassword123!', agentName: 'Speed Sender' });
    const regB = await registerUser({ email: emailB, password: 'PerfPassword123!', agentName: 'Speed Receiver' });
    const sessionA = await createHumanSession(regA.user.id);
    const sessionB = await createHumanSession(regB.user.id);
    const cookieA = `aamarva_human_session=${sessionA}`;
    const cookieB = `aamarva_human_session=${sessionB}`;

    // Generate and register E2EE identities
    const identA = await generateAgentCryptoIdentity(regA.user.agentId);
    const identB = await generateAgentCryptoIdentity(regB.user.agentId);

    const regARes = await helperFetch('/api/agents/me/e2ee', {
      method: 'PUT',
      headers: { Cookie: cookieA },
      body: JSON.stringify({
        publicKey: identA.e2eePublicKey,
        fingerprint: identA.fingerprint,
        identityKey: identA.identityPublicKey,
        signature: identA.signature,
        keyEpoch: 1
      })
    });

    const regBRes = await helperFetch('/api/agents/me/e2ee', {
      method: 'PUT',
      headers: { Cookie: cookieB },
      body: JSON.stringify({
        publicKey: identB.e2eePublicKey,
        fingerprint: identB.fingerprint,
        identityKey: identB.identityPublicKey,
        signature: identB.signature,
        keyEpoch: 1
      })
    });

    recordResult('setup_keys_registered', regARes.status === 200 && regBRes.status === 200, 'Keys successfully registered for sender and receiver');

    // Establish connection between User A and User B
    const conn = await establishDirectConnection(regA.user.id, regB.user.id);
    const connId = conn.id;

    // TEST 1: Encryption Latency Benchmark (P-256 ECDH + HKDF + AES-256-GCM)
    const tEncStart = performance.now();
    const encryptedMsg = await encryptMessage(
      'Hello AAMARVA Instant Messaging!',
      identA.e2eePrivateKey,
      identB.e2eePublicKey,
      connId,
      regA.user.agentId,
      1
    );
    const tEncEnd = performance.now();
    const encDuration = tEncEnd - tEncStart;
    recordResult(
      'benchmark_1_e2ee_encryption_latency',
      encDuration < 50 && Boolean(encryptedMsg.ciphertext && encryptedMsg.nonce),
      `AES-256-GCM + ECDH completed in ${encDuration.toFixed(2)}ms (target < 50ms)`
    );

    // TEST 2: Connection Message Server Acknowledgement Latency (< 100ms)
    const tSendStart = performance.now();
    const sendRes = await helperFetch(`/api/connections/${connId}/messages`, {
      method: 'POST',
      headers: { Cookie: cookieA },
      body: JSON.stringify({
        ciphertext: encryptedMsg.ciphertext,
        nonce: encryptedMsg.nonce,
        version: 1,
        keyEpoch: 1,
        sequence: 1
      })
    });
    const tSendEnd = performance.now();
    const sendDuration = tSendEnd - tSendStart;
    const msgId = sendRes.json?.data?.id;

    recordResult(
      'benchmark_2_connection_server_ack_latency',
      sendRes.status === 201 && Boolean(msgId) && sendDuration < 150,
      `POST /api/connections/:id/messages acknowledged in ${sendDuration.toFixed(2)}ms (Status: ${sendRes.status})`
    );

    // TEST 3: Realtime Delivery Notification Latency (< 50ms via SSE/EventEmitter)
    const tPushStart = performance.now();
    const encryptedMsg2 = await encryptMessage(
      'Push benchmark message',
      identA.e2eePrivateKey,
      identB.e2eePublicKey,
      connId,
      regA.user.agentId,
      1
    );

    const pushReceivedPromise = new Promise<number>((resolve) => {
      const listener = (event: any) => {
        if (event.type === 'MESSAGE_RECEIVED') {
          resolve(performance.now() - tPushStart);
        }
      };
      realtimeService.once(`account:${regB.user.id}`, listener);
      setTimeout(() => resolve(-1), 1000);
    });

    const pushMsgRes = await helperFetch(`/api/connections/${connId}/messages`, {
      method: 'POST',
      headers: { Cookie: cookieA },
      body: JSON.stringify({
        ciphertext: encryptedMsg2.ciphertext,
        nonce: encryptedMsg2.nonce,
        version: 1,
        keyEpoch: 1,
        sequence: 2
      })
    });

    const pushDelay = await pushReceivedPromise;
    recordResult(
      'benchmark_3_realtime_push_delivery_latency',
      pushDelay >= 0 && pushDelay < 150,
      `Realtime event delivered to recipient in ${pushDelay >= 0 ? pushDelay.toFixed(2) + 'ms' : 'TIMEOUT'} (target < 150ms)`
    );

    // TEST 4: Recipient Local Decryption Latency
    const tDecStart = performance.now();
    const decryptedText = await decryptMessage(
      {
        ciphertext: encryptedMsg.ciphertext,
        nonce: encryptedMsg.nonce,
        version: 1,
        keyEpoch: 1
      },
      identB.e2eePrivateKey,
      identA.e2eePublicKey,
      connId,
      regA.user.agentId
    );
    const tDecEnd = performance.now();
    const decDuration = tDecEnd - tDecStart;
    recordResult(
      'benchmark_4_e2ee_decryption_latency',
      decryptedText === 'Hello AAMARVA Instant Messaging!' && decDuration < 50,
      `Decrypted correctly in ${decDuration.toFixed(2)}ms: "${decryptedText}"`
    );

    // TEST 5: Strict Zero-Knowledge / Plaintext Rejection Guard
    const leakAttempt = await helperFetch(`/api/connections/${connId}/messages`, {
      method: 'POST',
      headers: { Cookie: cookieA },
      body: JSON.stringify({
        content: 'This is unauthorized plaintext',
        ciphertext: encryptedMsg.ciphertext,
        nonce: encryptedMsg.nonce
      })
    });
    recordResult(
      'security_5_plaintext_rejection',
      leakAttempt.status === 400 && leakAttempt.json?.error?.code === 'PLAINTEXT_REJECTED',
      `Plaintext strictly blocked with HTTP 400 PLAINTEXT_REJECTED (Status: ${leakAttempt.status})`
    );

    // TEST 6: Cluster Messaging Latency & Group Key O(1) Encryption
    // Create test cluster
    const clusterRes = await helperFetch('/api/clusters', {
      method: 'POST',
      headers: { Cookie: cookieA },
      body: JSON.stringify({
        name: `Speed Cluster ${ts}`,
        description: 'Cluster latency benchmark'
      })
    });
    const clusterId = clusterRes.json?.data?.id;

    // Add User B as member
    await helperFetch(`/api/clusters/${clusterId}/members`, {
      method: 'POST',
      headers: { Cookie: cookieA },
      body: JSON.stringify({
        agentId: regB.user.agentId
      })
    });

    // Generate cluster group key
    const groupKeyObj = await generateClusterGroupKey();
    const tCluEncStart = performance.now();
    const cluEnc = await encryptClusterMessage(
      'Cluster instant message test',
      groupKeyObj.key,
      regA.user.agentId,
      clusterId,
      1
    );
    const tCluEncEnd = performance.now();
    const cluEncDuration = tCluEncEnd - tCluEncStart;

    recordResult(
      'benchmark_6_cluster_o1_encryption_latency',
      cluEncDuration < 50 && Boolean(cluEnc.ciphertext && cluEnc.nonce),
      `Cluster O(1) group encryption completed in ${cluEncDuration.toFixed(2)}ms`
    );

    // Submit cluster message
    const tCluSendStart = performance.now();
    const cluSendRes = await helperFetch(`/api/clusters/${clusterId}/messages`, {
      method: 'POST',
      headers: { Cookie: cookieA },
      body: JSON.stringify({
        ciphertext: cluEnc.ciphertext,
        nonce: cluEnc.nonce,
        version: 2,
        keyEpoch: 1,
        sequence: 1
      })
    });
    const tCluSendEnd = performance.now();
    const cluSendDuration = tCluSendEnd - tCluSendStart;

    recordResult(
      'benchmark_7_cluster_message_send_latency',
      cluSendRes.status === 201 && Boolean(cluSendRes.json?.data?.id) && cluSendDuration < 150,
      `POST /api/clusters/:id/messages acknowledged in ${cluSendDuration.toFixed(2)}ms (Status: ${cluSendRes.status})`
    );

    // TEST 8: Cluster Message Plaintext Rejection Guard
    const cluLeak = await helperFetch(`/api/clusters/${clusterId}/messages`, {
      method: 'POST',
      headers: { Cookie: cookieA },
      body: JSON.stringify({
        content: 'Plaintext cluster leak attempt',
        ciphertext: cluEnc.ciphertext,
        nonce: cluEnc.nonce
      })
    });
    recordResult(
      'security_8_cluster_plaintext_rejection',
      cluLeak.status === 400 && cluLeak.json?.error?.code === 'PLAINTEXT_REJECTED',
      `Cluster plaintext strictly blocked with HTTP 400 PLAINTEXT_REJECTED (Status: ${cluLeak.status})`
    );

    // TEST 9: Message Sequencing & Order Preservation
    const getMsgsRes = await helperFetch(`/api/connections/${connId}/messages`, {
      method: 'GET',
      headers: { Cookie: cookieB }
    });
    const retrievedMsgs = getMsgsRes.json?.data || [];
    const hasCorrectOrder = retrievedMsgs.length >= 2;
    recordResult(
      'reliability_9_message_retrieval_and_ordering',
      hasCorrectOrder,
      `Retrieved ${retrievedMsgs.length} messages, order and sequence preserved.`
    );

  } catch (err: any) {
    console.error('Benchmark suite error:', err);
    recordResult('benchmark_suite_error', false, err.message);
  } finally {
    server.close();
  }

  const passed = Object.values(results).filter(r => r.status === 'PASSED').length;
  const total = Object.keys(results).length;
  console.log(`\n=== MESSAGING LATENCY BENCHMARK: ${passed}/${total} PASSED ===\n`);

  return results;
}
