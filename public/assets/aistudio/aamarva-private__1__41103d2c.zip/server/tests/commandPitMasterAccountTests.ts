import assert from 'node:assert';
import { normalizeUserRecord } from '../authService.js';
import { getAgentProfile } from '../services/agentService.js';
import { isSlaveAccount, isMasterAccountProfile } from '../../src/services/authApi.js';
import { getSupabaseClient } from '../supabase.js';

async function runCommandPitMasterAccountTests() {
  console.log('--- RUNNING COMMAND PIT MASTER ACCOUNT VISIBILITY TESTS ---');
  const supabase = getSupabaseClient();

  const pioneerId = 'pioneer_test_' + Math.random().toString(36).substring(2, 7);
  const pioneerAgentId = 'AMR-PION-001';
  const pioneerEmail = `pioneer_${pioneerId}@aamarva.net`;

  const additionalMasterId = 'master_slot_' + Math.random().toString(36).substring(2, 7);
  const additionalMasterAgentId = 'AMR-SLOT-002';
  const additionalMasterEmail = `slot_${additionalMasterId}@aamarva.net`;

  const slaveId = 'slave_test_' + Math.random().toString(36).substring(2, 7);
  const slaveAgentId = 'AMR-SLAV-003';
  const slaveEmail = `pioneer_${pioneerId}+${slaveAgentId}@aamarva.net`;

  // Insert mock accounts into database
  const pioneerRecord = {
    id: pioneerId,
    agentId: pioneerAgentId,
    email: pioneerEmail,
    name: 'Pioneer Master Test',
    status: 'active',
    is_master_primary: true,
    account_type: 'master',
    role: 'master',
    is_slave: false,
    passwordHash: 'dummy'
  };

  const additionalMasterRecord = {
    id: additionalMasterId,
    agentId: additionalMasterAgentId,
    email: additionalMasterEmail,
    name: 'Additional Master Test',
    status: 'active',
    master_id: pioneerId,
    is_master_primary: false,
    is_master_slot: true,
    account_type: 'master_slot',
    role: 'master',
    is_slave: false,
    passwordHash: 'dummy'
  };

  const slaveRecord = {
    id: slaveId,
    agentId: slaveAgentId,
    email: slaveEmail,
    name: 'Fleet Slave Test',
    status: 'active',
    master_id: pioneerId,
    is_master_primary: false,
    is_master_slot: false,
    account_type: 'slave',
    role: 'slave',
    is_slave: true,
    passwordHash: 'dummy'
  };

  await supabase.from('users').insert([pioneerRecord, additionalMasterRecord, slaveRecord]);

  // TEST 1: Pioneer Master Profile Normalization & Command Pit Visibility
  console.log('[TEST 1] Verifying Pioneer Master profile normalization...');
  const normPioneer = normalizeUserRecord(pioneerRecord);
  assert.strictEqual(normPioneer.is_master_primary, true, 'Pioneer must have is_master_primary = true');
  assert.strictEqual(normPioneer.isMasterUser, true, 'Pioneer must have isMasterUser = true');
  assert.strictEqual(normPioneer.is_slave, false, 'Pioneer must have is_slave = false');
  assert.strictEqual(isMasterAccountProfile(normPioneer), true, 'isMasterAccountProfile must be true for Pioneer');
  assert.strictEqual(isSlaveAccount(normPioneer), false, 'Command Pit must be VISIBLE (isSlaveAccount = false) for Pioneer Master');
  console.log('✅ [TEST 1 PASSED] Pioneer Master has full Command Pit visibility.');

  // TEST 2: Additional Master Profile Normalization & Command Pit Visibility
  console.log('[TEST 2] Verifying Additional Master profile normalization & visibility...');
  const normAdditional = normalizeUserRecord(additionalMasterRecord);
  assert.strictEqual(normAdditional.is_master_slot, true, 'Additional master must have is_master_slot = true');
  assert.strictEqual(normAdditional.account_type, 'master_slot', 'Additional master must have account_type = master_slot');
  assert.strictEqual(normAdditional.isMasterUser, true, 'Additional master must have isMasterUser = true');
  assert.strictEqual(normAdditional.is_slave, false, 'Additional master must NOT be marked as slave');
  assert.strictEqual(isMasterAccountProfile(normAdditional), true, 'isMasterAccountProfile must be true for Additional Master');
  assert.strictEqual(isSlaveAccount(normAdditional), false, 'Command Pit must be VISIBLE (isSlaveAccount = false) for Additional Master');
  console.log('✅ [TEST 2 PASSED] Additional Master has full Command Pit visibility.');

  // TEST 3: getAgentProfile accurately loads Additional Master without degrading to slave
  console.log('[TEST 3] Verifying getAgentProfile returns non-slave master slot for Additional Master...');
  const fetchedAdditionalProfile = await getAgentProfile(additionalMasterAgentId, true);
  assert.ok(fetchedAdditionalProfile, 'getAgentProfile must return profile');
  assert.strictEqual(fetchedAdditionalProfile.is_slave, false, 'Profile is_slave must be false');
  assert.strictEqual(fetchedAdditionalProfile.isMasterUser, true, 'Profile isMasterUser must be true');
  assert.strictEqual(fetchedAdditionalProfile.is_master_slot, true, 'Profile is_master_slot must be true');
  assert.strictEqual(fetchedAdditionalProfile.account_type, 'master_slot', 'Profile account_type must be master_slot');
  assert.strictEqual(isSlaveAccount(fetchedAdditionalProfile), false, 'Command Pit must remain VISIBLE after getAgentProfile refresh');
  console.log('✅ [TEST 3 PASSED] getAgentProfile preserves Additional Master status and Command Pit visibility on refresh.');

  // TEST 4: Unauthorized account types (Slaves) are properly restricted
  console.log('[TEST 4] Verifying Slave Account is properly restricted from Command Pit...');
  const normSlave = normalizeUserRecord(slaveRecord);
  assert.strictEqual(normSlave.is_slave, true, 'Slave must have is_slave = true');
  assert.strictEqual(normSlave.isMasterUser, false, 'Slave must have isMasterUser = false');
  assert.strictEqual(isMasterAccountProfile(normSlave), false, 'isMasterAccountProfile must be false for slave');
  assert.strictEqual(isSlaveAccount(normSlave), true, 'Command Pit must be HIDDEN (isSlaveAccount = true) for slave account');
  console.log('✅ [TEST 4 PASSED] Unauthorized account types correctly restricted from Command Pit.');

  // TEST 5: Verify slave account with human session payload isMasterUser=true flag remains classified as SLAVE
  console.log('[TEST 5] Verifying slave account carrying human session isMasterUser=true flag is correctly classified as SLAVE...');
  const slaveWithHumanPayload = {
    ...normSlave,
    isMasterUser: true // Attached by human session payload
  };
  assert.strictEqual(isMasterAccountProfile(slaveWithHumanPayload), false, 'Slave account must NEVER be recognized as master account profile');
  assert.strictEqual(isSlaveAccount(slaveWithHumanPayload), true, 'isSlaveAccount MUST return true for slave account carrying human session flag');
  console.log('✅ [TEST 5 PASSED] Slave account carrying human session isMasterUser=true flag correctly hidden from Command Pit.');

  // Clean up
  await supabase.from('users').delete().in('id', [pioneerId, additionalMasterId, slaveId]);
  console.log('🎉 ALL COMMAND PIT MASTER ACCOUNT TESTS PASSED SUCCESSFULLY!');
}

runCommandPitMasterAccountTests().catch((err) => {
  console.error('❌ TEST FAILED:', err);
  process.exit(1);
});
