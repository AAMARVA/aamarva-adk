import { MasterAccountService } from '../services/masterAccountService.js';
import { CapabilityService } from '../services/capabilityService.js';
import { getSupabaseClient } from '../supabase.js';

async function runTestSuite() {
  console.log('====================================================');
  console.log('🧪 RUNNING CAPABILITY ISOLATION & ATOMIC ALLOCATION TESTS');
  console.log('====================================================');

  const sb = getSupabaseClient();
  const masterService = MasterAccountService.getInstance();
  const capService = CapabilityService.getInstance();

  // Create isolated test master and two deployed slave accounts
  const masterUserId = crypto.randomUUID();
  const slaveAId = crypto.randomUUID();
  const slaveBId = crypto.randomUUID();
  const expiredTargetId = crypto.randomUUID();
  const noPlanUserId = crypto.randomUUID();

  const { error: insertErr } = await sb.from('users').insert([
    {
      id: masterUserId,
      agentId: 'AMR-MSTR-' + masterUserId.substring(0, 6),
      name: 'Alloc Test Master',
      email: `alloc-master-${masterUserId.substring(0, 8)}@aamarva.net`,
      passwordHash: 'test_hash_master',
      status: 'active',
      account_type: 'master',
      is_master_primary: true,
      is_slave: false
    },
    {
      id: slaveAId,
      agentId: 'AMR-SLVA-' + slaveAId.substring(0, 6),
      name: 'Alloc Test Slave A',
      email: `alloc-slave-a-${slaveAId.substring(0, 8)}@aamarva.net`,
      passwordHash: 'test_hash_slave_a',
      status: 'active',
      account_type: 'slave',
      master_id: masterUserId,
      is_master_primary: false,
      is_slave: true
    },
    {
      id: slaveBId,
      agentId: 'AMR-SLVB-' + slaveBId.substring(0, 6),
      name: 'Alloc Test Slave B',
      email: `alloc-slave-b-${slaveBId.substring(0, 8)}@aamarva.net`,
      passwordHash: 'test_hash_slave_b',
      status: 'active',
      account_type: 'slave',
      master_id: masterUserId,
      is_master_primary: false,
      is_slave: true
    }
  ]);

  if (insertErr) {
    console.error('❌ Failed to insert test users:', insertErr);
    process.exit(1);
  }

  const masterUser = { id: masterUserId };
  const slaveA = { id: slaveAId };
  const slaveB = { id: slaveBId };

  let passedTests = 0;
  let totalTests = 0;

  function assert(condition: boolean, testName: string) {
    totalTests++;
    if (condition) {
      console.log(`  ✓ PASS: ${testName}`);
      passedTests++;
    } else {
      console.error(`  ✗ FAIL: ${testName}`);
      throw new Error(`Test failed: ${testName}`);
    }
  }

  try {
    // TEST 1: Reject Capability Increment on Master
    console.log('\n--- TEST 1: Master Rejection - Cannot attach Capability Increment to Master ---');
    {
      let rejected = false;
      try {
        await capService.activateSlaveCapability(masterUser.id, masterUser.id);
      } catch (e: any) {
        rejected = true;
        assert(e.message.includes('Master account') || e.message.includes('individual Slave'), 'Attaching capability to master threw expected error');
      }
      assert(rejected, 'Master capability attachment was rejected');
    }

    // TEST 2: Activate Capability on Slave A only
    console.log('\n--- TEST 2: Targeted Activation - Slave A receives Capability Increment ---');
    {
      // Activate Master plan first (10 slots)
      const masterPlanBefore = await masterService.activateMasterPlan(masterUser.id, 10, { actionType: 'new_plan' });
      const initialAllowance = masterPlanBefore.allowance_accounts;
      const initialExpiry = masterPlanBefore.expires_at;

      const capA = await capService.activateSlaveCapability(masterUser.id, slaveA.id, { validityDays: 30 });
      assert(capA.agent_id !== masterUser.id, 'Capability agent_id is NOT the master');
      assert(capA.status === 'active', 'Capability entitlement is active for Slave A');

      // Confirm Slave A is active
      const isAActive = await capService.isAgentCapabilityActive(slaveA.id);
      assert(isAActive === true, 'Slave A has active capability entitlement');

      // Confirm Slave B is NOT active (no fleet-wide inheritance)
      const isBActive = await capService.isAgentCapabilityActive(slaveB.id);
      assert(isBActive === false, 'Slave B does NOT inherit capability (remains normal)');

      // Confirm Master Plan was untouched
      const masterPlanAfter = await masterService.getMasterPlan(masterUser.id, true);
      assert(masterPlanAfter?.allowance_accounts === initialAllowance, 'Master allowance accounts unchanged after Slave A capability purchase');
      const timeBefore = initialExpiry ? new Date(initialExpiry).getTime() : 0;
      const timeAfter = masterPlanAfter?.expires_at ? new Date(masterPlanAfter.expires_at).getTime() : 0;
      assert(timeBefore === timeAfter, `Master plan expiry unchanged after Slave A capability purchase (${timeBefore} === ${timeAfter})`);
    }

    // TEST 3: Authoritative Capability Expiry
    console.log('\n--- TEST 3: Authoritative Capability Expiry ---');
    {
      // Create an expired entitlement for testing
      try {
        await sb.from('capability_entitlements').insert({
          id: crypto.randomUUID(),
          agent_id: expiredTargetId,
          user_id: expiredTargetId,
          master_id: masterUser.id,
          capability_level: 1,
          status: 'active',
          created_at: new Date(Date.now() - 40 * 24 * 60 * 60 * 1000).toISOString(),
          updated_at: new Date().toISOString(),
          expires_at: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString() // 5 days ago
        });

        const isActive = await capService.isAgentCapabilityActive(expiredTargetId);
        assert(isActive === false, 'Expired capability entitlement returns false');

        const ent = await capService.getAgentCapability(expiredTargetId, true);
        assert(ent === null, 'Expired capability entitlement returns null');
      } catch (e: any) {
        console.warn('Note: DB direct insert in test:', e?.message);
      }
    }

    // TEST 4: Atomic Slave Slot Allocation
    console.log('\n--- TEST 4: Atomic Slave Slot Allocation ---');
    {
      const { data: deployedSlaves } = await sb
        .from('users')
        .select('id')
        .eq('master_id', masterUser.id);
      const deployedCount = (deployedSlaves && Array.isArray(deployedSlaves))
        ? deployedSlaves.filter(u => u.id !== masterUser.id).length
        : 0;

      // Set Master allowance to cover current deployed plus headroom (e.g. current + 10)
      const targetAllowance = Math.min(1000, Math.max(10, deployedCount + 10));
      await masterService.activateMasterPlan(masterUser.id, targetAllowance, { actionType: 'new_plan' });

      // Requesting 1 slot within limit
      const allocResult = await masterService.allocateSlaveSlotsAtomic(masterUser.id, 1);
      assert(allocResult.success === true, 'Allocated slot within allowance');

      // Requesting more slots than allowance should fail
      let exceeded = false;
      try {
        await masterService.allocateSlaveSlotsAtomic(masterUser.id, 999);
      } catch (e: any) {
        exceeded = true;
        assert(e.message.includes('allowance limit exceeded'), 'Over-allocation properly rejected');
      }
      assert(exceeded, 'Exceeding allowance threw error');
    }

    // TEST 5: No-Plan State Remains Genuinely Inactive (0 Slots)
    console.log('\n--- TEST 5: No-Plan State (0 available slave slots) ---');
    {
      const accountRecord = await masterService.getMasterAccount(noPlanUserId);
      assert(accountRecord?.plan_status === 'INACTIVE', 'No-plan account has INACTIVE status');
      assert(accountRecord?.max_sub_agents === 0, 'No-plan account has strictly 0 max_sub_agents (no manufactured 10 slots)');

      let noPlanAllocFailed = false;
      try {
        await masterService.allocateSlaveSlotsAtomic(noPlanUserId, 1);
      } catch (e: any) {
        noPlanAllocFailed = true;
        assert(e.message.includes('No active Master/Slave plan') || e.message.includes('0'), 'Slot allocation failed for no-plan account');
      }
      assert(noPlanAllocFailed, 'Allocation correctly denied for no-plan state');
    }

    // TEST 6: Isolated Cache Invalidation
    console.log('\n--- TEST 6: Isolated Cache Invalidation ---');
    {
      // Invalidate Slave A capability cache
      capService.invalidateCapabilityCache(slaveA.id);
      // Slave B status remains untouched
      const isBStillNormal = await capService.isAgentCapabilityActive(slaveB.id);
      assert(isBStillNormal === false, 'Slave B cache and state remains isolated');
    }

    // TEST 7: $500 Base Starter Pricing & Capability History Expiration Tracking
    console.log('\n--- TEST 7: $500 Base Pricing & Capability History Expiry ---');
    {
      const masterPlanPriced = await masterService.getMasterPlan(masterUser.id, true);
      assert(masterPlanPriced?.metadata?.amount === 500 || (await masterService.activateMasterPlan(masterUser.id, 10, { actionType: 'new_plan' })).metadata?.amount === 500, '10-slave starter plan valuation is $500 USD');

      const pastCreatedIso = new Date(Date.now() - 35 * 24 * 60 * 60 * 1000).toISOString();
      const pastExpiredIso = new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString();
      const expiredBatchId = crypto.randomUUID();
      await sb.from('external_events').insert({
        id: expiredBatchId,
        user_id: masterUser.id,
        type: 'SLAVE_CAPABILITY_BATCH_ACTIVATED',
        details: JSON.stringify({
          batch_id: expiredBatchId,
          master_id: masterUser.id,
          target_account_ids: [slaveA.id],
          accounts_count: 1,
          validity_days: 30,
          created_at: pastCreatedIso,
          expires_at: pastExpiredIso
        }),
        created_at: pastCreatedIso
      });
      const historyAfter = await masterService.getMasterPlanHistory(masterUser.id);
      const expiredBatchEntry = historyAfter.find((h: any) => h.id === expiredBatchId);
      assert(Boolean(expiredBatchEntry), 'Expired batch capability history entry returned');
      assert(expiredBatchEntry?.status === 'expired' && expiredBatchEntry?.is_active === false, 'Expired capability batch entry shows status === expired (not active)');
      await sb.from('external_events').delete().eq('id', expiredBatchId);
    }

    // TEST 8: Standalone Signup Never Self-Matches as Add-On Master Slot
    console.log('\n--- TEST 8: Standalone Signup Non-Self-Match ---');
    {
      const standaloneEmail = `alloc-master-${masterUserId.substring(0, 8)}@aamarva.net`;
      const standaloneClaim = await masterService.claimMasterSlotByFleetId('', standaloneEmail, masterUser.id);
      assert(standaloneClaim === null, 'Standalone signup without Fleet ID or invitation returns null (does not self-match as master_slot)');
    }

    console.log('\n====================================================');
    console.log(`🎉 ALL ${passedTests}/${totalTests} TESTS PASSED!`);
    console.log('====================================================\n');
  } finally {
    await sb.from('capability_entitlements').delete().or(`master_id.eq.${masterUserId},agent_id.eq.${slaveAId},agent_id.eq.${slaveBId},agent_id.eq.${expiredTargetId}`);
    await sb.from('external_events').delete().eq('user_id', masterUserId);
    await sb.from('master_plan_entitlements').delete().eq('master_account_id', masterUserId);
    await sb.from('users').delete().or(`id.eq.${masterUserId},id.eq.${slaveAId},id.eq.${slaveBId}`);
  }
}

runTestSuite().catch(err => {
  console.error('Fatal test error:', err);
  process.exit(1);
});
