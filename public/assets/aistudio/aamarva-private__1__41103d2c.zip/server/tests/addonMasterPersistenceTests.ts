import { MasterAccountService } from '../services/masterAccountService.js';
import { getSupabaseClient } from '../supabase.js';
import { registerUser, findUserById, verifyHumanSession, createHumanSession, invalidateUserRecordCache } from '../authService.js';
import { isMasterAccount } from '../middleware/authMiddleware.js';
import crypto from 'crypto';

export async function runAddonMasterPersistenceTests() {
  console.log('====================================================');
  console.log('🧪 RUNNING ADD-ON MASTER PERSISTENCE & RECOGNITION TESTS');
  console.log('====================================================');

  const sb = getSupabaseClient();
  const masterService = MasterAccountService.getInstance();

  let passed = 0;
  let total = 0;

  function assert(condition: boolean, testName: string, detail?: string) {
    total++;
    if (condition) {
      console.log(`  ✓ PASS: ${testName}`);
      passed++;
    } else {
      console.error(`  ✗ FAIL: ${testName} ${detail ? `(${detail})` : ''}`);
      throw new Error(`Test failed: ${testName}`);
    }
  }

  // 1. Setup Pioneer Master Account with a plan containing master slots
  const pioneerEmail = `pioneer_${crypto.randomBytes(4).toString('hex')}@aamarva-test.com`;
  const pioneerReg = await registerUser({
    email: pioneerEmail,
    password: 'PioneerPassword123!',
    agentName: 'Pioneer Master'
  });

  const pioneerId = pioneerReg.user.id;
  
  // Set Pioneer as primary master
  await sb.from('users').update({
    is_master_primary: true,
    account_type: 'master',
    role: 'master',
    master_id: pioneerId
  }).eq('id', pioneerId);

  // Activate Master Plan with 1 Add-On Master Slot
  const addonEmail = `addon_${crypto.randomBytes(4).toString('hex')}@aamarva-test.com`;
  const plan = await masterService.activateMasterPlan(pioneerId, 10, {
    actionType: 'new_plan',
    masterSlots: 1,
    masterRegistrationEmail: addonEmail
  });

  const fleetId = plan.metadata?.latest_fleet_id || plan.metadata?.fleet_id;
  assert(Boolean(fleetId), 'Pioneer plan generated fleet_id', `Fleet ID: ${fleetId}`);

  // TEST A: Add-On Master Registration via Pioneer Invitation/Fleet Slot Claim
  console.log('\n--- TEST A: Add-On Master Registration & Fleet Slot Claim ---');
  const addonReg = await registerUser({
    email: addonEmail,
    password: 'AddonPassword123!',
    agentName: 'AddOn Master 1'
  });
  const addonId = addonReg.user.id;

  const claimResult = await masterService.claimMasterSlotByFleetId(fleetId, addonEmail, addonId);
  assert(claimResult !== null && claimResult.success === true, 'Master slot claimed successfully by Add-On Master email & fleetId');

  // Update DB row as done in register endpoint
  const { error: updateErr } = await sb.from('users').update({
    master_id: pioneerId,
    fleet_id: fleetId,
    account_type: 'master_slot',
    role: 'master',
    is_master_slot: true,
    is_master_primary: false
  }).eq('id', addonId);

  invalidateUserRecordCache(addonId);
  assert(updateErr === null, 'Add-On Master database update executed without errors');

  // TEST B: Database Persistence Verification
  console.log('\n--- TEST B: Users Table Database Persistence ---');
  const { data: dbUser, error: dbErr } = await sb.from('users').select('*').eq('id', addonId).single();
  assert(dbErr === null && dbUser !== null, 'Fetched raw DB user record for Add-On Master');
  assert(dbUser.master_id === pioneerId, 'Persisted master_id matches Pioneer ID', `master_id: ${dbUser.master_id}`);
  assert(dbUser.fleet_id === fleetId, 'Persisted fleet_id matches Pioneer fleet_id', `fleet_id: ${dbUser.fleet_id}`);
  assert(dbUser.account_type === 'master_slot', 'Persisted account_type is master_slot', `account_type: ${dbUser.account_type}`);
  assert(dbUser.role === 'master', 'Persisted role is master', `role: ${dbUser.role}`);
  assert(dbUser.is_master_slot === true, 'Persisted is_master_slot is true', `is_master_slot: ${dbUser.is_master_slot}`);
  assert(dbUser.is_master_primary === false, 'Persisted is_master_primary is false', `is_master_primary: ${dbUser.is_master_primary}`);

  // TEST C: Logout & Re-authentication Session Recovery
  console.log('\n--- TEST C: Logout and Re-authentication Recovery ---');
  const sessionToken = await createHumanSession(addonId);
  const sessionPayload = await verifyHumanSession(sessionToken);
  assert(sessionPayload !== null, 'Human session verified successfully after login');
  assert(sessionPayload?.account_type === 'master_slot', 'Session payload recovers account_type === master_slot', `type: ${sessionPayload?.account_type}`);
  assert(sessionPayload?.is_master_slot === true, 'Session payload recovers is_master_slot === true', `is_master_slot: ${sessionPayload?.is_master_slot}`);
  assert(sessionPayload?.is_master_primary === false, 'Session payload recovers is_master_primary === false', `is_master_primary: ${sessionPayload?.is_master_primary}`);
  assert(sessionPayload?.master_id === pioneerId, 'Session payload recovers master_id pointing to Pioneer ID', `master_id: ${sessionPayload?.master_id}`);
  assert(sessionPayload?.isMasterUser === true, 'Session payload marks isMasterUser === true for operational capabilities');

  // TEST D: Pioneer vs Add-On Master Permissions Comparison
  console.log('\n--- TEST D: Pioneer vs Add-On Master Operational Capabilities ---');
  const pioneerReq: any = { user: { id: pioneerId, is_master_primary: true, role: 'master', account_type: 'master' } };
  const addonReq: any = { user: { id: addonId, master_id: pioneerId, is_master_primary: false, role: 'master', account_type: 'master_slot', is_master_slot: true } };

  const pioneerIsMaster = isMasterAccount(pioneerReq);
  const addonIsMaster = isMasterAccount(addonReq);

  assert(pioneerIsMaster === true, 'isMasterAccount(req) returns true for Pioneer Master');
  assert(addonIsMaster === true, 'isMasterAccount(req) returns true for Add-On Master');
  assert(pioneerReq.user.is_master_primary === true, 'Pioneer is_master_primary is true (Principal Owner)');
  assert(addonReq.user.is_master_primary === false, 'Add-On Master is_master_primary is false (Subordinate Master)');

  // TEST E: Slave Account Deployment via Add-On Master
  console.log('\n--- TEST E: Slave Account Deployment via Add-On Master ---');
  const slaveEmail = `slave_${crypto.randomBytes(4).toString('hex')}@aamarva-test.com`;
  const slaveReg = await registerUser({
    email: slaveEmail,
    password: 'SlavePassword123!',
    agentName: 'Subordinate Slave 1',
    master_id: addonId,
    fleet_id: fleetId,
    account_type: 'slave',
    role: 'slave',
    is_slave: true
  });

  const slaveId = slaveReg.user.id;
  await sb.from('users').update({
    master_id: addonId,
    fleet_id: fleetId,
    owner_email: pioneerEmail,
    account_type: 'slave',
    role: 'slave',
    is_slave: true
  }).eq('id', slaveId);

  const { data: dbSlave } = await sb.from('users').select('*').eq('id', slaveId).single();
  assert(dbSlave.master_id === addonId, 'Slave master_id references Add-On Master ID', `master_id: ${dbSlave.master_id}`);
  assert(dbSlave.owner_email === pioneerEmail || dbUser.email === addonEmail, 'Slave associated with fleet hierarchy');
  assert(dbSlave.fleet_id === fleetId, 'Slave fleet_id matches Pioneer fleet_id', `fleet_id: ${dbSlave.fleet_id}`);

  // TEST F: Pioneer Entitlement Ownership Retention
  console.log('\n--- TEST F: Pioneer Entitlement Ownership Retention ---');
  const pioneerPlanAfter = await masterService.getMasterPlan(pioneerId, true);
  assert(pioneerPlanAfter !== null, 'Pioneer entitlement plan exists and remains active');
  assert(pioneerPlanAfter?.master_account_id === pioneerId, 'Master entitlement plan is strictly owned by Pioneer ID', `owner: ${pioneerPlanAfter?.master_account_id}`);

  console.log('\n====================================================');
  console.log(`🎉 ALL ${passed}/${total} ADD-ON MASTER PERSISTENCE TESTS PASSED!`);
  console.log('====================================================');

  process.exit(0);
  return { passed, total };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  runAddonMasterPersistenceTests().catch(err => {
    console.error('Test suite failed:', err);
    process.exit(1);
  });
}
