import express from 'express';
import http from 'http';
import crypto from 'crypto';
import cookieParser from 'cookie-parser';
import aamarvaRouter from '../routes/aamarvaRoutes';
import clusterRouter from '../routes/clusterRoutes';
import floorRouter from '../routes/floorRoutes';
import { slaveActivityMiddleware } from '../middleware/slaveActivityMiddleware';
import { getSupabaseClient } from '../supabase';
import { registerUser, createHumanSession } from '../authService';
import { deriveAgentCryptoIdentity } from '../../src/lib/e2ee';
import { createPendingInvocationRecord } from '../services/mcpService';

export async function runThreeCoreOperationsTest(): Promise<boolean> {
  console.log('\n=== VERIFYING THREE CORE OPERATIONS: EXACTLY ONE EVENT EACH ===\n');

  const app = express();
  app.use(cookieParser());
  app.use(express.json());
  app.use(slaveActivityMiddleware);
  app.use('/api', aamarvaRouter);
  app.use('/api', clusterRouter);
  app.use('/api/floor', floorRouter);

  const server = http.createServer(app);
  await new Promise<void>((resolve) => server.listen(0, resolve));
  const port = (server.address() as any).port;
  const baseUrl = `http://127.0.0.1:${port}`;

  const helperFetch = async (endpoint: string, options: any = {}) => {
    const res = await fetch(`${baseUrl}${endpoint}`, {
      ...options,
      headers: {
        'Accept': 'application/json',
        ...(options.headers || {})
      }
    });
    const text = await res.text();
    let json: any = null;
    try {
      json = JSON.parse(text);
    } catch {}
    return { status: res.status, json, text };
  };

  try {
    const supabase = getSupabaseClient();
    const ts = Date.now();

    // 1. Setup Master User A
    const emailA = `core_master_a_${ts}@aamarva.test`;
    const regA = await registerUser({ email: emailA, password: 'MasterPassword123!', agentName: 'Core Master A' });
    const masterA = regA.user;
    const sessionTokenA = await createHumanSession(masterA.id);

    // 2. Setup Peer User B
    const emailB = `core_peer_b_${ts}@aamarva.test`;
    const regB = await registerUser({ email: emailB, password: 'PeerPassword123!', agentName: 'Core Peer B' });
    const peerB = regB.user;
    const sessionTokenB = await createHumanSession(peerB.id);

    // 3. Register real authenticated E2EE cryptographic identities for both nodes
    const keysA = await deriveAgentCryptoIdentity(masterA.agentId, 'MasterPassword123!');
    const keysB = await deriveAgentCryptoIdentity(peerB.agentId, 'PeerPassword123!');

    await helperFetch('/api/agents/me/e2ee', {
      method: 'PUT',
      headers: {
        'Cookie': `aamarva_human_session=${sessionTokenA}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        publicKey: keysA.e2eePublicKey,
        fingerprint: keysA.fingerprint,
        identityKey: keysA.identityPublicKey,
        signature: keysA.signature,
        keyEpoch: 1,
        allowRotation: false
      })
    });

    await helperFetch('/api/agents/me/e2ee', {
      method: 'PUT',
      headers: {
        'Cookie': `aamarva_human_session=${sessionTokenB}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        publicKey: keysB.e2eePublicKey,
        fingerprint: keysB.fingerprint,
        identityKey: keysB.identityPublicKey,
        signature: keysB.signature,
        keyEpoch: 1,
        allowRotation: false
      })
    });

    // =========================================================================
    // OPERATION 1: Real Direct Message (POST /api/connections/messages/:id)
    // =========================================================================
    const connId = `conn_core_${ts}`;
    await supabase.from('connections').insert({
      id: connId,
      user1_id: masterA.id,
      user2_id: peerB.id,
      user1_agent_id: masterA.agentId,
      user2_agent_id: peerB.agentId,
      user1_agent_name: 'Core Master A',
      user2_agent_name: 'Core Peer B',
      status: 'active',
      created_at: new Date().toISOString()
    });

    const msgRes = await helperFetch(`/api/connections/messages/${peerB.agentId}`, {
      method: 'POST',
      headers: {
        'Cookie': `aamarva_human_session=${sessionTokenA}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        ciphertext: Buffer.from('cipher_payload_data_123').toString('base64'),
        nonce: Buffer.from('123456789012').toString('base64'),
        version: 1,
        keyEpoch: 1
      })
    });

    console.log('[Direct Message Response]:', msgRes.status, msgRes.json?.success ? 'Success' : msgRes.text);
    await new Promise((r) => setTimeout(r, 200));

    const { data: directMsgFps } = await supabase
      .from('agent_footprints')
      .select('*')
      .eq('user_id', masterA.id)
      .eq('action', 'MESSAGE_SENT');

    const directMsgCount = directMsgFps?.length || 0;
    const directMsgPass = directMsgCount === 1;
    console.log(`[${directMsgPass ? 'PASSED' : 'FAILED'}] Direct Message: Exactly 1 event recorded (Found: ${directMsgCount})`);

    // =========================================================================
    // OPERATION 2: Real Cluster Message (POST /api/clusters/:id/messages)
    // =========================================================================
    const clusterId = `clu_core_${ts}`;
    await supabase.from('clusters').insert({
      id: clusterId,
      name: `Core Enclave ${ts}`,
      owner_user_id: masterA.id,
      owner_agent_id: masterA.agentId,
      ownerUserId: masterA.id,
      ownerAgentId: masterA.agentId,
      status: 'active',
      created_at: new Date().toISOString()
    });

    await supabase.from('cluster_members').insert({
      id: `cm_core_${ts}`,
      clusterId,
      userId: masterA.id,
      agentId: masterA.agentId,
      role: 'admin',
      status: 'active',
      createdAt: new Date().toISOString()
    });

    const cluMsgRes = await helperFetch(`/api/clusters/${clusterId}/messages`, {
      method: 'POST',
      headers: {
        'Cookie': `aamarva_human_session=${sessionTokenA}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        ciphertext: Buffer.from('cluster_cipher_xyz_payload').toString('base64'),
        nonce: crypto.randomBytes(12).toString('base64'),
        epoch: 1,
        keyEpoch: 1,
        version: 2
      })
    });

    console.log('[Cluster Message Response]:', cluMsgRes.status, cluMsgRes.json?.success ? 'Success' : cluMsgRes.text);
    await new Promise((r) => setTimeout(r, 200));

    const { data: cluMsgFps } = await supabase
      .from('agent_footprints')
      .select('*')
      .eq('user_id', masterA.id)
      .eq('action', 'CLUSTER_MESSAGE_SENT');

    const cluMsgCount = cluMsgFps?.length || 0;
    const cluMsgPass = cluMsgCount === 1;
    console.log(`[${cluMsgPass ? 'PASSED' : 'FAILED'}] Cluster Message: Exactly 1 event recorded (Found: ${cluMsgCount})`);

    // =========================================================================
    // OPERATION 3: Real FLOOR Tool Execution (POST /api/floor/invocations/:id/execute)
    // =========================================================================
    const serverId = crypto.randomUUID();
    const toolId = crypto.randomUUID();
    const invId = `inv_${crypto.randomBytes(8).toString('hex')}`;

    await supabase.from('mcp_servers').insert({
      id: serverId,
      name: `Core MCP Server ${ts}`,
      endpoint: 'https://core.internal.tools/mcp',
      owner_id: masterA.id,
      auth_type: 'none',
      transport: 'http',
      status: 'active',
      created_at: new Date().toISOString()
    });

    await supabase.from('mcp_tools').insert({
      id: toolId,
      server_id: serverId,
      owner_id: masterA.id,
      name: `core_analytics_tool_${ts}`,
      description: 'Analytics runner',
      is_enabled: true,
      input_schema: { type: 'object' },
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    });

    await createPendingInvocationRecord({
      id: invId,
      tool_id: toolId,
      caller_id: masterA.id,
      agent_id: masterA.agentId,
      owner_id: masterA.id,
      args: { query: 'run' },
      args_hash: 'hash_core',
      status: 'approved',
      expires_at: new Date(Date.now() + 3600000).toISOString(),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    });

    const floorExecRes = await helperFetch(`/api/floor/invocations/${invId}/execute`, {
      method: 'POST',
      headers: {
        'Cookie': `aamarva_human_session=${sessionTokenA}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ invocationId: invId })
    });

    console.log('[FLOOR Tool Execution Response]:', floorExecRes.status, floorExecRes.json?.success ? 'Success' : floorExecRes.text);
    await new Promise((r) => setTimeout(r, 200));

    const { data: floorFps } = await supabase
      .from('agent_footprints')
      .select('*')
      .eq('user_id', masterA.id)
      .eq('action', 'TOOL_EXECUTED');

    const floorCount = floorFps?.length || 0;
    const floorPass = floorCount === 1;
    console.log(`[${floorPass ? 'PASSED' : 'FAILED'}] FLOOR Tool Execution: Exactly 1 event recorded (Found: ${floorCount})`);

    const allPassed = directMsgPass && cluMsgPass && floorPass;
    console.log(`\n=== RESULT: ALL THREE CORE OPERATIONS VERIFIED: ${allPassed ? 'PASSED' : 'FAILED'} ===\n`);
    return allPassed;
  } catch (err) {
    console.error('Error in three core operations test:', err);
    return false;
  } finally {
    server.close();
  }
}

if (process.argv[1] && process.argv[1].includes('verifyThreeCoreOperations')) {
  runThreeCoreOperationsTest().then((passed) => {
    process.exit(passed ? 0 : 1);
  }).catch((e) => {
    console.error(e);
    process.exit(1);
  });
}
