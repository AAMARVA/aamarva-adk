import { createApp } from '../../server.js';
import { getSupabaseClient } from '../supabase.js';
import { registerUser, createHumanSession } from '../authService.js';
import { MasterAccountService } from '../services/masterAccountService.js';
import { 
  deriveAgentCryptoIdentity, 
  encryptMessage, 
  decryptMessage 
} from '../../src/lib/e2ee.js';

async function safeJson(res: any) {
  const text = await res.text();
  try {
    return JSON.parse(text);
  } catch (e) {
    throw new Error(`Failed to parse JSON from ${res.url} (Status ${res.status}): ${text}`);
  }
}

export async function runE2EERecipientKeyRegressionTests() {
  console.log('======================================================================');
  console.log('   AAMARVA E2EE RECIPIENT PUBLIC KEY LIFECYCLE & REGRESSION TESTS    ');
  console.log('======================================================================\n');

  process.env.VERCEL = '1';
  const app = await createApp();
  const server = app.listen(0);
  const port = (server.address() as any).port;
  const BASE_URL = `http://127.0.0.1:${port}`;

  let passed = 0;
  let total = 0;

  function assert(condition: boolean, msg: string) {
    total++;
    if (!condition) {
      console.error(`❌ FAIL: ${msg}`);
      throw new Error(`Assertion failed: ${msg}`);
    }
    passed++;
    console.log(`✅ PASS: ${msg}`);
  }

  try {
    const supabase = getSupabaseClient();
    const ts = Date.now();

    // 1. Setup Pioneer Master Account (Pioneer A)
    const emailPioneer = `pioneer_${ts}@aamarva.test`;
    const pwdPioneer = 'PioneerPass123!';
    const regPioneer = await registerUser({ email: emailPioneer, password: pwdPioneer, agentName: 'Pioneer Master' });
    const userPioneer = regPioneer.user;
    const sessionPioneer = await createHumanSession(userPioneer.id);
    const cookiePioneer = `aamarva_human_session=${sessionPioneer}`;

    // Mark userPioneer as Pioneer primary master and activate Master/Slave plan
    await supabase.from('users').update({
      account_type: 'master',
      role: 'master',
      is_master_primary: true,
      fleet_id: `fleet_${ts}`
    }).eq('id', userPioneer.id);

    await MasterAccountService.getInstance().activateMasterPlan(userPioneer.id, 10, { actionType: 'new_plan' });

    // 2. Setup Additional Master Account (Master B / Master Slot)
    const emailMasterB = `master_b_${ts}@aamarva.test`;
    const pwdMasterB = 'MasterBPass123!';
    const regMasterB = await registerUser({ email: emailMasterB, password: pwdMasterB, agentName: 'Additional Master B' });
    const userMasterB = regMasterB.user;
    const sessionMasterB = await createHumanSession(userMasterB.id);
    const cookieMasterB = `aamarva_human_session=${sessionMasterB}`;

    await supabase.from('users').update({
      account_type: 'master_slot',
      role: 'master',
      is_master_slot: true,
      master_id: userPioneer.id,
      fleet_id: `fleet_${ts}`
    }).eq('id', userMasterB.id);

    // 3. Setup Slave Account under Pioneer Master (Slave S1)
    const createSlaveRes = await fetch(`${BASE_URL}/api/auth/master/create-slave-agent`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: cookiePioneer },
      body: JSON.stringify({ agentName: 'Worker-Node-1' })
    });
    const createSlaveJson = await safeJson(createSlaveRes);
    assert((createSlaveRes.status === 200 || createSlaveRes.status === 201) && createSlaveJson.success, 'Slave agent created under Pioneer Master');
    const slaveS1 = createSlaveJson.data?.agent || createSlaveJson.data;
    const slaveApiKey = slaveS1.apiKey;
    const slaveAgentId = slaveS1.agentId;
    const slaveUserId = slaveS1.user?.id || slaveS1.id;

    // Client-side identity derivations (ECDH P-256 NIST)
    const cryptoPioneer = await deriveAgentCryptoIdentity(userPioneer.agentId, pwdPioneer);
    const cryptoMasterB = await deriveAgentCryptoIdentity(userMasterB.agentId, pwdMasterB);
    const cryptoSlaveS1 = await deriveAgentCryptoIdentity(slaveAgentId, slaveApiKey);

    // Register Pioneer Master E2EE Public Key
    const regPioneerKeyRes = await fetch(`${BASE_URL}/api/agents/me/e2ee`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', Cookie: cookiePioneer },
      body: JSON.stringify({
        publicKey: cryptoPioneer.e2eePublicKey,
        fingerprint: cryptoPioneer.fingerprint,
        identityKey: cryptoPioneer.identityPublicKey,
        signature: cryptoPioneer.signature,
        keyEpoch: 1
      })
    });
    assert(regPioneerKeyRes.status === 200, 'Pioneer Master public key registered');

    // Register Additional Master B E2EE Public Key
    const regMasterBKeyRes = await fetch(`${BASE_URL}/api/agents/me/e2ee`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', Cookie: cookieMasterB },
      body: JSON.stringify({
        publicKey: cryptoMasterB.e2eePublicKey,
        fingerprint: cryptoMasterB.fingerprint,
        identityKey: cryptoMasterB.identityPublicKey,
        signature: cryptoMasterB.signature,
        keyEpoch: 1
      })
    });
    assert(regMasterBKeyRes.status === 200, 'Additional Master B public key registered');

    // Register Slave S1 E2EE Public Key via Agent Token
    const regSlaveKeyRes = await fetch(`${BASE_URL}/api/agents/me/e2ee`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', 'x-api-key': slaveApiKey, 'Authorization': `Bearer ${slaveApiKey}` },
      body: JSON.stringify({
        publicKey: cryptoSlaveS1.e2eePublicKey,
        fingerprint: cryptoSlaveS1.fingerprint,
        identityKey: cryptoSlaveS1.identityPublicKey,
        signature: cryptoSlaveS1.signature,
        keyEpoch: 1
      })
    });
    assert(regSlaveKeyRes.status === 200, 'Slave S1 public key registered via agent runtime API');

    // ======================================================================
    // SCENARIO A: Pioneer Master -> Additional Master
    // ======================================================================
    console.log('\n--- Scenario A: Pioneer Master -> Additional Master ---');
    // Pioneer retrieves Additional Master B public key via composite ID
    // Notice: Testing the exact uppercase/composite format observed in the failure: conn_USERA_USERB
    const compositeConnAB = `conn_${userPioneer.id.toUpperCase()}_${userMasterB.id}`;
    const getPeerKeyResA = await fetch(`${BASE_URL}/api/connections/${compositeConnAB}/peer-key?receiverAgentId=${encodeURIComponent(userMasterB.agentId)}`, {
      headers: { Cookie: cookiePioneer }
    });
    const peerKeyDataA = await safeJson(getPeerKeyResA);
    assert(getPeerKeyResA.status === 200 && peerKeyDataA.success, 'Pioneer resolves Master B public key via composite connection ID');
    assert(peerKeyDataA.data?.peerE2eePublicKey === cryptoMasterB.e2eePublicKey, 'Resolved public key matches Master B registered public key');

    const canonicalConnIdAB = peerKeyDataA.data.connectionId;

    // Encrypt outbound message locally from Pioneer to Master B
    const plainTextA = 'Order Alpha: Coordinate fleet expansion protocols.';
    const encA = await encryptMessage(plainTextA, cryptoPioneer.e2eePrivateKey, cryptoMasterB.e2eePublicKey, canonicalConnIdAB, userPioneer.agentId);

    // Pioneer transmits encrypted message
    const sendResA = await fetch(`${BASE_URL}/api/connections/${canonicalConnIdAB}/messages`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: cookiePioneer },
      body: JSON.stringify({
        ciphertext: encA.ciphertext,
        nonce: encA.nonce,
        version: 1,
        keyEpoch: 1
      })
    });
    const sendJsonA = await safeJson(sendResA);
    assert((sendResA.status === 200 || sendResA.status === 201) && sendJsonA.success, 'Pioneer successfully sends E2EE message to Master B');

    // Master B retrieves and decrypts the message
    const getMsgsResB = await fetch(`${BASE_URL}/api/connections/${canonicalConnIdAB}/messages`, {
      headers: { Cookie: cookieMasterB }
    });
    const msgsJsonB = await safeJson(getMsgsResB);
    assert(getMsgsResB.status === 200 && Array.isArray(msgsJsonB.data), 'Master B retrieves messages from connection');
    const msgA = msgsJsonB.data.find((m: any) => m.ciphertext === encA.ciphertext);
    assert(Boolean(msgA), 'Outbound message from Pioneer is present in connection messages');

    const decryptedByB = await decryptMessage(msgA, cryptoMasterB.e2eePrivateKey, cryptoPioneer.e2eePublicKey, canonicalConnIdAB, userPioneer.agentId);
    assert(decryptedByB === plainTextA, 'Master B successfully decrypted message from Pioneer Master');

    // ======================================================================
    // SCENARIO B: Additional Master -> Pioneer Master
    // ======================================================================
    console.log('\n--- Scenario B: Additional Master -> Pioneer Master ---');
    const getPeerKeyResB = await fetch(`${BASE_URL}/api/connections/${canonicalConnIdAB}/peer-key?receiverAgentId=${encodeURIComponent(userPioneer.agentId)}`, {
      headers: { Cookie: cookieMasterB }
    });
    const peerKeyDataB = await safeJson(getPeerKeyResB);
    assert(getPeerKeyResB.status === 200 && peerKeyDataB.success, 'Master B resolves Pioneer public key');
    assert(peerKeyDataB.data?.peerE2eePublicKey === cryptoPioneer.e2eePublicKey, 'Resolved public key matches Pioneer registered public key');

    const plainTextB = 'Response Bravo: Fleet expansion protocols confirmed and deployed.';
    const encB = await encryptMessage(plainTextB, cryptoMasterB.e2eePrivateKey, cryptoPioneer.e2eePublicKey, canonicalConnIdAB, userMasterB.agentId);

    const sendResB = await fetch(`${BASE_URL}/api/connections/${canonicalConnIdAB}/messages`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: cookieMasterB },
      body: JSON.stringify({
        ciphertext: encB.ciphertext,
        nonce: encB.nonce,
        version: 1,
        keyEpoch: 1
      })
    });
    assert(sendResB.status === 200 || sendResB.status === 201, 'Master B successfully sends E2EE message to Pioneer Master');

    const getMsgsResA = await fetch(`${BASE_URL}/api/connections/${canonicalConnIdAB}/messages`, {
      headers: { Cookie: cookiePioneer }
    });
    const msgsJsonA = await safeJson(getMsgsResA);
    const msgB = msgsJsonA.data.find((m: any) => m.ciphertext === encB.ciphertext);
    const decryptedByA = await decryptMessage(msgB, cryptoPioneer.e2eePrivateKey, cryptoMasterB.e2eePublicKey, canonicalConnIdAB, userMasterB.agentId);
    assert(decryptedByA === plainTextB, 'Pioneer Master successfully decrypted message from Additional Master B');

    // ======================================================================
    // SCENARIO C: Master -> Slave
    // ======================================================================
    console.log('\n--- Scenario C: Master -> Slave ---');
    const compositeConnPioneerSlave = `conn_${userPioneer.id}_${slaveUserId}`;
    const getPeerKeyResPS = await fetch(`${BASE_URL}/api/connections/${compositeConnPioneerSlave}/peer-key?receiverAgentId=${encodeURIComponent(slaveAgentId)}`, {
      headers: { Cookie: cookiePioneer }
    });
    const peerKeyDataPS = await safeJson(getPeerKeyResPS);
    assert(getPeerKeyResPS.status === 200 && peerKeyDataPS.success, 'Pioneer Master resolves Slave S1 public key');
    assert(peerKeyDataPS.data?.peerE2eePublicKey === cryptoSlaveS1.e2eePublicKey, 'Resolved public key matches Slave S1 registered public key');

    const canonicalConnPS = peerKeyDataPS.data.connectionId;
    const plainTextMS = 'Command node: Execute telemetry scan.';
    const encMS = await encryptMessage(plainTextMS, cryptoPioneer.e2eePrivateKey, cryptoSlaveS1.e2eePublicKey, canonicalConnPS, userPioneer.agentId);

    const sendResMS = await fetch(`${BASE_URL}/api/connections/${canonicalConnPS}/messages`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: cookiePioneer },
      body: JSON.stringify({
        ciphertext: encMS.ciphertext,
        nonce: encMS.nonce,
        version: 1,
        keyEpoch: 1
      })
    });
    assert(sendResMS.status === 200 || sendResMS.status === 201, 'Master successfully sends encrypted message to Slave agent');

    // Slave retrieves and decrypts message via Agent Token
    const getMsgsResSlave = await fetch(`${BASE_URL}/api/connections/${canonicalConnPS}/messages`, {
      headers: { 'Authorization': `Bearer ${slaveApiKey}`, 'x-api-key': slaveApiKey }
    });
    const msgsJsonSlave = await safeJson(getMsgsResSlave);
    const msgMS = msgsJsonSlave.data.find((m: any) => m.ciphertext === encMS.ciphertext);
    const decryptedBySlave = await decryptMessage(msgMS, cryptoSlaveS1.e2eePrivateKey, cryptoPioneer.e2eePublicKey, canonicalConnPS, userPioneer.agentId);
    assert(decryptedBySlave === plainTextMS, 'Slave agent successfully decrypted message from Master');

    // ======================================================================
    // SCENARIO D: Slave -> Master
    // ======================================================================
    console.log('\n--- Scenario D: Slave -> Master ---');
    const plainTextSM = 'Scan report: All systems operational. 0 faults detected.';
    const encSM = await encryptMessage(plainTextSM, cryptoSlaveS1.e2eePrivateKey, cryptoPioneer.e2eePublicKey, canonicalConnPS, slaveAgentId);

    const sendResSM = await fetch(`${BASE_URL}/api/connections/${canonicalConnPS}/messages`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${slaveApiKey}`, 'x-api-key': slaveApiKey },
      body: JSON.stringify({
        ciphertext: encSM.ciphertext,
        nonce: encSM.nonce,
        version: 1,
        keyEpoch: 1
      })
    });
    assert(sendResSM.status === 200 || sendResSM.status === 201, 'Slave agent successfully sends encrypted message to Master');

    const getMsgsResPioneer2 = await fetch(`${BASE_URL}/api/connections/${canonicalConnPS}/messages`, {
      headers: { Cookie: cookiePioneer }
    });
    const msgsJsonPioneer2 = await safeJson(getMsgsResPioneer2);
    const msgSM = msgsJsonPioneer2.data.find((m: any) => m.ciphertext === encSM.ciphertext);
    const decryptedByMaster = await decryptMessage(msgSM, cryptoPioneer.e2eePrivateKey, cryptoSlaveS1.e2eePublicKey, canonicalConnPS, slaveAgentId);
    assert(decryptedByMaster === plainTextSM, 'Master successfully decrypted message from Slave agent');

    // ======================================================================
    // SCENARIO E: Account Switching followed by Messaging
    // ======================================================================
    console.log('\n--- Scenario E: Account Switching followed by Messaging ---');
    // Master switches to Slave S1
    const switchRes = await fetch(`${BASE_URL}/api/auth/master/switch`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: cookiePioneer },
      body: JSON.stringify({ targetAgentId: slaveUserId })
    });
    const switchJson = await safeJson(switchRes);
    assert(switchRes.status === 200 && switchJson.success, 'Pioneer master switched context to Slave S1');
    const switchedCookie = switchRes.headers.get('set-cookie') || cookiePioneer;

    // Verify switched session reflects slave identity
    const meRes = await fetch(`${BASE_URL}/api/agents/me`, {
      headers: { Cookie: switchedCookie }
    });
    const meJson = await safeJson(meRes);
    assert(meJson.data?.id === slaveUserId, 'Switched context returns Slave S1 identity');

    // Return back to Pioneer master
    const returnRes = await fetch(`${BASE_URL}/api/auth/master/switch`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: switchedCookie },
      body: JSON.stringify({ targetAgentId: userPioneer.id })
    });
    const returnJson = await safeJson(returnRes);
    assert(returnRes.status === 200 && returnJson.success, 'Successfully returned from slave to Pioneer master');
    const returnedCookie = returnRes.headers.get('set-cookie') || cookiePioneer;

    // After switching back, retrieve peer keys and send another message to verify no key corruption
    const postSwitchKeyRes = await fetch(`${BASE_URL}/api/connections/${canonicalConnIdAB}/peer-key`, {
      headers: { Cookie: returnedCookie }
    });
    const postSwitchKeyJson = await safeJson(postSwitchKeyRes);
    assert(postSwitchKeyJson.data?.peerE2eePublicKey === cryptoMasterB.e2eePublicKey, 'Key resolution remains pristine after account switching');

    // ======================================================================
    // SCENARIO F: Existing Connection with Previously Registered Public Key
    // ======================================================================
    console.log('\n--- Scenario F: Existing Connection with Previously Registered Public Key ---');
    const existingConnRes = await fetch(`${BASE_URL}/api/connections/${canonicalConnIdAB}/peer-key`, {
      headers: { Cookie: cookiePioneer }
    });
    const existingConnJson = await safeJson(existingConnRes);
    assert(existingConnRes.status === 200 && existingConnJson.data?.peerE2eePublicKey, 'Existing connection returns registered public key without re-registration');

    // ======================================================================
    // SCENARIO G: Existing Connection with Missing Public Key (Error Handling)
    // ======================================================================
    console.log('\n--- Scenario G: Connection with Missing Public Key (Diagnostics) ---');
    // Register User C with no public key published
    const emailC = `user_c_${ts}@aamarva.test`;
    const pwdC = 'PassC123!';
    const regC = await registerUser({ email: emailC, password: pwdC, agentName: 'Keyless Agent' });
    const userC = regC.user;

    // Establish connection between Pioneer and User C
    const connPC = `conn_${userPioneer.id}_${userC.id}`;
    const keyResC = await fetch(`${BASE_URL}/api/connections/${connPC}/peer-key?receiverAgentId=${encodeURIComponent(userC.agentId)}`, {
      headers: { Cookie: cookiePioneer }
    });
    const keyJsonC = await safeJson(keyResC);
    assert(keyResC.status === 200, 'Connection established but peer key is null');
    assert(keyJsonC.data?.peerE2eePublicKey === null, 'Peer public key correctly reported as null when not published');

    // Attempting to send message without recipient key fails closed server-side or throws required error
    const dummyKey = cryptoPioneer.e2eePublicKey; // sender has key, but keyEpoch 999 doesn't exist
    const invalidSendRes = await fetch(`${BASE_URL}/api/connections/${keyJsonC.data.connectionId}/messages`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: cookiePioneer },
      body: JSON.stringify({
        ciphertext: Buffer.from('hello').toString('base64'),
        nonce: Buffer.from('123456789012').toString('base64'),
        version: 1,
        keyEpoch: 999
      })
    });
    assert(invalidSendRes.status === 400, 'Sending with unregistered keyEpoch fails closed with 400 Bad Request');

    // ======================================================================
    // SCENARIO H: Asynchronous Registration & Connection Establishment
    // ======================================================================
    console.log('\n--- Scenario H: Asynchronous Registration & Connection ---');
    // User C now publishes their key asynchronously
    const cryptoUserC = await deriveAgentCryptoIdentity(userC.agentId, pwdC);
    const sessionC = await createHumanSession(userC.id);
    const cookieC = `aamarva_human_session=${sessionC}`;

    const regKeyCRes = await fetch(`${BASE_URL}/api/agents/me/e2ee`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', Cookie: cookieC },
      body: JSON.stringify({
        publicKey: cryptoUserC.e2eePublicKey,
        fingerprint: cryptoUserC.fingerprint,
        identityKey: cryptoUserC.identityPublicKey,
        signature: cryptoUserC.signature,
        keyEpoch: 1
      })
    });
    assert(regKeyCRes.status === 200, 'User C asynchronously publishes E2EE public key');

    // Pioneer re-queries peer key for existing connection
    const refetchKeyRes = await fetch(`${BASE_URL}/api/connections/${connPC}/peer-key`, {
      headers: { Cookie: cookiePioneer }
    });
    const refetchKeyJson = await safeJson(refetchKeyRes);
    assert(refetchKeyJson.data?.peerE2eePublicKey === cryptoUserC.e2eePublicKey, 'Pioneer immediately discovers newly published peer key on existing connection');

    // ======================================================================
    // SECURITY VALIDATION: Slave-to-Slave Connections Prohibited
    // ======================================================================
    console.log('\n--- Security Validation: Slave-to-Slave Prohibition ---');
    // Create second slave S2
    const createSlave2Res = await fetch(`${BASE_URL}/api/auth/master/create-slave-agent`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: cookiePioneer },
      body: JSON.stringify({ agentName: 'Worker-Node-2' })
    });
    const createSlave2Json = await safeJson(createSlave2Res);
    const slaveS2 = createSlave2Json.data?.agent || createSlave2Json.data;

    // S1 attempts connection with S2
    const s2sConn = `conn_${slaveUserId}_${slaveS2.user?.id || slaveS2.id}`;
    const s2sRes = await fetch(`${BASE_URL}/api/connections/${s2sConn}/peer-key`, {
      headers: { 'Authorization': `Bearer ${slaveApiKey}`, 'x-api-key': slaveApiKey }
    });
    assert(s2sRes.status === 404 || s2sRes.status === 403, 'Slave-to-slave connection attempt is strictly prohibited and blocked');

    console.log(`\n======================================================================`);
    console.log(`   ALL ${passed}/${total} E2EE RECIPIENT KEY REGRESSION TESTS PASSED   `);
    console.log(`======================================================================\n`);
  } finally {
    server.close();
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  runE2EERecipientKeyRegressionTests()
    .then(() => process.exit(0))
    .catch((err) => {
      console.error('Test Suite Failed:', err);
      process.exit(1);
    });
}
