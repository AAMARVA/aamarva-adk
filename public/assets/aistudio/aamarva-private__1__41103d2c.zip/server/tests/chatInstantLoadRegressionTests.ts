import express from 'express';
import http from 'http';
import cookieParser from 'cookie-parser';
import crypto from 'crypto';
import aamarvaRouter, { recordUserConnectionRead, userConnectionLastReadMap } from '../routes/aamarvaRoutes';
import clusterRouter from '../routes/clusterRoutes';
import { getSupabaseClient } from '../supabase';
import { registerUser, createHumanSession, generateAgentAccessToken } from '../authService';
import { getConnectionMessages, getConnectionRecord, resolveUserRecord } from '../services/connectionService';

async function runTests() {
  console.log('\n=== CHAT INSTANT LOAD, POSTGREST PAGINATION & ZERO-REGRESSION TESTS ===\n');
  let passed = 0;
  let failed = 0;

  const assert = (name: string, condition: boolean, detail?: string) => {
    if (condition) {
      passed++;
      console.log(`[PASS] ${name}`);
    } else {
      failed++;
      console.error(`[FAIL] ${name}${detail ? `: ${detail}` : ''}`);
    }
  };

  const app = express();
  app.use(cookieParser());
  app.use(express.json());
  app.use('/api', aamarvaRouter);
  app.use('/api', clusterRouter);

  const server = http.createServer(app);
  await new Promise<void>((resolve) => server.listen(0, resolve));
  const port = (server.address() as any).port;
  const baseUrl = `http://127.0.0.1:${port}`;

  const helperFetch = async (endpoint: string, options: any = {}) => {
    const res = await fetch(`${baseUrl}${endpoint}`, {
      ...options,
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        ...(options.headers || {}),
      },
    });
    const text = await res.text();
    let json: any = null;
    try {
      json = JSON.parse(text);
    } catch {}
    return { status: res.status, headers: res.headers, json, text };
  };

  try {
    const supabase = getSupabaseClient();
    const ts = Date.now();

    // 1. Setup Master + Slave in same fleet
    const masterEmail = `chat_instant_${ts}@aamarva.test`;
    const regMaster = await registerUser({
      email: masterEmail,
      password: 'MasterPassword123!',
      agentName: 'Instant Load Master',
    });
    const master = regMaster.user;
    const masterSession = await createHumanSession(master.id);

    const slaveId = `usr_slave_${ts}`;
    const slaveAgentId = `AMR-SLAVE-${ts}`;
    await supabase.from('users').insert({
      id: slaveId,
      agentId: slaveAgentId,
      name: 'Instant Slave Peer',
      email: `chat_instant_${ts}+${slaveAgentId}@aamarva.test`,
      passwordHash: '$2a$10$dummyhashforunittesting',
      emailVerified: true,
      master_id: master.id,
      is_master_primary: false,
      account_type: 'slave',
      role: 'slave',
      is_slave: true,
      createdAt: new Date().toISOString(),
    });
    const slaveToken = generateAgentAccessToken({
      id: slaveId,
      agentId: slaveAgentId,
      email: `chat_instant_${ts}+${slaveAgentId}@aamarva.test`,
      name: 'Instant Slave Peer',
      role: 'slave',
      account_type: 'slave',
      master_id: master.id,
      is_slave: true,
    });

    // Generate dummy valid P-256 JWK public keys for both master and slave
    const makeP256JwkStr = () => {
      const kp = crypto.generateKeyPairSync('ec', { namedCurve: 'P-256' });
      return JSON.stringify(kp.publicKey.export({ format: 'jwk' }));
    };
    const masterPubJwk = makeP256JwkStr();
    const slavePubJwk = makeP256JwkStr();

    await supabase.auth.admin.updateUserById(master.id, {
      user_metadata: {
        e2eePublicKey: masterPubJwk,
        e2eeKeyEpoch: 1,
        e2eePublicKeyFingerprint: `fp-m-${ts}`,
      },
    });
    await supabase.auth.admin.updateUserById(slaveId, {
      user_metadata: {
        e2eePublicKey: slavePubJwk,
        e2eeKeyEpoch: 1,
        e2eePublicKeyFingerprint: `fp-s-${ts}`,
      },
    });

    // Test resolveUserRecord without full table scan
    const resolvedByAgent = await resolveUserRecord(`@${slaveAgentId.toLowerCase()}`);
    assert('resolveUserRecord finds user by @agentId case-insensitively', resolvedByAgent?.id === slaveId);

    // 2. Establish connection and test >1,000-row PostgREST pagination in getConnectionMessages
    const connId = `fleet_conn_${master.id}_${slaveId}`;
    const connRecord = await getConnectionRecord(connId);
    assert('getConnectionRecord establishes valid Master<->Slave connection', Boolean(connRecord?.id));

    const canonicalId = connRecord!.id;
    const totalBulk = 1150;
    const baseTime = Date.now() - 2_000_000;
    const bulkRows: any[] = [];
    for (let i = 0; i < totalBulk; i++) {
      bulkRows.push({
        id: `msg_bulk_${ts}_${String(i).padStart(4, '0')}`,
        connectionId: canonicalId,
        senderUserId: i % 2 === 0 ? master.id : slaveId,
        senderAgentId: i % 2 === 0 ? master.agentId : slaveAgentId,
        content: null,
        ciphertext: Buffer.from(`cipher-${i}`).toString('base64'),
        nonce: Buffer.from(`nonce-${String(i).padStart(6, '0')}`).toString('base64'),
        version: 1,
        keyEpoch: 1,
        sequence: i + 1,
        createdAt: new Date(baseTime + i * 1000).toISOString(),
      });
    }
    await supabase.from('messages').insert(bulkRows);

    const fetchedAll = await getConnectionMessages(canonicalId, master.id, { preResolvedConnection: connRecord! });
    assert(
      'getConnectionMessages retrieves all >1,000 messages without truncating newest rows',
      fetchedAll.length === totalBulk && fetchedAll[fetchedAll.length - 1]?.sequence === totalBulk,
      `got ${fetchedAll.length} messages, last seq=${fetchedAll[fetchedAll.length - 1]?.sequence}`
    );

    // 3. Send a brand new message from Slave via POST /api/connections/:id/messages & check immediate retrieval + SSE ticket + no-store headers
    const newestNonce = crypto.randomBytes(12).toString('base64');
    const newestCipher = crypto.randomBytes(32).toString('base64');
    const postRes = await helperFetch(`/api/connections/${canonicalId}/messages`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${slaveToken}` },
      body: JSON.stringify({
        ciphertext: newestCipher,
        nonce: newestNonce,
        version: 1,
        keyEpoch: 1,
        sequence: totalBulk + 1,
      }),
    });
    assert('POST /api/connections/:id/messages succeeds for Slave->Master', postRes.status === 201 && postRes.json?.success === true);

    const getRes = await helperFetch(`/api/connections/${canonicalId}/messages`, {
      method: 'GET',
      headers: { Cookie: `aamarva_human_session=${masterSession}` },
    });
    const cacheCtrl = getRes.headers.get('cache-control') || '';
    const transcript = getRes.json?.data || [];
    const lastMsg = transcript[transcript.length - 1];
    assert(
      'GET /api/connections/:id/messages returns newest message immediately with no-store header',
      getRes.status === 200 &&
        cacheCtrl.includes('no-store') &&
        transcript.length === totalBulk + 1 &&
        lastMsg?.ciphertext === newestCipher,
      `status=${getRes.status}, len=${transcript.length}, cache=${cacheCtrl}`
    );

    // 4. Test recordUserConnectionRead 5s debounce prevents redundant auth.admin updates
    let updateCount = 0;
    const origUpdateUser = supabase.auth.admin.updateUserById.bind(supabase.auth.admin);
    (supabase.auth.admin as any).updateUserById = async (...args: any[]) => {
      updateCount++;
      return origUpdateUser(...(args as [any, any]));
    };
    const debounceTarget = `conn_debounce_${ts}`;
    await recordUserConnectionRead(master, debounceTarget, slaveAgentId);
    await recordUserConnectionRead(master, debounceTarget, slaveAgentId);
    await recordUserConnectionRead(master, debounceTarget, slaveAgentId);
    (supabase.auth.admin as any).updateUserById = origUpdateUser;
    assert(
      'recordUserConnectionRead updates in-memory read map immediately and debounces redundant auth.admin writes',
      updateCount === 1 && userConnectionLastReadMap.has(`${master.id}@@${debounceTarget}`),
      `updateCount=${updateCount}`
    );

    // 5. Verify GET /api/connections shows conversation with lastMessageAt & unread clears cleanly
    const connsResBefore = await helperFetch('/api/connections?limit=50', {
      method: 'GET',
      headers: { Cookie: `aamarva_human_session=${masterSession}` },
    });
    const matchedConnBefore = (connsResBefore.json?.data || []).find(
      (c: any) => c.id === canonicalId || String(c.agentId).toUpperCase() === slaveAgentId.toUpperCase()
    );
    assert(
      'GET /api/connections includes active connection with latest timestamp',
      connsResBefore.status === 200 && Boolean(matchedConnBefore?.lastMessageAt),
      `found=${Boolean(matchedConnBefore)}`
    );

    const readRes = await helperFetch(`/api/connections/${canonicalId}/read`, {
      method: 'POST',
      headers: { Cookie: `aamarva_human_session=${masterSession}` },
      body: JSON.stringify({ connectionId: canonicalId, agentId: slaveAgentId }),
    });
    assert('POST /api/connections/:id/read succeeds', readRes.status === 200 && readRes.json?.success === true);

    // 6. Zero regression checks on Realtime stream ticket, Watchtower activities, and Footprints/Webhooks
    const ticketRes = await helperFetch('/api/realtime/stream-ticket', {
      method: 'POST',
      headers: { Cookie: `aamarva_human_session=${masterSession}` },
    });
    assert('POST /api/realtime/stream-ticket issues SSE ticket', ticketRes.status === 200 && Boolean(ticketRes.json?.ticket));

    const wtRes = await helperFetch('/api/watchtower/activity?limit=10', {
      method: 'GET',
      headers: { Cookie: `aamarva_human_session=${masterSession}` },
    });
    assert('GET /api/watchtower/activity works without regression', wtRes.status === 200 && wtRes.json?.success === true);

    const fpRes = await helperFetch('/api/agent/footprints?limit=10', {
      method: 'GET',
      headers: { Authorization: `Bearer ${slaveToken}` },
    });
    assert('GET /api/agent/footprints works for agent without regression', fpRes.status === 200 && fpRes.json?.success === true);

    const whRes = await helperFetch('/api/webhooks/events?limit=10', {
      method: 'GET',
      headers: { Authorization: `Bearer ${slaveToken}` },
    });
    assert('GET /api/webhooks/events works for agent without regression', whRes.status === 200 && whRes.json?.success === true);
  } catch (err: any) {
    failed++;
    console.error('Unhandled error in chatInstantLoadRegressionTests:', err);
  } finally {
    server.close();
    console.log(`\nResults: ${passed} passed, ${failed} failed\n`);
    process.exit(failed > 0 ? 1 : 0);
  }
}

runTests();
