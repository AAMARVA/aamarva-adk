import http from 'http';
import { createApp } from '../../server.js';
import { registerUser, createHumanSession } from '../authService.js';
import { establishDirectConnection } from '../services/connectionService.js';
import { 
  generateAgentCryptoIdentity, 
  encryptAttachmentFile, 
  decryptAttachmentFile 
} from '../../src/lib/e2ee.js';
import { getSupportedAudioMimeType, queryMicrophonePermission } from '../../src/hooks/useVoiceRecorder.js';

export async function runVoiceMessageWorkflowTests(): Promise<Record<string, { status: 'PASSED' | 'FAILED'; reason?: string }>> {
  console.log('\n======================================================================');
  console.log('       AAMARVA VOICE MESSAGE RECORDING & E2EE WORKFLOW SUITE          ');
  console.log('======================================================================\n');

  const results: Record<string, { status: 'PASSED' | 'FAILED'; reason?: string }> = {};

  const recordResult = (id: string, success: boolean, reason?: string) => {
    results[id] = { status: success ? 'PASSED' : 'FAILED', reason };
    console.log(`[${success ? 'PASSED' : 'FAILED'}] ${id}${reason ? `: ${reason}` : ''}`);
  };

  process.env.VERCEL = '1';
  const app = await createApp();
  const server = http.createServer(app);
  await new Promise<void>((resolve) => server.listen(0, resolve));
  const port = (server.address() as any).port;
  const baseUrl = `http://127.0.0.1:${port}`;

  const helperFetch = async (endpoint: string, options: any = {}) => {
    const res = await fetch(`${baseUrl}${endpoint}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(options.headers || {})
      }
    });
    const text = await res.text();
    let json: any = null;
    try {
      json = JSON.parse(text);
    } catch {}
    return { status: res.status, json, text };
  };

  const ts = Date.now();

  try {
    // Test 1: Supported audio MIME type helper behaves safely in all environments
    const detectedMime = getSupportedAudioMimeType();
    recordResult('test_1_mime_type_detection', typeof detectedMime === 'string', `MIME type resolved: "${detectedMime}"`);

    // Test 1b: Permission query helper returns valid state safely without crashing
    const permState = await queryMicrophonePermission();
    recordResult('test_1b_permission_query_safe', ['granted', 'denied', 'prompt', 'unknown'].includes(permState), `Permission query result: "${permState}"`);

    // Setup sender (User A) and receiver (User B)
    const emailA = `voice_sender_${ts}@aamarva.test`;
    const regA = await registerUser({ email: emailA, password: 'VoicePassword123!', agentName: 'Voice Sender' });
    const userA = regA.user;
    const sessionA = await createHumanSession(userA.id);
    const cookieA = `aamarva_human_session=${sessionA}`;

    const emailB = `voice_recipient_${ts}@aamarva.test`;
    const regB = await registerUser({ email: emailB, password: 'VoicePassword123!', agentName: 'Voice Recipient' });
    const userB = regB.user;
    const sessionB = await createHumanSession(userB.id);
    const cookieB = `aamarva_human_session=${sessionB}`;

    // Generate cryptographic identities for both parties
    const identityA = await generateAgentCryptoIdentity(userA.agentId);
    const identityB = await generateAgentCryptoIdentity(userB.agentId);

    // Publish keys to the server
    const regARes = await helperFetch('/api/agents/me/e2ee', {
      method: 'PUT',
      headers: { Cookie: cookieA },
      body: JSON.stringify({
        publicKey: identityA.e2eePublicKey,
        identityKey: identityA.identityPublicKey,
        fingerprint: identityA.fingerprint,
        signature: identityA.signature,
        keyEpoch: 1
      })
    });

    const regBRes = await helperFetch('/api/agents/me/e2ee', {
      method: 'PUT',
      headers: { Cookie: cookieB },
      body: JSON.stringify({
        publicKey: identityB.e2eePublicKey,
        identityKey: identityB.identityPublicKey,
        fingerprint: identityB.fingerprint,
        signature: identityB.signature,
        keyEpoch: 1
      })
    });

    recordResult('test_keys_registered', regARes.status === 200 && regBRes.status === 200, 'Keys registered for sender and receiver');

    // Establish direct connection using user IDs
    const connAB = await establishDirectConnection(userA.id, userB.id);
    const connectionId = connAB.id;

    // Test 2: Audio recording simulation & non-zero file creation
    // Generate simulated audio bytes representing a WebM Opus audio file
    const simulatedAudioBytes = new Uint8Array(4096);
    for (let i = 0; i < simulatedAudioBytes.length; i++) {
      simulatedAudioBytes[i] = (i * 17 + 42) % 256;
    }
    const audioFilename = `voice_message_${ts}.webm`;
    const audioMimeType = 'audio/webm;codecs=opus';
    const audioDuration = 8; // 8 seconds

    recordResult(
      'test_2_audio_blob_generation',
      simulatedAudioBytes.byteLength > 0 && simulatedAudioBytes.byteLength === 4096,
      `Simulated audio generated: ${simulatedAudioBytes.byteLength} bytes`
    );

    // Test 3: Local client-side P-256 ECDH + HKDF + AES-256-GCM encryption
    const encryptedVoicePayload = await encryptAttachmentFile(
      {
        name: audioFilename,
        type: audioMimeType,
        size: simulatedAudioBytes.byteLength,
        data: simulatedAudioBytes
      },
      identityA.e2eePrivateKey,
      identityB.e2eePublicKey,
      connectionId,
      userA.agentId,
      1
    );

    const hasNoPlaintextLeak = !encryptedVoicePayload.ciphertext.includes('voice_message') &&
      !encryptedVoicePayload.ciphertext.includes(audioMimeType);

    recordResult(
      'test_3_e2ee_voice_encryption',
      Boolean(encryptedVoicePayload.ciphertext && encryptedVoicePayload.nonce && hasNoPlaintextLeak),
      `Encrypted locally with AES-256-GCM. Ciphertext size: ${encryptedVoicePayload.ciphertextSize} bytes`
    );

    // Test 4: Server-blind upload to attachments API
    const uploadRes = await helperFetch(`/api/connections/${connectionId}/attachments`, {
      method: 'POST',
      headers: { Cookie: cookieA },
      body: JSON.stringify(encryptedVoicePayload)
    });

    recordResult(
      'test_4_server_blind_upload',
      uploadRes.status === 201 && uploadRes.json?.success,
      `Uploaded to /api/connections/${connectionId}/attachments (Status: ${uploadRes.status})`
    );

    // Test 5: Voice message envelope transmission in secure chat
    const voiceEnvelope = JSON.stringify({
      aamarva_attachment: true,
      isVoiceMessage: true,
      attachmentId: encryptedVoicePayload.attachmentId,
      filename: audioFilename,
      size: simulatedAudioBytes.byteLength,
      mimeType: audioMimeType,
      duration: audioDuration,
      text: 'Encrypted voice briefing'
    });

    const encryptedEnvelope = await encryptAttachmentFile(
      {
        name: 'envelope.json',
        type: 'application/json',
        size: new TextEncoder().encode(voiceEnvelope).byteLength,
        data: new TextEncoder().encode(voiceEnvelope)
      },
      identityA.e2eePrivateKey,
      identityB.e2eePublicKey,
      connectionId,
      userA.agentId,
      1
    );

    const sendRes = await helperFetch(`/api/connections/${connectionId}/messages`, {
      method: 'POST',
      headers: { Cookie: cookieA },
      body: JSON.stringify({
        ciphertext: encryptedEnvelope.ciphertext,
        nonce: encryptedEnvelope.nonce,
        version: encryptedEnvelope.version,
        keyEpoch: encryptedEnvelope.keyEpoch,
        receiverAgentId: userB.agentId
      })
    });

    recordResult(
      'test_5_voice_message_envelope_transmission',
      (sendRes.status === 200 || sendRes.status === 201) && (sendRes.json?.id || sendRes.json?.messageId || sendRes.json?.success),
      `Voice message envelope sent successfully through E2EE channel`
    );

    // Test 6: Recipient retrieves encrypted ciphertext from server
    const recipientGetRes = await helperFetch(`/api/connections/${connectionId}/attachments/${encryptedVoicePayload.attachmentId}`, {
      method: 'GET',
      headers: { Cookie: cookieB }
    });

    recordResult(
      'test_6_recipient_retrieves_ciphertext',
      recipientGetRes.status === 200 && recipientGetRes.json?.data?.ciphertext === encryptedVoicePayload.ciphertext,
      `Recipient retrieved ciphertext without server decryption`
    );

    // Test 7: Recipient decrypts locally and verifies audio payload integrity
    const decryptedAudio = await decryptAttachmentFile(
      recipientGetRes.json.data,
      identityB.e2eePrivateKey,
      identityA.e2eePublicKey,
      connectionId,
      userA.agentId
    );

    const decryptedBytes = new Uint8Array(await decryptedAudio.blob.arrayBuffer());
    let identical = decryptedBytes.byteLength === simulatedAudioBytes.byteLength;
    if (identical) {
      for (let i = 0; i < decryptedBytes.byteLength; i++) {
        if (decryptedBytes[i] !== simulatedAudioBytes[i]) {
          identical = false;
          break;
        }
      }
    }

    recordResult(
      'test_7_recipient_local_decryption_and_playback_ready',
      identical && decryptedAudio.filename === audioFilename && decryptedAudio.mimeType === audioMimeType,
      `Decrypted locally on recipient device. Audio blob ready for HTMLAudioElement playback (size: ${decryptedBytes.byteLength} bytes)`
    );

    // Test 8: Tamper resistance: verify modified ciphertext fails AES-256-GCM verification
    let tamperFailed = false;
    try {
      const orig = recipientGetRes.json.data.ciphertext;
      const tamperedCiphertext = orig.charAt(0) === 'A' ? 'B' + orig.slice(1) : 'A' + orig.slice(1);
      const tamperedRecord = {
        ...recipientGetRes.json.data,
        ciphertext: tamperedCiphertext
      };
      await decryptAttachmentFile(
        tamperedRecord,
        identityB.e2eePrivateKey,
        identityA.e2eePublicKey,
        connectionId,
        userA.agentId
      );
    } catch (e: any) {
      tamperFailed = true;
    }

    recordResult(
      'test_8_tampered_audio_fails_verification',
      tamperFailed,
      `Tampered ciphertext was rejected by AES-256-GCM authentication verification`
    );

  } catch (err: any) {
    console.error('Workflow test error:', err);
    recordResult('workflow_fatal_error', false, err?.message);
  } finally {
    server.close();
  }

  const allPassed = Object.values(results).every((r) => r.status === 'PASSED');
  console.log(`\n=== VOICE MESSAGE WORKFLOW SUITE RESULT: ${allPassed ? 'ALL PASSED' : 'SOME FAILED'} ===\n`);
  return results;
}

if (process.argv[1]?.endsWith('voiceMessageWorkflowTests.ts')) {
  runVoiceMessageWorkflowTests().then((res) => {
    const failed = Object.entries(res).filter(([_, v]) => v.status === 'FAILED');
    if (failed.length > 0) {
      process.exit(1);
    } else {
      process.exit(0);
    }
  });
}
