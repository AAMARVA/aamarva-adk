import express from 'express';
import http from 'http';
import cookieParser from 'cookie-parser';
import aamarvaRouter from '../routes/aamarvaRoutes';
import clusterRouter, { getClusterTables } from '../routes/clusterRoutes';
import floorRouter from '../routes/floorRoutes';
import { getSupabaseClient } from '../supabase';
import { registerUser, createHumanSession } from '../authService';
import { watchtowerActivityService } from '../services/watchtowerActivityService';
import { deduplicateAndMergeWatchtowerActivities, getActivityKey } from '../../src/lib/watchtowerActivityDeduplication';

export async function runWatchtowerOptimizationTests(): Promise<Record<string, { status: 'PASSED' | 'FAILED'; reason?: string }>> {
  console.log('\n=== AAMARVA WATCHTOWER OPTIMIZATION & DUPLICATE ELIMINATION TESTS ===\n');
  const results: Record<string, { status: 'PASSED' | 'FAILED'; reason?: string }> = {};

  const recordResult = (id: string, success: boolean, reason?: string) => {
    results[id] = { status: success ? 'PASSED' : 'FAILED', reason };
    console.log(`[${success ? 'PASSED' : 'FAILED'}] ${id}${reason ? `: ${reason}` : ''}`);
  };

  const app = express();
  app.use(cookieParser());
  app.use(express.json());
  app.use('/api', aamarvaRouter);
  app.use('/api', clusterRouter);
  app.use('/api/floor', floorRouter);

  const server = http.createServer(app);
  await new Promise<void>((resolve) => server.listen(0, resolve));
  const port = (server.address() as any).port;
  const baseUrl = `http://127.0.0.1:${port}`;

  const helperFetch = async (endpoint: string, options: any = {}) => {
    const res = await fetch(`${baseUrl}${endpoint}`, {
      ...options,
      headers: {
        'Accept': 'application/json',
        ...(options.headers || {})
      }
    });
    const contentType = res.headers.get('content-type') || '';
    const text = await res.text();
    let json: any = null;
    try {
      json = JSON.parse(text);
    } catch {}
    return { status: res.status, headers: res.headers, contentType, json, text };
  };

  try {
    const supabase = getSupabaseClient();
    const ts = Date.now();

    // Setup Master user
    const emailA = `wt_optim_${ts}@aamarva.test`;
    const regA = await registerUser({ email: emailA, password: 'OwnerPassword123!', agentName: 'Watchtower Optim Master' });
    const userA = regA.user;
    const sessionTokenA = await createHumanSession(userA.id);

    // Setup Slave account
    const slaveId = `usr_wt_slave_${ts}`;
    const slaveAgentId = `AMR-WT-${ts}`;
    await supabase.from('users').insert({
      id: slaveId,
      agentId: slaveAgentId,
      name: 'Watchtower Slave Node',
      email: `slave_${ts}@aamarva.test`,
      passwordHash: '$2a$10$dummyhashforunittesting',
      emailVerified: true,
      master_id: userA.id,
      is_master_primary: false,
      createdAt: new Date().toISOString()
    });

    // -------------------------------------------------------------
    // TEST 1: Single canonical event per message sent (No duplicates in DB)
    // -------------------------------------------------------------
    const msgId = `msg_test_${ts}_1`;
    await watchtowerActivityService.recordWatchtowerActivity({
      id: `wt_msg_${msgId}`,
      agentId: userA.agentId,
      agentName: userA.name,
      text: `@${userA.agentId} transmitted encrypted message to @${slaveAgentId}`,
      type: 'MESSAGE_SENT',
      actorUserId: userA.id,
      masterId: userA.id,
      peerAgentId: slaveAgentId,
      entityId: msgId,
      activityKey: `msg_sent:${msgId}`
    });

    // Check agent_footprints in DB
    const { data: fpRows } = await supabase
      .from('agent_footprints')
      .select('*')
      .or(`id.eq.fp_wt_msg_${msgId},id.eq.wt_msg_${msgId}`);

    const hasSingleDbRow = fpRows?.length === 1;
    recordResult(
      'TEST 1: 1 Message produces exactly 1 durable database record',
      hasSingleDbRow,
      `agent_footprints rows count: ${fpRows?.length} (expected 1)`
    );

    // -------------------------------------------------------------
    // TEST 2: Two distinct messages sent within 1 second are both preserved (No 60s suppression)
    // -------------------------------------------------------------
    const msg2Id = `msg_test_${ts}_2`;
    const msg3Id = `msg_test_${ts}_3`;
    const nowIso = new Date().toISOString();

    const clientMessages = [
      {
        id: `wt_msg_${msg2Id}`,
        agentId: userA.agentId,
        peerAgentId: slaveAgentId,
        type: 'MESSAGE_SENT',
        text: `@${userA.agentId} transmitted encrypted message to @${slaveAgentId}`,
        createdAt: nowIso
      },
      {
        id: `wt_msg_${msg3Id}`,
        agentId: userA.agentId,
        peerAgentId: slaveAgentId,
        type: 'MESSAGE_SENT',
        text: `@${userA.agentId} transmitted encrypted message to @${slaveAgentId}`,
        createdAt: nowIso
      }
    ];

    const dedupedMessages = deduplicateAndMergeWatchtowerActivities(clientMessages);
    const bothMessagesPreserved = dedupedMessages.length === 2;

    recordResult(
      'TEST 2: Two distinct messages sent within 1 second are both preserved (No 60s suppression)',
      bothMessagesPreserved,
      `Input messages: 2, Output messages: ${dedupedMessages.length} (expected 2)`
    );

    // -------------------------------------------------------------
    // TEST 3: Identical message retried/resubmitted is completely idempotent (1 DB record)
    // -------------------------------------------------------------
    // Submit identical message ID a second time
    await watchtowerActivityService.recordWatchtowerActivity({
      id: `wt_msg_${msgId}`,
      agentId: userA.agentId,
      agentName: userA.name,
      text: `@${userA.agentId} transmitted encrypted message to @${slaveAgentId}`,
      type: 'MESSAGE_SENT',
      actorUserId: userA.id,
      masterId: userA.id,
      peerAgentId: slaveAgentId,
      entityId: msgId,
      activityKey: `msg_sent:${msgId}`
    });

    const { data: fpRowsAfterRetry } = await supabase
      .from('agent_footprints')
      .select('*')
      .or(`id.eq.fp_wt_msg_${msgId},id.eq.wt_msg_${msgId}`);

    const stillSingleRow = fpRowsAfterRetry?.length === 1;
    recordResult(
      'TEST 3: Identical message retried/re-submitted is completely idempotent',
      stillSingleRow,
      `Footprint rows after retry: ${fpRowsAfterRetry?.length} (expected 1)`
    );

    // -------------------------------------------------------------
    // TEST 4: Connection established produces 1 Connected event with canonical ID
    // -------------------------------------------------------------
    const connId = `conn_opt_${ts}`;
    const connRecord = await watchtowerActivityService.recordWatchtowerActivity({
      id: `wt_conn_${connId}`,
      agentId: userA.agentId,
      agentName: userA.name,
      text: `@${userA.agentId} connected with peer @${slaveAgentId}`,
      type: 'CONNECTED',
      category: 'connection',
      outcome: 'success',
      actorUserId: userA.id,
      masterId: userA.id,
      peerAgentId: slaveAgentId,
      entityId: connId,
      activityKey: `conn_est:${connId}`
    });

    const connHasCanonicalId = connRecord.id === `wt_conn_${connId}`;
    const connHasCanonicalType = connRecord.type === 'CONNECTED';
    recordResult(
      'TEST 4: Connection establishment produces canonical Connected event',
      connHasCanonicalId && connHasCanonicalType,
      `ID: ${connRecord.id}, type: ${connRecord.type}`
    );

    // -------------------------------------------------------------
    // TEST 5: Connection dissolved produces 1 Disconnected event with canonical ID
    // -------------------------------------------------------------
    const disconnRecord = await watchtowerActivityService.recordWatchtowerActivity({
      id: `wt_disconn_${connId}`,
      agentId: userA.agentId,
      agentName: userA.name,
      text: `@${userA.agentId} disconnected from peer @${slaveAgentId}`,
      type: 'DISCONNECTED',
      category: 'connection',
      outcome: 'info',
      actorUserId: userA.id,
      masterId: userA.id,
      peerAgentId: slaveAgentId,
      entityId: connId,
      activityKey: `conn_dissolved:${connId}`
    });

    const disconnHasCanonicalId = disconnRecord.id === `wt_disconn_${connId}`;
    const disconnHasCanonicalType = disconnRecord.type === 'DISCONNECTED';
    recordResult(
      'TEST 5: Connection dissolved produces canonical Disconnected event',
      disconnHasCanonicalId && disconnHasCanonicalType,
      `ID: ${disconnRecord.id}, type: ${disconnRecord.type}`
    );

    // -------------------------------------------------------------
    // TEST 6: Cluster operations use canonical vocabulary and IDs
    // -------------------------------------------------------------
    const clusterId = `clu_opt_${ts}`;
    const cluCreate = await watchtowerActivityService.recordWatchtowerActivity({
      id: `wt_clu_create_${clusterId}`,
      agentId: userA.agentId,
      agentName: userA.name,
      text: `@${userA.agentId} created cluster "Optimization Enclave"`,
      type: 'CLUSTER_CREATED',
      category: 'cluster',
      cluster: { id: clusterId, name: 'Optimization Enclave' }
    });

    const cluMemberAdd = await watchtowerActivityService.recordWatchtowerActivity({
      id: `wt_clu_add_${clusterId}_${slaveAgentId}`,
      agentId: userA.agentId,
      agentName: userA.name,
      text: `@${userA.agentId} added @${slaveAgentId} to cluster "Optimization Enclave"`,
      type: 'MEMBER_ADDED',
      category: 'cluster',
      peerAgentId: slaveAgentId,
      cluster: { id: clusterId, name: 'Optimization Enclave' }
    });

    const clusterEventsOk = cluCreate.id.startsWith('wt_clu_create_') &&
      cluMemberAdd.id.startsWith('wt_clu_add_') &&
      cluCreate.category === 'cluster' &&
      cluMemberAdd.category === 'cluster';

    recordResult(
      'TEST 6: Cluster creation and member operations produce canonical events',
      clusterEventsOk,
      `Create ID: ${cluCreate.id}, Member Add ID: ${cluMemberAdd.id}`
    );

    // -------------------------------------------------------------
    // TEST 7: Tool execution events use canonical vocabulary
    // -------------------------------------------------------------
    const toolId = `tool_opt_${ts}`;
    const toolAppr = await watchtowerActivityService.recordWatchtowerActivity({
      id: `wt_tool_appr_${toolId}`,
      agentId: userA.agentId,
      agentName: userA.name,
      text: `@${userA.name} approved tool "security_scanner"`,
      type: 'TOOL_APPROVED',
      category: 'tool',
      outcome: 'success'
    });

    const toolExec = await watchtowerActivityService.recordWatchtowerActivity({
      id: `wt_tool_exec_${toolId}`,
      agentId: userA.agentId,
      agentName: userA.name,
      text: `@${userA.agentId} executed tool "security_scanner"`,
      type: 'TOOL_EXECUTED',
      category: 'tool',
      outcome: 'success'
    });

    const toolEventsOk = toolAppr.category === 'tool' &&
      toolExec.category === 'tool' &&
      toolAppr.type === 'TOOL_APPROVED' &&
      toolExec.type === 'TOOL_EXECUTED';

    recordResult(
      'TEST 7: Tool lifecycle produces canonical Tool approved & Tool executed events',
      toolEventsOk,
      `Appr type: ${toolAppr.type}, Exec type: ${toolExec.type}`
    );

    // -------------------------------------------------------------
    // TEST 8: SSE broadcast delivers only watchtower_activity (0 floor_activity duplicates)
    // -------------------------------------------------------------
    let sseEventsReceived: Array<{ event: string; data: any }> = [];
    const mockRes: any = {
      write: (chunk: string) => {
        const lines = chunk.split('\n');
        let currentEvent = 'message';
        let currentData = '';
        for (const line of lines) {
          if (line.startsWith('event: ')) currentEvent = line.replace('event: ', '').trim();
          if (line.startsWith('data: ')) currentData = line.replace('data: ', '').trim();
        }
        if (currentData) {
          try {
            sseEventsReceived.push({ event: currentEvent, data: JSON.parse(currentData) });
          } catch {}
        }
      },
      on: () => {},
      end: () => {}
    };

    watchtowerActivityService.registerWatchtowerStreamClient(mockRes, {
      userId: userA.id,
      agentId: userA.agentId,
      masterId: userA.id,
      isMaster: true
    });

    // Clear initial handshake event
    sseEventsReceived = [];

    // Broadcast a new event
    await watchtowerActivityService.recordWatchtowerActivity({
      agentId: userA.agentId,
      agentName: userA.name,
      text: `@${userA.agentId} updated its profile`,
      type: 'PROFILE_UPDATED',
      category: 'account',
      actorUserId: userA.id,
      masterId: userA.id
    });

    const countWatchtowerActivity = sseEventsReceived.filter(e => e.event === 'watchtower_activity').length;
    const countFloorActivity = sseEventsReceived.filter(e => e.event === 'floor_activity').length;

    const sseBroadcastClean = countWatchtowerActivity === 1 && countFloorActivity === 0;
    recordResult(
      'TEST 8: SSE broadcast delivers only watchtower_activity (0 floor_activity duplicate)',
      sseBroadcastClean,
      `watchtower_activity: ${countWatchtowerActivity}, floor_activity: ${countFloorActivity}`
    );

    // -------------------------------------------------------------
    // TEST 9: Cursor-based pagination on /api/watchtower/activity
    // -------------------------------------------------------------
    const baseTime = Date.now();
    for (let i = 0; i < 6; i++) {
      await watchtowerActivityService.recordWatchtowerActivity({
        id: `wt_page_evt_${ts}_${i}`,
        agentId: userA.agentId,
        agentName: userA.name,
        text: `@${userA.agentId} completed activity step ${i}`,
        type: 'MESSAGE_SENT',
        actorUserId: userA.id,
        masterId: userA.id,
        createdAt: new Date(baseTime + i * 1000).toISOString()
      });
    }

    const resPage1 = await helperFetch('/api/watchtower/activity?limit=3', {
      headers: { 'Cookie': `aamarva_human_session=${sessionTokenA}` }
    });

    const page1Data = resPage1.json?.data || [];
    const hasLimit3 = page1Data.length <= 3 && page1Data.length > 0;
    const oldestTimestampPage1 = page1Data[page1Data.length - 1]?.createdAt;
    const oldestTime1Ms = new Date(oldestTimestampPage1).getTime();

    const resPage2 = await helperFetch(`/api/watchtower/activity?limit=3&before=${encodeURIComponent(oldestTimestampPage1)}`, {
      headers: { 'Cookie': `aamarva_human_session=${sessionTokenA}` }
    });
    const page2Data = resPage2.json?.data || [];

    const page2OlderThanPage1 = page2Data.length > 0 && page2Data.every((item: any) =>
      new Date(item.createdAt).getTime() < oldestTime1Ms
    );

    recordResult(
      'TEST 9: Cursor-based pagination returns bounded window ordered by timestamp',
      hasLimit3 && page2OlderThanPage1,
      `Page 1 count: ${page1Data.length}, Page 2 count: ${page2Data.length}, oldest P1: ${oldestTimestampPage1}, P2 newest: ${page2Data[0]?.createdAt}`
    );

    // -------------------------------------------------------------
    // TEST 10: Canonical event vocabulary matches exact table
    // -------------------------------------------------------------
    const sampleRecord = watchtowerActivityService.formatStructuredRecord({
      type: 'CAPACITY_UPDATED',
      text: 'Master expanded fleet capacity (+10 accounts, 20 total)',
      details: { added: 10, total: 20 }
    });

    const vocabularyRecognized = sampleRecord !== null &&
      sampleRecord.category === 'plan' &&
      sampleRecord.text.includes('Slave Account Slots') &&
      sampleRecord.text.includes('20 total slave slots') &&
      sampleRecord.planDetails?.planName === 'Slave Capacity Add-On Plan';

    recordResult(
      'TEST 10: Canonical event vocabulary maps seamlessly to structured activity record',
      vocabularyRecognized,
      `Type: ${sampleRecord?.type}, Category: ${sampleRecord?.category}, Text: ${sampleRecord?.text}`
    );

  } catch (err: any) {
    console.error('Fatal error during watchtower optimization tests:', err);
    recordResult('Watchtower Optimization Tests Execution', false, err.message);
  } finally {
    server.close();
  }

  return results;
}
