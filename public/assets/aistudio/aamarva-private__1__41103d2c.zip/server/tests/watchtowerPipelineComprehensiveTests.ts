import express from 'express';
import http from 'http';
import cookieParser from 'cookie-parser';
import aamarvaRouter from '../routes/aamarvaRoutes';
import clusterRouter from '../routes/clusterRoutes';
import floorRouter from '../routes/floorRoutes';
import { slaveActivityMiddleware } from '../middleware/slaveActivityMiddleware';
import { getSupabaseClient } from '../supabase';
import { registerUser, createHumanSession, generateAgentAccessToken } from '../authService';
import { watchtowerActivityService } from '../services/watchtowerActivityService';
import { deduplicateAndMergeWatchtowerActivities } from '../../src/lib/watchtowerActivityDeduplication';

export async function runWatchtowerPipelineTests(): Promise<Record<string, { status: 'PASSED' | 'FAILED'; reason?: string }>> {
  console.log('\n=== AAMARVA WATCHTOWER ACTIVITY PIPELINE: TESTS A THROUGH I ===\n');
  const results: Record<string, { status: 'PASSED' | 'FAILED'; reason?: string }> = {};

  const recordResult = (id: string, success: boolean, reason?: string) => {
    results[id] = { status: success ? 'PASSED' : 'FAILED', reason };
    console.log(`[${success ? 'PASSED' : 'FAILED'}] ${id}${reason ? `: ${reason}` : ''}`);
  };

  const app = express();
  app.use(cookieParser());
  app.use(express.json());
  app.use(slaveActivityMiddleware);
  app.use('/api', aamarvaRouter);
  app.use('/api', clusterRouter);
  app.use('/api/floor', floorRouter);

  const server = http.createServer(app);
  await new Promise<void>((resolve) => server.listen(0, resolve));
  const port = (server.address() as any).port;
  const baseUrl = `http://127.0.0.1:${port}`;

  const helperFetch = async (endpoint: string, options: any = {}) => {
    const res = await fetch(`${baseUrl}${endpoint}`, {
      ...options,
      headers: {
        'Accept': 'application/json',
        ...(options.headers || {})
      }
    });
    const contentType = res.headers.get('content-type') || '';
    const text = await res.text();
    let json: any = null;
    try {
      json = JSON.parse(text);
    } catch {}
    return { status: res.status, headers: res.headers, contentType, json, text };
  };

  try {
    const supabase = getSupabaseClient();
    const ts = Date.now();

    // 1. Setup Master A and Master B for fleet isolation testing
    const emailA = `wt_master_a_${ts}@aamarva.test`;
    const regA = await registerUser({ email: emailA, password: 'OwnerPassword123!', agentName: 'Master A' });
    const masterA = regA.user;
    const sessionTokenA = await createHumanSession(masterA.id);

    const emailB = `wt_master_b_${ts}@aamarva.test`;
    const regB = await registerUser({ email: emailB, password: 'OwnerPassword123!', agentName: 'Master B' });
    const masterB = regB.user;
    const sessionTokenB = await createHumanSession(masterB.id);

    // 2. Setup Slave Agent under Master A
    const slaveId = `usr_slave_a_${ts}`;
    const slaveAgentId = `AMR-SLA-${ts}`;
    await supabase.from('users').insert({
      id: slaveId,
      agentId: slaveAgentId,
      name: 'Slave Agent Alpha',
      email: `slave_a_${ts}@aamarva.test`,
      passwordHash: '$2a$10$dummyhashforunittesting',
      emailVerified: true,
      master_id: masterA.id,
      is_master_primary: false,
      account_type: 'slave',
      role: 'slave',
      createdAt: new Date().toISOString()
    });
    const slaveToken = generateAgentAccessToken({
      id: slaveId,
      agentId: slaveAgentId,
      type: 'agent'
    });

    // -------------------------------------------------------------
    // TEST A: Authenticated Slave Activity Recording
    // -------------------------------------------------------------
    // Slave updates its profile via authenticated request
    const updateRes = await helperFetch('/api/agents/me', {
      method: 'PATCH',
      headers: {
        'Authorization': `Bearer ${slaveToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ name: 'Slave Alpha Updated', description: 'Active node' })
    });

    // Wait 150ms for response finish event
    await new Promise((r) => setTimeout(r, 150));

    const { data: slaveFps } = await supabase
      .from('agent_footprints')
      .select('*')
      .eq('user_id', slaveId);

    const testASuccess = slaveFps && slaveFps.length > 0;
    recordResult(
      'TEST A: Authenticated slave activity records operational event',
      Boolean(testASuccess),
      `Found ${slaveFps?.length || 0} footprint record(s) for slave agent`
    );

    // -------------------------------------------------------------
    // TEST B: Authenticated Master Activity Recording
    // -------------------------------------------------------------
    // Master creates a cluster enclave
    const clusterRes = await helperFetch('/api/clusters', {
      method: 'POST',
      headers: {
        'Cookie': `aamarva_human_session=${sessionTokenA}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ name: `Enclave Alpha ${ts}`, description: 'Test Enclave' })
    });

    await new Promise((r) => setTimeout(r, 150));

    const { data: masterFps } = await supabase
      .from('agent_footprints')
      .select('*')
      .eq('user_id', masterA.id);

    const testBSuccess = masterFps && masterFps.some((f: any) => f.action.includes('CLUSTER'));
    recordResult(
      'TEST B: Master activity (cluster creation) records event under fleet',
      Boolean(testBSuccess),
      `Master footprint records: ${masterFps?.length || 0}`
    );

    // -------------------------------------------------------------
    // TEST C: Missing Middleware Coverage Fixed (Cluster Enclave Member Role Update)
    // -------------------------------------------------------------
    const createdClusterId = clusterRes.json?.data?.id;
    await supabase.from('cluster_members').insert({
      id: `member_${ts}`,
      clusterId: createdClusterId,
      userId: slaveId,
      agentId: slaveAgentId,
      role: 'member',
      status: 'active',
      createdAt: new Date().toISOString()
    });

    const roleRes = await helperFetch(`/api/clusters/${createdClusterId}/members/${slaveAgentId}/role`, {
      method: 'PATCH',
      headers: {
        'Cookie': `aamarva_human_session=${sessionTokenA}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ role: 'admin' })
    });

    await new Promise((r) => setTimeout(r, 150));

    const { data: roleFps } = await supabase
      .from('agent_footprints')
      .select('*')
      .eq('user_id', masterA.id)
      .eq('action', 'CLUSTER_ROLE_UPDATED');

    const testCSuccess = roleFps && roleFps.length > 0;
    recordResult(
      'TEST C: Missing middleware coverage records newly instrumented operation',
      Boolean(testCSuccess),
      `CLUSTER_ROLE_UPDATED events found: ${roleFps?.length || 0}`
    );

    // -------------------------------------------------------------
    // TEST D: Event Persistence in agent_footprints & Retrieval via /api/watchtower/activity
    // -------------------------------------------------------------
    const wtRes = await helperFetch('/api/watchtower/activity', {
      headers: { 'Cookie': `aamarva_human_session=${sessionTokenA}` }
    });

    const wtData = wtRes.json?.data || [];
    const testDSuccess = wtRes.status === 200 && Array.isArray(wtData) && wtData.length > 0;
    recordResult(
      'TEST D: Events persisted in agent_footprints and retrieved by /api/watchtower/activity',
      testDSuccess,
      `Retrieved ${wtData.length} activities for Master A fleet`
    );

    // -------------------------------------------------------------
    // TEST E: Live Delivery via SSE Broadcast
    // -------------------------------------------------------------
    let liveDelivered = false;
    const mockSseClient: any = {
      write: (payload: string) => {
        if (payload.includes('watchtower_activity') && payload.includes('LIVE_BROADCAST_TEST')) {
          liveDelivered = true;
        }
      },
      on: () => {},
      end: () => {}
    };

    watchtowerActivityService.registerWatchtowerStreamClient(mockSseClient, {
      userId: masterA.id,
      agentId: masterA.agentId,
      masterId: masterA.id,
      isMaster: true
    });

    await watchtowerActivityService.recordWatchtowerActivity({
      agentId: slaveAgentId,
      agentName: 'Slave Alpha',
      text: 'Executing live broadcast test',
      type: 'LIVE_BROADCAST_TEST',
      category: 'general',
      actorUserId: slaveId,
      masterId: masterA.id
    });

    recordResult(
      'TEST E: Live delivery broadcasts event to authorized fleet viewer',
      liveDelivered,
      `SSE event delivered: ${liveDelivered}`
    );

    // -------------------------------------------------------------
    // TEST F: Fleet Isolation (Master B cannot see Master A's fleet activity)
    // -------------------------------------------------------------
    const wtResB = await helperFetch('/api/watchtower/activity', {
      headers: { 'Cookie': `aamarva_human_session=${sessionTokenB}` }
    });

    const wtDataB = wtResB.json?.data || [];
    const leakedFromA = wtDataB.some((ev: any) =>
      ev.actorUserId === masterA.id ||
      ev.actorUserId === slaveId ||
      ev.agentId === slaveAgentId ||
      ev.text?.includes('Slave Alpha')
    );

    recordResult(
      'TEST F: Fleet isolation guarantees Master B cannot access Master A fleet activity',
      !leakedFromA,
      `Master B retrieved ${wtDataB.length} events, leaked from A: ${leakedFromA}`
    );

    // -------------------------------------------------------------
    // TEST G: Duplicate Prevention
    // -------------------------------------------------------------
    const dupTestKey = `test_dup_${ts}`;
    // 1. First record call
    await watchtowerActivityService.recordWatchtowerActivity({
      id: `wt_${dupTestKey}`,
      agentId: masterA.agentId,
      text: 'Testing duplicate prevention',
      type: 'TOOL_INVOKED',
      actorUserId: masterA.id,
      masterId: masterA.id,
      activityKey: `act:${dupTestKey}`
    });

    // 2. Second record call with same id & activityKey
    await watchtowerActivityService.recordWatchtowerActivity({
      id: `wt_${dupTestKey}`,
      agentId: masterA.agentId,
      text: 'Testing duplicate prevention',
      type: 'TOOL_INVOKED',
      actorUserId: masterA.id,
      masterId: masterA.id,
      activityKey: `act:${dupTestKey}`
    });

    const { data: dupRows } = await supabase
      .from('agent_footprints')
      .select('*')
      .eq('id', `fp_wt_${dupTestKey}`);

    const testGSuccess = dupRows?.length === 1;
    recordResult(
      'TEST G: Duplicate prevention guarantees idempotent persistence',
      Boolean(testGSuccess),
      `agent_footprints rows count: ${dupRows?.length || 0} (expected 1)`
    );

    // -------------------------------------------------------------
    // TEST H: Sensitive Data Sanitization
    // -------------------------------------------------------------
    const sensitiveEvt = await watchtowerActivityService.recordWatchtowerActivity({
      agentId: masterA.agentId,
      text: 'Security sanitized event',
      type: 'SECURITY_EVENT',
      actorUserId: masterA.id,
      masterId: masterA.id,
      details: {
        password: 'PlainTextSecretPassword!',
        apiKey: 'sk_amr_secret_api_key_12345',
        privateKey: '0xabc123privatekey',
        safeMetadata: 'public_audit_marker'
      }
    });

    const rawDetails = JSON.stringify(sensitiveEvt.details || {});
    const leakedSensitive = rawDetails.includes('PlainTextSecretPassword') ||
      rawDetails.includes('sk_amr_secret') ||
      rawDetails.includes('0xabc123privatekey');

    recordResult(
      'TEST H: Sensitive data sanitization strips credentials, secrets, and private keys',
      !leakedSensitive && sensitiveEvt.details?.safeMetadata === 'public_audit_marker',
      `Leaked sensitive keywords: ${leakedSensitive}`
    );

    // -------------------------------------------------------------
    // TEST I: Failure Handling
    // -------------------------------------------------------------
    let failureHandled = false;
    try {
      // Intentionally pass an invalid user_id that violates foreign key constraint or null text
      await (watchtowerActivityService as any).recordWatchtowerActivity({
        actorUserId: 'usr_non_existent_' + Math.random(),
        text: ''
      });
    } catch (e: any) {
      failureHandled = true;
    }

    recordResult(
      'TEST I: Failure handling appropriately captures persistence/validation errors',
      failureHandled,
      `Error properly caught and handled: ${failureHandled}`
    );

  } catch (err: any) {
    console.error('Fatal test suite exception:', err);
    recordResult('Pipeline Test Execution', false, err?.message);
  } finally {
    server.close();
  }

  return results;
}

if (process.argv[1] && process.argv[1].includes('watchtowerPipelineComprehensiveTests')) {
  runWatchtowerPipelineTests().then(() => {
    process.exit(0);
  }).catch((e) => {
    console.error(e);
    process.exit(1);
  });
}
