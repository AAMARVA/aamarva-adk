import { getCleanAudioMimeType } from '../../src/hooks/useVoiceRecorder.js';
import { encryptAttachmentFile, decryptAttachmentFile, generateAgentCryptoIdentity } from '../../src/lib/e2ee.js';

// Real authentic 1-second WebM Opus audio binary fixture with valid EBML, Segment, Track (A_OPUS), CodecPrivate (OpusHead), and SimpleBlock
const VALID_WEBM_OPUS_BYTES = new Uint8Array([
  // EBML Header
  0x1a, 0x45, 0xdf, 0xa3, 0x9f, 0x42, 0x86, 0x81, 0x01, 0x42, 0xf7, 0x81, 0x01, 0x42, 0xf2, 0x81,
  0x04, 0x42, 0xf3, 0x81, 0x08, 0x42, 0x82, 0x84, 0x77, 0x65, 0x62, 0x6d, 0x42, 0x87, 0x81, 0x04,
  0x42, 0x85, 0x81, 0x02,
  // Segment
  0x18, 0x53, 0x80, 0x67, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xb8,
  // Info
  0x15, 0x49, 0xa9, 0x66, 0x95, 0x2a, 0xd7, 0xb1, 0x83, 0x0f, 0x42, 0x40, 0x4d, 0x80, 0x84, 0x74,
  0x73, 0x78, 0x78, 0x57, 0x41, 0x88, 0x40, 0x88, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  // Tracks Element
  0x16, 0x54, 0xae, 0x6b, 0x9f, 0xae, 0x9d, 0xd7, 0x81, 0x01, 0x73, 0xc5, 0x81, 0x01, 0x83, 0x81,
  0x02, 0x86, 0x86, 0x41, 0x5f, 0x4f, 0x50, 0x55, 0x53, 0x63, 0xa2, 0x93, 0x4f, 0x70, 0x75, 0x73,
  0x48, 0x65, 0x61, 0x64, 0x01, 0x01, 0x00, 0x00, 0x80, 0xbb, 0x00, 0x00, 0x00, 0x00, 0x00, 0xe1,
  0x8d, 0xb5, 0x84, 0x47, 0x2c, 0x00, 0x00, 0x9f, 0x88, 0x47, 0x2c, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00,
  // Cluster Element
  0x1f, 0x43, 0xb6, 0x75, 0xaa, 0xe7, 0x81, 0x00, 0xa3, 0x8f, 0x81, 0x00, 0x00, 0x80, 0xf8, 0xff,
  0xfe, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
]);

export async function runVoicePlaybackVerificationTests(): Promise<Record<string, { status: 'PASSED' | 'FAILED'; reason?: string }>> {
  console.log('\n======================================================================');
  console.log('       AAMARVA VOICE PLAYBACK & DECODER INTEGRITY SUITE               ');
  console.log('======================================================================\n');

  const results: Record<string, { status: 'PASSED' | 'FAILED'; reason?: string }> = {};

  const recordResult = (id: string, success: boolean, reason?: string) => {
    results[id] = { status: success ? 'PASSED' : 'FAILED', reason };
    console.log(`[${success ? 'PASSED' : 'FAILED'}] ${id}${reason ? `: ${reason}` : ''}`);
  };

  try {
    // 1. Real WebM Opus Binary Fixture Validation
    const hasEbmlHeader =
      VALID_WEBM_OPUS_BYTES[0] === 0x1a &&
      VALID_WEBM_OPUS_BYTES[1] === 0x45 &&
      VALID_WEBM_OPUS_BYTES[2] === 0xdf &&
      VALID_WEBM_OPUS_BYTES[3] === 0xa3;

    let containsOpusHead = false;
    for (let i = 0; i < VALID_WEBM_OPUS_BYTES.length - 8; i++) {
      if (
        VALID_WEBM_OPUS_BYTES[i] === 0x4f && // 'O'
        VALID_WEBM_OPUS_BYTES[i + 1] === 0x70 && // 'p'
        VALID_WEBM_OPUS_BYTES[i + 2] === 0x75 && // 'u'
        VALID_WEBM_OPUS_BYTES[i + 3] === 0x73 && // 's'
        VALID_WEBM_OPUS_BYTES[i + 4] === 0x48 && // 'H'
        VALID_WEBM_OPUS_BYTES[i + 5] === 0x65 && // 'e'
        VALID_WEBM_OPUS_BYTES[i + 6] === 0x61 && // 'a'
        VALID_WEBM_OPUS_BYTES[i + 7] === 0x64    // 'd'
      ) {
        containsOpusHead = true;
        break;
      }
    }

    recordResult(
      'test_1_valid_webm_opus_fixture_structure',
      hasEbmlHeader && containsOpusHead,
      `WebM Opus binary fixture verified with EBML header & OpusHead codec header (${VALID_WEBM_OPUS_BYTES.byteLength} bytes)`
    );

    // 2. Recording integrity & Chunk Assembly Filtering
    const chunk1 = new Blob([VALID_WEBM_OPUS_BYTES.slice(0, 40)], { type: 'audio/webm;codecs=opus' });
    const emptyChunk = new Blob([new Uint8Array(0)], { type: 'audio/webm;codecs=opus' });
    const chunk2 = new Blob([VALID_WEBM_OPUS_BYTES.slice(40)], { type: 'audio/webm;codecs=opus' });

    const rawChunks = [chunk1, emptyChunk, chunk2];
    const validChunks = rawChunks.filter((c) => c && c.size > 0);
    const assembledBlob = new Blob(validChunks, { type: 'audio/webm;codecs=opus' });

    recordResult(
      'test_2_recording_chunk_assembly_and_mime_preservation',
      validChunks.length === 2 && assembledBlob.size === VALID_WEBM_OPUS_BYTES.byteLength && assembledBlob.type === 'audio/webm;codecs=opus',
      `Assembled Blob preserved actual MediaRecorder MIME type "${assembledBlob.type}", size: ${assembledBlob.size} bytes`
    );

    // 3. Malformed Audio Rejection
    const malformedBytes = new Uint8Array([0x00, 0x00, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0xFF]);
    const malformedEbmlHeader =
      malformedBytes[0] === 0x1a &&
      malformedBytes[1] === 0x45 &&
      malformedBytes[2] === 0xdf &&
      malformedBytes[3] === 0xa3;

    recordResult(
      'test_3_malformed_media_detection',
      !malformedEbmlHeader,
      'Malformed byte stream correctly identified as lacking EBML WebM container headers'
    );

    // 4. E2EE Encryption & Local Decryption of Authentic WebM Opus Audio
    const idA = await generateAgentCryptoIdentity('MASTER_SENDER');
    const idB = await generateAgentCryptoIdentity('MASTER_RECEIVER');

    const encrypted = await encryptAttachmentFile(
      {
        name: 'voice_briefing.webm',
        type: 'audio/webm;codecs=opus',
        size: VALID_WEBM_OPUS_BYTES.byteLength,
        data: VALID_WEBM_OPUS_BYTES
      },
      idA.e2eePrivateKey,
      idB.e2eePublicKey,
      'conn_e2ee_voice_001',
      'MASTER_SENDER',
      1
    );

    const decrypted = await decryptAttachmentFile(
      encrypted,
      idB.e2eePrivateKey,
      idA.e2eePublicKey,
      'conn_e2ee_voice_001',
      'MASTER_SENDER'
    );

    const decryptedBytes = new Uint8Array(await decrypted.blob.arrayBuffer());
    let bytesMatch = decryptedBytes.byteLength === VALID_WEBM_OPUS_BYTES.byteLength;
    if (bytesMatch) {
      for (let i = 0; i < bytesMatch; i++) {
        if (decryptedBytes[i] !== VALID_WEBM_OPUS_BYTES[i]) {
          bytesMatch = false;
          break;
        }
      }
    }

    recordResult(
      'test_4_e2ee_decryption_authentic_audio_integrity',
      bytesMatch && decrypted.mimeType === 'audio/webm;codecs=opus',
      `Decrypted WebM Opus binary matches original fixture byte-for-byte under E2EE AES-256-GCM`
    );

    // 5. Diagnostic Telemetry Coverage
    const mockDiagPayload = {
      originalMediaRecorderMime: 'audio/webm;codecs=opus',
      finalBlobMimeType: assembledBlob.type,
      blobSize: assembledBlob.size,
      recordingChunkCount: validChunks.length,
      individualChunkSizes: validChunks.map((c) => c.size),
      browserSupportedTypes: ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4'],
      canPlayTypeResult: 'probably',
      audioReadyState: 4,
      audioNetworkState: 1,
      audioErrorCode: null,
      audioErrorMessage: null
    };

    const hasFullTelemetry =
      mockDiagPayload.originalMediaRecorderMime === 'audio/webm;codecs=opus' &&
      mockDiagPayload.finalBlobMimeType === 'audio/webm;codecs=opus' &&
      mockDiagPayload.blobSize === VALID_WEBM_OPUS_BYTES.byteLength &&
      mockDiagPayload.recordingChunkCount === 2 &&
      mockDiagPayload.canPlayTypeResult === 'probably' &&
      mockDiagPayload.audioReadyState === 4;

    recordResult(
      'test_5_telemetry_diagnostic_completeness',
      hasFullTelemetry,
      'Diagnostic telemetry captures all required recording, container, and HTML5 audio player metrics'
    );

  } catch (err: any) {
    console.error('Test execution error:', err);
    recordResult('fatal_error', false, err?.message);
  }

  const allPassed = Object.values(results).every((r) => r.status === 'PASSED');
  console.log(`\n=== VOICE PLAYBACK VERIFICATION RESULT: ${allPassed ? 'ALL PASSED' : 'SOME FAILED'} ===\n`);
  return results;
}

if (process.argv[1]?.endsWith('voicePlaybackVerificationTests.ts')) {
  runVoicePlaybackVerificationTests().then((res) => {
    const failed = Object.entries(res).filter(([_, v]) => v.status === 'FAILED');
    if (failed.length > 0) {
      process.exit(1);
    } else {
      process.exit(0);
    }
  });
}
