import express from 'express';
import http from 'http';
import cookieParser from 'cookie-parser';
import aamarvaRouter from '../routes/aamarvaRoutes';
import clusterRouter from '../routes/clusterRoutes';
import floorRouter from '../routes/floorRoutes';
import { slaveActivityMiddleware } from '../middleware/slaveActivityMiddleware';
import { getSupabaseClient } from '../supabase';
import { registerUser, createHumanSession, generateAgentAccessToken } from '../authService';
import { deriveAgentCryptoIdentity } from '../../src/lib/e2ee';

async function testScenarios() {
  console.log('\n=== RUNNING TARGETED USER SCENARIO VALIDATION ===\n');

  const app = express();
  app.use(cookieParser());
  app.use(express.json());
  app.use(slaveActivityMiddleware);
  app.use('/api', aamarvaRouter);
  app.use('/api', clusterRouter);
  app.use('/api/floor', floorRouter);

  const server = http.createServer(app);
  await new Promise<void>((resolve) => server.listen(0, resolve));
  const port = (server.address() as any).port;
  const baseUrl = `http://127.0.0.1:${port}`;

  const helperFetch = async (endpoint: string, options: any = {}) => {
    const res = await fetch(`${baseUrl}${endpoint}`, {
      ...options,
      headers: {
        'Accept': 'application/json',
        ...(options.headers || {})
      }
    });
    const text = await res.text();
    let json: any = null;
    try { json = JSON.parse(text); } catch {}
    return { status: res.status, json, text };
  };

  try {
    const supabase = getSupabaseClient();
    const ts = Date.now();

    // Setup Pioneer Master (Fleet Owner)
    const pioneerReg = await registerUser({
      email: `pioneer_${ts}@aamarva.test`,
      password: 'PioneerPassword123!',
      agentName: 'Pioneer Master'
    });
    const pioneerMaster = pioneerReg.user;
    const pioneerSession = await createHumanSession(pioneerMaster.id);

    // Setup Add-on Master (Slot under Pioneer Master)
    const addonId = `usr_addon_${ts}`;
    const addonAgentId = `AMR-ADDON-${ts}`;
    await supabase.from('users').insert({
      id: addonId,
      agentId: addonAgentId,
      name: 'Addon Master 1',
      email: `addon_${ts}@aamarva.test`,
      passwordHash: '$2a$10$dummyhash',
      emailVerified: true,
      master_id: pioneerMaster.id,
      is_master_primary: false,
      account_type: 'master_slot',
      role: 'master',
      createdAt: new Date().toISOString()
    });
    const addonSession = await createHumanSession(addonId);

    // Setup 3 Slave Agents under Pioneer Master
    const slaveTokens: { id: string; agentId: string; token: string }[] = [];
    for (let i = 1; i <= 3; i++) {
      const sId = `usr_slave_${i}_${ts}`;
      const sAid = `AMR-SLAVE${i}-${ts}`;
      await supabase.from('users').insert({
        id: sId,
        agentId: sAid,
        name: `Slave Node ${i}`,
        email: `slave${i}_${ts}@aamarva.test`,
        passwordHash: '$2a$10$dummyhash',
        emailVerified: true,
        master_id: pioneerMaster.id,
        is_master_primary: false,
        account_type: 'slave',
        role: 'slave',
        createdAt: new Date().toISOString()
      });
      const tok = generateAgentAccessToken({ id: sId, agentId: sAid, type: 'agent' });
      slaveTokens.push({ id: sId, agentId: sAid, token: tok });
    }

    // Setup an external Peer Agent
    const peerReg = await registerUser({
      email: `ext_peer_${ts}@aamarva.test`,
      password: 'ExternalPassword123!',
      agentName: 'External Agent'
    });
    const extPeer = peerReg.user;
    const extPeerSession = await createHumanSession(extPeer.id);

    // Register cryptographic identities
    const keysSlave1 = await deriveAgentCryptoIdentity(slaveTokens[0].agentId, 'SlavePassword123!');
    const keysPeer = await deriveAgentCryptoIdentity(extPeer.agentId, 'ExternalPassword123!');

    await helperFetch('/api/agents/me/e2ee', {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${slaveTokens[0].token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        publicKey: keysSlave1.e2eePublicKey,
        fingerprint: keysSlave1.fingerprint,
        identityKey: keysSlave1.identityPublicKey,
        signature: keysSlave1.signature,
        keyEpoch: 1,
        allowRotation: false
      })
    });

    await helperFetch('/api/agents/me/e2ee', {
      method: 'PUT',
      headers: {
        'Cookie': `aamarva_human_session=${extPeerSession}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        publicKey: keysPeer.e2eePublicKey,
        fingerprint: keysPeer.fingerprint,
        identityKey: keysPeer.identityPublicKey,
        signature: keysPeer.signature,
        keyEpoch: 1,
        allowRotation: false
      })
    });

    // Establish connection between Slave 1 and External Peer
    await supabase.from('connections').insert({
      id: `conn_${ts}`,
      user1_id: slaveTokens[0].id,
      user2_id: extPeer.id,
      user1_agent_id: slaveTokens[0].agentId,
      user2_agent_id: extPeer.agentId,
      user1_agent_name: 'Slave Node 1',
      user2_agent_name: 'External Agent',
      status: 'active',
      created_at: new Date().toISOString()
    });

    // =========================================================================
    // SCENARIO A: Agent sends a direct message
    // =========================================================================
    console.log('--- Testing Scenario A: Direct Message ---');
    const msgRes = await helperFetch(`/api/connections/messages/${extPeer.agentId}`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${slaveTokens[0].token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        ciphertext: Buffer.from('confidential_direct_message').toString('base64'),
        nonce: Buffer.from('123456789012').toString('base64'),
        version: 1,
        keyEpoch: 1
      })
    });
    console.log('Direct message sent response:', msgRes.status, msgRes.json?.success ? 'Success' : msgRes.text);
    await new Promise((r) => setTimeout(r, 200));

    // Verify in agent_footprints
    const { data: sentFps } = await supabase
      .from('agent_footprints')
      .select('*')
      .eq('user_id', slaveTokens[0].id)
      .eq('action', 'MESSAGE_SENT');

    console.log(`[Scenario A Verification] Sent footprints found: ${sentFps?.length || 0}`);
    const scenarioAPass = sentFps && sentFps.length === 1;

    // =========================================================================
    // SCENARIO B: User updates account/profile name
    // =========================================================================
    console.log('\n--- Testing Scenario B: Profile Update ---');
    const updateRes = await helperFetch('/api/agents/me', {
      method: 'PATCH',
      headers: {
        'Authorization': `Bearer ${slaveTokens[1].token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ name: 'Robotic Chimpanzee', bio: 'Autonomous unit' })
    });
    console.log('Profile update response:', updateRes.status, updateRes.json?.success ? 'Success' : updateRes.text);
    await new Promise((r) => setTimeout(r, 200));

    const { data: profFps } = await supabase
      .from('agent_footprints')
      .select('*')
      .eq('user_id', slaveTokens[1].id)
      .eq('action', 'AGENT_PROFILE_UPDATED');

    console.log(`[Scenario B Verification] Profile update footprints found: ${profFps?.length || 0}`);
    const scenarioBPass = profFps && profFps.length === 1;

    // =========================================================================
    // SCENARIO C: Multiple agents in fleet & Add-on Master Watchtower Retrieval
    // =========================================================================
    console.log('\n--- Testing Scenario C: Add-on Master queries Watchtower ---');
    // Have Slave 3 perform an activity (e.g. update its profile)
    await helperFetch('/api/agents/me', {
      method: 'PATCH',
      headers: {
        'Authorization': `Bearer ${slaveTokens[2].token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ name: 'Cyber Gorilla', bio: 'Heavy unit' })
    });
    await new Promise((r) => setTimeout(r, 200));

    // Query Watchtower using Add-on Master's session!
    const wtRes = await helperFetch('/api/watchtower/activity', {
      headers: { 'Cookie': `aamarva_human_session=${addonSession}` }
    });

    const wtActivities: any[] = wtRes.json?.data || [];
    console.log(`[Scenario C Verification] Add-on Master retrieved ${wtActivities.length} activities`);
    
    // Check that activities from all slaves appear for the Add-on Master
    const hasSlave1Msg = wtActivities.some((a) => a.agentId === slaveTokens[0].agentId && a.type === 'MESSAGE_SENT');
    const hasSlave2Prof = wtActivities.some((a) => a.agentId === slaveTokens[1].agentId && a.type === 'AGENT_PROFILE_UPDATED');
    const hasSlave3Prof = wtActivities.some((a) => a.agentId === slaveTokens[2].agentId && a.type === 'AGENT_PROFILE_UPDATED');

    console.log('Add-on Master saw Slave 1 message:', hasSlave1Msg);
    console.log('Add-on Master saw Slave 2 profile update:', hasSlave2Prof);
    console.log('Add-on Master saw Slave 3 profile update:', hasSlave3Prof);

    const scenarioCPass = wtRes.status === 200 && hasSlave1Msg && hasSlave2Prof && hasSlave3Prof;

    const allPassed = scenarioAPass && scenarioBPass && scenarioCPass;
    console.log(`\n=== SCENARIO TEST SUMMARY: ${allPassed ? 'ALL PASSED' : 'SOME FAILED'} ===`);
    return allPassed;
  } finally {
    server.close();
  }
}

testScenarios().then((passed) => {
  process.exit(passed ? 0 : 1);
}).catch((err) => {
  console.error('Scenario test error:', err);
  process.exit(1);
});
