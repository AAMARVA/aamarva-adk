import http from 'http';
import { createApp } from '../../server.js';
import { getSupabaseClient } from '../supabase.js';
import { registerUser, createHumanSession } from '../authService.js';
import { establishDirectConnection } from '../services/connectionService.js';
import { 
  generateAgentCryptoIdentity, 
  encryptAttachmentFile, 
  decryptAttachmentFile,
  encryptMessage,
  decryptMessage,
  rotateAgentCryptoIdentity
} from '../../src/lib/e2ee.js';

export async function runServerBlindE2EEAttachmentTests(): Promise<Record<string, { status: 'PASSED' | 'FAILED'; reason?: string }>> {
  console.log('\n======================================================================');
  console.log('   AAMARVA SERVER-BLIND E2EE ATTACHMENT SECURITY & INTEGRITY SUITE   ');
  console.log('======================================================================\n');

  const results: Record<string, { status: 'PASSED' | 'FAILED'; reason?: string }> = {};

  const recordResult = (id: string, success: boolean, reason?: string) => {
    results[id] = { status: success ? 'PASSED' : 'FAILED', reason };
    console.log(`[${success ? 'PASSED' : 'FAILED'}] ${id}${reason ? `: ${reason}` : ''}`);
  };

  process.env.VERCEL = '1';
  const app = await createApp();
  const server = http.createServer(app);
  await new Promise<void>((resolve) => server.listen(0, resolve));
  const port = (server.address() as any).port;
  const baseUrl = `http://127.0.0.1:${port}`;

  const helperFetch = async (endpoint: string, options: any = {}) => {
    const res = await fetch(`${baseUrl}${endpoint}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(options.headers || {})
      }
    });
    const text = await res.text();
    let json: any = null;
    try {
      json = JSON.parse(text);
    } catch {}
    return { status: res.status, json, text };
  };

  const ts = Date.now();

  try {
    const supabase = getSupabaseClient();

    // 1. Setup Sender (User A)
    const emailA = `sender_a_${ts}@aamarva.test`;
    const regA = await registerUser({ email: emailA, password: 'SenderPassword123!', agentName: 'Sender Agent' });
    const userA = regA.user;
    const sessionA = await createHumanSession(userA.id);
    const cookieA = `aamarva_human_session=${sessionA}`;

    // 2. Setup Recipient (User B)
    const emailB = `recipient_b_${ts}@aamarva.test`;
    const regB = await registerUser({ email: emailB, password: 'RecipientPassword123!', agentName: 'Recipient Agent' });
    const userB = regB.user;
    const sessionB = await createHumanSession(userB.id);
    const cookieB = `aamarva_human_session=${sessionB}`;

    // 3. Setup Unauthorized Attacker (User C)
    const emailC = `attacker_c_${ts}@aamarva.test`;
    const regC = await registerUser({ email: emailC, password: 'AttackerPassword123!', agentName: 'Attacker Agent' });
    const userC = regC.user;
    const sessionC = await createHumanSession(userC.id);
    const cookieC = `aamarva_human_session=${sessionC}`;

    // 4. Establish Direct Connection between User A and User B
    const connAB = await establishDirectConnection(userA.id, userB.id);
    if (!connAB || !connAB.id) {
      throw new Error('Failed to establish direct connection between User A and User B');
    }
    const connectionId = connAB.id;

    // 5. Generate P-256 ECDH identities for User A, User B, and User C
    const identityA = await generateAgentCryptoIdentity(userA.agentId);
    const identityB = await generateAgentCryptoIdentity(userB.agentId);
    const identityC = await generateAgentCryptoIdentity(userC.agentId);

    // Register User B public key on the server
    const regBRes = await helperFetch(`/api/agents/me/e2ee`, {
      method: 'PUT',
      headers: { Cookie: cookieB },
      body: JSON.stringify({
        publicKey: identityB.e2eePublicKey,
        identityKey: identityB.identityPublicKey,
        fingerprint: identityB.fingerprint,
        signature: identityB.signature,
        keyEpoch: 1
      })
    });

    // Register User A public key on the server
    const regARes = await helperFetch(`/api/agents/me/e2ee`, {
      method: 'PUT',
      headers: { Cookie: cookieA },
      body: JSON.stringify({
        publicKey: identityA.e2eePublicKey,
        identityKey: identityA.identityPublicKey,
        fingerprint: identityA.fingerprint,
        signature: identityA.signature,
        keyEpoch: 1
      })
    });

    // -------------------------------------------------------------------------
    // Property 1: Client encrypts locally before upload
    // -------------------------------------------------------------------------
    const secretContentStr = 'CONFIDENTIAL_TOP_SECRET_ATTACHMENT_PAYLOAD_AAMARVA_2026';
    const secretRawBytes = new TextEncoder().encode(secretContentStr);
    const originalFilename = 'tactical_orders_classified.pdf';
    const originalMime = 'application/pdf';

    const encryptedPayload = await encryptAttachmentFile(
      {
        name: originalFilename,
        type: originalMime,
        size: secretRawBytes.byteLength,
        data: secretRawBytes
      },
      identityA.e2eePrivateKey,
      identityB.e2eePublicKey,
      connectionId,
      userA.agentId,
      1
    );

    const clientEncryptionValid = 
      Boolean(encryptedPayload.attachmentId) &&
      Boolean(encryptedPayload.ciphertext) &&
      Boolean(encryptedPayload.nonce) &&
      encryptedPayload.version === 1 &&
      encryptedPayload.keyEpoch === 1 &&
      typeof encryptedPayload.ciphertextSize === 'number' &&
      !encryptedPayload.ciphertext.includes(secretContentStr) &&
      !encryptedPayload.ciphertext.includes(originalFilename);

    recordResult('property_1_client_encrypts_locally_before_upload', clientEncryptionValid,
      'Client encrypted file locally with P-256 ECDH, HKDF, and AES-256-GCM. Ciphertext contains no plaintext leaks.');

    // -------------------------------------------------------------------------
    // Property 2: Server-blind storage and transmission
    // -------------------------------------------------------------------------
    // Upload valid encrypted payload
    const uploadRes = await helperFetch(`/api/connections/${connectionId}/attachments`, {
      method: 'POST',
      headers: { Cookie: cookieA },
      body: JSON.stringify(encryptedPayload)
    });

    const uploadSuccessful = uploadRes.status === 201 && uploadRes.json?.success === true;

    // Verify server rejected any payload containing plaintext keys
    const plaintextAttackRes = await helperFetch(`/api/connections/${connectionId}/attachments`, {
      method: 'POST',
      headers: { Cookie: cookieA },
      body: JSON.stringify({
        ...encryptedPayload,
        filename: 'leaked_filename.pdf',
        text: 'leaked plaintext message'
      })
    });

    const plaintextRejected = plaintextAttackRes.status === 400;

    // Check underlying storage directly to verify zero-knowledge storage
    const { data: dbRows } = await supabase
      .from('encrypted_attachments')
      .select('*')
      .eq('id', encryptedPayload.attachmentId);

    const storedRow = dbRows?.[0];
    const storageZeroKnowledge = 
      Boolean(storedRow) &&
      storedRow.ciphertext === encryptedPayload.ciphertext &&
      storedRow.nonce === encryptedPayload.nonce &&
      storedRow.content === undefined &&
      storedRow.filename === undefined &&
      storedRow.text === undefined;

    recordResult('property_2_server_blind_storage_and_transmission', 
      uploadSuccessful && plaintextRejected && storageZeroKnowledge,
      'Backend receives and stores only ciphertext and nonce. Plaintext payload fields are rejected with HTTP 400.');

    // -------------------------------------------------------------------------
    // Property 3: Server cannot decrypt (no private keys)
    // -------------------------------------------------------------------------
    // The server has no recipient private key. Any attempt to decrypt without the key throws an error.
    let serverDecryptionBlocked = false;
    try {
      await decryptAttachmentFile(
        encryptedPayload,
        null as any, // Server has no private key
        identityA.e2eePublicKey,
        connectionId,
        userA.agentId
      );
    } catch (err: any) {
      serverDecryptionBlocked = true;
    }

    recordResult('property_3_server_cannot_decrypt', serverDecryptionBlocked,
      'Server possesses no private keys and cannot decrypt stored attachment blobs.');

    // -------------------------------------------------------------------------
    // Property 4: Authorized recipient successfully decrypts and verifies SHA-256
    // -------------------------------------------------------------------------
    const recipientFetchRes = await helperFetch(`/api/connections/${connectionId}/attachments/${encryptedPayload.attachmentId}`, {
      method: 'GET',
      headers: { Cookie: cookieB }
    });

    const recipientFetchSuccess = recipientFetchRes.status === 200 && recipientFetchRes.json?.success === true;
    const downloadedPayload = recipientFetchRes.json?.data;

    const decryptedFile = await decryptAttachmentFile(
      downloadedPayload,
      identityB.e2eePrivateKey,
      identityA.e2eePublicKey,
      connectionId,
      userA.agentId
    );

    const decryptedText = new TextDecoder().decode(decryptedFile.data);
    const checksumValid = decryptedFile.checksum && decryptedFile.checksum.length === 64;
    const metadataMatch = 
      decryptedFile.filename === originalFilename &&
      decryptedFile.mimeType === originalMime &&
      decryptedText === secretContentStr &&
      checksumValid;

    recordResult('property_4_recipient_decrypts_and_verifies_checksum', 
      recipientFetchSuccess && Boolean(metadataMatch),
      `Authorized recipient decrypted attachment locally. Verified SHA-256 checksum (${decryptedFile.checksum.substring(0, 16)}...) and metadata.`);

    // -------------------------------------------------------------------------
    // Property 5: Unauthorized party rejected with 403 and decryption fails
    // -------------------------------------------------------------------------
    // User C tries to download User A and B's attachment from connection
    const attackerFetchRes = await helperFetch(`/api/connections/${connectionId}/attachments/${encryptedPayload.attachmentId}`, {
      method: 'GET',
      headers: { Cookie: cookieC }
    });

    const attackerForbidden = attackerFetchRes.status === 403;

    // Even if User C gets the ciphertext through eavesdropping, decrypting with User C's key fails
    let attackerDecryptionFailed = false;
    try {
      await decryptAttachmentFile(
        encryptedPayload,
        identityC.e2eePrivateKey,
        identityA.e2eePublicKey,
        connectionId,
        userA.agentId
      );
    } catch (err: any) {
      attackerDecryptionFailed = err?.code === 'AUTHENTICATION_TAG_FAILED' || err?.message?.includes('tag verification failed');
    }

    recordResult('property_5_unauthorized_party_rejected', 
      attackerForbidden && attackerDecryptionFailed,
      'Unauthorized caller received HTTP 403 on API. Local decryption with unauthorized key failed AUTHENTICATION_TAG_FAILED.');

    // -------------------------------------------------------------------------
    // Property 6: Tampered ciphertext or AAD fails AES-256-GCM verification
    // -------------------------------------------------------------------------
    // Mutate 1 character of ciphertext
    const tamperedCiphertext = 
      encryptedPayload.ciphertext.charAt(0) === 'A' 
        ? 'B' + encryptedPayload.ciphertext.slice(1) 
        : 'A' + encryptedPayload.ciphertext.slice(1);

    let tamperingDetected = false;
    try {
      await decryptAttachmentFile(
        {
          ...encryptedPayload,
          ciphertext: tamperedCiphertext
        },
        identityB.e2eePrivateKey,
        identityA.e2eePublicKey,
        connectionId,
        userA.agentId
      );
    } catch (err: any) {
      tamperingDetected = err?.code === 'AUTHENTICATION_TAG_FAILED' || err?.message?.includes('tag verification failed');
    }

    // Mutate AAD: different sender agent ID
    let aadTamperingDetected = false;
    try {
      await decryptAttachmentFile(
        encryptedPayload,
        identityB.e2eePrivateKey,
        identityA.e2eePublicKey,
        connectionId,
        'IMPOSTOR_AGENT_ID'
      );
    } catch (err: any) {
      aadTamperingDetected = err?.code === 'AUTHENTICATION_TAG_FAILED' || err?.message?.includes('tag verification failed');
    }

    recordResult('property_6_tampered_ciphertext_fails_aes_gcm', 
      tamperingDetected && aadTamperingDetected,
      'Tampered ciphertext and altered AAD both triggered AUTHENTICATION_TAG_FAILED without fallback.');

    // -------------------------------------------------------------------------
    // Property 7: Key rotation & key epochs work with epoch-specific keys
    // -------------------------------------------------------------------------
    // Rotate User B's identity to Epoch 2
    const identityB_Epoch2 = await rotateAgentCryptoIdentity(
      userB.agentId,
      identityB.identityPrivateKey,
      identityB.identityPublicKey,
      1
    );

    // Encrypt a new file under Epoch 2
    const epoch2FileStr = 'EPOCH_2_ROTATED_KEY_ATTACHMENT_CONTENT';
    const epoch2Bytes = new TextEncoder().encode(epoch2FileStr);
    const encryptedEpoch2Payload = await encryptAttachmentFile(
      {
        name: 'epoch2_rotated.txt',
        type: 'text/plain',
        size: epoch2Bytes.byteLength,
        data: epoch2Bytes
      },
      identityA.e2eePrivateKey,
      identityB_Epoch2.e2eePublicKey,
      connectionId,
      userA.agentId,
      2
    );

    // Decrypt Epoch 2 file using Epoch 2 key
    const decryptedEpoch2 = await decryptAttachmentFile(
      encryptedEpoch2Payload,
      identityB_Epoch2.e2eePrivateKey,
      identityA.e2eePublicKey,
      connectionId,
      userA.agentId
    );

    // Decrypt historical Epoch 1 file using historical Epoch 1 key
    const decryptedEpoch1Historical = await decryptAttachmentFile(
      encryptedPayload,
      identityB.e2eePrivateKey,
      identityA.e2eePublicKey,
      connectionId,
      userA.agentId
    );

    // Decrypt Epoch 2 file with outdated Epoch 1 key MUST fail
    let epochMismatchFailed = false;
    try {
      await decryptAttachmentFile(
        encryptedEpoch2Payload,
        identityB.e2eePrivateKey, // Wrong epoch key!
        identityA.e2eePublicKey,
        connectionId,
        userA.agentId
      );
    } catch {
      epochMismatchFailed = true;
    }

    const epochIntegrityValid = 
      new TextDecoder().decode(decryptedEpoch2.data) === epoch2FileStr &&
      new TextDecoder().decode(decryptedEpoch1Historical.data) === secretContentStr &&
      epochMismatchFailed;

    recordResult('property_7_key_rotation_and_epochs', epochIntegrityValid,
      'Key rotation preserved. Historical epoch 1 files decrypt with epoch 1 keys, epoch 2 with rotated keys, cross-epoch fails.');

    // -------------------------------------------------------------------------
    // Property 8: Standard text messaging remains unaffected
    // -------------------------------------------------------------------------
    const textMsg = 'Standard E2EE text message remains 100% operational';
    const encryptedText = await encryptMessage(
      textMsg,
      identityA.e2eePrivateKey,
      identityB.e2eePublicKey,
      connectionId,
      userA.agentId,
      1
    );

    const sendMsgRes = await helperFetch(`/api/connections/${connectionId}/messages`, {
      method: 'POST',
      headers: { Cookie: cookieA },
      body: JSON.stringify({
        ciphertext: encryptedText.ciphertext,
        nonce: encryptedText.nonce,
        version: encryptedText.version,
        keyEpoch: encryptedText.keyEpoch
      })
    });

    const sendMsgSuccess = sendMsgRes.status === 200 || sendMsgRes.status === 201;

    // Fetch messages as User B and decrypt
    const getMsgsRes = await helperFetch(`/api/connections/${connectionId}/messages`, {
      method: 'GET',
      headers: { Cookie: cookieB }
    });

    const msgsList = getMsgsRes.json?.data || getMsgsRes.json;
    const targetMsg = Array.isArray(msgsList) && msgsList.find((m: any) => m.nonce === encryptedText.nonce);

    let decryptedMsgText: string | null = null;
    if (targetMsg) {
      decryptedMsgText = await decryptMessage(
        {
          ciphertext: targetMsg.ciphertext,
          nonce: targetMsg.nonce,
          version: targetMsg.version,
          keyEpoch: targetMsg.keyEpoch
        },
        identityB.e2eePrivateKey,
        identityA.e2eePublicKey,
        connectionId,
        userA.agentId
      );
    }

    recordResult('property_8_standard_text_messaging_unaffected', 
      sendMsgSuccess && decryptedMsgText === textMsg,
      'Standard text E2EE messaging operates cleanly alongside encrypted attachments.');

  } catch (err: any) {
    console.error('Fatal error in serverBlindE2EEAttachmentTests:', err);
    recordResult('suite_execution', false, err?.message || String(err));
  } finally {
    server.close();
  }

  const allPassed = Object.values(results).every(r => r.status === 'PASSED');
  console.log(`\n=== SERVER-BLIND E2EE ATTACHMENT SUITE RESULT: ${allPassed ? 'ALL PASSED' : 'FAILURES DETECTED'} ===\n`);

  return results;
}

if (process.argv[1] && process.argv[1].includes('serverBlindE2EEAttachmentTests')) {
  runServerBlindE2EEAttachmentTests().then((res) => {
    const failed = Object.values(res).some(r => r.status === 'FAILED');
    process.exit(failed ? 1 : 0);
  }).catch((e) => {
    console.error('Test execution error:', e);
    process.exit(1);
  });
}
