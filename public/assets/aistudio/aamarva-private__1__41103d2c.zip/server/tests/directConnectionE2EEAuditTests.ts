/**
 * DIRECT CONNECTION MESSAGE DECRYPTION E2EE AUDIT & ACCEPTANCE TEST SUITE
 * 
 * Verifies the 8 critical criteria:
 * 1. A sender can send an encrypted message (WebCrypto AES-256-GCM + P-256 ECDH + HKDF).
 * 2. The backend cannot decrypt it (zero-knowledge verification: server stores & forwards only Base64 ciphertext/nonce).
 * 3. The recipient successfully decrypts it (Base64 decode -> WebCrypto AES-GCM decrypt -> plaintext).
 * 4. Modified ciphertext fails authentication (AES-GCM 128-bit tag check fails).
 * 5. Incorrect nonce fails authentication.
 * 6. Incorrect encryption key fails authentication.
 * 7. Messages survive serialization, database persistence and retrieval without corruption.
 * 8. Existing encrypted messages remain compatible across AAD candidates.
 */

import http from 'http';
import { createApp } from '../../server.js';
import { registerUser, createHumanSession } from '../authService.js';
import { establishDirectConnection } from '../services/connectionService.js';
import { getSupabaseClient } from '../supabase.js';
import {
  generateAgentCryptoIdentity,
  encryptMessage,
  decryptMessage,
  base64ToBuffer,
  bufferToBase64,
  E2EEDecryptionError
} from '../../src/lib/e2ee.js';

export async function runDirectConnectionE2EEAuditTests(): Promise<Record<string, { status: 'PASSED' | 'FAILED'; reason?: string }>> {
  console.log('\n======================================================================');
  console.log('       AAMARVA DIRECT CONNECTION E2EE AUDIT & VERIFICATION SUITE       ');
  console.log('======================================================================\n');

  const results: Record<string, { status: 'PASSED' | 'FAILED'; reason?: string }> = {};

  const recordResult = (id: string, success: boolean, reason?: string) => {
    results[id] = { status: success ? 'PASSED' : 'FAILED', reason };
    console.log(`[${success ? 'PASSED' : 'FAILED'}] ${id}${reason ? `: ${reason}` : ''}`);
  };

  process.env.VERCEL = '1';
  const app = await createApp();
  const server = http.createServer(app);
  await new Promise<void>((resolve) => server.listen(0, resolve));
  const port = (server.address() as any).port;
  const baseUrl = `http://127.0.0.1:${port}`;

  const helperFetch = async (endpoint: string, options: any = {}) => {
    const res = await fetch(`${baseUrl}${endpoint}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(options.headers || {})
      }
    });
    const text = await res.text();
    let json: any = null;
    try {
      json = JSON.parse(text);
    } catch {}
    return { status: res.status, json, text };
  };

  const ts = Date.now();

  try {
    // 1. Setup Identities for Alice (Sender) and Bob (Recipient)
    const emailA = `audit_alice_${ts}@aamarva.test`;
    const emailB = `audit_bob_${ts}@aamarva.test`;
    const emailEve = `audit_eve_${ts}@aamarva.test`;

    const regA = await registerUser({ email: emailA, password: 'Password123!', agentName: 'Alice Pioneer' });
    const regB = await registerUser({ email: emailB, password: 'Password123!', agentName: 'Bob Pioneer' });
    const regEve = await registerUser({ email: emailEve, password: 'Password123!', agentName: 'Eve Attacker' });

    const sessionA = await createHumanSession(regA.user.id);
    const sessionB = await createHumanSession(regB.user.id);
    const sessionEve = await createHumanSession(regEve.user.id);

    const cookieA = `aamarva_human_session=${sessionA}; auth_token=${sessionA}; aamarva_session=${sessionA}`;
    const cookieB = `aamarva_human_session=${sessionB}; auth_token=${sessionB}; aamarva_session=${sessionB}`;
    const cookieEve = `aamarva_human_session=${sessionEve}; auth_token=${sessionEve}; aamarva_session=${sessionEve}`;

    const identA = await generateAgentCryptoIdentity(regA.user.agentId);
    const identB = await generateAgentCryptoIdentity(regB.user.agentId);
    const identEve = await generateAgentCryptoIdentity(regEve.user.agentId);

    // Register E2EE Public Keys with backend
    await helperFetch('/api/agents/me/e2ee', {
      method: 'PUT',
      headers: { Cookie: cookieA },
      body: JSON.stringify({
        publicKey: identA.e2eePublicKey,
        fingerprint: identA.fingerprint,
        identityKey: identA.identityPublicKey,
        signature: identA.signature,
        keyEpoch: 1
      })
    });

    await helperFetch('/api/agents/me/e2ee', {
      method: 'PUT',
      headers: { Cookie: cookieB },
      body: JSON.stringify({
        publicKey: identB.e2eePublicKey,
        fingerprint: identB.fingerprint,
        identityKey: identB.identityPublicKey,
        signature: identB.signature,
        keyEpoch: 1
      })
    });

    // Establish direct connection between Alice and Bob
    const conn = await establishDirectConnection(regA.user.id, regB.user.id);
    const connectionId = conn.id;

    const originalSecretMessage = 'CONFIDENTIAL: Autonomous agent zero-knowledge coordination payload with unicode 🔐⚡️ and json { "op": "SYNC", "seq": 42 }';

    // -------------------------------------------------------------------------
    // CRITERION 1: A sender can send an encrypted message
    // -------------------------------------------------------------------------
    const encryptedEnvelope = await encryptMessage(
      originalSecretMessage,
      identA.e2eePrivateKey,
      identB.e2eePublicKey,
      connectionId,
      regA.user.agentId,
      1
    );

    const isCiphertextValidBase64 = typeof encryptedEnvelope.ciphertext === 'string' && encryptedEnvelope.ciphertext.length > 0;
    const isNonceValid12Bytes = base64ToBuffer(encryptedEnvelope.nonce).byteLength === 12;

    const sendRes = await helperFetch(`/api/connections/${connectionId}/messages`, {
      method: 'POST',
      headers: { Cookie: cookieA },
      body: JSON.stringify({
        ciphertext: encryptedEnvelope.ciphertext,
        nonce: encryptedEnvelope.nonce,
        version: 1,
        keyEpoch: 1,
        sequence: 1
      })
    });

    const msgId = sendRes.json?.data?.id;
    recordResult(
      'criterion_1_sender_sends_encrypted_message',
      (sendRes.status === 200 || sendRes.status === 201) && Boolean(msgId) && isCiphertextValidBase64 && isNonceValid12Bytes,
      `Encrypted envelope created with AES-256-GCM + ECDH and sent to connection (HTTP ${sendRes.status}, Message ID: ${msgId})`
    );

    // -------------------------------------------------------------------------
    // CRITERION 2: The backend cannot decrypt it (Zero-knowledge verification)
    // -------------------------------------------------------------------------
    const supabase = getSupabaseClient();
    const { data: dbRecords } = await supabase
      .from('messages')
      .select('id, connection_id, sender_user_id, sender_agent_id, content, ciphertext, nonce, version, key_epoch')
      .eq('id', msgId);

    const storedMsg = dbRecords?.[0];
    const serverPayloadStr = JSON.stringify(storedMsg || {});
    const hasPlaintextInDb = serverPayloadStr.includes('CONFIDENTIAL') || serverPayloadStr.includes('Autonomous agent');
    const hasPrivateKeyInDb = serverPayloadStr.includes('"d":') || serverPayloadStr.includes('privateKey');
    const storedCiphertextMatches = storedMsg?.ciphertext === encryptedEnvelope.ciphertext;
    const storedNonceMatches = storedMsg?.nonce === encryptedEnvelope.nonce;

    recordResult(
      'criterion_2_backend_cannot_decrypt_zero_knowledge',
      !hasPlaintextInDb && !hasPrivateKeyInDb && storedCiphertextMatches && storedNonceMatches,
      'Backend holds strictly Base64 ciphertext & nonce; zero plaintext or private keys exposed in storage.'
    );

    // -------------------------------------------------------------------------
    // CRITERION 3: The recipient successfully decrypts it (WebCrypto AES-256-GCM)
    // -------------------------------------------------------------------------
    const getRes = await helperFetch(`/api/connections/${connectionId}/messages`, {
      method: 'GET',
      headers: { Cookie: cookieB }
    });

    const receivedMessages = getRes.json?.data || [];
    const targetMsg = receivedMessages.find((m: any) => m.id === msgId);

    // Verify recipient executes full WebCrypto AES-GCM decryption lifecycle
    const decryptedText = await decryptMessage(
      {
        ciphertext: targetMsg.ciphertext,
        nonce: targetMsg.nonce,
        version: targetMsg.version,
        keyEpoch: targetMsg.keyEpoch
      },
      identB.e2eePrivateKey,
      identA.e2eePublicKey,
      connectionId,
      regA.user.agentId
    );

    recordResult(
      'criterion_3_recipient_successfully_decrypts',
      decryptedText === originalSecretMessage,
      'Recipient successfully deserialized Base64 and verified/decrypted AES-256-GCM ciphertext to exact plaintext.'
    );

    // -------------------------------------------------------------------------
    // CRITERION 4: Modified ciphertext fails authentication (Tag mismatch)
    // -------------------------------------------------------------------------
    let tamperedCiphertextBlocked = false;
    let tamperErrorCode: string | null = null;
    try {
      const rawBuf = base64ToBuffer(targetMsg.ciphertext);
      const u8 = new Uint8Array(rawBuf);
      // Flip a bit in the ciphertext / authentication tag
      u8[u8.length - 1] ^= 0x01;
      const tamperedCiphertext = bufferToBase64(u8.buffer);

      await decryptMessage(
        {
          ciphertext: tamperedCiphertext,
          nonce: targetMsg.nonce,
          version: targetMsg.version,
          keyEpoch: targetMsg.keyEpoch
        },
        identB.e2eePrivateKey,
        identA.e2eePublicKey,
        connectionId,
        regA.user.agentId
      );
    } catch (err: any) {
      tamperedCiphertextBlocked = true;
      tamperErrorCode = err?.code || err?.message;
    }

    recordResult(
      'criterion_4_modified_ciphertext_fails_authentication',
      tamperedCiphertextBlocked && (tamperErrorCode === 'AUTHENTICATION_TAG_FAILED' || String(tamperErrorCode).includes('authentication')),
      `Modified ciphertext failed AES-GCM 128-bit tag verification (${tamperErrorCode}).`
    );

    // -------------------------------------------------------------------------
    // CRITERION 5: Incorrect nonce fails authentication
    // -------------------------------------------------------------------------
    let modifiedNonceBlocked = false;
    let nonceErrorCode: string | null = null;
    try {
      const nonceBuf = base64ToBuffer(targetMsg.nonce);
      const nonceU8 = new Uint8Array(nonceBuf);
      nonceU8[0] ^= 0x55; // Mutate IV
      const modifiedNonce = bufferToBase64(nonceU8.buffer);

      await decryptMessage(
        {
          ciphertext: targetMsg.ciphertext,
          nonce: modifiedNonce,
          version: targetMsg.version,
          keyEpoch: targetMsg.keyEpoch
        },
        identB.e2eePrivateKey,
        identA.e2eePublicKey,
        connectionId,
        regA.user.agentId
      );
    } catch (err: any) {
      modifiedNonceBlocked = true;
      nonceErrorCode = err?.code || err?.message;
    }

    // Also verify wrong-length nonce is rejected
    let badLengthNonceBlocked = false;
    try {
      await decryptMessage(
        {
          ciphertext: targetMsg.ciphertext,
          nonce: bufferToBase64(new Uint8Array(8).buffer), // 8 bytes instead of 12
          version: targetMsg.version,
          keyEpoch: targetMsg.keyEpoch
        },
        identB.e2eePrivateKey,
        identA.e2eePublicKey,
        connectionId,
        regA.user.agentId
      );
    } catch (err: any) {
      if (err?.code === 'INVALID_NONCE') badLengthNonceBlocked = true;
    }

    recordResult(
      'criterion_5_incorrect_nonce_fails_authentication',
      modifiedNonceBlocked && badLengthNonceBlocked,
      'Mutated nonce rejected by AES-GCM tag verification; non-12-byte nonce rejected with INVALID_NONCE.'
    );

    // -------------------------------------------------------------------------
    // CRITERION 6: Incorrect encryption key fails authentication
    // -------------------------------------------------------------------------
    let wrongKeyBlocked = false;
    let wrongKeyErrorCode: string | null = null;
    try {
      // Eve attempts to decrypt Alice's message using Eve's private key
      await decryptMessage(
        {
          ciphertext: targetMsg.ciphertext,
          nonce: targetMsg.nonce,
          version: targetMsg.version,
          keyEpoch: targetMsg.keyEpoch
        },
        identEve.e2eePrivateKey,
        identA.e2eePublicKey,
        connectionId,
        regA.user.agentId
      );
    } catch (err: any) {
      wrongKeyBlocked = true;
      wrongKeyErrorCode = err?.code || err?.message;
    }

    recordResult(
      'criterion_6_incorrect_key_fails_authentication',
      wrongKeyBlocked && (wrongKeyErrorCode === 'AUTHENTICATION_TAG_FAILED' || String(wrongKeyErrorCode).includes('authentication')),
      `Attacker with unauthorized private key strictly blocked by AES-GCM tag check (${wrongKeyErrorCode}).`
    );

    // -------------------------------------------------------------------------
    // CRITERION 7: Messages survive serialization, persistence & retrieval
    // -------------------------------------------------------------------------
    const complexPayload = JSON.stringify({
      title: 'Multilingual & Special Characters Test: 🌟 🚀 汉字 العربية \n\r\t',
      meta: { nested: true, tokens: [1, 2, 3] },
      code: 'console.log("Zero-Knowledge E2EE Verified");'
    });

    const complexEnvelope = await encryptMessage(
      complexPayload,
      identA.e2eePrivateKey,
      identB.e2eePublicKey,
      connectionId,
      regA.user.agentId,
      1
    );

    const postComplexRes = await helperFetch(`/api/connections/${connectionId}/messages`, {
      method: 'POST',
      headers: { Cookie: cookieA },
      body: JSON.stringify({
        ciphertext: complexEnvelope.ciphertext,
        nonce: complexEnvelope.nonce,
        version: 1,
        keyEpoch: 1,
        sequence: 2
      })
    });

    const complexMsgId = postComplexRes.json?.data?.id;

    const getComplexRes = await helperFetch(`/api/connections/${connectionId}/messages`, {
      method: 'GET',
      headers: { Cookie: cookieB }
    });

    const complexMsgFromApi = (getComplexRes.json?.data || []).find((m: any) => m.id === complexMsgId);
    const decryptedComplex = await decryptMessage(
      {
        ciphertext: complexMsgFromApi.ciphertext,
        nonce: complexMsgFromApi.nonce,
        version: complexMsgFromApi.version,
        keyEpoch: complexMsgFromApi.keyEpoch
      },
      identB.e2eePrivateKey,
      identA.e2eePublicKey,
      connectionId,
      regA.user.agentId
    );

    recordResult(
      'criterion_7_serialization_persistence_retrieval_integrity',
      decryptedComplex === complexPayload,
      'Complex multi-line and unicode payloads survived serialization, database persistence, and retrieval without corruption.'
    );

    // -------------------------------------------------------------------------
    // CRITERION 8: Existing encrypted messages remain compatible
    // -------------------------------------------------------------------------
    // Decrypt messages with legacy and canonical AAD candidate variations
    const legacyCompatCheck = await decryptMessage(
      {
        ciphertext: targetMsg.ciphertext,
        nonce: targetMsg.nonce,
        version: 1,
        keyEpoch: 1
      },
      identB.e2eePrivateKey,
      identA.e2eePublicKey,
      connectionId,
      regA.user.agentId.toUpperCase()
    );

    recordResult(
      'criterion_8_existing_messages_remain_compatible',
      legacyCompatCheck === originalSecretMessage,
      'Legacy and case-variant AAD bindings decrypt successfully preserving full backward compatibility.'
    );

  } catch (fatalErr: any) {
    console.error('Fatal Direct Connection E2EE Audit Error:', fatalErr);
    recordResult('direct_e2ee_audit_fatal', false, fatalErr?.message || String(fatalErr));
  } finally {
    server.close();
  }

  const allPassed = Object.values(results).every(r => r.status === 'PASSED');
  console.log(`\n======================================================================`);
  console.log(` DIRECT CONNECTION E2EE AUDIT SUMMARY: ${allPassed ? 'ALL PASSED (8/8)' : 'FAILURES DETECTED'}`);
  console.log(`======================================================================\n`);

  return results;
}

if (process.argv[1]?.endsWith('directConnectionE2EEAuditTests.ts')) {
  runDirectConnectionE2EEAuditTests()
    .then(res => {
      const allOk = Object.values(res).every(r => r.status === 'PASSED');
      process.exit(allOk ? 0 : 1);
    })
    .catch(err => {
      console.error('Audit runner error:', err);
      process.exit(1);
    });
}
