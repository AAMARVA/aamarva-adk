import { getSupabaseClient } from '../supabase.js';
import { CapabilityService } from '../services/capabilityService.js';
import { normalizeUserRecord } from '../authService.js';

export async function runSlaveDeploymentUncappedPlanTests() {
  console.log('================================================================');
  console.log('🧪 RUNNING SLAVE DEPLOYMENT UNCAPPED CAPABILITY ZERO-REGRESSION TESTS');
  console.log('================================================================');

  const sb = getSupabaseClient();
  const capService = CapabilityService.getInstance();

  let passedTests = 0;
  let totalTests = 0;

  function assert(condition: boolean, testName: string) {
    totalTests++;
    if (condition) {
      console.log(`  ✓ PASS: ${testName}`);
      passedTests++;
    } else {
      console.error(`  ✗ FAIL: ${testName}`);
      throw new Error(`Test failed: ${testName}`);
    }
  }

  const testMasterId = crypto.randomUUID();
  const testNewSlaveId = crypto.randomUUID();
  const testPurchasedSlaveId = crypto.randomUUID();

  // 1. Insert Master and newly deployed Slave without any capability plan
  await sb.from('users').insert([
    {
      id: testMasterId,
      agentId: 'AMR-MSTR-' + testMasterId.substring(0, 6),
      name: 'Test Master Zero Cap',
      email: `mzero-${testMasterId.substring(0, 8)}@aamarva.net`,
      account_type: 'master',
      role: 'master',
      is_master_primary: true,
      status: 'active',
      createdAt: new Date().toISOString()
    },
    {
      id: testNewSlaveId,
      agentId: 'AMR-SLV-' + testNewSlaveId.substring(0, 6),
      name: 'Freshly Deployed Slave',
      email: `mzero-${testMasterId.substring(0, 8)}+fresh@aamarva.net`,
      account_type: 'slave',
      role: 'slave',
      is_slave: true,
      is_master_primary: false,
      master_id: testMasterId,
      status: 'active',
      createdAt: new Date().toISOString()
    },
    {
      id: testPurchasedSlaveId,
      agentId: 'AMR-SLV-' + testPurchasedSlaveId.substring(0, 6),
      name: 'Purchased Slave Node',
      email: `mzero-${testMasterId.substring(0, 8)}+pur@aamarva.net`,
      account_type: 'slave',
      role: 'slave',
      is_slave: true,
      is_master_primary: false,
      master_id: testMasterId,
      status: 'active',
      createdAt: new Date().toISOString()
    }
  ]);

  // Test 1: Freshly deployed slave has no active capability entitlement in capabilityService
  const freshCap = await capService.getAgentCapability(testNewSlaveId);
  assert(freshCap === null, 'Freshly deployed slave returns null for capability entitlement');

  const isFreshActive = await capService.isAgentCapabilityActive(testNewSlaveId);
  assert(isFreshActive === false, 'Freshly deployed slave is NOT active for capability increment');

  // Test 2: normalizeUserRecord on freshly deployed slave evaluates hasCapabilityIncrement and isCapped to false
  const { data: freshUserRaw } = await sb.from('users').select('*').eq('id', testNewSlaveId).maybeSingle();
  const normalizedFresh = normalizeUserRecord(freshUserRaw);
  assert(normalizedFresh.hasCapabilityIncrement === false, 'Freshly deployed slave normalizeUserRecord hasCapabilityIncrement is false');
  assert(normalizedFresh.isCapped === false, 'Freshly deployed slave normalizeUserRecord isCapped is false');
  assert(!normalizedFresh.expires_at, 'Freshly deployed slave normalizeUserRecord expires_at is undefined/null');

  // Test 3: Master accounts can never have capability increment
  const { data: masterRaw } = await sb.from('users').select('*').eq('id', testMasterId).maybeSingle();
  const normalizedMaster = normalizeUserRecord(masterRaw);
  assert(normalizedMaster.hasCapabilityIncrement === false, 'Master normalizeUserRecord hasCapabilityIncrement is always false');
  assert(normalizedMaster.isCapped === false, 'Master normalizeUserRecord isCapped is always false');

  // Test 4: Explicit purchase activates capability strictly for the target slave
  const activated = await capService.activateSlaveCapability(testMasterId, testPurchasedSlaveId, { validityDays: 30 });
  assert(Boolean(activated && activated.status === 'active'), 'Explicit purchase activates capability entitlement');
  assert(new Date(activated.expires_at).getTime() > Date.now(), 'Activated capability expires in future');

  // Test 5: Purchased slave now has active capability, but fresh slave STILL has none
  const purchasedCap = await capService.getAgentCapability(testPurchasedSlaveId);
  assert(Boolean(purchasedCap && purchasedCap.status === 'active'), 'Purchased slave has active entitlement');

  const freshCapAfterOtherPurchase = await capService.getAgentCapability(testNewSlaveId);
  assert(freshCapAfterOtherPurchase === null, 'Fresh slave still has NO capability after another slave purchased a plan');

  const isFreshActiveAfter = await capService.isAgentCapabilityActive(testNewSlaveId);
  assert(isFreshActiveAfter === false, 'Fresh slave remains completely uncapped after another slave purchased');

  console.log(`\n🎉 All ${passedTests}/${totalTests} Slave Deployment Uncapped Plan tests passed!`);
  return { passed: true, count: totalTests };
}
