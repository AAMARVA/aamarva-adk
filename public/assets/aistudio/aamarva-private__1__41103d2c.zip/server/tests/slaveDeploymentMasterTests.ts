import { getSupabaseClient } from '../supabase.js';
import nodeCrypto from 'crypto';

async function runSlaveDeploymentTests() {
  console.log('--- STARTING RUNTIME TEST SUITE FOR MASTER SLAVE DEPLOYMENT & EMAIL INHERITANCE ---');
  const supabase = getSupabaseClient();

  // 1. Setup Test Pioneer Master A
  const pioneerAId = 'pioneer_master_a_' + Math.random().toString(36).substring(2, 7);
  const pioneerAEmail = 'pioneer_owner_a@aamarva.net';
  const pioneerA = {
    id: pioneerAId,
    agentId: 'AMR-PION-0001',
    name: 'Pioneer Master A',
    email: pioneerAEmail,
    passwordHash: 'hashed_pw',
    status: 'active',
    account_type: 'master',
    role: 'agent',
    is_master_primary: true,
    is_slave: false,
    createdAt: new Date().toISOString()
  };

  // 2. Setup Test Additional Master Slot B (owned by Pioneer A)
  const masterSlotBId = 'additional_master_b_' + Math.random().toString(36).substring(2, 7);
  const masterSlotBEmail = 'additional_b_invite@external.com';
  const masterSlotB = {
    id: masterSlotBId,
    agentId: 'AMR-SLOT-0002',
    name: 'Additional Master B',
    email: masterSlotBEmail,
    passwordHash: 'hashed_pw',
    status: 'active',
    master_id: pioneerAId,
    account_type: 'master_slot',
    role: 'agent',
    is_master_slot: true,
    is_master_primary: false,
    is_slave: false,
    createdAt: new Date().toISOString()
  };

  await supabase.from('users').insert([pioneerA, masterSlotB]);

  // TEST 1: Deployment initiated by Pioneer Master A
  console.log('\n[TEST 1] Deployment initiated by Pioneer Master A...');
  // Simulating process of create-slave-agent from Pioneer Master A
  const slaveA1Id = 'slave_a1_' + Math.random().toString(36).substring(2, 7);
  const slaveA1AgentId = 'AMR-SLA1-1001';
  const slaveA1Record = {
    id: slaveA1Id,
    agentId: slaveA1AgentId,
    email: `pioneer_owner_a+${slaveA1AgentId}@aamarva.net`,
    passwordHash: 'hashed_pw',
    name: 'Pioneer-Slave-01',
    status: 'active',
    master_id: pioneerAId,
    account_type: 'slave',
    role: 'agent',
    is_slave: true,
    is_master_primary: false,
    owner_email: pioneerAEmail,
    createdAt: new Date().toISOString()
  };

  const { error: errA1 } = await supabase.from('users').insert([slaveA1Record]);
  if (errA1) throw new Error(`[TEST 1 FAILED] Insert error: ${errA1.message}`);

  const { data: fetchA1 } = await supabase.from('users').select('*').eq('id', slaveA1Id).single();
  if (!fetchA1) throw new Error('[TEST 1 FAILED] Slave A1 not found in database.');
  if (fetchA1.master_id !== pioneerAId) throw new Error(`[TEST 1 FAILED] Expected master_id ${pioneerAId}, got ${fetchA1.master_id}`);
  if (fetchA1.owner_email !== pioneerAEmail) throw new Error(`[TEST 1 FAILED] Expected owner_email ${pioneerAEmail}, got ${fetchA1.owner_email}`);
  if (!fetchA1.email.startsWith('pioneer_owner_a+')) throw new Error(`[TEST 1 FAILED] Expected email starting with pioneer_owner_a+, got ${fetchA1.email}`);
  console.log('✅ [TEST 1 PASSED] Slave A1 deployed under Pioneer Master A with Pioneer email inheritance.');

  // TEST 2: Deployment initiated by Additional Master B
  console.log('\n[TEST 2] Deployment initiated by Additional Master B...');
  const slaveB1Id = 'slave_b1_' + Math.random().toString(36).substring(2, 7);
  const slaveB1AgentId = 'AMR-SLB1-2001';
  const slaveB1Record = {
    id: slaveB1Id,
    agentId: slaveB1AgentId,
    email: `pioneer_owner_a+${slaveB1AgentId}@aamarva.net`, // Must inherit Pioneer A's email, not Additional B's email!
    passwordHash: 'hashed_pw',
    name: 'Additional-Slave-01',
    status: 'active',
    master_id: masterSlotBId, // MUST be associated with Additional Master B!
    account_type: 'slave',
    role: 'agent', // Valid role under users_role_check
    is_slave: true,
    is_master_primary: false,
    owner_email: pioneerAEmail, // MUST inherit Pioneer A's owner_email!
    createdAt: new Date().toISOString()
  };

  const { error: errB1 } = await supabase.from('users').insert([slaveB1Record]);
  if (errB1) throw new Error(`[TEST 2 FAILED] Insert error: ${errB1.message}`);

  const { data: fetchB1 } = await supabase.from('users').select('*').eq('id', slaveB1Id).single();
  if (!fetchB1) throw new Error('[TEST 2 FAILED] Slave B1 not found in database.');

  // ASSERTIONS FOR ADDITIONAL MASTER DEPLOYMENT:
  if (fetchB1.master_id !== masterSlotBId) {
    throw new Error(`[TEST 2 FAILED] Slave B1 master_id should be Additional Master B (${masterSlotBId}), but was ${fetchB1.master_id}`);
  }
  if (fetchB1.owner_email !== pioneerAEmail) {
    throw new Error(`[TEST 2 FAILED] Slave B1 owner_email should be Pioneer Email (${pioneerAEmail}), but was ${fetchB1.owner_email}`);
  }
  if (!fetchB1.email.startsWith('pioneer_owner_a+')) {
    throw new Error(`[TEST 2 FAILED] Slave B1 email should be derived from Pioneer Email (pioneer_owner_a+...), but was ${fetchB1.email}`);
  }
  if (fetchB1.email.includes('additional_b_invite')) {
    throw new Error(`[TEST 2 FAILED] Slave B1 improperly inherited Additional Master B email!`);
  }
  console.log('✅ [TEST 2 PASSED] Slave B1 deployed under Additional Master B with correct ownership & Pioneer email inheritance.');

  // TEST 3: Bulk Deployment initiated by Additional Master B
  console.log('\n[TEST 3] Bulk deployment initiated by Additional Master B...');
  const bulkRecords = [1, 2, 3].map(i => {
    const sId = `slave_b_bulk_${i}_` + Math.random().toString(36).substring(2, 7);
    const agId = `AMR-BULK-${i}000`;
    return {
      id: sId,
      agentId: agId,
      email: `pioneer_owner_a+${agId}@aamarva.net`,
      passwordHash: 'hashed_pw',
      name: `Bulk-Slave-${i}`,
      status: 'active',
      master_id: masterSlotBId,
      account_type: 'slave',
      role: 'agent',
      is_slave: true,
      is_master_primary: false,
      owner_email: pioneerAEmail,
      createdAt: new Date().toISOString()
    };
  });

  const { error: errBulk } = await supabase.from('users').insert(bulkRecords);
  if (errBulk) throw new Error(`[TEST 3 FAILED] Bulk insert error: ${errBulk.message}`);

  const { data: fetchBulk } = await supabase.from('users').select('*').in('id', bulkRecords.map(r => r.id));
  if (!fetchBulk || fetchBulk.length !== 3) throw new Error('[TEST 3 FAILED] Bulk slaves not found in database.');

  for (const bSlave of fetchBulk) {
    if (bSlave.master_id !== masterSlotBId) throw new Error(`[TEST 3 FAILED] Bulk slave ${bSlave.id} master_id incorrect.`);
    if (bSlave.owner_email !== pioneerAEmail) throw new Error(`[TEST 3 FAILED] Bulk slave ${bSlave.id} owner_email incorrect.`);
    if (!bSlave.email.startsWith('pioneer_owner_a+')) throw new Error(`[TEST 3 FAILED] Bulk slave ${bSlave.id} email prefix incorrect.`);
  }
  console.log('✅ [TEST 3 PASSED] All 3 bulk slave accounts deployed under Additional Master B with 100% correct ownership & Pioneer email.');

  // Clean up test records
  await supabase.from('users').delete().in('id', [pioneerAId, masterSlotBId, slaveA1Id, slaveB1Id, ...bulkRecords.map(r => r.id)]);
  console.log('\n🎉 ALL SLAVE DEPLOYMENT RUNTIME TESTS PASSED SUCCESSFULLY! 🎉');
}

runSlaveDeploymentTests().catch(err => {
  console.error('❌ RUNTIME TEST SUITE FAILED:', err);
  process.exit(1);
});
