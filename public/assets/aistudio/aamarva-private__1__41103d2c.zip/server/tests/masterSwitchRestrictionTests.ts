import express from 'express';
import http from 'http';
import cookieParser from 'cookie-parser';
import aamarvaRouter from '../routes/aamarvaRoutes.js';
import { getSupabaseClient } from '../supabase.js';
import { registerUser, createHumanSession } from '../authService.js';

async function runTests() {
  console.log('--- STARTING RUNTIME TEST SUITE FOR MASTER/SLAVE SWITCHING (TESTS A - H) ---');
  const app = express();
  app.use(cookieParser());
  app.use(express.json());
  app.use('/api', aamarvaRouter);

  const server = http.createServer(app);
  await new Promise<void>((resolve) => server.listen(0, resolve));
  const port = (server.address() as any).port;
  const baseUrl = `http://127.0.0.1:${port}`;

  const supabase = getSupabaseClient();
  const ts = Date.now();

  // 1. Setup Pioneer Master A
  const regA = await registerUser({
    email: `pioneer_a_${ts}@aamarva.test`,
    password: 'Password123!',
    agentName: 'Pioneer Master A'
  });
  const masterA = regA.user;
  await supabase.from('users').update({ is_master_primary: true, account_type: 'master', role: 'master' }).eq('id', masterA.id);

  // 2. Setup Slave A1 belonging to Master A
  const slaveA1Id = `slave_a1_${ts}`;
  const slaveA1AgentId = `AMR-SLA1-${ts.toString().slice(-4)}`;
  await supabase.from('users').insert({
    id: slaveA1Id,
    agentId: slaveA1AgentId,
    name: 'Slave A1 Node',
    email: `pioneer_a_${ts}+${slaveA1AgentId}@aamarva.test`,
    role: 'slave',
    account_type: 'slave',
    is_slave: true,
    is_master_primary: false,
    is_master_slot: false,
    master_id: masterA.id,
    status: 'active',
    whitelisted_networks: ['0.0.0.0/0', '::/0']
  });

  // 3. Setup Slave A2 belonging to Master A
  const slaveA2Id = `slave_a2_${ts}`;
  const slaveA2AgentId = `AMR-SLA2-${ts.toString().slice(-4)}`;
  await supabase.from('users').insert({
    id: slaveA2Id,
    agentId: slaveA2AgentId,
    name: 'Slave A2 Node',
    email: `pioneer_a_${ts}+${slaveA2AgentId}@aamarva.test`,
    role: 'slave',
    account_type: 'slave',
    is_slave: true,
    is_master_primary: false,
    is_master_slot: false,
    master_id: masterA.id,
    status: 'active',
    whitelisted_networks: ['0.0.0.0/0', '::/0']
  });

  // 4. Setup Slave A3 belonging to Master A
  const slaveA3Id = `slave_a3_${ts}`;
  const slaveA3AgentId = `AMR-SLA3-${ts.toString().slice(-4)}`;
  await supabase.from('users').insert({
    id: slaveA3Id,
    agentId: slaveA3AgentId,
    name: 'Slave A3 Node',
    email: `pioneer_a_${ts}+${slaveA3AgentId}@aamarva.test`,
    role: 'slave',
    account_type: 'slave',
    is_slave: true,
    is_master_primary: false,
    is_master_slot: false,
    master_id: masterA.id,
    status: 'active',
    whitelisted_networks: ['0.0.0.0/0', '::/0']
  });

  // 5. Setup Master B (unrelated external master)
  const regB = await registerUser({
    email: `pioneer_b_${ts}@aamarva.test`,
    password: 'Password123!',
    agentName: 'Master B'
  });
  const masterB = regB.user;
  await supabase.from('users').update({ is_master_primary: true, account_type: 'master', role: 'master' }).eq('id', masterB.id);

  // 6. Setup Slave B1 belonging to Master B
  const slaveB1Id = `slave_b1_${ts}`;
  const slaveB1AgentId = `AMR-SLB1-${ts.toString().slice(-4)}`;
  await supabase.from('users').insert({
    id: slaveB1Id,
    agentId: slaveB1AgentId,
    name: 'Slave B1 Node',
    email: `pioneer_b_${ts}+${slaveB1AgentId}@aamarva.test`,
    role: 'slave',
    account_type: 'slave',
    is_slave: true,
    is_master_primary: false,
    is_master_slot: false,
    master_id: masterB.id,
    status: 'active',
    whitelisted_networks: ['0.0.0.0/0', '::/0']
  });

  console.log('\n--- EXECUTING SPECIFIED RUNTIME TESTS (A - H) ---');

  // TEST A: Master A -> Slave A1. Expected: ALLOW.
  console.log('\n[TEST A] Master A -> Slave A1 (Master-to-Slave)');
  const sessionMasterA = await createHumanSession(masterA.id);
  const resA = await fetch(`${baseUrl}/api/auth/master/switch`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Cookie': `aamarva_human_session=${sessionMasterA}`
    },
    body: JSON.stringify({ targetAgentId: slaveA1Id })
  });
  const bodyA = await resA.json();
  const tokenA1 = resA.headers.get('set-cookie')?.match(/aamarva_human_session=([^;]+)/)?.[1] || bodyA.data?.token;
  if (resA.status === 200 && bodyA.success && bodyA.data?.returnMasterId === masterA.id) {
    console.log(`✅ [PASSED] Master A -> Slave A1 succeeded. returnMasterId=${bodyA.data.returnMasterId}`);
  } else {
    throw new Error(`TEST A FAILED: Expected 200 with returnMasterId=${masterA.id}, got ${resA.status}: ${JSON.stringify(bodyA)}`);
  }

  // TEST B: Slave A1 -> Slave A2 under Master A. Expected: ALLOW.
  console.log('\n[TEST B] Slave A1 -> Slave A2 under Master A (Same-Master Slave-to-Slave)');
  const resB = await fetch(`${baseUrl}/api/auth/master/switch`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Cookie': `aamarva_human_session=${tokenA1}`
    },
    body: JSON.stringify({ targetAgentId: slaveA2Id })
  });
  const bodyB = await resB.json();
  const tokenA2 = resB.headers.get('set-cookie')?.match(/aamarva_human_session=([^;]+)/)?.[1] || bodyB.data?.token;
  if (resB.status === 200 && bodyB.success && bodyB.data?.returnMasterId === masterA.id) {
    console.log(`✅ [PASSED] Slave A1 -> Slave A2 succeeded. Originating returnMasterId preserved: ${bodyB.data.returnMasterId}`);
  } else {
    throw new Error(`TEST B FAILED: Expected 200 with returnMasterId=${masterA.id}, got ${resB.status}: ${JSON.stringify(bodyB)}`);
  }

  // TEST C: Slave A2 -> Slave A3 under Master A. Expected: ALLOW.
  console.log('\n[TEST C] Slave A2 -> Slave A3 under Master A (Same-Master Slave-to-Slave Hop 2)');
  const resC = await fetch(`${baseUrl}/api/auth/master/switch`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Cookie': `aamarva_human_session=${tokenA2}`
    },
    body: JSON.stringify({ targetAgentId: slaveA3Id })
  });
  const bodyC = await resC.json();
  const tokenA3 = resC.headers.get('set-cookie')?.match(/aamarva_human_session=([^;]+)/)?.[1] || bodyC.data?.token;
  if (resC.status === 200 && bodyC.success && bodyC.data?.returnMasterId === masterA.id) {
    console.log(`✅ [PASSED] Slave A2 -> Slave A3 succeeded. Originating returnMasterId preserved: ${bodyC.data.returnMasterId}`);
  } else {
    throw new Error(`TEST C FAILED: Expected 200 with returnMasterId=${masterA.id}, got ${resC.status}: ${JSON.stringify(bodyC)}`);
  }

  // TEST D: Slave A3 -> Master A. Expected: ALLOW.
  console.log('\n[TEST D] Slave A3 -> Master A (Return to Originating Master)');
  const resD = await fetch(`${baseUrl}/api/auth/master/switch`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Cookie': `aamarva_human_session=${tokenA3}`
    },
    body: JSON.stringify({ targetAgentId: masterA.id })
  });
  const bodyD = await resD.json();
  if (resD.status === 200 && bodyD.success && bodyD.data?.returnMasterId === null) {
    console.log(`✅ [PASSED] Slave A3 successfully returned to Master A. returnMasterId cleared.`);
  } else {
    throw new Error(`TEST D FAILED: Expected 200 with returnMasterId=null, got ${resD.status}: ${JSON.stringify(bodyD)}`);
  }

  // TEST E: Slave A1 -> Slave B1 under Master B. Expected: BLOCK.
  console.log('\n[TEST E] Slave A1 -> Slave B1 under Master B (Cross-Master Slave Switch Blocked)');
  const resE = await fetch(`${baseUrl}/api/auth/master/switch`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Cookie': `aamarva_human_session=${tokenA1}`
    },
    body: JSON.stringify({ targetAgentId: slaveB1Id })
  });
  const bodyE = await resE.json();
  if (resE.status === 403 && bodyE.error?.code === 'UNAUTHORIZED_SLAVE_SWITCH') {
    console.log(`✅ [PASSED] Cross-master slave switch correctly blocked with 403 UNAUTHORIZED_SLAVE_SWITCH`);
  } else {
    throw new Error(`TEST E FAILED: Expected 403 UNAUTHORIZED_SLAVE_SWITCH, got ${resE.status}: ${JSON.stringify(bodyE)}`);
  }

  // TEST F: Master A -> Master B. Expected: BLOCK.
  console.log('\n[TEST F] Master A -> Master B (Master-to-Master Blocked)');
  const resF = await fetch(`${baseUrl}/api/auth/master/switch`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Cookie': `aamarva_human_session=${sessionMasterA}`
    },
    body: JSON.stringify({ targetAgentId: masterB.id })
  });
  const bodyF = await resF.json();
  if (resF.status === 403 && bodyF.error?.code === 'MASTER_TO_MASTER_SWITCH_PROHIBITED') {
    console.log(`✅ [PASSED] Master A -> Master B switch correctly blocked with 403 MASTER_TO_MASTER_SWITCH_PROHIBITED`);
  } else {
    throw new Error(`TEST F FAILED: Expected 403 MASTER_TO_MASTER_SWITCH_PROHIBITED, got ${resF.status}: ${JSON.stringify(bodyF)}`);
  }

  // TEST G: Switch between three slaves (A1 -> A2 -> A3), refresh browser, and verify Master A remains return destination
  console.log('\n[TEST G] Multi-slave chain & Refresh Persistence (A1 -> A2 -> A3 -> Refresh)');
  const resGAccounts = await fetch(`${baseUrl}/api/auth/master/accounts`, {
    headers: {
      'Cookie': `aamarva_human_session=${tokenA3}`
    }
  });
  const bodyGAccounts = await resGAccounts.json();
  if (resGAccounts.status === 200 && bodyGAccounts.data?.activeAgentId === slaveA3Id && bodyGAccounts.data?.returnMasterId === masterA.id) {
    console.log(`✅ [PASSED] Refresh persistence verified! Active=${bodyGAccounts.data.activeAgentId}, returnMasterId=${bodyGAccounts.data.returnMasterId}`);
  } else {
    throw new Error(`TEST G FAILED: Expected active=${slaveA3Id} and returnMasterId=${masterA.id}, got ${resGAccounts.status}: ${JSON.stringify(bodyGAccounts)}`);
  }

  // TEST H: Browser Isolation
  console.log('\n[TEST H] Separate Browser Profiles & Isolation');
  // Browser 1: Master A -> Slave A2
  const sessionB1MasterA = await createHumanSession(masterA.id);
  const resH1 = await fetch(`${baseUrl}/api/auth/master/switch`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Cookie': `aamarva_human_session=${sessionB1MasterA}`
    },
    body: JSON.stringify({ targetAgentId: slaveA2Id })
  });
  const bodyH1 = await resH1.json();
  const tokenH1 = resH1.headers.get('set-cookie')?.match(/aamarva_human_session=([^;]+)/)?.[1] || bodyH1.data?.token;

  // Browser 2: Master B -> Slave B1
  const sessionB2MasterB = await createHumanSession(masterB.id);
  const resH2 = await fetch(`${baseUrl}/api/auth/master/switch`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Cookie': `aamarva_human_session=${sessionB2MasterB}`
    },
    body: JSON.stringify({ targetAgentId: slaveB1Id })
  });
  const bodyH2 = await resH2.json();
  const tokenH2 = resH2.headers.get('set-cookie')?.match(/aamarva_human_session=([^;]+)/)?.[1] || bodyH2.data?.token;

  // Verify Browser 1 return master is Master A
  const b1Acc = await (await fetch(`${baseUrl}/api/auth/master/accounts`, { headers: { 'Cookie': `aamarva_human_session=${tokenH1}` } })).json();
  // Verify Browser 2 return master is Master B
  const b2Acc = await (await fetch(`${baseUrl}/api/auth/master/accounts`, { headers: { 'Cookie': `aamarva_human_session=${tokenH2}` } })).json();

  if (b1Acc.data?.returnMasterId === masterA.id && b2Acc.data?.returnMasterId === masterB.id) {
    console.log(`✅ [PASSED] Browser 1 returnMasterId=${b1Acc.data.returnMasterId} (Master A)`);
    console.log(`✅ [PASSED] Browser 2 returnMasterId=${b2Acc.data.returnMasterId} (Master B)`);
    console.log(`✅ [PASSED] Independent browser sessions and return contexts maintained with 100% isolation.`);
  } else {
    throw new Error(`TEST H FAILED: Isolation mismatch. B1=${b1Acc.data?.returnMasterId}, B2=${b2Acc.data?.returnMasterId}`);
  }

  // Cleanup test records
  await supabase.from('users').delete().in('id', [slaveA1Id, slaveA2Id, slaveA3Id, slaveB1Id]);
  server.close();

  console.log('\n🎉 ALL RUNTIME TESTS (A - H) PASSED SUCCESSFULLY! 🎉');
  process.exit(0);
}

runTests().catch(err => {
  console.error('\n❌ RUNTIME TEST SUITE FAILED:', err);
  process.exit(1);
});
