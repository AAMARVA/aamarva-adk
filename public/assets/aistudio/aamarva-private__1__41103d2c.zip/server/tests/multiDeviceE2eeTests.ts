import {
  generateAgentCryptoIdentity,
  rotateAgentCryptoIdentity,
  createEncryptedRecoveryVault,
  restoreFromEncryptedRecoveryVault,
  saveLocalKeyPair,
  getLocalKeyPair,
  getAllLocalEpochKeys,
  clearTransientJwkKeys,
  encryptMessage,
  decryptMessage,
  pinPeerKey,
  getPinnedPeerKey,
  resolveSenderPublicKey,
} from '../../src/lib/e2ee.ts';
import {
  generateClusterGroupKey,
  wrapClusterGroupKeyForMember,
  unwrapClusterGroupKeyFromPackage,
  encryptClusterMessage,
  decryptClusterMessage,
} from '../../src/lib/clusterCrypto.ts';

export async function runMultiDeviceE2eeTests() {
  console.log('=== AAMARVA MULTI-DEVICE E2EE (CONNECTIONS & CLUSTERS) REGRESSION TESTS ===\n');
  const results: Record<string, { status: 'PASSED' | 'FAILED'; reason?: string }> = {};

  const recordResult = (id: string, success: boolean, reason?: string) => {
    results[id] = { status: success ? 'PASSED' : 'FAILED', reason };
    console.log(`[${success ? 'PASSED' : 'FAILED'}] Test ${id}${reason ? `: ${reason}` : ''}`);
  };

  const suffix = Date.now();
  const aliceId = `AMR-MD-ALICE-${suffix}`;
  const bobId = `AMR-MD-BOB-${suffix}`;
  const bobCred = 'BobPassphrase#2026';
  const aliceCred = 'AlicePassphrase#2026';

  try {
    // -----------------------------------------------------------------
    // 1. Rotation after clearTransientJwkKeys without decryptable vault
    //    must still allow vault creation with preserveIdentityOnlyIfRecoverable
    // -----------------------------------------------------------------
    const aliceEp1 = await generateAgentCryptoIdentity(aliceId, 1);
    await saveLocalKeyPair(
      aliceId,
      aliceEp1.e2eePublicKey,
      aliceEp1.e2eePrivateKey,
      aliceEp1.fingerprint,
      aliceEp1.identityPublicKey,
      aliceEp1.identityPrivateKey,
      aliceEp1.signature,
      1,
      aliceEp1.transientPrivateKeyJwk,
      aliceEp1.transientIdentityPrivateKeyJwk
    );
    const aliceVault1 = await createEncryptedRecoveryVault(aliceId, aliceCred);
    clearTransientJwkKeys(aliceId);

    const aliceEp2 = await rotateAgentCryptoIdentity(aliceId, 1, {
      existingVault: null,
      credential: aliceCred,
      preserveIdentityOnlyIfRecoverable: true,
    });
    const aliceVault2 = await createEncryptedRecoveryVault(aliceId, aliceCred, undefined, aliceVault1);
    clearTransientJwkKeys(aliceId);

    const restoredAlice = await restoreFromEncryptedRecoveryVault(aliceId, aliceCred, aliceVault2);
    const aliceEpochs = await getAllLocalEpochKeys(aliceId);
    const hasEp1AndEp2 = aliceEpochs.some((e) => e.keyEpoch === 1) && aliceEpochs.some((e) => e.keyEpoch === 2);
    recordResult(
      'rotation_and_vault_preserves_all_epochs',
      Boolean(restoredAlice?.activeKey?.keyEpoch === 2 && hasEp1AndEp2),
      `Restored epoch=${restoredAlice?.activeKey?.keyEpoch}, totalEpochs=${aliceEpochs.length}`
    );

    // -----------------------------------------------------------------
    // 2. Peer key pinning preserves epoch history & keyEpoch across updates
    // -----------------------------------------------------------------
    const bobEp1 = await generateAgentCryptoIdentity(bobId, 1);
    await saveLocalKeyPair(
      bobId,
      bobEp1.e2eePublicKey,
      bobEp1.e2eePrivateKey,
      bobEp1.fingerprint,
      bobEp1.identityPublicKey,
      bobEp1.identityPrivateKey,
      bobEp1.signature,
      1,
      bobEp1.transientPrivateKeyJwk,
      bobEp1.transientIdentityPrivateKeyJwk
    );
    const bobVault1 = await createEncryptedRecoveryVault(bobId, bobCred);
    clearTransientJwkKeys(bobId);

    await pinPeerKey(bobId, bobEp1.e2eePublicKey, bobEp1.identityPublicKey, bobEp1.signature, true, 1);

    const bobEp2 = await rotateAgentCryptoIdentity(bobId, 1, {
      existingVault: bobVault1,
      credential: bobCred,
      preserveIdentityOnlyIfRecoverable: true,
    });
    const bobVault2 = await createEncryptedRecoveryVault(bobId, bobCred, undefined, bobVault1);
    clearTransientJwkKeys(bobId);

    await pinPeerKey(bobId, bobEp2.e2eePublicKey, bobEp2.identityPublicKey, bobEp2.signature, false, 2);
    const pinnedBob = await getPinnedPeerKey(bobId);
    const resolvedBobEp1 = await resolveSenderPublicKey(bobId, 1);
    const resolvedBobEp2 = await resolveSenderPublicKey(bobId, 2);

    recordResult(
      'pinned_peer_preserves_epoch_history_and_key_epoch',
      Boolean(
        pinnedBob?.keyEpoch === 2 &&
        pinnedBob?.epochKeys?.['1']?.publicKey === bobEp1.e2eePublicKey &&
        pinnedBob?.epochKeys?.['2']?.publicKey === bobEp2.e2eePublicKey &&
        resolvedBobEp1 === bobEp1.e2eePublicKey &&
        resolvedBobEp2 === bobEp2.e2eePublicKey
      ),
      `pinnedKeyEpoch=${pinnedBob?.keyEpoch}, ep1Match=${resolvedBobEp1 === bobEp1.e2eePublicKey}, ep2Match=${resolvedBobEp2 === bobEp2.e2eePublicKey}`
    );

    // -----------------------------------------------------------------
    // 3. Connection DM Multi-Device Send & Decrypt Across Epochs
    // -----------------------------------------------------------------
    const connId = `conn_md_${suffix}`;
    const msgFromBobEp1 = await encryptMessage(
      'Hello from Bob Device 1 (Epoch 1)',
      bobEp1.e2eePrivateKey,
      aliceEp2.e2eePublicKey,
      connId,
      bobId,
      1
    );
    const msgFromBobEp2 = await encryptMessage(
      'Hello from Bob Device 2 (Epoch 2)',
      bobEp2.e2eePrivateKey,
      aliceEp2.e2eePublicKey,
      connId,
      bobId,
      2
    );

    // Alice restores her vault on Device 2 and decrypts BOTH Epoch 1 and Epoch 2 Bob messages using exact epoch keys
    const restoredAliceEp2 = await getLocalKeyPair(aliceId, 2);
    const dec1 = await decryptMessage(msgFromBobEp1, restoredAliceEp2!.privateKey, resolvedBobEp1!, connId, bobId);
    const dec2 = await decryptMessage(msgFromBobEp2, restoredAliceEp2!.privateKey, resolvedBobEp2!, connId, bobId);

    recordResult(
      'connection_dm_multi_device_epoch_decrypt',
      dec1 === 'Hello from Bob Device 1 (Epoch 1)' && dec2 === 'Hello from Bob Device 2 (Epoch 2)',
      `ep1Ok=${dec1.includes('Device 1')}, ep2Ok=${dec2.includes('Device 2')}`
    );

    // -----------------------------------------------------------------
    // 4. Cluster E2EE Multi-Device Key Wrap/Unwrap Across Personal Epochs
    // -----------------------------------------------------------------
    const clusterId = `clu-md-${suffix}`;
    const clusterEpoch = 1;
    const gen = await generateClusterGroupKey();
    const rosterHash = `roster_${suffix}`;

    // Alice (admin, Ep2) wraps group key for Bob's NEW Device 2 key (Ep2)
    const wrappedForBobEp2 = await wrapClusterGroupKeyForMember(
      gen.rawKey,
      aliceEp2.e2eePrivateKey,
      bobEp2.e2eePublicKey,
      clusterId,
      clusterEpoch,
      {
        audienceHash: 'ALL',
        keyFingerprint: gen.fingerprint,
        rosterHash,
        senderPublicKey: aliceEp2.e2eePublicKey,
        senderAgentId: aliceId,
        recipientAgentId: bobId,
        recipientKeyFingerprint: bobEp2.fingerprint,
        recipientKeyEpoch: 2,
      }
    );

    // Simulate Bob's Device 1 (stale Ep1 local key) pulling bobVault2 to restore Ep2, then unwrapping & decrypting cluster msg
    const bobRestored = await restoreFromEncryptedRecoveryVault(bobId, bobCred, bobVault2);
    const unwrappedClusterKey = await unwrapClusterGroupKeyFromPackage(
      wrappedForBobEp2,
      bobRestored.activeKey.privateKey,
      aliceEp2.e2eePublicKey,
      clusterId,
      clusterEpoch,
      'ALL'
    );

    const encClusterMsg = await encryptClusterMessage(
      'Cluster secret after multi-device rotation',
      gen.key,
      aliceId,
      clusterId,
      clusterEpoch,
      'ALL'
    );
    const decClusterMsg = await decryptClusterMessage(
      encClusterMsg.ciphertext,
      encClusterMsg.nonce,
      unwrappedClusterKey.groupKey,
      aliceId,
      clusterId,
      clusterEpoch,
      encClusterMsg.version,
      'Alice',
      'Test Cluster',
      'ALL'
    );

    recordResult(
      'cluster_multi_device_vault_unwrap_and_decrypt',
      decClusterMsg === 'Cluster secret after multi-device rotation',
      `decrypted="${decClusterMsg}"`
    );

    return results;
  } catch (err: any) {
    recordResult('multi_device_e2ee_unexpected_error', false, err?.message || String(err));
    return results;
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  runMultiDeviceE2eeTests().then((res) => {
    const failed = Object.values(res).some((r) => r.status === 'FAILED');
    process.exit(failed ? 1 : 0);
  });
}
