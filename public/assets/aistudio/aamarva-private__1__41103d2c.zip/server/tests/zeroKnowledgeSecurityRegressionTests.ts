import {
  generateAgentCryptoIdentity,
  encryptMessage,
  decryptMessage,
  constructAAD
} from '../../src/lib/e2ee.js';
import { getSupabaseClient } from '../supabase.js';

export async function runZeroKnowledgeSecurityRegressionTests(): Promise<Record<string, { status: 'PASSED' | 'FAILED'; reason?: string }>> {
  console.log('\n======================================================================');
  console.log('       AAMARVA ZERO-KNOWLEDGE E2EE SECURITY REGRESSION TESTS           ');
  console.log('======================================================================\n');

  const results: Record<string, { status: 'PASSED' | 'FAILED'; reason?: string }> = {};
  const recordResult = (id: string, success: boolean, reason?: string) => {
    results[id] = { status: success ? 'PASSED' : 'FAILED', reason };
    console.log(`[${success ? 'PASSED' : 'FAILED'}] ${id}${reason ? `: ${reason}` : ''}`);
  };

  try {
    const supabase = getSupabaseClient();
    const ts = Date.now();

    // 1. Generate cryptographic identities
    const alice = await generateAgentCryptoIdentity(`AMR_ZK_ALICE_${ts}`);
    const bob = await generateAgentCryptoIdentity(`AMR_ZK_BOB_${ts}`);
    const connectionId = `conn_zk_reg_${ts}`;

    // 2. Encrypt message client-side
    const plaintext = 'Classified zero-knowledge message content: Enclave state secure.';
    const envelope = await encryptMessage(
      plaintext,
      alice.e2eePrivateKey,
      bob.e2eePublicKey,
      connectionId,
      alice.e2eePublicKey,
      1
    );

    // 3. Verify backend cryptographic blindness (Rule: server cannot decrypt)
    // Server only stores ciphertext, nonce, version, keyEpoch
    const msgId = `msg_zk_${ts}`;
    const { error: insertErr } = await supabase.from('connection_messages').insert({
      id: msgId,
      connection_id: connectionId,
      sender_agent_id: alice.e2eePublicKey,
      ciphertext: envelope.ciphertext,
      nonce: envelope.nonce,
      version: envelope.version,
      key_epoch: envelope.keyEpoch,
      created_at: new Date().toISOString()
    });

    if (insertErr) {
      throw new Error(`Failed to persist envelope: ${insertErr.message}`);
    }

    const { data: storedMsg, error: fetchErr } = await supabase
      .from('connection_messages')
      .select('ciphertext, nonce, version, key_epoch')
      .eq('id', msgId)
      .single();

    if (fetchErr || !storedMsg) {
      throw new Error('Failed to retrieve stored message.');
    }

    // Verify stored record contains zero plaintext and zero private keys
    const storedString = JSON.stringify(storedMsg);
    const hasPlaintext = storedString.includes(plaintext) || storedString.includes('Classified');
    // Private keys contain 'd":' or privateKey material; public keys (x, y, crv, kty) are public parameters
    const hasPrivateKey = storedString.includes('"d":') || storedString.includes('privateKey');
    
    recordResult(
      'zk_regression_1_backend_cryptographically_blind',
      !hasPlaintext && !hasPrivateKey,
      'Backend database record contains strictly ciphertext, nonce, and public routing keys; zero plaintext or private key material exposed.'
    );

    // 4. Verify recipient decryption succeeds with correct private key
    const decrypted = await decryptMessage(
      storedMsg,
      bob.e2eePrivateKey,
      alice.e2eePublicKey,
      connectionId,
      alice.e2eePublicKey
    );

    recordResult(
      'zk_regression_2_recipient_successful_decryption',
      decrypted === plaintext,
      'Recipient successfully decrypted ciphertext using E2EE private key.'
    );

    // 5. Verify tampering rejection (AES-256-GCM authentication failure)
    let tamperDetected = false;
    try {
      const tampered = { ...storedMsg, ciphertext: storedMsg.ciphertext.substring(0, storedMsg.ciphertext.length - 4) + 'AAAA' };
      await decryptMessage(
        tampered,
        bob.e2eePrivateKey,
        alice.e2eePublicKey,
        connectionId,
        alice.e2eePublicKey
      );
    } catch {
      tamperDetected = true;
    }

    recordResult(
      'zk_regression_3_tamper_resistance_enforced',
      tamperDetected,
      'Modified ciphertext was strictly rejected by AES-256-GCM authentication tag verification.'
    );

    // 6. Verify AAD channel binding prevents cross-connection replay
    let crossChannelReplayBlocked = false;
    try {
      await decryptMessage(
        storedMsg,
        bob.e2eePrivateKey,
        alice.e2eePublicKey,
        'conn_wrong_channel_999',
        alice.e2eePublicKey
      );
    } catch {
      crossChannelReplayBlocked = true;
    }

    recordResult(
      'zk_regression_4_aad_channel_binding_protection',
      crossChannelReplayBlocked,
      'Cross-connection replay was strictly blocked by Authenticated Associated Data (AAD) channel binding.'
    );

    // Cleanup
    await supabase.from('connection_messages').delete().eq('id', msgId);

  } catch (err: any) {
    recordResult('zk_regression_fatal', false, err?.message || String(err));
  }

  return results;
}

if (process.argv[1]?.endsWith('zeroKnowledgeSecurityRegressionTests.ts')) {
  runZeroKnowledgeSecurityRegressionTests().catch(err => {
    console.error('Fatal zero-knowledge test error:', err);
    process.exit(1);
  });
}
