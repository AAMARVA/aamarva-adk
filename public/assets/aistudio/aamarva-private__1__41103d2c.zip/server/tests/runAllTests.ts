import { runE2EEUnitTests } from './e2eeUnitTests.ts';
import { runE2EESessionTestSuite } from './e2eeSessionTestSuite.ts';
import { runE2EERegistrationTests } from './e2eeRegistrationTests.ts';
import { runE2EEHardeningTests } from './e2eeHardeningTests.ts';
import { runClusterMessagingSecurityTests } from './clusterMessagingSecurityTests.ts';
import { runClusterHumanOnlyTests } from './clusterHumanOnlyTests.ts';
import { runClusterMemberEditTests } from './clusterMemberEditTests.ts';
import { runObsoleteEndpointRegressionTests } from './obsoleteEndpointRegressionTests.ts';
import { runTelemetryActivityTests } from './telemetryActivityTests.ts';
import { runFloorMcpServerTests } from './floorMcpServerTests.ts';
import { runFloorMcpAuditTestSuite } from './floorMcpAuditTestSuite.ts';
import { runDirectConnectionAndClusterTests } from './directConnectionAndClusterTests.ts';
import { runCapabilityMessagingRateLimitTests } from './capabilityMessagingRateLimitTests.ts';
import { runAgentNameValidationTests } from './agentNameValidationTests.ts';
import { runFloorAgentFacingApiTests } from './floorAgentFacingApiTests.ts';
import { runServerBlindE2EEAttachmentTests } from './serverBlindE2EEAttachmentTests.ts';
import { runVoiceMessageWorkflowTests } from './voiceMessageWorkflowTests.ts';
import { runWatchtowerOptimizationTests } from './watchtowerOptimizationTests.ts';
import { runSlaveDeploymentUncappedPlanTests } from './slaveDeploymentUncappedPlanTests.ts';
import { runMessagingLatencyAndReliabilityTests } from './messagingLatencyAndReliabilityTests.ts';
import { runWebsocketSubMillisecondBenchmark } from './websocketSubMillisecondBenchmark.ts';
import { runZeroKnowledgeSecurityRegressionTests } from './zeroKnowledgeSecurityRegressionTests.ts';
import { runMultiDeviceE2eeTests } from './multiDeviceE2eeTests.ts';

async function runAll() {
  const suites = [
    { name: 'e2eeUnitTests', fn: runE2EEUnitTests },
    { name: 'e2eeSessionTestSuite', fn: runE2EESessionTestSuite },
    { name: 'e2eeRegistrationTests', fn: runE2EERegistrationTests },
    { name: 'e2eeHardeningTests', fn: runE2EEHardeningTests },
    { name: 'clusterMessagingSecurityTests', fn: runClusterMessagingSecurityTests },
    { name: 'clusterHumanOnlyTests', fn: runClusterHumanOnlyTests },
    { name: 'clusterMemberEditTests', fn: runClusterMemberEditTests },
    { name: 'obsoleteEndpointRegressionTests', fn: runObsoleteEndpointRegressionTests },
    { name: 'telemetryActivityTests', fn: runTelemetryActivityTests },
    { name: 'watchtowerOptimizationTests', fn: runWatchtowerOptimizationTests },
    { name: 'floorMcpServerTests', fn: runFloorMcpServerTests },
    { name: 'floorMcpAuditTestSuite', fn: runFloorMcpAuditTestSuite },
    { name: 'floorAgentFacingApiTests', fn: runFloorAgentFacingApiTests },
    { name: 'directConnectionAndClusterTests', fn: runDirectConnectionAndClusterTests },
    { name: 'capabilityMessagingRateLimitTests', fn: runCapabilityMessagingRateLimitTests },
    { name: 'agentNameValidationTests', fn: runAgentNameValidationTests },
    { name: 'serverBlindE2EEAttachmentTests', fn: runServerBlindE2EEAttachmentTests },
    { name: 'voiceMessageWorkflowTests', fn: runVoiceMessageWorkflowTests },
    { name: 'slaveDeploymentUncappedPlanTests', fn: runSlaveDeploymentUncappedPlanTests },
    { name: 'messagingLatencyAndReliabilityTests', fn: runMessagingLatencyAndReliabilityTests },
    { name: 'websocketSubMillisecondBenchmark', fn: runWebsocketSubMillisecondBenchmark },
    { name: 'zeroKnowledgeSecurityRegressionTests', fn: runZeroKnowledgeSecurityRegressionTests },
    { name: 'multiDeviceE2eeTests', fn: runMultiDeviceE2eeTests }
  ];

  const failedSuiteNames: string[] = [];

  for (const s of suites) {
    try {
      const res = await s.fn();
      if (typeof res === 'boolean') {
        if (!res) {
          failedSuiteNames.push(`${s.name} (returned false)`);
        } else {
          console.log('[PASSED] Test suite ' + s.name);
        }
      } else if (res && typeof res === 'object') {
        if ((res as any).success === false || (res as any).passed === false || (res as any).status === 'FAILED') {
          failedSuiteNames.push(`${s.name} (root status FAILED/success=false)`);
        } else {
          const entries = Object.entries(res);
          const failedEntry = entries.find(([k, v]: [string, any]) => {
            if (v === 'FAILED' || (v && typeof v === 'object' && v.status === 'FAILED')) {
              return true;
            }
            return false;
          });
          if (failedEntry) {
            failedSuiteNames.push(`${s.name} (entry ${failedEntry[0]} = ${JSON.stringify(failedEntry[1])})`);
          } else {
            console.log('[PASSED] Test suite ' + s.name);
          }
        }
      } else {
        console.log('[PASSED] Test suite ' + s.name);
      }
    } catch (err: any) {
      failedSuiteNames.push(`${s.name} (threw error: ${err?.message || err})`);
    }
  }

  if (failedSuiteNames.length > 0) {
    console.error('\n[FAILURE] Aggregate test run failed. Failing suites:', JSON.stringify(failedSuiteNames, null, 2));
    process.exitCode = 1;
  } else {
    console.log('\n[SUCCESS] ALL 21 TEST SUITES PASSED CLEANLY WITH ZERO FAILURES.');
    process.exitCode = 0;
  }
}

runAll().catch(e => {
  console.error('Fatal test runner error:', e);
  process.exit(1);
});
