import dns from 'node:dns';
import https from 'node:https';
import crypto from 'node:crypto';
import { config } from './config';

try {
  dns.setDefaultResultOrder('ipv4first');
} catch {}

const brevoHttpsAgent = new https.Agent({
  keepAlive: true,
  keepAliveMsecs: 15000,
  maxSockets: 16,
  maxFreeSockets: 4,
});

function postBrevoTransactionalApiOnce(apiKey: string, body: string): Promise<{ status: number; bodyText: string }> {
  return new Promise((resolve, reject) => {
    const req = https.request(
      {
        hostname: 'api.brevo.com',
        port: 443,
        path: '/v3/smtp/email',
        method: 'POST',
        agent: brevoHttpsAgent,
        family: 4,
        timeout: 10000,
        headers: {
          'accept': 'application/json',
          'content-type': 'application/json',
          'content-length': Buffer.byteLength(body),
          'api-key': apiKey,
        },
      },
      (res) => {
        const chunks: Buffer[] = [];
        res.on('data', (chunk) => chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)));
        res.on('end', () => {
          resolve({
            status: res.statusCode || 500,
            bodyText: Buffer.concat(chunks).toString('utf8'),
          });
        });
      }
    );

    req.on('timeout', () => {
      req.destroy(new Error('Brevo API request timed out after 10000ms'));
    });
    req.on('error', (err) => reject(err));
    req.write(body);
    req.end();
  });
}

async function postBrevoTransactionalApi(apiKey: string, payload: Record<string, any>): Promise<{ status: number; bodyText: string }> {
  const body = JSON.stringify(payload);
  try {
    return await postBrevoTransactionalApiOnce(apiKey, body);
  } catch (err: any) {
    const code = String(err?.code || '');
    const msg = String(err?.message || '').toLowerCase();
    if (code === 'ECONNRESET' || code === 'EPIPE' || msg.includes('socket hang up')) {
      return await postBrevoTransactionalApiOnce(apiKey, body);
    }
    throw err;
  }
}

/**
 * Helper to parse an email string like "AAMARVA <no-reply@aamarva.com>" or "no-reply@aamarva.com"
 * into a structured Brevo sender/replyTo object: { name?: string, email: string }.
 */
function parseEmailString(formatted: string, defaultName?: string): { name?: string; email: string } {
  if (!formatted) return { name: defaultName, email: '' };
  const match = formatted.match(/^(?:"?([^"]*)"?\s+)?<([^>]+)>$/);
  if (match) {
    const name = match[1]?.trim() || defaultName;
    const email = match[2]?.trim();
    return name ? { name, email } : { email };
  }
  const email = formatted.trim();
  return defaultName ? { name: defaultName, email } : { email };
}

function getBrevoConfig(): { apiKey: string; from: string; replyTo: string } {
  const apiKey = process.env.BREVO_API_KEY || config.brevoApiKey;
  const from = process.env.EMAIL_FROM || config.emailFrom || 'AAMARVA <no-reply@aamarva.com>';
  const replyTo = process.env.EMAIL_REPLY_TO || config.emailReplyTo || 'AAMARVA Support <support@aamarva.com>';

  if (!apiKey || !apiKey.trim()) {
    console.error('[DIAGNOSTIC_LOG] [BREVO_SERVICE] ❌ CANNOT SEND EMAIL: BREVO_API_KEY environment variable is not configured.');
    throw new Error('BREVO_API_KEY environment variable is not configured.');
  }

  return {
    apiKey: apiKey.trim(),
    from: from.trim(),
    replyTo: replyTo.trim(),
  };
}

/**
 * Generic internal function to dispatch an email via Brevo V3 Transactional API
 */
async function sendBrevoEmail(params: {
  toEmail: string;
  toName?: string;
  subject: string;
  html: string;
  replyToEmail?: string;
  replyToName?: string;
}): Promise<{ messageId?: string }> {
  const { apiKey, from, replyTo } = getBrevoConfig();
  const startedAt = Date.now();

  const senderObj = parseEmailString(from, 'AAMARVA');
  const replyToObj = params.replyToEmail?.trim()
    ? (params.replyToName?.trim()
        ? { email: params.replyToEmail.trim(), name: params.replyToName.trim() }
        : { email: params.replyToEmail.trim() })
    : parseEmailString(replyTo, 'AAMARVA Support');
  const cleanToEmail = String(params.toEmail || '').trim();
  const recipientObj: { email: string; name?: string } = { email: cleanToEmail };
  if (params.toName?.trim()) {
    recipientObj.name = params.toName.trim();
  }

  const payload = {
    sender: senderObj,
    to: [recipientObj],
    replyTo: replyToObj,
    subject: params.subject,
    htmlContent: params.html,
    textContent: params.html ? params.html.replace(/<[^>]*>?/gm, ' ').replace(/\s+/g, ' ').trim() : '',
    tags: ['transactional'],
    headers: {
      'X-Entity-Ref-ID': crypto.randomUUID(),
      'X-Priority': '1',
      'Importance': 'High',
    },
  };

  console.log(`[DIAGNOSTIC_LOG] [BREVO_SERVICE] 📨 Dispatching email to ${cleanToEmail} | Subject: ${params.subject}`);

  const { status, bodyText } = await postBrevoTransactionalApi(apiKey, payload);

  if (status < 200 || status >= 300) {
    let errorDetails = bodyText;
    try {
      errorDetails = JSON.stringify(JSON.parse(bodyText));
    } catch {}
    console.error(`[DIAGNOSTIC_LOG] [BREVO_SERVICE] ❌ Brevo API call failed with HTTP ${status} (${Date.now() - startedAt}ms):`, errorDetails);
    throw new Error(`Brevo API call failed (HTTP ${status}): ${errorDetails}`);
  }

  let data: { messageId?: string } = {};
  try {
    data = JSON.parse(bodyText) as { messageId?: string };
  } catch {}
  console.log(`[DIAGNOSTIC_LOG] [BREVO_SERVICE] ✅ Dispatched in ${Date.now() - startedAt}ms | messageId=${data?.messageId || 'ok'}`);
  return data;
}

export async function sendEmailVerification(
  currentEmail: string,
  newEmail: string,
  token: string,
  appUrl: string
) {
  const verificationLink = `${appUrl}/verify-email-change?token=${token}`;

  const html = `
    <div style="font-family: monospace, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #141414; max-width: 600px; margin: 0 auto; border: 4px solid #141414; padding: 28px; background: #ffffff; box-shadow: 8px 8px 0px 0px #141414;">
      <h2 style="text-transform: uppercase; letter-spacing: 0.1em; margin-top: 0; border-bottom: 2px solid #141414; padding-bottom: 12px; color: #141414; font-size: 18px;">EMAIL CHANGE VERIFICATION</h2>
      <p style="font-size: 13px;">Hello,</p>
      <p style="font-size: 13px;">We received a request to change your AAMARVA account email from <strong>${currentEmail}</strong> to <strong>${newEmail}</strong>.</p>
      
      <div style="border: 2px solid #141414; padding: 16px; margin: 20px 0; background: #F4F3F0;">
        <h3 style="margin-top: 0; text-transform: uppercase; font-size: 13px; color: #141414;">CONFIRM EMAIL TRANSFER</h3>
        <p style="font-size: 12px; margin-bottom: 14px; color: #141414;">To confirm this change and bind your node to the new address, click the button below:</p>
        <div style="text-align: center;">
          <a href="${verificationLink}" style="display: inline-block; padding: 12px 24px; background-color: #141414; color: #ffffff; font-size: 13px; font-weight: bold; text-decoration: none; text-transform: uppercase; border: 2px solid #141414; box-shadow: 3px 3px 0px 0px #141414;">
            Verify Email Change
          </a>
        </div>
      </div>

      <p style="font-size: 12px; color: #555;">If the button above does not work, copy and paste this verification URL into your browser:</p>
      <p style="font-size: 11px; word-break: break-all; background: #f4f4f4; padding: 8px; border: 1px solid #141414; margin: 8px 0;">
        ${verificationLink}
      </p>
      <p style="font-size: 11px; color: #777;">This verification link expires in 30 minutes.</p>
      <hr style="border: none; border-top: 2px solid #141414; margin: 20px 0;" />
      <p style="font-size: 11px; color: #141414; text-transform: uppercase; margin: 0;">AAMARVA | Autonomous Agent Command Protocol & Infrastructure</p>
    </div>
  `;

  await sendBrevoEmail({
    toEmail: currentEmail,
    subject: `Confirm your email change [Ref: ${Date.now().toString().slice(-6)}]`,
    html,
  });
}

export async function sendPasswordResetEmail(
  email: string,
  rawToken: string,
  appUrl: string,
  userName?: string
) {
  const resetLink = `${appUrl}/reset-password?token=${rawToken}`;

  const html = `
    <div style="font-family: monospace, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #141414; max-width: 600px; margin: 0 auto; border: 4px solid #141414; padding: 28px; background: #ffffff; box-shadow: 8px 8px 0px 0px #141414;">
      <h2 style="text-transform: uppercase; letter-spacing: 0.1em; margin-top: 0; border-bottom: 2px solid #141414; padding-bottom: 12px; color: #141414; font-size: 18px;">PASSWORD RESET REQUEST</h2>
      <p style="font-size: 13px;">Hello${userName ? ` <strong>${userName}</strong>` : ''},</p>
      <p style="font-size: 13px;">We received a security request to reset the password for your AAMARVA account (<strong>${email}</strong>).</p>

      <div style="border: 2px solid #141414; padding: 16px; margin: 20px 0; background: #F4F3F0;">
        <h3 style="margin-top: 0; text-transform: uppercase; font-size: 13px; color: #141414;">SECURE CREDENTIAL RESET</h3>
        <p style="font-size: 12px; margin-bottom: 14px; color: #141414;">Click the link below to securely set a new operator password:</p>
        <div style="text-align: center;">
          <a href="${resetLink}" style="display: inline-block; padding: 12px 24px; background-color: #141414; color: #ffffff; font-size: 13px; font-weight: bold; text-decoration: none; text-transform: uppercase; border: 2px solid #141414; box-shadow: 3px 3px 0px 0px #141414;">
            Reset Password
          </a>
        </div>
      </div>

      <p style="font-size: 12px; color: #555;">If the button above does not work, copy and paste this reset URL into your browser:</p>
      <p style="font-size: 11px; word-break: break-all; background: #f4f4f4; padding: 8px; border: 1px solid #141414; margin: 8px 0;">
        ${resetLink}
      </p>
      <p style="font-size: 11px; color: #777;">This single-use reset link expires in 30 minutes. If you did not make this request, your account credentials remain unchanged.</p>
      <hr style="border: none; border-top: 2px solid #141414; margin: 20px 0;" />
      <p style="font-size: 11px; color: #141414; text-transform: uppercase; margin: 0;">AAMARVA | Autonomous Agent Command Protocol & Infrastructure</p>
    </div>
  `;

  await sendBrevoEmail({
    toEmail: email,
    toName: userName,
    subject: `Reset your password [Ref: ${Date.now().toString().slice(-6)}]`,
    html,
  });
}

export async function sendApiKeyRotationEmail(
  email: string,
  token: string,
  appUrl: string,
  userName?: string,
  syncedSlaveAccounts?: Array<{ agentId: string; name: string }>
) {
  const confirmLink = `${appUrl}/confirm-api-key-rotation?token=${token}`;
  const hasSlaves = Array.isArray(syncedSlaveAccounts) && syncedSlaveAccounts.length > 0;
  const hasMoreThanTenSlaves = hasSlaves && syncedSlaveAccounts!.length > 10;
  const slavesListHtml = hasSlaves
    ? `<div style="border: 2px solid #141414; padding: 12px; margin: 16px 0; background: #ffffff;">
        <p style="margin: 0 0 8px 0; font-size: 11px; font-weight: bold; text-transform: uppercase;">Synced Slave Accounts Queued for Rotation (${syncedSlaveAccounts!.length}):</p>
        <div style="${hasMoreThanTenSlaves ? 'max-height: 210px; overflow-y: auto;' : ''}">
          <ul style="margin: 0; padding-left: 18px; font-size: 12px; line-height: 20px;">
            ${syncedSlaveAccounts!.map(s => `<li><strong>${s.name || s.agentId}</strong> (@${s.agentId})</li>`).join('')}
          </ul>
        </div>
        ${hasMoreThanTenSlaves ? `<p style="margin: 8px 0 0 0; padding-top: 6px; border-top: 1px solid #141414; font-size: 10px; font-weight: bold; text-transform: uppercase;">Showing 10 accounts &mdash; Scroll inside list to view all ${syncedSlaveAccounts!.length}</p>` : ''}
      </div>`
    : '';

  const html = `
    <div style="font-family: monospace, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #141414; max-width: 600px; margin: 0 auto; border: 4px solid #141414; padding: 28px; background: #ffffff; box-shadow: 8px 8px 0px 0px #141414;">
      <h2 style="text-transform: uppercase; letter-spacing: 0.1em; margin-top: 0; border-bottom: 2px solid #141414; padding-bottom: 12px; color: #141414; font-size: 18px;">CONFIRM API KEY ROTATION</h2>
      <p style="font-size: 13px;">Hello${userName ? ` <strong>${userName}</strong>` : ''},</p>
      <p style="font-size: 13px;">${
        hasSlaves
          ? `We received a Master security request to rotate the API keys for your synced AAMARVA slave agent accounts under <strong>${email}</strong>.`
          : `We received a security request to rotate the API key for your AAMARVA agent account (<strong>${email}</strong>).`
      }</p>
      ${slavesListHtml}

      <div style="border: 2px solid #141414; padding: 16px; margin: 20px 0; background: #F4F3F0;">
        <h3 style="margin-top: 0; text-transform: uppercase; font-size: 13px; color: #141414;">AUTHORIZE CRYPTOGRAPHIC KEY ROTATION</h3>
        <p style="font-size: 12px; margin-bottom: 14px; color: #141414;">To invalidate your prior secret${hasSlaves ? 's' : ''} and generate newly rotated key${hasSlaves ? 's' : ''}, click the button below:</p>
        <div style="text-align: center;">
          <a href="${confirmLink}" style="display: inline-block; padding: 12px 24px; background-color: #141414; color: #ffffff; font-size: 13px; font-weight: bold; text-decoration: none; text-transform: uppercase; border: 2px solid #141414; box-shadow: 3px 3px 0px 0px #141414;">
            Confirm API Key Rotation
          </a>
        </div>
      </div>

      <p style="font-size: 12px; color: #555;">If the button above does not work, copy and paste this verification URL into your browser or API client:</p>
      <p style="font-size: 11px; word-break: break-all; background: #f4f4f4; padding: 8px; border: 1px solid #141414; margin: 8px 0;">
        ${confirmLink}
      </p>
      <p style="font-size: 11px; color: #777;">This confirmation link expires in 30 minutes. If you did not request this rotation, ignore this email.</p>
      <hr style="border: none; border-top: 2px solid #141414; margin: 20px 0;" />
      <p style="font-size: 11px; color: #141414; text-transform: uppercase; margin: 0;">AAMARVA | Autonomous Agent Command Protocol & Infrastructure</p>
    </div>
  `;

  await sendBrevoEmail({
    toEmail: email,
    toName: userName,
    subject: `Confirm API Key Rotation [Ref: ${Date.now().toString().slice(-6)}]`,
    html,
  });
}



export async function sendApplicationUnderReviewEmail(
  email: string,
  fullName: string,
  agentName: string
) {
  const html = `
    <div style="font-family: monospace, sans-serif; line-height: 1.6; color: #141414; max-width: 580px; margin: 0 auto; border: 4px solid #141414; padding: 24px; background: #ffffff; box-shadow: 8px 8px 0px 0px #141414;">
      <h2 style="text-transform: uppercase; letter-spacing: 0.1em; margin-top: 0; border-bottom: 2px solid #141414; padding-bottom: 12px;">AAMARVA INTAKE RECEIVED</h2>
      <p>Hello <strong>${fullName}</strong>,</p>
      <p>We have successfully received your intake application to list <strong>${agentName}</strong> on the AAMARVA autonomous agent registry.</p>
      <p>Your application is currently <strong>UNDER REVIEW</strong> by the network operators. We will try to reach you as soon as possible.</p>
      <div style="margin: 20px 0; padding: 12px; background: #E4E3E0; border: 2px solid #141414; font-size: 11px;">
        <strong>APPLICATION DETAILS:</strong><br/>
        • Applicant Name: ${fullName}<br/>
        • Agent/Project: ${agentName}<br/>
        • Status: UNDER REVIEW
      </div>
      <p style="font-size: 12px; color: #555;">No action is required from your side at this time.</p>
      <hr style="border: none; border-top: 2px solid #141414; margin: 20px 0;" />
      <p style="font-size: 11px; color: #888; text-transform: uppercase;">AAMARVA | Autonomous Agent Command Protocol & Infrastructure</p>
    </div>
  `;

  try {
    await sendBrevoEmail({
      toEmail: email,
      toName: fullName,
      subject: `AAMARVA Application Received: ${agentName} [Ref: ${Date.now().toString().slice(-6)}]`,
      html,
    });
  } catch (err: any) {
    console.error('[APPLICATION_EMAIL_ERROR] Failed to send receipt confirmation email:', err?.message || err);
  }
}

export async function sendAdminOtpEmail(otp: string) {
  const html = `
    <div style="font-family: monospace, sans-serif; line-height: 1.6; color: #141414; max-width: 580px; margin: 0 auto; border: 4px solid #141414; padding: 24px; background: #ffffff; box-shadow: 8px 8px 0px 0px #141414;">
      <h2 style="text-transform: uppercase; letter-spacing: 0.1em; margin-top: 0; border-bottom: 2px solid #141414; padding-bottom: 12px;">AAMARVA ADMIN PORTAL OTP</h2>
      <p>Hello,</p>
      <p>A verification request was initiated to access the received applications database on AAMARVA.</p>
      <p>Please enter the following one-time passcode (OTP) on the gateway page to authorize your session:</p>
      <div style="margin: 24px 0; text-align: center;">
        <span style="display: inline-block; padding: 12px 32px; background-color: #141414; color: #ffffff; font-size: 24px; font-weight: bold; letter-spacing: 0.15em; border: 2px solid #141414; box-shadow: 4px 4px 0px 0px #E4E3E0;">
          ${otp}
        </span>
      </div>
      <p style="font-size: 12px; color: #555;">This OTP is strictly one-time use and will expire in 5 minutes.</p>
      <hr style="border: none; border-top: 2px solid #141414; margin: 20px 0;" />
      <p style="font-size: 11px; color: #888; text-transform: uppercase;">AAMARVA | Autonomous Agent Command Protocol & Infrastructure</p>
    </div>
  `;

  await sendBrevoEmail({
    toEmail: 'founder@aamarva.com',
    toName: 'AAMARVA Founder',
    subject: `AAMARVA Admin OTP Verification Code [Ref: ${Date.now().toString().slice(-6)}]`,
    html,
  });
}

export async function sendApplicationApprovedEmail(toEmail: string, fullName?: string, customAppUrl?: string) {
  const baseUrl = customAppUrl || process.env.APP_URL || config.appUrl || 'https://aamarva.com';
  const registerUrl = `${baseUrl}/?action=register&email=${encodeURIComponent(toEmail)}`;

  const cleanName = fullName?.trim();
  const emailPrefix = toEmail.split('@')[0]?.toLowerCase();
  const isGeneric = !cleanName || ['agent operator', 'operator', 'user', emailPrefix].includes(cleanName.toLowerCase());
  const greeting = isGeneric ? 'Hello,' : `Hello <strong>${cleanName}</strong>,`;

  const html = `
    <div style="font-family: monospace, sans-serif; line-height: 1.6; color: #141414; max-width: 620px; margin: 0 auto; border: 4px solid #141414; padding: 28px; background: #ffffff; box-shadow: 8px 8px 0px 0px #141414;">
      <h2 style="text-transform: uppercase; letter-spacing: 0.1em; margin-top: 0; border-bottom: 2px solid #141414; padding-bottom: 12px; color: #141414; font-size: 18px;">ACCESS AUTHORIZED // WHITELIST ACTIVE</h2>
      <p style="font-size: 13px;">${greeting}</p>
      <p style="font-size: 13px;">Your email (<strong>${toEmail}</strong>) is now active on the Registration Whitelist.</p>

      <!-- Web Registration -->
      <div style="border: 2px solid #141414; padding: 16px; margin: 20px 0; background: #F4F3F0;">
        <p style="font-size: 12px; margin-top: 0; margin-bottom: 14px; color: #141414;">Register directly through the browser portal with your whitelisted email address:</p>
        <div style="text-align: center;">
          <a href="${registerUrl}" style="display: inline-block; padding: 10px 24px; background-color: #141414; color: #ffffff; font-size: 13px; font-weight: bold; text-decoration: none; text-transform: uppercase; border: 2px solid #141414; box-shadow: 3px 3px 0px 0px #141414;">
            Register On The Web
          </a>
        </div>
      </div>

      <hr style="border: none; border-top: 2px solid #141414; margin: 20px 0;" />
      <p style="font-size: 11px; color: #141414; text-transform: uppercase; margin: 0;">AAMARVA | Autonomous Agent Command Protocol & Infrastructure</p>
    </div>
  `;

  try {
    await sendBrevoEmail({
      toEmail,
      toName: cleanName || emailPrefix || 'Operator',
      subject: `AAMARVA Access Authorized - Whitelisted for Registration [Ref: ${Date.now().toString().slice(-6)}]`,
      html,
    });
  } catch (err: any) {
    console.error('[APPROVAL_EMAIL_ERROR] Failed to send approval email:', err?.message || err);
  }
}

export async function sendApplicationRejectedEmail(toEmail: string, fullName: string) {
  const html = `
    <div style="font-family: monospace, sans-serif; line-height: 1.6; color: #141414; max-width: 580px; margin: 0 auto; border: 4px solid #141414; padding: 24px; background: #ffffff; box-shadow: 8px 8px 0px 0px #141414;">
      <h2 style="text-transform: uppercase; letter-spacing: 0.1em; margin-top: 0; border-bottom: 2px solid #141414; padding-bottom: 12px; color: #141414;">APPLICATION STATUS: DECISION RENDERED</h2>
      <p>Hello ${fullName},</p>
      <p>We appreciate your interest in registering on the AAMARVA autonomous network floor.</p>
      <p>After careful evaluation of your operating scope and agent capability index, we regret to inform you that we cannot allocate network resources to your node at this time.</p>
      <p>Please continue refining your agent's autonomy and stability. You are welcome to submit a new intake application in the future as your agent architecture evolves and network capacity expands.</p>
      <hr style="border: none; border-top: 2px solid #141414; margin: 20px 0;" />
      <p style="font-size: 11px; color: #141414; text-transform: uppercase;">AAMARVA | Autonomous Agent Command Protocol & Infrastructure</p>
    </div>
  `;

  try {
    await sendBrevoEmail({
      toEmail,
      toName: fullName,
      subject: `AAMARVA Application Status Update [Ref: ${Date.now().toString().slice(-6)}]`,
      html,
    });
  } catch (err: any) {
    console.error('[REJECTION_EMAIL_ERROR] Failed to send rejection email:', err?.message || err);
  }
}

export async function sendEnterpriseInquiryEmail(params: {
  orgName: string;
  contactName: string;
  workEmail: string;
  fleetSize: string;
  timeline: string;
  requirements?: string;
}) {
  const escapeHtml = (str: string) =>
    String(str || '').replace(/[&<>"']/g, (m) => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;',
    }[m] || m));

  const safeOrg = escapeHtml(params.orgName.trim());
  const safeContact = escapeHtml(params.contactName.trim());
  const safeEmail = escapeHtml(params.workEmail.trim());
  const safeFleet = escapeHtml(params.fleetSize.trim());
  const safeTimeline = escapeHtml(params.timeline.trim());
  const safeRequirements = escapeHtml((params.requirements || 'Not specified').trim()).replace(/\n/g, '<br/>');

  const html = `
    <div style="font-family: monospace, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #141414; max-width: 600px; margin: 0 auto; border: 4px solid #141414; padding: 28px; background: #ffffff; box-shadow: 8px 8px 0px 0px #141414;">
      <h2 style="text-transform: uppercase; letter-spacing: 0.1em; margin-top: 0; border-bottom: 2px solid #141414; padding-bottom: 12px; color: #141414; font-size: 18px;">ENTERPRISE FLEET INQUIRY</h2>
      <p style="font-size: 13px;">A new Enterprise custom pricing and infrastructure inquiry has been submitted on AAMARVA.</p>

      <div style="border: 2px solid #141414; padding: 16px; margin: 20px 0; background: #F4F3F0; font-size: 12px;">
        <h3 style="margin-top: 0; text-transform: uppercase; font-size: 13px; color: #141414;">CLIENT &amp; FLEET DETAILS</h3>
        <p style="margin: 6px 0;"><strong>Organization:</strong> ${safeOrg}</p>
        <p style="margin: 6px 0;"><strong>Contact Name &amp; Title:</strong> ${safeContact}</p>
        <p style="margin: 6px 0;"><strong>Work Email:</strong> <a href="mailto:${safeEmail}" style="color: #141414; font-weight: bold;">${safeEmail}</a></p>
        <p style="margin: 6px 0;"><strong>Target Fleet Size:</strong> ${safeFleet} Slave Accounts</p>
        <p style="margin: 6px 0;"><strong>Deployment Timeline:</strong> ${safeTimeline}</p>
      </div>

      <div style="border: 2px solid #141414; padding: 16px; margin: 20px 0; background: #ffffff; font-size: 12px;">
        <h3 style="margin-top: 0; text-transform: uppercase; font-size: 13px; color: #141414;">TECHNICAL REQUIREMENTS &amp; OPERATIONAL OBJECTIVES</h3>
        <p style="margin: 0; color: #141414;">${safeRequirements}</p>
      </div>

      <hr style="border: none; border-top: 2px solid #141414; margin: 20px 0;" />
      <p style="font-size: 11px; color: #141414; text-transform: uppercase; margin: 0;">AAMARVA | Autonomous Agent Command Protocol &amp; Infrastructure</p>
    </div>
  `;

  await sendBrevoEmail({
    toEmail: 'sales@aamarva.com',
    toName: 'AAMARVA Enterprise Sales',
    replyToEmail: params.workEmail.trim(),
    replyToName: params.contactName.trim(),
    subject: `AAMARVA Enterprise Inquiry: ${params.orgName.trim()} [Ref: ${Date.now().toString().slice(-6)}]`,
    html,
  });
}

export async function sendFleetSlotAssignedEmail(params: {
  toEmail: string;
  fleetId: string;
  slotToken?: string;
  masterName?: string;
  masterEmail?: string;
  appUrl: string;
}) {
  const tokenParam = params.slotToken ? `&slotToken=${encodeURIComponent(params.slotToken)}` : '';
  const registerUrl = `${params.appUrl}/?action=register&email=${encodeURIComponent(params.toEmail)}&fleetId=${encodeURIComponent(params.fleetId)}${tokenParam}`;

  const html = `
    <div style="font-family: monospace, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #141414; max-width: 600px; margin: 0 auto; border: 4px solid #141414; padding: 28px; background: #ffffff; box-shadow: 8px 8px 0px 0px #141414;">
      <h2 style="text-transform: uppercase; letter-spacing: 0.1em; margin-top: 0; border-bottom: 2px solid #141414; padding-bottom: 12px; color: #141414; font-size: 18px;">MASTER ACCOUNT SLOT ASSIGNED</h2>
      <p style="font-size: 13px;">Hello,</p>
      <p style="font-size: 13px;">You have been assigned a Master Account slot on the AAMARVA network by <strong>${params.masterName || params.masterEmail || 'Master Operator'}</strong> (Fleet ID: <strong>${params.fleetId}</strong>).</p>

      <div style="border: 2px solid #141414; padding: 16px; margin: 20px 0; background: #F4F3F0;">
        <h3 style="margin-top: 0; text-transform: uppercase; font-size: 13px; color: #141414;">CLAIM MASTER SLOT &amp; REGISTER</h3>
        <p style="font-size: 12px; margin-bottom: 14px; color: #141414;">Click below to activate and complete registration for your assigned email address (<a href="${registerUrl}" style="color: #141414; font-weight: bold; text-decoration: underline;">${params.toEmail}</a>):</p>
        <div style="text-align: center;">
          <a href="${registerUrl}" style="display: inline-block; padding: 12px 24px; background-color: #141414; color: #ffffff; font-size: 13px; font-weight: bold; text-decoration: none; text-transform: uppercase; border: 2px solid #141414; box-shadow: 3px 3px 0px 0px #141414;">
            Register On The Web
          </a>
        </div>
      </div>

      <hr style="border: none; border-top: 2px solid #141414; margin: 20px 0;" />
      <p style="font-size: 11px; color: #141414; text-transform: uppercase; margin: 0;">AAMARVA | Autonomous Agent Command Protocol &amp; Infrastructure</p>
    </div>
  `;

  try {
    await sendBrevoEmail({
      toEmail: params.toEmail,
      subject: `Master Account Slot Assigned (${params.fleetId}) [Ref: ${Date.now().toString().slice(-6)}]`,
      html,
    });
  } catch (err: any) {
    console.error('[SLOT_EMAIL_ERROR] Failed to send fleet slot email:', err?.message || err);
  }
}


