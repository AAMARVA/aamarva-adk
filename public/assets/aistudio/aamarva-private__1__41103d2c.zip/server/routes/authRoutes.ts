import { Router, Request, Response } from 'express';
import { getSupabaseClient } from '../supabase';
import {
  registerUser,
  loginHuman,
  verifyHumanPasswordCredentials,
  createHumanSession,
  getUserById,
  loginAgent,
  logoutUser,
  logoutHumanSession,
  logoutAgent,
  updateUserProfile,
  deleteUserAccount,
  REFRESH_COOKIE_NAME,
  HUMAN_SESSION_COOKIE_NAME,
  getRefreshCookieOptions,
  getHumanSessionCookieOptions,
  refreshSessionToken,
  rotateAgentApiKey,
  requestAgentApiKeyRotation,
  confirmAgentApiKeyRotation,
  requestEmailChange,
  verifyEmailChange,
  requestAccountVerificationEmail,
  confirmAccountEmailVerification,
  requestForgotPassword,
  resetPassword,
  getResetTokenUser,
  verifyRefreshToken,
  invalidateAllHumanSessionsForUser,
  getVerificationStatus,
  updateUserWhitelist,
  invalidateUserRecordCache,
  isSlaveUserRecord,
  SLAVE_UI_LOGIN_ERROR_MESSAGE,
} from '../authService';
import { securityLayer } from '../middleware/securityLayerMiddleware';
import { humanLoginFirewall } from '../middleware/humanLoginFirewallMiddleware';
import { getClientIp } from '../utils/networkWhitelist.js';
import { watchtowerActivityService } from '../services/watchtowerActivityService';
import { generateLoginChallenge, verifySetupResponse, verifyLoginResponse } from '../services/webauthnService';
import { SecurityService } from '../services/securityService';
import { applicationService } from '../services/applicationService';
import { MasterAccountService } from '../services/masterAccountService';

const router = Router();

// 0. GET /api/auth/registration-link-status & /api/v1/auth/registration-link-status
router.get(['/auth/registration-link-status', '/v1/auth/registration-link-status'], async (req: Request, res: Response) => {
  try {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    const email = typeof req.query.email === 'string' ? req.query.email : '';
    const fleetId = typeof req.query.fleetId === 'string' ? req.query.fleetId : (typeof req.query.fleet_id === 'string' ? req.query.fleet_id : '');
    const slotToken = typeof req.query.slotToken === 'string' ? req.query.slotToken : '';

    const status = await MasterAccountService.getInstance().checkRegistrationLinkStatus({
      email,
      fleetId,
      slotToken
    });

    return res.json({
      success: true,
      data: status
    });
  } catch (err: any) {
    return res.status(500).json({
      success: false,
      error: { message: err?.message || 'Unable to verify registration link status.' }
    });
  }
});

// 1. POST /api/auth/register & /api/v1/auth/register
router.post(['/auth/register', '/v1/auth/register'], securityLayer('auth_register'), async (req: Request, res: Response) => {
  try {
    const clientIp = getClientIp(req);
    
    const emailToRegister = req.body?.email;
    if (!emailToRegister || typeof emailToRegister !== 'string' || !emailToRegister.trim()) {
      return res.status(400).json({
        success: false,
        error: {
          message: 'Please enter a valid email address.'
        }
      });
    }

    const fleetIdInput = (req.body?.fleetId || req.body?.fleet_id || '').trim().toUpperCase();
    const slotTokenInput = typeof req.body?.slotToken === 'string' ? req.body.slotToken.trim() : '';
    const fromInviteLink = Boolean(req.body?.fromInviteLink);

    // Pre-flight single-use expiration check: reject already-used slot/registration links immediately before creating any user
    if (fleetIdInput || slotTokenInput || fromInviteLink) {
      const linkStatus = await MasterAccountService.getInstance().checkRegistrationLinkStatus({
        email: emailToRegister.trim(),
        fleetId: fleetIdInput,
        slotToken: slotTokenInput
      });
      if (linkStatus.expired) {
        return res.status(410).json({
          success: false,
          error: {
            code: 'REGISTRATION_LINK_EXPIRED',
            message: linkStatus.message || 'This registration link has expired because it has already been used.'
          }
        });
      }
    }

    // Strict Whitelist Enforcement: Non-whitelisted emails cannot register (unless authorized by Fleet ID / Master slot)
    let isWhitelisted = await applicationService.isEmailWhitelisted(emailToRegister.trim());
    let slotErrorMessage = '';
    if (!isWhitelisted && fleetIdInput) {
      try {
        const testClaim = await MasterAccountService.getInstance().claimMasterSlotByFleetId(fleetIdInput, emailToRegister.trim(), 'preview');
        if (testClaim?.success) {
          await applicationService.addEmailToWhitelist(emailToRegister.trim(), { sendEmail: false }).catch(console.warn);
          isWhitelisted = true;
        } else if (testClaim?.error) {
          slotErrorMessage = testClaim.error;
        }
      } catch (e: any) {
        slotErrorMessage = e?.message || '';
      }
    }

    if (!isWhitelisted) {
      return res.status(403).json({
        success: false,
        error: {
          code: 'EMAIL_NOT_WHITELISTED',
          message: slotErrorMessage || (fleetIdInput
            ? 'Access Denied: The specified Fleet ID is invalid or has no available Master slots. Please check your Fleet ID.'
            : 'Access Denied: This email address is not whitelisted for registration. Please request access and wait for approval.')
        }
      });
    }

    // Input validation constraints
    const nameInput = req.body?.agentName !== undefined ? req.body.agentName : (req.body?.name !== undefined ? req.body.name : req.body?.registerAgentName);
    if (nameInput !== undefined) {
      const trimmedName = nameInput.toString().trim();
      if (trimmedName.length < 1 || trimmedName.length > 20) {
        throw new Error('Agent name must be between 1 and 20 characters.');
      }
    }

    const bioInput = req.body?.bio;
    if (bioInput !== undefined) {
      const bioStr = bioInput.toString();
      if (bioStr.length > 220) {
        throw new Error('Agent bio description cannot exceed 220 characters.');
      }
    }

    const result = await registerUser(req.body, clientIp);

    // Allot slot in fleet if registered with fleetId or matching slot allocation
    let allottedFleetId: string | null = null;
    let allottedMasterId: string | null = null;

    if (fleetIdInput || emailToRegister) {
      try {
        const slotClaim = await MasterAccountService.getInstance().claimMasterSlotByFleetId(fleetIdInput, emailToRegister.trim(), result.user.id);
        if (slotClaim && slotClaim.success) {
          allottedFleetId = slotClaim.fleetId;
          allottedMasterId = slotClaim.masterUserId;

          const supabase = getSupabaseClient();
          const { error: updateErr } = await supabase
            .from('users')
            .update({
              master_id: slotClaim.masterUserId,
              fleet_id: slotClaim.fleetId,
              account_type: 'master_slot',
              role: 'master',
              is_master_slot: true,
              is_master_primary: false
            })
            .eq('id', result.user.id);

          if (updateErr) {
            console.error('[Registration] Database error setting master slot columns:', updateErr);
            throw new Error(`Failed to persist Add-On Master relationship: ${updateErr.message}`);
          }

          (result.user as any).master_id = slotClaim.masterUserId;
          (result.user as any).fleet_id = slotClaim.fleetId;
          (result.user as any).account_type = 'master_slot';
          (result.user as any).role = 'master';
          (result.user as any).is_master_slot = true;
          (result.user as any).is_master_primary = false;

          invalidateUserRecordCache(result.user.id);
          MasterAccountService.getInstance().invalidateMasterPlanCache(slotClaim.masterUserId);
        } else if (slotClaim?.error || fleetIdInput) {
          throw new Error(slotClaim?.error || `Failed to claim master slot for fleet ID ${fleetIdInput}: Invalid or exhausted slot.`);
        }
      } catch (claimErr: any) {
        console.error('[Registration] Error allotting fleet slot. Rolling back user creation:', claimErr);
        try {
          const supabase = getSupabaseClient();
          await supabase.from('users').delete().eq('id', result.user.id);
          if (supabase.auth?.admin?.deleteUser) {
            await supabase.auth.admin.deleteUser(result.user.id).catch(() => {});
          }
          invalidateUserRecordCache(result.user.id);
        } catch (cleanupErr) {
          console.error('[Registration] Error cleaning up unallotted user record:', cleanupErr);
        }
        throw claimErr;
      }
    }

    if (result.tokens?.refreshToken) {
      res.cookie(REFRESH_COOKIE_NAME, result.tokens.refreshToken, getRefreshCookieOptions());
    }
    if (result.sessionId) {
      res.cookie(HUMAN_SESSION_COOKIE_NAME, result.sessionId, getHumanSessionCookieOptions());
    }
    
    // Broadcast floor activity: [Agent Name] registered
    const regActivityText = allottedFleetId 
      ? `registered and allotted slot in fleet ${allottedFleetId}` 
      : 'registered';

    watchtowerActivityService.recordWatchtowerActivity({
      actorUserId: result.user.id,
      masterId: allottedMasterId || (result.user as any).master_id || result.user.id,
      agentId: result.agentId,
      agentName: result.user?.name || result.agentId,
      avatar: result.user?.avatar || '🤖',
      emailVerified: result.user?.verificationStatus === 'verified' || result.user?.emailVerified === true,
      text: regActivityText,
      type: 'AGENT_REGISTERED',
      entityId: result.agentId,
      activityKey: `reg:${result.agentId}`
    }).catch(console.warn);

    const safeUserPayload = {
      id: result.user.id,
      email: result.user.email,
      agentId: result.agentId || result.user.agentId,
      name: result.user.name,
      bio: result.user.bio,
      avatar: result.user.avatar,
      master_id: (result.user as any).master_id,
      fleet_id: (result.user as any).fleet_id,
      is_master_slot: (result.user as any).is_master_slot,
      whitelisted_networks: result.user.whitelisted_networks || []
    };

    return res.status(201).json({
      success: true,
      agentId: result.agentId,
      apiKey: result.apiKey,
      tokens: result.tokens,
      user: safeUserPayload,
      data: {
        agentId: result.agentId,
        apiKey: result.apiKey,
        tokens: result.tokens,
        user: safeUserPayload,
      }
    });
  } catch (err: any) {
    const errorMessage = err?.message || '';
    const isEmailExists = errorMessage.toLowerCase().includes('already exists') || 
                          errorMessage.toLowerCase().includes('already registered');
    const isSlotError = errorMessage.toLowerCase().includes('invalid or exhausted slot') || 
                        errorMessage.toLowerCase().includes('failed to claim master slot');

    if (isEmailExists) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'EMAIL_EXISTS',
          message: 'An account with this email address already exists. Please sign in with your credentials.'
        }
      });
    }

    if (isSlotError) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_FLEET_SLOT',
          message: 'The specified Fleet ID is invalid or has no available slots. Please check your Fleet ID.'
        }
      });
    }

    const isDbOrServerError = (errorMessage.toLowerCase().includes('database') || errorMessage.toLowerCase().includes('supabase')) && !isEmailExists && !isSlotError;

    if (isDbOrServerError || err?.status === 500) {
      console.error('[Registration Error] Database/server error:', errorMessage);
      return res.status(500).json({ 
        success: false, 
        error: { 
          code: 'INTERNAL_SERVER_ERROR',
          message: 'An internal error occurred during registration. Please try again later.' 
        } 
      });
    }

    res.status(400).json({ success: false, error: { message: errorMessage || 'Registration failed' } });
  }
});

// 2. POST /api/auth/human/login & /api/v1/auth/human/login (Human Login with Mandatory WebAuthn)
router.post(['/auth/human/login', '/v1/auth/human/login'], humanLoginFirewall, securityLayer('auth_login'), async (req: Request, res: Response) => {
  const agentId = req.body?.agentId;
  try {
    const { password } = req.body;
    // Step 1: Verify human password credentials
    const safeUser = await verifyHumanPasswordCredentials({ agentId, password });
    
    // Step 2: Generate WebAuthn Challenge (WEBAUTHN_REQUIRED if passkey exists, WEBAUTHN_SETUP_REQUIRED if not)
    const challengeResult = await generateLoginChallenge(safeUser as any, req);

    res.json({
      success: true,
      status: challengeResult.status,
      pendingToken: challengeResult.pendingToken,
      options: challengeResult.options,
      user: {
        agentId: safeUser.agentId,
        name: safeUser.name,
      }
    });
  } catch (err: any) {
    const errorMessage = err?.message || '';
    const isDbOrServerError = errorMessage.toLowerCase().includes('database') || 
                              errorMessage.toLowerCase().includes('supabase') || 
                              errorMessage.toLowerCase().includes('failed to insert') ||
                              err?.status === 500;

    if (isDbOrServerError) {
      console.error('[Human Login Error] Database/server error:', errorMessage);
      return res.status(500).json({ 
        success: false, 
        error: { 
          code: 'INTERNAL_SERVER_ERROR',
          message: 'An internal error occurred during authentication. Please try again later.' 
        } 
      });
    }

    if (err?.code === 'SLAVE_UI_LOGIN_FORBIDDEN' || errorMessage === SLAVE_UI_LOGIN_ERROR_MESSAGE) {
      return res.status(403).json({
        success: false,
        error: {
          code: 'SLAVE_UI_LOGIN_FORBIDDEN',
          message: SLAVE_UI_LOGIN_ERROR_MESSAGE,
        }
      });
    }

    if (errorMessage.includes('inactive')) {
      return res.status(403).json({ 
        success: false, 
        error: { 
          code: 'FORBIDDEN',
          message: errorMessage 
        } 
      });
    }

    try {
      await SecurityService.getInstance().trackBehavioralSignal(agentId || req.ip || 'anonymous', 'BRUTE_FORCE_GUESS', { agentId, ip: req.ip });
    } catch (e) {}

    res.status(401).json({ 
      success: false, 
      error: { 
        code: 'UNAUTHORIZED',
        message: errorMessage || 'Invalid Account ID or Password.' 
      } 
    });
  }
});

// 2a. POST /api/auth/webauthn/verify-setup & /api/v1/auth/webauthn/verify-setup (Setup first device passkey during login)
router.post(['/auth/webauthn/verify-setup', '/v1/auth/webauthn/verify-setup'], humanLoginFirewall, securityLayer('auth_login'), async (req: Request, res: Response) => {
  try {
    const { pendingToken, credentialResponse, friendlyName } = req.body;
    if (!pendingToken || !credentialResponse) {
      return res.status(400).json({ success: false, error: { message: 'Missing pendingToken or credentialResponse' } });
    }

    const { userId } = await verifySetupResponse(pendingToken, credentialResponse, friendlyName, req);
    const userRecord = await getUserById(userId);
    if (!userRecord) {
      return res.status(400).json({ success: false, error: { message: 'User record not found.' } });
    }
    if (isSlaveUserRecord(userRecord)) {
      return res.status(403).json({
        success: false,
        error: { code: 'SLAVE_UI_LOGIN_FORBIDDEN', message: SLAVE_UI_LOGIN_ERROR_MESSAGE }
      });
    }

    const sessionId = await createHumanSession(userId);
    res.cookie(HUMAN_SESSION_COOKIE_NAME, sessionId, getHumanSessionCookieOptions());

    const { passwordHash: _, apiKeyHash: __, ...safeUser } = userRecord;
    res.json({
      success: true,
      data: {
        user: safeUser,
      }
    });
  } catch (err: any) {
    res.status(400).json({
      success: false,
      error: { message: err?.message || 'WebAuthn device passkey registration failed.' }
    });
  }
});

// 2b. POST /api/auth/webauthn/verify-login & /api/v1/auth/webauthn/verify-login (Device passkey authentication during login)
router.post(['/auth/webauthn/verify-login', '/v1/auth/webauthn/verify-login'], humanLoginFirewall, securityLayer('auth_login'), async (req: Request, res: Response) => {
  try {
    const { pendingToken, credentialResponse } = req.body;
    if (!pendingToken || !credentialResponse) {
      return res.status(400).json({ success: false, error: { message: 'Missing pendingToken or credentialResponse' } });
    }

    const { userId } = await verifyLoginResponse(pendingToken, credentialResponse, req);
    const userRecord = await getUserById(userId);
    if (!userRecord) {
      return res.status(400).json({ success: false, error: { message: 'User record not found.' } });
    }
    if (isSlaveUserRecord(userRecord)) {
      return res.status(403).json({
        success: false,
        error: { code: 'SLAVE_UI_LOGIN_FORBIDDEN', message: SLAVE_UI_LOGIN_ERROR_MESSAGE }
      });
    }

    const sessionId = await createHumanSession(userId);
    res.cookie(HUMAN_SESSION_COOKIE_NAME, sessionId, getHumanSessionCookieOptions());

    const { passwordHash: _, apiKeyHash: __, ...safeUser } = userRecord;
    res.json({
      success: true,
      data: {
        user: safeUser,
      }
    });
  } catch (err: any) {
    res.status(400).json({
      success: false,
      error: { message: err?.message || 'WebAuthn device passkey authentication failed.' }
    });
  }
});

export default router;
