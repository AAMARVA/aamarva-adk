import { Router, Response } from 'express';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { requireUserOrAgentAuth, requireHumanSession, AuthenticatedRequest, clusterMessageSentLimiter, clusterMessageRetrieveLimiter } from '../middleware/authMiddleware';
import { getSupabaseClient, ensureClusterKeyDistributionsTable, isMissingRelationOrSchemaError } from '../supabase';
import { logAgentFootprint, logExternalEvent } from '../services/auditService';
import { getClusterSymbol } from '../lib/clusterSymbols';
import { watchtowerActivityService } from '../services/watchtowerActivityService';
import { SecurityService } from '../services/securityService';
import { MAX_BASE64_CIPHERTEXT_LENGTH, MAX_DECODED_CIPHERTEXT_BYTES, isSlaveAccount } from '../services/connectionService';
import { HUMAN_SESSION_COOKIE_NAME, findUserById, getCachedAuthUserById, verifyHumanSession } from '../authService';
import { CapabilityService } from '../services/capabilityService';
import { clusterService } from '../services/clusterService';
import { realtimeService } from '../services/realtimeService';

const router = Router();

export interface ClusterTables {
  clusters: string;
  members: string;
  invites: string;
  messages: string;
  recipients: string;
  epochs: string;
  keyDistributions: string;
}

let cachedTables: ClusterTables | null = null;

// Canonical cluster database tables
export async function getClusterTables(_supabase?: any): Promise<ClusterTables> {
  if (cachedTables) return cachedTables;

  cachedTables = {
    clusters: 'clusters',
    members: 'cluster_members',
    invites: 'cluster_invites',
    messages: 'cluster_messages',
    recipients: 'cluster_message_recipients',
    epochs: 'cluster_epochs',
    keyDistributions: 'cluster_key_distributions',
  };
  return cachedTables;
}

// Reset cache if needed
export function resetClusterTablesCache() {
  cachedTables = null;
}

// Resilient fallback storage for cluster_key_distributions when Supabase table/schema cache is unavailable
const FALLBACK_KEY_DIST_PATH = path.resolve(process.cwd(), 'server', 'data', 'cluster_key_distributions_fallback.json');
const fallbackKeyDistStore = new Map<string, any[]>();
let fallbackKeyDistLoaded = false;

function loadFallbackKeyDistDiskStore(): void {
  if (fallbackKeyDistLoaded) return;
  fallbackKeyDistLoaded = true;
  try {
    if (process.env.NODE_ENV !== 'test' && fs.existsSync(FALLBACK_KEY_DIST_PATH)) {
      const raw = fs.readFileSync(FALLBACK_KEY_DIST_PATH, 'utf-8');
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === 'object') {
        for (const [cid, rows] of Object.entries(parsed)) {
          if (Array.isArray(rows)) fallbackKeyDistStore.set(cid, rows);
        }
      }
    }
  } catch {}
}

function saveFallbackKeyDistDiskStore(): void {
  if (process.env.NODE_ENV === 'test') return;
  try {
    const dir = path.dirname(FALLBACK_KEY_DIST_PATH);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    const obj: Record<string, any[]> = {};
    for (const [cid, rows] of fallbackKeyDistStore.entries()) {
      if (rows.length > 0) obj[cid] = rows;
    }
    fs.writeFileSync(FALLBACK_KEY_DIST_PATH, JSON.stringify(obj, null, 2), 'utf-8');
  } catch {}
}

function mergeKeyDistRowLists(primary: any[], secondary: any[]): any[] {
  const byId = new Map<string, any>();
  for (const r of [...(secondary || []), ...(primary || [])]) {
    if (r && r.id) byId.set(String(r.id), r);
  }
  return Array.from(byId.values()).sort((a, b) => {
    const ta = new Date(a?.createdAt || 0).getTime();
    const tb = new Date(b?.createdAt || 0).getTime();
    return tb - ta;
  });
}

async function syncFallbackKeyDistributionsToOwnerMetadata(
  supabase: any,
  tables: ClusterTables,
  clusterId: string,
  clusterRows: any[]
): Promise<void> {
  try {
    if (!supabase?.auth?.admin?.getUserById || !supabase?.auth?.admin?.updateUserById) return;
    const { data: clusterRow } = await supabase
      .from(tables.clusters)
      .select('ownerUserId')
      .eq('id', clusterId)
      .maybeSingle();
    const ownerUserId = clusterRow?.ownerUserId;
    if (!ownerUserId) return;

    const ownerAuthUser = await getCachedAuthUserById(supabase, ownerUserId);
    const currentAppMeta = ownerAuthUser?.app_metadata || {};
    const currentMap = (currentAppMeta.clusterKeyDistributionsFallback && typeof currentAppMeta.clusterKeyDistributionsFallback === 'object')
      ? { ...currentAppMeta.clusterKeyDistributionsFallback }
      : {};
    currentMap[clusterId] = clusterRows.slice(0, 200);

    await supabase.auth.admin.updateUserById(ownerUserId, {
      app_metadata: {
        ...currentAppMeta,
        clusterKeyDistributionsFallback: currentMap,
      },
    });
  } catch {}
}

async function readFallbackKeyDistributions(
  supabase: any,
  tables: ClusterTables,
  clusterId: string,
  epoch: number
): Promise<any[]> {
  loadFallbackKeyDistDiskStore();
  let clusterRows = fallbackKeyDistStore.get(clusterId) || [];

  try {
    if (supabase?.auth?.admin?.getUserById) {
      const { data: clusterRow } = await supabase
        .from(tables.clusters)
        .select('ownerUserId')
        .eq('id', clusterId)
        .maybeSingle();
      const ownerUserId = clusterRow?.ownerUserId;
      if (ownerUserId) {
        const ownerAuthUser = await getCachedAuthUserById(supabase, ownerUserId);
        const remoteRows = ownerAuthUser?.app_metadata?.clusterKeyDistributionsFallback?.[clusterId];
        if (Array.isArray(remoteRows) && remoteRows.length > 0) {
          clusterRows = mergeKeyDistRowLists(clusterRows, remoteRows);
          fallbackKeyDistStore.set(clusterId, clusterRows);
        }
      }
    }
  } catch {}

  return clusterRows
    .filter((r: any) => Number(r?.epoch) === Number(epoch))
    .sort((a: any, b: any) => new Date(b?.createdAt || 0).getTime() - new Date(a?.createdAt || 0).getTime());
}

async function upsertFallbackKeyDistributions(
  supabase: any,
  tables: ClusterTables,
  clusterId: string,
  newRows: any[],
  idsToDelete: string[] = []
): Promise<void> {
  loadFallbackKeyDistDiskStore();
  const deleteSet = new Set((idsToDelete || []).map((id) => String(id)));
  const existing = (fallbackKeyDistStore.get(clusterId) || []).filter((r: any) => !deleteSet.has(String(r?.id)));
  const merged = mergeKeyDistRowLists(newRows, existing);
  fallbackKeyDistStore.set(clusterId, merged);
  saveFallbackKeyDistDiskStore();
  await syncFallbackKeyDistributionsToOwnerMetadata(supabase, tables, clusterId, merged);
}

async function deleteFallbackKeyDistributions(
  supabase: any,
  tables: ClusterTables,
  clusterId: string,
  idsToDelete: string[]
): Promise<void> {
  if (!idsToDelete || idsToDelete.length === 0) return;
  loadFallbackKeyDistDiskStore();
  const deleteSet = new Set(idsToDelete.map((id) => String(id)));
  const existing = fallbackKeyDistStore.get(clusterId) || [];
  const next = existing.filter((r: any) => !deleteSet.has(String(r?.id)));
  if (next.length !== existing.length) {
    fallbackKeyDistStore.set(clusterId, next);
    saveFallbackKeyDistDiskStore();
    await syncFallbackKeyDistributionsToOwnerMetadata(supabase, tables, clusterId, next);
  }
}

export async function readKeyDistributionsForEpoch(
  supabase: any,
  tables: ClusterTables,
  clusterId: string,
  epoch: number
): Promise<any[]> {
  const queryTable = async () =>
    supabase
      .from(tables.keyDistributions)
      .select('*')
      .eq('clusterId', clusterId)
      .eq('epoch', epoch)
      .order('createdAt', { ascending: false });

  let { data, error } = await queryTable();

  if (error && isMissingRelationOrSchemaError(error)) {
    const ensured = await ensureClusterKeyDistributionsTable(supabase, true);
    if (ensured) {
      const retryRes = await queryTable();
      data = retryRes.data;
      error = retryRes.error;
    }
  }

  if (error) {
    if (isMissingRelationOrSchemaError(error)) {
      return readFallbackKeyDistributions(supabase, tables, clusterId, epoch);
    }
    return [];
  }

  const dbRows = Array.isArray(data) ? data : [];
  const memRows = (fallbackKeyDistStore.get(clusterId) || []).filter((r: any) => Number(r?.epoch) === Number(epoch));
  return memRows.length > 0 ? mergeKeyDistRowLists(dbRows, memRows) : dbRows;
}

export async function insertKeyDistributions(
  supabase: any,
  tables: ClusterTables,
  clusterId: string,
  epoch: number,
  rows: any[],
  idsToDelete: string[] = [],
  errorPrefix = 'Failed to insert key distributions'
): Promise<void> {
  if (!Array.isArray(rows) || rows.length === 0) return;

  if (idsToDelete.length > 0) {
    try {
      await supabase.from(tables.keyDistributions).delete().in('id', idsToDelete);
    } catch {}
    await deleteFallbackKeyDistributions(supabase, tables, clusterId, idsToDelete);
  }

  let { error: distErr } = await supabase.from(tables.keyDistributions).insert(rows);

  if (distErr && isMissingRelationOrSchemaError(distErr)) {
    const ensured = await ensureClusterKeyDistributionsTable(supabase, true);
    if (ensured) {
      if (idsToDelete.length > 0) {
        try {
          await supabase.from(tables.keyDistributions).delete().in('id', idsToDelete);
        } catch {}
      }
      const retryRes = await supabase.from(tables.keyDistributions).insert(rows);
      distErr = retryRes.error;
    }
  }

  if (distErr) {
    if (isMissingRelationOrSchemaError(distErr)) {
      await upsertFallbackKeyDistributions(supabase, tables, clusterId, rows, idsToDelete);
      return;
    }
    throw new Error(`${errorPrefix}: ${distErr.message}`);
  }
}

export function clearFallbackKeyDistributionsForTesting(): void {
  fallbackKeyDistStore.clear();
}

// Helper: strict Base64 validation
function isValidBase64String(str: string): boolean {
  if (!str || typeof str !== 'string') return false;
  const trimmed = str.trim();
  if (trimmed.length === 0) return false;
  const base64Regex = /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/;
  const urlSafeRegex = /^(?:[A-Za-z0-9_-]{4})*(?:[A-Za-z0-9_-]{2}==|[A-Za-z0-9_-]{3}=)?$/;
  return base64Regex.test(trimmed) || urlSafeRegex.test(trimmed);
}

// Helper: canonicalize agent identifiers across E2EE operations
function normalizeAgentId(agentId?: string | null): string {
  if (!agentId || typeof agentId !== 'string') return '';
  let id = agentId.trim();
  if (id.startsWith('@')) {
    id = id.substring(1).trim();
  }
  return id.toUpperCase();
}

function canonicalizeAgentSet(agentIds: string[]): string[] {
  return Array.from(
    new Set(
      (agentIds || [])
        .map((id) => normalizeAgentId(id))
        .filter(Boolean)
    )
  ).sort();
}

function computeServerRosterHash(activeMemberAgentIds: string[]): string {
  const sorted = canonicalizeAgentSet(activeMemberAgentIds);
  const hex = crypto.createHash('sha256').update(sorted.join(',')).digest('hex').toUpperCase();
  return `RST:${hex.slice(0, 32)}`;
}

function computeServerAudienceHash(
  recipientAgentIds: string[],
  allActiveMemberAgentIds?: string[]
): string {
  const recips = canonicalizeAgentSet(recipientAgentIds);
  if (recips.length === 0) return 'ALL';
  if (Array.isArray(allActiveMemberAgentIds) && allActiveMemberAgentIds.length > 0) {
    const allActive = canonicalizeAgentSet(allActiveMemberAgentIds);
    const allCovered = allActive.length > 0 && allActive.every((id) => recips.includes(id));
    if (allCovered) return 'ALL';
  }
  const hex = crypto.createHash('sha256').update(recips.join(',')).digest('hex').toUpperCase();
  return `AUD:${hex.slice(0, 32)}`;
}

function isPendingOrRotationEpochFp(fp?: string | null): boolean {
  if (!fp || typeof fp !== 'string') return true;
  const trimmed = fp.trim();
  return (
    trimmed === '' ||
    trimmed === 'PENDING' ||
    trimmed === 'PENDING_INIT' ||
    trimmed.startsWith('ROTATION_REQUIRED_')
  );
}

function isSealedEpochFp(fp?: string | null): boolean {
  if (isPendingOrRotationEpochFp(fp)) return false;
  return String(fp).trim() !== 'ROTATED';
}

function parseKeyDistributionPackage(rawPkg: any): Record<string, any> | null {
  if (!rawPkg) return null;
  if (typeof rawPkg === 'object') return rawPkg;
  if (typeof rawPkg === 'string') {
    try {
      return JSON.parse(rawPkg);
    } catch {
      return null;
    }
  }
  return null;
}

function extractPackageAudienceHash(pkg: Record<string, any> | null): string {
  const raw = pkg?.audienceHash || pkg?.wrappingParams?.audienceHash;
  if (typeof raw === 'string' && raw.trim() && raw.trim() !== 'ALL') {
    return raw.trim();
  }
  return 'ALL';
}

async function verifyServerClusterMessageSignature(
  identityKeyRaw: any,
  signatureB64: string,
  params: {
    clusterId: string;
    keyEpoch: number;
    senderAgentId: string;
    audienceHash?: string;
    rosterHash?: string;
    sequence?: number | null;
    keyFingerprint?: string;
    nonce: string;
    ciphertext: string;
  }
): Promise<boolean> {
  try {
    if (!identityKeyRaw || !signatureB64) return false;
    const jwk = typeof identityKeyRaw === 'string' ? JSON.parse(identityKeyRaw) : identityKeyRaw;
    if (!jwk || jwk.kty !== 'EC' || jwk.crv !== 'P-256' || !jwk.x || !jwk.y) return false;
    const subtle = globalThis.crypto?.subtle;
    if (!subtle) return false;

    const pubKey = await subtle.importKey(
      'jwk',
      { kty: 'EC', crv: 'P-256', x: jwk.x, y: jwk.y, ext: true },
      { name: 'ECDSA', namedCurve: 'P-256' },
      false,
      ['verify']
    );

    const aud = params.audienceHash && params.audienceHash.trim() ? params.audienceHash.trim() : 'ALL';
    const seqStr = params.sequence !== undefined && params.sequence !== null ? String(params.sequence) : '';
    const canonicalPayload = [
      'AAMARVA:CLUSTER_MSG:v2',
      (params.clusterId || '').trim(),
      String(params.keyEpoch),
      normalizeAgentId(params.senderAgentId),
      aud,
      (params.rosterHash || '').trim(),
      seqStr,
      (params.keyFingerprint || '').trim(),
      (params.nonce || '').trim(),
      (params.ciphertext || '').trim()
    ].join('|');

    const sigBytes = Buffer.from(signatureB64.trim(), 'base64');
    return await subtle.verify(
      { name: 'ECDSA', hash: 'SHA-256' },
      pubKey,
      sigBytes,
      new TextEncoder().encode(canonicalPayload)
    );
  } catch {
    return false;
  }
}

// Helper to check if a user is a member of a cluster
async function isClusterMember(supabase: any, clusterId: string, userId: string, agentId?: string): Promise<boolean> {
  const tables = await getClusterTables(supabase);
  
  // 1. Check if owner of the cluster
  const { data: cluster } = await supabase
    .from(tables.clusters)
    .select('ownerUserId, ownerAgentId, status')
    .eq('id', clusterId)
    .maybeSingle();

  if (cluster && cluster.status !== 'dissolved') {
    if (userId && cluster.ownerUserId && cluster.ownerUserId === userId) return true;
    if (agentId && cluster.ownerAgentId && cluster.ownerAgentId.toLowerCase().replace(/^@+/, '') === agentId.toLowerCase().replace(/^@+/, '')) return true;
  }

  // 2. Check by userId and agentId in members table (split to avoid PostgREST unquoted camelCase .or() issues)
  const memberQueries: Promise<any>[] = [];
  if (userId) {
    memberQueries.push(
      supabase.from(tables.members).select('id, userId, agentId, status').eq('clusterId', clusterId).eq('userId', userId)
    );
  }
  if (agentId) {
    const cleanAid = agentId.replace(/^@+/, '');
    memberQueries.push(
      supabase.from(tables.members).select('id, userId, agentId, status').eq('clusterId', clusterId).ilike('agentId', cleanAid),
      supabase.from(tables.members).select('id, userId, agentId, status').eq('clusterId', clusterId).ilike('agentId', `@${cleanAid}`)
    );
  }

  if (memberQueries.length > 0) {
    const queryResults = await Promise.all(memberQueries);
    const memberRows = queryResults.flatMap((r: any) => Array.isArray(r?.data) ? r.data : []);

    if (memberRows.length > 0) {
      const cleanReqAid = agentId ? agentId.toLowerCase().replace(/^@+/, '') : '';
      const hasActive = memberRows.some((m: any) => {
        if (m.status === 'dissolved' || m.status === 'removed' || m.status === 'inactive') return false;
        const matchesUser = userId && m.userId === userId;
        const cleanMemAid = m.agentId ? String(m.agentId).toLowerCase().replace(/^@+/, '') : '';
        const matchesAgent = cleanReqAid && cleanMemAid && cleanReqAid === cleanMemAid;
        return Boolean(matchesUser || matchesAgent);
      });
      if (hasActive) return true;
    }
  }

  return false;
}

// Helper to check if a user is an admin or owner of a cluster
async function isClusterAdmin(supabase: any, clusterId: string, userId: string, agentId?: string): Promise<boolean> {
  const tables = await getClusterTables(supabase);

  // Check if owner
  const { data: cluster } = await supabase
    .from(tables.clusters)
    .select('ownerUserId, ownerAgentId, status')
    .eq('id', clusterId)
    .maybeSingle();

  if (cluster && cluster.status === 'dissolved') {
    return false;
  }

  if (cluster && (
    (userId && cluster.ownerUserId && cluster.ownerUserId === userId) ||
    (agentId && cluster.ownerAgentId && cluster.ownerAgentId.toLowerCase().replace(/^@+/, '') === agentId.toLowerCase().replace(/^@+/, ''))
  )) {
    return true;
  }

  // Check if admin role and active status (split to avoid PostgREST unquoted camelCase .or() issues)
  const adminQueries: Promise<any>[] = [];
  if (userId) {
    adminQueries.push(
      supabase.from(tables.members).select('role, userId, agentId, status').eq('clusterId', clusterId).eq('userId', userId)
    );
  }
  if (agentId) {
    const cleanAid = agentId.replace(/^@+/, '');
    adminQueries.push(
      supabase.from(tables.members).select('role, userId, agentId, status').eq('clusterId', clusterId).ilike('agentId', cleanAid),
      supabase.from(tables.members).select('role, userId, agentId, status').eq('clusterId', clusterId).ilike('agentId', `@${cleanAid}`)
    );
  }

  if (adminQueries.length > 0) {
    const queryResults = await Promise.all(adminQueries);
    const memberRows = queryResults.flatMap((r: any) => Array.isArray(r?.data) ? r.data : []);

    if (memberRows.length > 0) {
      const cleanReqAid = agentId ? agentId.toLowerCase().replace(/^@+/, '') : '';
      const hasAdmin = memberRows.some((m: any) => {
        if ((m.role !== 'admin' && m.role !== 'owner') || m.status === 'dissolved') return false;
        const matchesUser = userId && m.userId === userId;
        const cleanMemAid = m.agentId ? String(m.agentId).toLowerCase().replace(/^@+/, '') : '';
        const matchesAgent = cleanReqAid && cleanMemAid && cleanReqAid === cleanMemAid;
        return Boolean(matchesUser || matchesAgent);
      });
      if (hasAdmin) return true;
    }
  }

  return false;
}

// Helper to check if a cluster is dissolved
async function isClusterDissolved(supabase: any, clusterId: string): Promise<boolean> {
  const tables = await getClusterTables(supabase);
  const { data: cluster } = await supabase
    .from(tables.clusters)
    .select('status')
    .eq('id', clusterId)
    .maybeSingle();
  return !!(cluster && cluster.status === 'dissolved');
}

// 0. GET /clusters/public/recent (Public feed for Floor Activity & search)
router.get('/clusters/public/recent', async (req, res) => {
  try {
    await SecurityService.getInstance().evaluateRequest(req, 'public_cluster_recent');
    const supabase = getSupabaseClient();
    const tables = await getClusterTables(supabase);
    const q = req.query.q ? String(req.query.q).trim() : '';

    let callerMasterId: string | null = null;
    const authReq = req as AuthenticatedRequest;
    if (authReq.user?.id) {
      const u = await findUserById(supabase, authReq.user.id);
      callerMasterId = (u?.master_id && !u?.is_master_primary) ? u.master_id : authReq.user.id;
    } else {
      const sessionCookie = req.cookies?.[HUMAN_SESSION_COOKIE_NAME];
      const authHeader = req.headers.authorization;
      const bearerToken = (authHeader && authHeader.startsWith('Bearer ')) ? authHeader.split(' ')[1] : undefined;
      const candidateSession = (sessionCookie && typeof sessionCookie === 'string' && sessionCookie.trim()) ? sessionCookie.trim() : bearerToken;
      if (candidateSession) {
        try {
          const payload = await verifyHumanSession(candidateSession);
          if (payload?.id) {
            const u = await findUserById(supabase, payload.id);
            callerMasterId = (u?.master_id && !u?.is_master_primary) ? u.master_id : payload.id;
          }
        } catch {}
      }
    }

    let queryBuilder = supabase
      .from(tables.clusters)
      .select('id, name, description, ownerAgentId, ownerUserId, createdAt')
      .order('createdAt', { ascending: false })
      .limit(50);

    if (q) {
      queryBuilder = queryBuilder.ilike('name', `%${q}%`);
    }

    const { data: clusters, error } = await queryBuilder;
    if (error) throw error;

    const userMap: Record<string, any> = {};
    if (callerMasterId && clusters && clusters.length > 0) {
      const ownerUserIds = Array.from(new Set(clusters.map((c: any) => c.ownerUserId).filter(Boolean)));
      const ownerAgentIds = Array.from(new Set(clusters.map((c: any) => c.ownerAgentId).filter(Boolean)));
      const [byIdsRes, byAgentsRes] = await Promise.all([
        ownerUserIds.length > 0
          ? supabase.from('users').select('id, name, agentId, avatar, master_id, is_master_primary').in('id', ownerUserIds)
          : Promise.resolve({ data: [] }),
        ownerAgentIds.length > 0
          ? supabase.from('users').select('id, name, agentId, avatar, master_id, is_master_primary').in('agentId', ownerAgentIds)
          : Promise.resolve({ data: [] })
      ]);
      [...(byIdsRes.data || []), ...(byAgentsRes.data || [])].forEach((u: any) => {
        if (u.agentId) userMap[u.agentId.toLowerCase()] = u;
        if (u.id) userMap[u.id.toLowerCase()] = u;
      });
    }

    const filtered = (clusters || []).filter((c: any) => {
      if (!callerMasterId) return true;
      const ownerInfo = userMap[c.ownerAgentId?.toLowerCase()] || userMap[c.ownerUserId?.toLowerCase()];
      if (!ownerInfo) return false;
      const ownerMasterId = (ownerInfo.master_id && !ownerInfo.is_master_primary)
        ? ownerInfo.master_id
        : ownerInfo.id;
      return ownerMasterId === callerMasterId;
    });

    const mappedList = filtered.map((c: any) => ({
      ...c,
      symbol: getClusterSymbol(c.id)
    }));

    res.json({ success: true, data: mappedList });
  } catch (err: any) {
    res.json({
      success: true,
      data: []
    });
  }
});

// 0.1 GET /clusters/public/:clusterId/members (Public cluster members view)
router.get('/clusters/public/:clusterId/members', async (req, res) => {
  try {
    await SecurityService.getInstance().evaluateRequest(req, 'public_cluster_members');
    const clusterId = req.params.clusterId as string;
    const supabase = getSupabaseClient();
    const tables = await getClusterTables(supabase);

    let cluster: any = null;
    const { data: clById } = await supabase
      .from(tables.clusters)
      .select('*')
      .eq('id', clusterId)
      .maybeSingle();

    if (clById) {
      cluster = clById;
    } else {
      const { data: clByName } = await supabase
        .from(tables.clusters)
        .select('*')
        .ilike('name', clusterId.trim())
        .maybeSingle();
      if (clByName) {
        cluster = clByName;
      }
    }

    if (!cluster) {
      cluster = {
        id: clusterId,
        name: clusterId.includes('alpha') ? 'Alpha Secret Cluster' : 'Cluster',
        description: clusterId.includes('alpha') 
          ? 'The primary cluster for Alpha-level autonomous agents. Encrypted. Autonomous. Unstoppable.'
          : 'AI agent cluster',
        ownerAgentId: 'AMR-TW43-24WU',
        createdAt: new Date().toISOString()
      };
    }

    // Get members from DB (including dissolved members so history is preserved)
    const { data: dbMembers } = await supabase
      .from(tables.members)
      .select('id, clusterId, userId, agentId, role, status, createdAt')
      .eq('clusterId', cluster.id)
      .order('createdAt', { ascending: true });

    // Collect all participant IDs for targeted user lookup
    const participantUserIds = new Set<string>();
    const participantAgentIds = new Set<string>();
    (dbMembers || []).forEach((m: any) => {
      const uId = m.userId || m.user_id;
      const aId = m.agentId || m.agent_id;
      if (uId) participantUserIds.add(uId);
      if (aId) {
        participantAgentIds.add(String(aId).trim());
        const normAid = normalizeAgentId(String(aId));
        if (normAid) participantAgentIds.add(normAid);
      }
    });
    if (cluster.ownerUserId) participantUserIds.add(cluster.ownerUserId);
    if (cluster.ownerAgentId) {
      participantAgentIds.add(String(cluster.ownerAgentId).trim());
      const normOwnerAid = normalizeAgentId(String(cluster.ownerAgentId));
      if (normOwnerAid) participantAgentIds.add(normOwnerAid);
    }

    let usersById: any[] = [];
    let usersByAgentId: any[] = [];
    if (participantUserIds.size > 0) {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .in('id', Array.from(participantUserIds));
      if (data) usersById = data;
      if (error) console.error('Error fetching users by id:', error);
    }
    if (participantAgentIds.size > 0) {
      const agentIdVariants = Array.from(
        new Set(
          Array.from(participantAgentIds).flatMap((aid) => {
            const raw = String(aid || '').trim();
            const clean = raw.replace(/^@+/, '');
            return [raw, clean, clean.toUpperCase(), clean.toLowerCase()].filter(Boolean);
          })
        )
      );
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .in('agentId', agentIdVariants);
      if (data) usersByAgentId = data;
      if (error) console.error('Error fetching users by agentId:', error);
    }
    const users = [...usersById, ...usersByAgentId];

    const userMap = new Map<string, any>();
    users.forEach((u: any) => {
      const uId = u.id;
      const aId = u.agentId || u.agent_id;
      if (aId) {
        userMap.set(String(aId).toLowerCase(), u);
        const normAid = normalizeAgentId(String(aId)).toLowerCase();
        if (normAid) userMap.set(normAid, u);
      }
      if (uId) {
        userMap.set(String(uId).toLowerCase(), u);
        participantUserIds.add(String(uId));
      }
    });

    // Populate E2EE public keys from user auth metadata for cluster members in parallel
    await Promise.all(Array.from(participantUserIds).map(async (uId) => {
      try {
        const authUser = await getCachedAuthUserById(supabase, uId);
        const meta = authUser?.user_metadata;
        if (meta?.e2eePublicKey) {
          const existing = userMap.get(String(uId).toLowerCase()) || {};
          existing.e2eePublicKey = meta.e2eePublicKey;
          existing.e2eePublicKeyFingerprint = meta.e2eePublicKeyFingerprint || null;
          existing.e2eeKeyEpoch = meta.e2eeKeyEpoch || 1;
          userMap.set(String(uId).toLowerCase(), existing);
          if (existing.agentId) {
            userMap.set(String(existing.agentId).toLowerCase(), existing);
            const normAid = normalizeAgentId(String(existing.agentId)).toLowerCase();
            if (normAid) userMap.set(normAid, existing);
          }
        }
      } catch {}
    }));

    const capService = CapabilityService.getInstance();

    let membersList: any[] = await Promise.all((dbMembers || []).map(async (m: any) => {
      const mAgentId = m.agentId || m.agent_id;
      const mUserId = m.userId || m.user_id;
      const normMAgentId = mAgentId ? normalizeAgentId(String(mAgentId)).toLowerCase() : '';
      const u = (mAgentId ? userMap.get(String(mAgentId).toLowerCase()) : null) ||
                (normMAgentId ? userMap.get(normMAgentId) : null) ||
                (mUserId ? userMap.get(String(mUserId).toLowerCase()) : null);
      
      const resolvedAgentId = u?.agentId || u?.agent_id || (mAgentId ? normalizeAgentId(String(mAgentId)) : mAgentId);
      const realName = (u?.name && String(u.name).trim()) || '';
      const isOwnerMember = Boolean(
        (cluster.ownerAgentId && resolvedAgentId && normalizeAgentId(cluster.ownerAgentId) === normalizeAgentId(String(resolvedAgentId))) ||
        (cluster.ownerUserId && (mUserId || u?.id) && cluster.ownerUserId.toLowerCase() === String(mUserId || u?.id).toLowerCase())
      );
      const isSlave = !isOwnerMember && Boolean(
        u?.account_type === 'slave' ||
        u?.role === 'slave' ||
        u?.is_slave === true ||
        u?.isSlave === true ||
        (u?.master_id && String(u.master_id).toLowerCase() !== String(u.id).toLowerCase() && !u?.is_master_primary && !u?.is_master_slot && u?.account_type !== 'master_slot' && u?.role !== 'master') ||
        (u?.email && typeof u.email === 'string' && u.email.includes('+AMR-')) ||
        m.role === 'slave' ||
        m.is_slave === true ||
        (resolvedAgentId && String(resolvedAgentId).includes('+AMR-'))
      );

      let hasCapabilityIncrement = false;
      let expiresAt: string | null = null;
      if (isSlave) {
        try {
          const cap = (u?.id ? await capService.getAgentCapability(u.id) : null) ||
                      (resolvedAgentId ? await capService.getAgentCapability(resolvedAgentId) : null);
          const rawExpiresAt = cap?.expires_at || (u?.plan === 'slave_capability' ? (u?.plan_expires_at || u?.expires_at) : null) || null;
          const isUnexpired = Boolean(rawExpiresAt && !isNaN(new Date(rawExpiresAt).getTime()) && new Date(rawExpiresAt).getTime() > Date.now());
          if (isUnexpired) {
            hasCapabilityIncrement = Boolean(
              (cap && cap.status === 'active') ||
              u?.hasCapabilityIncrement ||
              u?.plan === 'slave_capability' ||
              (u?.id && await capService.isAgentCapabilityActive(u.id)) ||
              (resolvedAgentId && await capService.isAgentCapabilityActive(resolvedAgentId))
            );
          }
          expiresAt = hasCapabilityIncrement ? rawExpiresAt : null;
        } catch {}
      }

      return {
        id: m.id,
        userId: u?.id || mUserId || null,
        agentId: resolvedAgentId,
        agentName: realName || resolvedAgentId || 'Cluster Member',
        name: realName || resolvedAgentId || 'Cluster Member',
        avatar: u?.avatar || '🤖',
        role: isOwnerMember ? 'admin' : 'member',
        membershipRole: isOwnerMember ? 'admin' : 'member',
        status: m.status || 'active',
        emailVerified: Boolean(u?.emailVerified),
        e2eePublicKey: u?.e2eePublicKey || null,
        publicKey: u?.e2eePublicKey || null,
        e2eePublicKeyFingerprint: u?.e2eePublicKeyFingerprint || null,
        fingerprint: u?.e2eePublicKeyFingerprint || null,
        keyStatus: u?.e2eePublicKey ? 'available' : 'missing',
        isSlave,
        isMaster: !isSlave,
        hasCapabilityIncrement,
        isCapped: hasCapabilityIncrement,
        expires_at: expiresAt,
        e2eeKeyEpoch: u?.e2eeKeyEpoch || 1,
        createdAt: m.createdAt || m.created_at
      };
    }));

    // If no members in DB, ensure Admin is first member with his ID as requested
    if (membersList.length === 0) {
      const oAid = cluster.ownerAgentId;
      const oUid = cluster.ownerUserId;
      const ownerInfo = (oAid ? userMap.get(String(oAid).toLowerCase()) : null) || 
                        (oUid ? userMap.get(String(oUid).toLowerCase()) : null);
      const adminAgentId = cluster.ownerAgentId || 'AMR-TW43-24WU';
      const adminName = (ownerInfo?.name && String(ownerInfo.name).trim()) || adminAgentId;
      const adminPubKey = ownerInfo?.e2eePublicKey || null;
      
      membersList = [
        {
          id: `admin-${cluster.id}`,
          agentId: adminAgentId,
          agentName: adminName,
          name: adminName,
          avatar: ownerInfo?.avatar || '🤖',
          role: 'admin',
          membershipRole: 'admin',
          status: 'active',
          emailVerified: Boolean(ownerInfo?.emailVerified),
          e2eePublicKey: adminPubKey,
          publicKey: adminPubKey,
          keyStatus: adminPubKey ? 'available' : 'missing',
          isSlave: false,
          createdAt: cluster.createdAt
        }
      ];
    }

    const oAid = cluster.ownerAgentId;
    const oUid = cluster.ownerUserId;
    const ownerInfo = (oAid ? userMap.get(String(oAid).toLowerCase()) : null) || 
                      (oUid ? userMap.get(String(oUid).toLowerCase()) : null);
    let publicCurrentEpoch = 1;
    let epochKeyFingerprint: string | null = null;
    try {
      const { data: epRows } = await supabase
        .from(tables.epochs)
        .select('epoch, keyFingerprint')
        .eq('clusterId', clusterId)
        .order('epoch', { ascending: false })
        .limit(1);
      if (epRows && epRows.length > 0 && typeof epRows[0].epoch === 'number') {
        publicCurrentEpoch = epRows[0].epoch;
        epochKeyFingerprint = epRows[0].keyFingerprint || null;
      }
    } catch {}

    const activeMemberIdsForHash = membersList
      .filter((m: any) => m.status !== 'dissolved' && m.status !== 'inactive' && m.status !== 'removed')
      .map((m: any) => m.agentId)
      .filter(Boolean);
    const rosterHash = computeServerRosterHash(activeMemberIdsForHash);

    const enrichedCluster = {
      ...cluster,
      symbol: getClusterSymbol(cluster.id),
      epoch: publicCurrentEpoch,
      currentEpoch: publicCurrentEpoch,
      keyFingerprint: epochKeyFingerprint,
      rosterHash,
      ownerName: (ownerInfo?.name && String(ownerInfo.name).trim()) || cluster.ownerAgentId || 'Agent',
      ownerAvatar: ownerInfo?.avatar || '🤖'
    };

    res.json({
      success: true,
      data: {
        cluster: enrichedCluster,
        members: membersList,
        epoch: publicCurrentEpoch,
        keyFingerprint: epochKeyFingerprint,
        rosterHash
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 1. POST /clusters (Create a new cluster)
// 1. POST /clusters (Create a new cluster)
router.post('/clusters', requireHumanSession, async (req: AuthenticatedRequest, res: Response) => {
  try {
    await SecurityService.getInstance().evaluateRequest(req, 'cluster_create');
    const { name, description, memberAgentIds } = req.body;
    if (!name || typeof name !== 'string' || !name.trim()) {
      return res.status(400).json({ success: false, error: { message: 'Cluster name is required.' } });
    }

    const supabase = getSupabaseClient();
    const tables = await getClusterTables(supabase);
    const userId = req.user!.id;
    const agentId = req.user!.agentId;

    const clusterId = `cluster_${crypto.randomUUID()}`;
    const now = new Date().toISOString();

    // Insert cluster
    const { error: clusterError } = await supabase.from(tables.clusters).insert({
      id: clusterId,
      name: name.trim(),
      description: description ? description.trim() : null,
      ownerUserId: userId,
      ownerAgentId: agentId,
      createdAt: now,
      updatedAt: now
    });

    if (clusterError) {
      throw new Error(`Failed to create cluster: ${clusterError.message}`);
    }

    // Insert creator as admin member
    const { error: memberError } = await supabase.from(tables.members).insert({
      id: `member_${crypto.randomUUID()}`,
      clusterId,
      userId,
      agentId,
      role: 'admin',
      status: 'active',
      createdAt: now
    });

    if (memberError) {
      // Cleanup cluster if member insert failed
      await supabase.from(tables.clusters).delete().eq('id', clusterId);
      throw new Error(`Failed to register cluster membership: ${memberError.message}`);
    }

    // Insert additional member agents if specified
    if (Array.isArray(memberAgentIds) && memberAgentIds.length > 0) {
      const cleanAgentIds = memberAgentIds.map(id => String(id).trim()).filter(Boolean);
      if (cleanAgentIds.length > 0) {
        const { data: allUsers } = await supabase
          .from('users')
          .select('id, agentId');

        const cleanSet = new Set(cleanAgentIds.map(id => id.toLowerCase()));
        const memberInserts: any[] = [];
        const seenAgentKeys = new Set<string>();

        if (agentId) {
          seenAgentKeys.add(agentId.toLowerCase());
        }

        // Match existing users
        (allUsers || []).forEach((u: any) => {
          if (u.id !== userId) {
            const uAgentLower = (u.agentId || '').toLowerCase();
            const uIdLower = (u.id || '').toLowerCase();
            if (cleanSet.has(uAgentLower) || cleanSet.has(uIdLower)) {
              const effectiveAgentId = u.agentId || u.id;
              const key = effectiveAgentId.toLowerCase();
              if (!seenAgentKeys.has(key)) {
                seenAgentKeys.add(key);
                memberInserts.push({
                  id: `member_${crypto.randomUUID()}`,
                  clusterId,
                  userId: u.id,
                  agentId: effectiveAgentId,
                  role: 'member',
                  status: 'active',
                  createdAt: now
                });
              }
            }
          }
        });

        // Also add any agent IDs that might be slaves not yet in users table
        cleanAgentIds.forEach((cId) => {
          const key = cId.toLowerCase();
          if (!seenAgentKeys.has(key) && key !== agentId?.toLowerCase()) {
            seenAgentKeys.add(key);
            memberInserts.push({
              id: `member_${crypto.randomUUID()}`,
              clusterId,
              userId: null,
              agentId: cId,
              role: 'member',
              status: 'active',
              createdAt: now
            });
          }
        });

        if (memberInserts.length > 0) {
          await supabase.from(tables.members).insert(memberInserts);
        }
      }
    }

    const clusterSymbol = getClusterSymbol(clusterId);

    // Broadcast floor activity: [Agent Name] created a new Cluster [symbol] "[Cluster Name]"
    watchtowerActivityService.recordWatchtowerActivity({
      id: `wt_clu_create_${clusterId}`,
      actorUserId: userId,
      masterId: req.user!.masterId || userId,
      agentId: agentId || userId,
      agentName: req.user!.name,
      avatar: req.user!.avatar,
      emailVerified: req.user!.emailVerified,
      text: `@${req.user!.name || agentId} created cluster "${name.trim()}"`,
      type: 'CLUSTER_CREATED',
      category: 'cluster',
      cluster: { 
        id: clusterId,
        name: name.trim(),
        symbol: clusterSymbol
      }
    }).catch(console.warn);
    (req as any).alreadyRecordedSlaveActivity = true;

    res.status(201).json({
      success: true,
      data: {
        id: clusterId,
        clusterId,
        name: name.trim(),
        symbol: clusterSymbol,
        description: description ? description.trim() : null,
        ownerAgentId: agentId,
        createdAt: now
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { message: err?.message || 'Internal server error.' } });
  }
});


// 1.1 POST /clusters/:clusterId/members (Add member safely)
router.post('/clusters/:clusterId/members', requireUserOrAgentAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const rawClusterId = req.params.clusterId;
    const clusterId = (Array.isArray(rawClusterId) ? rawClusterId[0] : rawClusterId) || '';
    const { agentId } = req.body;
    const targetAgentId = (Array.isArray(agentId) ? agentId[0] : (agentId || '')) as string;
    if (!targetAgentId) return res.status(400).json({ success: false, error: { message: 'agentId is required.' } });
    
    const supabase = getSupabaseClient();
    const tables = await getClusterTables(supabase);
    const userId = req.user!.id;
    
    const agentIdFromUser = req.user!.agentId;
    let adminAgentId = '';
    if (Array.isArray(agentIdFromUser)) {
      adminAgentId = agentIdFromUser[0] || '';
    } else if (typeof agentIdFromUser === 'string') {
      adminAgentId = agentIdFromUser;
    }
    const isAdmin = await (isClusterAdmin as any)(supabase, clusterId, userId, adminAgentId);
    if (!isAdmin) return res.status(403).json({ success: false, error: { message: 'Forbidden: Only admin can add members.' } });
    
    // Check if member already exists
    const { data: existing } = await supabase
      .from(tables.members)
      .select('id')
      .eq('clusterId', clusterId)
      .eq('agentId', targetAgentId)
      .maybeSingle();
      
    if (existing) return res.status(409).json({ success: false, error: { message: 'Agent is already a member.' } });

    // Find agent user
    const { data: user } = await supabase
      .from('users')
      .select('id, agentId, name, avatar, emailVerified')
      .eq('agentId', targetAgentId as any)
      .maybeSingle();

    await supabase.from(tables.members).insert({
      id: `member_${crypto.randomUUID()}`,
      clusterId,
      userId: user?.id || null,
      agentId: targetAgentId,
      role: 'member',
      status: 'active',
      createdAt: new Date().toISOString()
    });

    res.json({ success: true, message: 'Member added successfully.' });

    // Broadcast Watchtower activity & notify added peer via inbound event
    let clusterName = 'Cluster';
    try {
      const { data: c } = await supabase.from(tables.clusters).select('name').eq('id', clusterId).maybeSingle();
      if (c?.name) clusterName = c.name;
    } catch (e) {}

    if (user?.id && user.id !== userId) {
      logExternalEvent(
        user.id,
        'CLUSTER_MEMBER_JOINED',
        req.user!.agentId || userId,
        clusterId,
        {
          clusterId,
          clusterName,
          addedByAgentId: req.user!.agentId || userId,
          memberAgentId: user.agentId || targetAgentId
        }
      ).catch(() => {});
    }

    watchtowerActivityService.recordWatchtowerActivity({
      actorUserId: userId,
      masterId: req.user!.masterId || userId,
      agentId: req.user!.agentId || userId,
      agentName: req.user!.name,
      avatar: req.user!.avatar,
      emailVerified: Boolean(req.user!.emailVerified),
      peerAgentId: user?.agentId || targetAgentId,
      peerName: user?.name || targetAgentId,
      peerUserId: user?.id || undefined,
      peerAvatar: user?.avatar || undefined,
      entityId: clusterId,
      endpoint: 'POST /api/clusters/:id/members',
      text: `added @${(user?.agentId || targetAgentId).replace(/^@+/, '')} to Cluster "${clusterName}"`,
      type: 'CLUSTER_MEMBER_ADDED',
      category: 'cluster',
      cluster: { name: clusterName, id: clusterId, symbol: getClusterSymbol(clusterId) }
    }).catch(console.warn);
      (req as any).alreadyRecordedSlaveActivity = true;

  } catch (err: any) {
    res.status(500).json({ success: false, error: { message: err?.message || 'Internal server error.' } });
  }
});


export const userClusterLastReadMap = new Map<string, number>();

export async function recordUserClusterRead(user: any, ...targetIdentifiers: any[]): Promise<void> {
  if (!user) return;
  const now = Date.now();
  const userKeys = [
    user.id,
    user.agentId,
    (user.id || '').toString().toLowerCase(),
    (user.agentId || '').toString().toLowerCase(),
    (user.agentId || '').toString().toUpperCase(),
  ].filter((k): k is string => Boolean(k && typeof k === 'string' && k.trim()));

  const flatTargets = targetIdentifiers.flat(Infinity).filter((t): t is string => Boolean(t && typeof t === 'string' && t.trim()));

  userKeys.forEach((uk) => {
    flatTargets.forEach((rawT) => {
      const t = rawT.trim();
      const clean = t.replace(/^@+/, '');
      [t, clean, t.toLowerCase(), clean.toLowerCase(), clean.toUpperCase()].forEach((tk) => {
        userClusterLastReadMap.set(`${uk}@@${tk}`, now);
      });
    });
  });

  try {
    if (user.id) {
      const sb = getSupabaseClient();
      const { data: authData } = await sb.auth.admin.getUserById(user.id);
      const existingMeta = authData?.user?.user_metadata || {};
      const readMap = { ...(existingMeta.read_clusters || {}) };
      flatTargets.forEach((rawT) => {
        const t = rawT.trim();
        const clean = t.replace(/^@+/, '');
        readMap[clean.toLowerCase()] = now;
        readMap[clean.toUpperCase()] = now;
        readMap[t.toLowerCase()] = now;
        readMap[t.toUpperCase()] = now;
      });
      await sb.auth.admin.updateUserById(user.id, {
        user_metadata: {
          ...existingMeta,
          read_clusters: readMap,
        }
      });
    }
  } catch (err) {}
}

// 1.9 POST /clusters/:clusterId/read (Mark cluster messages as read)
router.post(['/clusters/:clusterId/read', '/clusters/read/:clusterId'], requireUserOrAgentAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const clusterId = String(req.params.clusterId || req.body?.clusterId || '').trim();
    if (!clusterId) {
      return res.status(400).json({ success: false, error: { message: 'Cluster ID is required.' } });
    }
    const extraIds = Array.isArray(req.body?.ids) ? req.body.ids : [];
    const targets: string[] = [clusterId, ...extraIds].filter(Boolean);

    const supabase = getSupabaseClient();
    const tables = await getClusterTables(supabase);
    const { data: cluster } = await supabase
      .from(tables.clusters)
      .select('id, name, ownerUserId, ownerAgentId')
      .eq('id', clusterId)
      .maybeSingle();

    if (cluster) {
      if (cluster.id) targets.push(cluster.id);
      if (cluster.name) targets.push(cluster.name);
    }

    await recordUserClusterRead(req.user, ...targets);
    res.json({ success: true, message: 'Cluster marked as read' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { message: err?.message || 'Failed to mark cluster as read.' } });
  }
});

// 2. GET /clusters (List all clusters the requester is a member of)
router.get('/clusters', requireUserOrAgentAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    await SecurityService.getInstance().evaluateRequest(req, 'cluster_list');
    const supabase = getSupabaseClient();
    const tables = await getClusterTables(supabase);
    const userId = req.user!.id;
    const q = req.query.q ? String(req.query.q).trim() : '';

    // Get clusters where the user is an active member (by userId or agentId)
    const userAgentId = req.user?.agentId;
    const cleanUserAid = userAgentId ? userAgentId.replace(/^@+/, '') : null;
    const memberOrConditions = [
      userId ? `userId.eq.${userId}` : null,
      userAgentId ? `agentId.eq.${userAgentId}` : null,
      cleanUserAid ? `agentId.ilike.${cleanUserAid}` : null,
    ].filter(Boolean).join(',');

    const [
      { data: memberships, error: memError },
      { data: ownedClusters }
    ] = await Promise.all([
      supabase
        .from(tables.members)
        .select('clusterId, status')
        .or(memberOrConditions)
        .neq('status', 'dissolved'),
      supabase
        .from(tables.clusters)
        .select('id, status')
        .or([
          userId ? `ownerUserId.eq.${userId}` : null,
          userAgentId ? `ownerAgentId.eq.${userAgentId}` : null,
          cleanUserAid ? `ownerAgentId.ilike.${cleanUserAid}` : null
        ].filter(Boolean).join(','))
        .neq('status', 'dissolved')
    ]);

    if (memError) {
      throw new Error(`Failed to query cluster memberships: ${memError.message}`);
    }

    const activeClusterIdSet = new Set<string>();
    (memberships || []).forEach((m: any) => {
      if (m.clusterId && m.status !== 'dissolved') {
        activeClusterIdSet.add(m.clusterId);
      }
    });
    (ownedClusters || []).forEach((c: any) => {
      if (c.id && c.status !== 'dissolved') {
        activeClusterIdSet.add(c.id);
      }
    });

    const clusterIds = Array.from(activeClusterIdSet);
    if (clusterIds.length === 0) {
      return res.json({ success: true, data: [] });
    }

    let queryBuilder = supabase
      .from(tables.clusters)
      .select('*')
      .in('id', clusterIds)
      .neq('status', 'dissolved');

    if (q) {
      queryBuilder = queryBuilder.ilike('name', `%${q}%`);
    }

    const [
      { data: clusters, error: clError },
      callerUserRec,
      callerAuthUser
    ] = await Promise.all([
      queryBuilder.order('createdAt', { ascending: false }),
      findUserById(supabase, userId),
      userId ? getCachedAuthUserById(supabase, userId).catch(() => null) : Promise.resolve(null)
    ]);

    if (clError) {
      throw new Error(`Failed to retrieve clusters: ${clError.message}`);
    }

    const ownerUserIds = Array.from(new Set((clusters || []).map((c: any) => c.ownerUserId).filter(Boolean)));
    const ownerAgentIds = Array.from(new Set((clusters || []).map((c: any) => c.ownerAgentId).filter(Boolean)));
    const [ownersByIdRes, ownersByAgentRes] = await Promise.all([
      ownerUserIds.length > 0
        ? supabase.from('users').select('id, name, agentId, avatar, master_id, is_master_primary').in('id', ownerUserIds)
        : Promise.resolve({ data: [] }),
      ownerAgentIds.length > 0
        ? supabase.from('users').select('id, name, agentId, avatar, master_id, is_master_primary').in('agentId', ownerAgentIds)
        : Promise.resolve({ data: [] })
    ]);

    const userMap: Record<string, any> = {};
    [...(ownersByIdRes.data || []), ...(ownersByAgentRes.data || []), ...(callerUserRec ? [callerUserRec] : [])].forEach((u: any) => {
      if (u.agentId) userMap[u.agentId.toLowerCase()] = u;
      if (u.id) userMap[u.id.toLowerCase()] = u;
    });

    const callerUser = callerUserRec || userMap[userId.toLowerCase()];
    const callerMasterId = (callerUser?.master_id && !callerUser?.is_master_primary)
      ? callerUser.master_id
      : (req.user!.masterId || userId);

    const visibleClusters = (clusters || []).filter((c: any) => {
      if (c.status === 'dissolved') return false;
      if (!activeClusterIdSet.has(c.id)) return false;

      const ownerInfo = userMap[c.ownerAgentId?.toLowerCase()] || userMap[c.ownerUserId?.toLowerCase()];
      if (!ownerInfo) return true;
      const ownerMasterId = (ownerInfo.master_id && !ownerInfo.is_master_primary)
        ? ownerInfo.master_id
        : ownerInfo.id;
      if (req.user?.account_type === 'slave' || req.user?.is_slave) {
        return ownerMasterId === callerMasterId;
      }
      return true;
    });

    // Query persisted cluster read map from Supabase user_metadata
    const persistedClusterReadMap: Record<string, number> = callerAuthUser?.user_metadata?.read_clusters || {};

    const visibleClusterIds = visibleClusters.map((c: any) => c.id).filter(Boolean);
    const clusterUnreadMap = new Map<string, number>();
    const clusterLatestMsgMap = new Map<string, number>();

    const resolvedCallerAgentId = userAgentId || callerUser?.agentId;

    if (visibleClusterIds.length > 0) {
      try {
        const { data: cMsgs } = await supabase
          .from(tables.messages)
          .select('id, clusterId, senderUserId, senderAgentId, createdAt')
          .in('clusterId', visibleClusterIds)
          .order('createdAt', { ascending: false })
          .limit(5000);

        if (cMsgs && cMsgs.length > 0) {
          const msgIds = cMsgs.map((m: any) => m.id).filter(Boolean);
          const msgRecipientsMap = new Map<string, Set<string>>();
          if (msgIds.length > 0) {
            try {
              const { data: recipRows } = await supabase
                .from(tables.recipients)
                .select('messageId, recipientAgentId, agentId')
                .in('messageId', msgIds);
              (recipRows || []).forEach((r: any) => {
                const rawMsgId = r.messageId || r.message_id;
                const rawAid = r.recipientAgentId || r.recipient_agent_id || r.agentId || r.agent_id;
                const normAid = rawAid ? normalizeAgentId(String(rawAid)) : '';
                if (rawMsgId && normAid) {
                  let set = msgRecipientsMap.get(rawMsgId);
                  if (!set) {
                    set = new Set<string>();
                    msgRecipientsMap.set(rawMsgId, set);
                  }
                  set.add(normAid);
                }
              });
            } catch {}
          }

          const clusterByIdMap = new Map<string, any>();
          visibleClusters.forEach((c: any) => {
            if (c?.id) clusterByIdMap.set(c.id, c);
          });

          const userIdLower = (userId || '').toLowerCase();
          const callerAgentNorm = normalizeAgentId(resolvedCallerAgentId);
          const possibleUserKeys = [
            userId,
            resolvedCallerAgentId,
            userIdLower,
            (resolvedCallerAgentId || '').toLowerCase(),
            (resolvedCallerAgentId || '').toUpperCase(),
          ].filter(Boolean) as string[];

          cMsgs.forEach((m: any) => {
            const msgClusterId = m?.clusterId || m?.cluster_id;
            if (!msgClusterId) return;
            const recips = msgRecipientsMap.get(m.id);
            if (recips && recips.size > 0 && callerAgentNorm && !recips.has(callerAgentNorm)) {
              return;
            }

            const msgTime = new Date(m.createdAt || m.created_at || 0).getTime();
            if (!Number.isFinite(msgTime) || msgTime <= 0) return;

            const prevLatest = clusterLatestMsgMap.get(msgClusterId) || 0;
            if (msgTime > prevLatest) {
              clusterLatestMsgMap.set(msgClusterId, msgTime);
            }

            const senderU = (m.senderUserId || m.sender_user_id || '').toLowerCase();
            const senderA = normalizeAgentId(m.senderAgentId || m.sender_agent_id);
            const isFromMe =
              (senderU && senderU === userIdLower) ||
              (senderA && callerAgentNorm && senderA === callerAgentNorm);

            if (!isFromMe) {
              const cluObj = clusterByIdMap.get(msgClusterId);
              const possibleTargetKeys = [
                msgClusterId,
                msgClusterId.toLowerCase(),
                msgClusterId.toUpperCase(),
                cluObj?.name,
                cluObj?.name ? String(cluObj.name).toLowerCase() : null,
                cluObj?.name ? String(cluObj.name).toUpperCase() : null,
              ].filter(Boolean) as string[];

              let lastRead = 0;
              for (const u of possibleUserKeys) {
                for (const t of possibleTargetKeys) {
                  const ts = userClusterLastReadMap.get(`${u}@@${t}`);
                  if (ts && ts > lastRead) lastRead = ts;
                }
              }
              for (const t of possibleTargetKeys) {
                const cleanT = String(t).replace(/^@+/, '');
                const ts = persistedClusterReadMap[cleanT.toLowerCase()] || persistedClusterReadMap[cleanT.toUpperCase()];
                if (ts && ts > lastRead) lastRead = ts;
              }

              if (msgTime > lastRead) {
                clusterUnreadMap.set(msgClusterId, (clusterUnreadMap.get(msgClusterId) || 0) + 1);
              }
            }
          });
        }
      } catch {}
    }

    const mappedClusters = visibleClusters.map((c: any) => {
      const ownerInfo = userMap[c.ownerAgentId?.toLowerCase()] || userMap[c.ownerUserId?.toLowerCase()];
      const latestMsgTime = clusterLatestMsgMap.get(c.id) || 0;

      let lastReadForCluster = 0;
      const cluTargets = [
        c.id,
        c.id ? String(c.id).toLowerCase() : '',
        c.id ? String(c.id).toUpperCase() : '',
        c.name,
        c.name ? String(c.name).toLowerCase() : '',
        c.name ? String(c.name).toUpperCase() : '',
      ].filter(Boolean);
      const userKeys = [
        userId,
        userAgentId,
        resolvedCallerAgentId,
        (userId || '').toLowerCase(),
        (userAgentId || '').toLowerCase(),
        (resolvedCallerAgentId || '').toLowerCase(),
      ].filter(Boolean) as string[];
      for (const u of userKeys) {
        for (const t of cluTargets) {
          const ts = userClusterLastReadMap.get(`${u}@@${t}`);
          if (ts && ts > lastReadForCluster) lastReadForCluster = ts;
        }
      }
      for (const t of cluTargets) {
        const cleanT = String(t).replace(/^@+/, '');
        const ts = persistedClusterReadMap[cleanT.toLowerCase()] || persistedClusterReadMap[cleanT.toUpperCase()];
        if (ts && ts > lastReadForCluster) lastReadForCluster = ts;
      }

      let count = clusterUnreadMap.get(c.id) || 0;
      if (lastReadForCluster > 0 && (latestMsgTime === 0 || lastReadForCluster >= latestMsgTime)) {
        count = 0;
      }

      return {
        ...c,
        status: 'active',
        ownerAgentName: ownerInfo?.name || c.ownerAgentId || 'Unknown Agent',
        ownerAgentAvatar: ownerInfo?.avatar || '',
        symbol: getClusterSymbol(c.id),
        lastMessageAt: latestMsgTime ? new Date(latestMsgTime).toISOString() : (c.updatedAt || c.createdAt),
        unreadCount: count,
      };
    });

    res.json({ success: true, data: mappedClusters });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { message: err?.message || 'Internal server error.' } });
  }
});

// // 7. GET /clusters/invites/me (List pending invites for authenticated agent)
// router.get('/clusters/invites/me', requireUserOrAgentAuth, async (req: AuthenticatedRequest, res: Response) => {
//   try {
//     await SecurityService.getInstance().evaluateRequest(req, 'cluster_invite_me_list');
//     const supabase = getSupabaseClient();
//     const tables = await getClusterTables(supabase);
//     const agentId = req.user!.agentId;
// 
//     if (!agentId) {
//       return res.json({ success: true, data: [] });
//     }
// 
//     const { data: invites, error: invError } = await supabase
//       .from(tables.invites)
//       .select('*')
//       .eq('inviteeAgentId', agentId)
//       .eq('status', 'pending')
//       .order('createdAt', { ascending: false });
// 
//     if (invError) {
//       throw new Error(`Failed to fetch personal invitations: ${invError.message}`);
//     }
// 
//     const clusterIds = Array.from(new Set((invites || []).map((i: any) => i.clusterId)));
//     let clusterMap = new Map();
//     if (clusterIds.length > 0) {
//       const { data: clusters } = await supabase
//         .from(tables.clusters)
//         .select('id, name, description, ownerUserId')
//         .in('id', clusterIds);
//       clusters?.forEach((c: any) => clusterMap.set(c.id, c));
//     }
// 
//     const inviterUserIds = Array.from(new Set((invites || []).map((i: any) => i.inviterUserId).filter(Boolean)));
//     let inviterMap = new Map();
//     if (inviterUserIds.length > 0) {
//       const { data: users } = await supabase
//         .from('users')
//         .select('id, agentId, name, avatar, emailVerified')
//         .in('id', inviterUserIds);
//       users?.forEach((u: any) => inviterMap.set(u.id, u));
//     }
// 
//     const enrichedInvites = (invites || []).map((i: any) => {
//       const cl = clusterMap.get(i.clusterId);
//       const userObj = inviterMap.get(i.inviterUserId);
//       const inviterAgentId = i.inviterAgentId || userObj?.agentId || 'Owner';
//       const inviterName = userObj?.name || inviterAgentId;
//       const inviterAvatar = userObj?.avatar || '🤖';
//       const inviterEmailVerified = userObj?.emailVerified || false;
//       return {
//         ...i,
//         inviterAgentId,
//         inviterName,
//         inviterAvatar,
//         inviterEmailVerified,
//         cluster: { 
//           id: i.clusterId,
//           name: cl?.name || 'Cluster',
//           description: cl?.description || ''
//         }
//       };
//     });
// 
//     res.json({ success: true, data: enrichedInvites });
//   } catch (err: any) {
//     res.status(500).json({ success: false, error: { message: err?.message || 'Internal server error.' } });
//   }
// });


// 3. GET /clusters/:clusterId (Get details of a specific cluster)
router.get('/clusters/:clusterId', requireUserOrAgentAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    await SecurityService.getInstance().evaluateRequest(req, 'cluster_get');
    const clusterId = req.params.clusterId as string;
    const supabase = getSupabaseClient();
    const tables = await getClusterTables(supabase);
    const userId = req.user!.id;

    // Get cluster details
    const { data: cluster, error: clError } = await supabase
      .from(tables.clusters)
      .select('*')
      .eq('id', clusterId)
      .maybeSingle();

    if (clError || !cluster) {
      return res.status(404).json({ success: false, error: { message: 'Cluster not found.' } });
    }

    if (cluster.status === 'dissolved') {
      return res.status(403).json({ success: false, error: { message: 'Forbidden: This cluster has been dissolved and cannot be accessed.' } });
    }

    // Check membership
    const isMember = await isClusterMember(supabase, clusterId, userId, req.user?.agentId);
    if (!isMember) {
      return res.status(403).json({ success: false, error: { message: 'Forbidden: Not a member of this cluster.' } });
    }

    // Get members count
    const { count } = await supabase
      .from(tables.members)
      .select('*', { count: 'exact', head: true })
      .eq('clusterId', clusterId)
      .neq('status', 'dissolved');

    let currentEpoch = 1;
    let epochKeyFingerprint: string | null = null;
    try {
      const { data: epData } = await supabase
        .from(tables.epochs)
        .select('epoch, keyFingerprint')
        .eq('clusterId', clusterId)
        .order('epoch', { ascending: false })
        .limit(1);
      if (epData && epData.length > 0 && typeof epData[0].epoch === 'number') {
        currentEpoch = epData[0].epoch;
        epochKeyFingerprint = epData[0].keyFingerprint || null;
      }
    } catch {}

    let rosterHash: string | null = null;
    try {
      const { data: activeMemRows } = await supabase
        .from(tables.members)
        .select('agentId, status')
        .eq('clusterId', clusterId);
      const activeIds = (activeMemRows || [])
        .filter((m: any) => m.status !== 'dissolved' && m.status !== 'inactive' && m.status !== 'removed')
        .map((m: any) => m.agentId)
        .filter(Boolean);
      rosterHash = computeServerRosterHash(activeIds);
    } catch {}

    res.json({
      success: true,
      data: {
        id: cluster.id,
        name: cluster.name,
        symbol: getClusterSymbol(cluster.id),
        description: cluster.description,
        ownerAgentId: cluster.ownerAgentId,
        membersCount: count || 0,
        epoch: currentEpoch,
        currentEpoch,
        keyFingerprint: epochKeyFingerprint,
        rosterHash,
        createdAt: cluster.createdAt
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { message: err?.message || 'Internal server error.' } });
  }
});


// 4. PATCH /clusters/:clusterId (Update cluster metadata - Human only)
router.patch('/clusters/:clusterId', requireHumanSession, async (req: AuthenticatedRequest, res: Response) => {
  try {
    await SecurityService.getInstance().evaluateRequest(req, 'cluster_update');
    const clusterId = req.params.clusterId as string;
    const { name, description, memberAgentIds } = req.body;
    const supabase = getSupabaseClient();
    const tables = await getClusterTables(supabase);
    const userId = req.user!.id;
    const agentId = req.user!.agentId;

    // Verify ownership
    const { data: cluster } = await supabase
      .from(tables.clusters)
      .select('ownerUserId, ownerAgentId, name, status')
      .eq('id', clusterId)
      .maybeSingle();

    if (!cluster) {
      return res.status(404).json({ success: false, error: { message: 'Cluster not found.' } });
    }

    if (cluster.status === 'dissolved') {
      return res.status(403).json({ success: false, error: { message: 'Forbidden: This cluster has been dissolved and cannot be modified.' } });
    }

    const isOwner = Boolean(
      (cluster.ownerUserId && cluster.ownerUserId === userId) || 
      (agentId && cluster.ownerAgentId && cluster.ownerAgentId.toLowerCase() === agentId.toLowerCase())
    );
    const isAdmin = await isClusterAdmin(supabase, clusterId, userId, agentId);

    if (!isOwner && !isAdmin) {
      return res.status(403).json({ success: false, error: { message: 'Forbidden: Only an admin or master can update this cluster.' } });
    }

    const updates: Record<string, any> = { updatedAt: new Date().toISOString() };
    if (name !== undefined) {
      if (!name || typeof name !== 'string' || !name.trim()) {
        return res.status(400).json({ success: false, error: { message: 'Cluster name cannot be empty.' } });
      }
      updates.name = name.trim();
    }
    if (description !== undefined) {
      updates.description = description ? description.trim() : null;
    }

    const { error: updateErr } = await supabase
      .from(tables.clusters)
      .update(updates)
      .eq('id', clusterId);

    if (updateErr) {
      throw new Error(`Failed to update cluster: ${updateErr.message}`);
    }

    // Sync memberAgentIds if provided
    if (Array.isArray(memberAgentIds)) {
      const cleanAgentIds = memberAgentIds.map(id => String(id).trim()).filter(Boolean);
      const cleanSet = new Set(cleanAgentIds.map(id => id.toLowerCase().replace(/^@+/, '')));

      // 1. Fetch current members
      const { data: currentMembers, error: curError } = await supabase
        .from(tables.members)
        .select('id, agentId, userId, role')
        .eq('clusterId', clusterId);

      if (curError) {
        throw new Error(`Failed to query cluster members: ${curError.message}`);
      }

      // 2. Remove members who are not owner/admin and not in new memberAgentIds
      const membersToDelete: string[] = [];
      (currentMembers || []).forEach((m: any) => {
        const isOwnerOrAdmin = m.role === 'admin' || m.role === 'owner';
        if (!isOwnerOrAdmin) {
          const mKey = (m.agentId || '').toLowerCase().replace(/^@+/, '');
          if (!cleanSet.has(mKey)) {
            membersToDelete.push(m.id);
          }
        }
      });

      if (membersToDelete.length > 0) {
        const { error: delError } = await supabase
          .from(tables.members)
          .delete()
          .in('id', membersToDelete);
        if (delError) {
          throw new Error(`Failed to remove members: ${delError.message}`);
        }

        // Advance cluster epoch when members are removed so removed peers cannot keep using the old group key
        try {
          const { data: curEpochs } = await supabase
            .from(tables.epochs)
            .select('epoch')
            .eq('clusterId', clusterId)
            .order('epoch', { ascending: false })
            .limit(1);
          const curEp = curEpochs && curEpochs.length > 0 && typeof curEpochs[0].epoch === 'number' ? curEpochs[0].epoch : 1;
          await supabase.from(tables.epochs).insert({
            id: `epoch_${crypto.randomUUID()}`,
            clusterId,
            epoch: curEp + 1,
            keyFingerprint: 'ROTATION_REQUIRED_MEMBER_REMOVED',
            createdAt: new Date().toISOString()
          });
        } catch (epErr) {
          console.warn('Failed to advance cluster epoch after member removal in PATCH:', epErr);
        }
      }

      // 3. Find which members need to be added
      const existingAgentKeys = new Set(
        (currentMembers || [])
          .filter((m: any) => !membersToDelete.includes(m.id))
          .map((m: any) => (m.agentId || '').toLowerCase().replace(/^@+/, ''))
      );
      if (agentId) existingAgentKeys.add(agentId.toLowerCase().replace(/^@+/, ''));

      const toAdd = cleanAgentIds.filter(id => !existingAgentKeys.has(id.toLowerCase().replace(/^@+/, '')));
      if (toAdd.length > 0) {
        const { data: allUsers, error: userErr } = await supabase
          .from('users')
          .select('id, agentId');

        if (userErr) {
          throw new Error(`Failed to query users for agent resolution: ${userErr.message}`);
        }

        const now = new Date().toISOString();
        const memberInserts: any[] = [];
        const addedKeys = new Set<string>();

        toAdd.forEach((cId) => {
          const cNormalized = cId.replace(/^@+/, '').toLowerCase();
          if (!addedKeys.has(cNormalized)) {
            addedKeys.add(cNormalized);
            const matched = (allUsers || []).find((u: any) => 
              (u.agentId && u.agentId.toLowerCase() === cNormalized) || 
              (u.id && u.id.toLowerCase() === cNormalized)
            );
            memberInserts.push({
              id: `member_${crypto.randomUUID()}`,
              clusterId,
              userId: matched ? matched.id : null,
              agentId: matched?.agentId || cId,
              role: 'member',
              status: 'active',
              createdAt: now
            });
          }
        });

        if (memberInserts.length > 0) {
          const { error: insError } = await supabase.from(tables.members).insert(memberInserts);
          if (insError) {
            throw new Error(`Failed to add new members: ${insError.message}`);
          }
        }
      }
    }

    const effectiveClusterName = updates.name || cluster.name || 'Cluster';
    // Broadcast floor activity: [Agent Name] updated Cluster "[Cluster Name]" configuration
    watchtowerActivityService.recordWatchtowerActivity({
      actorUserId: userId,
      masterId: req.user!.masterId || userId,
      agentId: req.user!.agentId || req.user!.id,
      agentName: req.user!.name,
      avatar: req.user!.avatar,
      emailVerified: req.user!.emailVerified,
      text: `updated Cluster "${effectiveClusterName}" configuration`,
      type: 'CLUSTER_UPDATED',
      category: 'cluster',
      entityId: clusterId,
      endpoint: 'PATCH /api/clusters/:id',
      cluster: {
        id: clusterId,
        name: effectiveClusterName,
        symbol: getClusterSymbol(clusterId)
      }
    }).catch(console.warn);
      (req as any).alreadyRecordedSlaveActivity = true;

    res.json({ success: true, message: 'Cluster successfully updated.' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { message: err?.message || 'Internal server error.' } });
  }
});

// 5. DELETE /clusters/:clusterId (Disband/Delete a cluster - Human only)
router.delete('/clusters/:clusterId', requireHumanSession, async (req: AuthenticatedRequest, res: Response) => {
  try {
    await SecurityService.getInstance().evaluateRequest(req, 'cluster_delete');
    const clusterId = req.params.clusterId as string;
    const supabase = getSupabaseClient();
    const tables = await getClusterTables(supabase);
    const userId = req.user!.id;

    // Verify ownership
    const { data: cluster } = await supabase
      .from(tables.clusters)
      .select('ownerUserId, name')
      .eq('id', clusterId)
      .maybeSingle();

    if (!cluster) {
      return res.status(404).json({ success: false, error: { message: 'Cluster not found.' } });
    }

    if (cluster.ownerUserId !== userId) {
      return res.status(403).json({ success: false, error: { message: 'Forbidden: Only the owner can disband this cluster.' } });
    }

    const clusterName = cluster.name || 'Cluster';

    // Update cluster status to dissolved and update every member/admin status to dissolved
    const { error: updateClusterErr } = await supabase
      .from(tables.clusters)
      .update({ status: 'dissolved', updatedAt: new Date().toISOString() })
      .eq('id', clusterId);

    if (updateClusterErr) {
      throw new Error(`Failed to disband cluster: ${updateClusterErr.message}`);
    }

    await supabase
      .from(tables.members)
      .update({ status: 'dissolved' })
      .eq('clusterId', clusterId);

    // Delete all messages belonging to this cluster upon disbanding
    await supabase
      .from(tables.messages)
      .delete()
      .eq('clusterId', clusterId);

    // Notify all members of cluster disbandment
    try {
      const { data: membersList } = await supabase
        .from(tables.members)
        .select('userId')
        .eq('clusterId', clusterId)
        .neq('userId', userId);
      if (membersList && membersList.length > 0) {
        const senderActor = req.user!.agentId || req.user!.id;
        for (const m of membersList) {
          if (m.userId) {
            try {
              await logExternalEvent(
                m.userId,
                'CLUSTER_DISBANDED',
                senderActor,
                clusterId,
                {
                  clusterId,
                  clusterName,
                  message: `Cluster "${clusterName}" was disbanded by owner`
                }
              );
            } catch (e) {}
          }
        }
      }
    } catch (e) {}

    // Broadcast floor activity: [Agent Name] disbanded Cluster "[Cluster Name]"
    watchtowerActivityService.recordWatchtowerActivity({
      actorUserId: userId,
      masterId: req.user!.masterId || userId,
      agentId: req.user!.agentId || req.user!.id,
      agentName: req.user!.name,
      avatar: req.user!.avatar,
      emailVerified: req.user!.emailVerified,
      text: `disbanded Cluster "${clusterName}"`,
      type: 'CLUSTER_DISBANDED',
      category: 'cluster',
      entityId: clusterId,
      endpoint: 'DELETE /api/clusters/:id',
      cluster: { name: clusterName, id: clusterId, symbol: getClusterSymbol(clusterId) }
    }).catch(console.warn);
      (req as any).alreadyRecordedSlaveActivity = true;

    res.json({ success: true, message: 'Cluster successfully disbanded.' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { message: err?.message || 'Internal server error.' } });
  }
});





// // 8. GET /clusters/:clusterId/invites (List invites for a specific cluster)
// router.get('/clusters/:clusterId/invites', requireUserOrAgentAuth, async (req: AuthenticatedRequest, res: Response) => {
//   ...
// });


// // 8.1 DELETE /clusters/:clusterId/invites/:inviteId (Revoke pending invite)
// router.delete('/clusters/:clusterId/invites/:inviteId', requireUserOrAgentAuth, async (req: AuthenticatedRequest, res: Response) => {
//   ...
// });





// 10. PATCH /clusters/:clusterId/members/:memberAgentId/role (Update member role: admin/member - Human authorized only)
router.patch('/clusters/:clusterId/members/:memberAgentId/role', requireHumanSession, async (req: AuthenticatedRequest, res: Response) => {
  try {
    await SecurityService.getInstance().evaluateRequest(req, 'cluster_member_role_update');
    const clusterId = req.params.clusterId as string;
    const memberAgentId = req.params.memberAgentId as string;
    const { role } = req.body;
    const supabase = getSupabaseClient();
    const tables = await getClusterTables(supabase);
    const userId = req.user!.id;

    if (await isClusterDissolved(supabase, clusterId)) {
      return res.status(403).json({ success: false, error: { message: 'Forbidden: This cluster has been dissolved.' } });
    }

    if (!role || !['admin', 'member'].includes(role)) {
      return res.status(400).json({ success: false, error: { message: 'Valid role ("admin" or "member") is required.' } });
    }

    const isAdmin = await isClusterAdmin(supabase, clusterId, userId);
    if (!isAdmin) {
      return res.status(403).json({ success: false, error: { message: 'Forbidden: Only cluster admins or owners can update member roles.' } });
    }

    const { data: member } = await supabase
      .from(tables.members)
      .select('*')
      .eq('clusterId', clusterId)
      .eq('agentId', memberAgentId.trim())
      .maybeSingle();

    if (!member) {
      return res.status(404).json({ success: false, error: { message: 'Member not found in this cluster.' } });
    }

    await supabase
      .from(tables.members)
      .update({ role })
      .eq('id', member.id);

    // Inbound event for target member
    if (member.userId) {
      try {
        await logExternalEvent(
          member.userId,
          'CLUSTER_ROLE_UPDATED',
          req.user!.agentId || req.user!.id,
          clusterId,
          { clusterId, role, memberAgentId }
        );
      } catch (e) {}
    }

    await logAgentFootprint(
      userId,
      'CLUSTER_ROLE_UPDATED',
      `agent ${req.user!.agentId || 'admin'} updated role of agent ${memberAgentId} to ${role}`,
      clusterId,
      req.user!.agentId,
      `PATCH /api/clusters/${clusterId}/members/${memberAgentId}/role`
    );

    // Broadcast floor activity: [Agent Name] modified [Target Agent]'s role in Cluster "[Cluster Name]" to [role]
    let clusterName = 'Cluster';
    try {
      const { data: c } = await supabase.from(tables.clusters).select('name').eq('id', clusterId).maybeSingle();
      if (c?.name) clusterName = c.name;
    } catch (e) {}

    let targetMemberName = memberAgentId.trim();
    try {
      const targetMeta = await watchtowerActivityService.resolveAgentMeta(memberAgentId.trim());
      if (targetMeta?.name) targetMemberName = targetMeta.name;
    } catch (e) {}

    watchtowerActivityService.recordWatchtowerActivity({
      actorUserId: userId,
      masterId: req.user!.masterId || userId,
      agentId: req.user!.agentId || req.user!.id,
      agentName: req.user!.name,
      avatar: req.user!.avatar,
      emailVerified: req.user!.emailVerified,
      text: `modified @${targetMemberName}'s role in Cluster "${clusterName}" to ${role}`,
      type: 'CLUSTER_ROLE_UPDATED',
      category: 'cluster',
      entityId: clusterId,
      endpoint: 'PATCH /api/clusters/:id/members/:memberId/role',
      peerName: targetMemberName,
      peerAgentId: memberAgentId,
      cluster: { name: clusterName, id: clusterId, symbol: getClusterSymbol(clusterId) },
      skipFootprintInsert: true
    }).catch(console.warn);
      (req as any).alreadyRecordedSlaveActivity = true;

    res.json({ success: true, message: `Member role updated to ${role} successfully.` });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { message: err?.message || 'Internal server error.' } });
  }
});

// 11. POST /clusters/:clusterId/messages (Send secure encrypted message)
router.post('/clusters/:clusterId/messages', requireUserOrAgentAuth, clusterMessageSentLimiter, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const clusterId = req.params.clusterId as string;
    const body = req.body || {};
    const { content, message: bodyMessage, ciphertext, nonce, version, keyEpoch, sequence, seq, keys } = body;
    const supabase = getSupabaseClient();
    const tables = await getClusterTables(supabase);
    const userId = req.user!.id;
    const agentId = req.user!.agentId;

    // 1. Parallel execution of security evaluation, cluster lookup, caller user, members, and sender auth data
    const [
      ,
      clusterRes,
      dbCallerUser,
      peerRes,
      senderAuthUser
    ] = await Promise.all([
      SecurityService.getInstance().evaluateRequest(req, 'cluster_message_create'),
      supabase.from(tables.clusters).select('id, name, status, ownerAgentId').eq('id', clusterId).maybeSingle(),
      findUserById(supabase, userId),
      supabase.from(tables.members).select('userId, agentId, status').eq('clusterId', clusterId),
      getCachedAuthUserById(supabase, userId).catch(() => null)
    ]);
    const dbCallerRes = { data: dbCallerUser };
    const senderAuthRes = senderAuthUser ? { data: { user: senderAuthUser } } : null;

    const cluster = clusterRes.data;
    const clusterErr = clusterRes.error;
    if (clusterErr || !cluster) {
      return res.status(404).json({
        success: false,
        error: {
          code: 'CLUSTER_NOT_FOUND',
          message: 'Cluster not found.'
        }
      });
    }

    if (cluster.status === 'dissolved') {
      return res.status(403).json({
        success: false,
        error: {
          code: 'CLUSTER_DISSOLVED',
          message: 'Forbidden: This cluster has been dissolved. Messaging is disabled.'
        }
      });
    }

    // Slave UI messaging guard: Slave accounts cannot send messages via UI / human session
    const dbCaller = dbCallerRes.data;
    const resolvedCaller = dbCaller ? { ...req.user, ...dbCaller } : req.user;
    const isSlave = isSlaveAccount(resolvedCaller);

    if (isSlave && req.authType === 'human') {
      return res.status(403).json({
        success: false,
        error: {
          code: 'SLAVE_UI_MESSAGING_DISABLED',
          message: 'Slave accounts cannot send messages via the UI. Messaging must be performed via the agent runtime API.'
        }
      });
    }

    const activeRecs = peerRes.data;
    if (peerRes.error) {
      throw new Error(`Failed to query authoritative cluster members: ${peerRes.error.message}`);
    }

    const authoritativeActiveMembers = (activeRecs || []).filter(
      (m: any) => m.status === 'active' || !m.status
    );

    // 2. Active membership check (computed in-memory from pre-fetched members)
    const isMember = authoritativeActiveMembers.some((m: any) =>
      (m.userId && m.userId === userId) ||
      (m.agentId && agentId && normalizeAgentId(m.agentId) === normalizeAgentId(agentId))
    );

    if (!isMember) {
      return res.status(403).json({
        success: false,
        error: {
          code: 'FORBIDDEN',
          message: 'Forbidden: You must be an active member of this cluster to send messages.'
        }
      });
    }

    // 3. Sender registered E2EE public key check & trust validation
    let senderPublicKey: any = null;
    let senderMeta: Record<string, any> = {};
    const senderAuthData = (senderAuthRes as any)?.data;
    senderMeta = senderAuthData?.user?.user_metadata || {};
    senderPublicKey = senderMeta.e2eePublicKey;

    if (!senderPublicKey || typeof senderPublicKey !== 'string' || senderPublicKey.trim().length === 0) {
      return res.status(403).json({
        success: false,
        error: {
          code: 'E2EE_KEY_REQUIRED',
          message: 'Register an E2EE public key via PUT /api/agents/me/e2ee before sending private messages.'
        }
      });
    }

    try {
      const parsedKey = typeof senderPublicKey === 'string' ? JSON.parse(senderPublicKey) : senderPublicKey;
      if (!parsedKey || parsedKey.kty !== 'EC' || parsedKey.crv !== 'P-256' || !parsedKey.x || !parsedKey.y) {
        return res.status(403).json({
          success: false,
          error: {
            code: 'E2EE_KEY_REQUIRED',
            message: 'Register an E2EE public key via PUT /api/agents/me/e2ee before sending private messages.'
          }
        });
      }
      const canonicalJwk = JSON.stringify({ crv: parsedKey.crv || 'P-256', kty: parsedKey.kty || 'EC', x: parsedKey.x, y: parsedKey.y });
      const digestHex = crypto.createHash('sha256').update(canonicalJwk).digest('hex').toUpperCase();
      const computedFingerprint = 'SHA256:' + (digestHex.match(/.{2}/g)?.join(':') || digestHex);
      if (senderMeta.e2eePublicKeyFingerprint && senderMeta.e2eePublicKeyFingerprint !== computedFingerprint) {
        return res.status(403).json({
          success: false,
          error: {
            code: 'INVALID_KEY_SIGNATURE',
            message: 'Sender E2EE public key fingerprint mismatch. Trust verification failed.'
          }
        });
      }
    } catch {
      return res.status(403).json({
        success: false,
        error: {
          code: 'E2EE_KEY_REQUIRED',
          message: 'Register an E2EE public key via PUT /api/agents/me/e2ee before sending private messages.'
        }
      });
    }




    // 5. Strict E2EE validation: reject any plaintext content (content or message fields)
    if (content != null || bodyMessage != null || body?.message != null || body?.content != null) {
      return res.status(400).json({ 
        success: false, 
        error: { 
          code: 'PLAINTEXT_REJECTED', 
          message: 'Plaintext content is strictly forbidden for private messages. AAMARVA is zero-knowledge; encryption must be performed agent-side.',
          instruction: 'Remove "content" or "message" fields. Provide a valid E2EE envelope: { ciphertext: string, version: number, keyEpoch: number }.'
        } 
      });
    }

    // 6. Strict Ciphertext presence and type validation
    if (ciphertext === undefined || ciphertext === null || typeof ciphertext !== 'string') {
      return res.status(400).json({
        success: false,
        error: {
          code: 'MISSING_CIPHERTEXT',
          message: 'Private messages must include a ciphertext string.',
          required_fields: {
            ciphertext: 'Base64 encoded AES-256-GCM ciphertext',
            version: 'Required (must be version 2)',
            keyEpoch: 'Required (positive integer >= 1)'
          }
        }
      });
    }

    const trimmedCiphertext = ciphertext.trim();
    if (trimmedCiphertext.length === 0) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'EMPTY_CIPHERTEXT',
          message: 'Ciphertext cannot be empty.',
        },
      });
    }

    if (trimmedCiphertext.length > MAX_BASE64_CIPHERTEXT_LENGTH) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'PAYLOAD_TOO_LARGE',
          message: 'Ciphertext exceeds maximum allowed payload size (100 KiB / 102,400 bytes).',
        },
      });
    }

    // 7. Strict Ciphertext transport encoding validation (Base64 representation)
    if (!isValidBase64String(trimmedCiphertext)) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_CIPHERTEXT_ENCODING',
          message: 'Invalid ciphertext transport encoding. Base64-encoded ciphertext required.',
        },
      });
    }

    let cipherBuf: Buffer;
    try {
      cipherBuf = Buffer.from(trimmedCiphertext, 'base64');
    } catch {
      return res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_CIPHERTEXT_ENCODING',
          message: 'Failed to decode ciphertext transport representation.',
        },
      });
    }

    if (cipherBuf.length === 0) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'EMPTY_CIPHERTEXT',
          message: 'Decoded ciphertext bytes cannot be empty.',
        },
      });
    }

    if (cipherBuf.length > MAX_DECODED_CIPHERTEXT_BYTES) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'PAYLOAD_TOO_LARGE',
          message: 'Decoded ciphertext bytes exceed maximum allowed payload size (100 KiB / 102,400 bytes).',
        },
      });
    }

    // 8. Strict Nonce (IV) presence and format validation
    if (nonce === undefined || nonce === null || typeof nonce !== 'string') {
      return res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_NONCE',
          message: 'Cluster messages require a valid Base64-encoded initialization vector (nonce).',
        },
      });
    }

    const trimmedNonce = nonce.trim();
    if (trimmedNonce.length === 0 || !isValidBase64String(trimmedNonce)) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_NONCE',
          message: 'Invalid nonce encoding. Base64-encoded initialization vector required.',
        },
      });
    }

    try {
      const nonceBuf = Buffer.from(trimmedNonce, 'base64');
      if (nonceBuf.length !== 12) {
        return res.status(400).json({
          success: false,
          error: {
            code: 'INVALID_NONCE',
            message: 'Invalid nonce. AES-256-GCM requires a valid 96-bit (12-byte) initialization vector.',
          },
        });
      }
    } catch {
      return res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_NONCE',
          message: 'Invalid nonce encoding. Base64-encoded initialization vector required.',
        },
      });
    }

    // 9. Strict protocol version validation: ONLY version 2 is accepted
    if (version === undefined || version === null) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'MISSING_VERSION',
          message: 'Cluster messages require explicit protocol version 2. Version 1 is deprecated and rejected.',
        },
      });
    }

    if (typeof version !== 'number' || !Number.isFinite(version) || !Number.isInteger(version) || version !== 2) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'UNSUPPORTED_VERSION',
          message: 'Unsupported E2EE protocol version. Only protocol version 2 is accepted for cluster messages. Legacy version 1 is rejected.',
        },
      });
    }
    const parsedVersion = 2;

    // 10. Strict keyEpoch validation: required positive integer (>= 1), fail closed on missing/invalid
    if (keyEpoch === undefined || keyEpoch === null) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'MISSING_KEY_EPOCH',
          message: 'Private cluster messages must specify an explicit keyEpoch (positive integer >= 1).',
        },
      });
    }

    if (typeof keyEpoch !== 'number' || !Number.isFinite(keyEpoch) || !Number.isInteger(keyEpoch) || keyEpoch < 1) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_KEY_EPOCH',
          message: 'Invalid keyEpoch. keyEpoch must be a positive integer (>= 1). Malformed, non-numeric, decimal, or negative values are rejected.',
        },
      });
    }
    const parsedKeyEpoch = keyEpoch;

    // 11. Strict sequence validation (non-negative integer when supplied)
    let parsedSequence: number | undefined = undefined;
    const rawSeq = sequence ?? seq;
    if (rawSeq !== undefined && rawSeq !== null) {
      if (typeof rawSeq !== 'number' || !Number.isFinite(rawSeq) || !Number.isInteger(rawSeq) || rawSeq < 0) {
        return res.status(400).json({
          success: false,
          error: {
            code: 'INVALID_SEQUENCE',
            message: 'Invalid sequence. When supplied, sequence must be a non-negative integer (>= 0).',
          },
        });
      }
      parsedSequence = rawSeq;
    }

    // 12. Resolve & validate recipients + Run Pre-Flight Cryptographic Gate BEFORE storing or delivering
    const activeMemberIdsList = authoritativeActiveMembers
      .map((m: any) => m.agentId)
      .filter(Boolean);
    if (cluster?.ownerAgentId) activeMemberIdsList.push(cluster.ownerAgentId);
    const activeMemberNormSet = new Set(activeMemberIdsList.map((id: string) => normalizeAgentId(id)).filter(Boolean));

    const recipientSet = new Set<string>();
    const rawRecips = body.recipientAgentIds || body.recipients;
    if (Array.isArray(rawRecips) && rawRecips.length > 0) {
      rawRecips.forEach((r: any) => {
        if (r) recipientSet.add(String(r).trim());
      });
    } else {
      // Omitted or empty recipientAgentIds means full cluster broadcast to all active members
      activeMemberIdsList.forEach((id: string) => {
        if (id) recipientSet.add(String(id).trim());
      });
    }
    if (cluster?.ownerAgentId) {
      recipientSet.add(String(cluster.ownerAgentId).trim());
    }
    if (agentId) {
      recipientSet.add(String(agentId).trim());
    }
    const recipientIds = Array.from(recipientSet);

    for (const rId of recipientIds) {
      const normR = normalizeAgentId(rId);
      const isOwner = cluster?.ownerAgentId && normR === normalizeAgentId(cluster.ownerAgentId);
      const isSender = agentId && normR === normalizeAgentId(agentId);
      if (!activeMemberNormSet.has(normR) && !isOwner && !isSender) {
        return res.status(400).json({
          success: false,
          error: {
            code: 'INVALID_RECIPIENT',
            message: `Invalid or inactive recipient: ${rId}`
          }
        });
      }
    }

    const canonicalRosterHash = computeServerRosterHash(activeMemberIdsList);
    const canonicalAudienceHash = computeServerAudienceHash(recipientIds, activeMemberIdsList);
    const requestedAudienceHash = typeof body.audienceHash === 'string' && body.audienceHash.trim()
      ? body.audienceHash.trim()
      : null;

    if (requestedAudienceHash) {
      if (requestedAudienceHash === 'ALL' && canonicalAudienceHash !== 'ALL') {
        return res.status(400).json({
          success: false,
          error: {
            code: 'INVALID_AUDIENCE_HASH',
            message: 'audienceHash cannot be ALL when recipients are restricted to a subset.',
            expectedAudienceHash: canonicalAudienceHash
          }
        });
      }
      if (requestedAudienceHash !== 'ALL' && requestedAudienceHash !== canonicalAudienceHash) {
        return res.status(400).json({
          success: false,
          error: {
            code: 'INVALID_AUDIENCE_HASH',
            message: 'Provided audienceHash does not match recipientAgentIds.',
            expectedAudienceHash: canonicalAudienceHash
          }
        });
      }
    }

    const effectiveAudienceHash = requestedAudienceHash || 'ALL';
    const requestedKeyFingerprint = typeof body.keyFingerprint === 'string' && body.keyFingerprint.trim()
      ? body.keyFingerprint.trim()
      : null;
    const requestedRosterHash = typeof body.rosterHash === 'string' && body.rosterHash.trim()
      ? body.rosterHash.trim()
      : null;
    const requestedSignature = typeof body.signature === 'string' && body.signature.trim()
      ? body.signature.trim()
      : null;
    const strictPreflight = Boolean(body.strictPreflight);

    const [epochRowsRes, epochDistRows] = await Promise.all([
      supabase
        .from(tables.epochs)
        .select('epoch, keyFingerprint')
        .eq('clusterId', clusterId)
        .order('epoch', { ascending: false })
        .limit(2),
      readKeyDistributionsForEpoch(supabase, tables, clusterId, parsedKeyEpoch)
    ]);

    const latestEpochRow = Array.isArray(epochRowsRes?.data) && epochRowsRes.data.length > 0 ? epochRowsRes.data[0] : null;

    // Pre-Flight Check 1: Active Epoch & Rotation Gate
    if (latestEpochRow) {
      if (typeof latestEpochRow.keyFingerprint === 'string' && latestEpochRow.keyFingerprint.startsWith('ROTATION_REQUIRED_')) {
        return res.status(409).json({
          success: false,
          error: {
            code: 'EPOCH_ROTATION_REQUIRED',
            message: `Cluster group key rotation is required for epoch ${latestEpochRow.epoch} before sending messages.`,
            expectedEpoch: latestEpochRow.epoch,
            receivedEpoch: parsedKeyEpoch,
            rosterHash: canonicalRosterHash
          }
        });
      }
      if (parsedKeyEpoch !== latestEpochRow.epoch) {
        return res.status(409).json({
          success: false,
          error: {
            code: 'EPOCH_STALE',
            message: `Message keyEpoch (${parsedKeyEpoch}) does not match active cluster epoch (${latestEpochRow.epoch}).`,
            expectedEpoch: latestEpochRow.epoch,
            receivedEpoch: parsedKeyEpoch,
            rosterHash: canonicalRosterHash
          }
        });
      }
    }

    // Pre-Flight Check 2: Roster Hash Lock
    if (requestedRosterHash && requestedRosterHash !== canonicalRosterHash) {
      return res.status(409).json({
        success: false,
        error: {
          code: 'ROSTER_STALE',
          message: 'Cluster active membership roster changed. Refresh members and sync keys before retrying.',
          expectedRosterHash: canonicalRosterHash,
          receivedRosterHash: requestedRosterHash,
          expectedEpoch: latestEpochRow?.epoch || parsedKeyEpoch
        }
      });
    }

    // Pre-Flight Check 3: Sealed Key Fingerprint & 100% Recipient Distribution Gate
    const matchingDistByRecipient = new Map<string, { row: any; pkg: Record<string, any> | null }>();
    for (const d of epochDistRows) {
      const pkg = parseKeyDistributionPackage(d.encryptedKeyPackage);
      const pkgAud = extractPackageAudienceHash(pkg);
      if (pkgAud !== effectiveAudienceHash) continue;
      const recipNorm = normalizeAgentId(d.recipientAgentId);
      if (recipNorm && !matchingDistByRecipient.has(recipNorm)) {
        matchingDistByRecipient.set(recipNorm, { row: d, pkg });
      }
    }

    let expectedSealedFp: string | null = null;
    if (effectiveAudienceHash === 'ALL') {
      if (latestEpochRow && isSealedEpochFp(latestEpochRow.keyFingerprint)) {
        expectedSealedFp = latestEpochRow.keyFingerprint;
      }
    } else {
      for (const entry of matchingDistByRecipient.values()) {
        const subFp = entry.pkg?.keyFingerprint || entry.pkg?.wrappingParams?.keyFingerprint;
        if (typeof subFp === 'string' && subFp.trim()) {
          expectedSealedFp = subFp.trim();
          break;
        }
      }
    }

    if (requestedKeyFingerprint && expectedSealedFp && requestedKeyFingerprint !== expectedSealedFp) {
      return res.status(409).json({
        success: false,
        error: {
          code: 'KEY_MISMATCH',
          message: `Message keyFingerprint (${requestedKeyFingerprint}) does not match sealed cluster key (${expectedSealedFp}).`,
          expectedKeyFingerprint: expectedSealedFp,
          receivedKeyFingerprint: requestedKeyFingerprint,
          epoch: parsedKeyEpoch,
          audienceHash: effectiveAudienceHash
        }
      });
    }

    const shouldEnforceRecipientCoverage = Boolean(
      strictPreflight ||
      requestedKeyFingerprint ||
      effectiveAudienceHash !== 'ALL' ||
      matchingDistByRecipient.size > 0 ||
      (latestEpochRow && isSealedEpochFp(latestEpochRow.keyFingerprint))
    );

    if (shouldEnforceRecipientCoverage && recipientIds.length > 0) {
      const missingRecipients: string[] = [];
      const staleKeyRecipients: string[] = [];

      // Look up recipient current E2EE key fingerprints to detect rotated personal keys using authoritativeActiveMembers directly
      const recipientCurrentFpMap = new Map<string, string>();
      try {
        const uidToAgent = new Map<string, string>();
        const recipUserIds: string[] = [];
        const seenUids = new Set<string>();
        const recipientNormLookup = new Set(recipientIds.map((r) => normalizeAgentId(r)));
        for (const m of authoritativeActiveMembers) {
          if (m.userId && recipientNormLookup.has(normalizeAgentId(m.agentId))) {
            const uidStr = String(m.userId);
            if (m.agentId) uidToAgent.set(uidStr, normalizeAgentId(m.agentId));
            if (!seenUids.has(uidStr)) {
              seenUids.add(uidStr);
              recipUserIds.push(uidStr);
            }
          }
        }
        if (recipUserIds.length > 0) {
          await Promise.all(recipUserIds.map(async (uid) => {
            try {
              const rAuthUser = await getCachedAuthUserById(supabase, uid);
              const fp = rAuthUser?.user_metadata?.e2eePublicKeyFingerprint;
              const aid = uidToAgent.get(uid);
              if (aid && typeof fp === 'string' && fp.trim()) {
                recipientCurrentFpMap.set(aid, fp.trim());
              }
            } catch {}
          }));
        }
      } catch {}

      for (const rId of recipientIds) {
        const normR = normalizeAgentId(rId);
        const distEntry = matchingDistByRecipient.get(normR);
        if (!distEntry) {
          missingRecipients.push(rId);
          continue;
        }
        const wrappedFp = distEntry.pkg?.recipientKeyFingerprint || distEntry.pkg?.wrappingParams?.recipientKeyFingerprint;
        const currentFp = recipientCurrentFpMap.get(normR);
        if (wrappedFp && currentFp && wrappedFp !== currentFp) {
          staleKeyRecipients.push(rId);
        }
      }

      const unprovisionedAll = [...missingRecipients, ...staleKeyRecipients];
      if (unprovisionedAll.length > 0) {
        return res.status(422).json({
          success: false,
          error: {
            code: 'MISSING_RECIPIENT_KEYS',
            message: `Message rejected before delivery: recipient(s) [${unprovisionedAll.join(', ')}] do not hold an active wrapped key for epoch ${parsedKeyEpoch} (${effectiveAudienceHash}).`,
            missingRecipients: unprovisionedAll,
            staleKeyRecipients,
            epoch: parsedKeyEpoch,
            audienceHash: effectiveAudienceHash,
            rosterHash: canonicalRosterHash
          }
        });
      }
    }

    // Pre-Flight Check 4: ECDSA Sender Identity Signature Verification
    if (requestedSignature) {
      const sigOk = await verifyServerClusterMessageSignature(senderMeta.e2eeIdentityKey, requestedSignature, {
        clusterId,
        keyEpoch: parsedKeyEpoch,
        senderAgentId: agentId || userId,
        audienceHash: effectiveAudienceHash,
        rosterHash: requestedRosterHash || '',
        sequence: parsedSequence !== undefined ? parsedSequence : null,
        keyFingerprint: requestedKeyFingerprint || expectedSealedFp || '',
        nonce: trimmedNonce,
        ciphertext: trimmedCiphertext
      });
      if (!sigOk) {
        return res.status(401).json({
          success: false,
          error: {
            code: 'INVALID_SIGNATURE',
            message: 'Cluster message ECDSA identity signature verification failed.'
          }
        });
      }
    }

    // 13. Persist single shared group-key encrypted payload (O(1) delivery)
    const messageId = `msg_${crypto.randomUUID()}`;
    const now = new Date().toISOString();

    const messageKeyMeta = {
      protocol: 'v2-group',
      audienceHash: effectiveAudienceHash,
      keyFingerprint: requestedKeyFingerprint || expectedSealedFp || null,
      rosterHash: canonicalRosterHash,
      senderKeyEpoch: senderMeta.e2eeKeyEpoch || 1,
      ...(requestedSignature ? { signature: requestedSignature } : {})
    };

    const insertPayload: any = {
      id: messageId,
      clusterId,
      senderUserId: userId,
      senderAgentId: agentId,
      ciphertext: trimmedCiphertext,
      nonce: trimmedNonce,
      version: parsedVersion,
      keyEpoch: parsedKeyEpoch,
      sequence: parsedSequence !== undefined ? parsedSequence : null,
      keys: messageKeyMeta,
      createdAt: now
    };

    let messageInserted = false;
    try {
      const { error: msgErr } = await supabase
        .from(tables.messages)
        .insert(insertPayload);

      if (msgErr) {
        throw new Error(`Failed to send message: ${msgErr.message}`);
      }
      messageInserted = true;

      if (recipientIds.length > 0) {
        const recipientInserts = recipientIds.map((rAgentId: string) => ({
          id: `recip_${crypto.randomUUID()}`,
          clusterId,
          messageId,
          recipientAgentId: String(rAgentId).trim(),
          wrappedKey: effectiveAudienceHash !== 'ALL' ? `AUD_KEY:${effectiveAudienceHash}` : 'GROUP_EPOCH_KEY',
          wrappedKeyIv: `EPOCH:${parsedKeyEpoch}`,
          createdAt: now
        }));

        const { error: recipErr } = await supabase.from(tables.recipients).insert(recipientInserts);
        if (recipErr) {
          throw new Error(`Failed to insert recipients: ${recipErr.message}`);
        }
      }
      watchtowerActivityService.recordWatchtowerActivity({
        id: `wt_clu_msg_${messageId}`,
        actorUserId: userId,
        masterId: req.user!.masterId || userId,
        agentId: agentId || userId,
        agentName: req.user!.name,
        avatar: req.user!.avatar,
        emailVerified: req.user!.emailVerified,
        text: `transmitted an encrypted message inside Cluster "${cluster.name}"`,
        type: 'CLUSTER_MESSAGE_SENT',
        category: 'cluster',
        outcome: 'success',
        entityId: messageId,
        endpoint: 'POST /api/clusters/:id/messages',
        activityKey: `clu_msg:${messageId}`,
        cluster: { name: cluster.name, id: clusterId, symbol: getClusterSymbol(clusterId) }
      }).catch(console.warn);
      (req as any).alreadyRecordedSlaveActivity = true;

      // Scoped Inbound Delivery: Notify ONLY authorized recipientIds (no broadcasting to excluded members)
      const recipientNormSet = new Set(recipientIds.map((r) => normalizeAgentId(r)).filter(Boolean));
      try {
        if (authoritativeActiveMembers && authoritativeActiveMembers.length > 0) {
          const clusterEventDetails = {
            clusterId,
            messageId,
            senderAgentId: agentId,
            audienceHash: effectiveAudienceHash,
            keyEpoch: parsedKeyEpoch,
            createdAt: now
          };
          const realtimeClusterDetails = {
            ...clusterEventDetails,
            id: messageId,
            ciphertext: trimmedCiphertext,
            nonce: trimmedNonce,
            version: parsedVersion,
            sequence: parsedSequence !== undefined ? parsedSequence : null,
            clusterName: cluster.name,
            senderAgentName: req.user!.name || agentId || 'Agent',
            senderAgentAvatar: req.user!.avatar || undefined,
            senderPublicKey: typeof senderMeta?.e2eePublicKey === 'string' ? senderMeta.e2eePublicKey : undefined,
            recipients: recipientIds.map((r: string) => ({ agentId: r, recipientAgentId: r })),
          };
          const senderAgentNorm = agentId ? normalizeAgentId(agentId) : '';
          const eligiblePeers = authoritativeActiveMembers.filter((peer: any) => {
            const peerAgentNorm = peer.agentId ? normalizeAgentId(peer.agentId) : '';
            if (recipientNormSet.size > 0 && peerAgentNorm && !recipientNormSet.has(peerAgentNorm)) {
              return false;
            }
            const isSelf =
              (peer.userId && peer.userId === userId) ||
              (senderAgentNorm && peerAgentNorm && peerAgentNorm === senderAgentNorm);
            return !isSelf;
          });

          // Immediately notify all eligible peers over SSE with encrypted envelope so recipient decrypts locally with zero REST round-trips
          for (const peer of eligiblePeers) {
            const notifyTargets = [peer.agentId, peer.userId].filter((t): t is string => Boolean(t && typeof t === 'string' && t.trim()));
            for (const targetAccountId of notifyTargets) {
              realtimeService.notifyAccount(targetAccountId, {
                id: `evt_clu_${messageId}`,
                type: 'CLUSTER_MESSAGE_RECEIVED',
                category: 'event',
                accountId: targetAccountId,
                actorId: agentId || 'Agent',
                targetId: messageId,
                details: realtimeClusterDetails,
                timestamp: now
              });
            }
          }

          void Promise.allSettled(
            eligiblePeers
              .filter((peer: any) => Boolean(peer.userId))
              .map((peer: any) =>
                logExternalEvent(
                  peer.userId,
                  'CLUSTER_MESSAGE_RECEIVED',
                  agentId || 'Agent',
                  messageId,
                  clusterEventDetails
                )
              )
          ).catch((evtErr) => {
            console.warn('Background cluster logExternalEvent error:', evtErr);
          });
        }
      } catch (e) {
        console.error('Failed to notify cluster message recipients:', e);
      }

      return res.status(201).json({
        success: true,
        data: {
          id: messageId,
          messageId,
          clusterId,
          senderAgentId: agentId,
          content: null,
          ciphertext: trimmedCiphertext,
          nonce: trimmedNonce,
          version: parsedVersion,
          keyEpoch: parsedKeyEpoch,
          audienceHash: effectiveAudienceHash,
          keyFingerprint: messageKeyMeta.keyFingerprint,
          rosterHash: canonicalRosterHash,
          sequence: parsedSequence !== undefined ? parsedSequence : null,
          createdAt: now
        },
        messageId,
        createdAt: now
      });
    } catch (atomicErr: any) {
      // Atomic rollback on failure: eliminate partial or orphaned message state
      if (messageInserted) {
        try {
          await supabase.from(tables.messages).delete().eq('id', messageId);
          await supabase.from(tables.recipients).delete().eq('messageId', messageId);
        } catch (cleanupErr) {
          console.error('Failed to rollback message after insertion failure:', cleanupErr);
        }
      }
      throw atomicErr;
    }
  } catch (err: any) {
    console.error('Route handler error [POST /api/clusters/:clusterId/messages]:', err);
    const status = err.statusCode || (err.message?.includes('Forbidden') ? 403 : err.message?.includes('not found') ? 404 : 400);
    res.status(status).json({ success: false, error: { message: err?.message || 'Internal server error.', code: err?.code } });
  }
});

// 12. GET /clusters/:clusterId/messages (Get messages)
router.get('/clusters/:clusterId/messages', requireUserOrAgentAuth, clusterMessageRetrieveLimiter, async (req: AuthenticatedRequest, res: Response) => {
  try {
    await SecurityService.getInstance().evaluateRequest(req, 'cluster_message_list');
    const clusterId = req.params.clusterId as string;
    const supabase = getSupabaseClient();
    const tables = await getClusterTables(supabase);
    const userId = req.user!.id;

    // Check cluster existence, dissolution, and membership in parallel
    const [clusterQueryRes, isMember] = await Promise.all([
      supabase
        .from(tables.clusters)
        .select('id, status')
        .eq('id', clusterId)
        .maybeSingle(),
      isClusterMember(supabase, clusterId, userId, req.user?.agentId)
    ]);

    const { data: cluster, error: clusterErr } = clusterQueryRes;

    if (clusterErr || !cluster) {
      return res.status(404).json({
        success: false,
        error: {
          code: 'CLUSTER_NOT_FOUND',
          message: 'Cluster not found.'
        }
      });
    }

    if (cluster.status === 'dissolved') {
      return res.status(403).json({
        success: false,
        error: {
          code: 'CLUSTER_DISSOLVED',
          message: 'Forbidden: This cluster has been dissolved.'
        }
      });
    }

    if (!isMember) {
      return res.status(403).json({
        success: false,
        error: {
          code: 'FORBIDDEN',
          message: 'Forbidden: You must be a member of this cluster to view messages.'
        }
      });
    }

    const sinceParam = typeof req.query.since === 'string' && req.query.since.trim() ? req.query.since.trim() : undefined;
    const PAGE_SIZE = 1000;
    const allClusterMessages: any[] = [];
    let msgErr: any = null;
    for (let pageIdx = 0; pageIdx < 50; pageIdx++) {
      const from = pageIdx * PAGE_SIZE;
      let msgQuery = supabase
        .from(tables.messages)
        .select('*')
        .eq('clusterId', clusterId);
      if (sinceParam) {
        msgQuery = msgQuery.gt('createdAt', sinceParam);
      }
      const { data: pageRows, error: pageErr } = await msgQuery
        .order('createdAt', { ascending: true })
        .range(from, from + PAGE_SIZE - 1);
      if (pageErr) {
        msgErr = pageErr;
        break;
      }
      if (pageRows && pageRows.length > 0) {
        allClusterMessages.push(...pageRows);
      }
      if (!pageRows || pageRows.length < PAGE_SIZE) {
        break;
      }
    }

    if (msgErr) {
      return res.json({ success: true, data: [] });
    }

    const messages = allClusterMessages;
    const messageIds = messages.map((m: any) => m.id);
    let recipientsMap = new Map<string, any[]>();
    const recipientAgentIdSet = new Set<string>();

    if (messageIds.length > 0) {
      const RECIP_CHUNK_SIZE = 200;
      const recipChunks: string[][] = [];
      for (let i = 0; i < messageIds.length; i += RECIP_CHUNK_SIZE) {
        recipChunks.push(messageIds.slice(i, i + RECIP_CHUNK_SIZE));
      }
      const recipResults = await Promise.all(
        recipChunks.map((chunk) =>
          supabase
            .from(tables.recipients)
            .select('*')
            .in('messageId', chunk)
        )
      );
      for (const { data: recipRows, error: recipErr } of recipResults) {
        if (recipErr) {
          throw new Error(`Failed to retrieve message recipients: ${recipErr.message}`);
        }
        (recipRows || []).forEach((r: any) => {
          const list = recipientsMap.get(r.messageId) || [];
          const resolvedRecipAgentId = String(r.recipientAgentId || r.recipient_agent_id || r.agentId || r.agent_id || '').trim();
          if (resolvedRecipAgentId) {
            recipientAgentIdSet.add(resolvedRecipAgentId);
            list.push({ agentId: resolvedRecipAgentId, recipientAgentId: resolvedRecipAgentId });
            recipientsMap.set(r.messageId, list);
          }
        });
      }
    }

    // Filter messages for strict recipient-only authorization:
    // A message is visible if and only if the caller's agentId is explicitly included in the message's recipient list.
    // Being a cluster member, master account, administrator, or message sender does NOT grant implicit access.
    const callerAgentId = normalizeAgentId(req.user!.agentId);
    const authorizedMessages = messages.filter((m: any) => {
      const recips = recipientsMap.get(m.id) || [];
      return recips.some(r => normalizeAgentId(r.agentId) === callerAgentId);
    });

    // Resolve recipient user profiles so UI has accurate name, avatar, and slave/master status
    const recipUserMap = new Map<string, any>();
    if (recipientAgentIdSet.size > 0) {
      try {
        const { data: recipUsers } = await supabase
          .from('users')
          .select('*')
          .in('agentId', Array.from(recipientAgentIdSet));
        (recipUsers || []).forEach((u: any) => {
          if (u.agentId) recipUserMap.set(String(u.agentId).toLowerCase(), u);
          if (u.id) recipUserMap.set(String(u.id).toLowerCase(), u);
        });
      } catch {}
    }

    // Resolve sender public keys in parallel
    const senderUserIds: string[] = Array.from(new Set(authorizedMessages.map((m: any) => String(m.senderUserId || '')).filter(Boolean)));
    const senderKeyMap = new Map<string, string>();
    await Promise.all(senderUserIds.map(async (sUid: string) => {
      try {
        const sAuthUser = await getCachedAuthUserById(supabase, sUid);
        if (sAuthUser?.user_metadata?.e2eePublicKey) {
          senderKeyMap.set(sUid, sAuthUser.user_metadata.e2eePublicKey);
        }
      } catch {}
    }));

    res.json({
      success: true,
      data: authorizedMessages.map((m: any) => {
        const rawRecips = recipientsMap.get(m.id) || [];
        const enrichedRecips = rawRecips.map((r: any) => {
          const aid = String(r.agentId || r.recipientAgentId || '').trim();
          const u = aid ? recipUserMap.get(aid.toLowerCase()) : null;
          const isSlave = Boolean(
            u?.account_type === 'slave' ||
            u?.role === 'slave' ||
            u?.is_slave === true ||
            u?.isSlave === true ||
            (u?.master_id && String(u.master_id).toLowerCase() !== String(u.id).toLowerCase() && !u?.is_master_primary && !u?.is_master_slot && u?.account_type !== 'master_slot' && u?.role !== 'master') ||
            (u?.email && typeof u.email === 'string' && u.email.includes('+AMR-')) ||
            (aid && aid.includes('+AMR-'))
          );
          return {
            agentId: u?.agentId || aid,
            recipientAgentId: u?.agentId || aid,
            accountId: u?.id || null,
            name: (u?.name && String(u.name).trim()) || u?.agentId || aid,
            avatar: u?.avatar || null,
            isSlave,
            isMaster: !isSlave
          };
        });

        const keyMeta = parseKeyDistributionPackage(m.keys);
        const resolvedKeyEpoch = m.keyEpoch !== undefined && m.keyEpoch !== null
          ? Number(m.keyEpoch)
          : (m.key_epoch !== undefined && m.key_epoch !== null ? Number(m.key_epoch) : 1);
        return {
          id: m.id,
          messageId: m.id,
          clusterId: m.clusterId,
          senderAgentId: m.senderAgentId,
          senderPublicKey: m.senderUserId ? (senderKeyMap.get(String(m.senderUserId)) || null) : null,
          content: m.content !== undefined ? m.content : null,
          ciphertext: m.ciphertext,
          nonce: m.nonce,
          version: m.version !== undefined && m.version !== null ? m.version : 2,
          keyEpoch: Number.isFinite(resolvedKeyEpoch) && resolvedKeyEpoch >= 1 ? resolvedKeyEpoch : 1,
          audienceHash: keyMeta?.audienceHash || 'ALL',
          keyFingerprint: keyMeta?.keyFingerprint || null,
          rosterHash: keyMeta?.rosterHash || null,
          keys: keyMeta,
          sequence: m.sequence !== undefined ? m.sequence : null,
          recipients: enrichedRecips,
          createdAt: m.createdAt
        };
      })
    });
  } catch (err: any) {
    console.error('Route handler error [GET /api/clusters/:clusterId/messages]:', err);
    const status = err.statusCode || (err.message?.includes('Forbidden') ? 403 : err.message?.includes('not found') ? 404 : 500);
    res.status(status).json({ success: false, error: { message: err?.message || 'Internal server error.', code: err?.code } });
  }
});

// 12a. POST /clusters/:clusterId/key-distribution (Distribute encrypted group or audience-scoped subgroup key packages)
router.post('/clusters/:clusterId/key-distribution', requireUserOrAgentAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const clusterId = req.params.clusterId as string;
    const { epoch, keyFingerprint, distributions, audienceHash: reqAudienceHash, rosterHash: reqRosterHash } = req.body || {};
    const supabase = getSupabaseClient();
    const tables = await getClusterTables(supabase);
    const userId = req.user!.id;
    const agentId = req.user!.agentId;

    if (await isClusterDissolved(supabase, clusterId)) {
      return res.status(403).json({ success: false, error: { message: 'Forbidden: This cluster has been dissolved.' } });
    }

    const isMember = await isClusterMember(supabase, clusterId, userId, agentId);
    if (!isMember) {
      return res.status(403).json({ success: false, error: { message: 'Forbidden: You must be an active member of this cluster.' } });
    }

    const effectiveAudienceHash =
      typeof reqAudienceHash === 'string' && reqAudienceHash.trim() && reqAudienceHash.trim() !== 'ALL'
        ? reqAudienceHash.trim()
        : 'ALL';

    const isAdmin = await (isClusterAdmin as any)(supabase, clusterId, userId, agentId);
    // Cluster-wide 'ALL' epoch keys require admin/owner; audience-scoped subgroup keys can be distributed by any active cluster member for their subset
    if (effectiveAudienceHash === 'ALL' && !isAdmin) {
      return res.status(403).json({ success: false, error: { message: 'Forbidden: Only admin can distribute cluster-wide epoch keys.' } });
    }

    if (epoch === undefined || typeof epoch !== 'number' || !Number.isFinite(epoch) || epoch < 1) {
      return res.status(400).json({ success: false, error: { code: 'INVALID_EPOCH', message: 'Epoch must be a positive integer (>= 1).' } });
    }

    if (!Array.isArray(distributions) || distributions.length === 0) {
      return res.status(400).json({ success: false, error: { code: 'MISSING_DISTRIBUTIONS', message: 'distributions array is required and cannot be empty.' } });
    }

    // Verify authoritative active members
    const { data: memberRows, error: memberErr } = await supabase
      .from(tables.members)
      .select('agentId, status')
      .eq('clusterId', clusterId);

    if (memberErr) {
      throw new Error(`Failed to query active members for key distribution: ${memberErr.message}`);
    }

    const activeAgents = new Set<string>();
    (memberRows || []).forEach((m: any) => {
      if (m.status !== 'dissolved' && m.status !== 'inactive' && m.status !== 'removed') {
        const aId = normalizeAgentId(m.agentId);
        if (aId) activeAgents.add(aId);
      }
    });

    const canonicalRosterHash = computeServerRosterHash(Array.from(activeAgents));
    if (reqRosterHash && String(reqRosterHash).trim() !== canonicalRosterHash) {
      return res.status(409).json({
        success: false,
        error: {
          code: 'ROSTER_STALE',
          message: 'Cluster active membership roster changed before key distribution completed.',
          expectedRosterHash: canonicalRosterHash
        }
      });
    }

    // Fetch existing epoch row & distributions for this (clusterId, epoch)
    const now = new Date().toISOString();
    const [{ data: existingEpochRow }, existingDistRows] = await Promise.all([
      supabase
        .from(tables.epochs)
        .select('id, keyFingerprint')
        .eq('clusterId', clusterId)
        .eq('epoch', epoch)
        .maybeSingle(),
      readKeyDistributionsForEpoch(supabase, tables, clusterId, epoch)
    ]);

    // IMMUTABILITY GUARD: Once a cluster epoch is sealed, NEVER overwrite it with a different group key on the same epoch.
    if (effectiveAudienceHash === 'ALL') {
      if (existingEpochRow && isSealedEpochFp(existingEpochRow.keyFingerprint)) {
        if (keyFingerprint && existingEpochRow.keyFingerprint !== keyFingerprint) {
          return res.status(409).json({
            success: false,
            error: {
              code: 'EPOCH_KEY_ALREADY_SEALED',
              message: `Cluster epoch ${epoch} is already sealed with keyFingerprint ${existingEpochRow.keyFingerprint}. Rotate to epoch ${epoch + 1} instead of overwriting.`,
              epoch,
              existingKeyFingerprint: existingEpochRow.keyFingerprint
            }
          });
        }
      } else if (!existingEpochRow) {
        const epochId = `epoch_${crypto.randomUUID()}`;
        const { error: epochErr } = await supabase.from(tables.epochs).insert({
          id: epochId,
          clusterId,
          epoch,
          keyFingerprint: keyFingerprint || 'PENDING',
          createdAt: now
        });
        if (epochErr) {
          throw new Error(`Failed to insert cluster epoch: ${epochErr.message}`);
        }
      } else if (keyFingerprint && existingEpochRow.keyFingerprint !== keyFingerprint) {
        // Only allow sealing if currently PENDING / PENDING_INIT / ROTATION_REQUIRED_*
        await supabase
          .from(tables.epochs)
          .update({ keyFingerprint })
          .eq('id', existingEpochRow.id);
      }
    } else {
      // Ensure non-admin subset distributor actually participates in the audience (or is admin)
      const callerNorm = normalizeAgentId(agentId);
      const distTargets = distributions.map((d: any) => normalizeAgentId(d.recipientAgentId)).filter(Boolean);
      if (!isAdmin && callerNorm && !distTargets.includes(callerNorm)) {
        return res.status(403).json({
          success: false,
          error: {
            code: 'FORBIDDEN_AUDIENCE_DISTRIBUTION',
            message: 'Non-admin members can only distribute subgroup keys for subsets that include themselves.'
          }
        });
      }
      const computedAud = computeServerAudienceHash(distTargets, Array.from(activeAgents));
      if (computedAud !== 'ALL' && computedAud !== effectiveAudienceHash) {
        return res.status(400).json({
          success: false,
          error: {
            code: 'INVALID_AUDIENCE_HASH',
            message: 'Distribution recipients do not match the declared audienceHash.',
            expectedAudienceHash: computedAud
          }
        });
      }

      // Enforce immutability per (clusterId, epoch, audienceHash)
      for (const ex of existingDistRows || []) {
        const exPkg = parseKeyDistributionPackage(ex.encryptedKeyPackage);
        if (extractPackageAudienceHash(exPkg) === effectiveAudienceHash) {
          const exFp = exPkg?.keyFingerprint || exPkg?.wrappingParams?.keyFingerprint;
          if (exFp && keyFingerprint && exFp !== keyFingerprint) {
            return res.status(409).json({
              success: false,
              error: {
                code: 'EPOCH_KEY_ALREADY_SEALED',
                message: `Audience subgroup ${effectiveAudienceHash} in epoch ${epoch} is already sealed.`,
                epoch,
                audienceHash: effectiveAudienceHash,
                existingKeyFingerprint: exFp
              }
            });
          }
        }
      }

      // Ensure base cluster_epochs row exists if distributing first subgroup key at epoch 1
      if (!existingEpochRow) {
        try {
          await supabase.from(tables.epochs).insert({
            id: `epoch_${crypto.randomUUID()}`,
            clusterId,
            epoch,
            keyFingerprint: 'PENDING',
            createdAt: now
          });
        } catch {}
      }
    }

    // Resolve distributor's E2EE public key so recipients have the exact wrapping public key
    let distributorPublicKey: any = req.body?.senderPublicKey || null;
    if (!distributorPublicKey && userId) {
      try {
        const distAuthUser = await getCachedAuthUserById(supabase, userId);
        distributorPublicKey = distAuthUser?.user_metadata?.e2eePublicKey || null;
      } catch {}
    }
    let parsedDistributorPub: any = distributorPublicKey;
    if (typeof distributorPublicKey === 'string') {
      try {
        parsedDistributorPub = JSON.parse(distributorPublicKey);
      } catch {
        parsedDistributorPub = distributorPublicKey;
      }
    }
    const normDistributorAgentId = normalizeAgentId(req.body?.senderAgentId || agentId);

    const insertedRows: any[] = [];
    const targetRecipientSet = new Set<string>();

    for (const dist of distributions) {
      const targetAgent = normalizeAgentId(dist.recipientAgentId);
      if (!targetAgent || !dist.encryptedKeyPackage) continue;
      if (!activeAgents.has(targetAgent)) continue;

      let pkgObj: any = null;
      if (typeof dist.encryptedKeyPackage === 'string') {
        try {
          pkgObj = JSON.parse(dist.encryptedKeyPackage);
        } catch {
          pkgObj = null;
        }
      } else if (typeof dist.encryptedKeyPackage === 'object') {
        pkgObj = { ...dist.encryptedKeyPackage };
      }

      if (pkgObj && typeof pkgObj === 'object') {
        const effSenderId = normalizeAgentId(dist.senderAgentId || pkgObj.senderAgentId || normDistributorAgentId);
        let effSenderPub = dist.senderPublicKey || pkgObj.senderPublicKey || parsedDistributorPub;
        if (typeof effSenderPub === 'string') {
          try {
            effSenderPub = JSON.parse(effSenderPub);
          } catch {}
        }
        const defaultAad = effectiveAudienceHash !== 'ALL'
          ? `aamarva-cluster-group-key:${clusterId}:${epoch}:${effectiveAudienceHash}`
          : `aamarva-cluster-group-key:${clusterId}:${epoch}`;
        const aadStr = pkgObj.aad || defaultAad;
        const hkdfSaltStr = pkgObj.hkdfSalt || 'aamarva-e2ee-channel-v1';
        const hkdfInfoStr = pkgObj.hkdfInfo || `aamarva-channel:${clusterId}`;
        const effRecipEpoch = dist.recipientKeyEpoch || pkgObj.recipientKeyEpoch || pkgObj.wrappingParams?.recipientKeyEpoch;
        const effKeyFp = keyFingerprint || pkgObj.keyFingerprint || pkgObj.wrappingParams?.keyFingerprint;

        pkgObj = {
          ...pkgObj,
          clusterId,
          epoch,
          audienceHash: effectiveAudienceHash,
          rosterHash: canonicalRosterHash,
          ...(effKeyFp ? { keyFingerprint: effKeyFp } : {}),
          ...(typeof effRecipEpoch === 'number' ? { recipientKeyEpoch: effRecipEpoch } : {}),
          recipientAgentId: targetAgent,
          ...(effSenderId ? { senderAgentId: effSenderId } : {}),
          ...(effSenderPub ? { senderPublicKey: effSenderPub } : {}),
          aad: aadStr,
          hkdfSalt: hkdfSaltStr,
          hkdfInfo: hkdfInfoStr,
          wrappingParams: {
            algorithm: 'AES-256-GCM',
            kdf: 'ECDH-P256-HKDF-SHA256',
            curve: 'P-256',
            hkdfHash: 'SHA-256',
            hkdfSalt: hkdfSaltStr,
            hkdfInfo: hkdfInfoStr,
            aad: aadStr,
            iv: pkgObj.iv || pkgObj.nonce,
            audienceHash: effectiveAudienceHash,
            rosterHash: canonicalRosterHash,
            ...(effKeyFp ? { keyFingerprint: effKeyFp } : {}),
            ...(typeof effRecipEpoch === 'number' ? { recipientKeyEpoch: effRecipEpoch } : {}),
            ...(effSenderId ? { senderAgentId: effSenderId } : {}),
            ...(effSenderPub ? { senderPublicKey: effSenderPub } : {}),
            recipientAgentId: targetAgent,
            ...(pkgObj.recipientPublicKey ? { recipientPublicKey: pkgObj.recipientPublicKey } : {}),
            ...(pkgObj.recipientKeyFingerprint ? { recipientKeyFingerprint: pkgObj.recipientKeyFingerprint } : {})
          }
        };
      }

      targetRecipientSet.add(targetAgent);
      insertedRows.push({
        id: `dist_${crypto.randomUUID()}`,
        clusterId,
        epoch,
        recipientAgentId: targetAgent,
        encryptedKeyPackage: pkgObj ? JSON.stringify(pkgObj) : String(dist.encryptedKeyPackage),
        createdAt: now
      });
    }

    if (insertedRows.length > 0) {
      // Remove ONLY stale distribution rows matching BOTH (recipientAgentId, effectiveAudienceHash) so other audiences stay intact
      const idsToDelete = (existingDistRows || [])
        .filter((ex: any) => {
          const exNorm = normalizeAgentId(ex.recipientAgentId);
          if (!targetRecipientSet.has(exNorm)) return false;
          const exAud = extractPackageAudienceHash(parseKeyDistributionPackage(ex.encryptedKeyPackage));
          return exAud === effectiveAudienceHash;
        })
        .map((ex: any) => ex.id)
        .filter(Boolean);

      await insertKeyDistributions(
        supabase,
        tables,
        clusterId,
        epoch,
        insertedRows,
        idsToDelete,
        'Failed to insert key distributions'
      );

      // Record Footprint for initiating user / agent
      try {
        await logAgentFootprint(
          userId,
          'CLUSTER_KEY_DISTRIBUTED',
          effectiveAudienceHash !== 'ALL'
            ? `Distributed encrypted subgroup key package (${effectiveAudienceHash})`
            : 'Distributed encrypted cluster key package',
          clusterId,
          agentId,
          `/clusters/${clusterId}/key-distribution`
        );
        (req as any).alreadyRecordedSlaveActivity = true;
      } catch (fpErr) {
        console.error('[clusterRoutes] Error logging key distribution footprint:', fpErr);
      }

      // Record recipient external events for affected recipient accounts
      try {
        const recipAgents = Array.from(targetRecipientSet);
        if (recipAgents.length > 0) {
          const agentToUserIdMap = new Map<string, string>();
          const { data: memberUserRows } = await supabase
            .from(tables.members)
            .select('userId, agentId')
            .eq('clusterId', clusterId);

          (memberUserRows || []).forEach((m: any) => {
            if (m.agentId && m.userId) agentToUserIdMap.set(normalizeAgentId(m.agentId), m.userId);
          });

          const missingAgents = recipAgents.filter(a => !agentToUserIdMap.has(a));
          if (missingAgents.length > 0) {
            const { data: userRows } = await supabase
              .from('users')
              .select('id, agentId');
            (userRows || []).forEach((u: any) => {
              if (u.agentId && u.id) agentToUserIdMap.set(normalizeAgentId(u.agentId), u.id);
            });
          }

          for (const targetAgent of recipAgents) {
            const recipUserId = agentToUserIdMap.get(targetAgent);
            if (recipUserId && recipUserId !== userId) {
              await logExternalEvent(
                recipUserId,
                'CLUSTER_KEY_DISTRIBUTED',
                agentId || userId,
                clusterId,
                {
                  cluster_id: clusterId,
                  epoch,
                  audienceHash: effectiveAudienceHash,
                  sender_agent_id: agentId || userId,
                  target_account_ids: [recipUserId],
                  targetAgentId: targetAgent
                }
              );
            }
          }
        }
      } catch (evtErr) {
        console.error('[clusterRoutes] Error logging key distribution recipient external events:', evtErr);
      }
    }

    const persistedRecipients = Array.from(targetRecipientSet);
    return res.status(201).json({
      success: true,
      data: {
        clusterId,
        epoch,
        audienceHash: effectiveAudienceHash,
        rosterHash: canonicalRosterHash,
        distributedCount: insertedRows.length,
        persistedRecipients
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { message: err?.message || 'Internal server error.' } });
  }
});

// 12b. GET /clusters/:clusterId/key-distribution (Retrieve encrypted group/subgroup key package for the caller)
router.get('/clusters/:clusterId/key-distribution', requireUserOrAgentAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const clusterId = req.params.clusterId as string;
    const supabase = getSupabaseClient();
    const tables = await getClusterTables(supabase);
    const userId = req.user!.id;
    const agentId = req.user!.agentId;

    if (await isClusterDissolved(supabase, clusterId)) {
      return res.status(403).json({ success: false, error: { message: 'Forbidden: This cluster has been dissolved.' } });
    }

    const isMember = await isClusterMember(supabase, clusterId, userId, agentId);
    if (!isMember) {
      return res.status(403).json({ success: false, error: { message: 'Forbidden: You must be an active member of this cluster.' } });
    }

    const rawEpoch = req.query.epoch ? parseInt(String(req.query.epoch), 10) : undefined;
    const requestedAudienceHash =
      typeof req.query.audienceHash === 'string' && req.query.audienceHash.trim() && req.query.audienceHash.trim() !== 'ALL'
        ? req.query.audienceHash.trim()
        : 'ALL';

    let targetEpoch = rawEpoch;
    if (!targetEpoch || isNaN(targetEpoch)) {
      const { data: epochs } = await supabase
        .from(tables.epochs)
        .select('epoch')
        .eq('clusterId', clusterId)
        .order('epoch', { ascending: false })
        .limit(1);
      targetEpoch = epochs && epochs.length > 0 ? epochs[0].epoch : 1;
    }

    const callerAgent = normalizeAgentId(agentId);

    const distRows = await readKeyDistributionsForEpoch(supabase, tables, clusterId, targetEpoch);

    const audienceFilteredRows = (distRows || []).filter((d: any) => {
      const pkg = parseKeyDistributionPackage(d.encryptedKeyPackage);
      return extractPackageAudienceHash(pkg) === requestedAudienceHash;
    });

    const matched = audienceFilteredRows.find((d: any) => normalizeAgentId(d.recipientAgentId) === callerAgent);

    if (!matched) {
      return res.status(200).json({
        success: false,
        data: null,
        error: {
          code: 'KEY_PACKAGE_NOT_FOUND',
          message: `No encrypted key package found for agent ${agentId} at epoch ${targetEpoch} (${requestedAudienceHash}).`
        }
      });
    }

    const { data: epochMeta } = await supabase
      .from(tables.epochs)
      .select('keyFingerprint')
      .eq('clusterId', clusterId)
      .eq('epoch', targetEpoch)
      .maybeSingle();

    const parsedPkg = parseKeyDistributionPackage(matched.encryptedKeyPackage);

    // Resolve distributor agent, primary public key, and historical epoch public keys
    let senderAgentId: string | null = parsedPkg?.senderAgentId ? normalizeAgentId(parsedPkg.senderAgentId) : null;
    let senderPublicKey: any = parsedPkg?.senderPublicKey || null;
    const senderPublicKeyHistory: Array<{ keyEpoch: number; publicKey: any; fingerprint?: string | null }> = [];
    const pushSenderHistoryKey = (keyEpochNum: number, rawPub: any, fp?: string | null) => {
      if (!rawPub) return;
      let parsedPub = rawPub;
      if (typeof rawPub === 'string') {
        try {
          parsedPub = JSON.parse(rawPub);
        } catch {
          parsedPub = rawPub;
        }
      }
      const serialized = typeof parsedPub === 'string' ? parsedPub : JSON.stringify(parsedPub);
      if (!serialized) return;
      if (!senderPublicKeyHistory.some((h) => (typeof h.publicKey === 'string' ? h.publicKey : JSON.stringify(h.publicKey)) === serialized)) {
        senderPublicKeyHistory.push({ keyEpoch: keyEpochNum, publicKey: parsedPub, fingerprint: fp || null });
      }
    };

    try {
      const { data: clusterRow } = await supabase
        .from(tables.clusters)
        .select('ownerUserId, ownerAgentId')
        .eq('id', clusterId)
        .maybeSingle();

      if (!senderAgentId && clusterRow?.ownerAgentId) {
        senderAgentId = normalizeAgentId(clusterRow.ownerAgentId);
      }

      let distributorUid: string | null = null;
      if (senderAgentId) {
        const cleanSender = senderAgentId.replace(/^@+/, '');
        const senderVariants = Array.from(new Set([cleanSender, cleanSender.toUpperCase(), cleanSender.toLowerCase()].filter(Boolean)));
        const { data: senderUserRow } = await supabase
          .from('users')
          .select('id, agentId')
          .in('agentId', senderVariants)
          .limit(1)
          .maybeSingle();
        distributorUid = senderUserRow?.id || null;
      }
      if (!distributorUid && (!senderAgentId || (clusterRow?.ownerAgentId && normalizeAgentId(clusterRow.ownerAgentId) === senderAgentId))) {
        distributorUid = clusterRow?.ownerUserId || null;
      }

      if (distributorUid) {
        const distAuthUser = await getCachedAuthUserById(supabase, distributorUid);
        const distMeta = distAuthUser?.user_metadata || {};
        const rawDistPub = distMeta.e2eePublicKey || null;
        if (rawDistPub) {
          pushSenderHistoryKey(Number(distMeta.e2eeKeyEpoch || 1), rawDistPub, distMeta.e2eePublicKeyFingerprint || null);
          if (!senderPublicKey) {
            try {
              senderPublicKey = typeof rawDistPub === 'string' ? JSON.parse(rawDistPub) : rawDistPub;
            } catch {
              senderPublicKey = rawDistPub;
            }
          }
        }
        const epHist = distMeta.e2eeEpochHistory;
        if (epHist && typeof epHist === 'object') {
          for (const [epKey, epVal] of Object.entries(epHist) as Array<[string, any]>) {
            const epNum = Number(epVal?.keyEpoch || epKey || 1);
            if (epVal?.publicKey) {
              pushSenderHistoryKey(epNum, epVal.publicKey, epVal.fingerprint || null);
            }
          }
        }
      }
    } catch {}

    // Resolve caller's current E2EE public key & fingerprint to detect key rotation mismatch
    let recipientPublicKey: any = parsedPkg?.recipientPublicKey || null;
    let recipientKeyFingerprint: string | null = parsedPkg?.recipientKeyFingerprint || null;
    let callerCurrentFingerprint: string | null = null;
    let callerCurrentKeyEpoch: number = 1;
    if (userId) {
      try {
        const callerAuthUser = await getCachedAuthUserById(supabase, userId);
        const callerMeta = callerAuthUser?.user_metadata || {};
        callerCurrentFingerprint = callerMeta.e2eePublicKeyFingerprint || null;
        callerCurrentKeyEpoch = callerMeta.e2eeKeyEpoch || 1;
        if (!recipientPublicKey && callerMeta.e2eePublicKey) {
          try {
            recipientPublicKey = typeof callerMeta.e2eePublicKey === 'string'
              ? JSON.parse(callerMeta.e2eePublicKey)
              : callerMeta.e2eePublicKey;
          } catch {
            recipientPublicKey = callerMeta.e2eePublicKey;
          }
        }
        if (!recipientKeyFingerprint && callerMeta.e2eePublicKeyFingerprint) {
          recipientKeyFingerprint = callerMeta.e2eePublicKeyFingerprint;
        }
      } catch {}
    }

    const defaultAad = requestedAudienceHash !== 'ALL'
      ? `aamarva-cluster-group-key:${clusterId}:${targetEpoch}:${requestedAudienceHash}`
      : `aamarva-cluster-group-key:${clusterId}:${targetEpoch}`;
    const aadStr = parsedPkg?.aad || defaultAad;
    const hkdfSaltStr = parsedPkg?.hkdfSalt || 'aamarva-e2ee-channel-v1';
    const hkdfInfoStr = parsedPkg?.hkdfInfo || `aamarva-channel:${clusterId}`;
    const pkgKeyFingerprint = parsedPkg?.keyFingerprint || parsedPkg?.wrappingParams?.keyFingerprint || null;
    const resolvedKeyFingerprint = pkgKeyFingerprint || (requestedAudienceHash === 'ALL' ? (epochMeta?.keyFingerprint || null) : null);
    const resolvedRecipientKeyEpoch = parsedPkg?.recipientKeyEpoch || parsedPkg?.wrappingParams?.recipientKeyEpoch || null;
    const recipientKeyMismatch = Boolean(
      parsedPkg?.recipientKeyFingerprint &&
      callerCurrentFingerprint &&
      parsedPkg.recipientKeyFingerprint !== callerCurrentFingerprint
    );

    const wrappingParams = {
      algorithm: 'AES-256-GCM',
      kdf: 'ECDH-P256-HKDF-SHA256',
      curve: 'P-256',
      hkdfHash: 'SHA-256',
      hkdfSalt: hkdfSaltStr,
      hkdfInfo: hkdfInfoStr,
      aad: aadStr,
      iv: parsedPkg?.iv || parsedPkg?.nonce || null,
      ciphertext: parsedPkg?.key || parsedPkg?.ciphertext || null,
      audienceHash: requestedAudienceHash,
      keyFingerprint: resolvedKeyFingerprint,
      senderAgentId,
      senderPublicKey,
      recipientAgentId: callerAgent,
      recipientPublicKey,
      recipientKeyFingerprint,
      recipientKeyEpoch: resolvedRecipientKeyEpoch
    };

    let enrichedPackageString = matched.encryptedKeyPackage;
    let enrichedPackageObj = parsedPkg;
    if (parsedPkg && typeof parsedPkg === 'object') {
      enrichedPackageObj = {
        ...parsedPkg,
        clusterId,
        epoch: targetEpoch,
        audienceHash: requestedAudienceHash,
        ...(resolvedKeyFingerprint ? { keyFingerprint: resolvedKeyFingerprint } : {}),
        ...(senderAgentId ? { senderAgentId } : {}),
        ...(senderPublicKey ? { senderPublicKey } : {}),
        recipientAgentId: callerAgent,
        ...(recipientPublicKey ? { recipientPublicKey } : {}),
        ...(recipientKeyFingerprint ? { recipientKeyFingerprint } : {}),
        ...(resolvedRecipientKeyEpoch ? { recipientKeyEpoch: resolvedRecipientKeyEpoch } : {}),
        aad: aadStr,
        hkdfSalt: hkdfSaltStr,
        hkdfInfo: hkdfInfoStr,
        wrappingParams
      };
      enrichedPackageString = JSON.stringify(enrichedPackageObj);
    }

    const persistedRecipientsList = Array.from(
      new Set(audienceFilteredRows.map((d: any) => normalizeAgentId(d.recipientAgentId)).filter(Boolean))
    );
    const staleRecipientsList: string[] = [];
    if (persistedRecipientsList.length > 0) {
      try {
        const recipientVariants = Array.from(
          new Set(
            persistedRecipientsList.flatMap((aid) => {
              const clean = String(aid || '').trim().replace(/^@+/, '');
              return [clean, clean.toUpperCase(), clean.toLowerCase()].filter(Boolean);
            })
          )
        );
        const { data: recipFpRows } = await supabase
          .from('users')
          .select('id, agentId, e2eePublicKeyFingerprint, e2eeKeyEpoch')
          .in('agentId', recipientVariants);
        const currentFpByAgent = new Map<string, string>();
        await Promise.all(
          (recipFpRows || []).map(async (u: any) => {
            const normId = normalizeAgentId(u.agentId);
            if (!normId) return;
            let activeFp = typeof u.e2eePublicKeyFingerprint === 'string' ? u.e2eePublicKeyFingerprint.trim() : '';
            if (u.id) {
              try {
                const authUser = await getCachedAuthUserById(supabase, u.id);
                const metaFp = authUser?.user_metadata?.e2eePublicKeyFingerprint;
                const metaEpoch = Number(authUser?.user_metadata?.e2eeKeyEpoch || 0);
                const dbEpoch = Number(u.e2eeKeyEpoch || 0);
                if (typeof metaFp === 'string' && metaFp.trim() && (!activeFp || metaEpoch >= dbEpoch)) {
                  activeFp = metaFp.trim();
                }
              } catch {}
            }
            if (activeFp) {
              currentFpByAgent.set(normId, activeFp);
            }
          })
        );
        for (const row of audienceFilteredRows) {
          const normRecip = normalizeAgentId(row.recipientAgentId);
          if (!normRecip || staleRecipientsList.includes(normRecip)) continue;
          const rowPkg = parseKeyDistributionPackage(row.encryptedKeyPackage);
          const wrappedFp = rowPkg?.recipientKeyFingerprint || rowPkg?.wrappingParams?.recipientKeyFingerprint;
          const activeFp = currentFpByAgent.get(normRecip);
          if (wrappedFp && activeFp && wrappedFp !== activeFp) {
            staleRecipientsList.push(normRecip);
          }
        }
      } catch {}
    }

    return res.json({
      success: true,
      data: {
        clusterId,
        epoch: targetEpoch,
        audienceHash: requestedAudienceHash,
        keyFingerprint: resolvedKeyFingerprint,
        rosterHash: parsedPkg?.rosterHash || null,
        senderAgentId,
        senderPublicKey: senderPublicKey ? (typeof senderPublicKey === 'string' ? senderPublicKey : JSON.stringify(senderPublicKey)) : null,
        senderPublicKeyJwk: senderPublicKey,
        senderPublicKeyHistory,
        recipientAgentId: callerAgent,
        recipientPublicKey: recipientPublicKey ? (typeof recipientPublicKey === 'string' ? recipientPublicKey : JSON.stringify(recipientPublicKey)) : null,
        recipientPublicKeyJwk: recipientPublicKey,
        recipientKeyFingerprint,
        recipientKeyEpoch: resolvedRecipientKeyEpoch,
        callerCurrentKeyEpoch,
        recipientKeyMismatch,
        wrappingParams,
        keyPackage: enrichedPackageObj,
        encryptedKeyPackage: enrichedPackageString,
        persistedRecipients: persistedRecipientsList,
        staleRecipients: staleRecipientsList
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { message: err?.message || 'Internal server error.' } });
  }
});

// 12c. POST /clusters/:clusterId/rotate-key (Initiate cluster group key rotation and advance epoch)
router.post('/clusters/:clusterId/rotate-key', requireHumanSession, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const clusterId = req.params.clusterId as string;
    const supabase = getSupabaseClient();
    const tables = await getClusterTables(supabase);
    const userId = req.user!.id;
    const agentId = req.user!.agentId;

    if (await isClusterDissolved(supabase, clusterId)) {
      return res.status(403).json({ success: false, error: { message: 'Forbidden: This cluster has been dissolved.' } });
    }

    // Only cluster admin or owner can rotate key
    const isAdmin = await (isClusterAdmin as any)(supabase, clusterId, userId, agentId);
    if (!isAdmin) {
      return res.status(403).json({ success: false, error: { message: 'Forbidden: Only cluster admin or owner can rotate the group key.' } });
    }

    const { nextEpoch: userNextEpoch, keyFingerprint, distributions, rosterHash: reqRosterHash } = req.body || {};

    // Query active members and verify rosterHash if provided
    const { data: memberRows, error: memberErr } = await supabase
      .from(tables.members)
      .select('agentId, status')
      .eq('clusterId', clusterId);

    if (memberErr) {
      throw new Error(`Failed to query active members for key rotation: ${memberErr.message}`);
    }

    const activeAgents = new Set<string>();
    (memberRows || []).forEach((m: any) => {
      if (m.status !== 'dissolved' && m.status !== 'inactive' && m.status !== 'removed') {
        const aId = normalizeAgentId(m.agentId);
        if (aId) activeAgents.add(aId);
      }
    });
    const canonicalRosterHash = computeServerRosterHash(Array.from(activeAgents));
    if (reqRosterHash && String(reqRosterHash).trim() !== canonicalRosterHash) {
      return res.status(409).json({
        success: false,
        error: {
          code: 'ROSTER_STALE',
          message: 'Cluster active membership roster changed before key rotation completed.',
          expectedRosterHash: canonicalRosterHash
        }
      });
    }

    // Find current latest epoch
    const { data: existingEpochs } = await supabase
      .from(tables.epochs)
      .select('id, epoch, keyFingerprint')
      .eq('clusterId', clusterId)
      .order('epoch', { ascending: false })
      .limit(1);

    const latestEpochRow = existingEpochs && existingEpochs.length > 0 ? existingEpochs[0] : null;
    const currentEpoch = latestEpochRow && typeof latestEpochRow.epoch === 'number' ? latestEpochRow.epoch : 1;

    // If caller supplied userNextEpoch targeting an already sealed epoch, reject
    if (typeof userNextEpoch === 'number' && Number.isFinite(userNextEpoch)) {
      const { data: targetRow } = await supabase
        .from(tables.epochs)
        .select('id, epoch, keyFingerprint')
        .eq('clusterId', clusterId)
        .eq('epoch', userNextEpoch)
        .maybeSingle();
      if (targetRow && isSealedEpochFp(targetRow.keyFingerprint)) {
        return res.status(409).json({
          success: false,
          error: {
            code: 'EPOCH_KEY_ALREADY_SEALED',
            message: `Epoch ${userNextEpoch} is already sealed and immutable. Choose epoch ${currentEpoch + 1}.`,
            epoch: userNextEpoch,
            existingKeyFingerprint: targetRow.keyFingerprint
          }
        });
      }
    }

    // Seal a pending/rotation-required epoch in-place when appropriate, otherwise advance epoch
    const canSealCurrentPending = Boolean(
      latestEpochRow &&
      isPendingOrRotationEpochFp(latestEpochRow.keyFingerprint) &&
      (userNextEpoch === undefined || userNextEpoch === null || userNextEpoch === currentEpoch)
    );
    const nextEpoch = canSealCurrentPending
      ? currentEpoch
      : (typeof userNextEpoch === 'number' && userNextEpoch > currentEpoch ? userNextEpoch : currentEpoch + 1);

    const now = new Date().toISOString();
    const resolvedEpochFp = (typeof keyFingerprint === 'string' && keyFingerprint.trim()) ? keyFingerprint.trim() : 'ROTATED';

    if (canSealCurrentPending && latestEpochRow?.id) {
      const { error: updErr } = await supabase
        .from(tables.epochs)
        .update({ keyFingerprint: resolvedEpochFp })
        .eq('id', latestEpochRow.id);
      if (updErr) {
        throw new Error(`Failed to seal rotated cluster epoch: ${updErr.message}`);
      }
    } else {
      const { data: existingTargetRow } = await supabase
        .from(tables.epochs)
        .select('id, keyFingerprint')
        .eq('clusterId', clusterId)
        .eq('epoch', nextEpoch)
        .maybeSingle();

      if (existingTargetRow && isSealedEpochFp(existingTargetRow.keyFingerprint)) {
        return res.status(409).json({
          success: false,
          error: {
            code: 'EPOCH_KEY_ALREADY_SEALED',
            message: `Epoch ${nextEpoch} is already sealed and immutable.`,
            epoch: nextEpoch,
            existingKeyFingerprint: existingTargetRow.keyFingerprint
          }
        });
      } else if (existingTargetRow) {
        const { error: updErr } = await supabase
          .from(tables.epochs)
          .update({ keyFingerprint: resolvedEpochFp })
          .eq('id', existingTargetRow.id);
        if (updErr) {
          throw new Error(`Failed to update cluster epoch: ${updErr.message}`);
        }
      } else {
        const epochId = `epoch_${crypto.randomUUID()}`;
        const { error: epochErr } = await supabase.from(tables.epochs).insert({
          id: epochId,
          clusterId,
          epoch: nextEpoch,
          keyFingerprint: resolvedEpochFp,
          createdAt: now
        });
        if (epochErr) {
          throw new Error(`Failed to insert rotated cluster epoch: ${epochErr.message}`);
        }
      }
    }

    // Resolve distributor E2EE public key so recipients have the exact wrapping public key
    let distributorPublicKey: any = req.body?.senderPublicKey || null;
    if (!distributorPublicKey && userId) {
      try {
        const distAuthUser = await getCachedAuthUserById(supabase, userId);
        distributorPublicKey = distAuthUser?.user_metadata?.e2eePublicKey || null;
      } catch {}
    }
    let parsedDistributorPub: any = distributorPublicKey;
    if (typeof distributorPublicKey === 'string') {
      try {
        parsedDistributorPub = JSON.parse(distributorPublicKey);
      } catch {
        parsedDistributorPub = distributorPublicKey;
      }
    }
    const normDistributorAgentId = normalizeAgentId(req.body?.senderAgentId || agentId);

    let distributedCount = 0;
    const persistedRecipientsSet = new Set<string>();
    if (Array.isArray(distributions) && distributions.length > 0) {
      const distInserts: any[] = [];
      for (const d of distributions) {
        const normTarget = normalizeAgentId(d.recipientAgentId);
        if (!normTarget || !d.encryptedKeyPackage || !activeAgents.has(normTarget)) continue;

        let pkgObj: any = null;
        if (typeof d.encryptedKeyPackage === 'string') {
          try {
            pkgObj = JSON.parse(d.encryptedKeyPackage);
          } catch {
            pkgObj = null;
          }
        } else if (typeof d.encryptedKeyPackage === 'object') {
          pkgObj = { ...d.encryptedKeyPackage };
        }

        if (pkgObj && typeof pkgObj === 'object') {
          const effSenderId = normalizeAgentId(d.senderAgentId || pkgObj.senderAgentId || normDistributorAgentId);
          let effSenderPub = d.senderPublicKey || pkgObj.senderPublicKey || parsedDistributorPub;
          if (typeof effSenderPub === 'string') {
            try {
              effSenderPub = JSON.parse(effSenderPub);
            } catch {}
          }
          const aadStr = pkgObj.aad || `aamarva-cluster-group-key:${clusterId}:${nextEpoch}`;
          const hkdfSaltStr = pkgObj.hkdfSalt || 'aamarva-e2ee-channel-v1';
          const hkdfInfoStr = pkgObj.hkdfInfo || `aamarva-channel:${clusterId}`;
          const effRecipEpoch = d.recipientKeyEpoch || pkgObj.recipientKeyEpoch || pkgObj.wrappingParams?.recipientKeyEpoch;
          const effKeyFp = keyFingerprint || pkgObj.keyFingerprint || pkgObj.wrappingParams?.keyFingerprint;

          pkgObj = {
            ...pkgObj,
            clusterId,
            epoch: nextEpoch,
            audienceHash: 'ALL',
            rosterHash: canonicalRosterHash,
            ...(effKeyFp ? { keyFingerprint: effKeyFp } : {}),
            ...(typeof effRecipEpoch === 'number' ? { recipientKeyEpoch: effRecipEpoch } : {}),
            recipientAgentId: normTarget,
            ...(effSenderId ? { senderAgentId: effSenderId } : {}),
            ...(effSenderPub ? { senderPublicKey: effSenderPub } : {}),
            aad: aadStr,
            hkdfSalt: hkdfSaltStr,
            hkdfInfo: hkdfInfoStr,
            wrappingParams: {
              ...(pkgObj.wrappingParams && typeof pkgObj.wrappingParams === 'object' ? pkgObj.wrappingParams : {}),
              algorithm: 'AES-256-GCM',
              kdf: 'ECDH-P256-HKDF-SHA256',
              curve: 'P-256',
              hkdfHash: 'SHA-256',
              hkdfSalt: hkdfSaltStr,
              hkdfInfo: hkdfInfoStr,
              aad: aadStr,
              iv: pkgObj.iv || pkgObj.nonce,
              audienceHash: 'ALL',
              rosterHash: canonicalRosterHash,
              ...(effKeyFp ? { keyFingerprint: effKeyFp } : {}),
              ...(typeof effRecipEpoch === 'number' ? { recipientKeyEpoch: effRecipEpoch } : {}),
              ...(effSenderId ? { senderAgentId: effSenderId } : {}),
              ...(effSenderPub ? { senderPublicKey: effSenderPub } : {}),
              recipientAgentId: normTarget
            }
          };
        }

        persistedRecipientsSet.add(normTarget);
        distInserts.push({
          id: `dist_${crypto.randomUUID()}`,
          clusterId,
          epoch: nextEpoch,
          recipientAgentId: normTarget,
          encryptedKeyPackage: pkgObj ? JSON.stringify(pkgObj) : String(d.encryptedKeyPackage),
          createdAt: now
        });
      }
      if (distInserts.length > 0) {
        // Remove any prior cluster-wide distributions on nextEpoch before inserting rotated ones
        let delIds: string[] = [];
        try {
          const oldDists = await readKeyDistributionsForEpoch(supabase, tables, clusterId, nextEpoch);
          delIds = (oldDists || [])
            .filter((ex: any) => {
              const exNorm = normalizeAgentId(ex.recipientAgentId);
              if (!persistedRecipientsSet.has(exNorm)) return false;
              return extractPackageAudienceHash(parseKeyDistributionPackage(ex.encryptedKeyPackage)) === 'ALL';
            })
            .map((ex: any) => ex.id)
            .filter(Boolean);
        } catch {}

        await insertKeyDistributions(
          supabase,
          tables,
          clusterId,
          nextEpoch,
          distInserts,
          delIds,
          'Failed to insert rotated key distributions'
        );
        distributedCount = distInserts.length;
      }
    }

    // Record Footprint for initiating user
    try {
      await logAgentFootprint(
        userId,
        'CLUSTER_KEY_ROTATED',
        'Initiated cluster key rotation',
        clusterId,
        req.user?.agentId,
        `/clusters/${clusterId}/rotate-key`
      );
      (req as any).alreadyRecordedSlaveActivity = true;
    } catch (fpErr) {
      console.error('[clusterRoutes] Error logging key rotation footprint:', fpErr);
    }

    // Record recipient external events for affected active cluster members
    try {
      const { data: memberUserRows } = await supabase
        .from(tables.members)
        .select('userId, agentId, status')
        .eq('clusterId', clusterId);

      const activeMemberUserIds = new Set<string>();
      const agentToUserMap = new Map<string, string>();
      (memberUserRows || []).forEach((m: any) => {
        if (m.status !== 'dissolved' && m.status !== 'inactive' && m.status !== 'removed') {
          if (m.userId) activeMemberUserIds.add(m.userId);
          if (m.agentId && m.userId) agentToUserMap.set(normalizeAgentId(m.agentId), m.userId);
        }
      });

      if (Array.isArray(distributions) && distributions.length > 0) {
        const candidateAgentIds = Array.from(new Set(
          distributions.flatMap((d: any) => {
            const raw = String(d?.recipientAgentId || '').trim();
            if (!raw) return [];
            const norm = normalizeAgentId(raw);
            if (agentToUserMap.has(norm)) return [];
            const bare = raw.replace(/^@+/, '');
            return [raw, bare, `@${bare}`, bare.toUpperCase(), bare.toLowerCase()];
          }).filter(Boolean)
        ));

        if (candidateAgentIds.length > 0) {
          const { data: userRows } = await supabase
            .from('users')
            .select('id, agentId')
            .in('agentId', candidateAgentIds);
          (userRows || []).forEach((u: any) => {
            if (u.agentId && u.id) agentToUserMap.set(normalizeAgentId(u.agentId), u.id);
          });
        }

        distributions.forEach((d: any) => {
          const normAid = normalizeAgentId(d.recipientAgentId);
          const uId = agentToUserMap.get(normAid);
          if (uId) activeMemberUserIds.add(uId);
        });
      }

      for (const memberUid of Array.from(activeMemberUserIds)) {
        if (!memberUid || memberUid === userId) continue;
        await logExternalEvent(
          memberUid,
          'CLUSTER_KEY_ROTATED',
          req.user?.agentId || userId,
          clusterId,
          {
            cluster_id: clusterId,
            new_epoch: nextEpoch,
            sender_agent_id: req.user?.agentId || userId,
            target_account_ids: [memberUid]
          }
        );
      }
    } catch (evtErr) {
      console.error('[clusterRoutes] Error logging key rotation recipient external events:', evtErr);
    }

    res.json({
      success: true,
      data: {
        clusterId,
        previousEpoch: currentEpoch,
        epoch: nextEpoch,
        keyFingerprint: resolvedEpochFp,
        rosterHash: canonicalRosterHash,
        distributedCount,
        persistedRecipients: Array.from(persistedRecipientsSet)
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { message: err?.message || 'Internal server error.' } });
  }
});

// 13. DELETE /clusters/:clusterId/members/:memberAgentId (Kick member - Human authorized only)
router.delete('/clusters/:clusterId/members/:memberAgentId', requireHumanSession, async (req: AuthenticatedRequest, res: Response) => {
  try {
    await SecurityService.getInstance().evaluateRequest(req, 'cluster_member_kick');
    const clusterId = req.params.clusterId as string;
    const memberAgentId = req.params.memberAgentId as string;
    const supabase = getSupabaseClient();
    const tables = await getClusterTables(supabase);
    const userId = req.user!.id;

    if (await isClusterDissolved(supabase, clusterId)) {
      return res.status(403).json({ success: false, error: { message: 'Forbidden: This cluster has been dissolved.' } });
    }

    if (!memberAgentId || typeof memberAgentId !== 'string' || !memberAgentId.trim()) {
      return res.status(400).json({ success: false, error: { message: 'Member Account ID is required.' } });
    }

    // Verify requester is admin or owner
    const isAdmin = await isClusterAdmin(supabase, clusterId, userId);
    if (!isAdmin) {
      return res.status(403).json({ success: false, error: { message: 'Forbidden: Only cluster admins or owners can kick members.' } });
    }

    const cleanMemberAgentId = memberAgentId.trim().replace(/^@/, '');

    // Find the member record (flexible lookup by agentId, clean agentId, or userId)
    let { data: member, error: memberErr } = await supabase
      .from(tables.members)
      .select('*')
      .eq('clusterId', clusterId)
      .eq('agentId', memberAgentId.trim())
      .maybeSingle();

    if (!member && cleanMemberAgentId !== memberAgentId.trim()) {
      const { data: memberAlt } = await supabase
        .from(tables.members)
        .select('*')
        .eq('clusterId', clusterId)
        .eq('agentId', cleanMemberAgentId)
        .maybeSingle();
      if (memberAlt) member = memberAlt;
    }

    if (!member) {
      const { data: memberByUserId } = await supabase
        .from(tables.members)
        .select('*')
        .eq('clusterId', clusterId)
        .eq('userId', cleanMemberAgentId)
        .maybeSingle();
      if (memberByUserId) member = memberByUserId;
    }

    if (memberErr || !member) {
      return res.status(404).json({ success: false, error: { message: 'Member not found in this cluster.' } });
    }

    // Verify target is not cluster owner or admin
    const { data: clusterData } = await supabase
      .from(tables.clusters)
      .select('ownerUserId, ownerAgentId')
      .eq('id', clusterId)
      .maybeSingle();

    const isTargetOwner = (clusterData?.ownerUserId && (clusterData.ownerUserId === member.userId || clusterData.ownerUserId === member.id)) ||
      (clusterData?.ownerAgentId && (clusterData.ownerAgentId.toLowerCase() === (member.agentId || '').toLowerCase() || clusterData.ownerAgentId.toLowerCase() === cleanMemberAgentId.toLowerCase()));

    if (isTargetOwner || member.role === 'owner') {
      return res.status(400).json({ success: false, error: { message: 'Cannot remove the cluster owner/admin.' } });
    }

    // Update membership status to dissolved for specific agent
    const { error: kickErr } = await supabase
      .from(tables.members)
      .update({ status: 'dissolved' })
      .eq('id', member.id);

    if (kickErr) {
      throw new Error(`Failed to update member status: ${kickErr.message}`);
    }

    // Advance cluster epoch upon member removal so future messages require a new key epoch
    try {
      const { data: curEpochs } = await supabase
        .from(tables.epochs)
        .select('epoch')
        .eq('clusterId', clusterId)
        .order('epoch', { ascending: false })
        .limit(1);
      const curEp = curEpochs && curEpochs.length > 0 && typeof curEpochs[0].epoch === 'number' ? curEpochs[0].epoch : 1;
      const nextEp = curEp + 1;
      await supabase.from(tables.epochs).insert({
        id: `epoch_${crypto.randomUUID()}`,
        clusterId,
        epoch: nextEp,
        keyFingerprint: 'ROTATION_REQUIRED_MEMBER_REMOVED',
        createdAt: new Date().toISOString()
      });
    } catch (epErr) {
      console.warn('Failed to advance cluster epoch on member kick:', epErr);
    }

    // Broadcast floor activity & metadata lookup
    let clusterName = 'Cluster';
    try {
      const { data: c } = await supabase.from(tables.clusters).select('name').eq('id', clusterId).maybeSingle();
      if (c?.name) clusterName = c.name;
    } catch (e) {}

    let targetMemberName = cleanMemberAgentId;
    try {
      const targetMeta = await watchtowerActivityService.resolveAgentMeta(cleanMemberAgentId);
      if (targetMeta?.name) targetMemberName = targetMeta.name;
    } catch (e) {}

    // Inbound event for kicked member
    if (member.userId) {
      try {
        await logExternalEvent(
          member.userId,
          'CLUSTER_MEMBER_REMOVED',
          req.user!.agentId || req.user!.id,
          clusterId,
          { clusterId, clusterName, memberAgentId: member.agentId || cleanMemberAgentId }
        );
      } catch (e) {
        try {
          await supabase.from('external_events').insert({
            user_id: member.userId,
            type: 'CLUSTER_MEMBER_REMOVED',
            sender_id: req.user!.agentId || req.user!.id,
            target_id: clusterId,
            created_at: new Date().toISOString()
          });
        } catch (e2) {}
      }
    }

    // Footprint tracking for audit trail
    let removeFp: any = null;
    try {
      removeFp = await logAgentFootprint(
        userId,
        'CLUSTER_MEMBER_REMOVED',
        `agent ${req.user!.agentId || userId} removed member ${cleanMemberAgentId} from cluster ${clusterId}`,
        clusterId,
        req.user!.agentId
      );
    } catch (e) {}

    // Floor activity record safely handled
    try {
      const removeEventId = removeFp?.id || `wt_clu_rem_${crypto.randomUUID()}`;
      await watchtowerActivityService.recordWatchtowerActivity({
        id: removeEventId,
        actorUserId: userId,
        masterId: req.user!.masterId || userId,
        agentId: req.user!.agentId || req.user!.id,
        agentName: req.user!.name,
        avatar: req.user!.avatar,
        emailVerified: req.user!.emailVerified,
        text: `removed @${targetMemberName} from Cluster "${clusterName}"`,
        type: 'CLUSTER_MEMBER_REMOVED',
        category: 'cluster',
        activityKey: `clu_rem:${removeEventId}`,
        endpoint: 'DELETE /api/clusters/:id/members/:memberId',
        peerName: targetMemberName,
        peerAgentId: cleanMemberAgentId,
        cluster: { name: clusterName, id: clusterId, symbol: getClusterSymbol(clusterId) },
        skipFootprintInsert: true
      });
      (req as any).alreadyRecordedSlaveActivity = true;
    } catch (err) {
      console.warn('[ClusterRoutes] Failed to record floor activity:', err);
    }

    res.json({ success: true, message: 'Member was successfully removed from the cluster.' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { message: err?.message || 'Internal server error.' } });
  }
});

// 14. DELETE /clusters/:clusterId/leave (Leave cluster voluntarily - Human authorized only)
router.delete('/clusters/:clusterId/leave', requireHumanSession, async (req: AuthenticatedRequest, res: Response) => {
  try {
    await SecurityService.getInstance().evaluateRequest(req, 'cluster_leave');
    const clusterId = req.params.clusterId as string;
    const supabase = getSupabaseClient();
    const tables = await getClusterTables(supabase);
    const userId = req.user!.id;
    const agentId = req.user!.agentId;

    if (await isClusterDissolved(supabase, clusterId)) {
      return res.status(403).json({ success: false, error: { message: 'Forbidden: This cluster has already been dissolved.' } });
    }

    const { data: member } = await supabase
      .from(tables.members)
      .select('*')
      .eq('clusterId', clusterId)
      .eq('userId', userId)
      .maybeSingle();

    if (!member) {
      return res.status(404).json({ success: false, error: { message: 'You are not a member of this cluster.' } });
    }

    const { data: cluster } = await supabase
      .from(tables.clusters)
      .select('ownerUserId')
      .eq('id', clusterId)
      .maybeSingle();

    if (cluster && cluster.ownerUserId === userId) {
      return res.status(400).json({ success: false, error: { message: 'Cluster owners cannot leave their own cluster; please disband the cluster instead.' } });
    }

    await supabase
      .from(tables.members)
      .update({ status: 'dissolved' })
      .eq('id', member.id);

    // Advance cluster epoch on voluntary leave so departed peer loses future group key access
    try {
      const { data: curEpochs } = await supabase
        .from(tables.epochs)
        .select('epoch')
        .eq('clusterId', clusterId)
        .order('epoch', { ascending: false })
        .limit(1);
      const curEp = curEpochs && curEpochs.length > 0 && typeof curEpochs[0].epoch === 'number' ? curEpochs[0].epoch : 1;
      await supabase.from(tables.epochs).insert({
        id: `epoch_${crypto.randomUUID()}`,
        clusterId,
        epoch: curEp + 1,
        keyFingerprint: 'ROTATION_REQUIRED_MEMBER_LEFT',
        createdAt: new Date().toISOString()
      });
    } catch (epErr) {
      console.warn('Failed to advance cluster epoch on member leave:', epErr);
    }

    const leaveFp = await logAgentFootprint(
      userId,
      'CLUSTER_LEFT',
      `agent ${agentId || 'member'} left cluster`,
      clusterId,
      agentId
    );

    // Broadcast floor activity: [Agent Name] left Cluster "[Cluster Name]"
    let clusterName = 'Cluster';
    try {
      const { data: c } = await supabase.from(tables.clusters).select('name').eq('id', clusterId).maybeSingle();
      if (c?.name) clusterName = c.name;
    } catch (e) {}

    // Notify cluster owner via inbound external event, realtime SSE, and outbound webhook
    if (cluster?.ownerUserId && cluster.ownerUserId !== userId) {
      try {
        await logExternalEvent(
          cluster.ownerUserId,
          'CLUSTER_MEMBER_LEFT',
          agentId || userId,
          clusterId,
          {
            clusterId,
            clusterName,
            memberAgentId: agentId || userId
          }
        );
      } catch (e) {}
    }

    try {
      const leaveEventId = leaveFp?.id || `wt_clu_left_${crypto.randomUUID()}`;
      await watchtowerActivityService.recordWatchtowerActivity({
        id: leaveEventId,
        actorUserId: userId,
        masterId: req.user!.masterId || userId,
        agentId: agentId || req.user!.id,
        agentName: req.user!.name,
        avatar: req.user!.avatar,
        emailVerified: req.user!.emailVerified,
        text: `left Cluster "${clusterName}"`,
        type: 'CLUSTER_LEFT',
        category: 'cluster',
        activityKey: `clu_left:${leaveEventId}`,
        endpoint: 'DELETE /api/clusters/:id/leave',
        cluster: { name: clusterName, id: clusterId, symbol: getClusterSymbol(clusterId) },
        skipFootprintInsert: true
      });
      (req as any).alreadyRecordedSlaveActivity = true;
    } catch (wtErr) {
      console.warn('[ClusterRoutes] Failed to record leave Watchtower activity:', wtErr);
    }

    res.json({ success: true, message: 'Successfully left the cluster.' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { message: err?.message || 'Internal server error.' } });
  }
});

export default router;

