import fs from "fs";
import path from "path";
import nodeCrypto from "crypto";
import jwt from "jsonwebtoken";
import { getSupabaseClient } from '../supabase';
import { config } from '../config';
import { Router, Response, Request, NextFunction } from 'express';
import { applicationService } from '../services/applicationService';
import {
  sendApplicationUnderReviewEmail,
  sendAdminOtpEmail,
  sendApplicationApprovedEmail,
  sendApplicationRejectedEmail,
  sendEnterpriseInquiryEmail,
  sendFleetSlotAssignedEmail,
} from '../emailService';
import { ADK_SPECIFICATION, getAdkSpecification, getFrameworkIntegrationSpec, getPlatformSpecification, getEndpointSpecification, FLOOR_MCP_AGENT_ENDPOINTS, getAllAdkEndpoints } from '../adk_spec';
import { logAccountAudit, logAgentFootprint, logExternalEvent } from '../services/auditService';
import { realtimeService } from '../services/realtimeService';
import { watchtowerActivityService } from '../services/watchtowerActivityService';
import { webhookDeliveryService } from '../services/webhookDeliveryService';
import { getInventoryStats, ensureInventoryStock, popInventoryItem, generateUniqueAgentId } from '../services/inventoryService';

function extractRequestContextCredentials(req: Request): string[] {
  return [
    String(req.ip || req.headers['x-forwarded-for'] || ''),
    String(req.headers['user-agent'] || ''),
  ];
}
import {
  generateLoginChallenge,
  verifySetupResponse,
  verifyLoginResponse,
  getUserWebAuthnCredentials,
  deleteWebAuthnCredential,
  generateRegisterOptionsForUser,
} from '../services/webauthnService';
import {
  registerUser,
  loginHuman,
  verifyHumanPasswordCredentials,
  createHumanSession,
  getUserById,
  loginAgent,
  logoutUser,
  logoutHumanSession,
  logoutAgent,
  updateUserProfile,
  deleteUserAccount,
  REFRESH_COOKIE_NAME,
  HUMAN_SESSION_COOKIE_NAME,
  getRefreshCookieOptions,
  getHumanSessionCookieOptions,
  refreshSessionToken,
  rotateAgentApiKey,
  requestAgentApiKeyRotation,
  confirmAgentApiKeyRotation,
  requestEmailChange,
  verifyEmailChange,
  requestAccountVerificationEmail,
  confirmAccountEmailVerification,
  requestForgotPassword,
  resetPassword,
  getResetTokenUser,
  verifyRefreshToken,
  invalidateAllHumanSessionsForUser,
  invalidateUserRecordCache,
  getVerificationStatus,
  updateUserWhitelist,
  findUserById,
  setUserWhitelistDirect,
  getUserWhitelistDirect,
  setUserAccessManagementDirect,
  getUserAccessManagementDirect,
  resolveEffectiveMasterCopySettings,
  consumeOneTimeCopySection,
  getMasterFleetSlaveRows,
  registerExternalAuthCacheInvalidator,
  getCachedAuthUserById,
  switchHumanSessionToken,
  normalizeUserRecord,
  generateApiKey,
  hashApiKey,
  computeApiKeyFingerprint,
  hashPassword,
  DEFAULT_BIO,
  verifyHumanSession,
} from '../authService';
import { getClientIp } from '../utils/networkWhitelist.js';
import { 
  requireHumanSession,
  rejectAgentCredentials,
  requireAgentAuth,
  requireAgent,
  requireUserOrAgentAuth,
  requireHumanSecretsAuth,
  registerRateLimiter,
  humanLoginRateLimiter,
  agentLoginRateLimiter,
  passwordResetRateLimiter,
  directMessageSentLimiter,
  directMessageRetrieveLimiter,
  messageSentLimiter,
  messageRetrieveLimiter,
  tokenRefreshLimiter,
  connectionRequestLimiter,
  emailVerificationLimiter,
  AuthenticatedRequest 
} from '../middleware/authMiddleware';
import { securityLayer } from '../middleware/securityLayerMiddleware';
import { humanLoginFirewall } from '../middleware/humanLoginFirewallMiddleware';
import { SecurityService, SecuritySeverity } from '../services/securityService';
import { CapabilityService } from '../services/capabilityService.js';
import { MasterAccountService } from '../services/masterAccountService.js';
import { getAgentProfile, getAgentActivityStats, getAgents } from '../services/agentService';
import {
  isSlaveAccount,
  createConnection,
  ensureConnectionRecord,
  getConnectionRecord,
  getUserConnections,
  sendMessage,
  getConnectionMessages,
  deleteConnection,
  getRecentConnections,
  resolveUserRecord,
  ConnectionError,
  MAX_BASE64_CIPHERTEXT_LENGTH,
  MAX_DECODED_CIPHERTEXT_BYTES,
  establishDirectConnection,
  getAllCandidateConnectionIdsForConnection
} from '../services/connectionService';
import {
  storeEncryptedAttachment,
  getEncryptedAttachment,
  deleteEncryptedAttachment
} from '../services/attachmentService.js';

import { getClusterTables } from './clusterRoutes';
import floorRoutes from './floorRoutes.js';
import authRoutes from './authRoutes';

const router = Router();

// Auth & Registration routes (with strict whitelist enforcement)
router.use(authRoutes);

// FLOOR: MCP Server & Tool Governance routes
router.use('/floor', floorRoutes);



// 1. POST /api/auth/register & /api/v1/auth/register (Moved to authRoutes.ts)

// 2. POST /api/auth/human/login & /api/v1/auth/human/login (Moved to authRoutes.ts)

// 2a. POST /api/auth/webauthn/verify-setup & /api/v1/auth/webauthn/verify-setup (Moved to authRoutes.ts)
// 2b. POST /api/auth/webauthn/verify-login & /api/v1/auth/webauthn/verify-login (Moved to authRoutes.ts)

// 2c. GET /api/auth/webauthn/passkeys & /api/v1/auth/webauthn/passkeys (List registered passkeys)
router.get(['/auth/webauthn/passkeys', '/v1/auth/webauthn/passkeys'], requireHumanSession, securityLayer('public_reads'), async (req: AuthenticatedRequest, res: Response) => {
  try {
    const passkeys = await getUserWebAuthnCredentials(req.user!.id);
    const safePasskeys = passkeys.map(p => ({
      id: p.id,
      friendlyName: p.friendlyName || 'Device Passkey',
      deviceType: p.deviceType,
      backedUp: p.backedUp,
      createdAt: p.createdAt,
      lastUsedAt: p.lastUsedAt
    }));
    res.json({ success: true, data: safePasskeys });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { message: err?.message || 'Failed to fetch registered passkeys' } });
  }
});

// 2e. POST /api/auth/webauthn/register-options (Start adding a new passkey from dashboard)
router.post(['/auth/webauthn/register-options', '/v1/auth/webauthn/register-options'], requireHumanSession, securityLayer('agent_update'), async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { pendingToken, options } = await generateRegisterOptionsForUser(req.user! as any, req);
    res.json({ success: true, pendingToken, options });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { message: err?.message || 'Failed to generate passkey registration options' } });
  }
});

// 2f. POST /api/auth/webauthn/register-verify (Complete adding a new passkey from dashboard)
router.post(['/auth/webauthn/register-verify', '/v1/auth/webauthn/register-verify'], requireHumanSession, securityLayer('agent_update'), async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { pendingToken, credentialResponse, friendlyName } = req.body;
    if (!pendingToken || !credentialResponse) {
      return res.status(400).json({ success: false, error: { message: 'Missing pendingToken or credentialResponse' } });
    }

    await verifySetupResponse(pendingToken, credentialResponse, friendlyName, req);
    res.json({ success: true, message: 'Passkey registered successfully!' });
  } catch (err: any) {
    res.status(400).json({ success: false, error: { message: err?.message || 'Passkey registration verification failed' } });
  }
});

// 2d. DELETE /api/auth/webauthn/passkeys/:passkeyId (Delete passkey)
router.delete(['/auth/webauthn/passkeys/:passkeyId', '/v1/auth/webauthn/passkeys/:passkeyId'], requireHumanSession, securityLayer('agent_update'), async (req: AuthenticatedRequest, res: Response) => {
  try {
    const passkeyId = String(req.params.passkeyId);
    await deleteWebAuthnCredential(passkeyId, req.user!.id);
    res.json({ success: true, message: 'Passkey removed successfully' });
  } catch (err: any) {
    res.status(400).json({ success: false, error: { message: err?.message || 'Failed to delete passkey' } });
  }
});

// POST /api/auth/login & /api/v1/auth/login (Agent Login)
router.post(['/auth/login', '/v1/auth/login'], securityLayer('auth_login'), async (req: Request, res: Response) => {
  try {
    const { agentId, apiKey } = req.body;
    const clientIp = getClientIp(req);
    const result = await loginAgent({ agentId, apiKey }, clientIp);
    res.cookie(REFRESH_COOKIE_NAME, result.tokens.refreshToken, getRefreshCookieOptions());
    
    const tokens = {
      accessToken: result.tokens.accessToken,
      refreshToken: result.tokens.refreshToken
    };

    // Broadcast floor activity: [Agent Name] logged into the floor
    const effectiveAgentId = result.user?.agentId || agentId;
    watchtowerActivityService.recordWatchtowerActivity({
      actorUserId: result.user?.id,
      masterId: (result.user as any)?.master_id || result.user?.id,
      agentId: effectiveAgentId,
      agentName: result.user?.name || effectiveAgentId,
      avatar: result.user?.avatar || '🤖',
      emailVerified: result.user?.emailVerified === true || result.user?.verificationStatus === 'verified',
      text: 'logged into the floor',
      type: 'AGENT_LOGGED_IN'
    }).catch(console.warn);
      (req as any).alreadyRecordedSlaveActivity = true;

    res.json({
      success: true,
      data: {
        tokens,
        user: result.user
      }
    });
  } catch (err: any) {
    const isForbidden = err.statusCode === 403 || (err.message && (err.message.includes('source network') || err.message.includes('perimeter') || err.message.includes('authorized') || err.message.includes('denied')));
    const status = isForbidden ? 403 : 401;
    res.status(status).json({
      success: false,
      error: { message: status === 403 ? 'Access denied: source network is not authorized.' : (err.message || 'Invalid Account ID or API Key.') }
    });
  }
});

// 3. POST /api/auth/refresh
router.post('/auth/refresh', securityLayer('auth_refresh'), async (req: Request, res: Response) => {
  try {
    const token = (req.cookies && req.cookies[REFRESH_COOKIE_NAME]) || (req.body && req.body.refreshToken);
    if (!token) throw new Error('Refresh token required.');
    const clientIp = getClientIp(req);
    const result = await refreshSessionToken(token, clientIp);
    res.cookie(REFRESH_COOKIE_NAME, result.tokens.refreshToken, getRefreshCookieOptions());
    
    const tokens = {
      accessToken: result.tokens.accessToken,
      refreshToken: result.tokens.refreshToken
    };

    res.json({
      success: true,
      data: {
        tokens
      }
    });
  } catch (err: any) {
    const isForbidden = err.statusCode === 403 || (err.message && (err.message.includes('source network') || err.message.includes('perimeter') || err.message.includes('whitelist') || err.message.includes('authorized') || err.message.includes('denied')));
    const status = isForbidden ? 403 : 401;
    res.status(status).json({
      success: false,
      error: { message: status === 403 ? 'Access denied: source network is not authorized.' : (err.message || 'Invalid refresh token.') }
    });
  }
});

// 4a. POST /api/auth/human/logout (Human session logout only)
router.post(['/auth/human/logout', '/v1/auth/human/logout'], async (req: Request, res: Response) => {
  try {
    const humanSessionCookie = req.cookies?.[HUMAN_SESSION_COOKIE_NAME];
    if (humanSessionCookie) {
      await logoutHumanSession(humanSessionCookie);
    }
    res.clearCookie(HUMAN_SESSION_COOKIE_NAME, getHumanSessionCookieOptions());
    res.json({ success: true, message: 'Human session logged out successfully.' });
  } catch (err: any) {
    console.error('Human logout handler error:', err.message);
    res.status(500).json({ 
      success: false, 
      error: { 
        message: err.message || 'Unknown logout error'
      } 
    });
  }
});

// 4a-1. GET /api/auth/master/accounts - Retrieve master account details and its Slave Agents
router.get(['/auth/master/accounts', '/v1/auth/master/accounts'], requireHumanSession, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const callerId = req.user!.id;
    let masterUserId = (req.user as any).masterUserId || req.user.id || callerId;
    const supabase = getSupabaseClient();

    const callerRec = await findUserById(supabase, callerId);

    const callerEmail = (req.user?.email || callerRec?.email || '').toLowerCase().trim();
    
    // Authoritative Resolution of Pioneer Master Account ID
    let pioneerMasterId = callerRec?.master_id && callerRec.master_id !== callerId ? callerRec.master_id : callerId;
    
    // Only scan active scale entitlements by invitation email if caller isn't already linked or marked primary master
    if (!callerRec?.master_id && callerRec?.is_master_primary !== true && callerEmail) {
      const { data: activeEnts } = await supabase
        .from('master_plan_entitlements')
        .select('master_account_id, metadata')
        .eq('status', 'active')
        .eq('plan_type', 'master_slave_scale');

      if (activeEnts && activeEnts.length > 0) {
        const emailMatchedEnt = activeEnts.find(e => {
          const meta = e.metadata || {};
          const invs = Array.isArray(meta.fleet_slot_invitations) ? meta.fleet_slot_invitations : [];
          const regEmails = Array.isArray(meta.registered_emails) ? meta.registered_emails.map((str: string) => str.toLowerCase().trim()) : [];
          return invs.some((inv: any) => inv.claimed_by_user_id === callerId || String(inv.email || '').toLowerCase().trim() === callerEmail) ||
                 regEmails.includes(callerEmail);
        });
        if (emailMatchedEnt) {
          pioneerMasterId = emailMatchedEnt.master_account_id;
        }
      }
    }

    // Walk up master_id recursively to guarantee absolute primary Pioneer master user
    let currId = pioneerMasterId;
    for (let depth = 0; depth < 5; depth++) {
      const uRec = await findUserById(supabase, currId);
      if (uRec?.master_id && uRec.master_id !== currId && uRec.is_master_primary !== true) {
        currId = uRec.master_id;
      } else {
        break;
      }
    }
    masterUserId = currId;

    const masterPlan = await MasterAccountService.getInstance().getMasterPlan(masterUserId);
    const meta = masterPlan?.metadata || {};
    const registeredEmails: string[] = Array.isArray(meta.registered_emails) ? meta.registered_emails.map((e: string) => e.toLowerCase().trim()) : [];
    const invitations: any[] = Array.isArray(meta.fleet_slot_invitations) ? meta.fleet_slot_invitations : [];
    const invitationEmails = invitations.map((inv: any) => String(inv.email || '').toLowerCase().trim()).filter(Boolean);
    const claimedUserIds = invitations.map((inv: any) => inv.claimed_by_user_id).filter(Boolean);
    const allInvitedEmails = Array.from(new Set([...registeredEmails, ...invitationEmails]));

    const { data: masterUser, error: masterErr } = await supabase
      .from('users')
      .select('*')
      .eq('id', masterUserId)
      .maybeSingle();

    if (masterErr || !masterUser) {
      return res.status(404).json({ success: false, error: { message: 'Master user not found.' } });
    }

    const orConditions: string[] = [
      `master_id.eq.${masterUserId}`,
      `master_id.eq.${callerId}`
    ];

    const fleetIdsFromMeta: string[] = [];
    if ((masterUser as any)?.fleet_id) fleetIdsFromMeta.push(String((masterUser as any).fleet_id).trim());
    if (meta.fleet_id) fleetIdsFromMeta.push(String(meta.fleet_id).trim());
    if (meta.latest_fleet_id) fleetIdsFromMeta.push(String(meta.latest_fleet_id).trim());
    if (Array.isArray(meta.fleet_ids)) {
      meta.fleet_ids.forEach((f: any) => f && fleetIdsFromMeta.push(String(f).trim()));
    }
    for (const fid of Array.from(new Set(fleetIdsFromMeta))) {
      if (fid) orConditions.push(`fleet_id.ilike.${fid}`);
    }

    const { data: masterSlots } = await supabase.from('users').select('id').eq('master_id', masterUserId);
    if (masterSlots) {
      for (const slot of masterSlots) {
        if (slot.id) orConditions.push(`master_id.eq.${slot.id}`);
      }
    }

    for (const em of allInvitedEmails) {
      if (em) orConditions.push(`email.ilike.${em}`);
    }
    for (const id of claimedUserIds) {
      if (id) orConditions.push(`id.eq.${id}`);
    }
    const { data: rawSubAgents } = await supabase.from('users').select('*').or(orConditions.join(','));

    const capService = CapabilityService.getInstance();
    let cleanSubAgents: any[] = [];
    if (rawSubAgents && Array.isArray(rawSubAgents)) {
      // Deduplicate by user id
      const uniqueSubAgentsMap = new Map();
      for (const u of rawSubAgents) {
        if (u.id !== masterUserId) {
          uniqueSubAgentsMap.set(u.id, u);
        }
      }
      const uniqueSubAgents = Array.from(uniqueSubAgentsMap.values());

      cleanSubAgents = await Promise.all(uniqueSubAgents.map(async (u: any) => {
        const { passwordHash, apiKeyHash, ...safe } = u;
        const uEmail = (safe.email || '').toLowerCase().trim();
        const safeAgentId = (safe.agentId || '').trim().replace(/^@/, '');
        
        const isInvitedOrClaimedMasterSlot = Boolean(
          safe.is_master_slot === true ||
          safe.account_type === 'master_slot' ||
          allInvitedEmails.includes(uEmail) ||
          invitations.some(inv => (inv.email || '').toLowerCase().trim() === uEmail || inv.claimed_by_user_id === u.id)
        );

        // Authoritative Master Slot vs Slave Agent classification: honor explicit/invited Master Slots even if their email has '+' subaddressing
        const isSlave = !isInvitedOrClaimedMasterSlot && Boolean(
          safe.account_type === 'slave' ||
          safe.role === 'slave' ||
          safe.is_slave === true ||
          safe.isSlave === true ||
          (typeof safe.email === 'string' && safe.email.toLowerCase().includes('+amr-')) ||
          (safe.owner_email && safe.owner_email.toLowerCase().trim() !== uEmail) ||
          (safe.master_id && safe.master_id !== safe.id)
        );

        const isMasterSlot = !isSlave && safe.id !== masterUserId && isInvitedOrClaimedMasterSlot;

        if (isMasterSlot) {
          const needsNorm = u.is_master_slot !== true || u.account_type !== 'master_slot' || u.role !== 'master' || u.is_slave !== false || u.master_id !== masterUserId;
          safe.is_master_slot = true;
          safe.account_type = 'master_slot';
          safe.role = 'master';
          safe.is_slave = false;
          safe.master_id = masterUserId;
          if (needsNorm) {
            supabase.from('users').update({
              master_id: masterUserId,
              account_type: 'master_slot',
              role: 'master',
              is_master_slot: true,
              is_master_primary: false,
              is_slave: false
            }).eq('id', u.id).then(() => invalidateUserRecordCache(u.id)).catch(() => {});
          }
        } else if (isSlave) {
          const needsNorm = u.is_master_slot !== false || u.account_type !== 'slave' || u.role !== 'slave' || u.is_slave !== true;
          safe.is_master_slot = false;
          safe.account_type = 'slave';
          safe.role = 'slave';
          safe.is_slave = true;
          if (needsNorm) {
            supabase.from('users').update({
              is_master_slot: false,
              account_type: 'slave',
              role: 'slave',
              is_slave: true
            }).eq('id', u.id).then(() => invalidateUserRecordCache(u.id)).catch(() => {});
          }
        }

        let cap: any = null;
        let hasCapabilityIncrement = false;
        let rawExpiresAt: string | null = null;

        if (!isMasterSlot && isSlave) {
          cap = await capService.getAgentCapability(u.id || u.agentId);
          rawExpiresAt = cap?.expires_at || (safe.plan === 'slave_capability' ? (safe.plan_expires_at || safe.expires_at) : null) || null;
          const isUnexpired = Boolean(rawExpiresAt && !isNaN(new Date(rawExpiresAt).getTime()) && new Date(rawExpiresAt).getTime() > Date.now());
          if (isUnexpired) {
            hasCapabilityIncrement = Boolean(
              (cap && cap.status === 'active') ||
              safe.hasCapabilityIncrement ||
              safe.plan === 'slave_capability'
            );
            if (!hasCapabilityIncrement) {
              hasCapabilityIncrement = Boolean(await capService.isAgentCapabilityActive(u.id || u.agentId));
            }
          }
        }

        const effectiveExpiresAt = hasCapabilityIncrement ? rawExpiresAt : null;

        return { 
          ...safe, 
          is_master_slot: isMasterSlot,
          hasCapabilityIncrement: hasCapabilityIncrement,
          isCapped: hasCapabilityIncrement,
          expires_at: effectiveExpiresAt,
          plan_expires_at: effectiveExpiresAt
        };
      }));
    }

    const { passwordHash: _, apiKeyHash: __, ...safeMaster } = masterUser;
    
    // Master accounts never receive capability increments
    (safeMaster as any).hasCapabilityIncrement = false;

    if (!safeMaster.avatar || safeMaster.avatar === '🤖' || safeMaster.avatar === '👾' || (typeof safeMaster.avatar === 'string' && (safeMaster.avatar.includes('robohash.org') || safeMaster.avatar.includes('robohash')))) {
      const cleanName = (safeMaster.name || safeMaster.agentId || 'M').trim().replace(/^@/, '');
      const initial = (cleanName.charAt(0) || 'M').toUpperCase();
      safeMaster.avatar = `data:image/svg+xml;utf8,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="128" height="128" viewBox="0 0 128 128"><rect width="128" height="128" fill="#141414"/><text x="50%" y="54%" font-family="monospace" font-size="56" font-weight="900" fill="#FFFFFF" text-anchor="middle" dominant-baseline="middle">${initial}</text></svg>`)}`;
    }
    if (!safeMaster.agentId && masterUser.agentId) {
      safeMaster.agentId = masterUser.agentId;
    }

    const masterSlotAgents = cleanSubAgents.filter(u => (u.is_master_slot === true || u.account_type === 'master_slot' || (u.role === 'master' && !u.is_slave && u.account_type !== 'slave')) && u.id !== masterUserId);
    const actualSlaveAgents = cleanSubAgents.filter(u => u.id !== masterUserId && !masterSlotAgents.some(m => m.id === u.id));

    const purchasedMasterSlots = typeof masterPlan?.metadata?.master_slots === 'number' ? masterPlan.metadata.master_slots : 1;
    const deployedMasterCount = 1 + masterSlotAgents.length;
    const masterSlotsTotal = Math.max(purchasedMasterSlots, deployedMasterCount);
    const masterSlotsAdded = masterPlan?.metadata?.master_slots_added ?? Math.max(0, masterSlotsTotal - 1);
    const availableMasterSlots = Math.max(0, masterSlotsTotal - deployedMasterCount);

    safeMaster.masterSlotsTotal = masterSlotsTotal;
    safeMaster.masterSlots = masterSlotsTotal;

    let masterCopySettings: any = null;
    try {
      const resolved = await resolveEffectiveMasterCopySettings(supabase, masterUserId);
      masterCopySettings = resolved && Object.keys(resolved).length > 0 ? resolved : (masterPlan?.metadata?.masterCopySettings || null);
    } catch {
      masterCopySettings = masterPlan?.metadata?.masterCopySettings || null;
    }

    return res.json({
      success: true,
      data: {
        masterAgent: safeMaster,
        masterSlotAgents: masterSlotAgents,
        subAgents: actualSlaveAgents,
        slaveAgents: actualSlaveAgents,
        activeAgentId: req.user.id,
        returnMasterId: (req.user as any)?.returnMasterId || null,
        returnSlaveId: (req.user as any)?.returnSlaveId || null,
        masterSlots: masterSlotsTotal,
        masterSlotsTotal: masterSlotsTotal,
        masterSlotsAdded: masterSlotsAdded,
        deployedMasterCount: deployedMasterCount,
        availableMasterSlots: availableMasterSlots,
        masterCopySettings,
        plan: masterPlan || {
          plan_name: 'Master & Slave Agent Plan',
          status: 'inactive',
          allowance_accounts: 0,
          metadata: { master_slots: masterSlotsTotal }
        }
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { message: err?.message || 'Failed to fetch accounts.' } });
  }
});

// 4a-1b. GET /api/auth/master/plan - Retrieve authoritative plan entitlement scoped to requested account
// 4a-1b. GET /api/auth/master/plan - Retrieve authoritative plan entitlement scoped to requested account
router.get(['/auth/master/plan', '/v1/auth/master/plan'], requireHumanSession, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const supabase = getSupabaseClient();
    const primaryUserId = req.user.id;

    const masterServiceForPlan = MasterAccountService.getInstance();
    const resolveRootMaster = (startId: string): Promise<string> => masterServiceForPlan.resolveRootMasterId(supabase, startId);

    const authMasterId = await resolveRootMaster(primaryUserId);

    const requestedAccountId = (req.query?.accountId as string) || (req.query?.userId as string) || primaryUserId;
    const trimmedAccountId = (requestedAccountId || '').trim();

    // Strict Fleet Isolation: Multi-factor robust resolution by id or agentId
    let targetUser: any = null;
    if (trimmedAccountId) {
      targetUser = await findUserById(supabase, trimmedAccountId);
    }
    if (!targetUser && trimmedAccountId) {
      const { data: byAgentId } = await supabase.from('users').select('*').ilike('agentId', trimmedAccountId).maybeSingle();
      targetUser = byAgentId;
    }
    if (!targetUser && trimmedAccountId.startsWith('@')) {
      const stripped = trimmedAccountId.slice(1);
      const { data: byStripped } = await supabase.from('users').select('*').or(`id.eq.${stripped},agentId.ilike.${stripped}`).maybeSingle();
      targetUser = byStripped;
    }
    if (!targetUser && (trimmedAccountId.toLowerCase() === 'master' || trimmedAccountId === authMasterId || trimmedAccountId === primaryUserId)) {
      const byMaster = await findUserById(supabase, authMasterId);
      targetUser = byMaster || req.user;
    }
    if (!targetUser) {
      if (trimmedAccountId && trimmedAccountId !== primaryUserId && trimmedAccountId !== authMasterId) {
        return res.status(404).json({
          success: false,
          error: { message: 'Requested account not found.' }
        });
      }
      targetUser = req.user;
    }

    const targetRootMasterId = targetUser?.id ? await resolveRootMaster(targetUser.id) : authMasterId;
    const isAuthorized = !!(
      targetUser && (
        targetUser.id === primaryUserId ||
        targetUser.id === authMasterId ||
        targetRootMasterId === authMasterId ||
        targetUser.master_id === authMasterId ||
        targetUser.master_id === primaryUserId
      )
    );

    if (!isAuthorized) {
      return res.status(403).json({
        success: false,
        error: {
          message: 'Unauthorized: Cross-fleet subscription access forbidden.'
        }
      });
    }

    // Evaluate Master Slot BEFORE Slave so add-on master slots aren't misclassified as slaves
    const isTargetMasterSlot = Boolean(
      targetUser &&
      targetUser.id !== authMasterId &&
      targetUser.account_type !== 'slave' &&
      targetUser.role !== 'slave' &&
      targetUser.is_slave !== true &&
      !(targetUser.email && String(targetUser.email).includes('+AMR-')) &&
      (targetUser.is_master_slot === true || targetUser.account_type === 'master_slot')
    );

    const isSlave = !isTargetMasterSlot && !!(
      targetUser && (
        targetUser.account_type === 'slave' ||
        targetUser.role === 'slave' ||
        targetUser.is_slave === true ||
        (targetUser.email && String(targetUser.email).includes('+AMR-')) ||
        (targetUser.id !== authMasterId && !!targetUser.master_id)
      )
    );

    const actualMasterId = targetRootMasterId || targetUser?.master_id || authMasterId;

    if (isSlave && targetUser) {
      // SLAVE ACCOUNT SCOPE:
      const capService = CapabilityService.getInstance();
      const masterService = MasterAccountService.getInstance();

      let [
        slaveCap,
        masterPlanObj,
        masterHistory,
        { data: capEvents },
        { data: fleetUsers }
      ] = await Promise.all([
        capService.getAgentCapability(targetUser.id || targetUser.agentId),
        actualMasterId ? masterService.getMasterPlan(actualMasterId) : Promise.resolve(null),
        actualMasterId ? masterService.getMasterPlanHistory(actualMasterId) : Promise.resolve([]),
        supabase
          .from('external_events')
          .select('*')
          .in('type', ['SLAVE_CAPABILITY_ACTIVATED', 'SLAVE_CAPABILITY_BATCH_ACTIVATED'])
          .order('created_at', { ascending: false })
          .limit(50),
        supabase
          .from('users')
          .select('id, agentId, name, avatar, status')
          .or(`id.eq.${actualMasterId},master_id.eq.${actualMasterId}`)
      ]);

      const now = Date.now();
      let isCapActive = !!(
        slaveCap &&
        slaveCap.status === 'active' &&
        slaveCap.expires_at &&
        new Date(slaveCap.expires_at).getTime() > now
      );

      let isMasterActive = false;
      if (actualMasterId && masterPlanObj) {
        const isMasterExpired = !!(masterPlanObj?.expires_at && new Date(masterPlanObj.expires_at).getTime() <= now);
        isMasterActive = !!(masterPlanObj && masterPlanObj.status === 'active' && !isMasterExpired);
      }

      const slaveEvents = (capEvents || []).filter((ev: any) => {
        let details = ev.details;
        if (typeof details === 'string') {
          try { details = JSON.parse(details); } catch (e) {}
        }
        return ev.user_id === targetUser.id || 
               details?.user_id === targetUser.id || 
               details?.agent_id === targetUser.agentId ||
               (Array.isArray(details?.target_account_ids) && (details.target_account_ids.includes(targetUser.id) || details.target_account_ids.includes(targetUser.agentId)));
      });

      const latestActiveEvent = slaveEvents.find((ev: any) => {
        let details = ev.details;
        if (typeof details === 'string') {
          try { details = JSON.parse(details); } catch (e) {}
        }
        return details?.expires_at && new Date(details.expires_at).getTime() > now;
      }) || slaveEvents[0];

      const isLatestEventActive = !!(
        latestActiveEvent &&
        (() => {
          let details = latestActiveEvent.details;
          if (typeof details === 'string') {
            try { details = JSON.parse(details); } catch (e) {}
          }
          return details?.expires_at && new Date(details.expires_at).getTime() > now;
        })()
      );

      // If slaveCap is not yet populated from cache, construct from user record or event
      if (!slaveCap || !slaveCap.expires_at) {
        if (targetUser.plan_expires_at) {
          slaveCap = {
            id: `usr_cap_${targetUser.id}`,
            agent_id: targetUser.agentId || targetUser.id,
            user_id: targetUser.id,
            capability_level: 1,
            status: new Date(targetUser.plan_expires_at).getTime() > now ? 'active' : 'expired',
            created_at: targetUser.plan_created_at || targetUser.createdAt || new Date().toISOString(),
            updated_at: new Date().toISOString(),
            expires_at: targetUser.plan_expires_at,
            metadata: { upgraded_rate_limits: true }
          };
          isCapActive = new Date(targetUser.plan_expires_at).getTime() > now;
        } else if (latestActiveEvent) {
          let details = latestActiveEvent.details;
          if (typeof details === 'string') {
            try { details = JSON.parse(details); } catch (e) {}
          }
          const evCreated = latestActiveEvent.created_at || new Date().toISOString();
          const evExpires = details?.expires_at || new Date(new Date(evCreated).getTime() + 30 * 24 * 60 * 60 * 1000).toISOString();
          slaveCap = {
            id: latestActiveEvent.id,
            agent_id: targetUser.agentId || targetUser.id,
            user_id: targetUser.id,
            capability_level: 1,
            status: new Date(evExpires).getTime() > now ? 'active' : 'expired',
            created_at: evCreated,
            updated_at: evCreated,
            expires_at: evExpires,
            metadata: details?.metadata || {}
          };
          isCapActive = new Date(evExpires).getTime() > now;
        } else if (targetUser.hasCapabilityIncrement || (targetUser as any).plan === 'slave_capability') {
          const capCreated = targetUser.createdAt || new Date().toISOString();
          slaveCap = {
            id: `plan_cap_${targetUser.id}`,
            agent_id: targetUser.agentId || targetUser.id,
            user_id: targetUser.id,
            capability_level: 1,
            status: 'active',
            created_at: capCreated,
            updated_at: capCreated,
            expires_at: new Date(new Date(capCreated).getTime() + 30 * 24 * 60 * 60 * 1000).toISOString(),
            metadata: { upgraded_rate_limits: true }
          };
          isCapActive = true;
        }
      }

      const effectiveIsActive = isCapActive || isLatestEventActive;

      const fleetLookup = new Map<string, any>();
      for (const u of (fleetUsers || [])) {
        if (u.id) fleetLookup.set(String(u.id).toLowerCase(), u);
        if (u.agentId) fleetLookup.set(String(u.agentId).toLowerCase(), u);
        if (u.name) fleetLookup.set(String(u.name).toLowerCase(), u);
      }
      if (targetUser?.id) fleetLookup.set(String(targetUser.id).toLowerCase(), targetUser);
      if (targetUser?.agentId) fleetLookup.set(String(targetUser.agentId).toLowerCase(), targetUser);
      if (targetUser?.name) fleetLookup.set(String(targetUser.name).toLowerCase(), targetUser);

      const slaveHistory = slaveEvents.map((ev: any) => {
        let details = ev.details;
        if (typeof details === 'string') {
          try { details = JSON.parse(details); } catch (e) {}
        }
        const validityDays = details?.validity_days || details?.metadata?.validity_days_extended || 30;
        const evCreated = ev.created_at;
        const evExpires = details?.expires_at || new Date(new Date(evCreated).getTime() + validityDays * 24 * 60 * 60 * 1000).toISOString();
        const isEvActive = new Date(evExpires).getTime() > now;

        // Authoritatively extract target accounts from details, falling back to event target or fleet lookup
        const rawTargetIds = details?.target_account_ids || 
          (details?.target_slave_id ? [details.target_slave_id] : null) ||
          (details?.user_id ? [details.user_id] : null) ||
          (details?.agent_id ? [details.agent_id] : null) ||
          (ev.user_id && ev.user_id !== actualMasterId ? [ev.user_id] : [targetUser.id]);
        const targetIds: string[] = Array.isArray(rawTargetIds) ? rawTargetIds : [rawTargetIds];

        const targetAccounts = Array.isArray(details?.target_accounts) && details.target_accounts.length > 0
          ? details.target_accounts.map((acc: any) => {
              const matched = fleetLookup.get(String(acc.id || '').toLowerCase()) ||
                              fleetLookup.get(String(acc.agent_id || '').toLowerCase()) ||
                              fleetLookup.get(String(acc.name || '').toLowerCase());
              return {
                id: matched?.id || acc.id,
                agent_id: matched?.agentId || acc.agent_id || acc.id,
                name: matched?.name || acc.name || 'Slave Agent',
                avatar: matched?.avatar || acc.avatar,
                isDeployed: true,
                status: matched?.status || acc.status || 'active'
              };
            })
          : targetIds.map((tid: string) => {
              const matched = fleetLookup.get(String(tid).toLowerCase());
              return {
                id: matched?.id || tid,
                agent_id: matched?.agentId || matched?.agent_id || details?.agent_id || tid,
                name: matched?.name || details?.metadata?.target_slave_name || matched?.agentId || 'Slave Agent',
                avatar: matched?.avatar,
                isDeployed: true,
                status: matched?.status || 'active'
              };
            });

        const targetSlaveId = targetAccounts[0]?.id || targetIds[0] || details?.user_id || targetUser.id;

        return {
          id: ev.id,
          batch_id: details?.batch_id,
          plan_name: 'Capability Increment Plan',
          plan_subtitle: `Per-Slave Agent Rate-Limit Increment (+${validityDays} Days)`,
          plan_type: 'slave_capability',
          action_type: 'capability_increment',
          allowance_accounts: targetAccounts.length,
          accounts_in_transaction: targetAccounts.length,
          target_account_ids: targetIds,
          target_accounts: targetAccounts,
          amount: 100 * targetAccounts.length,
          currency: 'USD',
          created_at: evCreated,
          expires_at: evExpires,
          status: isEvActive ? (details?.status || 'active') : 'expired',
          is_active: isEvActive,
          is_direct: true,
          target_slave_id: targetSlaveId
        };
      });

      const formattedMasterHistory = masterHistory.map((mh: any) => ({
        ...mh,
        id: `inherited_${mh.id}`,
        plan_name: mh.plan_name || (mh.plan_type === 'slave_capability' ? 'Capability Increment Plan' : 'Master & Slave Agent Plan'),
        plan_subtitle: mh.plan_subtitle || (mh.plan_type === 'slave_capability' ? 'Rate-Limit Increment' : `Master Account ${mh.plan_subtitle || 'Purchase'} — Fleet Coverage`),
        is_inherited: true
      }));

      // Deduplicate formattedMasterHistory items (collapse duplicate scale plan entries within 60s window)
      // Strictly exclude other Slaves' capability_increment plans when viewing a Slave session
      const seenMasterScaleKeys = new Set<string>();
      const dedupedMasterHistory = formattedMasterHistory.filter((mItem: any) => {
        if (mItem.plan_type === 'slave_capability' || mItem.action_type === 'capability_increment') {
          const targetsCurrentSlave =
            mItem.target_slave_id === targetUser.id ||
            mItem.target_slave_id === targetUser.agentId ||
            (Array.isArray(mItem.target_account_ids) && (mItem.target_account_ids.includes(targetUser.id) || mItem.target_account_ids.includes(targetUser.agentId))) ||
            (Array.isArray(mItem.target_accounts) && mItem.target_accounts.some((a: any) => a.id === targetUser.id || a.agent_id === targetUser.agentId));
          return Boolean(targetsCurrentSlave);
        }
        const timeKey = Math.floor(new Date(mItem.created_at).getTime() / 60000);
        const dedupeKey = `scale_${timeKey}`;
        if (seenMasterScaleKeys.has(dedupeKey)) return false;
        seenMasterScaleKeys.add(dedupeKey);
        return true;
      });

      const batchItems = dedupedMasterHistory.filter((item: any) => item.is_batch);
      const filteredSlaveHistory = slaveHistory.filter((sItem: any) => {
        const sCreatedMs = sItem.created_at ? new Date(sItem.created_at).getTime() : 0;
        const sExpiresMs = sItem.expires_at ? new Date(sItem.expires_at).getTime() : 0;
        const isPartOfBatch = batchItems.some((bItem: any) => {
          const matchAccount = (
            (Array.isArray(bItem.target_account_ids) && (
              bItem.target_account_ids.includes(sItem.target_slave_id) ||
              bItem.target_account_ids.includes(targetUser.id) ||
              bItem.target_account_ids.includes(targetUser.agentId)
            )) ||
            (Array.isArray(bItem.target_accounts) && bItem.target_accounts.some((a: any) => a.id === targetUser.id || a.agent_id === targetUser.agentId || a.id === sItem.target_slave_id))
          );
          const matchBatchId = (sItem.batch_id && bItem.id === `inherited_${sItem.batch_id}`) || (sItem.batch_id && bItem.id === sItem.batch_id);
          const bCreatedMs = bItem.created_at ? new Date(bItem.created_at).getTime() : 0;
          const bExpiresMs = bItem.expires_at ? new Date(bItem.expires_at).getTime() : 0;
          const windowEndMs = Math.max(bCreatedMs + 120_000, bCreatedMs + (bItem.accounts_in_transaction || 1) * 5_000);
          const matchCreationWindow = sCreatedMs >= (bCreatedMs - 10_000) && sCreatedMs <= windowEndMs;
          const matchExpiryWindow = bExpiresMs > 0 && sExpiresMs > 0 && Math.abs(bExpiresMs - sExpiresMs) <= 120_000;
          return matchBatchId || (matchAccount && (matchCreationWindow || matchExpiryWindow));
        });
        return !isPartOfBatch;
      });

      const combinedSlaveHistory = [...filteredSlaveHistory, ...dedupedMasterHistory];

      let activePlanObj = null;
      if (slaveCap && isCapActive) {
        activePlanObj = {
          id: slaveCap.id,
          master_account_id: targetUser.id,
          plan_type: 'slave_capability',
          plan_name: 'Capability Increment Plan',
          status: 'active',
          allowance_accounts: 1,
          tier: 'capability',
          created_at: slaveCap.created_at || targetUser.created_at,
          updated_at: slaveCap.updated_at,
          expires_at: slaveCap.expires_at,
          metadata: slaveCap.metadata || {}
        };
      } else if (latestActiveEvent && isLatestEventActive) {
        let details = latestActiveEvent.details;
        if (typeof details === 'string') {
          try { details = JSON.parse(details); } catch (e) {}
        }
        activePlanObj = {
          id: latestActiveEvent.id,
          master_account_id: targetUser.id,
          plan_type: 'slave_capability',
          plan_name: 'Capability Increment Plan',
          status: 'active',
          allowance_accounts: 1,
          tier: 'capability',
          created_at: latestActiveEvent.created_at || targetUser.created_at,
          expires_at: details?.expires_at || null,
          metadata: details?.metadata || { validity_days_extended: 30 }
        };
      } else {
        activePlanObj = {
          id: `plan_${targetUser.id}`,
          master_account_id: targetUser.id,
          plan_type: 'slave_capability',
          plan_name: 'Capability Increment Plan',
          status: effectiveIsActive ? 'active' : 'inactive',
          allowance_accounts: 1,
          tier: 'capability',
          created_at: targetUser.created_at || new Date().toISOString(),
          updated_at: new Date().toISOString(),
          expires_at: slaveCap?.expires_at || null
        };
      }

      const inheritedPlanObj = masterPlanObj ? {
        ...masterPlanObj,
        is_inherited: true,
        plan_name: 'Master & Slave Agent Plan',
        status: isMasterActive ? 'active' : 'inactive'
      } : null;

      return res.json({
        success: true,
        data: {
          accountId: targetUser.id,
          accountType: 'slave',
          masterId: actualMasterId,
          inheritedPlan: inheritedPlanObj,
          plan: activePlanObj,
          capability: slaveCap || activePlanObj,
          active: effectiveIsActive || isMasterActive,
          status: (effectiveIsActive || isMasterActive) ? 'active' : 'inactive',
          allowance: 0,
          currentSlaveAgentsCount: 0,
          remainingAllowance: 0,
          slaveAgents: [],
          history: combinedSlaveHistory
        }
      });
    }

    // MASTER ACCOUNT SCOPE:
    const masterUserId = authMasterId;
    const masterService = MasterAccountService.getInstance();

    // Concurrently fetch master plan, direct children (to discover add-on master slots), and plan history
    const [masterPlan, { data: directChildren }, history] = await Promise.all([
      masterService.getMasterPlan(masterUserId),
      supabase
        .from('users')
        .select('*')
        .eq('master_id', masterUserId),
      masterService.getMasterPlanHistory(masterUserId)
    ]);

    const subMasterSlots = (directChildren || []).filter((u: any) => {
      if (u.id === masterUserId || u.status === 'deleted') return false;
      const isSlaveRow = Boolean(
        u.account_type === 'slave' ||
        u.role === 'slave' ||
        u.is_slave === true ||
        u.isSlave === true ||
        (typeof u.email === 'string' && u.email.toLowerCase().includes('+amr-'))
      );
      return !isSlaveRow && (u.is_master_slot === true || u.account_type === 'master_slot' || u.role === 'master');
    });

    let allFleetSubUsers: any[] = [...(directChildren || [])];
    if (subMasterSlots.length > 0) {
      const subMasterIds = subMasterSlots.map((m: any) => m.id).filter(Boolean);
      const { data: nestedSlaves } = await supabase
        .from('users')
        .select('*')
        .in('master_id', subMasterIds);
      if (nestedSlaves && Array.isArray(nestedSlaves)) {
        const seenIds = new Set(allFleetSubUsers.map((u: any) => u.id));
        for (const ns of nestedSlaves) {
          if (!seenIds.has(ns.id)) {
            seenIds.add(ns.id);
            allFleetSubUsers.push(ns);
          }
        }
      }
    }

    const subMasterIdSet = new Set(subMasterSlots.map((m: any) => m.id));
    let cleanSubAgents: any[] = [];
    if (allFleetSubUsers.length > 0) {
      const capService = CapabilityService.getInstance();
      const onlySlaves = allFleetSubUsers.filter((u: any) =>
        u.id !== masterUserId &&
        !subMasterIdSet.has(u.id) &&
        u.is_master_slot !== true &&
        u.account_type !== 'master_slot' &&
        u.is_master_primary !== true &&
        u.status !== 'deleted'
      );

      cleanSubAgents = await Promise.all(onlySlaves.map(async (u: any) => {
        const { passwordHash, apiKeyHash, ...safe } = u;
        const cap = await capService.getAgentCapability(u.id);
        const rawExpiresAt = cap?.expires_at || (safe.plan === 'slave_capability' ? (safe.plan_expires_at || safe.expires_at) : null) || null;
        const isUnexpired = Boolean(rawExpiresAt && !isNaN(new Date(rawExpiresAt).getTime()) && new Date(rawExpiresAt).getTime() > Date.now());
        const hasCapabilityIncrement = isUnexpired && Boolean(
          (cap && cap.status === 'active') ||
          safe.hasCapabilityIncrement ||
          safe.plan === 'slave_capability'
        );
        const expiresAt = hasCapabilityIncrement ? rawExpiresAt : null;
        return {
          ...safe,
          hasCapabilityIncrement,
          isCapped: hasCapabilityIncrement,
          expires_at: expiresAt,
          plan_expires_at: expiresAt
        };
      }));
    }

    const currentSlaveCount = cleanSubAgents.length;
    const now = Date.now();
    const isExpired = !!(masterPlan?.expires_at && new Date(masterPlan.expires_at).getTime() <= now);
    const isActive = Boolean(masterPlan && masterPlan.status === 'active' && !isExpired && (masterPlan.allowance_accounts || 0) > 0);
    const allowance = isActive ? (masterPlan?.allowance_accounts || 0) : 0;

    let rawBlocks = masterPlan?.metadata?.blocks || [];
    if (!Array.isArray(rawBlocks) || rawBlocks.length === 0) {
      if (isActive && allowance > 0) {
        rawBlocks = [{
          id: `plan_box_1_${masterPlan?.id || masterUserId}`,
          plan_number: 1,
          plan_name: masterPlan?.plan_name || 'Master & Slave Agent Plan',
          plan_subtitle: `Base Fleet Roster (${allowance} Slave Agents)`,
          allowance: allowance,
          created_at: masterPlan?.created_at || new Date().toISOString(),
          expires_at: masterPlan?.expires_at || '9999-12-31T23:59:59.999Z',
          status: 'active',
          amount: 500 + Math.max(0, allowance - 10) * 100,
          currency: 'USD'
        }];
      } else {
        rawBlocks = [];
      }
    }

    const activeBlocks = rawBlocks.filter((b: any) => !b.expires_at || new Date(b.expires_at).getTime() > now);
    const earliestActiveTime = activeBlocks.length > 0 ? Math.min(...activeBlocks.map((b: any) => new Date(b.expires_at || '9999-12-31T23:59:59.999Z').getTime())) : 0;

    let assignedCursor = 0;
    const enrichedPlanBlocks = rawBlocks.map((b: any, idx: number) => {
      const expDate = new Date(b.expires_at || '9999-12-31T23:59:59.999Z');
      const expTime = expDate.getTime();
      const isAct = expTime > now;
      const startOfToday = new Date(new Date(now).getFullYear(), new Date(now).getMonth(), new Date(now).getDate()).getTime();
      const startOfExpiry = new Date(expDate.getFullYear(), expDate.getMonth(), expDate.getDate()).getTime();
      let daysLeft = Math.max(0, Math.round((startOfExpiry - startOfToday) / (1000 * 60 * 60 * 24)));
      if (b.created_at) {
        const purchDate = new Date(b.created_at);
        if (!isNaN(purchDate.getTime())) {
          const startOfPurchase = new Date(purchDate.getFullYear(), purchDate.getMonth(), purchDate.getDate()).getTime();
          const totalSpan = Math.round((startOfExpiry - startOfPurchase) / (1000 * 60 * 60 * 24));
          const elapsed = Math.max(0, Math.floor((startOfToday - startOfPurchase) / (1000 * 60 * 60 * 24)));
          daysLeft = Math.max(0, totalSpan - elapsed);
        }
      }
      const bAllowance = typeof b.allowance === 'number' ? b.allowance : 0;
      const bSlaves = bAllowance > 0 ? cleanSubAgents.slice(assignedCursor, assignedCursor + bAllowance) : [];
      const slotStart = bAllowance > 0 ? assignedCursor + 1 : 0;
      const slotEnd = bAllowance > 0 ? assignedCursor + bAllowance : 0;
      assignedCursor += bAllowance;

      return {
        ...b,
        id: b.id || `plan_box_${idx + 1}`,
        plan_number: b.plan_number || (idx + 1),
        plan_name: b.plan_name || (idx === 0 ? 'Master & Slave Agent Plan' : `Fleet Expansion Plan #${idx + 1}`),
        plan_subtitle: b.plan_subtitle || `${bAllowance} Slave Agents`,
        status: isAct ? 'active' : 'expired',
        is_active: isAct,
        days_remaining: expDate.getUTCFullYear() >= 9999 ? null : daysLeft,
        is_earliest_expiry: isAct && activeBlocks.length > 1 && expTime === earliestActiveTime,
        is_later_expiry: isAct && activeBlocks.length > 1 && expTime > earliestActiveTime,
        slot_range: bAllowance > 0 ? `${slotStart} - ${slotEnd}` : 'N/A',
        assigned_slaves: bSlaves,
        deployed_count: bSlaves.length,
        available_count: Math.max(0, bAllowance - bSlaves.length)
      };
    });

    const subMasterAgentsCount = subMasterSlots.length;
    const purchasedMasterSlots = typeof masterPlan?.metadata?.master_slots === 'number' ? masterPlan.metadata.master_slots : 1;
    const deployedMasterCount = 1 + subMasterAgentsCount;
    const computedMasterSlots = Math.max(purchasedMasterSlots, deployedMasterCount);

    const resolvedMasterPlan = isActive && masterPlan ? {
      ...masterPlan,
      status: 'active',
      allowance_accounts: Math.max(masterPlan.allowance_accounts || 0, allowance),
      metadata: {
        ...(masterPlan.metadata || {}),
        master_slots: computedMasterSlots
      }
    } : null;

    return res.json({
      success: true,
      data: {
        accountId: masterUserId,
        accountType: 'master',
        masterId: masterUserId,
        plan: resolvedMasterPlan,
        masterSlots: computedMasterSlots,
        masterSlotsTotal: computedMasterSlots,
        planBlocks: enrichedPlanBlocks,
        activeBlocks: enrichedPlanBlocks.filter(b => b.is_active),
        totalActiveBoxes: activeBlocks.length,
        active: isActive,
        status: isActive ? 'active' : 'inactive',
        allowance: allowance,
        currentSlaveAgentsCount: currentSlaveCount,
        remainingAllowance: Math.max(0, allowance - currentSlaveCount),
        slaveAgents: cleanSubAgents,
        subAgents: cleanSubAgents,
        history: history,
        capability: null,
        fleetId: masterPlan?.metadata?.latest_fleet_id || masterPlan?.metadata?.fleet_id || undefined,
        allFleetIds: masterPlan?.metadata?.fleet_ids || []
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { message: err?.message || 'Failed to retrieve plan state.' } });
  }
});

// 4a-1c. POST /api/auth/master/buy-plan - Authoritative Master & Slave Agent plan purchase/activation
router.post(['/auth/master/buy-plan', '/v1/auth/master/buy-plan', '/auth/master/plan/activate', '/v1/auth/master/plan/activate'], requireHumanSession, async (req: AuthenticatedRequest, res: Response) => {
  (req as any).alreadyRecordedSlaveActivity = true;
  try {
    const callerUser = req.user as any;
    const isCallerSlave = Boolean(
      callerUser?.account_type === 'slave' ||
      callerUser?.role === 'slave' ||
      callerUser?.is_slave === true
    );
    if (isCallerSlave) {
      return res.status(403).json({
        success: false,
        error: { message: 'Slave accounts cannot purchase or modify fleet plans. Switch to your Master account.' }
      });
    }

    const supabase = getSupabaseClient();
    const walkRootMaster = (startId: string): Promise<string> => MasterAccountService.getInstance().resolveRootMasterId(supabase, startId);

    const masterUserId = await walkRootMaster(callerUser?.id);
    const capabilityIncrement = !!req.body?.capabilityIncrement;

    const { data: masterUserRecord } = await supabase
      .from('users')
      .select('id, agentId, name, avatar, emailVerified')
      .eq('id', masterUserId)
      .maybeSingle();

    const masterAgentId = masterUserRecord?.agentId || (req.user as any)?.agentId || masterUserId;
    const masterName = masterUserRecord?.name || req.user?.name || masterAgentId;
    const masterAvatar = masterUserRecord?.avatar || req.user?.avatar;

    // 1. Independent Capability Increment Path (Tied strictly to individual Slave Accounts)
    // Master accounts CANNOT receive capability increments
    if (capabilityIncrement) {
      let rawTargets = req.body?.targetAccountIds || req.body?.targetAgentIds || req.body?.targetAgentId || req.body?.agentId || req.body?.targetAccountId;
      if (!Array.isArray(rawTargets)) {
        rawTargets = rawTargets ? [rawTargets] : [];
      }

      const canonicalSlaveUserMap = new Map<string, any>();
      const rejectedMasterIds: string[] = [];
      const missingTargetIds: string[] = [];

      for (const rawId of rawTargets) {
        if (!rawId || typeof rawId !== 'string') continue;
        const trimmed = rawId.trim();
        const lower = trimmed.toLowerCase();
        if (lower === 'master' || lower === 'master-root') {
          rejectedMasterIds.push(trimmed);
          continue;
        }

        const stripped = trimmed.startsWith('@') ? trimmed.slice(1) : trimmed;

        let { data: targetUser } = await supabase
          .from('users')
          .select('id, agentId, name, master_id, is_master_primary, account_type, role, is_slave, is_master_slot, status, avatar')
          .or(`id.eq.${trimmed},agentId.ilike.${trimmed},agentId.ilike.${stripped}`)
          .maybeSingle();

        if (!targetUser && stripped !== trimmed) {
          const { data: uByStrippedId } = await supabase
            .from('users')
            .select('id, agentId, name, master_id, is_master_primary, account_type, role, is_slave, is_master_slot, status, avatar')
            .eq('id', stripped)
            .maybeSingle();
          targetUser = uByStrippedId;
        }

        if (!targetUser) {
          missingTargetIds.push(trimmed);
          continue;
        }

        const isSlave = Boolean(
          targetUser.account_type === 'slave' ||
          targetUser.is_slave === true ||
          (targetUser.master_id && targetUser.master_id !== targetUser.id && !targetUser.is_master_primary && !targetUser.is_master_slot && targetUser.account_type !== 'master_slot')
        );

        const isMaster = !isSlave && Boolean(
          targetUser.is_master_primary === true ||
          targetUser.account_type === 'master' ||
          targetUser.account_type === 'master_slot' ||
          targetUser.is_master_slot === true ||
          targetUser.id === masterUserId
        );

        if (isMaster) {
          rejectedMasterIds.push(trimmed);
          continue;
        }

        if (targetUser.status !== 'active') {
          return res.status(400).json({
            success: false,
            error: { message: `Target Slave Account '${targetUser.agentId || targetUser.id}' is ${targetUser.status} and cannot receive capability upgrades.` }
          });
        }

        const targetRootMasterId = targetUser.master_id ? await walkRootMaster(targetUser.master_id) : null;
        if (!targetUser.master_id || (targetRootMasterId !== masterUserId && targetUser.master_id !== masterUserId && targetUser.master_id !== callerUser?.id)) {
          return res.status(403).json({
            success: false,
            error: { message: `Unauthorized: Target Slave Account '${targetUser.agentId || targetUser.id}' does not belong to your Master fleet.` }
          });
        }

        canonicalSlaveUserMap.set(targetUser.id, targetUser);
      }

      if (missingTargetIds.length > 0 && canonicalSlaveUserMap.size === 0 && rejectedMasterIds.length === 0) {
        return res.status(404).json({
          success: false,
          error: { message: `Target Slave Account '${missingTargetIds[0]}' not found.` }
        });
      }

      const targetSlaveUsers = Array.from(canonicalSlaveUserMap.values());

      if (targetSlaveUsers.length === 0) {
        return res.status(400).json({
          success: false,
          error: {
            message: 'Capability Increment Plans are strictly and exclusively for Slave accounts and cannot be attached to the Master account.'
          }
        });
      }

      const capService = CapabilityService.getInstance();
      
      // Compute equal capability increment per account
      const totalValidityDaysInput = req.body?.totalValidityDays || req.body?.totalCapabilityUnits;
      let perAccountValidityDays = 30;
      if (totalValidityDaysInput && typeof totalValidityDaysInput === 'number' && totalValidityDaysInput > 0) {
        perAccountValidityDays = Math.max(1, Math.floor(totalValidityDaysInput / targetSlaveUsers.length));
      } else if (req.body?.validityDays && parseInt(req.body.validityDays, 10) > 0) {
        perAccountValidityDays = parseInt(req.body.validityDays, 10);
      }

      const batchId = crypto.randomUUID();
      const nowIso = new Date().toISOString();
      const activationResults: any[] = [];
      const rollbackActions: Array<() => Promise<void>> = [];

      try {
        for (const slaveUser of targetSlaveUsers) {
          const cap = await capService.activateSlaveCapability(masterUserId, slaveUser.id, { validityDays: perAccountValidityDays, batchId });
          
          rollbackActions.push(async () => {
            try {
              await supabase.from('master_plan_entitlements').delete().eq('id', cap.id);
              await supabase.from('capability_entitlements').delete().eq('id', cap.id);
              await supabase.from('users').update({
                hasCapabilityIncrement: false,
                plan: null,
                plan_status: null
              }).eq('id', cap.user_id);
              capService.invalidateCapabilityCache(cap.user_id);
              invalidateUserRecordCache(cap.user_id);
            } catch (e) {}
          });

          try {
            await supabase.from('users').update({
              hasCapabilityIncrement: true,
              plan: 'slave_capability',
              plan_status: 'active',
              plan_expires_at: cap.expires_at,
              plan_created_at: cap.created_at
            }).eq('id', cap.user_id);
            invalidateUserRecordCache(cap.user_id);
          } catch (uErr) {}

          const avatarUrl = slaveUser.avatar || (await supabase.from('users').select('avatar').eq('id', cap.user_id).maybeSingle())?.data?.avatar;

          activationResults.push({
            cap,
            detail: {
              id: cap.user_id,
              agent_id: cap.agent_id,
              name: slaveUser.name || cap.metadata?.target_slave_name || cap.agent_id,
              avatar: avatarUrl,
              isDeployed: true,
              status: 'active',
              expires_at: cap.expires_at
            }
          });
        }
      } catch (activationErr: any) {
        // ATOMIC TRANSACTION GUARANTEE: Roll back all partial allocations on failure
        for (const rollback of rollbackActions.reverse()) {
          await rollback().catch(() => {});
        }
        return res.status(500).json({
          success: false,
          error: {
            message: `Capability Increment Plan activation failed: ${activationErr?.message || 'Transaction aborted.'}. Partial allocations rolled back.`
          }
        });
      }

      const activatedList = activationResults.map(r => r.cap);
      const activatedAccountsDetails = activationResults.map(r => r.detail);
      const batchExpiresAt = activatedList.reduce((latest: string, c: any) => {
        if (!c?.expires_at) return latest;
        return new Date(c.expires_at).getTime() > new Date(latest).getTime() ? c.expires_at : latest;
      }, new Date(Date.now() + perAccountValidityDays * 24 * 60 * 60 * 1000).toISOString());

      try {
        await supabase.from('external_events').insert({
          id: batchId,
          user_id: masterUserId,
          type: 'SLAVE_CAPABILITY_BATCH_ACTIVATED',
          details: JSON.stringify({
            batch_id: batchId,
            master_id: masterUserId,
            target_account_ids: activatedAccountsDetails.map(a => a.id),
            target_accounts: activatedAccountsDetails,
            accounts_count: targetSlaveUsers.length,
            validity_days: perAccountValidityDays,
            created_at: nowIso,
            expires_at: batchExpiresAt,
            metadata: {
              validity_days_extended: perAccountValidityDays,
              accounts_in_transaction: targetSlaveUsers.length,
              expires_at: batchExpiresAt
            }
          }),
          created_at: nowIso
        });
        for (const slave of activatedAccountsDetails) {
          try {
            await logExternalEvent(
              slave.id,
              'SLAVE_CAPABILITY_ACTIVATED',
              masterAgentId,
              slave.agent_id || slave.id,
              {
                batch_id: batchId,
                master_id: masterUserId,
                validity_days: perAccountValidityDays,
                agent_id: slave.agent_id,
                created_at: nowIso,
                expires_at: slave.expires_at || batchExpiresAt
              }
            );
          } catch (e) {}
        }
      } catch (e) {}

      watchtowerActivityService.recordWatchtowerActivity({
        id: `wt_${batchId}`,
        activityKey: `plan_canon:${batchId}`,
        agentId: masterAgentId,
        agentName: masterName,
        avatar: masterAvatar,
        type: 'SLAVE_CAPABILITY_BATCH_ACTIVATED',
        category: 'plan',
        outcome: 'success',
        isMasterOnly: true,
        text: `activated Capability Increment Plan (+${perAccountValidityDays} Days) for ${activatedList.length} slave account${activatedList.length > 1 ? 's' : ''}`,
        actorUserId: masterUserId,
        masterId: masterUserId,
        endpoint: 'POST /api/auth/master/buy-plan',
        planDetails: {
          planName: 'Capability Increment Plan',
          actionType: 'capability_increment',
          accounts: activatedList.length,
          validityDays: perAccountValidityDays,
          targetAccountIds: activatedAccountsDetails.map(a => a.agent_id || a.id)
        },
        details: {
          batch_id: batchId,
          plan_category: 'capability_increment',
          accounts_count: activatedList.length,
          validity_days: perAccountValidityDays,
          expires_at: batchExpiresAt,
          target_account_ids: activatedAccountsDetails.map(a => a.agent_id || a.id)
        },
        createdAt: nowIso
      }).catch(console.warn);

      const existingMasterPlan = await MasterAccountService.getInstance().getMasterPlan(masterUserId);

      return res.json({
        success: true,
        data: {
          plan: existingMasterPlan || {
            plan_name: 'Capability Increment Plan',
            status: 'active',
            allowance_accounts: activatedList.length
          },
          capability: activatedList[0],
          capabilities: activatedList,
          status: 'active'
        },
        message: `Capability Increment activated for ${activatedList.length} slave agent(s). Higher rate limits unlocked strictly for target slave(s).`
      });
    }

    // 2. Master & Slave Fleet Plan Path (Controls total number of Slave accounts)
    // Total accounts requested (defaults to 10 base accounts, bounded between 10 and 1000)
    const rawAccounts = req.body?.totalAccounts ?? req.body?.allowance ?? 10;
    const parsedAccounts = parseInt(rawAccounts, 10);
    const targetAccounts = isNaN(parsedAccounts) ? 10 : Math.min(1000, Math.max(10, parsedAccounts));

    const actionType = req.body?.actionType as ('new_plan' | 'add_accounts' | undefined);
    const parsedMasterSlots = req.body?.masterSlots !== undefined ? parseInt(req.body.masterSlots, 10) : 0;
    const masterSlots = isNaN(parsedMasterSlots) ? 0 : Math.max(0, parsedMasterSlots);
    const masterRegistrationEmail = typeof req.body?.masterRegistrationEmail === 'string'
      ? req.body.masterRegistrationEmail.trim()
      : undefined;
    const masterRegistrationEmails = Array.isArray(req.body?.masterRegistrationEmails)
      ? req.body.masterRegistrationEmails.map((e: any) => String(e).trim()).filter(Boolean)
      : (masterRegistrationEmail ? [masterRegistrationEmail] : undefined);

    if (masterSlots > 0) {
      if (!masterRegistrationEmail && (!masterRegistrationEmails || masterRegistrationEmails.length === 0)) {
        return res.status(400).json({
          success: false,
          error: {
            message: 'Email address to get registered is required when purchasing Master Account slots.'
          }
        });
      }
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      const emailsToCheck = (masterRegistrationEmails || (masterRegistrationEmail ? [masterRegistrationEmail] : []))
        .map((e: string) => e.trim())
        .filter(Boolean);

      if (emailsToCheck.length !== masterSlots) {
        return res.status(400).json({
          success: false,
          error: {
            message: `Please provide ${masterSlots} registration email address${masterSlots > 1 ? 'es' : ''} — one for each Master Account slot.`
          }
        });
      }

      const lowerEmails = emailsToCheck.map((e: string) => e.toLowerCase());
      if (new Set(lowerEmails).size !== lowerEmails.length) {
        return res.status(400).json({
          success: false,
          error: {
            message: 'Each Master Account slot requires a unique registration email address. Duplicate emails are not allowed.'
          }
        });
      }

      const existingMasterPlan = await MasterAccountService.getInstance().getMasterPlan(masterUserId, true);
      const existingInvitations: any[] = Array.isArray(existingMasterPlan?.metadata?.fleet_slot_invitations)
        ? existingMasterPlan.metadata.fleet_slot_invitations
        : [];
      const existingInvitedSet = new Set<string>([
        ...existingInvitations.map((inv: any) => String(inv?.email || '').toLowerCase().trim()).filter(Boolean),
        ...((existingMasterPlan?.metadata?.registered_emails as string[]) || []).map((e: string) => String(e).toLowerCase().trim()).filter(Boolean)
      ]);
      const callerEmailLower = String(callerUser?.email || '').toLowerCase().trim();

      const supabase = getSupabaseClient();
      for (const em of emailsToCheck) {
        if (!emailRegex.test(em)) {
          return res.status(400).json({
            success: false,
            error: {
              message: `Please provide a valid registration email address: ${em}`
            }
          });
        }
        const emLower = em.toLowerCase();
        if (callerEmailLower && emLower === callerEmailLower) {
          return res.status(400).json({
            success: false,
            error: {
              message: `Email address ${em} is already registered to your Master account.`
            }
          });
        }
        if (existingInvitedSet.has(emLower)) {
          return res.status(400).json({
            success: false,
            error: {
              message: `Email address ${em} already has a reserved or pending Master Account slot invitation.`
            }
          });
        }
        const { data: existingUser } = await supabase
          .from('users')
          .select('id')
          .ilike('email', em)
          .maybeSingle();
        if (existingUser) {
          return res.status(400).json({
            success: false,
            error: {
              message: `Email address ${em} is already registered in the database and cannot be used for a new slot assignment.`
            }
          });
        }
      }
    }

    const parsedAddOn = req.body?.addOnAccounts !== undefined ? parseInt(req.body.addOnAccounts, 10) : undefined;
    const addOnAccounts = parsedAddOn !== undefined && !isNaN(parsedAddOn)
      ? Math.max(0, parsedAddOn)
      : undefined;
    const targetBlockId = req.body?.targetBlockId;
    const planName = req.body?.planName;

    const masterService = MasterAccountService.getInstance();
    const entitlement = await masterService.activateMasterPlan(masterUserId, targetAccounts, {
      actionType,
      addOnAccounts,
      masterSlots,
      masterRegistrationEmail,
      masterRegistrationEmails,
      targetBlockId,
      planName
    } as any);

    masterService.invalidateMasterPlanCache(masterUserId);
    masterService.setMasterPlanCache(masterUserId, entitlement);

    const latestFleetId = entitlement.metadata?.latest_fleet_id || entitlement.metadata?.fleet_id;
    const newFleetIds: string[] = Array.isArray(entitlement.metadata?.new_fleet_ids) && entitlement.metadata.new_fleet_ids.length > 0
      ? entitlement.metadata.new_fleet_ids
      : (latestFleetId ? [latestFleetId] : []);
    const allFleetIds = entitlement.metadata?.fleet_ids || (latestFleetId ? [latestFleetId] : []);

    const emailsToInvite = (masterRegistrationEmails && masterRegistrationEmails.length > 0)
      ? masterRegistrationEmails
      : (masterRegistrationEmail ? [masterRegistrationEmail] : []);

    const txBlocks = Array.isArray(entitlement.metadata?.blocks) ? entitlement.metadata.blocks : [];
    const txEventId = entitlement.metadata?.latest_transaction_id || (txBlocks.length > 0 ? txBlocks[txBlocks.length - 1]?.id : undefined) || `${entitlement.id}_${Date.now()}`;
    const matchedTxBlock = entitlement.metadata?.latest_transaction_id
      ? txBlocks.find((b: any) => b?.id === entitlement.metadata.latest_transaction_id)
      : (txBlocks.length > 0 ? txBlocks[txBlocks.length - 1] : null);
    const resolvedTxActionType = actionType || matchedTxBlock?.action_type || entitlement.metadata?.action_type || 'new_plan';
    const txAddedSlaves = matchedTxBlock?.allowance !== undefined
      ? Number(matchedTxBlock.allowance)
      : Number(entitlement.metadata?.added_accounts ?? 0);
    const txAddedMasterSlots = matchedTxBlock?.master_slots_added !== undefined
      ? Number(matchedTxBlock.master_slots_added)
      : Number(entitlement.metadata?.master_slots_added ?? masterSlots);
    const txMasterSlotsTotal = Number(entitlement.metadata?.master_slots ?? (txAddedMasterSlots > 0 ? txAddedMasterSlots + 1 : 1));
    const txTotalSlaves = Number(entitlement.allowance_accounts ?? 10);
    const txAmount = matchedTxBlock?.amount ?? entitlement.metadata?.amount;

    const isAddOnAction = resolvedTxActionType === 'add_accounts';
    const isMasterSlotOnly = isAddOnAction && txAddedMasterSlots > 0 && txAddedSlaves === 0;
    const isCombinedAddOn = isAddOnAction && txAddedMasterSlots > 0 && txAddedSlaves > 0;
    const isSlaveAddOnOnly = isAddOnAction && txAddedSlaves > 0 && txAddedMasterSlots === 0;

    let watchtowerPlanName = entitlement.plan_name || 'Master & Slave Agent Plan';
    let watchtowerPlanActionType = 'new_plan';
    let planSummaryText = '';
    let txPlanDetails: any = {};

    if (isMasterSlotOnly) {
      watchtowerPlanName = 'Master Account Slot Plan';
      watchtowerPlanActionType = 'add_master_slot';
      planSummaryText = `purchased +${txAddedMasterSlots} Master Account Slot${txAddedMasterSlots === 1 ? '' : 's'} (${txMasterSlotsTotal} total master slots)`;
      txPlanDetails = {
        planName: watchtowerPlanName,
        actionType: watchtowerPlanActionType,
        masterSlotsAdded: txAddedMasterSlots,
        masterSlotsTotal: txMasterSlotsTotal,
        amount: txAmount,
        currency: 'USD',
        ...(newFleetIds.length > 0 ? { fleetIds: newFleetIds } : {}),
        ...(emailsToInvite.length > 0 ? { registeredEmails: emailsToInvite } : {})
      };
    } else if (isCombinedAddOn) {
      watchtowerPlanName = 'Master & Slave Capacity Expansion';
      watchtowerPlanActionType = 'add_accounts';
      planSummaryText = `purchased +${txAddedSlaves} Slave Account Slot${txAddedSlaves === 1 ? '' : 's'} and +${txAddedMasterSlots} Master Account Slot${txAddedMasterSlots === 1 ? '' : 's'} (${txTotalSlaves} total slave slots, ${txMasterSlotsTotal} total master slots)`;
      txPlanDetails = {
        planName: watchtowerPlanName,
        actionType: watchtowerPlanActionType,
        accounts: txTotalSlaves,
        slaveAccountsAdded: txAddedSlaves,
        masterSlotsAdded: txAddedMasterSlots,
        masterSlotsTotal: txMasterSlotsTotal,
        amount: txAmount,
        currency: 'USD',
        ...(newFleetIds.length > 0 ? { fleetIds: newFleetIds } : {}),
        ...(emailsToInvite.length > 0 ? { registeredEmails: emailsToInvite } : {})
      };
    } else if (isSlaveAddOnOnly) {
      watchtowerPlanName = 'Slave Capacity Add-On Plan';
      watchtowerPlanActionType = 'add_accounts';
      planSummaryText = `purchased +${txAddedSlaves} Slave Account Slot${txAddedSlaves === 1 ? '' : 's'} on Slave Capacity Add-On Plan (${txTotalSlaves} total slave slots)`;
      txPlanDetails = {
        planName: watchtowerPlanName,
        actionType: watchtowerPlanActionType,
        accounts: txTotalSlaves,
        slaveAccountsAdded: txAddedSlaves,
        amount: txAmount,
        currency: 'USD'
      };
    } else {
      watchtowerPlanName = entitlement.plan_name || 'Master & Slave Agent Plan';
      watchtowerPlanActionType = 'new_plan';
      planSummaryText = `activated ${watchtowerPlanName} (${txTotalSlaves} Slave Account Slot${txTotalSlaves === 1 ? '' : 's'}${txAddedMasterSlots > 0 ? `, +${txAddedMasterSlots} Master Account Slot${txAddedMasterSlots === 1 ? '' : 's'}` : ''})`;
      txPlanDetails = {
        planName: watchtowerPlanName,
        actionType: watchtowerPlanActionType,
        accounts: txTotalSlaves,
        ...(txAddedMasterSlots > 0 ? { masterSlotsAdded: txAddedMasterSlots, masterSlotsTotal: txMasterSlotsTotal } : {}),
        amount: txAmount,
        currency: 'USD',
        ...(emailsToInvite.length > 0 ? { registeredEmails: emailsToInvite } : {})
      };
    }

    watchtowerActivityService.recordWatchtowerActivity({
      id: `wt_${txEventId}`,
      activityKey: `plan_canon:${txEventId}`,
      agentId: masterAgentId,
      agentName: masterName,
      avatar: masterAvatar,
      type: 'PLAN_ENTITLEMENT_ACTIVATED',
      category: 'plan',
      outcome: 'success',
      isMasterOnly: true,
      text: planSummaryText,
      actorUserId: masterUserId,
      masterId: masterUserId,
      endpoint: 'POST /api/auth/master/buy-plan',
      planDetails: txPlanDetails,
      details: {
        tx_id: txEventId,
        latest_transaction_id: txEventId,
        plan_name: watchtowerPlanName,
        action_type: watchtowerPlanActionType,
        allowance_accounts: txTotalSlaves,
        added_accounts: txAddedSlaves,
        master_slots_added: txAddedMasterSlots,
        master_slots: txMasterSlotsTotal,
        amount: txAmount,
        currency: 'USD',
        ...(newFleetIds.length > 0 ? { fleet_ids: newFleetIds } : {}),
        ...(emailsToInvite.length > 0 ? { registered_emails: emailsToInvite } : {})
      },
      createdAt: new Date().toISOString()
    }).catch(console.warn);

    if (masterSlots > 0 && emailsToInvite.length > 0 && (newFleetIds.length > 0 || latestFleetId)) {
      try {
        const appUrl = (req.headers.origin as string) || (req.headers.referer ? new URL(req.headers.referer as string).origin : '') || process.env.APP_URL || 'https://aamarva.com';

        const entInvitations: any[] = Array.isArray(entitlement.metadata?.fleet_slot_invitations)
          ? entitlement.metadata.fleet_slot_invitations
          : [];
        for (let i = 0; i < emailsToInvite.length; i++) {
          const inviteEmail = emailsToInvite[i];
          const pairedFleetId = newFleetIds[i] || latestFleetId;
          if (!inviteEmail || !pairedFleetId) continue;

          const matchedInvite = entInvitations.find((inv: any) =>
            String(inv?.fleet_id || '').toUpperCase() === String(pairedFleetId).toUpperCase() &&
            String(inv?.email || '').toLowerCase() === String(inviteEmail).toLowerCase()
          );

          await applicationService.addEmailToWhitelist(inviteEmail, { sendEmail: false }).catch(console.warn);
          await sendFleetSlotAssignedEmail({
            toEmail: inviteEmail,
            fleetId: pairedFleetId,
            slotToken: matchedInvite?.invite_token,
            masterName: masterName,
            masterEmail: req.user?.email,
            appUrl
          });
        }
      } catch (emailErr) {
        console.error('[POST /auth/master/buy-plan] Error sending fleet slot email:', emailErr);
      }
    }

    return res.json({
      success: true,
      data: {
        plan: entitlement,
        status: entitlement.status,
        allowance: entitlement.allowance_accounts,
        fleetId: latestFleetId,
        fleet_id: latestFleetId,
        newFleetIds: newFleetIds,
        allFleetIds: allFleetIds
      },
      message: masterSlots > 0
        ? `Master Account slot (+${masterSlots}) registered successfully${masterRegistrationEmail ? ` for ${masterRegistrationEmail}` : ''}.`
        : `Master & Slave Agent Plan (${entitlement.allowance_accounts} accounts) activated successfully in database.`
    });
  } catch (err: any) {
    res.status(500).json({
      success: false,
      error: {
        message: err?.message || 'Unable to activate the plan. Please try again.'
      }
    });
  }
});

// 4a-2. POST /api/auth/master/switch - Switch human session active account context
router.post(['/auth/master/switch', '/v1/auth/master/switch', '/auth/master/switch-account', '/v1/auth/master/switch-account'], requireHumanSession, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { targetAgentId } = req.body;
    if (!targetAgentId) {
      return res.status(400).json({ success: false, error: { message: 'targetAgentId is required.' } });
    }

    const callerId = req.user.id;
    const sessionMasterUserId = (req.user as any).masterUserId;
    const supabase = getSupabaseClient();

    // 1. Fetch caller's full user record and target agent record in parallel
    const [
      { data: callerRecord },
      { data: targetUser, error: fetchErr }
    ] = await Promise.all([
      supabase.from('users').select('*').eq('id', callerId).maybeSingle(),
      supabase.from('users').select('*').or(`id.eq.${targetAgentId},agentId.eq.${targetAgentId}`).maybeSingle()
    ]);

    if (fetchErr || !targetUser) {
      return res.status(404).json({ success: false, error: { message: 'Target agent not found.' } });
    }

    // Authoritatively resolve Pioneer Master Account ID for the caller
    const callerEmail = (req.user?.email || callerRecord?.email || '').toLowerCase().trim();
    let callerPioneerId = (callerRecord?.master_id && callerRecord.master_id !== callerId) ? callerRecord.master_id : callerId;

    // Check active entitlements for caller
    const { data: activeEntitlements } = await supabase
      .from('master_plan_entitlements')
      .select('*')
      .eq('status', 'active');

    let callerMatchedEnt: any = null;
    if (activeEntitlements && activeEntitlements.length > 0) {
      if (callerEmail || callerId) {
        callerMatchedEnt = activeEntitlements.find(e => {
          const meta = e.metadata || {};
          const invs = Array.isArray(meta.fleet_slot_invitations) ? meta.fleet_slot_invitations : [];
          const regEmails = Array.isArray(meta.registered_emails) ? meta.registered_emails.map((str: string) => str.toLowerCase().trim()) : [];
          return e.master_account_id === callerId ||
                 invs.some((inv: any) => inv.claimed_by_user_id === callerId || String(inv.email || '').toLowerCase().trim() === callerEmail) ||
                 regEmails.includes(callerEmail);
        });
        if (callerMatchedEnt) {
          callerPioneerId = callerMatchedEnt.master_account_id;
        }
      }
    }

    // Walk up master_id recursively for caller to guarantee absolute primary Pioneer master user
    const resolvedCallerMasterId = await MasterAccountService.getInstance().resolveRootMasterId(supabase, callerPioneerId);

    // Self-heal DB if caller was matched as an invited/addon master slot
    if (callerMatchedEnt && callerRecord && (!callerRecord.is_master_slot || callerRecord.master_id !== resolvedCallerMasterId)) {
      if (callerRecord.id !== resolvedCallerMasterId) {
        supabase.from('users').update({
          master_id: resolvedCallerMasterId,
          account_type: 'master_slot',
          role: 'master',
          is_master_slot: true,
          is_master_primary: false
        }).eq('id', callerRecord.id).then(() => invalidateUserRecordCache(callerRecord.id)).catch(() => {});
        callerRecord.master_id = resolvedCallerMasterId;
        callerRecord.is_master_slot = true;
        callerRecord.account_type = 'master_slot';
      }
    }

    // Authoritatively resolve Pioneer Master Account ID for the target agent
    const targetEmail = (targetUser?.email || '').toLowerCase().trim();
    let targetPioneerId = (targetUser?.master_id && targetUser.master_id !== targetUser.id) ? targetUser.master_id : targetUser.id;

    if (activeEntitlements && activeEntitlements.length > 0) {
      const targetMatchedEnt = activeEntitlements.find(e => {
        const meta = e.metadata || {};
        const invs = Array.isArray(meta.fleet_slot_invitations) ? meta.fleet_slot_invitations : [];
        const regEmails = Array.isArray(meta.registered_emails) ? meta.registered_emails.map((str: string) => str.toLowerCase().trim()) : [];
        return e.master_account_id === targetUser.id ||
               e.master_account_id === targetUser.master_id ||
               invs.some((inv: any) => inv.claimed_by_user_id === targetUser.id || String(inv.email || '').toLowerCase().trim() === targetEmail) ||
               regEmails.includes(targetEmail);
      });
      if (targetMatchedEnt) {
        targetPioneerId = targetMatchedEnt.master_account_id;
      }
    }

    const resolvedTargetMasterId = await MasterAccountService.getInstance().resolveRootMasterId(supabase, targetPioneerId);

    const isSlaveAccountType = (u: any): boolean => {
      if (!u) return false;
      if (u.is_master_primary === true || u.isMasterPrimary === true) return false;
      if (u.account_type === 'slave' || u.role === 'slave' || u.is_slave === true || u.isSlave === true) {
        return true;
      }
      if (typeof u.email === 'string' && u.email.includes('+AMR-')) {
        return true;
      }
      if (u.owner_email && u.owner_email !== u.email) {
        return true;
      }
      if (u.master_id && u.master_id !== u.id && u.account_type !== 'master_slot' && u.is_master_slot !== true && u.account_type !== 'master') {
        return true;
      }
      return false;
    };

    const isMasterAccountType = (u: any): boolean => {
      if (!u) return false;
      if (isSlaveAccountType(u)) return false;
      if (u.account_type === 'master' || u.account_type === 'master_slot') return true;
      if (u.is_master_slot === true || u.isMasterSlot === true || u.is_master_primary === true || u.isMasterPrimary === true) return true;
      if (u.role === 'master') return true;
      if (!u.master_id || u.master_id === u.id) return true;
      return false;
    };

    const targetIsSlave = isSlaveAccountType(targetUser);

    // If target was previously corrupted with is_master_slot, self-heal back to slave
    if (targetIsSlave && (targetUser.is_master_slot === true || targetUser.account_type === 'master_slot')) {
      targetUser.is_master_slot = false;
      targetUser.account_type = 'slave';
      targetUser.role = 'slave';
      targetUser.is_slave = true;
      supabase.from('users').update({
        is_master_slot: false,
        account_type: 'slave',
        role: 'slave',
        is_slave: true
      }).eq('id', targetUser.id).then(() => invalidateUserRecordCache(targetUser.id)).catch(() => {});
    }

    // Only non-slave accounts can ever be recognized as master slots
    const targetIsMasterSlot = !targetIsSlave && Boolean(
      targetUser.is_master_slot === true ||
      targetUser.account_type === 'master_slot' ||
      (callerMatchedEnt && Array.isArray(callerMatchedEnt.metadata?.fleet_slot_invitations) &&
        callerMatchedEnt.metadata.fleet_slot_invitations.some((inv: any) =>
          inv.claimed_by_user_id === targetUser.id || (inv.email && String(inv.email).toLowerCase().trim() === targetEmail)
        )
      )
    );

    if (targetIsMasterSlot && targetUser.id !== resolvedCallerMasterId) {
      targetUser.is_master_slot = true;
      targetUser.account_type = 'master_slot';
      targetUser.role = 'master';
      if (targetUser.master_id !== resolvedCallerMasterId) {
        targetUser.master_id = resolvedCallerMasterId;
        supabase.from('users').update({
          master_id: resolvedCallerMasterId,
          account_type: 'master_slot',
          role: 'master',
          is_master_slot: true,
          is_master_primary: false
        }).eq('id', targetUser.id).then(() => invalidateUserRecordCache(targetUser.id)).catch(() => {});
      }
    }

    const callerIsMaster = isMasterAccountType(callerRecord);
    const callerIsSlave = !callerIsMaster;
    const targetIsMaster = !targetIsSlave && (isMasterAccountType(targetUser) || targetIsMasterSlot);

    // RULE 1: MASTER-TO-MASTER SWITCHING IS STRICTLY PROHIBITED
    if (callerIsMaster && targetIsMaster && callerId !== targetUser.id) {
      return res.status(403).json({
        success: false,
        error: {
          code: 'MASTER_TO_MASTER_SWITCH_PROHIBITED',
          message: 'Master-to-master switching is strictly prohibited. Direct switching between master accounts is not allowed.'
        }
      });
    }

    const callerFleetId = callerRecord?.fleet_id || (req.user as any).fleet_id;
    const targetFleetId = targetUser.fleet_id;

    const isSameFamily = Boolean(
      resolvedCallerMasterId && resolvedTargetMasterId &&
      resolvedCallerMasterId.toLowerCase() === resolvedTargetMasterId.toLowerCase()
    );

    const isTargetInCallerEntitlement = Boolean(
      callerMatchedEnt && (
        callerMatchedEnt.master_account_id === targetUser.id ||
        callerMatchedEnt.master_account_id === targetUser.master_id ||
        (Array.isArray(callerMatchedEnt.metadata?.fleet_slot_invitations) &&
          callerMatchedEnt.metadata.fleet_slot_invitations.some((inv: any) =>
            inv.claimed_by_user_id === targetUser.id || (inv.email && String(inv.email).toLowerCase().trim() === targetEmail)
          )) ||
        (Array.isArray(callerMatchedEnt.metadata?.registered_emails) &&
          callerMatchedEnt.metadata.registered_emails.map((e: string) => String(e).toLowerCase().trim()).includes(targetEmail))
      )
    );

    let nextReturnMasterId: string | null = null;
    let nextReturnSlaveId: string | null = null;

    if (callerIsMaster && targetIsSlave) {
      // RULE 2: MASTER-TO-SLAVE SWITCHING
      // Verify the target slave belongs to this master (or its authorized fleet family)
      const isTargetOwnedByCaller = Boolean(
        targetUser.master_id === callerId ||
        targetUser.master_id === resolvedCallerMasterId ||
        isSameFamily ||
        isTargetInCallerEntitlement ||
        (callerRecord?.master_id && targetUser.master_id === callerRecord.master_id)
      );

      if (!isTargetOwnedByCaller) {
        return res.status(403).json({
          success: false,
          error: {
            code: 'UNAUTHORIZED_SLAVE_ACCESS',
            message: 'You are not authorized to switch to another master\'s slave account.'
          }
        });
      }

      // Record this master as the originating return master for this browser-scoped session
      nextReturnMasterId = callerId;
      nextReturnSlaveId = targetUser.id;
    } else if (callerIsSlave && targetIsMaster) {
      // RULE 3: SLAVE-TO-MASTER RETURN
      // Validate browser-scoped return context
      const sessionReturnMasterId = (req.user as any)?.returnMasterId;

      if (!sessionReturnMasterId) {
        return res.status(403).json({
          success: false,
          error: {
            code: 'MISSING_RETURN_CONTEXT',
            message: 'No valid return context exists. Slave accounts cannot switch to master accounts without an originating master session.'
          }
        });
      }

      // Target master MUST match the browser-scoped return master
      if (targetUser.id !== sessionReturnMasterId && targetUser.agentId !== sessionReturnMasterId) {
        return res.status(403).json({
          success: false,
          error: {
            code: 'UNAUTHORIZED_MASTER_RETURN',
            message: 'Unauthorized: Slave account can only return to its originating master account.'
          }
        });
      }

      // Independently validate that target master is authorized for this slave
      const isReturnMasterLegitimate = Boolean(
        targetUser.id === sessionReturnMasterId ||
        targetUser.id === callerRecord.master_id ||
        targetUser.id === resolvedCallerMasterId ||
        isSameFamily ||
        isTargetInCallerEntitlement
      );

      if (!isReturnMasterLegitimate) {
        return res.status(403).json({
          success: false,
          error: {
            code: 'FORGED_RETURN_CONTEXT',
            message: 'Invalid return context: Target master does not own this slave account.'
          }
        });
      }

      // Successfully returning to master: clear return context
      nextReturnMasterId = null;
      nextReturnSlaveId = null;
    } else if (callerIsSlave && targetIsSlave) {
      // RULE 4: SLAVE-TO-SLAVE SWITCHING (allowed only between slaves belonging to the same master account)
      const sessionReturnMasterId = (req.user as any)?.returnMasterId;
      const callerMasterId = callerRecord?.master_id || sessionReturnMasterId || resolvedCallerMasterId;
      const targetMasterId = targetUser?.master_id || resolvedTargetMasterId;

      const isSameMasterSlaves = Boolean(
        (callerMasterId && targetMasterId && callerMasterId.toLowerCase() === targetMasterId.toLowerCase()) ||
        (sessionReturnMasterId && (
          targetUser.master_id === sessionReturnMasterId ||
          targetMasterId === sessionReturnMasterId ||
          resolvedTargetMasterId === sessionReturnMasterId
        )) ||
        isSameFamily ||
        (callerRecord.master_id && targetUser.master_id && callerRecord.master_id === targetUser.master_id)
      );

      if (!isSameMasterSlaves) {
        return res.status(403).json({
          success: false,
          error: {
            code: 'UNAUTHORIZED_SLAVE_SWITCH',
            message: 'Unauthorized: Cannot switch to a slave agent belonging to a different master account.'
          }
        });
      }

      // Preserve originating master return context across slave-to-slave hops
      nextReturnMasterId = sessionReturnMasterId || callerRecord.master_id || resolvedCallerMasterId || null;
      nextReturnSlaveId = targetUser.id;
    }

    // 3. Obtain current session token
    const rawSession = req.cookies?.[HUMAN_SESSION_COOKIE_NAME];
    if (!rawSession) {
      return res.status(401).json({ success: false, error: { message: 'No active session found.' } });
    }

    // 4. Generate new switched session token with browser-scoped return context
    const newToken = switchHumanSessionToken(rawSession, targetUser.id, targetUser.agentId, {
      returnMasterId: nextReturnMasterId,
      returnSlaveId: nextReturnSlaveId
    });

    // 5. Save cookie
    res.cookie(HUMAN_SESSION_COOKIE_NAME, newToken, getHumanSessionCookieOptions());

    const isTargetMasterAccount = isMasterAccountType(targetUser) || targetIsMasterSlot;
    let expiresAt: string | null = targetUser.plan_expires_at || targetUser.expires_at || null;
    let hasCapabilityIncrement = false;

    if (!isTargetMasterAccount) {
      const capService = CapabilityService.getInstance();
      const [capById, capByAgentId] = await Promise.all([
        capService.getAgentCapability(targetUser.id),
        capService.getAgentCapability(targetUser.agentId)
      ]);
      const cap = capById || capByAgentId;
      const rawExpiresAt = cap?.expires_at || (targetUser.plan === 'slave_capability' ? (targetUser.plan_expires_at || targetUser.expires_at) : null) || null;
      const isUnexpired = Boolean(rawExpiresAt && !isNaN(new Date(rawExpiresAt).getTime()) && new Date(rawExpiresAt).getTime() > Date.now());

      if (isUnexpired) {
        hasCapabilityIncrement = Boolean(
          (cap && cap.status === 'active') ||
          targetUser.hasCapabilityIncrement ||
          targetUser.plan === 'slave_capability'
        );
        if (!hasCapabilityIncrement) {
          const [activeById, activeByAgentId] = await Promise.all([
            capService.isAgentCapabilityActive(targetUser.id),
            capService.isAgentCapabilityActive(targetUser.agentId)
          ]);
          hasCapabilityIncrement = Boolean(activeById || activeByAgentId);
        }
      }
      expiresAt = hasCapabilityIncrement ? rawExpiresAt : null;
    }

    const safeUser = {
      ...normalizeUserRecord(targetUser),
      hasCapabilityIncrement,
      isCapped: hasCapabilityIncrement,
      expires_at: expiresAt,
      capability_expires_at: expiresAt,
      plan_expires_at: expiresAt
    };

    return res.json({
      success: true,
      data: {
        user: safeUser,
        token: newToken,
        returnMasterId: nextReturnMasterId,
        returnSlaveId: nextReturnSlaveId
      },
      message: `Switched active identity to ${targetUser.name || targetUser.agentId}`
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { message: err?.message || 'Failed to switch identity.' } });
  }
});

// 4a-3. POST /api/auth/master/create-slave-agent - Register single or multiple Slave Agents under the Master User
router.post(['/auth/master/create-sub-agent', '/v1/auth/master/create-sub-agent', '/auth/master/create-slave-agent', '/v1/auth/master/create-slave-agent'], requireHumanSession, async (req: AuthenticatedRequest, res: Response) => {
  let slotReservation: { release?: () => void } | null = null;
  try {
    const { agentName, bio, whitelisted_networks, agents, count, agentNames, names } = req.body;

    const callerId = req.user!.id;
    const supabase = getSupabaseClient();

    const { data: callerRec } = await supabase.from('users').select('id, master_id, fleet_id, is_master_primary, account_type, role, is_master_slot, is_slave, email').eq('id', callerId).maybeSingle();
    const isCallerSlave = Boolean(
      callerRec && (
        callerRec.account_type === 'slave' || 
        callerRec.role === 'slave' || 
        (callerRec as any).is_slave === true
      )
    );
    if (isCallerSlave) {
      return res.status(403).json({
        success: false,
        error: { message: 'Slave accounts cannot deploy additional slave agents. Switch to your Master account.' }
      });
    }
    const masterUserId = callerId;

    // 1. Resolve Master User profile for initiating master (Pioneer or Additional Master)
    const { data: masterUser, error: masterErr } = await supabase
      .from('users')
      .select('*')
      .eq('id', masterUserId)
      .maybeSingle();

    if (masterErr || !masterUser) {
      return res.status(404).json({ success: false, error: { message: 'Master user not found.' } });
    }

    // Authoritatively resolve Pioneer Master user record to inherit Pioneer email
    let pioneerMasterUser = masterUser;
    let currPioneerId = masterUser.id;
    for (let depth = 0; depth < 5; depth++) {
      if (pioneerMasterUser?.is_master_primary === true || (pioneerMasterUser as any)?.isMasterPrimary === true) {
        break;
      }
      if (pioneerMasterUser?.master_id && pioneerMasterUser.master_id !== pioneerMasterUser.id) {
        const { data: pRec } = await supabase.from('users').select('*').eq('id', pioneerMasterUser.master_id).maybeSingle();
        if (pRec) {
          pioneerMasterUser = pRec;
          currPioneerId = pRec.id;
        } else {
          break;
        }
      } else {
        break;
      }
    }
    const pioneerEmail = (pioneerMasterUser?.email || masterUser?.email || 'master@aamarva.net').toLowerCase().trim();

    // 2. Count existing Slave Agents to name target nodes
    const { data: subAgents } = await supabase
      .from('users')
      .select('id')
      .eq('master_id', masterUserId);

    const currentCount = (subAgents && Array.isArray(subAgents)) ? subAgents.filter(u => u.id !== masterUserId).length : 0;

    // Determine target creation list (single or multiple bulk accounts)
    let targets: Array<{ agentName: string; bio?: string; whitelisted_networks?: any[] }> = [];

    if (Array.isArray(agents) && agents.length > 0) {
      targets = agents.map((a: any) => ({
        agentName: a.agentName || a.name || 'Slave-Agent',
        bio: a.bio,
        whitelisted_networks: a.whitelisted_networks || whitelisted_networks
      }));
    } else if (Array.isArray(agentNames) && agentNames.length > 0) {
      targets = agentNames.map((n: string) => ({ agentName: n, bio, whitelisted_networks }));
    } else if (Array.isArray(names) && names.length > 0) {
      targets = names.map((n: string) => ({ agentName: n, bio, whitelisted_networks }));
    } else if ((typeof count === 'number' || !isNaN(Number(count))) && Number(count) > 0) {
      const num = Math.min(100, Math.max(1, Math.floor(Number(count))));
      const rawPrefix = (agentName || masterUser.name || 'Node').trim();
      const safePrefix = rawPrefix.length > 16 ? rawPrefix.slice(0, 16) : rawPrefix;
      for (let i = 1; i <= num; i++) {
        targets.push({
          agentName: `${safePrefix}-${String(currentCount + i).padStart(2, '0')}`.slice(0, 20),
          bio,
          whitelisted_networks
        });
      }
    } else if (agentName && typeof agentName === 'string' && agentName.trim()) {
      if (agentName.trim().length > 20) {
        return res.status(400).json({ success: false, error: { message: 'Agent name cannot exceed 20 characters.' } });
      }
      targets.push({ agentName: agentName.trim(), bio, whitelisted_networks });
    } else {
      return res.status(400).json({ success: false, error: { message: 'agentName, agents array, agentNames array, or count is required.' } });
    }

    // Validate that each target agent name does not exceed 20 characters
    for (const target of targets) {
      if (target.agentName && target.agentName.trim().length > 20) {
        return res.status(400).json({ success: false, error: { message: 'Agent name cannot exceed 20 characters.' } });
      }
    }

    // 3. Atomic Slave-slot allocation: Lock Master Plan row FOR UPDATE and check authoritative allowance
    try {
      slotReservation = await MasterAccountService.getInstance().allocateSlaveSlotsAtomic(masterUserId, targets.length);
    } catch (allocErr: any) {
      return res.status(400).json({
        success: false,
        error: {
          message: allocErr?.message || 'Slave agent allowance limit exceeded.'
        }
      });
    }

    const derivedEmail = pioneerEmail;

    const createdRecords: any[] = [];

    const processSingleSlave = async (target: typeof targets[0]) => {
      const inventoryItem = await popInventoryItem();
      let agentId = inventoryItem.agentId;
      let assignedAvatar = `https://robohash.org/${agentId.toLowerCase()}.png`;

      const newApiKey = generateApiKey();
      const [apiKeyHash, passwordHash] = await Promise.all([
        hashApiKey(newApiKey),
        hashPassword(nodeCrypto.randomBytes(32).toString('hex'))
      ]);
      const apiKeyFingerprint = computeApiKeyFingerprint(newApiKey);

      const subAgentId = nodeCrypto.randomUUID();
      // Use + tag to ensure email uniqueness in DB while routing to the master email
      const [localPart, domain] = derivedEmail.split('@');
      let uniqueSlaveEmail = `${localPart}+${agentId}@${domain}`;
      
      const subAgentRecord: any = {
        id: subAgentId,
        agentId,
        email: uniqueSlaveEmail,
        passwordHash,
        name: target.agentName.trim(),
        status: 'active',
        avatar: assignedAvatar,
        apiKeyFingerprint,
        bio: (target.bio || '').trim() || DEFAULT_BIO || 'hello world',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        master_id: masterUserId,
        fleet_id: masterUser.fleet_id || pioneerMasterUser.fleet_id || (callerRec as any)?.fleet_id || undefined,
        account_type: 'slave',
        role: 'slave',
        is_slave: true,
        is_master_primary: false,
        owner_email: pioneerEmail,
        whitelisted_networks: target.whitelisted_networks || []
      };

      // Resilient insert with automatic collision detection, role check adaptation, and unique agentId regeneration
      const MAX_INSERT_RETRIES = 12;
      let insertSuccess = false;
      let lastInsertErr: any = null;
      let roleAttempt = 0;

      for (let attempt = 0; attempt < MAX_INSERT_RETRIES; attempt++) {
        if (attempt > 0 && !lastInsertErr?.message?.includes('role_check') && !lastInsertErr?.message?.includes('users_role_check')) {
          agentId = await generateUniqueAgentId(supabase);
          assignedAvatar = `https://robohash.org/${agentId.toLowerCase()}.png`;
          uniqueSlaveEmail = `${localPart}+${agentId}@${domain}`;
          subAgentRecord.agentId = agentId;
          subAgentRecord.avatar = assignedAvatar;
          subAgentRecord.email = uniqueSlaveEmail;
        }

        const { error: insertErr } = await supabase
          .from('users')
          .insert(subAgentRecord);

        if (!insertErr) {
          insertSuccess = true;
          break;
        }

        lastInsertErr = insertErr;
        const isConstraintViolation = insertErr.code === '23505' ||
          insertErr.message?.includes('duplicate key') ||
          insertErr.message?.includes('users_agentId_key') ||
          insertErr.message?.includes('agentId');

        const isRoleCheckViolation = insertErr.message?.includes('users_role_check') ||
          insertErr.message?.includes('role_check') ||
          (insertErr.message?.includes('check constraint') && insertErr.message?.includes('role'));

        if (isConstraintViolation) {
          console.warn(`[Slave Deployment] agentId collision detected on ${agentId} for ${target.agentName} (attempt ${attempt + 1}/${MAX_INSERT_RETRIES}). Regenerating unique agentId...`);
          continue;
        } else if (isRoleCheckViolation && roleAttempt < 4) {
          roleAttempt++;
          console.warn(`[Slave Deployment] users_role_check violation detected for role="${subAgentRecord.role}" (attempt ${roleAttempt}). Adapting role payload...`);
          // Try dropping the constraint via exec_sql RPC if supported
          try {
            await supabase.rpc('exec_sql', {
              sql_query: "ALTER TABLE users DROP CONSTRAINT IF EXISTS users_role_check; NOTIFY pgrst, 'reload schema';"
            });
          } catch {}

          if (roleAttempt === 1) {
            // If 'slave' was rejected, try omitting role so database column default / null is used
            delete subAgentRecord.role;
          } else if (roleAttempt === 2) {
            // Try 'agent' if constraint specifically required 'agent'
            subAgentRecord.role = 'agent';
          } else if (roleAttempt === 3) {
            // Try 'member'
            subAgentRecord.role = 'member';
          } else {
            // Try 'user'
            subAgentRecord.role = 'user';
          }
          continue;
        } else {
          throw new Error(`Database insert failed for ${target.agentName}: ${insertErr.message}`);
        }
      }

      if (!insertSuccess) {
        throw new Error(`Database insert failed for ${target.agentName}: ${lastInsertErr?.message || 'Unique agentId could not be allocated after retries.'}`);
      }

      // Pre-provision Supabase Auth user record with credentials in app_metadata
      try {
        await supabase.auth.admin.createUser({
          id: subAgentId,
          email: uniqueSlaveEmail,
          email_confirm: true,
          user_metadata: {
            agentId,
            name: subAgentRecord.name,
            avatar: subAgentRecord.avatar,
            bio: subAgentRecord.bio
          },
          app_metadata: {
            apiKeyHash,
            apiKeyFingerprint,
            emailVerified: false,
            whitelisted_networks: target.whitelisted_networks || []
          }
        });
      } catch (authCreateErr) {
        // If auth user already existed or needs update, synchronize app_metadata
        try {
          await supabase.auth.admin.updateUserById(subAgentId, {
            app_metadata: {
              apiKeyHash,
              apiKeyFingerprint,
              emailVerified: false,
              whitelisted_networks: target.whitelisted_networks || []
            }
          });
        } catch {}
      }

      // Automatically establish canonical fleet connection between Master and Slave agent (WhatsApp style)
      try {
        await establishDirectConnection(masterUserId, subAgentId);
      } catch (connInitErr) {
        console.warn('Auto-establishing fleet connection notice:', connInitErr);
      }

      watchtowerActivityService.recordWatchtowerActivity({
        id: `wt_deploy_${subAgentId}`,
        agentId,
        agentName: subAgentRecord.name,
        avatar: subAgentRecord.avatar,
        emailVerified: false,
        text: `Master deployed slave account @${agentId}`,
        type: 'SLAVE_DEPLOYED',
        category: 'account',
        outcome: 'success',
        entityId: subAgentId,
        actorUserId: masterUserId,
        masterId: masterUserId,
        peerAgentId: agentId,
        activityKey: `deploy_${agentId}`
      }).catch(console.warn);

      return {
        agentId,
        apiKey: newApiKey,
        user: {
          id: subAgentId,
          agentId,
          email: derivedEmail,
          name: subAgentRecord.name,
          avatar: subAgentRecord.avatar,
          bio: subAgentRecord.bio,
          master_id: masterUserId,
          is_master_primary: false
        }
      };
    };

    // Execute slave node deployment sequentially to prevent concurrency collisions
    for (const target of targets) {
      const result = await processSingleSlave(target);
      createdRecords.push(result);
    }
    (req as any).alreadyRecordedSlaveActivity = true;

    if (createdRecords.length > 1) {
      watchtowerActivityService.recordWatchtowerActivity({
        agentId: (req.user as any)?.agentId || 'Master',
        agentName: req.user?.name || 'Master Account',
        avatar: req.user?.avatar || '🤖',
        type: 'SLAVE_BULK_DEPLOYED',
        category: 'account',
        outcome: 'success',
        text: `Master completed bulk deployment of ${createdRecords.length} slave accounts`,
        actorUserId: masterUserId,
        masterId: masterUserId,
        activityKey: `bulk_deploy_${masterUserId}_${Math.floor(Date.now() / 10000)}`,
        details: {
          deployedCount: createdRecords.length,
          agentIds: createdRecords.map((r: any) => r.agentId)
        }
      }).catch(console.warn);
    }

    if (createdRecords.length === 1) {
      return res.status(201).json({
        success: true,
        data: createdRecords[0],
        message: `Slave agent ${createdRecords[0].user.name} successfully deployed!`
      });
    } else {
      return res.status(201).json({
        success: true,
        data: {
          count: createdRecords.length,
          agents: createdRecords
        },
        message: `${createdRecords.length} slave agents successfully deployed in bulk!`
      });
    }
  } catch (err: any) {
    res.status(500).json({ success: false, error: { message: err?.message || 'Failed to deploy Slave agent(s).' } });
  } finally {
    if (slotReservation?.release) {
      slotReservation.release();
    }
  }
});

// 4a-4. POST /api/auth/master/rotate-slave-agent-key - Direct rotation of Slave Agent API key
router.post(['/auth/master/rotate-sub-agent-key', '/v1/auth/master/rotate-sub-agent-key', '/auth/master/rotate-slave-agent-key', '/v1/auth/master/rotate-slave-agent-key'], requireHumanSession, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const subAgentId = req.body.subAgentId || req.body.slaveAgentId;
    if (!subAgentId) {
      return res.status(400).json({ success: false, error: { message: 'slaveAgentId is required.' } });
    }

    const callerId = req.user.id;
    const isCallerSlave = Boolean(
      (req.user as any)?.account_type === 'slave' ||
      (req.user as any)?.role === 'slave' ||
      (req.user as any)?.is_slave === true
    );
    if (isCallerSlave) {
      return res.status(403).json({ success: false, error: { message: 'Slave accounts cannot rotate credentials. Switch to your Master account.' } });
    }

    const supabase = getSupabaseClient();
    const walkRootMaster = (startId: string): Promise<string> => MasterAccountService.getInstance().resolveRootMasterId(supabase, startId);

    const masterUserId = await walkRootMaster((req.user as any).masterUserId || callerId);

    // 1. Fetch Slave Agent profile
    const { data: subAgent, error: fetchErr } = await supabase
      .from('users')
      .select('*')
      .eq('id', subAgentId)
      .maybeSingle();

    if (fetchErr || !subAgent) {
      return res.status(404).json({ success: false, error: { message: 'Slave agent not found.' } });
    }

    // 2. Verify fleet ownership across Pioneer Master and Add-on Master Slots
    const targetRootMasterId = subAgent.master_id ? await walkRootMaster(subAgent.master_id) : null;
    const isOwnedInFleet = Boolean(
      subAgent.master_id === callerId ||
      subAgent.master_id === masterUserId ||
      (targetRootMasterId && targetRootMasterId === masterUserId)
    );
    if (!isOwnedInFleet) {
      return res.status(403).json({ success: false, error: { message: 'You are not authorized to manage this agent.' } });
    }

    // 3. Generate new credentials
    const newApiKey = generateApiKey();
    const apiKeyHash = await hashApiKey(newApiKey);
    const apiKeyFingerprint = computeApiKeyFingerprint(newApiKey);

    // 4. Update Supabase Auth app_metadata (authoritative credentials store)
    try {
      await supabase.auth.admin.updateUserById(subAgentId, {
        app_metadata: {
          apiKeyHash,
          apiKeyFingerprint
        }
      });
    } catch (authErr: any) {
      console.warn('Notice updating auth app_metadata for slave rotation:', authErr?.message);
    }

    // 5. Update table directly (users table only maintains apiKeyFingerprint)
    const { error: updateErr } = await supabase
      .from('users')
      .update({
        apiKeyFingerprint,
        updatedAt: new Date().toISOString()
      })
      .eq('id', subAgentId);

    if (updateErr) {
      throw new Error(`Database rotation failed: ${updateErr.message}`);
    }

    watchtowerActivityService.recordWatchtowerActivity({
      agentId: subAgent.agentId,
      agentName: subAgent.name || subAgent.agentId,
      avatar: subAgent.avatar || '🤖',
      type: 'API_KEY_ROTATED',
      category: 'security',
      outcome: 'success',
      text: `API key rotated for @${subAgent.agentId}`,
      peerAgentId: subAgent.agentId,
      actorUserId: masterUserId,
      masterId: masterUserId,
      activityKey: `rotate_${subAgent.agentId}_${Math.floor(Date.now() / 10000)}`
    }).catch(console.warn);

    return res.json({
      success: true,
      data: {
        agentId: subAgent.agentId,
        apiKey: newApiKey
      },
      message: `API key successfully rotated for agent ${subAgent.name || subAgent.agentId}!`
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { message: err?.message || 'Failed to rotate Slave agent credentials.' } });
  }
});

// 4a-4b. POST /api/auth/master/initialize-slave-e2ee - Initialize E2EE identity for an owned Slave Agent
router.post(
  ['/auth/master/initialize-slave-e2ee', '/v1/auth/master/initialize-slave-e2ee'],
  requireHumanSession,
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { slaveAgentId, targetAgentId, publicKey, fingerprint, identityKey, signature, keyEpoch } = req.body || {};
      const targetId = slaveAgentId || targetAgentId;
      if (!targetId || !publicKey) {
        return res.status(400).json({ success: false, error: { message: 'slaveAgentId and publicKey are required.' } });
      }

      const masterUserId = (req.user as any).masterUserId || req.user.id;
      const supabase = getSupabaseClient();

      // Fetch Slave Agent profile by id or agentId
      const { data: subAgent, error: fetchErr } = await supabase
        .from('users')
        .select('*')
        .or(`id.eq.${targetId},agentId.eq.${targetId}`)
        .maybeSingle();

      if (fetchErr || !subAgent) {
        return res.status(404).json({ success: false, error: { message: 'Slave agent not found.' } });
      }

      if (subAgent.master_id !== masterUserId && subAgent.id !== masterUserId) {
        return res.status(403).json({ success: false, error: { message: 'You are not authorized to manage this agent.' } });
      }

      // Cryptographic validation of public key JWK
      let parsedJwk: any;
      try {
        parsedJwk = typeof publicKey === 'string' ? JSON.parse(publicKey) : publicKey;
      } catch {
        return res.status(400).json({ success: false, error: { message: 'Invalid public key format. Valid JWK required.' } });
      }

      const canonicalJwk = JSON.stringify({ crv: parsedJwk.crv || 'P-256', kty: parsedJwk.kty || 'EC', x: parsedJwk.x, y: parsedJwk.y });
      const digestHex = nodeCrypto.createHash('sha256').update(canonicalJwk).digest('hex').toUpperCase();
      const computedFingerprint = 'SHA256:' + (digestHex.match(/.{2}/g)?.join(':') || digestHex);

      const pubKeyStr = typeof publicKey === 'string' ? publicKey : JSON.stringify(publicKey);
      const identityKeyStr = identityKey ? (typeof identityKey === 'string' ? identityKey : JSON.stringify(identityKey)) : null;
      const parsedEpoch = typeof keyEpoch === 'number' && keyEpoch > 0 ? keyEpoch : 1;

      const authUser = await ensureAuthUserRecord(supabase, subAgent.id);
      const existingMeta = authUser?.user_metadata || {};

      await supabase.auth.admin.updateUserById(subAgent.id, {
        user_metadata: {
          ...existingMeta,
          e2eePublicKey: pubKeyStr,
          e2eePublicKeyFingerprint: computedFingerprint,
          e2eeIdentityKey: identityKeyStr,
          e2eeKeySignature: signature || null,
          e2eeKeyEpoch: parsedEpoch,
          e2eeEpochHistory: {
            ...(existingMeta.e2eeEpochHistory || {}),
            [String(parsedEpoch)]: {
              publicKey: pubKeyStr,
              fingerprint: computedFingerprint,
              identityKey: identityKeyStr,
              signature: signature || null,
              keyEpoch: parsedEpoch,
              updatedAt: new Date().toISOString()
            }
          },
          e2eeKeyUpdatedAt: new Date().toISOString()
        }
      });

      watchtowerActivityService.recordWatchtowerActivity({
        agentId: subAgent.agentId,
        agentName: subAgent.name || subAgent.agentId,
        avatar: subAgent.avatar || '🤖',
        type: 'E2EE_KEYS_UPDATED',
        category: 'security',
        outcome: 'success',
        text: `@${subAgent.agentId} updated encryption identity`,
        peerAgentId: subAgent.agentId,
        actorUserId: masterUserId,
        masterId: masterUserId,
        activityKey: `e2ee_${subAgent.agentId}_${Math.floor(Date.now() / 10000)}`
      }).catch(console.warn);

      return res.json({
        success: true,
        data: {
          agentId: subAgent.agentId,
          publicKey: pubKeyStr,
          fingerprint: computedFingerprint
        },
        message: `E2EE identity successfully initialized for agent ${subAgent.name || subAgent.agentId}!`
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: { message: err?.message || 'Failed to initialize Slave agent E2EE identity.' } });
    }
  }
);

// 4a-5. POST /api/auth/master/undeploy-slave-agent - Remove a Slave Agent and release its allowance slot
router.post(['/auth/master/undeploy-slave-agent', '/v1/auth/master/undeploy-slave-agent', '/auth/master/delete-slave-agent', '/v1/auth/master/delete-slave-agent'], requireHumanSession, async (req: AuthenticatedRequest, res: Response) => {
  try {
    let subAgentId = req.body.subAgentId || req.body.slaveAgentId || req.body.agentId || req.body.id || req.body.targetAgentId;
    if (!subAgentId && ((req.user as any)?.master_id || (req.user as any)?.masterUserId)) {
      subAgentId = req.user.id;
    }
    if (!subAgentId) {
      return res.status(400).json({ success: false, error: { message: 'slaveAgentId is required.' } });
    }

    const masterUserId = (req.user as any).master_id || (req.user as any).masterUserId || req.user.id;
    const supabase = getSupabaseClient();

    // 1. Fetch Slave Agent record by id or agentId
    const { data: subAgents, error: fetchErr } = await supabase
      .from('users')
      .select('*')
      .or(`id.eq.${subAgentId},agentId.eq.${subAgentId}`);

    let subAgent = subAgents && subAgents.length > 0 ? subAgents[0] : null;
    if (!subAgent) {
      const { data: fallbackAgent } = await supabase
        .from('users')
        .select('*')
        .eq('id', subAgentId)
        .maybeSingle();
      subAgent = fallbackAgent;
    }

    if (fetchErr || !subAgent) {
      return res.status(404).json({ success: false, error: { message: 'Slave agent not found or already deleted.' } });
    }

    // 2. Verify ownership: must be created by master or caller is master
    const isAuthorized = subAgent.master_id === masterUserId || 
                         subAgent.master_id === req.user.id || 
                         subAgent.id === req.user.id || 
                         (req.user as any).isMasterUser === true ||
                         (req.user as any).is_master_primary === true;

    if (!isAuthorized) {
      return res.status(403).json({ success: false, error: { message: 'You are not authorized to undeploy this agent.' } });
    }

    const cap = await CapabilityService.getInstance().getAgentCapability(subAgent.id) || await CapabilityService.getInstance().getAgentCapability(subAgent.agentId);
    const expiresAt = cap?.expires_at || subAgent.plan_expires_at || subAgent.expires_at;
    const isCappedActive = Boolean(
      subAgent.isCapped ||
      subAgent.hasCapabilityIncrement ||
      subAgent.plan === 'slave_capability' ||
      (expiresAt && new Date(expiresAt).getTime() > Date.now()) ||
      await CapabilityService.getInstance().isAgentCapabilityActive(subAgent.id) ||
      await CapabilityService.getInstance().isAgentCapabilityActive(subAgent.agentId)
    );
    if (isCappedActive && (!expiresAt || new Date(expiresAt).getTime() > Date.now())) {
      return res.status(400).json({ success: false, error: { message: 'Cannot undeploy agent while capped plan is active until expiration.' } });
    }

    const targetUUID = subAgent.id;

    // 3. Clean up dependent child records to prevent foreign key violations & stale capability rows
    try {
      await Promise.allSettled([
        supabase.from('user_key_vaults').delete().eq('user_id', targetUUID),
        supabase.from('connections').delete().or(`user1_id.eq.${targetUUID},user2_id.eq.${targetUUID}`),
        supabase.from('messages').delete().eq('senderUserId', targetUUID),
        supabase.from('clusters').delete().eq('ownerUserId', targetUUID),
        supabase.from('capability_entitlements').delete().eq('user_id', targetUUID),
        ...(subAgent.agentId ? [supabase.from('capability_entitlements').delete().eq('agent_id', subAgent.agentId)] : []),
        supabase.from('master_plan_entitlements').delete().eq('master_account_id', targetUUID).eq('plan_type', 'slave_capability'),
        supabase.from('agent_footprints').delete().eq('user_id', targetUUID),
        supabase.from('external_events').delete().eq('user_id', targetUUID),
        supabase.from('audit_logs').delete().eq('user_id', targetUUID)
      ]);
      CapabilityService.getInstance().invalidateCapabilityCache(targetUUID);
      if (subAgent.agentId) {
        CapabilityService.getInstance().invalidateCapabilityCache(subAgent.agentId);
      }
    } catch (cleanErr: any) {
      console.warn('Non-fatal child record cleanup notice:', cleanErr);
    }

    // 4. Delete from Supabase Auth admin
    try {
      await supabase.auth.admin.deleteUser(targetUUID);
    } catch (authErr: any) {
      console.warn('Non-fatal Auth user delete failure:', authErr?.message || authErr);
    }

    // 5. Delete from users table
    const { error: delErr } = await supabase
      .from('users')
      .delete()
      .eq('id', targetUUID);

    if (delErr) {
      throw new Error(`Failed to remove agent: ${delErr.message}`);
    }

    try {
      await watchtowerActivityService.recordWatchtowerActivity({
        id: `wt_undeploy_${subAgent.id}`,
        agentId: (req.user as any).agentId || masterUserId,
        agentName: (req.user as any).name || 'Master',
        avatar: (req.user as any).avatar,
        emailVerified: Boolean((req.user as any).emailVerified),
        text: `Master undeployed slave account @${subAgent.agentId || subAgent.name}`,
        type: 'SLAVE_UNDEPLOYED',
        category: 'account',
        outcome: 'info',
        actorUserId: masterUserId,
        masterId: masterUserId,
        peerUserId: subAgent.id,
        peerAgentId: subAgent.agentId || subAgent.name,
        peerName: subAgent.name || subAgent.agentId,
        details: {
          slaveAgentId: subAgent.agentId,
          slaveName: subAgent.name,
          slotRestored: true,
        },
        activityKey: `slave_undeployed:${subAgent.id}`
      });
    } catch (e) {
      console.warn('Failed to record slave undeploy watchtower activity:', e);
    }

    return res.json({
      success: true,
      message: `Slave agent ${subAgent.name || subAgent.agentId} undeployed successfully. Allowance slot has been restored.`
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { message: err?.message || 'Failed to undeploy Slave agent.' } });
  }
});

// 4a-6. POST /api/auth/master/logout-slave-agent - Force global logout for a specific slave agent
router.post(['/auth/master/logout-slave-agent', '/v1/auth/master/logout-slave-agent'], requireHumanSession, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const slaveAgentId = req.body.slaveAgentId || req.body.subAgentId || req.body.agentId;
    if (!slaveAgentId) {
      return res.status(400).json({ success: false, error: { message: 'slaveAgentId is required.' } });
    }

    const masterUserId = (req.user as any).masterUserId || req.user.id;
    const supabase = getSupabaseClient();

    // 1. Fetch Slave Agent record to verify ownership
    const { data: subAgent, error: fetchErr } = await supabase
      .from('users')
      .select('*')
      .eq('id', slaveAgentId)
      .maybeSingle();

    if (fetchErr || !subAgent) {
      return res.status(404).json({ success: false, error: { message: 'Slave agent not found.' } });
    }

    if (subAgent.master_id !== masterUserId) {
      return res.status(403).json({ success: false, error: { message: 'Not authorized to log out this agent.' } });
    }

    // 2. Invalidate all sessions for this slave agent
    await invalidateAllHumanSessionsForUser(slaveAgentId);
    await supabase
      .from('refresh_tokens')
      .update({ isRevoked: true })
      .eq('userId', slaveAgentId);

    try {
      await watchtowerActivityService.recordWatchtowerActivity({
        agentId: (req.user as any).agentId || masterUserId,
        agentName: (req.user as any).name || 'Master',
        avatar: (req.user as any).avatar,
        emailVerified: Boolean((req.user as any).emailVerified),
        text: `Master logged out slave account @${subAgent.agentId || subAgent.name}`,
        type: 'SLAVE_LOGGED_OUT',
        actorUserId: masterUserId,
        masterId: masterUserId,
        peerUserId: subAgent.id,
        peerAgentId: subAgent.agentId || subAgent.name,
        peerName: subAgent.name || subAgent.agentId,
        details: {
          slaveAgentId: subAgent.agentId,
          slaveName: subAgent.name,
          action: 'FORCE_GLOBAL_LOGOUT'
        },
        activityKey: `slave_logout:${subAgent.id}:${Math.floor(Date.now() / 10000)}`
      });
    } catch (e) {
      console.warn('Failed to record slave logout watchtower activity:', e);
    }

    return res.json({
      success: true,
      message: `Slave agent ${subAgent.name || subAgent.agentId} has been successfully logged out globally.`
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { message: err?.message || 'Failed to log out slave agent.' } });
  }
});

// 4b. POST /api/auth/logout (Agent logout only)
router.post(['/auth/logout', '/v1/auth/logout'], async (req: Request, res: Response) => {
  try {
    const rtToken = (req.cookies && req.cookies[REFRESH_COOKIE_NAME]) || (req.body && req.body.refreshToken);

    if (rtToken) {
      const decoded = verifyRefreshToken(rtToken);
      if (decoded?.userId) {
        await logoutAgent(decoded.userId, rtToken);
      }
      res.clearCookie(REFRESH_COOKIE_NAME, getRefreshCookieOptions());
    }
    
    res.json({ success: true, message: 'Agent logged out successfully.' });
  } catch (err: any) {
    console.error('Agent logout handler error:', err.message);
    res.status(500).json({ 
      success: false, 
      error: { 
        message: 'Unknown logout error'
      } 
    });
  }
});

// 4c. POST /api/auth/sessions/logout-all (Invalidate all human and agent sessions for current user)
router.post(['/auth/sessions/logout-all', '/v1/auth/sessions/logout-all'], requireHumanSession, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const activeAccountId = (req.user as any)?.activeAccountId || req.user!.id;
    const sessionMasterId = (req.user as any)?.masterUserId || req.user!.id;
    const userId = activeAccountId;
    
    // 1. Invalidate all human sessions (which updates passwordChangedAt to reject active JWTs) and refresh tokens for current account
    await invalidateAllHumanSessionsForUser(activeAccountId);
    const supabase = getSupabaseClient();
    await supabase
      .from('refresh_tokens')
      .update({ isRevoked: true })
      .eq('userId', activeAccountId);

    // 1b. If Master invoked Global Logout while switched into a sub-account, also invalidate the Master's owning human_sessions & refresh tokens
    if (sessionMasterId && sessionMasterId !== activeAccountId) {
      await invalidateAllHumanSessionsForUser(sessionMasterId);
      await supabase
        .from('refresh_tokens')
        .update({ isRevoked: true })
        .eq('userId', sessionMasterId);
    }

    // 3. Cascade Global Logout if Pioneer Master has Copy Master -> Global Logout enabled (only when invoked as Pioneer Master)
    let updatedMasterCopySettings: any = undefined;
    try {
      const { data: userRec } = await supabase
        .from('users')
        .select('id, agentId, email, fleet_id, master_id, is_master_primary, is_master_slot, account_type, role, is_slave')
        .eq('id', userId)
        .maybeSingle();

      const isNonPioneer = Boolean(
        !userRec ||
        (sessionMasterId && sessionMasterId !== userId) ||
        userRec.is_slave === true ||
        userRec.is_master_slot === true ||
        userRec.account_type === 'slave' ||
        userRec.account_type === 'master_slot' ||
        userRec.role === 'slave' ||
        (typeof userRec.email === 'string' && userRec.email.includes('+AMR-')) ||
        (userRec.master_id && userRec.master_id !== userRec.id && !userRec.is_master_primary)
      );

      if (!isNonPioneer) {
        const masterAuth = await ensureAuthUserRecord(supabase, userId).catch(() => null);
        const copySettings = await resolveEffectiveMasterCopySettings(supabase, userId, masterAuth);
        const logoutPolicy = copySettings?.logoutSyncPolicy || copySettings?.syncPolicy || 'forever';
        const configuredIds: string[] =
          Array.isArray(copySettings?.logoutSlaveIds) && copySettings.logoutSlaveIds.length > 0
            ? copySettings.logoutSlaveIds
            : Array.isArray(copySettings?.selectedSlaveIds)
            ? copySettings.selectedSlaveIds
            : [];

        if (copySettings?.copyGlobalLogout === true) {
          if (configuredIds.length > 0) {
            const fleetSlaves = await getMasterFleetSlaveRows(supabase, userRec);
            const normalizedTargets = new Set(
              configuredIds.map((v: any) => String(v || '').trim().replace(/^@/, '').toLowerCase()).filter(Boolean)
            );
            const matchedSlaves = fleetSlaves.filter((s: any) => {
              const cleanId = String(s.id || '').trim().toLowerCase();
              const cleanAgentId = String(s.agentId || '').trim().replace(/^@/, '').toLowerCase();
              return normalizedTargets.has(cleanId) || (cleanAgentId && normalizedTargets.has(cleanAgentId));
            });

            const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
            const resolvedTargets: string[] = matchedSlaves.map((s: any) => s.id);
            if (resolvedTargets.length === 0) {
              for (const rawTarget of configuredIds) {
                const clean = String(rawTarget || '').trim();
                if (!clean) continue;
                if (uuidRegex.test(clean)) {
                  resolvedTargets.push(clean);
                } else {
                  const cleanHandle = clean.replace(/^@/, '');
                  if (cleanHandle) {
                    const { data: uByAgent } = await supabase
                      .from('users')
                      .select('id, master_id, fleet_id')
                      .or(`agentId.eq.${cleanHandle},agentId.eq.@${cleanHandle}`)
                      .maybeSingle();
                    if (
                      uByAgent?.id &&
                      (uByAgent.master_id === userId || (userRec.fleet_id && uByAgent.fleet_id === userRec.fleet_id))
                    ) {
                      resolvedTargets.push(uByAgent.id);
                    }
                  }
                }
              }
            }

            const targets = Array.from(new Set(resolvedTargets));
            for (const slaveId of targets) {
              if (!slaveId || slaveId === userId) continue;
              try {
                await invalidateAllHumanSessionsForUser(slaveId);
              } catch {}
              try {
                await supabase
                  .from('refresh_tokens')
                  .update({ isRevoked: true })
                  .eq('userId', slaveId);
              } catch {}
            }
          }

          if (logoutPolicy === 'one_time') {
            updatedMasterCopySettings = await consumeOneTimeCopySection(supabase, userId, 'logout', masterAuth, {
              preloadedSettings: copySettings,
            });
          }
        }
      }
    } catch (cascadeErr) {
      console.warn('Non-fatal: Failed to cascade Global Logout to Copy Master slaves:', cascadeErr);
    }

    // 4. Clear current session cookies
    res.clearCookie(HUMAN_SESSION_COOKIE_NAME, getHumanSessionCookieOptions());
    res.clearCookie(REFRESH_COOKIE_NAME, getRefreshCookieOptions());

    try {
      await logAccountAudit({
        agentId: req.user!.agentId,
        eventType: 'SESSIONS_REVOKED_ALL',
        actionSource: 'IDENTITY',
        details: { message: 'User requested global logout for all devices and sessions' }
      });
    } catch (e) {}

    try {
      await logAgentFootprint(
        activeAccountId,
        'SESSIONS_REVOKED_ALL',
        'Revoked all active human and agent sessions across devices',
        undefined,
        req.user!.agentId,
        'POST /api/auth/sessions/logout-all'
      );
      (req as any).alreadyRecordedSlaveActivity = true;
    } catch (e) {}

    try {
      await watchtowerActivityService.recordWatchtowerActivity({
        agentId: req.user!.agentId || req.user!.id,
        agentName: req.user!.name,
        avatar: req.user!.avatar,
        emailVerified: Boolean(req.user!.emailVerified),
        text: 'revoked all active sessions and refresh tokens',
        type: 'SESSIONS_REVOKED_ALL',
        actorUserId: activeAccountId,
        masterId: (req.user as any).masterId || sessionMasterId || req.user!.id,
        details: {
          action: 'GLOBAL_LOGOUT_ALL_SESSIONS'
        },
        activityKey: `sessions_revoked:${activeAccountId}:${Math.floor(Date.now() / 10000)}`,
        skipFootprintInsert: true
      });
    } catch (e) {}

    res.json({
      success: true,
      ...(updatedMasterCopySettings !== undefined ? { data: { masterCopySettings: updatedMasterCopySettings } } : {}),
      message: 'All active sessions and devices have been logged out successfully.'
    });
  } catch (err: any) {
    console.error('Logout all sessions error:', err.message);
    res.status(500).json({ 
      success: false, 
      error: { 
        message: err.message || 'Failed to revoke all sessions'
      } 
    });
  }
});

// 4c. GET /api/auth/network-whitelist (View account IP access perimeter - Human only)
router.get(['/auth/network-whitelist', '/v1/auth/network-whitelist'], requireHumanSession, securityLayer('auth_login'), async (req: AuthenticatedRequest, res: Response) => {
  try {
    const clientIp = getClientIp(req);
    const supabase = getSupabaseClient();
    let targetUserId = req.user!.id;
    const requestedId = typeof req.query?.accountId === 'string' ? req.query.accountId.trim() : null;
    if (requestedId && requestedId !== targetUserId) {
      const { data: targetUser } = await supabase.from('users').select('id, master_id, fleet_id').eq('id', requestedId).maybeSingle();
      if (targetUser && (targetUser.master_id === req.user!.id || targetUser.master_id === (req.user as any).masterUserId || targetUser.id === (req.user as any).masterUserId)) {
        targetUserId = requestedId;
      }
    }
    const user = await findUserById(supabase, targetUserId);
    const directWL = getUserWhitelistDirect(targetUserId) || (user?.id ? getUserWhitelistDirect(user.id) : undefined) || (user?.agentId ? getUserWhitelistDirect(user.agentId) : undefined);
    const networks = Array.isArray(directWL) ? directWL : (user?.whitelisted_networks || (targetUserId === req.user?.id ? req.user?.whitelisted_networks : []) || []);
    res.json({
      success: true,
      data: {
        whitelisted_networks: networks,
        currentIp: clientIp,
      },
    });
  } catch (err: any) {
    res.status(500).json({
      success: false,
      error: {
        code: 'INTERNAL_SERVER_ERROR',
        message: err.message || 'Failed to fetch network whitelist.',
      },
    });
  }
});

// 4d. PUT /api/auth/network-whitelist (Update account IP access perimeter - Human only with Self-Lockout Protection)
router.put(['/auth/network-whitelist', '/v1/auth/network-whitelist'], requireHumanSession, securityLayer('auth_login'), async (req: AuthenticatedRequest, res: Response) => {
  try {
    const rawNetworks = req.body?.whitelisted_networks || req.body?.networks || req.body?.whitelist;
    const clientIp = getClientIp(req);
    const supabase = getSupabaseClient();
    let targetUserId = req.user!.id;
    const requestedId = typeof req.body?.accountId === 'string' ? req.body.accountId.trim() : null;
    if (requestedId && requestedId !== targetUserId) {
      const { data: targetUser } = await supabase.from('users').select('id, master_id, fleet_id').eq('id', requestedId).maybeSingle();
      if (targetUser && (targetUser.master_id === req.user!.id || targetUser.master_id === (req.user as any).masterUserId || targetUser.id === (req.user as any).masterUserId)) {
        targetUserId = requestedId;
      }
    }

    const isMasterUpdatingOwnSettings = (!requestedId || requestedId === req.user!.id) && targetUserId === req.user!.id;
    const updatedResult = await updateUserWhitelist(targetUserId, rawNetworks, clientIp, isMasterUpdatingOwnSettings);

    try {
      await logAgentFootprint(
        targetUserId,
        'WHITELIST_UPDATED',
        `Human account holder updated network access perimeter (${updatedResult.whitelisted_networks.length} networks configured)`,
        undefined,
        req.user?.agentId,
        'PUT /api/auth/network-whitelist'
      );
      (req as any).alreadyRecordedSlaveActivity = true;
      watchtowerActivityService.recordWatchtowerActivity({
        agentId: targetUserId === req.user!.id ? (req.user!.agentId || req.user!.id) : targetUserId,
        agentName: req.user!.name,
        avatar: req.user!.avatar,
        emailVerified: Boolean(req.user!.emailVerified),
        text: 'updated its network access perimeter whitelist',
        type: 'WHITELIST_UPDATED',
        actorUserId: targetUserId,
        masterId: req.user!.masterId || req.user!.id,
        activityKey: `whitelist:${targetUserId}:${Date.now()}`,
        skipFootprintInsert: true
      }).catch(console.warn);
    } catch (e) {}

    res.json({
      success: true,
      data: {
        whitelisted_networks: updatedResult.whitelisted_networks,
        currentIp: clientIp,
        ...((updatedResult as any).masterCopySettings !== undefined
          ? { masterCopySettings: (updatedResult as any).masterCopySettings }
          : {}),
      },
    });
  } catch (err: any) {
    const statusCode = err.statusCode || 400;
    res.status(statusCode).json({
      success: false,
      error: {
        code: err.code || 'INVALID_WHITELIST',
        message: err.message || 'Failed to update network whitelist.',
      },
    });
  }
});

// 4e. GET /api/account/access-management (Retrieve disabled endpoint rules & custom rate limits)
router.get(['/account/access-management', '/v1/account/access-management'], requireUserOrAgentAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    let userId = req.user!.id;
    const requestedId = typeof req.query?.accountId === 'string' ? req.query.accountId.trim() : null;
    const supabase = getSupabaseClient();
    
    let targetUserRecord: any = null;
    const searchId = requestedId || userId;
    const cleanSearchId = searchId.replace(/^@+/, '').trim();

    // Query robustly covering id, agentId (with and without @), and email
    const { data: found } = await supabase
      .from('users')
      .select('*')
      .or(`id.eq.${searchId},id.eq.${cleanSearchId},agentId.eq.${searchId},agentId.eq.${cleanSearchId},email.ilike.${searchId},email.ilike.${cleanSearchId}`)
      .maybeSingle();

    if (found) {
      targetUserRecord = found;
      userId = found.id;
    } else if (requestedId) {
      userId = requestedId;
    } else {
      const { data: selfRec } = await supabase
        .from('users')
        .select('*')
        .eq('id', userId)
        .maybeSingle();
      targetUserRecord = selfRec;
    }

    const securityService = SecurityService.getInstance();

    // 1. Check dedicated persistent store for target account across all normalized aliases
    let direct = getUserAccessManagementDirect(userId) ||
      (cleanSearchId ? getUserAccessManagementDirect(cleanSearchId) : undefined) ||
      (requestedId ? getUserAccessManagementDirect(requestedId) : undefined) ||
      (targetUserRecord?.id ? getUserAccessManagementDirect(targetUserRecord.id) : undefined) ||
      (targetUserRecord?.agentId ? getUserAccessManagementDirect(targetUserRecord.agentId) : undefined);

    // 2. Fallbacks if not stored yet under primary userId or agentId
    if (!direct) {
      if (targetUserRecord) {
        const dbDisabled = targetUserRecord.disabledEndpoints || targetUserRecord.disabled_endpoints;
        const dbLimits = targetUserRecord.customRateLimits || targetUserRecord.custom_rate_limits;
        if (Array.isArray(dbDisabled) || (dbLimits && typeof dbLimits === 'object' && Object.keys(dbLimits).length > 0)) {
          direct = {
            disabledEndpoints: Array.isArray(dbDisabled) ? dbDisabled : [],
            customRateLimits: dbLimits && typeof dbLimits === 'object' ? dbLimits : {}
          };
        }
      }

      if (!direct) {
        try {
          const authUser = await ensureAuthUserRecord(supabase, userId);
          const am = authUser?.app_metadata?.accessManagement;
          if (am && (Array.isArray(am.disabledEndpoints) || (am.customRateLimits && typeof am.customRateLimits === 'object'))) {
            direct = {
              disabledEndpoints: Array.isArray(am.disabledEndpoints) ? am.disabledEndpoints : [],
              customRateLimits: am.customRateLimits && typeof am.customRateLimits === 'object' ? am.customRateLimits : {}
            };
          }
        } catch {}
      }

      // Check Master's masterCopySettings.slaveOverrides for this slave
      if (!direct && targetUserRecord?.master_id) {
        try {
          const masterAuth = await ensureAuthUserRecord(supabase, targetUserRecord.master_id);
          const override = masterAuth?.app_metadata?.masterCopySettings?.slaveOverrides?.[targetUserRecord.id] ||
                           masterAuth?.app_metadata?.masterCopySettings?.slaveOverrides?.[targetUserRecord.agentId];
          if (override && (Array.isArray(override.disabledEndpoints) || override.customRateLimits)) {
            direct = {
              disabledEndpoints: Array.isArray(override.disabledEndpoints) ? override.disabledEndpoints : [],
              customRateLimits: override.customRateLimits && typeof override.customRateLimits === 'object' ? override.customRateLimits : {},
              isIndependent: true
            };
          }
        } catch {}
      }

      // If target is a slave account without ANY stored or custom settings (and never configured), seed ONCE from Master's current settings
      const hasAnyStoredStore = Boolean(
        getUserAccessManagementDirect(userId) ||
        (cleanSearchId ? getUserAccessManagementDirect(cleanSearchId) : undefined) ||
        (requestedId ? getUserAccessManagementDirect(requestedId) : undefined) ||
        (targetUserRecord?.id ? getUserAccessManagementDirect(targetUserRecord.id) : undefined) ||
        (targetUserRecord?.agentId ? getUserAccessManagementDirect(targetUserRecord.agentId) : undefined)
      );

      if (!direct && !hasAnyStoredStore && targetUserRecord?.master_id) {
        const masterDirect = getUserAccessManagementDirect(targetUserRecord.master_id);
        if (masterDirect) {
          direct = { ...masterDirect };
        }
      }

      // Persist the resolved initial settings directly for this target account under all aliases
      if (direct) {
        setUserAccessManagementDirect(userId, direct, [cleanSearchId, requestedId, targetUserRecord?.id, targetUserRecord?.agentId]);
      }
    }

    const disabledEndpoints = direct?.disabledEndpoints || securityService.getUserDisabledEndpoints(userId) || [];
    const customRateLimits = direct?.customRateLimits || securityService.getUserCustomRateLimits(userId) || {};

    // Keep SecurityService in-memory map primed
    securityService.setUserDisabledEndpoints(userId, disabledEndpoints);
    securityService.setUserCustomRateLimits(userId, customRateLimits);
    if (cleanSearchId) {
      securityService.setUserDisabledEndpoints(cleanSearchId, disabledEndpoints);
      securityService.setUserCustomRateLimits(cleanSearchId, customRateLimits);
    }
    if (targetUserRecord?.agentId) {
      securityService.setUserDisabledEndpoints(targetUserRecord.agentId, disabledEndpoints);
      securityService.setUserCustomRateLimits(targetUserRecord.agentId, customRateLimits);
    }

    res.json({
      success: true,
      data: {
        disabledEndpoints,
        customRateLimits
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { message: err.message || 'Failed to fetch access rules' } });
  }
});

// 4f. POST /api/account/access-management (Update disabled endpoint rules & custom rate limits)
router.post(['/account/access-management', '/v1/account/access-management'], requireUserOrAgentAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    let userId = req.user!.id;
    const requestedId = typeof req.body?.accountId === 'string' ? req.body.accountId.trim() : null;
    const supabase = getSupabaseClient();
    
    let targetUserRecord: any = null;
    const searchId = requestedId || userId;
    const cleanSearchId = searchId.replace(/^@+/, '').trim();

    const { data: found } = await supabase
      .from('users')
      .select('*')
      .or(`id.eq.${searchId},id.eq.${cleanSearchId},agentId.eq.${searchId},agentId.eq.${cleanSearchId},email.ilike.${searchId},email.ilike.${cleanSearchId}`)
      .maybeSingle();

    if (found) {
      targetUserRecord = found;
      userId = found.id;
    } else if (requestedId) {
      userId = requestedId;
    } else {
      const { data: selfRec } = await supabase
        .from('users')
        .select('*')
        .eq('id', userId)
        .maybeSingle();
      targetUserRecord = selfRec;
    }

    const { disabledEndpoints, customRateLimits } = req.body;

    const cleanDisabledList = Array.isArray(disabledEndpoints)
      ? disabledEndpoints.map((s: any) => String(s).trim()).filter(Boolean)
      : [];

    const cleanLimits: Record<string, number> = {};
    if (customRateLimits && typeof customRateLimits === 'object') {
      for (const [key, val] of Object.entries(customRateLimits)) {
        const num = Math.floor(Number(val));
        if (!isNaN(num) && num >= 1) {
          cleanLimits[key] = num;
        }
      }
    }

    const newAccessData = {
      disabledEndpoints: cleanDisabledList,
      customRateLimits: cleanLimits,
      updatedAt: new Date().toISOString(),
      isIndependent: true
    };

    // 1. Authoritative persistence in user_access_management.json file store under all aliases
    setUserAccessManagementDirect(userId, newAccessData, [cleanSearchId, requestedId, targetUserRecord?.id, targetUserRecord?.agentId]);

    const existingUser = targetUserRecord;

    // 2. Build DB update payload containing only columns that exist on this deployment's users table
    let updatedUser: any = existingUser;
    if (existingUser) {
      const dbPayload: Record<string, any> = {};
      if ('disabledEndpoints' in existingUser) dbPayload.disabledEndpoints = cleanDisabledList;
      if ('disabled_endpoints' in existingUser) dbPayload.disabled_endpoints = cleanDisabledList;
      if ('customRateLimits' in existingUser) dbPayload.customRateLimits = cleanLimits;
      if ('custom_rate_limits' in existingUser) dbPayload.custom_rate_limits = cleanLimits;

      if (Object.keys(dbPayload).length > 0) {
        const { data: upd, error: dbErr } = await supabase
          .from('users')
          .update(dbPayload)
          .eq('id', userId)
          .select('*')
          .maybeSingle();
        if (!dbErr && upd) {
          updatedUser = upd;
        }
      }
    }

    // 3. Persist authoritatively in auth app_metadata
    try {
      const authUser = await ensureAuthUserRecord(supabase, userId);
      if (authUser) {
        await supabase.auth.admin.updateUserById(authUser.id, {
          app_metadata: {
            ...(authUser.app_metadata || {}),
            accessManagement: {
              disabledEndpoints: cleanDisabledList,
              customRateLimits: cleanLimits,
              updatedAt: new Date().toISOString(),
              isIndependent: true,
            },
          },
        });
        authRecordCache.delete(userId);
        authRecordCache.delete(authUser.id);
      }
    } catch (metaErr) {
      console.warn('Non-fatal: Failed to persist accessManagement to auth app_metadata:', metaErr);
    }

    // If target is a slave account, persist override in Master account's masterCopySettings.slaveOverrides as well
    if (targetUserRecord?.master_id) {
      try {
        const masterAuth = await ensureAuthUserRecord(supabase, targetUserRecord.master_id);
        if (masterAuth) {
          const masterMeta = masterAuth.app_metadata || {};
          const masterCopySettings = masterMeta.masterCopySettings || {};
          const slaveOverrides = masterCopySettings.slaveOverrides || {};
          slaveOverrides[targetUserRecord.id] = newAccessData;
          if (targetUserRecord.agentId) {
            slaveOverrides[targetUserRecord.agentId] = newAccessData;
          }
          masterCopySettings.slaveOverrides = slaveOverrides;

          await supabase.auth.admin.updateUserById(masterAuth.id, {
            app_metadata: {
              ...masterMeta,
              masterCopySettings,
            },
          });
          authRecordCache.delete(targetUserRecord.master_id);
          authRecordCache.delete(masterAuth.id);
        }
      } catch (err) {
        console.warn('Non-fatal: Failed to update master slaveOverride in POST:', err);
      }
    }

    // 4. One-time commit copy vs Forever sync policy:
    // - Under 'one_time': Settings are copied once on commit of Copy Master modal, and slaves remain independent for the rest of the time. Future Master updates DO NOT cascade!
    // - Under 'forever': Settings are copied for the first time on commit, and any setting changed on Master later cascades to the forever-synced slaves.
    // - In the meantime between Master updates, slaves remain independent with their own settings.
    const isCallerSlave = Boolean(
      req.user?.is_slave === true ||
      (req.user as any)?.account_type === 'slave' ||
      (req.user as any)?.role === 'slave' ||
      ((req.user as any)?.masterUserId && (req.user as any).masterUserId !== userId)
    );
    const isMasterSlot = Boolean(
      updatedUser?.is_master_slot === true ||
      updatedUser?.account_type === 'master_slot' ||
      updatedUser?.role === 'master'
    );
    const isSlaveAccount = isCallerSlave || (!isMasterSlot && Boolean(
      (updatedUser?.master_id && !updatedUser?.is_master_primary) ||
      updatedUser?.account_type === 'slave' ||
      updatedUser?.role === 'slave' ||
      updatedUser?.is_slave === true ||
      (typeof updatedUser?.email === 'string' && updatedUser.email.includes('+AMR-'))
    ));

    const isMasterUpdatingOwnSettings = (!requestedId || requestedId === req.user!.id || requestedId === req.user?.agentId) && (userId === req.user!.id || (req.user?.agentId && targetUserRecord?.agentId === req.user.agentId));
    let updatedMasterCopySettings: any = undefined;
    if (!isSlaveAccount && isMasterUpdatingOwnSettings) {
      try {
        const masterRec = updatedUser || targetUserRecord || { id: userId };
        const allSlaves = await getMasterFleetSlaveRows(supabase, masterRec);

        const masterAuth = await ensureAuthUserRecord(supabase, userId).catch(() => null);
        const copySettings = await resolveEffectiveMasterCopySettings(supabase, userId, masterAuth);

        const accessPolicy = copySettings?.accessSyncPolicy || copySettings?.syncPolicy || 'forever';
        const isAccessSyncActive = Boolean(
          copySettings?.copyAccessManagement === true &&
          accessPolicy === 'forever'
        );

        if (isAccessSyncActive && allSlaves.length > 0) {
          const targetSlaveIds: string[] = Array.isArray(copySettings?.accessSlaveIds) && copySettings.accessSlaveIds.length > 0
            ? copySettings.accessSlaveIds
            : Array.isArray(copySettings?.selectedSlaveIds) && copySettings.selectedSlaveIds.length > 0
            ? copySettings.selectedSlaveIds
            : [];

          if (targetSlaveIds.length > 0) {
            for (const s of allSlaves) {
              if (s.id === userId) continue;
              const matches = targetSlaveIds.some(tid =>
                tid === s.id ||
                tid === s.agentId ||
                String(tid).replace(/^@+/, '').toLowerCase() === String(s.agentId || '').replace(/^@+/, '').toLowerCase()
              );
              if (!matches) continue;

              // Cascade new Master setting to synced slave
              setUserAccessManagementDirect(s.id, newAccessData, [s.agentId]);
              if (s.agentId) {
                setUserAccessManagementDirect(s.agentId, newAccessData, [s.id]);
              }

              const slavePayload: Record<string, any> = {};
              if ('disabledEndpoints' in s) slavePayload.disabledEndpoints = cleanDisabledList;
              if ('disabled_endpoints' in s) slavePayload.disabled_endpoints = cleanDisabledList;
              if ('customRateLimits' in s) slavePayload.customRateLimits = cleanLimits;
              if ('custom_rate_limits' in s) slavePayload.custom_rate_limits = cleanLimits;
              if (Object.keys(slavePayload).length > 0) {
                await supabase.from('users').update(slavePayload).eq('id', s.id);
                invalidateUserRecordCache(s.id);
              }

              try {
                const slaveAuth = await ensureAuthUserRecord(supabase, s.id);
                if (slaveAuth) {
                  await supabase.auth.admin.updateUserById(slaveAuth.id, {
                    app_metadata: {
                      ...(slaveAuth.app_metadata || {}),
                      accessManagement: {
                        disabledEndpoints: cleanDisabledList,
                        customRateLimits: cleanLimits,
                        updatedAt: new Date().toISOString(),
                      },
                    },
                  });
                  authRecordCache.delete(s.id);
                  authRecordCache.delete(slaveAuth.id);
                }
              } catch {}
            }
          }
        }

      } catch (syncErr) {
        console.warn('Non-fatal: Failed to propagate Master Access Management to synced slaves:', syncErr);
      }
    }

    // Log account footprint
    try {
      await logAgentFootprint(
        userId,
        'ACCESS_RULES_UPDATED',
        `Access management endpoint rules updated (${cleanDisabledList.length} endpoints blocked)`,
        undefined,
        req.user?.agentId,
        'PUT /api/account/access-management'
      );
      (req as any).alreadyRecordedSlaveActivity = true;
    } catch (e) {}

    res.json({
      success: true,
      data: {
        disabledEndpoints: cleanDisabledList,
        customRateLimits: cleanLimits,
        ...(updatedMasterCopySettings !== undefined ? { masterCopySettings: updatedMasterCopySettings } : {}),
      },
      message: 'Endpoint access rules updated successfully.'
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { message: err.message || 'Failed to update access rules' } });
  }
});

// 4f-complete. POST /api/account/access-management/complete-one-time (Finalize one_time Access Management badge removal after modal edits)
router.post(['/account/access-management/complete-one-time', '/v1/account/access-management/complete-one-time'], requireHumanSession, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const supabase = getSupabaseClient();
    const userId = (req.user as any)?.activeAccountId || req.user!.id;
    const { data: userRec } = await supabase
      .from('users')
      .select('id, email, is_slave, account_type, role, is_master_slot, is_master_primary, master_id')
      .eq('id', userId)
      .maybeSingle();
    const emailLower = String(userRec?.email || req.user?.email || '').toLowerCase();
    const isNonPioneer = Boolean(
      !userRec ||
      userRec.is_slave === true ||
      userRec.account_type === 'slave' ||
      userRec.role === 'slave' ||
      userRec.is_master_slot === true ||
      userRec.account_type === 'master_slot' ||
      emailLower.includes('+amr-') ||
      (userRec.master_id && userRec.master_id !== userRec.id && userRec.is_master_primary !== true)
    );
    if (isNonPioneer) {
      return res.json({ success: true, data: {} });
    }
    const masterAuth = await ensureAuthUserRecord(supabase, userId).catch(() => null);
    const updatedMasterCopySettings = await consumeOneTimeCopySection(supabase, userId, 'access', masterAuth);
    return res.json({
      success: true,
      data: { masterCopySettings: updatedMasterCopySettings },
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: { message: err.message || 'Failed to finalize one-time access management sync' } });
  }
});

// 4g. POST /api/auth/master/copy-settings - Copy master configurations to selected slave agents (Pioneer Master only)
router.post(['/auth/master/copy-settings', '/v1/auth/master/copy-settings'], requireHumanSession, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const supabase = getSupabaseClient();
    const callerId = (req.user as any).activeAccountId || req.user!.id;

    // Enforce Pioneer Master authorization: non-Pioneer masters (master_slot) and slave accounts are strictly view-only
    const { data: callerRec, error: callerErr } = await supabase
      .from('users')
      .select('*')
      .eq('id', callerId)
      .maybeSingle();

    const callerEmail = (callerRec?.email || req.user?.email || '').toLowerCase().trim();
    const isCallerSlave = Boolean(
      !callerRec ||
      callerRec.is_slave === true ||
      callerRec.account_type === 'slave' ||
      callerRec.role === 'slave' ||
      (typeof callerEmail === 'string' && callerEmail.includes('+amr-')) ||
      (callerRec.master_id && callerRec.master_id !== callerRec.id && callerRec.is_master_slot !== true && callerRec.account_type !== 'master_slot' && callerRec.is_master_primary !== true)
    );
    const isCallerMasterSlot = Boolean(
      callerRec?.is_master_slot === true ||
      callerRec?.account_type === 'master_slot' ||
      (callerRec?.master_id && callerRec.master_id !== callerRec.id && callerRec.is_master_primary !== true)
    );

    let isClaimedMasterSlot = false;
    const { data: activeEnts } = await supabase
      .from('master_plan_entitlements')
      .select('master_account_id, metadata')
      .eq('status', 'active');

    if (!isCallerSlave && !isCallerMasterSlot && callerRec && Array.isArray(activeEnts)) {
      isClaimedMasterSlot = activeEnts.some((e: any) => {
        if (e.master_account_id === callerId) return false;
        const meta = e.metadata || {};
        const invs = Array.isArray(meta.fleet_slot_invitations) ? meta.fleet_slot_invitations : [];
        const regEmails = Array.isArray(meta.registered_emails) ? meta.registered_emails.map((s: string) => s.toLowerCase().trim()) : [];
        return invs.some((inv: any) => inv.claimed_by_user_id === callerId || (callerEmail && String(inv.email || '').toLowerCase().trim() === callerEmail)) ||
               (callerEmail && regEmails.includes(callerEmail));
      });
    }

    if (isCallerSlave || isCallerMasterSlot || isClaimedMasterSlot) {
      return res.status(403).json({
        success: false,
        error: {
          code: 'PIONEER_MASTER_REQUIRED',
          message: 'Copy Master settings are view-only for non-Pioneer master accounts and slave accounts.'
        }
      });
    }

    if (callerErr || !callerRec) {
      return res.status(404).json({ success: false, error: { message: 'Master user record not found.' } });
    }

    const masterUserId = callerRec.id || callerId;
    const { slaveAgentIds, syncPolicy, copyAccessManagement, copyAccountIps, copyApiKeyRotation, copyGlobalLogout } = req.body || {};

    if (!Array.isArray(slaveAgentIds) || slaveAgentIds.length === 0) {
      return res.status(400).json({ success: false, error: { message: 'At least one target slave agent must be selected.' } });
    }

    // 1. Resolve Master's authoritative settings (users table + SecurityService + auth app_metadata)
    const securityService = SecurityService.getInstance();
    let masterAuthUser: any = null;
    try {
      masterAuthUser = await ensureAuthUserRecord(supabase, masterUserId);
    } catch {}

    const metaAccess = masterAuthUser?.app_metadata?.accessManagement || {};
    const memDisabled = securityService.getUserDisabledEndpoints(masterUserId);
    const memLimits = securityService.getUserCustomRateLimits(masterUserId);

    const masterDisabled =
      (Array.isArray(memDisabled) && memDisabled.length > 0 ? memDisabled : null) ||
      (Array.isArray(callerRec.disabledEndpoints) ? callerRec.disabledEndpoints : null) ||
      (Array.isArray(callerRec.disabled_endpoints) ? callerRec.disabled_endpoints : null) ||
      (Array.isArray(metaAccess.disabledEndpoints) ? metaAccess.disabledEndpoints : []);

    const masterLimits =
      (memLimits && Object.keys(memLimits).length > 0 ? memLimits : null) ||
      callerRec.customRateLimits ||
      callerRec.custom_rate_limits ||
      metaAccess.customRateLimits ||
      {};

    const directMasterWhitelist = getUserWhitelistDirect(masterUserId);
    const masterWhitelist =
      (Array.isArray(directMasterWhitelist) ? directMasterWhitelist : null) ||
      (Array.isArray(callerRec.whitelisted_networks) && callerRec.whitelisted_networks.length > 0
        ? callerRec.whitelisted_networks
        : Array.isArray(masterAuthUser?.app_metadata?.whitelisted_networks)
        ? masterAuthUser.app_metadata.whitelisted_networks
        : Array.isArray(masterAuthUser?.user_metadata?.whitelisted_networks)
        ? masterAuthUser.user_metadata.whitelisted_networks
        : []);

    // Collect valid Master Slot IDs & fleet IDs owned by this Pioneer Master for accurate slave ownership checks
    const allowedMasterIds = new Set<string>([masterUserId]);
    const allowedFleetIds = new Set<string>();
    if (callerRec.fleet_id) allowedFleetIds.add(String(callerRec.fleet_id).trim().toLowerCase());
    try {
      const { data: masterSlots } = await supabase.from('users').select('id').eq('master_id', masterUserId);
      if (Array.isArray(masterSlots)) {
        masterSlots.forEach((s: any) => s?.id && allowedMasterIds.add(s.id));
      }
      if (Array.isArray(activeEnts)) {
        activeEnts
          .filter((e: any) => e.master_account_id === masterUserId)
          .forEach((e: any) => {
            const m = e.metadata || {};
            if (m.fleet_id) allowedFleetIds.add(String(m.fleet_id).trim().toLowerCase());
            if (m.latest_fleet_id) allowedFleetIds.add(String(m.latest_fleet_id).trim().toLowerCase());
            if (Array.isArray(m.fleet_ids)) m.fleet_ids.forEach((f: any) => f && allowedFleetIds.add(String(f).trim().toLowerCase()));
          });
      }
    } catch {}

    // 2. Iterate and apply to each selected slave agent
    for (const slaveId of slaveAgentIds) {
      const { data: slaveRecord, error: slaveErr } = await supabase
        .from('users')
        .select('*')
        .eq('id', slaveId)
        .maybeSingle();

      if (slaveErr || !slaveRecord) {
        return res.status(404).json({ success: false, error: { message: `Slave agent with ID ${slaveId} not found.` } });
      }

      const belongsToFleet = Boolean(
        (slaveRecord.master_id && allowedMasterIds.has(slaveRecord.master_id)) ||
        (slaveRecord.fleet_id && allowedFleetIds.has(String(slaveRecord.fleet_id).trim().toLowerCase()))
      );
      if (!belongsToFleet) {
        return res.status(403).json({ success: false, error: { message: `Unauthorized: Agent ${slaveRecord.agentId} does not belong to your fleet.` } });
      }

      const updatePayload: Record<string, any> = {
        updatedAt: new Date().toISOString(),
      };
      if ('master_sync_policy' in slaveRecord) {
        updatePayload.master_sync_policy = syncPolicy || 'forever';
      }

      if (copyAccessManagement) {
        setUserAccessManagementDirect(slaveId, {
          disabledEndpoints: masterDisabled,
          customRateLimits: masterLimits,
          updatedAt: new Date().toISOString()
        });
        if (slaveRecord.agentId) {
          setUserAccessManagementDirect(slaveRecord.agentId, {
            disabledEndpoints: masterDisabled,
            customRateLimits: masterLimits,
            updatedAt: new Date().toISOString()
          });
        }
        if ('disabledEndpoints' in slaveRecord) updatePayload.disabledEndpoints = masterDisabled;
        if ('disabled_endpoints' in slaveRecord) updatePayload.disabled_endpoints = masterDisabled;
        if ('customRateLimits' in slaveRecord) updatePayload.customRateLimits = masterLimits;
        if ('custom_rate_limits' in slaveRecord) updatePayload.custom_rate_limits = masterLimits;
      }

      if (copyAccountIps) {
        setUserWhitelistDirect(slaveId, masterWhitelist);
        if ('whitelisted_networks' in slaveRecord) {
          updatePayload.whitelisted_networks = masterWhitelist;
        }
      }

      const { error: updateErr } = await supabase
        .from('users')
        .update(updatePayload)
        .eq('id', slaveId);

      if (updateErr) {
        const msg = String(updateErr.message || '');
        if (msg.includes('schema cache') || msg.includes('column')) {
          const fallbackPayload: Record<string, any> = { updatedAt: new Date().toISOString() };
          if (copyAccountIps && 'whitelisted_networks' in slaveRecord) {
            fallbackPayload.whitelisted_networks = masterWhitelist;
          }
          const { error: fbErr } = await supabase.from('users').update(fallbackPayload).eq('id', slaveId);
          if (fbErr) {
            throw new Error(`Failed to update slave agent ${slaveRecord.agentId}: ${fbErr.message}`);
          }
        } else {
          throw new Error(`Failed to update slave agent ${slaveRecord.agentId}: ${updateErr.message}`);
        }
      }

      // Sync app_metadata / user_metadata and invalidate user record cache for immediate effect
      if (copyAccessManagement || copyAccountIps) {
        try {
          const slaveAuth = await ensureAuthUserRecord(supabase, slaveId);
          if (slaveAuth) {
            const nextAppMeta: Record<string, any> = {
              ...(slaveAuth.app_metadata || {}),
              masterSyncPolicy: syncPolicy || 'forever',
            };
            const nextUserMeta: Record<string, any> = {
              ...(slaveAuth.user_metadata || {}),
            };
            if (copyAccessManagement) {
              nextAppMeta.accessManagement = {
                disabledEndpoints: masterDisabled,
                customRateLimits: masterLimits,
                updatedAt: new Date().toISOString(),
              };
            }
            if (copyAccountIps) {
              setUserWhitelistDirect(slaveId, masterWhitelist);
              nextAppMeta.whitelisted_networks = masterWhitelist;
              nextUserMeta.whitelisted_networks = masterWhitelist;
            }
            await supabase.auth.admin.updateUserById(slaveAuth.id, {
              app_metadata: nextAppMeta,
              user_metadata: nextUserMeta,
            });
            authRecordCache.delete(slaveId);
            authRecordCache.delete(slaveAuth.id);
          }
        } catch {}
      }

      // For forever policy, immediately revoke active slave sessions upon sync; for one_time, arm the Copy 1 trigger to fire once on the next Master Global Logout
      if (copyGlobalLogout && syncPolicy !== 'one_time') {
        await invalidateAllHumanSessionsForUser(slaveId);
        try {
          await supabase
            .from('refresh_tokens')
            .update({ isRevoked: true })
            .eq('userId', slaveId);
        } catch {}
      }

      try {
        invalidateUserRecordCache(slaveId);
      } catch {}
    }

    // 3. Persist Master Copy Settings in Master's auth app_metadata & master_plan_entitlements metadata
    // Under 'one_time', Access Management and Network Whitelist IPs have ALREADY been copied instantly above —
    // their one-time job is done, so only pending trigger-based modules (API Key Rotation / Global Logout) retain one_time flags/badges.
    const resolvedPolicy: 'one_time' | 'forever' = syncPolicy === 'one_time' ? 'one_time' : 'forever';
    const hasAccess = Boolean(copyAccessManagement);
    const hasIp = Boolean(copyAccountIps);
    const hasRotation = Boolean(copyApiKeyRotation);
    const hasLogout = Boolean(copyGlobalLogout);
    const keepAccess = hasAccess && resolvedPolicy === 'forever';
    const keepIp = hasIp && resolvedPolicy === 'forever';

    let savedMasterCopySettings: any = {
      syncPolicy: resolvedPolicy,
      copyAccessManagement: keepAccess,
      copyAccountIps: keepIp,
      copyApiKeyRotation: hasRotation,
      copyGlobalLogout: hasLogout,
      selectedSlaveIds: slaveAgentIds,
      accessSlaveIds: keepAccess ? slaveAgentIds : [],
      accessSyncPolicy: keepAccess ? resolvedPolicy : null,
      ipSlaveIds: keepIp ? slaveAgentIds : [],
      ipSyncPolicy: keepIp ? resolvedPolicy : null,
      rotationSlaveIds: hasRotation ? slaveAgentIds : [],
      rotationSyncPolicy: hasRotation ? resolvedPolicy : null,
      logoutSlaveIds: hasLogout ? slaveAgentIds : [],
      logoutSyncPolicy: hasLogout ? resolvedPolicy : null,
      updatedAt: new Date().toISOString(),
    };

    try {
      const authUser = masterAuthUser || (await ensureAuthUserRecord(supabase, masterUserId));
      if (authUser) {
        const existingMeta = authUser.app_metadata || {};
        await supabase.auth.admin.updateUserById(authUser.id, {
          app_metadata: {
            ...existingMeta,
            masterCopySettings: savedMasterCopySettings,
          },
        });
        authRecordCache.delete(masterUserId);
        authRecordCache.delete(authUser.id);
        invalidateUserRecordCache(masterUserId);
        invalidateUserRecordCache(authUser.id);
      }
    } catch (metaErr) {
      console.warn('Non-fatal: Failed to persist masterCopySettings to auth app_metadata:', metaErr);
    }

    try {
      const { data: entRows } = await supabase
        .from('master_plan_entitlements')
        .select('id, metadata')
        .eq('master_account_id', masterUserId)
        .order('updated_at', { ascending: false })
        .limit(10);
      if (Array.isArray(entRows) && entRows.length > 0) {
        const nowIso = new Date().toISOString();
        for (const entRow of entRows) {
          await supabase
            .from('master_plan_entitlements')
            .update({
              metadata: {
                ...(entRow.metadata || {}),
                masterCopySettings: savedMasterCopySettings,
              },
              updated_at: nowIso,
            })
            .eq('id', entRow.id);
        }
        try {
          MasterAccountService.getInstance().invalidateMasterPlanCache(masterUserId);
        } catch {}
      }
    } catch (entErr) {
      console.warn('Non-fatal: Failed to mirror masterCopySettings to master_plan_entitlements:', entErr);
    }

    try {
      await watchtowerActivityService.recordWatchtowerActivity({
        agentId: req.user!.agentId || masterUserId,
        agentName: req.user!.name,
        avatar: req.user!.avatar,
        type: 'MASTER_SETTINGS_COPIED',
        category: 'security',
        outcome: 'success',
        text: `Master synced settings (Access: ${!!copyAccessManagement}, IPs: ${!!copyAccountIps}, KeyRotation: ${!!copyApiKeyRotation}, Logout: ${!!copyGlobalLogout}) to ${slaveAgentIds.length} slave agents`,
        actorUserId: masterUserId,
        masterId: masterUserId,
        activityKey: `copy_settings:${masterUserId}:${Math.floor(Date.now() / 10000)}`
      });
    } catch (e) {}

    return res.json({
      success: true,
      data: {
        masterCopySettings: savedMasterCopySettings,
      },
      message: `Successfully synced configurations to ${slaveAgentIds.length} slave agents using ${resolvedPolicy === 'one_time' ? 'One-Time Copy' : 'Copy Forever'} policy.`
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: { message: err?.message || 'Failed to copy master settings.' } });
  }
});

// 5. GET /api/agents/me (View own agent profile)
router.get('/agents/me', requireUserOrAgentAuth, securityLayer('public_reads'), async (req: AuthenticatedRequest, res: Response) => {
  try {
    const profile = await getAgentProfile(req.user!.agentId, true);
    if (profile) {
      return res.json({ 
        success: true, 
        data: { 
          ...profile, 
          id: req.user!.id, 
          userId: req.user!.id,
          accountId: req.user!.id || (profile as any).accountId || req.user!.agentId
        } 
      });
    }
    res.json({ success: true, data: profile });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { message: err.message } });
  }
});

// In-memory cache to eliminate repetitive auth.admin.getUserById roundtrips across routes
const authRecordCache = new Map<string, { user: any; timestamp: number }>();
const AUTH_RECORD_CACHE_TTL_MS = 60000;

registerExternalAuthCacheInvalidator((uid?: string) => {
  if (!uid) {
    authRecordCache.clear();
  } else {
    authRecordCache.delete(uid);
  }
});

// Helper to guarantee an auth.users record exists for any database agent (including slave agents)
async function ensureAuthUserRecord(supabase: any, userId: string, bypassCache: boolean = false): Promise<any> {
  if (!userId) return null;
  const now = Date.now();
  if (!bypassCache) {
    const cached = authRecordCache.get(userId);
    if (cached && (now - cached.timestamp < AUTH_RECORD_CACHE_TTL_MS)) {
      return cached.user;
    }
  }

  try {
    const [authUserObj, dbUser] = await Promise.all([
      bypassCache
        ? supabase.auth.admin.getUserById(userId).then((r: any) => (!r.error ? r.data?.user : null)).catch(() => null)
        : getCachedAuthUserById(supabase, userId),
      findUserById(supabase, userId)
    ]);
    const authData = authUserObj ? { user: authUserObj } : null;
    const authErr = !authUserObj;

    if (!authErr && authData?.user) {
      const meta = authData.user.user_metadata || {};
      const metaEpoch = Number(meta.e2eeKeyEpoch || 0);
      const dbEpoch = Number(dbUser?.e2eeKeyEpoch || 0);
      const mergedHistory = {
        ...(dbUser?.e2eeEpochHistory && typeof dbUser.e2eeEpochHistory === 'object' ? dbUser.e2eeEpochHistory : {}),
        ...(meta.e2eeEpochHistory && typeof meta.e2eeEpochHistory === 'object' ? meta.e2eeEpochHistory : {}),
      };
      if (dbUser?.e2eePublicKey && (!meta.e2eePublicKey || dbEpoch > metaEpoch)) {
        authData.user.user_metadata = {
          ...meta,
          e2eePublicKey: dbUser.e2eePublicKey,
          e2eePublicKeyFingerprint: dbUser.e2eePublicKeyFingerprint,
          e2eeKeyEpoch: dbUser.e2eeKeyEpoch || 1,
          e2eeIdentityKey: dbUser.e2eeIdentityKey || meta.e2eeIdentityKey,
          e2eeKeySignature: dbUser.e2eeKeySignature || meta.e2eeKeySignature,
          e2eeEpochHistory: mergedHistory,
        };
      } else if (Object.keys(mergedHistory).length > 0) {
        authData.user.user_metadata = {
          ...meta,
          e2eeEpochHistory: mergedHistory,
        };
      }
      authRecordCache.set(userId, { user: authData.user, timestamp: now });
      return authData.user;
    }

    if (dbUser) {
      const email = dbUser.email || `${(dbUser.agentId || 'agent').toLowerCase()}@aamarva.net`;
      const { data: created, error: createErr } = await supabase.auth.admin.createUser({
        id: dbUser.id,
        email,
        email_confirm: true,
        user_metadata: {
          agentId: dbUser.agentId,
          name: dbUser.name,
          avatar: dbUser.avatar,
          bio: dbUser.bio,
          e2eePublicKey: dbUser.e2eePublicKey || null,
          e2eePublicKeyFingerprint: dbUser.e2eePublicKeyFingerprint || null,
          e2eeKeyEpoch: dbUser.e2eeKeyEpoch || 1,
          e2eeIdentityKey: dbUser.e2eeIdentityKey || null,
          e2eeKeySignature: dbUser.e2eeKeySignature || null,
          e2eeEpochHistory: dbUser.e2eeEpochHistory || {},
        }
      });

      if (!createErr && created?.user) {
        authRecordCache.set(userId, { user: created.user, timestamp: now });
        return created.user;
      }
    }

    const { data: refetched } = await supabase.auth.admin.getUserById(userId);
    return refetched?.user || null;
  } catch (err) {
    console.warn('ensureAuthUserRecord notice:', err);
    return null;
  }
}

// 5b-2. GET /api/agents/me/e2ee (Retrieve Registered E2EE Public Key & Fingerprint)
router.get('/agents/me/e2ee', requireUserOrAgentAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const supabase = getSupabaseClient();
    const [authUser, dbUser] = await Promise.all([
      ensureAuthUserRecord(supabase, req.user!.id, false),
      findUserById(supabase, req.user!.id)
    ]);
    const meta = authUser?.user_metadata || {};
    const useDbAsNewer = Boolean(
      dbUser?.e2eePublicKey &&
      (!meta.e2eePublicKey || Number(dbUser.e2eeKeyEpoch || 1) > Number(meta.e2eeKeyEpoch || 1))
    );
    const mergedHistory = {
      ...(dbUser?.e2eeEpochHistory && typeof dbUser.e2eeEpochHistory === 'object' ? dbUser.e2eeEpochHistory : {}),
      ...(meta.e2eeEpochHistory && typeof meta.e2eeEpochHistory === 'object' ? meta.e2eeEpochHistory : {}),
    };
    res.json({
      success: true,
      data: {
        publicKey: useDbAsNewer ? dbUser.e2eePublicKey : (meta.e2eePublicKey || dbUser?.e2eePublicKey || null),
        fingerprint: useDbAsNewer ? dbUser.e2eePublicKeyFingerprint : (meta.e2eePublicKeyFingerprint || dbUser?.e2eePublicKeyFingerprint || null),
        identityKey: useDbAsNewer ? dbUser.e2eeIdentityKey : (meta.e2eeIdentityKey || dbUser?.e2eeIdentityKey || null),
        keyEpoch: useDbAsNewer ? (dbUser.e2eeKeyEpoch || 1) : (meta.e2eeKeyEpoch || dbUser?.e2eeKeyEpoch || 1),
        epochHistory: Object.keys(mergedHistory).length > 0 ? mergedHistory : null,
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { message: err.message } });
  }
});

// 5b-3. GET /api/agents/:agentId/e2ee (Retrieve Registered E2EE Public Key & Fingerprint by Agent ID or User ID)
router.get('/agents/:agentId/e2ee', requireUserOrAgentAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const rawTarget = req.params.agentId as string;
    if (!rawTarget) {
      return res.status(400).json({ success: false, error: { message: 'Agent ID is required.' } });
    }

    const supabase = getSupabaseClient();
    let targetUserId = req.user?.id;
    let targetAgentId = req.user?.agentId;
    let targetUser: any = null;

    if (rawTarget.toLowerCase() !== 'me') {
      targetUser = await resolveUserRecord(rawTarget);

      if (!targetUser) {
        return res.status(404).json({ success: false, error: { message: `Agent identity ${rawTarget} not found.` } });
      }

      targetUserId = targetUser.id;
      targetAgentId = targetUser.agentId;
    } else {
      targetUser = await findUserById(supabase, targetUserId!);
    }

    const authUser = await ensureAuthUserRecord(supabase, targetUserId!, false);
    const meta = authUser?.user_metadata || {};

    const useDbAsNewer = Boolean(
      targetUser?.e2eePublicKey &&
      (!meta.e2eePublicKey || Number(targetUser.e2eeKeyEpoch || 1) > Number(meta.e2eeKeyEpoch || 1))
    );
    let resolvedPubKey = useDbAsNewer ? targetUser.e2eePublicKey : (meta.e2eePublicKey || targetUser?.e2eePublicKey || null);
    let resolvedFp = useDbAsNewer ? targetUser.e2eePublicKeyFingerprint : (meta.e2eePublicKeyFingerprint || targetUser?.e2eePublicKeyFingerprint || null);
    let resolvedIdKey = useDbAsNewer ? targetUser.e2eeIdentityKey : (meta.e2eeIdentityKey || targetUser?.e2eeIdentityKey || null);
    let resolvedEpoch = useDbAsNewer ? (targetUser.e2eeKeyEpoch || 1) : (meta.e2eeKeyEpoch || targetUser?.e2eeKeyEpoch || 1);
    const mergedHistory = {
      ...(targetUser?.e2eeEpochHistory && typeof targetUser.e2eeEpochHistory === 'object' ? targetUser.e2eeEpochHistory : {}),
      ...(meta.e2eeEpochHistory && typeof meta.e2eeEpochHistory === 'object' ? meta.e2eeEpochHistory : {}),
    };
    let resolvedHistory = Object.keys(mergedHistory).length > 0 ? mergedHistory : null;

    if (!resolvedPubKey) {
      const { data: vault } = await supabase.from('user_key_vaults').select('*').eq('user_id', targetUserId!).maybeSingle();
      if (vault?.public_key) {
        resolvedPubKey = vault.public_key;
      }
    }

    res.json({
      success: true,
      data: {
        agentId: targetAgentId,
        userId: targetUserId,
        publicKey: resolvedPubKey,
        fingerprint: resolvedFp,
        identityKey: resolvedIdKey,
        keyEpoch: resolvedEpoch,
        epochHistory: resolvedHistory,
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { message: err.message } });
  }
});

// 5c. PUT /api/agents/me/e2ee (Upload E2EE Public Key with Authenticated Identity Binding)
router.put('/agents/me/e2ee', requireUserOrAgentAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { publicKey, fingerprint, identityKey, signature, allowRotation, keyEpoch } = req.body;
    if (!publicKey) throw new Error('Public key is required.');

    const parsedEpoch = typeof keyEpoch === 'number' && keyEpoch > 0 ? keyEpoch : 1;

    // Cryptographic validation of public key JWK (ECDH NIST P-256)
    let parsedJwk: any;
    try {
      parsedJwk = typeof publicKey === 'string' ? JSON.parse(publicKey) : publicKey;
    } catch {
      res.status(400).json({ success: false, error: { message: 'Invalid public key format. Valid JWK required.' } });
      return;
    }

    if (parsedJwk.kty !== 'EC' || parsedJwk.crv !== 'P-256' || !parsedJwk.x || !parsedJwk.y) {
      res.status(400).json({ success: false, error: { message: 'Public key must be a valid ECDH NIST P-256 JWK.' } });
      return;
    }

    // Canonical fingerprint computation matching src/lib/e2ee.ts (colon-delimited SHA256)
    const canonicalJwk = JSON.stringify({ crv: parsedJwk.crv || 'P-256', kty: parsedJwk.kty || 'EC', x: parsedJwk.x, y: parsedJwk.y });
    const digestHex = nodeCrypto.createHash('sha256').update(canonicalJwk).digest('hex').toUpperCase();
    const computedFingerprint = 'SHA256:' + (digestHex.match(/.{2}/g)?.join(':') || digestHex);

    // Authenticated Identity Key Binding Verification (ECDSA P-256)
    let parsedIdentityJwk: any = null;
    let identityKeyStr: string | null = null;
    if (identityKey) {
      try {
        parsedIdentityJwk = typeof identityKey === 'string' ? JSON.parse(identityKey) : identityKey;
      } catch {
        res.status(400).json({ success: false, error: { message: 'Invalid identity key format. Valid JWK required.' } });
        return;
      }

      if (parsedIdentityJwk.kty !== 'EC' || parsedIdentityJwk.crv !== 'P-256' || !parsedIdentityJwk.x || !parsedIdentityJwk.y) {
        res.status(400).json({ success: false, error: { message: 'Identity key must be a valid ECDSA NIST P-256 JWK.' } });
        return;
      }

      identityKeyStr = typeof identityKey === 'string' ? identityKey : JSON.stringify(identityKey);

      // Verify the cryptographic signature over the canonical binding statement
      if (!signature || typeof signature !== 'string') {
        res.status(400).json({ success: false, error: { message: 'Identity signature is required when providing an identity key.' } });
        return;
      }

      try {
        const canonicalAgentId = req.user!.agentId.toUpperCase();
        const bindingStatement = new TextEncoder().encode(`AAMARVA-KEY-BINDING:v1:${canonicalAgentId}:${computedFingerprint}`);
        const importedIdKey = await crypto.subtle.importKey(
          'jwk',
          parsedIdentityJwk,
          { name: 'ECDSA', namedCurve: 'P-256' },
          true,
          ['verify']
        );
        const sigBuffer = Buffer.from(signature, 'base64');
        const isSigValid = await crypto.subtle.verify(
          { name: 'ECDSA', hash: 'SHA-256' },
          importedIdKey,
          sigBuffer,
          bindingStatement
        );

        if (!isSigValid) {
          res.status(400).json({
            success: false,
            error: {
              code: 'INVALID_KEY_SIGNATURE',
              message: 'Cryptographic identity binding verification failed. Signature does not match identity key and agent ID.'
            }
          });
          return;
        }
      } catch (verErr: any) {
        res.status(400).json({
          success: false,
          error: {
            code: 'INVALID_KEY_SIGNATURE',
            message: `Cryptographic identity verification error: ${verErr.message}`
          }
        });
        return;
      }
    }

    const supabase = getSupabaseClient();
    const authUser = await ensureAuthUserRecord(supabase, req.user!.id);
    if (!authUser) {
      console.warn('User account not found for E2EE key update:', req.user!.id);
      res.status(404).json({
        success: false,
        error: {
          code: 'USER_NOT_FOUND',
          message: 'User account not found.'
        }
      });
      return;
    }

    const userDataMeta = authUser.user_metadata || {};
    const existingFp = userDataMeta.e2eePublicKeyFingerprint;
    const existingIdKey = userDataMeta.e2eeIdentityKey;

    const isRotationAuthorized = allowRotation === true || allowRotation === 'true' || allowRotation === 1;

    // Prevent silent key replacement / substitution if key already exists and rotation is not authorized
    if (existingFp && existingFp !== computedFingerprint && !isRotationAuthorized) {
      res.status(409).json({
        success: false,
        error: {
          code: 'KEY_ROTATION_CONFIRMATION_REQUIRED',
          message: 'An E2EE public key is already registered for this identity. Explicit key rotation authorization is required to replace it.'
        }
      });
      return;
    }

    // Prevent unauthorized replacement of identity signing key
    if (existingIdKey && identityKeyStr && existingIdKey !== identityKeyStr && !isRotationAuthorized) {
      res.status(409).json({
        success: false,
        error: {
          code: 'IDENTITY_KEY_IMMUTABLE',
          message: 'Agent identity key is permanently bound to this agent. Explicit key rotation authorization is required to re-bind identity.'
        }
      });
      return;
    }

    const pubKeyStr = typeof publicKey === 'string' ? publicKey : JSON.stringify(publicKey);
    const existingEpochHistory = (userDataMeta.e2eeEpochHistory as Record<string, any>) || {};
    
    // Strict epoch immutability check: Never overwrite an existing epoch with a different key
    const existingEpochEntry = existingEpochHistory[String(parsedEpoch)];
    if (existingEpochEntry && existingEpochEntry.fingerprint && existingEpochEntry.fingerprint !== computedFingerprint) {
      res.status(409).json({
        success: false,
        error: {
          code: 'E2EE_EPOCH_ALREADY_EXISTS',
          message: `Key epoch ${parsedEpoch} already exists with a different cryptographic key. Historical key epochs are immutable and cannot be overwritten.`
        }
      });
      return;
    }

    existingEpochHistory[String(parsedEpoch)] = {
      publicKey: pubKeyStr,
      fingerprint: computedFingerprint,
      keyEpoch: parsedEpoch,
      identityKey: identityKeyStr,
      signature: signature,
      updatedAt: new Date().toISOString()
    };

    const updatedMetadata = {
      ...userDataMeta,
      e2eePublicKey: pubKeyStr,
      e2eePublicKeyFingerprint: computedFingerprint,
      e2eeKeyEpoch: parsedEpoch,
      e2eeEpochHistory: existingEpochHistory,
      ...(identityKeyStr ? { e2eeIdentityKey: identityKeyStr } : {}),
      ...(signature ? { e2eeKeySignature: signature } : {}),
      e2eeKeyUpdatedAt: new Date().toISOString()
    };

    const { error: updateError } = await supabase.auth.admin.updateUserById(req.user!.id, {
      user_metadata: updatedMetadata
    });

    if (updateError) {
      console.warn('Failed to persist E2EE key metadata to auth user:', updateError.message);
      res.status(500).json({
        success: false,
        error: {
          code: 'E2EE_KEY_PERSISTENCE_FAILED',
          message: 'Failed to persist E2EE key metadata.'
        }
      });
      return;
    }

    try {
      await supabase.from('users').update({
        e2eePublicKey: pubKeyStr,
        e2eePublicKeyFingerprint: computedFingerprint,
        e2eeKeyEpoch: parsedEpoch,
        e2eeEpochHistory: existingEpochHistory,
        ...(identityKeyStr ? { e2eeIdentityKey: identityKeyStr } : {}),
        ...(signature ? { e2eeKeySignature: signature } : {}),
        updatedAt: new Date().toISOString()
      }).eq('id', req.user!.id);
    } catch (dbSyncErr) {
      console.warn('Syncing E2EE key to users table note:', dbSyncErr);
    }

    authRecordCache.delete(req.user!.id);
    if (req.user!.agentId) authRecordCache.delete(req.user!.agentId);
    invalidateUserRecordCache(req.user!.id);

    try {
      watchtowerActivityService.recordWatchtowerActivity({
        agentId: req.user!.agentId || req.user!.id,
        agentName: req.user!.name,
        avatar: req.user!.avatar,
        emailVerified: req.user!.emailVerified,
        text: 'registered its E2EE cryptographic identity',
        type: 'E2EE_KEYS_UPDATED',
        actorUserId: req.user!.id,
        masterId: req.user!.masterId || req.user!.id,
        entityId: req.user!.agentId || undefined,
        endpoint: 'PUT /api/agents/me/e2ee',
        activityKey: `e2ee_keys:${req.user!.id}:${parsedEpoch}`
      }).catch(console.warn);
      (req as any).alreadyRecordedSlaveActivity = true;
    } catch {}

    res.json({
      success: true,
      data: {
        fingerprint: computedFingerprint,
        keyEpoch: parsedEpoch,
        hasIdentityBinding: !!identityKeyStr
      }
    });
  } catch (err: any) {
    res.status(400).json({ success: false, error: { message: err.message } });
  }
});

// 5d. GET /api/agents/me/e2ee/recovery (Retrieve Encrypted Recovery Artifact for Multi-Device E2EE Sync - Human Session Only)
router.get('/agents/me/e2ee/recovery', requireHumanSession, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const supabase = getSupabaseClient();
    const authUser = await ensureAuthUserRecord(supabase, req.user!.id, true);
    if (!authUser) {
      return res.status(404).json({ success: false, error: { message: 'User not found.' } });
    }
    const metadata = authUser.user_metadata || {};

    res.json({
      success: true,
      data: {
        recoveryVault: metadata.e2eeRecoveryVault || null,
        publicKey: metadata.e2eePublicKey || null,
        fingerprint: metadata.e2eePublicKeyFingerprint || null,
        keyEpoch: metadata.e2eeKeyEpoch || 1,
        epochHistory: metadata.e2eeEpochHistory || null
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { message: err.message || 'Failed to retrieve recovery vault.' } });
  }
});

// Helper for strict Base64 validation
function isValidBase64(str: string): boolean {
  if (!str || typeof str !== 'string') return false;
  const trimmed = str.trim();
  if (trimmed.length === 0) return false;
  const base64Regex = /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/;
  const urlSafeRegex = /^(?:[A-Za-z0-9_-]{4})*(?:[A-Za-z0-9_-]{2}==|[A-Za-z0-9_-]{3}=)?$/;
  return base64Regex.test(trimmed) || urlSafeRegex.test(trimmed);
}

// 5e. PUT /api/agents/me/e2ee/recovery (Upload Encrypted Recovery Artifact - Human Session Only, Strict Transport Validation)
router.put('/agents/me/e2ee/recovery', requireHumanSession, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { recoveryVault } = req.body;
    if (!recoveryVault || typeof recoveryVault !== 'object') {
      return res.status(400).json({ success: false, error: { message: 'Valid recoveryVault object is required.' } });
    }

    const { ciphertext, nonce, version, kdfVersion } = recoveryVault;
    if (!ciphertext || typeof ciphertext !== 'string' || !nonce || typeof nonce !== 'string') {
      return res.status(400).json({ success: false, error: { message: 'ciphertext and nonce strings are required in recoveryVault.' } });
    }

    // Strict transport validation: Base64 and max size checks
    if (!isValidBase64(ciphertext)) {
      return res.status(400).json({ success: false, error: { message: 'Invalid ciphertext transport encoding. Base64 required.' } });
    }

    if (ciphertext.length > 131072) {
      return res.status(400).json({ success: false, error: { message: 'Recovery payload exceeds maximum allowed size (128KB).' } });
    }

    if (!isValidBase64(nonce)) {
      return res.status(400).json({ success: false, error: { message: 'Invalid nonce encoding. Base64 required.' } });
    }

    try {
      const nonceBuf = Buffer.from(nonce, 'base64');
      if (nonceBuf.length !== 12) {
        return res.status(400).json({ success: false, error: { message: 'Invalid nonce. AES-256-GCM requires exactly 12 bytes (96 bits).' } });
      }
    } catch {
      return res.status(400).json({ success: false, error: { message: 'Invalid nonce decoding.' } });
    }

    const parsedVersion = version !== undefined ? Number(version) : 1;
    if (!Number.isInteger(parsedVersion) || (parsedVersion !== 1 && parsedVersion !== 2)) {
      return res.status(400).json({ success: false, error: { message: 'Unsupported recovery-vault version.' } });
    }

    const parsedKdfVersion = kdfVersion !== undefined ? Number(kdfVersion) : 2;
    if (!Number.isInteger(parsedKdfVersion) || (parsedKdfVersion !== 1 && parsedKdfVersion !== 2)) {
      return res.status(400).json({ success: false, error: { message: 'Unsupported KDF version.' } });
    }

    const supabase = getSupabaseClient();
    const vaultEntry = {
      ciphertext,
      nonce,
      version: parsedVersion,
      kdfVersion: parsedKdfVersion,
      updatedAt: new Date().toISOString()
    };

    const authUser = await ensureAuthUserRecord(supabase, req.user!.id, true);
    if (!authUser) {
      return res.status(404).json({ success: false, error: { message: 'User not found.' } });
    }
    const metadata = authUser.user_metadata || {};
    const { error: updateError } = await supabase.auth.admin.updateUserById(req.user!.id, {
      user_metadata: {
        ...metadata,
        e2eeRecoveryVault: vaultEntry
      }
    });
    if (updateError) {
      return res.status(500).json({ success: false, error: { message: 'Failed to update recovery vault.' } });
    }

    authRecordCache.delete(req.user!.id);
    if (req.user!.agentId) authRecordCache.delete(req.user!.agentId);
    invalidateUserRecordCache(req.user!.id);

    res.json({
      success: true,
      message: 'Encrypted recovery artifact preserved successfully.'
    });
  } catch (err: any) {
    res.status(400).json({ success: false, error: { message: err.message } });
  }
});

// 5b. PATCH /api/agents/me (Edit own agent profile)
router.patch('/agents/me', requireUserOrAgentAuth, securityLayer('agent_update'), async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { name, bio, avatar } = req.body;
    
    const supabase = getSupabaseClient();
    const { data: dbUser } = await supabase
      .from('users')
      .select('*')
      .eq('id', req.user!.id)
      .maybeSingle();

    const isSlave = !!(
      (dbUser && (
        dbUser.account_type === 'slave' ||
        dbUser.role === 'slave' ||
        dbUser.is_slave === true ||
        (dbUser.email && typeof dbUser.email === 'string' && dbUser.email.includes('+AMR-')) ||
        (dbUser.master_id && dbUser.master_id !== dbUser.id)
      )) ||
      (req.user && (
        (req.user as any).account_type === 'slave' ||
        (req.user as any).role === 'slave' ||
        (req.user as any).is_slave === true ||
        ((req.user as any).masterId && (req.user as any).masterId !== req.user.id)
      ))
    );

    // Input validation constraints
    if (name !== undefined) {
      const trimmedName = name.toString().trim();
      if (trimmedName.length < 1 || trimmedName.length > 20) {
        throw new Error('Agent name must be between 1 and 20 characters.');
      }
    }

    if (bio !== undefined) {
      const bioStr = bio.toString();
      if (bioStr.length > 220) {
        throw new Error('Agent bio description cannot exceed 220 characters.');
      }
    }

    if (avatar !== undefined && !isSlave) {
      const avatarStr = typeof avatar === 'string' ? avatar.trim() : '';
      if (avatarStr.length > 1000000) {
        throw new Error('Avatar payload is too large.');
      }
    }

    const updateData: any = {};
    if (name !== undefined) updateData.name = name;
    if (bio !== undefined) updateData.bio = bio;
    if (avatar !== undefined && !isSlave) {
      updateData.avatar = avatar;
    }
    
    if (Object.keys(updateData).length === 0) {
      throw new Error('No data provided to update.');
    }
    
    const updatedProfile = await updateUserProfile(req.user!.id, updateData);
    const trimmedNewName = updateData.name !== undefined ? String(updateData.name).trim() : '';
    const profileDetailsText = trimmedNewName ? `updated profile name to "${trimmedNewName}"` : 'updated its profile';
    const profileFp = await logAgentFootprint(
      req.user!.id,
      'PROFILE_UPDATED',
      profileDetailsText,
      undefined,
      req.user?.agentId,
      'PATCH /api/agents/me'
    );

    // Broadcast floor activity: [Agent Name] updated its profile (await before responding so immediate refresh sees it)
    try {
      await watchtowerActivityService.recordWatchtowerActivity({
        id: profileFp?.id || `wt_prof_${crypto.randomUUID()}`,
        agentId: req.user!.agentId || req.user!.id,
        agentName: (updatedProfile as any)?.name || req.user!.name,
        avatar: (updatedProfile as any)?.avatar || req.user!.avatar,
        emailVerified: req.user!.emailVerified,
        text: trimmedNewName ? `updated profile name to "${trimmedNewName}"` : 'updated its profile',
        type: 'AGENT_PROFILE_UPDATED',
        details: trimmedNewName ? { updatedName: trimmedNewName } : undefined,
        actorUserId: req.user!.id,
        masterId: req.user!.masterId || req.user!.id,
        endpoint: 'PATCH /api/agents/me',
        skipFootprintInsert: true
      });
      (req as any).alreadyRecordedSlaveActivity = true;
    } catch (wtErr: any) {
      console.warn('[PATCH /agents/me] Watchtower activity warning:', wtErr?.message || wtErr);
    }

    res.json({ success: true, data: updatedProfile });
  } catch (err: any) {
    res.status(400).json({ success: false, error: { message: err.message } });
  }
});

// Helper: Authenticate session optionally or extract master ID from auth header / cookie
async function resolveAuthMasterId(req: Request): Promise<string | null> {
  const authReq = req as AuthenticatedRequest;
  if (authReq.user?.id) {
    const sb = getSupabaseClient();
    const { data: u } = await sb.from('users').select('id, master_id, is_master_primary').eq('id', authReq.user.id).maybeSingle();
    return (u?.master_id && !u?.is_master_primary) ? u.master_id : authReq.user.id;
  }

  // Check human session cookie or Bearer token
  const sessionCookie = req.cookies?.[HUMAN_SESSION_COOKIE_NAME];
  const authHeader = req.headers.authorization;
  const bearerToken = (authHeader && authHeader.startsWith('Bearer ')) ? authHeader.split(' ')[1] : undefined;
  const candidateSession = (sessionCookie && typeof sessionCookie === 'string' && sessionCookie.trim())
    ? sessionCookie.trim()
    : bearerToken;

  if (candidateSession) {
    try {
      const payload = await verifyHumanSession(candidateSession);
      if (payload && payload.id) {
        const sb = getSupabaseClient();
        const u = await findUserById(sb, payload.id);
        return (u?.master_id && !u?.is_master_primary) ? u.master_id : payload.id;
      }
    } catch (e) {}
  }

  // Check agent API key via real fingerprint lookup
  const apiKey = req.headers['x-api-key'] as string;
  if (apiKey && typeof apiKey === 'string' && apiKey.trim()) {
    try {
      const fingerprint = computeApiKeyFingerprint(apiKey.trim());
      const sb = getSupabaseClient();
      const { data: u } = await sb
        .from('users')
        .select('id, master_id, is_master_primary, status')
        .eq('apiKeyFingerprint', fingerprint)
        .maybeSingle();
      if (u?.id && u.status !== 'deleted') {
        return (u.master_id && !u.is_master_primary) ? u.master_id : u.id;
      }
    } catch (e) {}
  }

  return null;
}

// 6. GET /api/agents/:agentId (Fleet-isolated private profile read)
router.get('/agents/:agentId', requireUserOrAgentAuth, securityLayer('public_reads'), async (req: Request, res: Response) => {
  try {
    const agentId = req.params.agentId as string;
    const callerMasterId = await resolveAuthMasterId(req);

    if (!callerMasterId) {
      return res.status(404).json({ success: false, error: { message: 'Agent profile not found.' } });
    }

    const profile = await getAgentProfile(agentId, false, callerMasterId);
    res.json({ success: true, data: profile });
  } catch (err: any) {
    res.status(404).json({ success: false, error: { message: 'Agent profile not found.' } });
  }
});

// 7b. DELETE /api/agents/me (Delete own account)
router.delete('/agents/me', requireUserOrAgentAuth, securityLayer('agent_delete'), async (req: AuthenticatedRequest, res: Response) => {
  try {
    const isSlave = !!((req.user as any)?.master_id || (req.user as any)?.masterUserId);
    const masterId = (req.user as any)?.master_id || (req.user as any)?.masterUserId;

    // Broadcast floor activity: [Agent Name] left the floor
    watchtowerActivityService.recordWatchtowerActivity({
      agentId: req.user!.agentId || req.user!.id,
      agentName: req.user!.name,
      avatar: req.user!.avatar,
      emailVerified: req.user!.emailVerified,
      text: 'left the floor',
      type: 'AGENT_DECOMMISSIONED'
    }).catch(console.warn);
      (req as any).alreadyRecordedSlaveActivity = true;

    await deleteUserAccount(req.user!.id);

    if (isSlave && masterId) {
      const rawSession = req.cookies?.[HUMAN_SESSION_COOKIE_NAME];
      if (rawSession) {
        try {
          const supabase = getSupabaseClient();
          const { data: masterUser } = await supabase
            .from('users')
            .select('agentId, agent_id')
            .eq('id', masterId)
            .maybeSingle();

          const masterAgentId = masterUser?.agentId || masterUser?.agent_id || 'master';

          const newToken = switchHumanSessionToken(rawSession, masterId, masterAgentId);
          res.cookie(HUMAN_SESSION_COOKIE_NAME, newToken, getHumanSessionCookieOptions());
        } catch (swErr) {
          console.warn('Failed to auto-switch session cookie to master:', swErr);
        }
      }
      return res.json({ success: true, data: { switchedToMaster: true, masterId } });
    }

    res.clearCookie(HUMAN_SESSION_COOKIE_NAME, getHumanSessionCookieOptions());
    res.clearCookie(REFRESH_COOKIE_NAME, getRefreshCookieOptions());
    res.json({ success: true, data: null });
  } catch (err: any) {
    res.status(400).json({ success: false, error: { message: err.message } });
  }
});



export const userConnectionLastReadMap = new Map<string, number>();

export async function recordUserConnectionRead(user: any, ...targetIdentifiers: any[]): Promise<void> {
  if (!user) return;
  const now = Date.now();
  const userKeys = [
    user.id,
    user.agentId,
    (user.id || '').toString().toLowerCase(),
    (user.agentId || '').toString().toLowerCase(),
    (user.agentId || '').toString().toUpperCase(),
  ].filter((k): k is string => Boolean(k && typeof k === 'string' && k.trim()));

  const selfNormSet = new Set<string>(
    [user.id, user.agentId]
      .filter((k): k is string => Boolean(k && typeof k === 'string' && k.trim()))
      .map((k) => k.trim().replace(/^@+/, '').toLowerCase())
  );

  const flatTargets = targetIdentifiers
    .flat(Infinity)
    .filter((t): t is string => Boolean(t && typeof t === 'string' && t.trim()))
    .filter((t) => !selfNormSet.has(t.trim().replace(/^@+/, '').toLowerCase()));

  if (flatTargets.length === 0) return;

  // Check if all targets were already recorded very recently in memory to avoid thrashing Supabase Auth Admin
  const primaryUserKey = user.id || userKeys[0];
  const alreadyRecordedRecently =
    Boolean(primaryUserKey) &&
    flatTargets.every((rawT) => {
      const clean = rawT.trim().replace(/^@+/, '').toLowerCase();
      const prevTs = userConnectionLastReadMap.get(`${primaryUserKey}@@${clean}`);
      return typeof prevTs === 'number' && now - prevTs < 5000;
    });

  userKeys.forEach((uk) => {
    flatTargets.forEach((rawT) => {
      const t = rawT.trim();
      const clean = t.replace(/^@+/, '');
      [t, clean, t.toLowerCase(), clean.toLowerCase(), clean.toUpperCase()].forEach((tk) => {
        userConnectionLastReadMap.set(`${uk}@@${tk}`, now);
      });
    });
  });

  if (alreadyRecordedRecently) {
    return;
  }

  // Persist into user_metadata for long-term survival across reloads/restarts
  try {
    if (user.id) {
      const sb = getSupabaseClient();
      const { data: authData } = await sb.auth.admin.getUserById(user.id);
      const existingMeta = authData?.user?.user_metadata || {};
      const readMap = { ...(existingMeta.read_connections || {}) };
      flatTargets.forEach((rawT) => {
        const t = rawT.trim();
        const clean = t.replace(/^@+/, '');
        readMap[clean.toLowerCase()] = now;
        readMap[clean.toUpperCase()] = now;
        readMap[t.toLowerCase()] = now;
        readMap[t.toUpperCase()] = now;
      });
      await sb.auth.admin.updateUserById(user.id, {
        user_metadata: {
          ...existingMeta,
          read_connections: readMap,
        }
      });
    }
  } catch (err) {}
}

// 13c. POST /api/connections/:connectionId/read (Mark connection messages as read)
router.post(['/connections/:connectionId/read', '/connections/read/:connectionId'], requireUserOrAgentAuth, async (req: AuthenticatedRequest, res: Response) => {
  const cid = (req.params.connectionId || req.body?.connectionId || '').trim();
  const agentId = (req.body?.agentId || '').trim();
  const extraIds = Array.isArray(req.body?.ids) ? req.body.ids : [];

  const targets: string[] = [cid, agentId, ...extraIds].filter(Boolean);

  try {
    const sb = getSupabaseClient();
    if (cid) {
      const conn = await getConnectionRecord(cid);
      if (conn) {
        if (conn.id) targets.push(conn.id);
        const myIdLower = (req.user?.id || '').toLowerCase();
        const myAgentLower = (req.user?.agentId || '').replace(/^@+/, '').toLowerCase();
        const isNotSelf = (val?: string | null) => {
          if (!val) return false;
          const norm = val.trim().replace(/^@+/, '').toLowerCase();
          return Boolean(norm && norm !== myIdLower && norm !== myAgentLower);
        };
        if (isNotSelf(conn.user1_agent_id)) targets.push(conn.user1_agent_id);
        if (isNotSelf(conn.user2_agent_id)) targets.push(conn.user2_agent_id);
        if (isNotSelf(conn.user1_id)) targets.push(conn.user1_id);
        if (isNotSelf(conn.user2_id)) targets.push(conn.user2_id);
      }
    }
    if (agentId) {
      const cleanAid = agentId.replace(/^@+/, '');
      const { data: userByAgent } = await sb.from('users').select('id, agentId').ilike('agentId', cleanAid).maybeSingle();
      if (userByAgent) {
        if (userByAgent.id) targets.push(userByAgent.id);
        if (userByAgent.agentId) targets.push(userByAgent.agentId);
      }
    }
  } catch (e) {}

  await recordUserConnectionRead(req.user, ...targets);
  res.json({ success: true, message: 'Marked as read' });
});

// 13. GET /api/connections (User or Agent)
router.get('/connections', requireUserOrAgentAuth, securityLayer('public_reads'), async (req: AuthenticatedRequest, res: Response) => {
  try {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    res.setHeader('Pragma', 'no-cache');
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 20;
    const result = await getUserConnections(req.user!.id, page, limit);

    const connIds = (result.connections || []).map((c: any) => c.id).filter(Boolean);
    const aliasToCanonConnId = new Map<string, string>();
    const allQueryConnIds = new Set<string>();
    for (const c of result.connections || []) {
      if (!c?.id) continue;
      allQueryConnIds.add(c.id);
      aliasToCanonConnId.set(c.id, c.id);
      aliasToCanonConnId.set(String(c.id).toLowerCase(), c.id);
      if (Array.isArray(c.allConnectionIds)) {
        for (const aid of c.allConnectionIds) {
          if (!aid) continue;
          allQueryConnIds.add(aid);
          aliasToCanonConnId.set(aid, c.id);
          aliasToCanonConnId.set(String(aid).toLowerCase(), c.id);
        }
      }
    }

    const sb = getSupabaseClient();
    let connReviewsMap = new Map<string, { id: string; comment: string }>();
    if (connIds.length > 0) {
      try {
        const { data: revs } = await sb.from('reviews').select('id, connectionId, comment').in('connectionId', connIds);
        if (revs) {
          revs.forEach((r: any) => {
            if (r.connectionId && !connReviewsMap.has(r.connectionId)) {
              connReviewsMap.set(r.connectionId, { id: r.id, comment: r.comment });
            }
          });
        }
      } catch (e) {}
    }

    // Query persisted read map from Supabase user_metadata
    let persistedReadMap: Record<string, number> = {};
    try {
      if (req.user?.id) {
        const authUser = await getCachedAuthUserById(sb, req.user.id);
        if (authUser?.user_metadata?.read_connections) {
          persistedReadMap = authUser.user_metadata.read_connections;
        }
      }
    } catch (e) {}

    const connUnreadMap = new Map<string, number>();
    const connLatestMsgMap = new Map<string, number>();
    if (allQueryConnIds.size > 0) {
      try {
        const uniqueQueryIds = Array.from(allQueryConnIds);
        const msgs: any[] = [];
        const chunkSize = 25;
        const PAGE_SIZE = 1000;
        const chunks: string[][] = [];
        for (let i = 0; i < uniqueQueryIds.length; i += chunkSize) {
          chunks.push(uniqueQueryIds.slice(i, i + chunkSize));
        }
        await Promise.all(
          chunks.map(async (chunk) => {
            for (let pageIdx = 0; pageIdx < 10; pageIdx++) {
              const from = pageIdx * PAGE_SIZE;
              const { data: chunkMsgs } = await sb
                .from('messages')
                .select('id, connectionId, senderUserId, senderAgentId, createdAt')
                .in('connectionId', chunk)
                .order('createdAt', { ascending: false })
                .range(from, from + PAGE_SIZE - 1);
              if (chunkMsgs && chunkMsgs.length > 0) {
                msgs.push(...chunkMsgs);
              }
              if (!chunkMsgs || chunkMsgs.length < PAGE_SIZE) {
                break;
              }
            }
          })
        );

        if (msgs.length > 0) {
          const userIdLower = (req.user!.id || '').toLowerCase();
          const userAgentLower = (req.user!.agentId || '').toLowerCase();

          const possibleUserKeys = [
            req.user?.id,
            req.user?.agentId,
            userIdLower,
            userAgentLower,
            (req.user?.agentId || '').toUpperCase(),
          ].filter(Boolean);

          msgs.forEach((m: any) => {
            if (!m.connectionId) return;
            const canonConnId =
              aliasToCanonConnId.get(m.connectionId) ||
              aliasToCanonConnId.get(String(m.connectionId).toLowerCase()) ||
              m.connectionId;
            const msgTime = new Date(m.createdAt).getTime();
            const prevLatest = connLatestMsgMap.get(canonConnId) || 0;
            if (msgTime > prevLatest) {
              connLatestMsgMap.set(canonConnId, msgTime);
            }

            const senderU = (m.senderUserId || '').toLowerCase();
            const senderA = (m.senderAgentId || '').toLowerCase().replace(/^@+/, '');
            const cleanUserAgent = userAgentLower.replace(/^@+/, '');
            const isFromMe = (senderU && senderU === userIdLower) || (senderA && cleanUserAgent && senderA === cleanUserAgent);
            if (!isFromMe) {
              const possibleTargetKeys = [
                canonConnId,
                m.connectionId,
                (m.connectionId || '').toLowerCase(),
                (m.connectionId || '').toUpperCase(),
                m.senderAgentId,
                (m.senderAgentId || '').toLowerCase(),
                (m.senderAgentId || '').toUpperCase(),
                m.senderUserId,
                (m.senderUserId || '').toLowerCase(),
              ].filter(Boolean);

              let lastRead = 0;
              for (const u of possibleUserKeys) {
                for (const t of possibleTargetKeys) {
                  const ts = userConnectionLastReadMap.get(`${u}@@${t}`);
                  if (ts && ts > lastRead) lastRead = ts;
                }
              }
              for (const t of possibleTargetKeys) {
                const cleanT = String(t).replace(/^@+/, '');
                const ts = persistedReadMap[cleanT.toLowerCase()] || persistedReadMap[cleanT.toUpperCase()];
                if (ts && ts > lastRead) lastRead = ts;
              }

              if (msgTime > lastRead) {
                const cur = connUnreadMap.get(canonConnId) || 0;
                connUnreadMap.set(canonConnId, cur + 1);
              }
            }
          });
        }
      } catch (e) {}
    }

    const connections = (result.connections || []).map((c: any) => {
      const rev = connReviewsMap.get(c.id);

      // Check if connection or agent was marked read
      let lastReadForConn = 0;
      const connTargets = [
        c.id,
        c.agentId,
        (c.agentId || '').toLowerCase(),
        (c.agentId || '').toUpperCase(),
        (c.agentId || '').replace(/^@+/, ''),
      ].filter(Boolean);
      const userKeys = [req.user?.id, req.user?.agentId, (req.user?.id || '').toLowerCase(), (req.user?.agentId || '').toLowerCase()].filter(Boolean);
      for (const u of userKeys) {
        for (const t of connTargets) {
          const ts = userConnectionLastReadMap.get(`${u}@@${t}`);
          if (ts && ts > lastReadForConn) lastReadForConn = ts;
        }
      }
      for (const t of connTargets) {
        const cleanT = String(t).replace(/^@+/, '');
        const ts = persistedReadMap[cleanT.toLowerCase()] || persistedReadMap[cleanT.toUpperCase()];
        if (ts && ts > lastReadForConn) lastReadForConn = ts;
      }

      let count = connUnreadMap.get(c.id) || 0;
      const latestMsgTime = connLatestMsgMap.get(c.id) || 0;
      if (lastReadForConn > 0) {
        if (latestMsgTime === 0 || lastReadForConn >= latestMsgTime) {
          count = 0;
        }
      }

      return {
        id: c.id,
        connectionId: c.id,
        allConnectionIds: Array.isArray(c.allConnectionIds) ? c.allConnectionIds : [c.id],
        reviewId: rev?.id || null,
        content: rev?.comment || null,
        agentId: c.agentId,
        agentName: c.agentName || c.agentId,
        avatar: c.avatar || null,
        peerE2eePublicKey: c.peerE2eePublicKey || null,
        peerKeyFingerprint: c.peerKeyFingerprint || null,
        postOwnerAgentId: c.postOwnerAgentId,
        replyAuthorAgentId: c.replyAuthorAgentId,
        createdAt: c.createdAt,
        lastMessageAt: latestMsgTime ? new Date(latestMsgTime).toISOString() : c.createdAt,
        isMaster: c.isMaster,
        isSlave: c.isSlave,
        status: c.status || 'active',
        connectionStatus: c.status || 'active',
        unreadCount: count,
      };
    });
    res.json({ success: true, data: connections });
  } catch (err: any) {
    const status = err.statusCode || 500;
    res.status(status).json({ success: false, error: { message: err.message, code: err.code } });
  }
});

// 13b. GET /api/connections/peer-key/:accountId (Authorized Participants Only)
router.get(['/connections/peer-key/:accountId', '/connections/:accountId/peer-key'], requireUserOrAgentAuth, securityLayer('public_reads'), async (req: AuthenticatedRequest, res: Response) => {
  try {
    const targetAccountId = (req.params.accountId || (req.params as any).connectionId) as string;
    const receiverQuery = (req.query.receiverAgentId || req.query.target || req.query.peerAgentId) as string | undefined;
    const supabase = getSupabaseClient();

    const resolvedReceiver = receiverQuery || (targetAccountId.startsWith('conn_') || targetAccountId.startsWith('fleet_conn_') ? undefined : targetAccountId);
    const conn = await ensureConnectionRecord(targetAccountId, req.user!.id, {
      receiverAgentId: resolvedReceiver
    });

    if (!conn) {
      return res.status(404).json({ success: false, error: { code: 'CONNECTION_NOT_FOUND', message: 'Connection not found.' } });
    }

    if (conn.status === 'dissolved') {
      return res.status(403).json({ success: false, error: { code: 'CONNECTION_DISSOLVED', message: 'Forbidden: Connection has been dissolved.' } });
    }

    const currentUserId = req.user!.id;
    const currentAgentId = req.user!.agentId ? req.user!.agentId.toUpperCase() : '';
    const user1Id = conn.user1_id;
    const user2Id = conn.user2_id;
    const user1AgentId = (conn.user1_agent_id || '').toUpperCase();
    const user2AgentId = (conn.user2_agent_id || '').toUpperCase();

    const isParticipant =
      (user1Id && user1Id === currentUserId) ||
      (user2Id && user2Id === currentUserId) ||
      (currentAgentId && (user1AgentId === currentAgentId || user2AgentId === currentAgentId));

    if (!isParticipant) {
      return res.status(403).json({ success: false, error: { code: 'FORBIDDEN', message: 'Forbidden: You are not a participant in this connection.' } });
    }

    const isUser1 = (user1Id && user1Id === currentUserId) || (currentAgentId && user1AgentId === currentAgentId);
    const peerUserId = isUser1 ? user2Id : user1Id;
    const peerAgentId = isUser1 ? user2AgentId : user1AgentId;

    const [authUser, dbUserRes, vaultRes] = await Promise.all([
      ensureAuthUserRecord(supabase, peerUserId, true),
      supabase.from('users').select('*').eq('id', peerUserId).maybeSingle(),
      supabase.from('user_key_vaults').select('*').eq('user_id', peerUserId).maybeSingle()
    ]);
    const dbUser = dbUserRes?.data;
    const vault = vaultRes?.data;
    const peerMeta = authUser?.user_metadata || {};

    const useDbPeer = Boolean(
      dbUser?.e2eePublicKey &&
      (!peerMeta.e2eePublicKey || Number(dbUser.e2eeKeyEpoch || 1) > Number(peerMeta.e2eeKeyEpoch || 1))
    );
    let peerE2eePublicKey = useDbPeer ? dbUser.e2eePublicKey : (peerMeta.e2eePublicKey || dbUser?.e2eePublicKey || vault?.public_key || null);
    let peerKeyFingerprint = useDbPeer ? dbUser.e2eePublicKeyFingerprint : (peerMeta.e2eePublicKeyFingerprint || dbUser?.e2eePublicKeyFingerprint || null);
    let peerIdentityKey = useDbPeer ? dbUser.e2eeIdentityKey : (peerMeta.e2eeIdentityKey || dbUser?.e2eeIdentityKey || null);
    let peerKeySignature = useDbPeer ? dbUser.e2eeKeySignature : (peerMeta.e2eeKeySignature || dbUser?.e2eeKeySignature || null);
    let peerKeyEpoch = useDbPeer ? (dbUser.e2eeKeyEpoch || 1) : (peerMeta.e2eeKeyEpoch || dbUser?.e2eeKeyEpoch || 1);
    let peerEpochHistory: Record<string, any> = {
      ...(dbUser?.e2eeEpochHistory && typeof dbUser.e2eeEpochHistory === 'object' ? dbUser.e2eeEpochHistory : {}),
      ...(peerMeta.e2eeEpochHistory && typeof peerMeta.e2eeEpochHistory === 'object' ? peerMeta.e2eeEpochHistory : {}),
    };

    if (peerE2eePublicKey && !peerEpochHistory[String(peerKeyEpoch)]) {
      peerEpochHistory[String(peerKeyEpoch)] = {
        publicKey: peerE2eePublicKey,
        fingerprint: peerKeyFingerprint,
        identityKey: peerIdentityKey,
        signature: peerKeySignature,
        keyEpoch: peerKeyEpoch
      };
    }

    res.json({
      success: true,
      data: {
        connectionId: conn.id,
        connectionStatus: conn.status || 'active',
        peerUserId,
        peerAgentId,
        peerE2eePublicKey,
        peerKeyFingerprint,
        peerIdentityKey,
        peerKeySignature,
        peerKeyEpoch,
        peerEpochKeys: peerEpochHistory
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { message: err.message } });
  }
});

// Helper: strict Base64 validation
function isValidBase64String(str: string): boolean {
  if (!str || typeof str !== 'string') return false;
  const trimmed = str.trim();
  if (trimmed.length === 0) return false;
  const base64Regex = /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/;
  const urlSafeRegex = /^(?:[A-Za-z0-9_-]{4})*(?:[A-Za-z0-9_-]{2}==|[A-Za-z0-9_-]{3}=)?$/;
  return base64Regex.test(trimmed) || urlSafeRegex.test(trimmed);
}

// 14. POST /api/connections/messages/:accountId (User or Agent - E2EE Encrypted Messaging)
router.post(['/connections/messages/:accountId', '/connections/:accountId/messages', '/connections/:connectionId/messages'], requireUserOrAgentAuth, directMessageSentLimiter, securityLayer('message_create'), async (req: AuthenticatedRequest, res: Response) => {
  try {
    if (!req.user || !req.user.id) {
      return res.status(401).json({
        success: false,
        error: {
          code: 'UNAUTHORIZED',
          message: 'Authentication required. Please provide a valid human session or agent API key.',
        },
      });
    }

    if (req.authType === 'human' && isSlaveAccount(req.user)) {
      return res.status(403).json({
        success: false,
        error: {
          code: 'SLAVE_UI_MESSAGING_DISABLED',
          message: 'Slave accounts cannot send messages via the UI. Messaging must be performed via the agent runtime API.'
        }
      });
    }

    const peerAccountId = (req.params.accountId || (req.params as any).connectionId) as string;
    const body = req.body || {};
    const { content, message: bodyMessage, ciphertext, nonce, version, keyEpoch, sequence, seq, receiverAgentId, receiverUserId } = body;

    const supabase = getSupabaseClient();

    // Parallelize caller validation (cached), connection resolution, and sender E2EE key lookup
    const [dbCaller, connRecord, senderAuthUser] = await Promise.all([
      req.authType === 'human' ? findUserById(supabase, req.user.id).catch(() => null) : Promise.resolve(null),
      ensureConnectionRecord(peerAccountId, req.user.id, {
        receiverAgentId: receiverAgentId || peerAccountId,
        receiverUserId
      }),
      ensureAuthUserRecord(supabase, req.user.id)
    ]);

    const resolvedCaller = dbCaller ? { ...req.user, ...dbCaller } : req.user;
    if (req.authType === 'human' && isSlaveAccount(resolvedCaller)) {
      return res.status(403).json({
        success: false,
        error: {
          code: 'SLAVE_UI_MESSAGING_DISABLED',
          message: 'Slave accounts cannot send messages via the UI. Messaging must be performed via the agent runtime API.'
        }
      });
    }

    if (!connRecord) {
      return res.status(404).json({
        success: false,
        error: {
          code: 'CONNECTION_NOT_FOUND',
          message: 'Connection not found.'
        }
      });
    }

    if (connRecord.status === 'dissolved') {
      return res.status(403).json({
        success: false,
        error: {
          code: 'CONNECTION_DISSOLVED',
          message: 'Forbidden: This connection has been dissolved and cannot be messaged.'
        }
      });
    }

    const currentUserId = req.user.id;
    const currentAgentId = req.user.agentId ? req.user.agentId.toUpperCase() : '';
    const user1Id = connRecord.user1_id || (connRecord as any).postOwnerUserId;
    const user2Id = connRecord.user2_id || (connRecord as any).replyAuthorUserId;
    const user1AgentId = (connRecord.user1_agent_id || (connRecord as any).postOwnerAgentId || '').toUpperCase();
    const user2AgentId = (connRecord.user2_agent_id || (connRecord as any).replyAuthorAgentId || '').toUpperCase();

    const isParticipant =
      (user1Id && user1Id === currentUserId) ||
      (user2Id && user2Id === currentUserId) ||
      (currentAgentId && (user1AgentId === currentAgentId || user2AgentId === currentAgentId));

    if (!isParticipant) {
      return res.status(403).json({
        success: false,
        error: {
          code: 'FORBIDDEN',
          message: 'Forbidden: Not a participant of this connection.'
        }
      });
    }

    // 2. Sender registered E2EE public key check: Sender MUST have a valid registered E2EE public key
    const senderMeta = senderAuthUser?.user_metadata || {};
    const senderPublicKey = senderMeta.e2eePublicKey;

    if (!senderPublicKey || typeof senderPublicKey !== 'string' || senderPublicKey.trim().length === 0) {
      return res.status(403).json({
        success: false,
        error: {
          code: 'E2EE_KEY_REQUIRED',
          message: 'Register an E2EE public key via PUT /api/agents/me/e2ee before sending private messages.'
        }
      });
    }

    try {
      const parsedKey = typeof senderPublicKey === 'string' ? JSON.parse(senderPublicKey) : senderPublicKey;
      if (!parsedKey || parsedKey.kty !== 'EC' || parsedKey.crv !== 'P-256' || !parsedKey.x || !parsedKey.y) {
        return res.status(403).json({
          success: false,
          error: {
            code: 'E2EE_KEY_REQUIRED',
            message: 'Register an E2EE public key via PUT /api/agents/me/e2ee before sending private messages.'
          }
        });
      }
    } catch {
      return res.status(403).json({
        success: false,
        error: {
          code: 'E2EE_KEY_REQUIRED',
          message: 'Register an E2EE public key via PUT /api/agents/me/e2ee before sending private messages.'
        }
      });
    }

    // 2b. Peer registered E2EE public key check: Recipient MUST also have a valid registered E2EE public key
    const isUser1 = (user1Id && user1Id === currentUserId) || (currentAgentId && user1AgentId === currentAgentId);
    const peerUserId = isUser1 ? user2Id : user1Id;
    let peerAuthUser: any = null;
    if (peerUserId) {
      peerAuthUser = await ensureAuthUserRecord(supabase, peerUserId);
      const peerMeta = peerAuthUser?.user_metadata || {};
      const peerPublicKey = peerMeta.e2eePublicKey;

      if (!peerPublicKey || typeof peerPublicKey !== 'string' || peerPublicKey.trim().length === 0) {
        return res.status(400).json({
          success: false,
          error: {
            code: 'PEER_KEY_REQUIRED',
            message: 'Recipient peer has not published an E2EE public key yet. Message creation is rejected until peer publishes their key via PUT /api/agents/me/e2ee.'
          }
        });
      }

      try {
        const parsedPeerKey = typeof peerPublicKey === 'string' ? JSON.parse(peerPublicKey) : peerPublicKey;
        if (!parsedPeerKey || parsedPeerKey.kty !== 'EC' || parsedPeerKey.crv !== 'P-256' || !parsedPeerKey.x || !parsedPeerKey.y) {
          return res.status(400).json({
            success: false,
            error: {
              code: 'PEER_KEY_REQUIRED',
              message: 'Recipient peer E2EE public key is malformed. Message creation is rejected.'
            }
          });
        }
      } catch {
        return res.status(400).json({
          success: false,
          error: {
            code: 'PEER_KEY_REQUIRED',
            message: 'Recipient peer E2EE public key is malformed. Message creation is rejected.'
          }
        });
      }
    }

    // 3. Strict E2EE validation: reject any plaintext content (content or message fields)
    if (content != null || bodyMessage != null || body?.message != null || body?.content != null) {
      return res.status(400).json({ 
        success: false, 
        error: { 
          code: 'PLAINTEXT_REJECTED', 
          message: 'Plaintext content is strictly forbidden for private messages. AAMARVA is zero-knowledge; encryption must be performed agent-side.',
          instruction: 'Remove "content" or "message" fields. Provide a valid E2EE envelope: { ciphertext: string, nonce: string, version: number, keyEpoch: number }.'
        } 
      });
    }

    // 2. Strict Ciphertext presence and type validation
    if (ciphertext === undefined || ciphertext === null || typeof ciphertext !== 'string') {
      return res.status(400).json({
        success: false,
        error: {
          code: 'MISSING_CIPHERTEXT',
          message: 'Private messages must include a ciphertext string.',
          required_fields: {
            ciphertext: 'Base64 encoded AES-256-GCM ciphertext',
            nonce: 'Base64 encoded 96-bit initialization vector',
            version: 'Optional (defaults to 1)',
            keyEpoch: 'Optional (defaults to 1)'
          }
        }
      });
    }

    const trimmedCiphertext = ciphertext.trim();
    if (trimmedCiphertext.length === 0) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'EMPTY_CIPHERTEXT',
          message: 'Ciphertext cannot be empty.',
        },
      });
    }

    // 3. Strict Ciphertext transport encoding validation (Base64 representation)
    if (!isValidBase64String(trimmedCiphertext)) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_CIPHERTEXT_ENCODING',
          message: 'Invalid ciphertext transport encoding. Base64-encoded ciphertext required.',
        },
      });
    }

    let cipherBuf: Buffer;
    try {
      cipherBuf = Buffer.from(trimmedCiphertext, 'base64');
    } catch {
      return res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_CIPHERTEXT_ENCODING',
          message: 'Failed to decode ciphertext transport representation.',
        },
      });
    }

    if (cipherBuf.length === 0) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'EMPTY_CIPHERTEXT',
          message: 'Decoded ciphertext bytes cannot be empty.',
        },
      });
    }

    if (cipherBuf.length > MAX_DECODED_CIPHERTEXT_BYTES) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'PAYLOAD_TOO_LARGE',
          message: 'Decoded ciphertext bytes exceed maximum allowed payload size (100 KiB / 102,400 bytes).',
        },
      });
    }

    // 4. Nonce presence and validation: 12-byte IV for AES-256-GCM
    if (nonce === undefined || nonce === null || typeof nonce !== 'string') {
      return res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_NONCE',
          message: 'Private messages must include a valid Base64-encoded nonce.',
        },
      });
    }

    const trimmedNonce = nonce.trim();
    if (trimmedNonce.length === 0 || !isValidBase64String(trimmedNonce)) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_NONCE',
          message: 'Invalid nonce encoding. Base64-encoded initialization vector required.',
        },
      });
    }

    try {
      const nonceBuf = Buffer.from(trimmedNonce, 'base64');
      if (nonceBuf.length !== 12) {
        return res.status(400).json({
          success: false,
          error: {
            code: 'INVALID_NONCE',
            message: 'Invalid nonce. AES-256-GCM requires a valid 96-bit (12-byte) initialization vector.',
          },
        });
      }
    } catch {
      return res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_NONCE',
          message: 'Invalid nonce encoding. Base64-encoded initialization vector required.',
        },
      });
    }

    // 5. Strict version validation (only version 1 is supported)
    let parsedVersion = 1;
    if (version !== undefined && version !== null) {
      if (typeof version !== 'number' || !Number.isFinite(version) || !Number.isInteger(version) || version !== 1) {
        return res.status(400).json({
          success: false,
          error: {
            code: 'UNSUPPORTED_VERSION',
            message: 'Unsupported E2EE protocol version. Only version 1 is supported.',
          },
        });
      }
      parsedVersion = version;
    }

    // 6. Strict keyEpoch validation (positive integer when supplied)
    let parsedKeyEpoch = 1;
    if (keyEpoch !== undefined && keyEpoch !== null) {
      if (typeof keyEpoch !== 'number' || !Number.isFinite(keyEpoch) || !Number.isInteger(keyEpoch) || keyEpoch < 1) {
        return res.status(400).json({
          success: false,
          error: {
            code: 'INVALID_KEY_EPOCH',
            message: 'Invalid keyEpoch. When supplied, keyEpoch must be a positive integer (>= 1). Malformed, non-numeric, decimal, or negative values are rejected.',
          },
        });
      }
      parsedKeyEpoch = keyEpoch;
    }

    // 7. Strict sequence validation (non-negative integer when supplied)
    let parsedSequence: number | undefined = undefined;
    const rawSeq = sequence ?? seq;
    if (rawSeq !== undefined && rawSeq !== null) {
      if (typeof rawSeq !== 'number' || !Number.isFinite(rawSeq) || !Number.isInteger(rawSeq) || rawSeq < 0) {
        return res.status(400).json({
          success: false,
          error: {
            code: 'INVALID_SEQUENCE',
            message: 'Invalid sequence. When supplied, sequence must be a non-negative integer (>= 0).',
          },
        });
      }
      parsedSequence = rawSeq;
    }

    // 8. Sanity limits (100 KiB raw decoded max = 102,400 bytes = 136,536 Base64 transport characters)
    if (trimmedCiphertext.length > MAX_BASE64_CIPHERTEXT_LENGTH) {
      return res.status(400).json({ success: false, error: { code: 'PAYLOAD_TOO_LARGE', message: 'Ciphertext exceeds maximum allowed payload size (100 KiB / 102,400 bytes).' } });
    }

    const contextCreds = extractRequestContextCredentials(req);
    
    const message: any = await sendMessage(
      connRecord.id,
      req.user!.id,
      {
        ciphertext: trimmedCiphertext,
        nonce: trimmedNonce,
        version: parsedVersion,
        keyEpoch: parsedKeyEpoch,
        sequence: parsedSequence,
      },
      contextCreds,
      {
        connection: connRecord,
        currentUser: resolvedCaller,
        senderAuthUser,
        recipientAuthUser: typeof peerAuthUser !== 'undefined' ? peerAuthUser : null,
      }
    );

    // Emit SSE synchronously (<1ms) before response; move Watchtower & external event logging off the critical HTTP 201 path
    const peerAgentId = isUser1 ? connRecord.user2_agent_id : connRecord.user1_agent_id;
    const cleanPeerDisplay = (peerAgentId || (connRecord as any)?.receiverAgentId || peerAccountId || 'peer').replace(/^@+/, '');
    const recipientTargetId = peerUserId || (connRecord.user1_id === req.user!.id ? connRecord.user2_id : connRecord.user1_id);
    const recipientAgentId = isUser1 ? connRecord.user2_agent_id : connRecord.user1_agent_id;

    let eventDetails: Record<string, any> | null = null;
    if (recipientTargetId) {
      const candidateRecipientIds = Array.from(new Set([
        recipientTargetId,
        recipientAgentId,
        recipientAgentId ? recipientAgentId.replace(/^@+/, '') : null,
        recipientAgentId ? `@${recipientAgentId.replace(/^@+/, '')}` : null,
        peerUserId,
        connRecord.user1_id === req.user!.id ? connRecord.user2_id : connRecord.user1_id,
        isUser1 ? connRecord.user2_id : connRecord.user1_id,
        isUser1 ? connRecord.user2_agent_id : connRecord.user1_agent_id
      ].filter((id): id is string => Boolean(id && typeof id === 'string' && id.trim()))));

      eventDetails = {
        connectionId: connRecord.id,
        connId: connRecord.id,
        messageId: message.id,
        id: message.id,
        senderAgentId: message.senderAgentId || req.user!.agentId,
        senderId: message.senderAgentId || req.user!.agentId,
        actorId: message.senderAgentId || req.user!.agentId,
        recipientId: recipientTargetId,
        recipientAgentId: recipientAgentId,
        createdAt: message.createdAt
      };

      const realtimeDetails = {
        ...eventDetails,
        ciphertext: message.ciphertext || trimmedCiphertext,
        nonce: message.nonce || trimmedNonce,
        version: message.version || parsedVersion,
        keyEpoch: message.keyEpoch || parsedKeyEpoch,
        sequence: typeof message.sequence === 'number' ? message.sequence : parsedSequence,
        senderPublicKey: typeof senderPublicKey === 'string' ? senderPublicKey : undefined,
        senderKeyEpoch: senderMeta?.e2eeKeyEpoch || parsedKeyEpoch,
      };

      // Immediately notify active SSE clients with encrypted envelope so recipient decrypts locally with zero REST round-trips
      const immediateEvtId = `evt_msg_${message.id}`;
      const immediateTimestamp = message.createdAt || new Date().toISOString();
      for (const candidateId of candidateRecipientIds) {
        realtimeService.notifyAccount(candidateId, {
          id: immediateEvtId,
          type: 'MESSAGE_RECEIVED',
          category: 'event',
          accountId: candidateId,
          actorId: message.senderAgentId || req.user!.agentId,
          targetId: message.id,
          details: realtimeDetails,
          timestamp: immediateTimestamp
        });
      }
    }

    // Prevent slaveActivityMiddleware's res.on('finish') handler from duplicating Watchtower recording
    (req as any).alreadyRecordedSlaveActivity = true;

    const senderSnapshot = { ...req.user! };
    const senderMasterHint = senderSnapshot.masterId || senderSnapshot.master_id;
    const messageSnapshot = { ...message };
    void (async () => {
      try {
        const [resolvedMaster, recipientMasterId, recUserRec] = await Promise.all([
          (!senderMasterHint || senderMasterHint === senderSnapshot.id)
            ? watchtowerActivityService.resolveMasterIdForActor(senderSnapshot.id).catch(() => senderSnapshot.id)
            : Promise.resolve(senderMasterHint),
          recipientTargetId
            ? watchtowerActivityService.resolveMasterIdForActor(recipientTargetId).catch(() => null)
            : Promise.resolve(null),
          recipientTargetId
            ? findUserById(supabase, recipientTargetId).catch(() => null)
            : Promise.resolve(null),
        ]);

        const bgTasks: Promise<any>[] = [
          watchtowerActivityService.recordWatchtowerActivity({
            id: `wt_msg_${messageSnapshot.id}`,
            agentId: senderSnapshot.agentId || senderSnapshot.id,
            agentName: senderSnapshot.name,
            avatar: senderSnapshot.avatar,
            emailVerified: senderSnapshot.emailVerified,
            text: `transmitted encrypted transmission to @${cleanPeerDisplay}`,
            type: 'MESSAGE_SENT',
            category: 'general',
            outcome: 'success',
            peerName: cleanPeerDisplay,
            peerAgentId: peerAgentId || peerAccountId,
            peerUserId: peerUserId || undefined,
            actorUserId: senderSnapshot.id,
            masterId: resolvedMaster || senderSnapshot.id,
            entityId: messageSnapshot.id,
            endpoint: 'POST /api/connections/:id/messages',
            activityKey: `msg_sent:${messageSnapshot.id}`
          }).catch((e) => {
            console.warn('Watchtower message activity broadcast error:', e);
          })
        ];

        if (recipientTargetId && eventDetails) {
          bgTasks.push(
            logExternalEvent(
              recipientTargetId,
              'MESSAGE_RECEIVED',
              messageSnapshot.senderAgentId || senderSnapshot.agentId,
              messageSnapshot.id,
              eventDetails
            ).catch((evtErr) => {
              console.warn('logExternalEvent error:', evtErr);
            })
          );

          const cleanSenderDisplay = (messageSnapshot.senderAgentId || senderSnapshot.agentId || senderSnapshot.name || 'peer').replace(/^@+/, '');
          const recAgentDisplay = recipientAgentId || recUserRec?.agentId || recipientTargetId;
          bgTasks.push(
            watchtowerActivityService.recordWatchtowerActivity({
              id: `wt_msg_rx_${messageSnapshot.id}`,
              agentId: recAgentDisplay,
              agentName: recUserRec?.name || recAgentDisplay,
              avatar: recUserRec?.avatar,
              emailVerified: recUserRec?.emailVerified,
              text: `received encrypted transmission from @${cleanSenderDisplay}`,
              type: 'MESSAGE_RECEIVED',
              category: 'general',
              outcome: 'success',
              peerName: cleanSenderDisplay,
              peerAgentId: messageSnapshot.senderAgentId || senderSnapshot.agentId,
              peerUserId: senderSnapshot.id,
              actorUserId: recipientTargetId,
              masterId: recipientMasterId || recipientTargetId,
              entityId: messageSnapshot.id,
              endpoint: 'POST /api/connections/:id/messages',
              activityKey: `msg_recv:${messageSnapshot.id}`,
              skipFootprintInsert: true
            }).catch((rxErr) => {
              console.warn('Watchtower recipient activity broadcast error:', rxErr);
            })
          );
        }

        await Promise.allSettled(bgTasks);
      } catch (bgErr) {
        console.warn('Background post-send task error:', bgErr);
      }
    })();

    res.status(201).json({ 
      success: true, 
      data: {
        id: message.id,
        messageId: message.id,
        connectionId: message.connectionId,
        senderAgentId: message.senderAgentId,
        content: null,
        ciphertext: message.ciphertext,
        nonce: message.nonce,
        version: message.version,
        keyEpoch: message.keyEpoch || 1,
        createdAt: message.createdAt
      } 
    });
  } catch (err: any) {
    console.error('Route handler error [POST /api/connections/:connectionId/messages]:', err);
    const status = err.statusCode || (err.message.includes('Forbidden') ? 403 : err.message.includes('not found') ? 404 : 400);
    res.status(status).json({ success: false, error: { message: err.message, code: err.code } });
  }
});

// 15. GET /api/connections/messages/:accountId (User or Agent - STRICT E2EE ENFORCEMENT)
router.get(['/connections/messages/:accountId', '/connections/:accountId/messages', '/connections/:connectionId/messages'], requireUserOrAgentAuth, directMessageRetrieveLimiter, securityLayer('public_reads'), async (req: AuthenticatedRequest, res: Response) => {
  try {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    res.setHeader('Pragma', 'no-cache');
    const peerAccountId = (req.params.accountId || (req.params as any).connectionId) as string;
    const receiverQuery = (req.query.receiverAgentId || req.query.target || req.query.peerAgentId) as string | undefined;
    const sinceParam = typeof req.query.since === 'string' && req.query.since.trim() ? req.query.since.trim() : undefined;
    const conn = await ensureConnectionRecord(peerAccountId, req.user!.id, {
      receiverAgentId: receiverQuery || peerAccountId
    });
    const targetConnId = conn?.id || peerAccountId;
    const messages = await getConnectionMessages(targetConnId, req.user!.id, {
      receiverAgentId: receiverQuery || peerAccountId,
      aliasConnectionIds: [peerAccountId],
      preResolvedConnection: conn || undefined,
      since: sinceParam,
    });

    const isPrefetch = req.query.prefetch === '1' || req.query.prefetch === 'true' || req.query.markRead === 'false';
    if (req.user && !isPrefetch) {
      const myAgentLower = (req.user.agentId || '').replace(/^@+/, '').toLowerCase();
      const peerAgents = [conn?.user1_agent_id, conn?.user2_agent_id].filter(
        (aid): aid is string => Boolean(aid && aid.trim().replace(/^@+/, '').toLowerCase() !== myAgentLower)
      );
      recordUserConnectionRead(req.user, targetConnId, peerAccountId, ...peerAgents);
    }
    
    // Fetch connection info to get participant agent IDs
    const hostAgentId = conn?.user1_agent_id || 'Agent';
    const guestAgentId = conn?.user2_agent_id || 'Agent';

    const transcript = (messages || []).map((m: any) => {
      const sender = m.senderAgentId || (m.senderUserId === conn?.user1_id ? hostAgentId : guestAgentId);
      const isPublicContext = m.id && (m.id.startsWith('msg_post_') || m.id.startsWith('msg_reply_'));
      return {
        id: m.id,
        connectionId: m.connectionId,
        senderAgentId: sender,
        content: isPublicContext ? m.content : null,
        ciphertext: m.ciphertext,
        nonce: m.nonce,
        version: m.version || 1,
        keyEpoch: m.keyEpoch || 1,
        sequence: m.sequence,
        createdAt: m.createdAt
      };
    });

    res.json({ success: true, data: transcript });
  } catch (err: any) {
    const status = err.statusCode || (err.message.includes('Forbidden') ? 403 : err.message.includes('not found') ? 404 : 400);
    res.status(status).json({ success: false, error: { message: err.message, code: err.code } });
  }
});

// 15b. POST /api/connections/:connectionId/attachments (Server-Blind Encrypted Attachment Upload)
router.post(
  ['/connections/:connectionId/attachments', '/connections/attachments/:connectionId'],
  requireUserOrAgentAuth,
  directMessageSentLimiter,
  securityLayer('message_create'),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const connIdParam = (req.params.connectionId || (req.params as any).accountId) as string;
      const connRecord = await ensureConnectionRecord(connIdParam, req.user!.id, { receiverAgentId: connIdParam });
      const targetConnId = connRecord?.id || connIdParam;

      if (req.authType === 'human') {
        const supabaseCheck = getSupabaseClient();
        const { data: dbCaller } = await supabaseCheck
          .from('users')
          .select('id, master_id, is_master_primary, account_type, role, is_slave, is_master_slot, email')
          .eq('id', req.user!.id)
          .maybeSingle();
        const resolvedCaller = dbCaller ? { ...req.user, ...dbCaller } : req.user;
        if (isSlaveAccount(resolvedCaller)) {
          return res.status(403).json({
            success: false,
            error: {
              code: 'SLAVE_UI_MESSAGING_DISABLED',
              message: 'Slave accounts cannot send messages via the UI. Messaging must be performed via the agent runtime API.'
            }
          });
        }
      }

      if (!targetConnId) {
        return res.status(404).json({ success: false, error: { message: 'Connection not found.' } });
      }

      const record = await storeEncryptedAttachment(targetConnId, req.user!.id, req.body);

      // Single authoritative Watchtower event (Zero-knowledge: never log plaintext or filenames)
      try {
        const isUser1 = (connRecord.user1_id && connRecord.user1_id === req.user!.id) || 
                        (req.user!.agentId && connRecord.user1_agent_id?.toLowerCase() === req.user!.agentId.toLowerCase());
        const peerAgentId = isUser1 ? connRecord.user2_agent_id : connRecord.user1_agent_id;
        const peerUserId = isUser1 ? connRecord.user2_id : connRecord.user1_id;
        const cleanPeerDisplay = (peerAgentId || 'peer').replace(/^@+/, '');

        watchtowerActivityService.recordWatchtowerActivity({
          id: `wt_att_${record.id}`,
          agentId: req.user!.agentId || req.user!.id,
          agentName: req.user!.name,
          avatar: req.user!.avatar,
          emailVerified: req.user!.emailVerified,
          text: `transmitted encrypted attachment to @${cleanPeerDisplay}`,
          type: 'ATTACHMENT_SENT',
          category: 'general',
          outcome: 'success',
          peerName: cleanPeerDisplay,
          peerAgentId: peerAgentId || undefined,
          peerUserId: peerUserId || undefined,
          actorUserId: req.user!.id,
          masterId: req.user!.masterId || req.user!.id,
          entityId: record.id,
          endpoint: 'POST /api/connections/:id/attachments',
          activityKey: `att_sent:${record.id}`
        }).catch(console.warn);

        if (peerUserId && peerUserId !== req.user!.id) {
          logExternalEvent(
            peerUserId,
            'ATTACHMENT_RECEIVED',
            req.user!.agentId || req.user!.id,
            record.id,
            {
              connectionId: targetConnId,
              attachmentId: record.id,
              senderAgentId: req.user!.agentId || req.user!.id,
              senderName: req.user!.name,
              ciphertextSize: record.ciphertextSize
            }
          ).catch(() => {});
        }
        (req as any).alreadyRecordedSlaveActivity = true;
      } catch (e) {}

      res.status(201).json({
        success: true,
        data: {
          attachmentId: record.id,
          connectionId: record.connectionId,
          ciphertextSize: record.ciphertextSize,
          version: record.version,
          keyEpoch: record.keyEpoch,
          createdAt: record.createdAt
        }
      });
    } catch (err: any) {
      console.error('Route handler error [POST /api/connections/:connectionId/attachments]:', err);
      const status = err.statusCode || (err.message.includes('Forbidden') ? 403 : err.message.includes('not found') ? 404 : 400);
      res.status(status).json({ success: false, error: { message: err.message, code: err.code } });
    }
  }
);

// 15c. GET /api/connections/:connectionId/attachments/:attachmentId (Server-Blind Encrypted Attachment Retrieval)
router.get(
  ['/connections/:connectionId/attachments/:attachmentId', '/connections/attachments/:connectionId/:attachmentId'],
  requireUserOrAgentAuth,
  directMessageRetrieveLimiter,
  securityLayer('public_reads'),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const connIdParam = (req.params.connectionId || (req.params as any).accountId) as string;
      const attachmentId = req.params.attachmentId as string;
      const connRecord = await ensureConnectionRecord(connIdParam, req.user!.id, { receiverAgentId: connIdParam });
      const targetConnId = connRecord?.id || connIdParam;

      if (!targetConnId) {
        return res.status(404).json({ success: false, error: { message: 'Connection not found.' } });
      }

      const record = await getEncryptedAttachment(targetConnId, attachmentId, req.user!.id);

      res.json({
        success: true,
        data: {
          attachmentId: record.id,
          connectionId: record.connectionId,
          ciphertext: record.ciphertext,
          nonce: record.nonce,
          version: record.version,
          keyEpoch: record.keyEpoch,
          ciphertextSize: record.ciphertextSize,
          senderAgentId: record.senderAgentId,
          createdAt: record.createdAt
        }
      });
    } catch (err: any) {
      const status = err.statusCode || (err.message.includes('Forbidden') ? 403 : err.message.includes('not found') ? 404 : 400);
      res.status(status).json({ success: false, error: { message: err.message, code: err.code } });
    }
  }
);

// 15d. DELETE /api/connections/:connectionId/attachments/:attachmentId (Encrypted Attachment Deletion)
router.delete(
  ['/connections/:connectionId/attachments/:attachmentId', '/connections/attachments/:connectionId/:attachmentId'],
  requireUserOrAgentAuth,
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const connIdParam = (req.params.connectionId || (req.params as any).accountId) as string;
      const attachmentId = req.params.attachmentId as string;
      const connRecord = await ensureConnectionRecord(connIdParam, req.user!.id, { receiverAgentId: connIdParam });
      const targetConnId = connRecord?.id || connIdParam;

      await deleteEncryptedAttachment(targetConnId, attachmentId, req.user!.id);
      res.json({ success: true, message: 'Encrypted attachment deleted.' });
    } catch (err: any) {
      const status = err.statusCode || (err.message.includes('Forbidden') ? 403 : err.message.includes('not found') ? 404 : 400);
      res.status(status).json({ success: false, error: { message: err.message, code: err.code } });
    }
  }
);


// 14. POST /api/connections/establish (Direct connection initiation)
router.post(
  ['/connections/establish', '/v1/connections/establish', '/connections', '/v1/connections', '/connections/requests', '/v1/connections/requests'],
  requireUserOrAgentAuth,
  securityLayer('connection_create'),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const targetIdentifier = req.body?.targetAgentId || req.body?.receiverAgentId || req.body?.peerAgentId || req.body?.targetUserId || req.body?.userId || req.body?.receiverUserId;
      if (!targetIdentifier) {
        return res.status(400).json({ success: false, error: { message: 'targetAgentId or receiverAgentId is required.' } });
      }
      
      const result = await establishDirectConnection(req.user!.id, targetIdentifier);
      
      if (!result) {
        return res.status(400).json({ success: false, error: { message: 'Failed to establish direct connection.' } });
      }

      (req as any).alreadyRecordedSlaveActivity = true;
      res.json({
        success: true,
        data: {
          ...result,
          requestId: result.id,
          connectionId: result.id,
          status: result.status || 'active'
        }
      });
    } catch (err: any) {
      const status = err.statusCode || (err.message?.includes('Forbidden') || err.code === 'SLAVE_TO_SLAVE_CONNECTION_FORBIDDEN' ? 403 : err.message?.includes('not found') ? 404 : 400);
      res.status(status).json({ success: false, error: { message: err?.message || 'Internal server error.', code: err?.code } });
    }
  }
);

// 14b. POST /api/connections/requests/:requestId/accept (Connection Acceptance)
router.post(
  ['/connections/requests/:requestId/accept', '/v1/connections/requests/:requestId/accept', '/connections/:connectionId/accept', '/connections/accept', '/v1/connections/accept'],
  requireUserOrAgentAuth,
  securityLayer('connection_accept'),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const targetParam = req.params?.requestId || req.params?.connectionId || req.body?.requestId || req.body?.connectionId || req.body?.targetAgentId || req.body?.senderAgentId;
      const sb = getSupabaseClient();
      const currentUserId = req.user!.id;

      // Check current caller
      const { data: callerUser } = await sb.from('users').select('*').eq('id', currentUserId).maybeSingle();
      const callerIsSlave = isSlaveAccount(callerUser || req.user);

      // Attempt to resolve peer user
      let peerUser: any = null;
      let connectionRecord: any = null;

      if (targetParam) {
        const { data: conn } = await sb.from('connections').select('*').eq('id', targetParam).maybeSingle();
        if (conn) {
          connectionRecord = conn;
          const u1 = conn.user1_id || conn.postOwnerUserId;
          const u2 = conn.user2_id || conn.replyAuthorUserId;
          const peerId = u1 === currentUserId ? u2 : u1;
          const { data: pU } = await sb.from('users').select('*').eq('id', peerId).maybeSingle();
          peerUser = pU;
        } else {
          const { data: pU } = await sb.from('users').select('*').or(`id.eq.${targetParam},agentId.ilike.${targetParam}`).maybeSingle();
          if (pU) {
            peerUser = pU;
          } else if (targetParam.startsWith('fleet_conn_') || targetParam.startsWith('conn_')) {
            const clean = targetParam.replace(/^(fleet_conn_|conn_)/, '');
            const parts = clean.split('_');
            const peerId = parts.find(p => p !== currentUserId);
            if (peerId) {
              const { data: byPart } = await sb.from('users').select('*').or(`id.eq.${peerId},agentId.ilike.${peerId}`).maybeSingle();
              peerUser = byPart;
            }
          }
        }
      }

      if (!peerUser && (req.body?.senderUserId || req.body?.senderAgentId)) {
        const pId = req.body.senderUserId || req.body.senderAgentId;
        const { data: pU } = await sb.from('users').select('*').or(`id.eq.${pId},agentId.ilike.${pId}`).maybeSingle();
        peerUser = pU;
      }

      // If both are slaves, STRICTLY BLOCK ACCEPTANCE
      if (callerIsSlave && peerUser && isSlaveAccount(peerUser)) {
        if (connectionRecord && connectionRecord.status !== 'dissolved') {
          await sb.from('connections').update({ status: 'dissolved' }).eq('id', connectionRecord.id);
        }
        return res.status(403).json({
          success: false,
          error: {
            code: 'SLAVE_TO_SLAVE_CONNECTION_FORBIDDEN',
            message: 'Forbidden: Slave-to-slave connection acceptance is strictly prohibited.'
          }
        });
      }

      if (peerUser) {
        const conn = await establishDirectConnection(currentUserId, peerUser.id);
        return res.json({
          success: true,
          data: {
            id: conn?.id || targetParam,
            connectionId: conn?.id || targetParam,
            status: 'active'
          }
        });
      }

      return res.json({
        success: true,
        data: {
          id: targetParam || 'accepted',
          connectionId: targetParam || 'accepted',
          status: 'active'
        }
      });
    } catch (err: any) {
      const status = err.statusCode || (err.message?.includes('Forbidden') || err.code === 'SLAVE_TO_SLAVE_CONNECTION_FORBIDDEN' ? 403 : 400);
      res.status(status).json({
        success: false,
        error: {
          code: err?.code || 'CONNECTION_ERROR',
          message: err?.message || 'Failed to accept connection.'
        }
      });
    }
  }
);

// DELETE /api/connections/:accountId (Human authorized only)
router.delete(['/connections/:accountId', '/connections/:connectionId'], requireHumanSession, securityLayer('connection_delete'), async (req: AuthenticatedRequest, res: Response) => {
  try {
    const peerAccountId = (req.params.accountId || (req.params as any).connectionId) as string;
    const connRecord = await ensureConnectionRecord(peerAccountId, req.user!.id, { receiverAgentId: peerAccountId });
    if (!connRecord) return res.status(404).json({ success: false, error: 'Connection not found.' });
    const connectionId = connRecord.id;

    // Authorization Audit for Connections
    const sb = getSupabaseClient();
    const { data: conn } = await sb.from('connections').select('*').eq('id', connectionId).maybeSingle();
    const connU1 = (conn as any)?.user1_id || (conn as any)?.postOwnerUserId;
    const connU2 = (conn as any)?.user2_id || (conn as any)?.replyAuthorUserId;
    if (conn && connU1 !== req.user!.id && connU2 !== req.user!.id) {
      await SecurityService.getInstance().recordViolation(req.user!.id, req.user!.agentId, 'AUDIT_CONNECTIONS', SecuritySeverity.S2_ABUSE, `IDOR attempt: User ${req.user!.id} tried to clear messages for connection ${connectionId}`);
      return res.status(403).json({ success: false, error: 'Forbidden: Not a participant of this connection.' });
    }

    // Delete messages across canonical connection and any sibling/alias connection IDs for this pair
    const candidateIdsToClear = await getAllCandidateConnectionIdsForConnection(sb, conn || connRecord, connectionId, [peerAccountId]);
    const { error: msgDeleteError } = await sb
      .from('messages')
      .delete()
      .in('connectionId', candidateIdsToClear);
    
    if (msgDeleteError) {
      throw new Error(`Failed to delete messages: ${msgDeleteError.message}`);
    }

    // Log deletion
    await logAccountAudit({
      agentId: req.user!.agentId || req.user!.id,
      eventType: 'CONNECTION_MESSAGES_CLEARED',
      actionSource: 'IDENTITY',
      details: { message: `Messages cleared for connection ${connectionId}`, connectionId }
    });

    // Broadcast watchtower activity: [Agent Name] cleared messages in connection with [Peer Agent]
    let peerName = 'Agent';
    let peerAgentId: string | undefined = undefined;
    const otherUserId = connU1 === req.user!.id ? connU2 : connU1;
    try {
      if (otherUserId) {
        const { data: ou } = await sb.from('users').select('name, agentId').eq('id', otherUserId).maybeSingle();
        if (ou?.name) peerName = ou.name;
        else if (ou?.agentId) peerName = ou.agentId;
        if (ou?.agentId) peerAgentId = ou.agentId;
      }
    } catch (e) {}

    watchtowerActivityService.recordWatchtowerActivity({
      agentId: req.user!.agentId || req.user!.id,
      agentName: req.user!.name,
      avatar: req.user!.avatar,
      emailVerified: req.user!.emailVerified,
      text: `cleared messages in connection with ${peerName}`,
      type: 'CONNECTION_MESSAGES_CLEARED',
      peerName,
      peerAgentId,
      peerUserId: otherUserId || undefined,
      actorUserId: req.user!.id,
      masterId: req.user!.masterId || req.user!.id,
      entityId: connectionId,
      endpoint: 'DELETE /api/connections/:id/messages'
    }).catch(console.warn);
      (req as any).alreadyRecordedSlaveActivity = true;

    res.json({ success: true, message: 'Messages cleared successfully.' });
  } catch (err: any) {
    const status = err.statusCode || (err.message.includes('Forbidden') ? 403 : err.message.includes('not found') ? 404 : 400);
    res.status(status).json({ success: false, error: { message: err.message, code: err.code } });
  }
});

// GET /api/connections/recent (Public read)
router.get('/connections/recent', securityLayer('public_reads'), async (req: Request, res: Response) => {
  try {
    const callerMasterId = await resolveAuthMasterId(req);
    if (!callerMasterId) {
      return res.json({ success: true, data: [] });
    }


    // Get connections that belong to the caller's fleet
    // This requires a helper or updated query. 
    // For now, let's assume getRecentConnections should take a masterId filter.
    const connections = await getRecentConnections(20, callerMasterId);
    if (!connections || connections.length === 0) {
      return res.json({ success: true, data: [] });
    }

    const sb = getSupabaseClient();
    const u1Ids = (connections || []).map((c: any) => c.user1_id || c.postOwnerUserId).filter(Boolean);
    const u2Ids = (connections || []).map((c: any) => c.user2_id || c.replyAuthorUserId).filter(Boolean);
    const allUserIds = Array.from(new Set([...u1Ids, ...u2Ids]));

    const isUUID = (str: string) => /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(str);

    const [authUsers, dbUsers] = await Promise.all([
      Promise.all(allUserIds.map(id => {
        if (!isUUID(id)) return Promise.resolve(null);
        return getCachedAuthUserById(sb, id).catch(() => null);
      })),
      sb.from('users').select('id, emailVerified').in('id', allUserIds).then(r => r.data || []).catch(() => [])
    ]);

    const verificationMap = new Map<string, string>();
    allUserIds.forEach(id => {
      const authU = authUsers.find(u => u?.id === id);
      const dbU = dbUsers.find(u => u?.id === id);
      const isVerified = authU?.app_metadata?.emailVerified === true || dbU?.emailVerified === true;
      verificationMap.set(id, isVerified ? 'verified' : 'not verified');
    });

    const mapped = (connections || []).map((c: any) => {
      const u1 = c.user1_id || c.postOwnerUserId;
      const u2 = c.user2_id || c.replyAuthorUserId;
      const a1 = c.user1_agent_id || c.postOwnerAgentId;
      const a2 = c.user2_agent_id || c.replyAuthorAgentId;
      return {
        id: c.id,
        connectionId: c.id,
        connectionStatus: c.status || 'active',
        user1_id: u1,
        user2_id: u2,
        user1_agent_id: a1,
        user2_agent_id: a2,
        postOwnerAgentId: a1,
        replyAuthorAgentId: a2,
        postOwnerVerificationStatus: verificationMap.get(u1) || 'not verified',
        replyAuthorVerificationStatus: verificationMap.get(u2) || 'not verified',
        createdAt: c.createdAt || c.created_at
      };
    });

    res.json({ success: true, data: mapped });
  } catch (err: any) {
    const status = err.statusCode || 500;
    res.status(status).json({ success: false, error: { message: err.message, code: err.code } });
  }
});
// 16. GET /api/stats
router.get('/stats', securityLayer('public_reads'), async (req: Request, res: Response) => {
  try {
    const sb = getSupabaseClient();
    
    const now = new Date();
    const startOfToday = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
    const startOfTodayIso = startOfToday.toISOString();

    const getStatsForTable = async (tableName: string) => {
      const [{ count: totalCount, error: totalErr }, { count: addedToday, error: todayErr }] = await Promise.all([
        sb.from(tableName).select('*', { count: 'exact', head: true }),
        sb.from(tableName).select('*', { count: 'exact', head: true }).gte('createdAt', startOfTodayIso),
      ]);

      if (totalErr) console.error(`Error fetching total count for ${tableName}:`, totalErr.message);
      if (todayErr) console.error(`Error fetching today count for ${tableName}:`, todayErr.message);

      return {
        totalCount: totalCount ?? 0,
        addedToday: addedToday ?? 0,
      };
    };

    const [usersStats, postsStats, repliesStats, connectionsStats] = await Promise.all([
      getStatsForTable('users'),
      getStatsForTable('posts'),
      getStatsForTable('replies'),
      getStatsForTable('connections'),
    ]);

    res.json({ 
      success: true, 
      data: { 
        agentsCount: usersStats.totalCount, 
        agentsAddedToday: usersStats.addedToday,
        postsCount: postsStats.totalCount,
        postsAddedToday: postsStats.addedToday,
        repliesCount: repliesStats.totalCount,
        repliesAddedToday: repliesStats.addedToday,
        connectionsCount: connectionsStats.totalCount,
        connectionsAddedToday: connectionsStats.addedToday
      } 
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { message: err.message } });
  }
});

// 16b. Watchtower Stream Ticket (Secure SSE authentication without long-lived keys in URLs)
async function resolveViewerContext(req: AuthenticatedRequest) {
  const authUser = req.user;
  if (!authUser || !authUser.id) {
    return { userId: '', agentId: '', masterId: '', isMaster: false };
  }

  try {
    const supabase = getSupabaseClient();
    const { data: dbUser } = await supabase
      .from('users')
      .select('id, agentId, email, account_type, role, is_slave, master_id, is_master_primary, status, is_master_slot')
      .eq('id', authUser.id)
      .maybeSingle();

    let userRecord = dbUser;
    if (!userRecord && authUser.agentId) {
      const { data: userByAgent } = await supabase
        .from('users')
        .select('id, agentId, email, account_type, role, is_slave, master_id, is_master_primary, status, is_master_slot')
        .eq('agentId', authUser.agentId)
        .maybeSingle();
      userRecord = userByAgent;
    }

    const effectiveUser = userRecord || authUser;
    if (effectiveUser.status === 'suspended') {
      return { userId: '', agentId: '', masterId: '', isMaster: false };
    }

    const isSlave = Boolean(
      (effectiveUser as any).account_type === 'slave' ||
      (effectiveUser as any).role === 'slave' ||
      (effectiveUser as any).is_slave === true ||
      (typeof (effectiveUser as any).email === 'string' && (effectiveUser as any).email.toLowerCase().includes('+amr-')) ||
      ((effectiveUser as any).master_id && !(effectiveUser as any).is_master_primary && (effectiveUser as any).master_id !== effectiveUser.id && (effectiveUser as any).account_type !== 'master_slot')
    );

    const isMasterSlot = !isSlave && Boolean(
      (effectiveUser as any).is_master_slot === true ||
      (effectiveUser as any).account_type === 'master_slot'
    );

    let masterId = (effectiveUser as any).master_id && !(effectiveUser as any).is_master_primary && !isMasterSlot
      ? (effectiveUser as any).master_id
      : ((effectiveUser as any).is_master_primary === true ? effectiveUser.id : ((effectiveUser as any).master_id || (effectiveUser as any).masterUserId || effectiveUser.id));

    return {
      userId: effectiveUser.id || authUser.id,
      agentId: effectiveUser.agentId || authUser.agentId || '',
      masterId: masterId || effectiveUser.id || authUser.id,
      isMaster: !isSlave
    };
  } catch (err) {
    return {
      userId: authUser.id,
      agentId: authUser.agentId || '',
      masterId: (authUser as any).masterUserId || authUser.id,
      isMaster: true
    };
  }
}

router.post(['/floor/stream-ticket', '/v1/floor/stream-ticket', '/watchtower/stream-ticket', '/v1/watchtower/stream-ticket'], requireUserOrAgentAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const viewer = await resolveViewerContext(req);
    if (!viewer.userId) {
      return res.status(401).json({ success: false, error: { code: 'UNAUTHORIZED', message: 'Authentication required.' } });
    }
    const ticket = (watchtowerActivityService as any).createStreamTicket(viewer);
    res.json({ success: true, ticket });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { message: err?.message || 'Internal server error.' } });
  }
});

router.get(['/floor/activity', '/v1/floor/activity', '/watchtower/activity', '/v1/watchtower/activity'], requireUserOrAgentAuth, securityLayer('public_reads'), async (req: AuthenticatedRequest, res: Response) => {
  try {
    const viewer = await resolveViewerContext(req);
    if (!viewer.userId) {
      return res.status(401).json({ success: false, error: { code: 'UNAUTHORIZED', message: 'Authentication required.' } });
    }
    const limit = req.query.limit ? parseInt(req.query.limit as string, 10) : undefined;
    const before = typeof req.query.before === 'string' ? req.query.before : (typeof req.query.cursor === 'string' ? req.query.cursor : undefined);
    const data = await watchtowerActivityService.fetchWatchtowerActivitiesForViewer(viewer, { limit, before });
    res.json({ success: true, data, activities: data });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { message: err?.message || 'Internal server error.' } });
  }
});

router.get(['/floor/stream', '/v1/floor/stream', '/watchtower/stream', '/v1/watchtower/stream'], async (req: AuthenticatedRequest, res: Response) => {
  let viewer: any = null;
  const ticket = req.query.ticket as string;
  if (ticket) {
    viewer = (watchtowerActivityService as any).redeemStreamTicket(ticket);
    if (viewer && viewer.userId) {
      try {
        const sb = getSupabaseClient();
        const { data: userRec } = await sb.from('users').select('id, status, master_id').eq('id', viewer.userId).maybeSingle();
        if (!userRec || userRec.status === 'suspended') {
          viewer = null;
        } else if (userRec.master_id && viewer.masterId && userRec.master_id !== viewer.masterId) {
          viewer = null;
        }
      } catch (e) {
        viewer = null;
      }
    }
  }
  if (!viewer) {
    await new Promise<void>((resolve) => {
      requireUserOrAgentAuth(req, res, () => {
        resolve();
      });
    });
    if (res.headersSent) return;
    if (req.user) {
      viewer = await resolveViewerContext(req);
    }
  }

  if (!viewer || !viewer.userId) {
    return res.status(401).json({ success: false, error: { code: 'UNAUTHORIZED', message: 'Authentication required for SSE stream.' } });
  }

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  if (typeof (res as any).flushHeaders === 'function') {
    (res as any).flushHeaders();
  }

  watchtowerActivityService.registerWatchtowerStreamClient(res, viewer);
});

// 16c. GET /api/telemetry/activity (Fleet Telemetry Summary: agents activity & clusters ranking)
router.get(['/telemetry/activity', '/v1/telemetry/activity'], requireUserOrAgentAuth, securityLayer('public_reads'), async (req: AuthenticatedRequest, res: Response) => {
  try {
    const callerMasterId = await resolveAuthMasterId(req);
    if (!callerMasterId) {
      return res.status(401).json({
        success: false,
        error: {
          code: 'UNAUTHORIZED',
          message: 'Authentication required. Telemetry activity is restricted to authenticated fleet accounts.'
        }
      });
    }

    const activityData = await getAgentActivityStats(callerMasterId);

    res.json({
      success: true,
      data: activityData
    });
  } catch (err: any) {
    res.status(500).json({
      success: false,
      error: {
        code: 'TELEMETRY_ERROR',
        message: err.message || 'Failed to retrieve telemetry activity.'
      }
    });
  }
});

// 17. GET /api/agents (Fleet-limited: List master and slave accounts belonging to caller's current fleet)
router.get('/agents', requireUserOrAgentAuth, securityLayer('public_reads'), async (req: AuthenticatedRequest, res: Response) => {
  try {
    const q = (req.query.q as string) || '';
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 20;

    const callerMasterId = await resolveAuthMasterId(req);
    if (!callerMasterId) {
      return res.status(401).json({
        success: false,
        error: {
          code: 'FLEET_AUTH_REQUIRED',
          message: 'Authentication required. This endpoint is fleet-limited to the authenticated caller\'s fleet.'
        }
      });
    }

    const result = await getAgents(q, page, limit, callerMasterId);

    res.json({
      success: true,
      data: result
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { message: err.message } });
  }
});

// 18. GET /api/adk (Get ADK specification)
router.get(['/adk', '/adk/spec'], securityLayer('public_reads'), (req: Request, res: Response) => {
  try {
    const rawSpec = getAdkSpecification() || ADK_SPECIFICATION;
    const host = req.get('host') || 'aamarva.com';
    const protocol = (req.headers['x-forwarded-proto'] as string) || req.protocol || 'https';
    const currentUrl = `${protocol}://${host}`;
    const adkSpec = rawSpec ? rawSpec.replace(/https:\/\/aamarva\.com/g, currentUrl) : rawSpec;
    const allEndpoints = getAllAdkEndpoints();
    const frameworksSpec = (getFrameworkIntegrationSpec() || '').replace(/https:\/\/aamarva\.com/g, currentUrl);
    const platformSpec = (getPlatformSpecification() || '').replace(/https:\/\/aamarva\.com/g, currentUrl);
    const endpointsSpec = (getEndpointSpecification() || '').replace(/https:\/\/aamarva\.com/g, currentUrl);

    if (req.headers.accept && req.headers.accept.includes('text/plain')) {
      res.setHeader('Content-Type', 'text/plain; charset=utf-8');
      return res.send(adkSpec);
    }

    res.json({
      success: true,
      version: '2.0.0',
      data: {
        version: '2.0.0',
        adk: adkSpec,
        frameworks: frameworksSpec,
        frameworkIntegrations: frameworksSpec,
        platform: platformSpec,
        platformSpec: platformSpec,
        endpointsSpec: endpointsSpec,
        floorEndpoints: FLOOR_MCP_AGENT_ENDPOINTS,
        floor_endpoints: FLOOR_MCP_AGENT_ENDPOINTS,
        endpoints: allEndpoints
      },
      endpoints: allEndpoints,
      floorEndpoints: FLOOR_MCP_AGENT_ENDPOINTS,
      floor_endpoints: FLOOR_MCP_AGENT_ENDPOINTS
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/adk/framework-integration (Dedicated framework integration specification)
router.get(['/adk/framework-integration', '/adk/frameworks', '/adk/framework-integrations'], securityLayer('public_reads'), (req: Request, res: Response) => {
  try {
    const host = req.get('host') || 'aamarva.com';
    const protocol = (req.headers['x-forwarded-proto'] as string) || req.protocol || 'https';
    const currentUrl = `${protocol}://${host}`;
    const frameworks = (getFrameworkIntegrationSpec() || '').replace(/https:\/\/aamarva\.com/g, currentUrl);

    if (req.headers.accept && req.headers.accept.includes('text/plain')) {
      res.setHeader('Content-Type', 'text/plain; charset=utf-8');
      return res.send(frameworks);
    }

    res.json({
      success: true,
      version: '2.0.0',
      data: {
        version: '2.0.0',
        frameworks,
        spec: frameworks
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 19. GET /api/health, /api/v1/health, /api/readiness, /api/liveness
router.get(['/health', '/v1/health', '/readiness', '/liveness'], async (req: Request, res: Response) => {
  try {
    const sb = getSupabaseClient();
    const startTime = Date.now();
    const { error } = await sb.from('users').select('id').limit(1);
    const dbLatencyMs = Date.now() - startTime;

    const isHealthy = !error;
    const statusCode = isHealthy ? 200 : 503;

    res.status(statusCode).json({
      success: isHealthy,
      status: isHealthy ? 'UP' : 'DOWN',
      timestamp: new Date().toISOString(),
      version: '1.0.0-production',
      services: {
        database: {
          status: isHealthy ? 'HEALTHY' : 'UNHEALTHY',
          latencyMs: dbLatencyMs,
          error: error ? error.message : null,
        },
      },
      system: {
        uptimeSeconds: Math.floor(process.uptime()),
        memoryUsageMb: Math.round(process.memoryUsage().heapUsed / 1024 / 1024),
      },
    });
  } catch (err: any) {
    res.status(503).json({
      success: false,
      status: 'DOWN',
      error: { message: err.message || 'Health check failed' },
    });
  }
});

// 21. POST /api/auth/agent/rotate-api-key & /api/auth/agent/revoke-api-key (Request API key rotation/revocation - Human Session Only)
router.post(
  [
    '/auth/agent/rotate-api-key',
    '/v1/auth/agent/rotate-api-key',
    '/auth/agent/revoke-api-key',
    '/v1/auth/agent/revoke-api-key',
  ],
  securityLayer('rotate_api_key'),
  async (req: any, res: Response) => {
    try {
      const token = req.body?.token || req.query?.token;
      const bodyAppUrl = req.body?.appUrl || req.query?.appUrl;
      const appUrl = bodyAppUrl || process.env.APP_URL || config.appUrl;

      if (token) {
        // Confirmation with token (reject agent credentials if present)
        return rejectAgentCredentials(req, res, async () => {
          try {
            const { pendingToken, credentialResponse, isSetup } = req.body || {};
            
            // Step A: Extract user ID from token and verify existence
            const userId = token.split('.')[0];
            const user = await getUserById(userId);
            if (!user) throw new Error('User account not found.');

            // Step B: If WebAuthn response is not yet provided, challenge the user
            if (!pendingToken || !credentialResponse) {
              const challengeResult = await generateLoginChallenge(user as any, req);
              return res.json({
                success: true,
                requiresWebAuthn: true,
                status: challengeResult.status,
                pendingToken: challengeResult.pendingToken,
                options: challengeResult.options,
                userName: user.name || user.agentId,
              });
            }

            // Step C: Verify the WebAuthn cryptographic hardware assertion
            if (isSetup) {
              await verifySetupResponse(pendingToken, credentialResponse, 'API Key Security Passkey', req);
            } else {
              const loginResult = await verifyLoginResponse(pendingToken, credentialResponse, req);
              if (loginResult.userId !== user.id) {
                throw new Error('WebAuthn hardware verification failed: account mismatch.');
              }
            }

            // Step D: Assertion verified! Finalize the rotation
            const result = await confirmAgentApiKeyRotation(token);
            await logAgentFootprint(
              token.split('.')[0] || 'system',
              'API_KEY_ROTATED',
              'Rotated agent API key via email confirmation link and hardware assertion',
              undefined,
              user.agentId,
              'POST /api/auth/agent/rotate-api-key'
            );
            (req as any).alreadyRecordedSlaveActivity = true;
            return res.json({ success: true, data: result, message: 'API key successfully rotated via email confirmation link and hardware assertion.' });
          } catch (err: any) {
            return res.status(400).json({ success: false, error: err.message || 'Failed to confirm API key rotation.' });
          }
        });
      }

      // NO token present: Strictly require human session authentication
      return requireHumanSession(req, res, async () => {
        try {
          const targetAccountId = (req.user as any)?.activeAccountId || req.user!.id;
          const result = await requestAgentApiKeyRotation(targetAccountId, appUrl);
          await logAgentFootprint(
            targetAccountId,
            'API_KEY_ROTATION_REQUESTED',
            'Requested API key rotation confirmation link via email',
            undefined,
            req.user?.agentId,
            'POST /api/auth/agent/rotate-api-key'
          );
          (req as any).alreadyRecordedSlaveActivity = true;
          res.json(result);
        } catch (err: any) {
          res.status(400).json({ success: false, error: err.message || 'Failed to request API key rotation link.' });
        }
      });
    } catch (err: any) {
      console.error('Error processing API key rotation:', err.message);
      res.status(400).json({ 
        success: false, 
        error: err.message || 'Failed to process API key rotation request.' 
      });
    }
  }
);

// 21b. GET & POST /api/auth/agent/rotate-api-key/confirm (Confirm rotation token directly - Reject Agent Credentials)
router.all(
  [
    '/auth/agent/rotate-api-key/confirm',
    '/v1/auth/agent/rotate-api-key/confirm',
    '/auth/agent/revoke-api-key/confirm',
    '/v1/auth/agent/revoke-api-key/confirm',
  ],
  rejectAgentCredentials,
  securityLayer('rotate_api_key'),
  async (req: Request, res: Response) => {
    try {
      const token = String(req.body?.token || req.query?.token || '');
      const { pendingToken, credentialResponse, isSetup } = req.body || {};
      
      if (!token) {
        return res.status(400).json({ success: false, error: 'Rotation confirmation token is required.' });
      }

      // Step A: Extract user ID from token and verify existence
      const userId = token.split('.')[0];
      const user = await getUserById(userId);
      if (!user) throw new Error('User account not found.');

      // Step B: If WebAuthn response is not yet provided, challenge the user
      if (!pendingToken || !credentialResponse) {
        const challengeResult = await generateLoginChallenge(user as any, req);
        return res.json({
          success: true,
          requiresWebAuthn: true,
          status: challengeResult.status,
          pendingToken: challengeResult.pendingToken,
          options: challengeResult.options,
          userName: user.name || user.agentId,
        });
      }

      // Step C: Verify the WebAuthn cryptographic hardware assertion
      if (isSetup) {
        await verifySetupResponse(pendingToken, credentialResponse, 'API Key Security Passkey', req);
      } else {
        const loginResult = await verifyLoginResponse(pendingToken, credentialResponse, req);
        if (loginResult.userId !== user.id) {
          throw new Error('WebAuthn hardware verification failed: account mismatch.');
        }
      }

      // Step D: Assertion verified! Finalize the rotation
      const result = await confirmAgentApiKeyRotation(token);
      await logAgentFootprint(
        token.split('.')[0] || 'system',
        'API_KEY_ROTATED',
        'Rotated agent API key via email confirmation link and hardware assertion',
        undefined,
        user.agentId,
        'POST /api/auth/agent/rotate-api-key/confirm'
      );
      (req as any).alreadyRecordedSlaveActivity = true;
      try {
        const rotUserId = token.split('.')[0];
        const rotUser = await getUserById(rotUserId);
        if (rotUser) {
          watchtowerActivityService.recordWatchtowerActivity({
            agentId: rotUser.agentId || rotUser.id,
            agentName: rotUser.name || rotUser.agentId,
            avatar: rotUser.avatar || '🤖',
            emailVerified: Boolean(rotUser.emailVerified),
            text: 'rotated its API key',
            type: 'API_KEY_ROTATED',
            actorUserId: rotUser.id,
            masterId: (rotUser.master_id && !rotUser.is_master_primary) ? rotUser.master_id : rotUser.id,
            activityKey: `api_key_rot:${rotUser.id}:${Date.now()}`,
            skipFootprintInsert: true
          }).catch(console.warn);
        }
      } catch (e) {}
      res.json({
        success: true,
        data: result,
        message: 'API key successfully rotated via email confirmation link and hardware assertion.',
      });
    } catch (err: any) {
      res.status(400).json({ success: false, error: err.message || 'Failed to confirm API key rotation.' });
    }
  }
);

// 22. POST /api/auth/change-email/request (Request email change - Human Session Only)
router.post(
  ['/auth/change-email/request', '/v1/auth/change-email/request'],
  requireHumanSession,
  securityLayer('change_email'),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { newEmail, appUrl: bodyAppUrl } = req.body;
      if (!newEmail) {
        return res.status(400).json({ success: false, error: 'New email address is required.' });
      }
      const appUrl = bodyAppUrl || process.env.APP_URL || config.appUrl;
      const result = await requestEmailChange(req.user!.id, { newEmail }, appUrl);
      res.json({ success: true, data: result });
    } catch (err: any) {
      const status = err.message.includes('Incorrect') || err.message.includes('password') ? 401 : 400;
      res.status(status).json({ success: false, error: err.message });
    }
  }
);

// 23. POST /api/auth/change-email/verify (Verify email change - Reject Agent Credentials)
router.post(
  ['/auth/change-email/verify', '/v1/auth/change-email/verify'],
  rejectAgentCredentials,
  securityLayer('change_email'),
  async (req: Request, res: Response) => {
    try {
      const { token, pendingToken, credentialResponse, isSetup } = req.body;
      if (!token) return res.status(400).json({ success: false, error: 'Token is required.' });

      // Step A: Extract user ID from token
      const userId = token.split('.')[0];
      const user = await getUserById(userId);
      if (!user) throw new Error('User account not found.');

      // Step B: If WebAuthn response is not yet provided, challenge the user
      if (!pendingToken || !credentialResponse) {
        const challengeResult = await generateLoginChallenge(user as any, req);
        return res.json({
          success: true,
          requiresWebAuthn: true,
          status: challengeResult.status,
          pendingToken: challengeResult.pendingToken,
          options: challengeResult.options,
          userName: user.name || user.agentId,
        });
      }

      // Step C: Verify the WebAuthn cryptographic hardware assertion
      if (isSetup) {
        await verifySetupResponse(pendingToken, credentialResponse, 'Email Security Passkey', req);
      } else {
        const loginResult = await verifyLoginResponse(pendingToken, credentialResponse, req);
        if (loginResult.userId !== user.id) {
          throw new Error('WebAuthn hardware verification failed: account mismatch.');
        }
      }

      // Step D: Assertion verified! Finalize the change
      const result = await verifyEmailChange(token);
      res.json({ success: true, data: result });
    } catch (err: any) {
      res.status(400).json({ success: false, error: err.message });
    }
  }
);

// 23b. POST /api/auth/verify-email/request (Request account verification link - Strictly Requires Human Session)
router.post(
  ['/auth/verify-email/request', '/v1/auth/verify-email/request'],
  requireHumanSession,
  securityLayer('verify_email'),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { appUrl: bodyAppUrl } = req.body || {};
      const appUrl = bodyAppUrl || process.env.APP_URL || config.appUrl;
      const result = await requestAccountVerificationEmail(req.user!.id, appUrl);
      res.json(result);
    } catch (err: any) {
      res.status(400).json({ success: false, error: err.message || 'Failed to request verification email.' });
    }
  }
);

// 23c. POST /api/auth/verify-email/confirm (Confirm account verification token - Strictly Requires Human Session)
router.post(
  ['/auth/verify-email/confirm', '/v1/auth/verify-email/confirm'],
  requireHumanSession,
  securityLayer('verify_email'),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { token } = req.body || {};
      if (!token) {
        return res.status(400).json({ success: false, error: 'Verification token is required.' });
      }

      // Enforce that the verification token matches the authenticated human session
      if (typeof token === 'string' && token.includes('.')) {
        const tokenUserId = token.split('.')[0];
        if (tokenUserId !== req.user!.id) {
          return res.status(403).json({
            success: false,
            error: 'Verification token does not match the active human session. Please sign in to the corresponding account.',
          });
        }
      }

      const result = await confirmAccountEmailVerification(token);
      res.json(result);
    } catch (err: any) {
      res.status(400).json({ success: false, error: err.message || 'Verification failed.' });
    }
  }
);


// 23d. GET /api/auth/verify-email/confirm (Browser redirect to human verification view - Reject Agent Credentials)
router.get(
  ['/auth/verify-email/confirm', '/v1/auth/verify-email/confirm'],
  rejectAgentCredentials,
  securityLayer('verify_email'),
  async (req: Request, res: Response) => {
    try {
      const token = String(req.query.token || '');
      const appUrl = process.env.APP_URL || config.appUrl || '';
      if (token) {
        return res.redirect(`${appUrl}/verify-email?token=${encodeURIComponent(token)}`);
      }
      return res.redirect(appUrl || '/');
    } catch (err: any) {
      res.status(400).json({ success: false, error: err.message || 'Verification redirect failed.' });
    }
  }
);

// 24. POST /api/auth/forgot-password (Request password reset email - Reject Agent Credentials)
router.post(
  ['/auth/forgot-password', '/v1/auth/forgot-password'],
  rejectAgentCredentials,
  passwordResetRateLimiter,
  securityLayer('forgot_password'),
  async (req: Request, res: Response) => {
    try {
      const { email, appUrl: bodyAppUrl } = req.body;
      const appUrl = bodyAppUrl || process.env.APP_URL || config.appUrl;
      const result = await requestForgotPassword(email, appUrl);
      res.json(result);
    } catch (err: any) {
      console.error('[DIAGNOSTIC_LOG] [AUTH] Exception in forgot-password handler:', err?.message || err);
      res.json({ success: true, message: "If an account exists for this email, password reset instructions have been sent." });
    }
  }
);

// 25. POST /api/auth/reset-password (Reset password using token + WebAuthn Enforcement - Reject Agent Credentials)
router.post(
  ['/auth/reset-password', '/v1/auth/reset-password'],
  rejectAgentCredentials,
  passwordResetRateLimiter,
  securityLayer('reset_password'),
  async (req: Request, res: Response) => {
    try {
      const { token, newPassword, pendingToken, credentialResponse, isSetup } = req.body;
      if (!token || !newPassword) {
        return res.status(400).json({ success: false, error: 'Token and new password are required.' });
      }

      // Step A: Look up the user for this reset token
      const user = await getResetTokenUser(token);

      // Step B: If WebAuthn response is not yet provided, challenge the user
      if (!pendingToken || !credentialResponse) {
        const challengeResult = await generateLoginChallenge(user as any, req);
        return res.json({
          success: true,
          requiresWebAuthn: true,
          status: challengeResult.status,
          pendingToken: challengeResult.pendingToken,
          options: challengeResult.options,
          userName: user.name || user.agentId,
        });
      }

      // Step C: Verify the WebAuthn cryptographic hardware assertion
      let verifiedUserId: string;
      if (isSetup) {
        const setupResult = await verifySetupResponse(pendingToken, credentialResponse, 'Password Reset Passkey', req);
        verifiedUserId = setupResult.userId;
      } else {
        const loginResult = await verifyLoginResponse(pendingToken, credentialResponse, req);
        verifiedUserId = loginResult.userId;
      }

      // Cryptographic guarantee: verify that hardware assertion belongs to the reset account
      if (verifiedUserId !== user.id) {
        return res.status(403).json({
          success: false,
          error: 'WebAuthn hardware verification failed: credential does not match the account requesting password reset.',
        });
      }

      // Step D: Assertion verified! Atomically update the password and burn the reset token
      const result = await resetPassword(token, newPassword);

      // Step E: Issue an authenticated human session cookie directly to the verified browser!
      const sessionId = await createHumanSession(user.id);
      res.cookie(HUMAN_SESSION_COOKIE_NAME, sessionId, getHumanSessionCookieOptions());

      res.json({
        success: true,
        data: {
          message: result.message,
          user: {
            id: user.id,
            agentId: user.agentId,
            name: user.name,
            email: user.email,
          },
        },
      });
    } catch (err: any) {
      res.status(400).json({ success: false, error: err.message || 'Failed to reset password.' });
    }
  }
);

async function resolveTelemetryCallerContext(req: AuthenticatedRequest): Promise<{
  callerUserId: string;
  callerAgentId: string;
  callerMasterId: string;
  callerFleetId?: string;
  isSlave: boolean;
}> {
  const sb = getSupabaseClient();
  const callerUserId = (req.user as any)!.id || (req.user as any)!.userId;
  const callerAgentId = req.user!.agentId || callerUserId;
  const rawMasterId = (req.user as any)?.masterUserId || (req.user as any)?.master_id || (req.user as any)?.masterId;
  let callerFleetId = (req.user as any)?.fleet_id;

  let effectiveUser: any = req.user || {};
  if (
    effectiveUser.account_type === undefined ||
    effectiveUser.is_master_slot === undefined ||
    effectiveUser.is_master_primary === undefined
  ) {
    try {
      const { data: dbUser } = await sb
        .from('users')
        .select('id, agentId, email, account_type, role, is_slave, is_master_slot, is_master_primary, master_id, fleet_id')
        .eq('id', callerUserId)
        .maybeSingle();
      if (dbUser) {
        effectiveUser = { ...effectiveUser, ...dbUser };
        if (!callerFleetId && dbUser.fleet_id) callerFleetId = dbUser.fleet_id;
      }
    } catch {}
  }

  const effectiveMasterId = rawMasterId || effectiveUser.master_id || callerUserId;
  const isExplicitMaster = Boolean(
    effectiveUser.is_master_primary === true ||
    effectiveUser.isMasterPrimary === true ||
    effectiveUser.is_master_slot === true ||
    effectiveUser.isMasterSlot === true ||
    effectiveUser.account_type === 'master_slot' ||
    effectiveUser.account_type === 'master' ||
    effectiveUser.role === 'master'
  );
  const isExplicitSlave = Boolean(
    effectiveUser.account_type === 'slave' ||
    effectiveUser.role === 'slave' ||
    effectiveUser.is_slave === true ||
    effectiveUser.isSlave === true ||
    (typeof effectiveUser.email === 'string' && effectiveUser.email.includes('+AMR-'))
  );
  const isSlave = isExplicitSlave || (!isExplicitMaster && Boolean(effectiveMasterId && effectiveMasterId !== callerUserId));

  return {
    callerUserId,
    callerAgentId,
    callerMasterId: effectiveMasterId,
    callerFleetId,
    isSlave,
  };
}

async function resolveRequestedRealtimeStreamTarget(req: AuthenticatedRequest): Promise<{ errorStatus?: number; errorBody?: any; userId: string; agentId: string }> {
  const ctx = await resolveTelemetryCallerContext(req);
  let streamUserId = ctx.callerUserId;
  let streamAgentId = ctx.callerAgentId;

  const requestedTarget = String(
    req.headers['x-target-agent-id'] ||
    req.query.agentId ||
    req.query.agent_id ||
    req.query.targetAgentId ||
    ''
  ).trim();

  if (requestedTarget) {
    const isTargetSelf =
      requestedTarget.toLowerCase() === ctx.callerUserId.toLowerCase() ||
      requestedTarget.toLowerCase() === ctx.callerAgentId.toLowerCase();

    if (!isTargetSelf) {
      if (ctx.isSlave) {
        return {
          errorStatus: 403,
          errorBody: {
            success: false,
            error: {
              code: 'UNAUTHORIZED',
              message: 'Unauthorized: Slave accounts are strictly account-restricted and cannot stream events for other accounts.'
            }
          },
          userId: '',
          agentId: ''
        };
      }

      const sb = getSupabaseClient();
      const { data: matchById } = await sb
        .from('users')
        .select('id, agentId, master_id, fleet_id')
        .eq('id', requestedTarget)
        .maybeSingle();
      let slaveMatch = matchById;
      if (!slaveMatch) {
        const cleanHandle = requestedTarget.replace(/^@+/, '');
        const { data: matchByAgentId } = await sb
          .from('users')
          .select('id, agentId, master_id, fleet_id')
          .ilike('agentId', cleanHandle)
          .maybeSingle();
        slaveMatch = matchByAgentId;
      }

      const inFleet = Boolean(
        slaveMatch && (
          slaveMatch.id === ctx.callerUserId ||
          slaveMatch.master_id === ctx.callerUserId ||
          slaveMatch.master_id === ctx.callerMasterId ||
          (ctx.callerFleetId && slaveMatch.fleet_id && slaveMatch.fleet_id === ctx.callerFleetId)
        )
      );
      if (!inFleet || !slaveMatch) {
        return {
          errorStatus: 403,
          errorBody: {
            success: false,
            error: {
              code: 'UNAUTHORIZED',
              message: 'Unauthorized: Cannot stream events outside your fleet.'
            }
          },
          userId: '',
          agentId: ''
        };
      }
      streamUserId = slaveMatch.id;
      streamAgentId = slaveMatch.agentId || slaveMatch.id;
    }
  }

  return { userId: streamUserId, agentId: streamAgentId };
}

// 25a. POST /api/realtime/stream-ticket (Short-lived ticket so EventSource works with Agent/API-Key auth)
router.post(['/realtime/stream-ticket', '/v1/realtime/stream-ticket'], requireUserOrAgentAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const resolved = await resolveRequestedRealtimeStreamTarget(req);
    if (resolved.errorStatus) {
      return res.status(resolved.errorStatus).json(resolved.errorBody);
    }
    const ticket = realtimeService.createStreamTicket({
      userId: resolved.userId,
      agentId: resolved.agentId,
    });
    res.json({ success: true, ticket });
  } catch (err: any) {
    res.status(500).json({ success: false, error: { message: err?.message || 'Failed to issue stream ticket.' } });
  }
});

// 25b. GET /api/realtime/stream (Realtime Server-Sent Events stream for authenticated account)
router.get('/realtime/stream', async (req: AuthenticatedRequest, res: Response) => {
  let streamUserId = '';
  let streamAgentId = '';

  const ticket = typeof req.query.ticket === 'string' ? req.query.ticket : '';
  if (ticket) {
    const redeemed = realtimeService.redeemStreamTicket(ticket);
    if (redeemed && redeemed.userId) {
      try {
        const sb = getSupabaseClient();
        const { data: userRec } = await sb.from('users').select('id, status, agentId').eq('id', redeemed.userId).maybeSingle();
        if (userRec && userRec.status !== 'suspended') {
          streamUserId = userRec.id;
          streamAgentId = redeemed.agentId || userRec.agentId || userRec.id;
        }
      } catch {}
    }
  }

  if (!streamUserId) {
    await new Promise<void>((resolve) => {
      requireUserOrAgentAuth(req, res, () => {
        resolve();
      });
    });
    if (res.headersSent) return;
    if (req.user) {
      const resolved = await resolveRequestedRealtimeStreamTarget(req);
      if (resolved.errorStatus) {
        return res.status(resolved.errorStatus).json(resolved.errorBody);
      }
      streamUserId = resolved.userId;
      streamAgentId = resolved.agentId;
    }
  }

  if (!streamUserId) {
    return res.status(401).json({ success: false, error: { code: 'UNAUTHORIZED', message: 'Authentication required for SSE stream.' } });
  }

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders?.();

  // Strictly register ONLY the resolved target/caller account — NEVER subscribe sub-accounts to masterId
  realtimeService.registerClient(streamUserId, res, streamAgentId);
});

// Alias: GET /api/realtime/events (Agent only - strictly account-restricted for sub/slave agents)
router.get('/realtime/events', requireAgentAuth, requireAgent, async (req: AuthenticatedRequest, res: Response) => {
  const ctx = await resolveTelemetryCallerContext(req);
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders?.();

  realtimeService.registerClient(ctx.callerUserId, res, ctx.callerAgentId);
});

function getEndpointForAction(action: string, target?: string): string {
  switch (action) {
    // Floor Transmissions & Tool Invocations
    case 'TOOL_INVOKED': return target ? `/api/floor/tools/${target}/invoke` : '/api/floor/tools/:id/invoke';
    case 'TOOL_EXECUTED': return target ? `/api/floor/invocations/${target}/execute` : '/api/floor/invocations/:id/execute';
    case 'TOOL_APPROVED':
    case 'TOOL_DENIED': return target ? `POST /api/floor/approvals/${target}` : 'POST /api/floor/approvals/:id';
    case 'MCP_SERVER_REGISTERED': return 'POST /api/floor/servers';
    case 'MCP_TOOL_INVOCATION_BLOCKED': return target ? `POST /api/floor/tools/${target}/invoke` : 'POST /api/floor/tools/:id/invoke';

    // Direct Connections & Messaging
    case 'CONNECTED':
    case 'CONNECTION_ACCEPTED':
    case 'CONNECTION_ESTABLISHED': return target ? `/api/connections/${target}` : '/api/connections';
    case 'DISCONNECTED':
    case 'CONNECTION_DISSOLVED': return target ? `POST /api/connections/${target}/dissolve` : 'POST /api/connections/:id/dissolve';
    case 'CONNECTION_REMOVED': return target ? `DELETE /api/connections/${target}` : 'DELETE /api/connections/:id';
    case 'MESSAGE_SENT': return target ? `POST /api/connections/${target}/messages` : 'POST /api/connections/:id/messages';
    case 'ATTACHMENT_SENT':
    case 'ATTACHMENT_RECEIVED': return target ? `POST /api/connections/${target}/attachments` : 'POST /api/connections/:id/attachments';
    case 'CONNECTION_MESSAGES_CLEARED': return target ? `DELETE /api/connections/${target}/messages` : 'DELETE /api/connections/:id/messages';

    // Reputation & Reviews
    case 'PEER_REVIEW': return 'POST /api/reviews';
    case 'PEER_REVIEW_DELETED':
    case 'REVIEW_DELETED': return target ? `DELETE /api/reviews/${target}` : 'DELETE /api/reviews/:id';

    // Agent Identity, Security & Access Governance
    case 'AGENT_REGISTERED': return 'POST /api/auth/register';
    case 'PROFILE_UPDATED':
    case 'AGENT_PROFILE_UPDATED': return 'PATCH /api/agents/me';
    case 'E2EE_KEYS_UPDATED': return 'PUT /api/agents/me/e2ee';
    case 'API_KEY_ROTATED': return 'POST /api/agents/me/api-key/rotate';
    case 'API_KEY_ROTATION_REQUESTED': return 'POST /api/auth/agent/rotate-api-key';
    case 'PASSWORD_CHANGED': return 'POST /api/auth/change-password';
    case 'EMAIL_UPDATED': return 'POST /api/auth/change-email';
    case 'WHITELIST_UPDATED': return 'PUT /api/auth/network-whitelist';
    case 'ACCESS_RULES_UPDATED': return 'PUT /api/account/access-management';
    case 'SESSIONS_REVOKED_ALL':
    case 'GLOBAL_LOGOUT': return 'POST /api/auth/sessions/logout-all';
    case 'FLEET_SETTINGS_COPIED': return 'POST /api/auth/master/copy-settings';

    // Slave Fleet Management & Plan Activations
    case 'SLAVE_DEPLOYED': return 'POST /api/auth/master/create-slave-agent';
    case 'SLAVE_UNDEPLOYED': return 'POST /api/auth/master/undeploy-slave';
    case 'SLAVE_CAPABILITY_BATCH_ACTIVATED': return 'POST /api/auth/master/buy-plan';

    // Cluster Enclaves
    case 'CLUSTER_CREATED': return 'POST /api/clusters';
    case 'CLUSTER_UPDATED': return target ? `PATCH /api/clusters/${target}` : 'PATCH /api/clusters/:id';
    case 'CLUSTER_DELETED': return target ? `DELETE /api/clusters/${target}` : 'DELETE /api/clusters/:id';
    case 'CLUSTER_INVITE_SENT': return target ? `POST /api/clusters/${target}/invites` : 'POST /api/clusters/:id/invites';
    case 'CLUSTER_INVITE_REVOKED': return target ? `DELETE /api/clusters/invites/${target}` : 'DELETE /api/clusters/:id/invites/:inviteId';
    case 'CLUSTER_JOINED': return target ? `POST /api/clusters/${target}/join` : 'POST /api/clusters/:id/join';
    case 'CLUSTER_LEFT': return target ? `DELETE /api/clusters/${target}/leave` : 'DELETE /api/clusters/:id/leave';
    case 'CLUSTER_MEMBER_ADDED':
    case 'CLUSTER_MEMBER_INVITED': return target ? `POST /api/clusters/${target}/members` : 'POST /api/clusters/:id/members';
    case 'CLUSTER_ROLE_UPDATED':
    case 'CLUSTER_MEMBER_ROLE_UPDATED': return target ? `PATCH /api/clusters/members/${target}/role` : 'PATCH /api/clusters/:id/members/:memberId/role';
    case 'CLUSTER_MEMBER_REMOVED': return target ? `DELETE /api/clusters/members/${target}` : 'DELETE /api/clusters/:id/members/:memberId';
    case 'CLUSTER_MESSAGE_SENT': return target ? `POST /api/clusters/${target}/messages` : 'POST /api/clusters/:id/messages';
    case 'CLUSTER_KEY_DISTRIBUTED': return target ? `POST /api/clusters/${target}/key-distribution` : 'POST /api/clusters/:id/key-distribution';
    case 'CLUSTER_KEY_ROTATED': return target ? `POST /api/clusters/${target}/rotate-key` : 'POST /api/clusters/:id/rotate-key';

    // Feed
    case 'POST_CREATED': return 'POST /api/posts';
    case 'BID_SUBMITTED': return 'POST /api/bids';

    default: return 'POST /api/agent/action';
  }
}

// Helper: Safe user metadata lookup by mixed user IDs and agentIds without PostgREST unquoted .or() camelCase issues
async function fetchUsersByIdsOrAgentIds(sb: any, identifiers: string[]): Promise<any[]> {
  const cleanIds = Array.from(new Set(identifiers.map((s) => String(s || '').trim()).filter(Boolean)));
  if (cleanIds.length === 0) return [];
  const strippedIds = Array.from(new Set(cleanIds.map((s) => s.replace(/^@+/, '')).filter(Boolean)));
  const prefixedIds = Array.from(new Set(strippedIds.map((s) => `@${s}`)));
  const agentCandidates = Array.from(new Set([...cleanIds, ...strippedIds, ...prefixedIds]));

  const [byIdRes, byAgentIdRes] = await Promise.all([
    sb.from('users').select('id, agentId, name, avatar').in('id', cleanIds),
    sb.from('users').select('id, agentId, name, avatar').in('agentId', agentCandidates)
  ]);

  if (byIdRes?.error) {
    console.warn('[TelemetryLookup] users.in(id) error:', byIdRes.error.message || byIdRes.error);
  }
  if (byAgentIdRes?.error) {
    console.warn('[TelemetryLookup] users.in(agentId) error:', byAgentIdRes.error.message || byAgentIdRes.error);
  }

  const map = new Map<string, any>();
  for (const u of [...(byIdRes?.data || []), ...(byAgentIdRes?.data || [])]) {
    if (u?.id) map.set(u.id, u);
  }
  return Array.from(map.values());
}

// 26. GET /api/agent/footprints (Agent activity history - Master fleet-restricted, Sub account-restricted)
router.get('/agent/footprints', requireUserOrAgentAuth, securityLayer('public_reads'), async (req: AuthenticatedRequest, res: Response) => {
  try {
    const sb = getSupabaseClient();
    const { callerUserId, callerAgentId, callerMasterId, callerFleetId, isSlave } = await resolveTelemetryCallerContext(req);

    const targetAgentHeader = req.headers['x-target-agent-id'] as string | undefined;
    const queryAgentId = (targetAgentHeader || req.query.agentId || req.query.agent_id) as string | undefined;
    const queryUserId = (req.query.userId || req.query.user_id) as string | undefined;

    let targetUserId = callerUserId;
    let targetAgentId = callerAgentId;

    const requestedTarget = (queryAgentId || queryUserId || '').trim();

    if (requestedTarget) {
      const isTargetSelf = 
        requestedTarget.toLowerCase() === callerUserId.toLowerCase() ||
        requestedTarget.toLowerCase() === callerAgentId.toLowerCase();

      if (isSlave) {
        // A slave agent may access ONLY its own activity
        if (!isTargetSelf) {
          return res.status(403).json({
            success: false,
            error: {
              code: 'UNAUTHORIZED',
              message: 'Unauthorized: Slave agents cannot access activity records of other accounts.'
            }
          });
        }
      } else {
        // Master account: can access self or subordinate agents within its own fleet
        if (!isTargetSelf) {
          let slaveMatch: any = null;
          const { data: matchById } = await sb
            .from('users')
            .select('id, agentId, master_id, fleet_id')
            .eq('id', requestedTarget)
            .maybeSingle();
          slaveMatch = matchById;
          if (!slaveMatch) {
            const { data: matchByAgentId } = await sb
              .from('users')
              .select('id, agentId, master_id, fleet_id')
              .ilike('agentId', requestedTarget.replace(/^@+/, ''))
              .maybeSingle();
            slaveMatch = matchByAgentId;
          }

          const inFleet = Boolean(
            slaveMatch && (
              slaveMatch.id === callerUserId ||
              slaveMatch.master_id === callerUserId ||
              slaveMatch.master_id === callerMasterId ||
              (callerFleetId && slaveMatch.fleet_id && slaveMatch.fleet_id === callerFleetId)
            )
          );
          if (!slaveMatch || !inFleet) {
            return res.status(403).json({
              success: false,
              error: {
                code: 'UNAUTHORIZED',
                message: 'Unauthorized: Cannot access activity records outside your fleet.'
              }
            });
          }
          targetUserId = slaveMatch.id;
          targetAgentId = slaveMatch.agentId || slaveMatch.id;
        }
      }
    }

    let footprints: any[] = [];
    const clusterTables = await getClusterTables(sb);

    // Fetch authoritative acting user profile once for targetUserId
    let targetUserRec: any = null;
    try {
      const { data: uRec } = await sb
        .from('users')
        .select('id, agentId, name, avatar, createdAt, created_at')
        .eq('id', targetUserId)
        .maybeSingle();
      targetUserRec = uRec || null;
      if (targetUserRec?.agentId && (!targetAgentId || targetAgentId === targetUserId)) {
        targetAgentId = targetUserRec.agentId;
      }
    } catch {}

    const extractPeerHandleFromText = (str: string): string | null => {
      if (!str || typeof str !== 'string') return null;
      const amrMatch = str.match(/(AMR-[A-Za-z0-9_-]+)/i);
      if (amrMatch && amrMatch[1]) {
        return amrMatch[1].replace(/^@+/, '');
      }
      const atMatch = str.match(/@([A-Za-z0-9][A-Za-z0-9_-]+)/);
      if (atMatch && atMatch[1] && atMatch[1].toLowerCase() !== 'agent' && !atMatch[1].toLowerCase().startsWith('req_')) {
        return atMatch[1];
      }
      const phraseMatch = str.match(/(?:handshake with agent|with agent|to agent|from agent|for agent)\s+@?([A-Za-z0-9_-]+)/i);
      if (phraseMatch && phraseMatch[1]) {
        const candidate = phraseMatch[1].replace(/^@+/, '');
        const lower = candidate.toLowerCase();
        const stopWords = new Set(['node', 'identity', 'profile', 'key', 'keys', 'account', 'accounts', 'session', 'sessions', 'token', 'settings', 'status', 'action', 'slot', 'record', 'unknown', 'agent']);
        if (!lower.startsWith('req_') && !stopWords.has(lower)) {
          return candidate;
        }
      }
      return null;
    };

    const isSelfAccountFootprintAction = (actionUpper: string): boolean => {
      return (
        actionUpper.includes('PROFILE') ||
        actionUpper.includes('E2EE') ||
        actionUpper.includes('PASSWORD') ||
        actionUpper.includes('EMAIL') ||
        actionUpper.includes('WHITELIST') ||
        actionUpper.includes('ACCESS_RULES') ||
        actionUpper.includes('LOGOUT') ||
        actionUpper.includes('SESSIONS_REVOKED') ||
        actionUpper.includes('API_KEY') ||
        actionUpper.includes('PLAN_ENTITLEMENT') ||
        actionUpper.includes('CAPABILITY_BATCH') ||
        actionUpper.includes('FLEET_SETTINGS') ||
        actionUpper.startsWith('TOOL_') ||
        actionUpper.startsWith('MCP_') ||
        actionUpper === 'AGENT_REGISTERED' ||
        actionUpper === 'AGENT_LOGGED_IN' ||
        actionUpper === 'STREAM_CONNECTED'
      );
    };

    try {
      let data: any[] | null = null;
      let error: any = null;
      if (targetUserId === callerUserId) {
        const resFp = await sb
          .from('agent_footprints')
          .select('*')
          .eq('user_id', targetUserId)
          .order('created_at', { ascending: false })
          .limit(50);
        data = resFp.data;
        error = resFp.error;
      } else {
        const [slaveOwnRes, masterTaggedRes] = await Promise.all([
          sb.from('agent_footprints').select('*').eq('user_id', targetUserId).order('created_at', { ascending: false }).limit(50),
          targetAgentId
            ? sb.from('agent_footprints').select('*').eq('user_id', callerUserId).ilike('agent_id', targetAgentId).order('created_at', { ascending: false }).limit(50)
            : Promise.resolve({ data: [], error: null })
        ]);
        error = slaveOwnRes.error || masterTaggedRes.error;
        const fpMap = new Map<string, any>();
        for (const r of [...(slaveOwnRes.data || []), ...(masterTaggedRes.data || [])]) {
          if (r?.id) fpMap.set(r.id, r);
        }
        data = Array.from(fpMap.values())
          .sort((a, b) => new Date(b.created_at || b.createdAt || 0).getTime() - new Date(a.created_at || a.createdAt || 0).getTime())
          .slice(0, 50);
      }
      if (error) {
        console.warn('[Footprints] agent_footprints query error:', error.message || error);
      }
      if (!error && data && data.length > 0) {
        // Enforce strict account isolation and exclude inbound-only webhook types from outbound footprints
        const INBOUND_ONLY_FOOTPRINT_EXCLUDE = new Set([
          'MESSAGE_RECEIVED',
          'DIRECT_ENCRYPTED_MESSAGE_RECEIVED',
          'ATTACHMENT_RECEIVED',
          'CLUSTER_MESSAGE_RECEIVED',
          'PEER_REVIEW_RECEIVED',
          'CONNECTION_REQUEST_RECEIVED',
          'CONNECTION_ACCEPTED_BY_TARGET',
          'CONNECTION_REJECTED',
          'CLUSTER_MEMBER_JOINED',
          'SLAVE_CAPABILITY_ACTIVATED',
          'STREAM_CONNECTED'
        ]);
        const authorizedData = data.filter((item: any) => {
          const upperAction = String(item.action || '').toUpperCase();
          if (INBOUND_ONLY_FOOTPRINT_EXCLUDE.has(upperAction)) return false;
          return item.user_id === targetUserId || (targetUserId !== callerUserId && item.user_id === callerUserId);
        });

        // Collect potential agent IDs, actor IDs, connection IDs, and user IDs
        const targetAgentIds = new Set<string>();
        const potentialConnIds = new Set<string>();

        authorizedData.forEach((item: any) => {
          if (item.user_id) targetAgentIds.add(item.user_id);
          if (item.agent_id && !['AGENT', 'MASTER'].includes(String(item.agent_id).trim().toUpperCase())) {
            targetAgentIds.add(String(item.agent_id).trim());
          }
          if (item.target_agent_id) targetAgentIds.add(item.target_agent_id);
          const tgt = (item.target || '').trim();
          if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(tgt)) {
            potentialConnIds.add(tgt);
          } else if (tgt && !tgt.toLowerCase().startsWith('req_') && !tgt.toLowerCase().startsWith('post_') && !tgt.toLowerCase().startsWith('cluster_')) {
            targetAgentIds.add(tgt);
          }

          let str = '';
          if (typeof item.details === 'string') {
            str = item.details;
          } else if (item.details && typeof item.details === 'object') {
            str = item.details.message || item.details.targetAgentId || item.details.receiverAgentId || '';
            if (item.details.targetAgentId) targetAgentIds.add(item.details.targetAgentId);
            if (item.details.receiverAgentId) targetAgentIds.add(item.details.receiverAgentId);
            if (item.details.agentId) targetAgentIds.add(item.details.agentId);
          }
          const extracted = extractPeerHandleFromText(str);
          if (extracted) {
            targetAgentIds.add(extracted);
          }
        });

        // Resolve connections if target was a connection UUID
        const connLookupMap: Record<string, any> = {};
        if (potentialConnIds.size > 0) {
          try {
            const { data: matchedConns } = await sb
              .from('connections')
              .select('id, user1_id, user2_id, user1_agent_id, user2_agent_id, user1_agent_name, user2_agent_name')
              .in('id', Array.from(potentialConnIds));
            if (matchedConns) {
              matchedConns.forEach((c: any) => {
                const isU1 = c.user1_id === targetUserId || (c.user1_agent_id && c.user1_agent_id.toLowerCase() === targetAgentId.toLowerCase());
                const peerAid = isU1 ? c.user2_agent_id : c.user1_agent_id;
                const peerUid = isU1 ? c.user2_id : c.user1_id;
                const peerName = isU1 ? c.user2_agent_name : c.user1_agent_name;
                connLookupMap[c.id] = { peerAid, peerUid, peerName };
                if (peerAid) targetAgentIds.add(peerAid);
                if (peerUid) targetAgentIds.add(peerUid);
              });
            }
          } catch (e) {}
        }

        const userMap: Record<string, any> = {};
        if (targetUserRec?.id) {
          userMap[targetUserRec.id] = targetUserRec;
          if (targetUserRec.agentId) {
            userMap[targetUserRec.agentId] = targetUserRec;
            userMap[targetUserRec.agentId.toLowerCase()] = targetUserRec;
          }
        }
        if (targetAgentIds.size > 0) {
          try {
            const matchedUsers = await fetchUsersByIdsOrAgentIds(sb, Array.from(targetAgentIds));
            matchedUsers.forEach((u: any) => {
              userMap[u.id] = u;
              if (u.agentId) {
                userMap[u.agentId] = u;
                userMap[u.agentId.toLowerCase()] = u;
              }
            });
          } catch (e) {}
        }

        footprints = authorizedData.map((item: any) => {
          const actionUpper = String(item.action || '').toUpperCase();
          const tgt = (item.target || '').trim();
          const connInfo = connLookupMap[tgt];

          const rawRowAgentId = item.agent_id && !['AGENT', 'MASTER'].includes(String(item.agent_id).trim().toUpperCase())
            ? String(item.agent_id).trim().replace(/^@+/, '')
            : '';
          const actorUser =
            (item.user_id && userMap[item.user_id]) ||
            (rawRowAgentId && (userMap[rawRowAgentId] || userMap[rawRowAgentId.toLowerCase()])) ||
            targetUserRec ||
            null;
          const actorAgentId = actorUser?.agentId || rawRowAgentId || targetUserRec?.agentId || (targetAgentId && targetAgentId !== targetUserId ? targetAgentId : undefined);
          const actorAgentName = (actorUser?.name && !['Agent', 'AGENT', 'Master'].includes(actorUser.name))
            ? actorUser.name
            : (targetUserRec?.name || actorAgentId || undefined);
          const rawActorAvatar = actorUser?.avatar || targetUserRec?.avatar;
          const actorAvatar = (rawActorAvatar && rawActorAvatar !== '🤖' && rawActorAvatar !== '👾') ? rawActorAvatar : undefined;

          let resolvedTargetAgentId = item.target_agent_id || (connInfo ? connInfo.peerAid : null);

          if (!resolvedTargetAgentId) {
            let str = '';
            if (typeof item.details === 'string') str = item.details;
            else if (item.details && typeof item.details === 'object') str = item.details.message || item.details.targetAgentId || item.details.receiverAgentId || '';
            const extracted = extractPeerHandleFromText(str);
            if (extracted) {
              resolvedTargetAgentId = extracted;
            }
          }

          if (!resolvedTargetAgentId && tgt && !tgt.toLowerCase().startsWith('req_') && !tgt.toLowerCase().startsWith('post_') && !tgt.toLowerCase().startsWith('cluster_') && !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(tgt)) {
            resolvedTargetAgentId = tgt;
          }

          const targetUser = resolvedTargetAgentId ? (userMap[resolvedTargetAgentId] || userMap[resolvedTargetAgentId.toLowerCase()]) : (connInfo?.peerUid ? userMap[connInfo.peerUid] : null);
          let finalAgentId = targetUser?.agentId || resolvedTargetAgentId || undefined;
          let finalAgentName = targetUser?.name || connInfo?.peerName || finalAgentId || undefined;
          let finalAvatar = (targetUser?.avatar && targetUser.avatar !== '🤖' && targetUser.avatar !== '👾') ? targetUser.avatar : undefined;

          if (!finalAgentId && isSelfAccountFootprintAction(actionUpper)) {
            finalAgentId = actorAgentId;
            finalAgentName = actorAgentName;
            finalAvatar = actorAvatar;
          }

          return {
            id: item.id,
            action: item.action,
            endpoint: item.endpoint || (item.method && item.path ? `${item.method} ${item.path}` : (typeof item.details === 'string' && item.details.match(/\((GET|POST|PUT|PATCH|DELETE)\s+([^)]+)\)/i) ? `${RegExp.$1.toUpperCase()} ${RegExp.$2}` : getEndpointForAction(item.action, item.target))),
            details: item.details || item.content,
            target: finalAgentId || item.target || item.target_agent_id,
            rawTarget: item.target || undefined,
            targetAgentId: finalAgentId,
            targetAgentName: finalAgentName,
            targetAvatar: finalAvatar,
            agentId: actorAgentId,
            agentName: actorAgentName,
            avatar: actorAvatar,
            actorAgentId,
            actorAgentName,
            actorAvatar,
            timestamp: item.created_at || item.createdAt || item.timestamp
          };
        });
      }
    } catch (e) {
      // Table may not exist yet in Supabase
    }

    // Deduplicate against already persisted footprints using deterministic composite keys + entity IDs
    const seenKeys = new Set<string>();
    footprints.forEach(f => {
      const act = String(f.action || '').toUpperCase();
      const canonAct = (act === 'CONNECTED' || act === 'CONNECTION_ACCEPTED') ? 'CONNECTION_ESTABLISHED' : act;
      if (canonAct && f.target) seenKeys.add(`${canonAct}:${String(f.target).toLowerCase()}`);
      if (canonAct && f.rawTarget) seenKeys.add(`${canonAct}:${String(f.rawTarget).toLowerCase()}`);
      if (canonAct && f.targetAgentId) seenKeys.add(`${canonAct}:${String(f.targetAgentId).toLowerCase()}`);
      if (f.id) {
        seenKeys.add(f.id);
        const cleanEntityId = String(f.id).replace(/^(fp_wt_msg_|fp_wt_conn_|wt_msg_|wt_conn_|fp_conn_|fp_msg_|fp_)/i, '');
        if (cleanEntityId) {
          seenKeys.add(`${canonAct}:${cleanEntityId.toLowerCase()}`);
        }
      }
    });

    const dynamicFootprints: any[] = [];

    // 3. Fetch user's established connections
    try {
      const { data: conns } = await sb
        .from('connections')
        .select('id, user1_agent_id, user2_agent_id, user1_id, user2_id, user1_agent_name, user2_agent_name, createdAt')
        .or(`user1_id.eq.${targetUserId},user2_id.eq.${targetUserId},user1_agent_id.ilike.${targetAgentId},user2_agent_id.ilike.${targetAgentId}`)
        .neq('status', 'dissolved')
        .order('createdAt', { ascending: false })
        .limit(30);
      if (conns && conns.length > 0) {
        const peerLookupIds = new Set<string>();
        conns.forEach((c: any) => {
          const u1 = c.user1_id || c.postOwnerUserId;
          const a1 = c.user1_agent_id || c.postOwnerAgentId;
          const u2 = c.user2_id || c.replyAuthorUserId;
          const a2 = c.user2_agent_id || c.replyAuthorAgentId;
          const isU1 = u1 === targetUserId || (a1 && a1.toLowerCase() === targetAgentId.toLowerCase());
          const peerUid = isU1 ? u2 : u1;
          const peerAid = isU1 ? a2 : a1;
          if (peerUid) peerLookupIds.add(peerUid);
          if (peerAid) peerLookupIds.add(peerAid);
        });

        const connUserMap: Record<string, any> = {};
        if (peerLookupIds.size > 0) {
          try {
            const pUsers = await fetchUsersByIdsOrAgentIds(sb, Array.from(peerLookupIds));
            pUsers.forEach((u: any) => {
              connUserMap[u.id] = u;
              if (u.agentId) connUserMap[u.agentId.toLowerCase()] = u;
            });
          } catch (e) {}
        }

        conns.forEach((c: any) => {
          const u1 = c.user1_id || c.postOwnerUserId;
          const a1 = c.user1_agent_id || c.postOwnerAgentId;
          const u2 = c.user2_id || c.replyAuthorUserId;
          const a2 = c.user2_agent_id || c.replyAuthorAgentId;
          const isU1 = u1 === targetUserId || (a1 && a1.toLowerCase() === targetAgentId.toLowerCase());
          const peerAid = isU1 ? a2 : a1;
          const peerUid = isU1 ? u2 : u1;
          const peerNameFallback = isU1 ? c.user2_agent_name : c.user1_agent_name;
          const peerUser = connUserMap[peerUid] || (peerAid ? connUserMap[peerAid.toLowerCase()] : null);

          const finalPeerAgentId = peerUser?.agentId || peerAid || 'peer_node';
          const finalPeerName = peerUser?.name || peerNameFallback || finalPeerAgentId;
          const finalPeerAvatar = peerUser?.avatar;

          const idKey = `CONNECTION_ESTABLISHED:${String(c.id).toLowerCase()}`;
          const peerKey = `CONNECTION_ESTABLISHED:${String(finalPeerAgentId).toLowerCase()}`;
          if (!seenKeys.has(idKey) && !seenKeys.has(peerKey)) {
            seenKeys.add(idKey);
            seenKeys.add(peerKey);

            dynamicFootprints.push({
              id: `fp_conn_${c.id}`,
              action: 'CONNECTION_ESTABLISHED',
              endpoint: 'POST /api/connections',
              target: finalPeerAgentId,
              targetAgentId: finalPeerAgentId,
              targetAgentName: finalPeerName,
              targetAvatar: finalPeerAvatar,
              details: `Established link with agent ${finalPeerAgentId}`,
              timestamp: c.createdAt
            });
          }
        });
      }
    } catch (e) {}

    // 4. Sent messages
    try {
      const [msgsByUserRes, msgsByAgentRes] = await Promise.all([
        sb.from('messages').select('id, connectionId, createdAt').eq('senderUserId', targetUserId).order('createdAt', { ascending: false }).limit(30),
        targetAgentId
          ? sb.from('messages').select('id, connectionId, createdAt').ilike('senderAgentId', targetAgentId).order('createdAt', { ascending: false }).limit(30)
          : Promise.resolve({ data: [], error: null })
      ]);
      const msgMap = new Map<string, any>();
      for (const m of [...(msgsByUserRes.data || []), ...(msgsByAgentRes.data || [])]) {
        if (m?.id) msgMap.set(m.id, m);
      }
      const sentMsgs = Array.from(msgMap.values())
        .sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime())
        .slice(0, 30);
      if (sentMsgs.length > 0) {
        const cIds = Array.from(new Set(sentMsgs.map((m: any) => m.connectionId).filter(Boolean)));
        let connsMap: Record<string, any> = {};
        if (cIds.length > 0) {
          try {
            const { data: mConns } = await sb
              .from('connections')
              .select('id, user1_id, user2_id, user1_agent_id, user2_agent_id, user1_agent_name, user2_agent_name')
              .in('id', cIds);
            if (mConns) {
              mConns.forEach((c: any) => { connsMap[c.id] = c; });
            }
          } catch (e) {}
        }

        sentMsgs.forEach((m: any) => {
          const key = `MESSAGE_SENT:${String(m.id).toLowerCase()}`;
          if (!seenKeys.has(key)) {
            seenKeys.add(key);
            const c = connsMap[m.connectionId];
            let peerAid: string | undefined;
            let peerName: string | undefined;
            if (c) {
              const isU1 = c.user1_id === targetUserId || (c.user1_agent_id && c.user1_agent_id.toLowerCase() === targetAgentId.toLowerCase());
              peerAid = isU1 ? c.user2_agent_id : c.user1_agent_id;
              peerName = isU1 ? c.user2_agent_name : c.user1_agent_name;
            }
            dynamicFootprints.push({
              id: `fp_msg_${m.id}`,
              action: 'MESSAGE_SENT',
              endpoint: `POST /api/connections/${m.connectionId}/messages`,
              target: peerAid || m.connectionId,
              targetAgentId: peerAid,
              targetAgentName: peerName || peerAid,
              details: 'Transmitted secure end-to-end encrypted payload',
              timestamp: m.createdAt
            });
          }
        });
      }
    } catch (e) {}

    // 5. Submitted reviews
    try {
      const [revByUserRes, revByAgentRes] = await Promise.all([
        sb.from('reviews').select('id, connectionId, targetAgentId, comment, createdAt').eq('reviewerUserId', targetUserId).order('createdAt', { ascending: false }).limit(30),
        targetAgentId
          ? sb.from('reviews').select('id, connectionId, targetAgentId, comment, createdAt').ilike('reviewerAgentId', targetAgentId).order('createdAt', { ascending: false }).limit(30)
          : Promise.resolve({ data: [], error: null })
      ]);
      const revMap = new Map<string, any>();
      for (const r of [...(revByUserRes.data || []), ...(revByAgentRes.data || [])]) {
        if (r?.id) revMap.set(r.id, r);
      }
      const submittedReviews = Array.from(revMap.values())
        .sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime())
        .slice(0, 30);
      if (submittedReviews.length > 0) {
        const revAgentIds = Array.from(new Set(submittedReviews.map((r: any) => r.targetAgentId).filter(Boolean)));
        const revUserMap: Record<string, any> = {};
        if (revAgentIds.length > 0) {
          try {
            const { data: rUsers } = await sb.from('users').select('agentId, name, avatar').in('agentId', revAgentIds);
            if (rUsers) {
              rUsers.forEach((u: any) => { revUserMap[u.agentId] = u; });
            }
          } catch (e) {}
        }
        submittedReviews.forEach((rev: any) => {
          const key = `PEER_REVIEW:${rev.id}`;
          if (!seenKeys.has(key)) {
            seenKeys.add(key);
            const u = revUserMap[rev.targetAgentId];
            dynamicFootprints.push({
              id: `fp_rev_${rev.id}`,
              action: 'PEER_REVIEW',
              endpoint: 'POST /api/reviews',
              target: rev.targetAgentId || rev.connectionId,
              targetAgentId: rev.targetAgentId,
              targetAgentName: u?.name || rev.targetAgentId,
              targetAvatar: u?.avatar,
              details: `Submitted review for agent ${rev.targetAgentId}`,
              timestamp: rev.createdAt
            });
          }
        });
      }
    } catch (e) {}

    // 6. Created clusters
    try {
      const [clByUserRes, clByAgentRes] = await Promise.all([
        sb.from(clusterTables.clusters).select('id, name, createdAt, ownerAgentId').eq('ownerUserId', targetUserId).order('createdAt', { ascending: false }).limit(30),
        targetAgentId
          ? sb.from(clusterTables.clusters).select('id, name, createdAt, ownerAgentId').ilike('ownerAgentId', targetAgentId).order('createdAt', { ascending: false }).limit(30)
          : Promise.resolve({ data: [], error: null })
      ]);
      const clMap = new Map<string, any>();
      for (const cl of [...(clByUserRes.data || []), ...(clByAgentRes.data || [])]) {
        if (cl?.id) clMap.set(cl.id, cl);
      }
      const createdClusters = Array.from(clMap.values())
        .sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime())
        .slice(0, 30);
      if (createdClusters.length > 0) {
        createdClusters.forEach((cl: any) => {
          const key = `CLUSTER_CREATED:${cl.id}`;
          if (!seenKeys.has(key)) {
            seenKeys.add(key);
            dynamicFootprints.push({
              id: `fp_cl_create_${cl.id}`,
              action: 'CLUSTER_CREATED',
              endpoint: 'POST /api/clusters',
              target: cl.id,
              targetAgentId: cl.ownerAgentId || targetAgentId,
              targetAgentName: cl.name,
              details: `Provisioned cluster enclave "${cl.name}"`,
              timestamp: cl.createdAt || cl.created_at || new Date().toISOString()
            });
          }
        });
      }
    } catch (e) {}

    // 7. Agent node identity initialization footprint
    try {
      const userRec = targetUserRec;
      if (userRec) {
        const key = `PROFILE_INITIALIZED:${userRec.id}`;
        if (!seenKeys.has(key)) {
          seenKeys.add(key);
          const cleanAvatar = (userRec.avatar && userRec.avatar !== '🤖' && userRec.avatar !== '👾') ? userRec.avatar : undefined;
          dynamicFootprints.push({
            id: `fp_init_${userRec.id}`,
            action: 'PROFILE_UPDATED',
            endpoint: 'PATCH /api/agents/me',
            target: userRec.agentId || userRec.id,
            targetAgentId: userRec.agentId,
            targetAgentName: userRec.name,
            targetAvatar: cleanAvatar,
            agentId: userRec.agentId,
            agentName: userRec.name,
            avatar: cleanAvatar,
            actorAgentId: userRec.agentId,
            actorAgentName: userRec.name,
            actorAvatar: cleanAvatar,
            details: `Initialized autonomous agent node identity @${userRec.agentId || 'agent'}`,
            timestamp: userRec.createdAt || userRec.created_at || new Date().toISOString()
          });
        }
      }
    } catch (e) {}

    // Merge and sort
    footprints = [...footprints, ...dynamicFootprints];
    footprints.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    footprints = footprints.slice(0, 50);

    // Strict Privacy Requirement: Never manufacture fake activity (e.g. fp_initial).
    // If an agent has no recorded activity, return an empty array.

    res.json({ success: true, data: footprints });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to fetch agent footprints.' });
  }
});

// 27. GET /api/webhooks/events (Fetch inbound external events - Master fleet-restricted, Sub account-restricted)
router.get('/webhooks/events', requireUserOrAgentAuth, securityLayer('public_reads'), async (req: AuthenticatedRequest, res: Response) => {
  try {
    const sb = getSupabaseClient();
    const { callerUserId, callerAgentId, callerMasterId, callerFleetId, isSlave } = await resolveTelemetryCallerContext(req);

    const targetAgentHeader = req.headers['x-target-agent-id'] as string | undefined;
    const queryAgentId = (targetAgentHeader || req.query.agentId || req.query.agent_id) as string | undefined;
    const queryUserId = (req.query.userId || req.query.user_id) as string | undefined;

    let targetUserId = callerUserId;
    let targetAgentId = callerAgentId;

    const requestedTarget = (queryAgentId || queryUserId || '').trim();

    if (requestedTarget) {
      const isTargetSelf = 
        requestedTarget.toLowerCase() === callerUserId.toLowerCase() ||
        requestedTarget.toLowerCase() === callerAgentId.toLowerCase();

      if (isSlave) {
        // A slave agent may access ONLY its own inbound webhook activity
        if (!isTargetSelf) {
          return res.status(403).json({
            success: false,
            error: {
              code: 'UNAUTHORIZED',
              message: 'Unauthorized: Slave agents cannot access activity records of other accounts.'
            }
          });
        }
      } else {
        // Master account: can access self or subordinate agents within its own fleet
        if (!isTargetSelf) {
          let slaveMatch: any = null;
          const { data: matchById } = await sb
            .from('users')
            .select('id, agentId, master_id, fleet_id')
            .eq('id', requestedTarget)
            .maybeSingle();
          slaveMatch = matchById;
          if (!slaveMatch) {
            const { data: matchByAgentId } = await sb
              .from('users')
              .select('id, agentId, master_id, fleet_id')
              .ilike('agentId', requestedTarget.replace(/^@+/, ''))
              .maybeSingle();
            slaveMatch = matchByAgentId;
          }

          const inFleet = Boolean(
            slaveMatch && (
              slaveMatch.id === callerUserId ||
              slaveMatch.master_id === callerUserId ||
              slaveMatch.master_id === callerMasterId ||
              (callerFleetId && slaveMatch.fleet_id && slaveMatch.fleet_id === callerFleetId)
            )
          );
          if (!slaveMatch || !inFleet) {
            return res.status(403).json({
              success: false,
              error: {
                code: 'UNAUTHORIZED',
                message: 'Unauthorized: Cannot access activity records outside your fleet.'
              }
            });
          }
          targetUserId = slaveMatch.id;
          targetAgentId = slaveMatch.agentId || slaveMatch.id;
        }
      }
    }

    let events: any[] = [];
    const clusterTables = await getClusterTables(sb);
    let rawFetchedEvents: any[] = [];
    try {
      if (targetUserId === callerUserId) {
        const { data } = await sb
          .from('external_events')
          .select('*')
          .eq('user_id', targetUserId)
          .order('created_at', { ascending: false })
          .limit(100);
        rawFetchedEvents = data || [];
      } else {
        // Master querying Slave webhooks: fetch slave's own inbound events AND master's targeted events in parallel
        // using separate safe filters so missing optional columns (like details) never abort the query.
        const [slaveEventsRes, masterByTargetIdRes, masterByTargetAgentRes, masterByDetailsUidRes, masterByDetailsAidRes, masterRecentRes] = await Promise.all([
          sb.from('external_events').select('*').eq('user_id', targetUserId).order('created_at', { ascending: false }).limit(100),
          sb.from('external_events').select('*').eq('user_id', callerUserId).eq('target_id', targetUserId).order('created_at', { ascending: false }).limit(100),
          targetAgentId
            ? sb.from('external_events').select('*').eq('user_id', callerUserId).ilike('target_id', targetAgentId).order('created_at', { ascending: false }).limit(100)
            : Promise.resolve({ data: [] }),
          sb.from('external_events').select('*').eq('user_id', callerUserId).ilike('details', `%${targetUserId}%`).order('created_at', { ascending: false }).limit(50),
          targetAgentId
            ? sb.from('external_events').select('*').eq('user_id', callerUserId).ilike('details', `%${targetAgentId}%`).order('created_at', { ascending: false }).limit(50)
            : Promise.resolve({ data: [] }),
          sb.from('external_events').select('*').eq('user_id', callerUserId).order('created_at', { ascending: false }).limit(50)
        ]);

        const combinedMap = new Map<string, any>();
        for (const row of [
          ...(slaveEventsRes.data || []),
          ...(masterByTargetIdRes.data || []),
          ...(masterByTargetAgentRes.data || []),
          ...(masterByDetailsUidRes.data || []),
          ...(masterByDetailsAidRes.data || []),
          ...(masterRecentRes.data || [])
        ]) {
          if (row?.id) combinedMap.set(row.id, row);
        }

        rawFetchedEvents = Array.from(combinedMap.values());
        rawFetchedEvents.sort((a, b) => new Date(b.created_at || b.createdAt || 0).getTime() - new Date(a.created_at || a.createdAt || 0).getTime());
      }

      if (rawFetchedEvents.length > 0) {
        // Enforce strict account isolation with structured recipient validation
        const authorizedData = rawFetchedEvents.filter((item: any) => {
          if (item.user_id === targetUserId) {
            return true;
          }
          if (targetUserId !== callerUserId && item.user_id === callerUserId) {
            // Master-originated event: include ONLY if structured fields confirm it targets/affects this requested slave
            const targetIdMatch = Boolean(
              item.target_id && typeof item.target_id === 'string' && (
                item.target_id === targetUserId ||
                item.target_id.toLowerCase() === targetAgentId.toLowerCase()
              )
            );

            let detailsObj: any = item.details;
            if (typeof detailsObj === 'string') {
              try { detailsObj = JSON.parse(detailsObj); } catch (e) {}
            }

            const detailsObjMatch = Boolean(
              detailsObj && typeof detailsObj === 'object' && (
                (Array.isArray(detailsObj.target_account_ids) && detailsObj.target_account_ids.some((id: any) => typeof id === 'string' && (id === targetUserId || id.toLowerCase() === targetAgentId.toLowerCase()))) ||
                (Array.isArray(detailsObj.target_accounts) && detailsObj.target_accounts.some((acc: any) => acc && typeof acc === 'object' && ((acc.id && acc.id === targetUserId) || (acc.agent_id && typeof acc.agent_id === 'string' && acc.agent_id.toLowerCase() === targetAgentId.toLowerCase()) || (acc.agentId && typeof acc.agentId === 'string' && acc.agentId.toLowerCase() === targetAgentId.toLowerCase())))) ||
                (typeof detailsObj.slave_id === 'string' && detailsObj.slave_id === targetUserId) ||
                (typeof detailsObj.slaveId === 'string' && detailsObj.slaveId === targetUserId) ||
                (typeof detailsObj.targetAgentId === 'string' && detailsObj.targetAgentId.toLowerCase() === targetAgentId.toLowerCase()) ||
                (typeof detailsObj.targetUserId === 'string' && detailsObj.targetUserId === targetUserId) ||
                (typeof detailsObj.agentId === 'string' && detailsObj.agentId.toLowerCase() === targetAgentId.toLowerCase())
              )
            );

            return Boolean(targetIdMatch || detailsObjMatch);
          }
          return false;
        }).slice(0, 100);

        const outboundActions = [
          'POST_DELETED', 'REPLY_DELETED',
          'CONNECTION_ESTABLISHED', 'CONNECTION_REMOVED', 'CONNECTION_REQUEST_SENT',
          'CONNECTION_REJECTED', 'CONNECTION_REQUEST_ACCEPTED', 'COUNTER_PARTY_REVIEW', 'PEER_REVIEW',
          'MESSAGE_SENT', 'CLUSTER_MESSAGE_SENT', 'CLUSTER_CREATED'
        ];

        // Collect all IDs to resolve
        const idsToResolve = new Set<string>();
        authorizedData.forEach((item: any) => {
          let detailsObj: any = item.details;
          if (typeof detailsObj === 'string') {
            try { detailsObj = JSON.parse(detailsObj); } catch (e) {}
          }
          if (item.sender_id) idsToResolve.add(item.sender_id);
          if (item.target_id) idsToResolve.add(item.target_id);
          if (detailsObj?.user_id) idsToResolve.add(detailsObj.user_id);
          if (detailsObj?.agent_id) idsToResolve.add(detailsObj.agent_id);
          if (detailsObj?.targetAgentId) idsToResolve.add(detailsObj.targetAgentId);
          if (detailsObj?.senderAgentId) idsToResolve.add(detailsObj.senderAgentId);
          if (Array.isArray(detailsObj?.target_account_ids)) {
            detailsObj.target_account_ids.forEach((id: string) => idsToResolve.add(id));
          }
          if (Array.isArray(detailsObj?.target_accounts)) {
            detailsObj.target_accounts.forEach((acc: any) => {
              if (acc.id) idsToResolve.add(acc.id);
              if (acc.agent_id) idsToResolve.add(acc.agent_id);
            });
          }
        });

        const usersMap: Record<string, any> = {};
        if (idsToResolve.size > 0) {
          try {
            const matchedUsers = await fetchUsersByIdsOrAgentIds(sb, Array.from(idsToResolve));
            matchedUsers.forEach((u: any) => {
              usersMap[u.id] = u;
              if (u.agentId) {
                usersMap[u.agentId] = u;
                usersMap[u.agentId.toLowerCase()] = u;
              }
            });
          } catch (e) {}
        }
        
        events = authorizedData
          .filter((item: any) => {
            if (outboundActions.includes(item.type)) return false;
            // Inbound webhook event must strictly represent activity received from external peers or systems
            const sender = (item.sender_id || item.senderId || '').toLowerCase();
            if (sender && (sender === targetAgentId.toLowerCase() || sender === targetUserId.toLowerCase())) {
              return false;
            }
            return true;
          })
          .map((item: any) => {
            let detailsObj: any = item.details;
            if (typeof detailsObj === 'string') {
              try { detailsObj = JSON.parse(detailsObj); } catch (e) {}
            }

            const rawSender = item.sender_id || item.senderId;
            const senderUser = rawSender ? (usersMap[rawSender] || usersMap[rawSender.toLowerCase()]) : null;

            let resolvedTargetAgentId: string | undefined = undefined;
            let resolvedTargetName: string | undefined = undefined;
            let resolvedTargetAvatar: string | undefined = undefined;

            if (item.type === 'SLAVE_CAPABILITY_BATCH_ACTIVATED' || item.type === 'SLAVE_CAPABILITY_ACTIVATED') {
              let candidateAcc: any = null;
              if (Array.isArray(detailsObj?.target_accounts) && detailsObj.target_accounts.length > 0) {
                candidateAcc = detailsObj.target_accounts.find((a: any) => 
                  (a.agent_id && a.agent_id.toLowerCase() === targetAgentId.toLowerCase()) ||
                  (a.id && a.id === targetUserId)
                ) || detailsObj.target_accounts[0];
              }

              if (candidateAcc) {
                const u = usersMap[candidateAcc.id] || (candidateAcc.agent_id ? usersMap[candidateAcc.agent_id.toLowerCase()] : null);
                resolvedTargetAgentId = candidateAcc.agent_id || u?.agentId || candidateAcc.id;
                resolvedTargetName = u?.name || candidateAcc.name || resolvedTargetAgentId;
                resolvedTargetAvatar = u?.avatar || candidateAcc.avatar;
              } else if (item.target_id || detailsObj?.agent_id) {
                const candId = detailsObj?.agent_id || item.target_id;
                const u = usersMap[candId] || usersMap[candId.toLowerCase()];
                resolvedTargetAgentId = u?.agentId || candId;
                resolvedTargetName = u?.name || resolvedTargetAgentId;
                resolvedTargetAvatar = u?.avatar;
              }
            } else if (item.target_id) {
              const u = usersMap[item.target_id] || usersMap[item.target_id.toLowerCase()];
              resolvedTargetAgentId = u?.agentId || item.target_id;
              resolvedTargetName = u?.name || resolvedTargetAgentId;
              resolvedTargetAvatar = u?.avatar;
            }

            return {
              id: item.id,
              type: item.type || item.event_type,
              category: 'event',
              senderId: senderUser?.agentId || rawSender,
              senderAgentId: senderUser?.agentId || rawSender,
              senderAgentName: senderUser?.name,
              senderAvatar: senderUser?.avatar,
              targetId: resolvedTargetAgentId || item.target_id || item.targetId,
              targetAgentId: resolvedTargetAgentId,
              targetAgentName: resolvedTargetName,
              targetAvatar: resolvedTargetAvatar,
              details: (detailsObj && typeof detailsObj === 'object') ? detailsObj : (item.details || item.content),
              timestamp: item.created_at || item.createdAt || item.timestamp
            };
          });
      }
    } catch (e) {
      // Table may not exist yet in Supabase
    }

    const seenEventKeys = new Set<string>();
    events.forEach(e => {
      if (e.type && e.targetId) seenEventKeys.add(`${e.type}:${e.targetId}`);
      if (e.type && e.senderId && e.timestamp) seenEventKeys.add(`${e.type}:${e.senderId}:${e.timestamp}`);
      if (e.type && e.senderId && e.targetId) seenEventKeys.add(`${e.type}:${e.targetId}:${String(e.senderId).toLowerCase()}`);
      if (e.id) seenEventKeys.add(e.id);
      let det: any = e.details;
      if (typeof det === 'string') {
        try { det = JSON.parse(det); } catch {}
      }
      if (det && typeof det === 'object') {
        const entityRef = det.messageId || det.connectionId || det.connection_id || det.clusterId || det.cluster_id;
        if (e.type && entityRef) {
          seenEventKeys.add(`${e.type}:${entityRef}`);
        }
      }
    });

    const dynamicEvents: any[] = [];

    // 1. Inbound connection requests received by this agent
    try {
      // Connection requests are retired.
    } catch (e) {}

    // 2. Incoming connection acceptances
    try {
      let conns: any[] = [];
      const { data: c1, error: e1 } = await sb
        .from('connections')
        .select('id, user1_id, user2_id, user1_agent_id, user2_agent_id, user1_agent_name, user2_agent_name, createdAt, created_at')
        .or(`user1_id.eq.${targetUserId},user2_id.eq.${targetUserId},user1_agent_id.ilike.${targetAgentId},user2_agent_id.ilike.${targetAgentId}`)
        .neq('status', 'dissolved')
        .order('createdAt', { ascending: false })
        .limit(30);
      if (!e1 && c1) {
        conns = c1;
      }
      if (conns && conns.length > 0) {
        const peerLookupIds = new Set<string>();
        conns.forEach((c: any) => {
          const u1 = c.user1_id || c.postOwnerUserId;
          const a1 = c.user1_agent_id || c.postOwnerAgentId;
          const u2 = c.user2_id || c.replyAuthorUserId;
          const a2 = c.user2_agent_id || c.replyAuthorAgentId;
          const isMeU1 = u1 === targetUserId || (a1 && a1.toLowerCase() === targetAgentId.toLowerCase());
          const peerUid = isMeU1 ? u2 : u1;
          const peerAid = isMeU1 ? a2 : a1;
          if (peerUid) peerLookupIds.add(peerUid);
          if (peerAid) peerLookupIds.add(peerAid);
        });

        const connUserMap: Record<string, any> = {};
        if (peerLookupIds.size > 0) {
          try {
            const pUsers = await fetchUsersByIdsOrAgentIds(sb, Array.from(peerLookupIds));
            pUsers.forEach((u: any) => {
              connUserMap[u.id] = u;
              if (u.agentId) connUserMap[u.agentId.toLowerCase()] = u;
            });
          } catch (e) {}
        }

        conns.forEach((c: any) => {
          const u1 = c.user1_id || c.postOwnerUserId;
          const a1 = c.user1_agent_id || c.postOwnerAgentId;
          const u2 = c.user2_id || c.replyAuthorUserId;
          const a2 = c.user2_agent_id || c.replyAuthorAgentId;
          const isMeU1 = u1 === targetUserId || (a1 && a1.toLowerCase() === targetAgentId.toLowerCase());
          const isMeU2 = u2 === targetUserId || (a2 && a2.toLowerCase() === targetAgentId.toLowerCase());
          
          const peerAid = isMeU1 ? a2 : a1;
          const peerUid = isMeU1 ? u2 : u1;
          const peerNameFallback = isMeU1 ? c.user2_agent_name : c.user1_agent_name;
          const peerUser = connUserMap[peerUid] || (peerAid ? connUserMap[peerAid.toLowerCase()] : null);
          const finalPeerAgentId = peerUser?.agentId || peerAid || 'peer_node';
          const finalPeerName = peerUser?.name || peerNameFallback || finalPeerAgentId;
          const finalPeerAvatar = peerUser?.avatar;

          const key = `CONNECTION_ACCEPTED_BY_TARGET:${c.id}`;
          if (!seenEventKeys.has(key)) {
            seenEventKeys.add(key);
            dynamicEvents.push({
              id: `evt_conn_${c.id}`,
              type: 'CONNECTION_ACCEPTED_BY_TARGET',
              senderId: finalPeerAgentId,
              senderAgentId: finalPeerAgentId,
              senderAgentName: finalPeerName,
              senderAvatar: finalPeerAvatar,
              targetId: c.id,
              details: `Peer agent @${finalPeerAgentId} established connection link`,
              timestamp: c.createdAt || c.created_at
            });
          }
        });
      }
    } catch (e) {}

    // 3. Incoming messages on user's active connections
    try {
      const { data: userConns } = await sb
        .from('connections')
        .select('id, user1_id, user2_id, user1_agent_id, user2_agent_id, user1_agent_name, user2_agent_name')
        .or(`user1_id.eq.${targetUserId},user2_id.eq.${targetUserId},user1_agent_id.ilike.${targetAgentId},user2_agent_id.ilike.${targetAgentId}`);
      if (userConns && userConns.length > 0) {
        const connIds = userConns.map((c: any) => c.id);
        const { data: incomingMsgs } = await sb
          .from('messages')
          .select('id, connectionId, senderUserId, senderAgentId, createdAt')
          .in('connectionId', connIds)
          .neq('senderUserId', targetUserId)
          .order('createdAt', { ascending: false })
          .limit(30);
        if (incomingMsgs && incomingMsgs.length > 0) {
          const senderIds = Array.from(new Set<string>(incomingMsgs.map((m: any) => String(m.senderUserId || m.senderAgentId || '').trim()).filter(Boolean)));
          const msgUserMap: Record<string, any> = {};
          if (senderIds.length > 0) {
            try {
              const mUsers = await fetchUsersByIdsOrAgentIds(sb, senderIds);
              mUsers.forEach((u: any) => {
                msgUserMap[u.id] = u;
                if (u.agentId) msgUserMap[u.agentId.toLowerCase()] = u;
              });
            } catch (e) {}
          }

          incomingMsgs.forEach((m: any) => {
            const key = `MESSAGE_RECEIVED:${m.id}`;
            if (!seenEventKeys.has(key)) {
              seenEventKeys.add(key);
              const u = msgUserMap[m.senderUserId] || (m.senderAgentId ? msgUserMap[m.senderAgentId.toLowerCase()] : null);
              const senderAid = u?.agentId || m.senderAgentId || m.senderUserId;
              const senderName = u?.name || senderAid;
              const senderAvatar = u?.avatar;

              dynamicEvents.push({
                id: `evt_msg_${m.id}`,
                type: 'MESSAGE_RECEIVED',
                senderId: senderAid,
                senderAgentId: senderAid,
                senderAgentName: senderName,
                senderAvatar: senderAvatar,
                targetId: m.connectionId,
                details: 'Encrypted telemetry transmission received from connected peer',
                timestamp: m.createdAt
              });
            }
          });
        }
      }
    } catch (e) {}

    // 4. Incoming peer reviews received by this agent
    try {
      const { data: incomingReviews } = await sb
        .from('reviews')
        .select('id, connectionId, reviewerAgentId, reviewerUserId, comment, createdAt')
        .ilike('targetAgentId', targetAgentId)
        .neq('reviewerUserId', targetUserId)
        .order('createdAt', { ascending: false })
        .limit(30);
      if (incomingReviews && incomingReviews.length > 0) {
        const revUserIds = Array.from(new Set<string>(incomingReviews.map((r: any) => String(r.reviewerUserId || r.reviewerAgentId || '').trim()).filter(Boolean)));
        const revUserMap: Record<string, any> = {};
        if (revUserIds.length > 0) {
          try {
            const rUsers = await fetchUsersByIdsOrAgentIds(sb, revUserIds);
            rUsers.forEach((u: any) => {
              revUserMap[u.id] = u;
              if (u.agentId) revUserMap[u.agentId.toLowerCase()] = u;
            });
          } catch (e) {}
        }

        incomingReviews.forEach((rev: any) => {
          const key = `PEER_REVIEW_RECEIVED:${rev.id}`;
          if (!seenEventKeys.has(key)) {
            seenEventKeys.add(key);
            const u = revUserMap[rev.reviewerUserId] || (rev.reviewerAgentId ? revUserMap[rev.reviewerAgentId.toLowerCase()] : null);
            const reviewerAid = u?.agentId || rev.reviewerAgentId;
            const reviewerName = u?.name || reviewerAid;
            const reviewerAvatar = u?.avatar;

            dynamicEvents.push({
              id: `evt_rev_${rev.id}`,
              type: 'PEER_REVIEW_RECEIVED',
              senderId: reviewerAid,
              senderAgentId: reviewerAid,
              senderAgentName: reviewerName,
              senderAvatar: reviewerAvatar,
              targetId: rev.connectionId,
              details: rev.comment ? (rev.comment.length > 60 ? rev.comment.slice(0, 60) + '...' : rev.comment) : 'Peer review received from network partner',
              timestamp: rev.createdAt
            });
          }
        });
      }
    } catch (e) {}

    // 6. Incoming cluster enclave messages from peers
    try {
      const [memByUserRes, memByAgentRes] = await Promise.all([
        sb.from(clusterTables.members).select('clusterId').eq('userId', targetUserId),
        targetAgentId
          ? sb.from(clusterTables.members).select('clusterId').ilike('agentId', targetAgentId)
          : Promise.resolve({ data: [] })
      ]);
      const clusterIdSet = new Set<string>();
      for (const m of [...(memByUserRes.data || []), ...(memByAgentRes.data || [])]) {
        if (m?.clusterId) clusterIdSet.add(m.clusterId);
      }
      if (clusterIdSet.size > 0) {
        const clusterIds = Array.from(clusterIdSet);
        const { data: incomingClusterMsgs } = await sb
          .from(clusterTables.messages)
          .select('id, clusterId, senderAgentId, senderUserId, createdAt')
          .in('clusterId', clusterIds)
          .neq('senderUserId', targetUserId)
          .order('createdAt', { ascending: false })
          .limit(30);
        if (incomingClusterMsgs && incomingClusterMsgs.length > 0) {
          const clSenderIds = Array.from(new Set<string>(incomingClusterMsgs.map((cm: any) => String(cm.senderUserId || cm.senderAgentId || '').trim()).filter(Boolean)));
          const clUserMap: Record<string, any> = {};
          if (clSenderIds.length > 0) {
            try {
              const cUsers = await fetchUsersByIdsOrAgentIds(sb, clSenderIds);
              cUsers.forEach((u: any) => {
                clUserMap[u.id] = u;
                if (u.agentId) clUserMap[u.agentId.toLowerCase()] = u;
              });
            } catch (e) {}
          }

          incomingClusterMsgs.forEach((cm: any) => {
            const key = `CLUSTER_MESSAGE_RECEIVED:${cm.id}`;
            if (!seenEventKeys.has(key)) {
              seenEventKeys.add(key);
              const u = clUserMap[cm.senderUserId] || (cm.senderAgentId ? clUserMap[cm.senderAgentId.toLowerCase()] : null);
              const clSenderAid = u?.agentId || cm.senderAgentId || cm.senderUserId;
              const clSenderName = u?.name || clSenderAid;
              const clSenderAvatar = u?.avatar;

              dynamicEvents.push({
                id: `evt_cl_msg_${cm.id}`,
                type: 'CLUSTER_MESSAGE_RECEIVED',
                senderId: clSenderAid,
                senderAgentId: clSenderAid,
                senderAgentName: clSenderName,
                senderAvatar: clSenderAvatar,
                targetId: cm.clusterId,
                details: 'Encrypted cluster enclave transmission received',
                timestamp: cm.createdAt || cm.created_at
              });
            }
          });
        }
      }
    } catch (e) {}

    // 7. Peer member joins & departures in user's clusters
    try {
      const [ownedByUserRes, ownedByAgentRes] = await Promise.all([
        sb.from(clusterTables.clusters).select('id').eq('ownerUserId', targetUserId),
        targetAgentId
          ? sb.from(clusterTables.clusters).select('id').ilike('ownerAgentId', targetAgentId)
          : Promise.resolve({ data: [] })
      ]);
      const ownedClusterIdSet = new Set<string>();
      for (const c of [...(ownedByUserRes.data || []), ...(ownedByAgentRes.data || [])]) {
        if (c?.id) ownedClusterIdSet.add(c.id);
      }
      if (ownedClusterIdSet.size > 0) {
        const ownedClusterIds = Array.from(ownedClusterIdSet);
        const { data: memberActivity } = await sb
          .from(clusterTables.members)
          .select('id, clusterId, agentId, userId, createdAt, status')
          .in('clusterId', ownedClusterIds)
          .neq('userId', targetUserId)
          .order('createdAt', { ascending: false })
          .limit(30);
        if (memberActivity && memberActivity.length > 0) {
          const memIds = Array.from(new Set<string>(memberActivity.map((ma: any) => String(ma.userId || ma.agentId || '').trim()).filter(Boolean)));
          const memUserMap: Record<string, any> = {};
          if (memIds.length > 0) {
            try {
              const mUsers = await fetchUsersByIdsOrAgentIds(sb, memIds);
              mUsers.forEach((u: any) => {
                memUserMap[u.id] = u;
                if (u.agentId) memUserMap[u.agentId.toLowerCase()] = u;
              });
            } catch (e) {}
          }

          memberActivity.forEach((ma: any) => {
            const isLeft = ma.status === 'dissolved' || ma.status === 'left';
            const eventType = isLeft ? 'CLUSTER_MEMBER_LEFT' : 'CLUSTER_MEMBER_JOINED';
            const u = memUserMap[ma.userId] || (ma.agentId ? memUserMap[ma.agentId.toLowerCase()] : null);
            const memAid = u?.agentId || ma.agentId || ma.userId;
            const memName = u?.name || memAid;
            const memAvatar = u?.avatar;
            const key = `${eventType}:${ma.id}`;
            const compositeKey = `${eventType}:${ma.clusterId}:${String(memAid || '').toLowerCase()}`;
            if (!seenEventKeys.has(key) && !seenEventKeys.has(compositeKey)) {
              seenEventKeys.add(key);
              seenEventKeys.add(compositeKey);

              dynamicEvents.push({
                id: `evt_cl_mem_${ma.id}`,
                type: eventType,
                senderId: memAid,
                senderAgentId: memAid,
                senderAgentName: memName,
                senderAvatar: memAvatar,
                targetId: ma.clusterId,
                details: isLeft ? 'Member exited cluster enclave' : 'New member joined cluster enclave',
                timestamp: ma.createdAt || ma.joinedAt || ma.joined_at || new Date().toISOString()
              });
            }
          });
        }
      }
    } catch (e) {}

    // Merge and sort
    events = [...events, ...dynamicEvents];
    events.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    events = events.slice(0, 50);

    res.json({ success: true, data: events });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to fetch webhook events.' });
  }
});



// Admin Auth Guard
const adminAuthGuard = (req: Request, res: Response, next: any) => {
  const adminSecret = process.env.ADMIN_SECRET_KEY;
  const providedKey = req.headers['x-admin-key'] || (req.headers['authorization'] as string)?.replace('Bearer ', '');
  const isInternal = req.ip === '127.0.0.1' || req.ip === '::1';
  if (isInternal) {
    return next();
  }
  if (adminSecret && typeof adminSecret === 'string' && adminSecret.trim().length > 0) {
    if (providedKey && providedKey === adminSecret) {
      return next();
    }
  }
  return res.status(403).json({ success: false, error: 'Access Denied: Missing or invalid x-admin-key authorization header.' });
};

// Admin Inventory Diagnostics & Seeding
router.get('/admin/inventory/status', adminAuthGuard, async (req: Request, res: Response) => {
  try {
    const stats = await getInventoryStats();
    res.json({ success: true, realtime: stats });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || String(err) });
  }
});

router.post('/admin/inventory/seed', adminAuthGuard, async (req: Request, res: Response) => {
  try {
    await ensureInventoryStock();
    const stats = await getInventoryStats();
    res.json({ success: true, message: `Stock replenished successfully. Current stock: ${stats.count}`, stats });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || String(err) });
  }
});

// ----------------------------------------------------
// AAMARVA Applications & Intake System Endpoints
// ----------------------------------------------------

// Check if an email is eligible to submit an application
router.get('/applications/check-email', async (req: Request, res: Response) => {
  try {
    const email = (req.query.email as string || '').trim().toLowerCase();
    if (!email) {
      return res.json({ success: true, allowed: true });
    }

    const existingList = await applicationService.getApplications();
    const applicationsForEmail = existingList.filter(
      app => (app.emailAddress || '').trim().toLowerCase() === email
    );

    const pending = applicationsForEmail.find(
      app => !app.status || app.status === 'Under Review'
    );
    if (pending) {
      return res.json({
        success: true,
        allowed: false,
        status: 'Under Review',
        message: 'An application for this email is currently under review. Re-applying is locked until a final decision is issued.'
      });
    }

    const approved = applicationsForEmail.find(app => app.status === 'Approved');
    if (approved) {
      return res.json({
        success: true,
        allowed: false,
        status: 'Approved',
        message: 'This email is already approved and whitelisted for registration.'
      });
    }

    // Allowed (either new email or previous application was Declined)
    return res.json({ success: true, allowed: true });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to verify email eligibility.' });
  }
});

// Submit a new application
router.post('/applications', async (req: Request, res: Response) => {
  try {
    const record = await applicationService.saveApplication(req.body);
    res.status(201).json({ success: true, record });
  } catch (err: any) {
    console.error('[APPLICATIONS_ROUTE_ERROR] Submit failed:', err);
    const status = err.statusCode || 500;
    res.status(status).json({ success: false, error: err?.message || 'Failed to submit application.' });
  }
});

// Middleware to enforce Admin Portal OTP JWT authorization on /applications/admin API routes
const requireAdminOperatorAuth = (req: Request, res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : '';
  if (!token) {
    return res.status(401).json({
      success: false,
      error: 'OTP Gateway Authorization Required: Please verify the 6-digit OTP sent to founder@aamarva.com.',
    });
  }
  try {
    const adminSecret = process.env.JWT_SECRET || 'aamarva-admin-super-key-2026';
    const decoded = jwt.verify(token, adminSecret) as any;
    if (!decoded || decoded.role !== 'admin_operator') {
      return res.status(403).json({
        success: false,
        error: 'Access Denied: Invalid admin operator token.',
      });
    }
    return next();
  } catch {
    return res.status(401).json({
      success: false,
      error: 'Admin session expired or invalid. Please re-authenticate via the OTP gateway.',
    });
  }
};

// Request 6-digit Admin Portal OTP (sends sendAdminOtpEmail strictly to founder@aamarva.com)
router.post(['/applications/admin/request-otp', '/appliactions/admin/request-otp'], async (req: Request, res: Response) => {
  try {
    const clientIp = String(req.ip || req.headers['x-forwarded-for'] || 'unknown');
    if (!applicationService.checkAdminAttempt(clientIp)) {
      return res.status(429).json({
        success: false,
        error: 'Too many failed verification attempts. Access locked for 24 hours.',
      });
    }

    const { email } = req.body || {};
    const normalizedEmail = typeof email === 'string' ? email.trim().toLowerCase() : 'founder@aamarva.com';
    if (normalizedEmail !== 'founder@aamarva.com') {
      return res.status(403).json({
        success: false,
        error: 'Access Denied: Only founder@aamarva.com is authorized for the Admin OTP Gateway.',
      });
    }

    await applicationService.generateAndSendOtp();
    return res.status(200).json({
      success: true,
      recipient: 'founder@aamarva.com',
      message: 'A 6-digit one-time passcode (OTP) has been dispatched to founder@aamarva.com.',
    });
  } catch (err: any) {
    console.error('[APPLICATIONS_ADMIN_OTP_REQUEST_ERROR]', err);
    return res.status(500).json({
      success: false,
      error: err?.message || 'Failed to dispatch Admin OTP email.',
    });
  }
});

// Verify 6-digit Admin Portal OTP
router.post(['/applications/admin/verify-otp', '/appliactions/admin/verify-otp'], async (req: Request, res: Response) => {
  try {
    const clientIp = String(req.ip || req.headers['x-forwarded-for'] || 'unknown');
    if (!applicationService.checkAdminAttempt(clientIp)) {
      return res.status(429).json({
        success: false,
        error: 'Too many failed verification attempts. Access locked for 24 hours.',
      });
    }

    const { code, otp } = req.body || {};
    const codeToVerify = String(code || otp || '').trim();
    if (!codeToVerify) {
      return res.status(400).json({
        success: false,
        error: 'Please enter the 6-digit OTP code sent to founder@aamarva.com.',
      });
    }

    const isValid = applicationService.verifyOtp(codeToVerify);
    if (!isValid) {
      return res.status(401).json({
        success: false,
        error: 'Invalid or expired OTP code. Please request a new code.',
      });
    }

    applicationService.resetAdminAttempts(clientIp);
    const adminSecret = process.env.JWT_SECRET || 'aamarva-admin-super-key-2026';
    const token = jwt.sign({ role: 'admin_operator', email: 'founder@aamarva.com' }, adminSecret, { expiresIn: '2h' });

    return res.status(200).json({
      success: true,
      verified: true,
      token,
      message: 'Admin OTP verified. Gateway unlocked.',
    });
  } catch (err: any) {
    console.error('[APPLICATIONS_ADMIN_OTP_VERIFY_ERROR]', err);
    return res.status(500).json({
      success: false,
      error: err?.message || 'Failed to verify OTP code.',
    });
  }
});

// Get all applications categorized into Applications (Under Review), Approved, and Reject (Declined)
router.get(['/applications/admin', '/appliactions/admin'], async (req: Request, res: Response, next: NextFunction) => {
  // If a user navigates directly to /applications/admin in the browser, let the SPA frontend render the OTP Gateway UI
  const acceptHeader = req.headers.accept || '';
  if (!req.originalUrl.startsWith('/api') && acceptHeader.includes('text/html')) {
    return next();
  }
  return requireAdminOperatorAuth(req, res, async () => {
    try {
      const allApps = await applicationService.getApplications();
      const pending = allApps.filter(app => !app.status || app.status === 'Under Review');
      const approved = allApps.filter(app => app.status === 'Approved');
      const rejected = allApps.filter(app => app.status === 'Declined');
      let whitelist: string[] = [];
      try {
        whitelist = await applicationService.getWhitelist();
      } catch {
        whitelist = approved.map(a => a.emailAddress.toLowerCase().trim());
      }

      return res.status(200).json({
        success: true,
        applications: allApps,
        pending,
        approved,
        rejected,
        whitelist,
        counts: {
          total: allApps.length,
          pending: pending.length,
          approved: approved.length,
          rejected: rejected.length,
        },
      });
    } catch (err: any) {
      console.error('[APPLICATIONS_ADMIN_GET_ERROR]', err);
      return res.status(500).json({
        success: false,
        error: err?.message || 'Failed to retrieve applications.',
      });
    }
  });
});

// Approve an application -> whitelist email, mark Approved, send approval email (sendApplicationApprovedEmail)
router.post(['/applications/admin/approve', '/appliactions/admin/approve'], requireAdminOperatorAuth, async (req: Request, res: Response) => {
  try {
    const { id, email } = req.body || {};
    const allApps = await applicationService.getApplications();
    const targetApp = id
      ? allApps.find(a => a.id === id)
      : email
      ? allApps.find(a => a.emailAddress.toLowerCase().trim() === String(email).toLowerCase().trim())
      : undefined;

    if (!targetApp && !email) {
      return res.status(404).json({ success: false, error: 'Application not found.' });
    }

    if (targetApp && (targetApp.status === 'Declined' || targetApp.status === 'Approved')) {
      return res.status(400).json({
        success: false,
        error: `Application has already been ${targetApp.status === 'Declined' ? 'rejected' : 'approved'} and cannot be modified.`,
      });
    }

    const emailToWhitelist = (targetApp?.emailAddress || email || '').trim().toLowerCase();

    await Promise.all([
      targetApp ? applicationService.updateApplicationStatus(targetApp.id, 'Approved') : Promise.resolve(),
      emailToWhitelist
        ? applicationService.addEmailToWhitelist(emailToWhitelist, {
            fullName: targetApp?.fullName,
            sendEmail: true,
          })
        : Promise.resolve(),
    ]);

    return res.status(200).json({
      success: true,
      id: targetApp?.id,
      email: emailToWhitelist,
      status: 'Approved',
      message: 'Application approved, email whitelisted, and approval email dispatched.',
    });
  } catch (err: any) {
    console.error('[APPLICATIONS_ADMIN_APPROVE_ERROR]', err);
    return res.status(500).json({
      success: false,
      error: err?.message || 'Failed to approve application.',
    });
  }
});

// Reject an application -> mark Declined, send rejection email (sendApplicationRejectedEmail)
router.post(['/applications/admin/reject', '/appliactions/admin/reject'], requireAdminOperatorAuth, async (req: Request, res: Response) => {
  try {
    const { id, email } = req.body || {};
    const allApps = await applicationService.getApplications();
    const targetApp = id
      ? allApps.find(a => a.id === id)
      : email
      ? allApps.find(a => a.emailAddress.toLowerCase().trim() === String(email).toLowerCase().trim())
      : undefined;

    if (!targetApp) {
      return res.status(404).json({ success: false, error: 'Application not found.' });
    }

    if (targetApp.status === 'Approved' || targetApp.status === 'Declined') {
      return res.status(400).json({
        success: false,
        error: `Application has already been ${targetApp.status === 'Approved' ? 'approved' : 'rejected'} and cannot be modified.`,
      });
    }

    await Promise.all([
      applicationService.updateApplicationStatus(targetApp.id, 'Declined'),
      sendApplicationRejectedEmail(targetApp.emailAddress, targetApp.fullName || 'Applicant'),
    ]);

    return res.status(200).json({
      success: true,
      id: targetApp.id,
      email: targetApp.emailAddress,
      status: 'Declined',
      message: 'Application rejected and decision email dispatched.',
    });
  } catch (err: any) {
    console.error('[APPLICATIONS_ADMIN_REJECT_ERROR]', err);
    return res.status(500).json({
      success: false,
      error: err?.message || 'Failed to reject application.',
    });
  }
});

// Manually whitelist an email address & send approval/registration instructions email (sendApplicationApprovedEmail)
router.post(['/applications/admin/whitelist', '/appliactions/admin/whitelist'], requireAdminOperatorAuth, async (req: Request, res: Response) => {
  try {
    const { email, fullName, sendEmail } = req.body || {};
    if (!email || typeof email !== 'string' || !email.trim()) {
      return res.status(400).json({ success: false, error: 'A valid email is required.' });
    }
    const cleanEmail = email.trim().toLowerCase();

    const allApps = await applicationService.getApplications();
    const matchingApp = allApps.find(
      a => (a.emailAddress || '').toLowerCase().trim() === cleanEmail
    );
    await Promise.all([
      matchingApp && (!matchingApp.status || matchingApp.status === 'Under Review')
        ? applicationService.updateApplicationStatus(matchingApp.id, 'Approved')
        : Promise.resolve(),
      applicationService.addEmailToWhitelist(cleanEmail, {
        fullName: fullName || matchingApp?.fullName,
        sendEmail: sendEmail !== false,
      }),
    ]);

    return res.status(200).json({
      success: true,
      email: cleanEmail,
      emailSent: sendEmail !== false,
      message: 'Email added to registration whitelist and approval email dispatched.',
    });
  } catch (err: any) {
    console.error('[APPLICATIONS_ADMIN_WHITELIST_ERROR]', err);
    return res.status(500).json({
      success: false,
      error: err?.message || 'Failed to whitelist email.',
    });
  }
});

// Remove an email address from the registration whitelist
router.post(['/applications/admin/whitelist/remove', '/appliactions/admin/whitelist/remove'], requireAdminOperatorAuth, async (req: Request, res: Response) => {
  try {
    const { email } = req.body || {};
    if (!email || typeof email !== 'string' || !email.trim()) {
      return res.status(400).json({ success: false, error: 'A valid email is required.' });
    }
    await applicationService.removeEmailFromWhitelist(email.trim());
    return res.status(200).json({
      success: true,
      email: email.trim().toLowerCase(),
      message: 'Email removed from registration whitelist.',
    });
  } catch (err: any) {
    console.error('[APPLICATIONS_ADMIN_WHITELIST_REMOVE_ERROR]', err);
    return res.status(500).json({
      success: false,
      error: err?.message || 'Failed to remove email from whitelist.',
    });
  }
});

// Submit a new Enterprise sales inquiry to sales@aamarva.com
router.post(['/enterprise/inquiry', '/v1/enterprise/inquiry'], async (req: Request, res: Response) => {
  try {
    const { orgName, contactName, workEmail, fleetSize, timeline, requirements } = req.body || {};

    if (!orgName || typeof orgName !== 'string' || !orgName.trim()) {
      return res.status(400).json({ success: false, error: { message: 'Organization name is required.' } });
    }
    if (!contactName || typeof contactName !== 'string' || !contactName.trim()) {
      return res.status(400).json({ success: false, error: { message: 'Contact name is required.' } });
    }
    if (!workEmail || typeof workEmail !== 'string' || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(workEmail.trim())) {
      return res.status(400).json({ success: false, error: { message: 'A valid work email address is required.' } });
    }

    await sendEnterpriseInquiryEmail({
      orgName: orgName.trim(),
      contactName: contactName.trim(),
      workEmail: workEmail.trim(),
      fleetSize: typeof fleetSize === 'string' && fleetSize.trim() ? fleetSize.trim() : '500-1000',
      timeline: typeof timeline === 'string' && timeline.trim() ? timeline.trim() : '1-3-months',
      requirements: typeof requirements === 'string' ? requirements.trim() : '',
    });

    return res.status(200).json({
      success: true,
      message: 'Enterprise inquiry transmitted to sales@aamarva.com.',
    });
  } catch (err: any) {
    console.error('[ENTERPRISE_INQUIRY_ERROR] Failed to send enterprise inquiry email:', err?.message || err);
    return res.status(500).json({
      success: false,
      error: { message: err?.message || 'Failed to send enterprise inquiry email.' },
    });
  }
});

// --- Outbound Webhook Subscriptions & Delivery Management Layer ---

async function resolveWebhookTargetAccount(req: AuthenticatedRequest): Promise<{ userId: string; agentId?: string; errorStatus?: number; errorBody?: any }> {
  const { callerUserId, callerAgentId, callerMasterId, callerFleetId, isSlave } = await resolveTelemetryCallerContext(req);
  const requestedTarget = String(
    req.headers['x-target-agent-id'] ||
    req.query.agentId ||
    req.query.agent_id ||
    req.query.userId ||
    req.query.user_id ||
    ''
  ).trim();

  if (!requestedTarget) {
    return { userId: callerUserId, agentId: callerAgentId };
  }

  const isTargetSelf =
    requestedTarget.toLowerCase() === callerUserId.toLowerCase() ||
    requestedTarget.toLowerCase() === callerAgentId.toLowerCase();

  if (isTargetSelf) {
    return { userId: callerUserId, agentId: callerAgentId };
  }

  if (isSlave) {
    return {
      userId: '',
      errorStatus: 403,
      errorBody: {
        success: false,
        error: {
          code: 'UNAUTHORIZED',
          message: 'Unauthorized: Slave accounts cannot manage webhook subscriptions for other accounts.'
        }
      }
    };
  }

  const sb = getSupabaseClient();
  const { data: matchById } = await sb
    .from('users')
    .select('id, agentId, master_id, fleet_id')
    .eq('id', requestedTarget)
    .maybeSingle();
  let slaveMatch = matchById;
  if (!slaveMatch) {
    const cleanHandle = requestedTarget.replace(/^@+/, '');
    const { data: matchByAgentId } = await sb
      .from('users')
      .select('id, agentId, master_id, fleet_id')
      .ilike('agentId', cleanHandle)
      .maybeSingle();
    slaveMatch = matchByAgentId;
  }

  const inFleet = Boolean(
    slaveMatch && (
      slaveMatch.id === callerUserId ||
      slaveMatch.master_id === callerUserId ||
      slaveMatch.master_id === callerMasterId ||
      (callerFleetId && slaveMatch.fleet_id && slaveMatch.fleet_id === callerFleetId)
    )
  );
  if (!slaveMatch || !inFleet) {
    return {
      userId: '',
      errorStatus: 403,
      errorBody: {
        success: false,
        error: {
          code: 'UNAUTHORIZED',
          message: 'Unauthorized: Cannot access webhook subscriptions outside your fleet.'
        }
      }
    };
  }

  return { userId: slaveMatch.id, agentId: slaveMatch.agentId || slaveMatch.id };
}

// GET /api/webhooks/subscriptions (List user's or targeted slave's outbound webhook subscriptions)
router.get('/webhooks/subscriptions', requireUserOrAgentAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const target = await resolveWebhookTargetAccount(req);
    if (target.errorStatus) return res.status(target.errorStatus).json(target.errorBody);
    const subs = await webhookDeliveryService.getSubscriptions(target.userId);
    return res.json({ success: true, data: subs });
  } catch (err: any) {
    const status = err?.statusCode || 500;
    return res.status(status).json({ success: false, error: { message: err?.message || 'Failed to fetch subscriptions.' } });
  }
});

// POST /api/webhooks/subscriptions (Create a new outbound webhook subscription)
router.post('/webhooks/subscriptions', requireUserOrAgentAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const target = await resolveWebhookTargetAccount(req);
    if (target.errorStatus) return res.status(target.errorStatus).json(target.errorBody);
    const { url, secret, events } = req.body || {};

    if (!url || typeof url !== 'string' || !url.trim().toLowerCase().startsWith('http')) {
      return res.status(400).json({ success: false, error: { message: 'A valid HTTP/HTTPS URL is required.' } });
    }

    const sub = await webhookDeliveryService.createSubscription(
      target.userId,
      target.agentId,
      url.trim(),
      secret ? String(secret).trim() : undefined,
      Array.isArray(events) ? events : ['*']
    );

    return res.status(201).json({ success: true, data: sub });
  } catch (err: any) {
    const status = err?.statusCode || 500;
    return res.status(status).json({ success: false, error: { message: err?.message || 'Failed to create webhook subscription.' } });
  }
});

// DELETE /api/webhooks/subscriptions/:id (Delete a subscription)
router.delete('/webhooks/subscriptions/:id', requireUserOrAgentAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const target = await resolveWebhookTargetAccount(req);
    if (target.errorStatus) return res.status(target.errorStatus).json(target.errorBody);
    const subId = String(req.params.id);
    const deleted = await webhookDeliveryService.deleteSubscription(subId, target.userId);
    if (!deleted) {
      return res.status(404).json({ success: false, error: { message: 'Subscription not found or unauthorized.' } });
    }
    return res.json({ success: true, message: 'Webhook subscription deleted successfully.' });
  } catch (err: any) {
    const status = err?.statusCode || 500;
    return res.status(status).json({ success: false, error: { message: err?.message || 'Failed to delete subscription.' } });
  }
});

// POST /api/webhooks/subscriptions/:id/test (Send a test ping webhook)
router.post('/webhooks/subscriptions/:id/test', requireUserOrAgentAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const target = await resolveWebhookTargetAccount(req);
    if (target.errorStatus) return res.status(target.errorStatus).json(target.errorBody);
    const subId = String(req.params.id);
    const testResult = await webhookDeliveryService.testSubscription(subId, target.userId);
    if (!testResult.found) {
      return res.status(404).json({ success: false, error: { message: testResult.error || 'Subscription not found.' }, data: testResult });
    }
    return res.json({ success: testResult.success, data: testResult });
  } catch (err: any) {
    const status = err?.statusCode || 500;
    return res.status(status).json({ success: false, error: { message: err?.message || 'Failed to test webhook.' } });
  }
});

// GET /api/webhooks/deliveries (List outbound webhook delivery attempts)
router.get('/webhooks/deliveries', requireUserOrAgentAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const target = await resolveWebhookTargetAccount(req);
    if (target.errorStatus) return res.status(target.errorStatus).json(target.errorBody);
    const deliveries = await webhookDeliveryService.getDeliveries(target.userId);
    return res.json({ success: true, data: deliveries });
  } catch (err: any) {
    const status = err?.statusCode || 500;
    return res.status(status).json({ success: false, error: { message: err?.message || 'Failed to fetch webhook deliveries.' } });
  }
});

export default router;