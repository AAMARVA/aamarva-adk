import { Request, Response, NextFunction } from 'express';
import { SecurityService, SecurityError, GLOBAL_SECURITY_POLICIES, SecuritySeverity, TrafficClass } from '../services/securityService';
import { AuthenticatedRequest } from './authMiddleware';
import { HUMAN_SESSION_COOKIE_NAME } from '../authService.js';

/**
 * Detects the traffic class based on existing authentication headers and cookies.
 * Does NOT perform full verification, only presence detection for classification.
 */
function detectTrafficClass(req: Request): TrafficClass {
  const authenticatedReq = req as AuthenticatedRequest;
  
  // 1. Check if authMiddleware already ran and set authType
  if (authenticatedReq.authType === 'human') return TrafficClass.HUMAN_SESSION;
  if (authenticatedReq.authType === 'agent') return TrafficClass.AGENT_AUTH;

  // 2. Fallback: Detect based on presence of credentials
  const sessionCookie = req.cookies?.[HUMAN_SESSION_COOKIE_NAME];
  if (sessionCookie && typeof sessionCookie === 'string' && sessionCookie.trim()) {
    return TrafficClass.HUMAN_SESSION;
  }

  const authHeader = req.headers.authorization;
  const apiKeyHeader = req.headers['x-api-key'];
  if (
    (authHeader && authHeader.startsWith('Bearer ')) || 
    (apiKeyHeader && typeof apiKeyHeader === 'string' && apiKeyHeader.trim())
  ) {
    return TrafficClass.AGENT_AUTH;
  }

  return TrafficClass.PUBLIC;
}

export async function validateSecurityPayload(req: Request, res: Response, policyName: string): Promise<boolean> {
  const securityService = SecurityService.getInstance();
  const authenticatedReq = req as AuthenticatedRequest;
  const userId = authenticatedReq.user?.id;
  const agentId = authenticatedReq.user?.agentId;

  if (req.body && typeof req.body === 'object') {
    const bodyStr = JSON.stringify(req.body);
    const policy = GLOBAL_SECURITY_POLICIES[policyName];
    const maxBodySize = policy?.resourceLimits?.maxBodySize || 200000;

    if (bodyStr.length > maxBodySize) {
      await securityService.recordViolation(userId || '', agentId || '', policyName, SecuritySeverity.S2_ABUSE, `Payload size violation: ${bodyStr.length} > ${maxBodySize}`, req.ip);
      res.status(400).json({ success: false, error: 'Request payload too large.' });
      return false;
    }

    try {
      securityService.checkPayloadDepth(req.body, 0, 10);
    } catch (depthError: any) {
      await securityService.recordViolation(userId || '', agentId || '', policyName, SecuritySeverity.S2_ABUSE, `Payload depth violation: ${depthError.message}`, req.ip);
      res.status(400).json({ success: false, error: 'Invalid request payload structure.' });
      return false;
    }
  }
  return true;
}

export async function runSecurityEvaluationOrRespond(req: Request, res: Response, policyName: string): Promise<boolean> {
  try {
    const securityService = SecurityService.getInstance();
    const trafficClass = detectTrafficClass(req);
    const authenticatedReq = req as AuthenticatedRequest;
    await securityService.evaluateRequest(req, policyName, authenticatedReq.user?.id, trafficClass);
    return true;
  } catch (err: any) {
    if (err instanceof SecurityError) {
      console.warn(`[SECURITY ENFORCEMENT] ${err.code}: ${err.message} on ${req.originalUrl} from ${req.ip}`);

      let status = 429;
      if (err.code === 'PERMANENT_BAN') status = 403;
      else if (err.code === 'SUSPENDED') status = 423;
      else if (err.code === 'DATABASE_UNAVAILABLE') status = 503;
      else if (err.code === 'FORBIDDEN') status = 403;
      else if (err.code === 'RESOURCE_LIMIT_EXCEEDED') status = 403;

      res.status(status).json({
        success: false,
        error: {
          code: err.code,
          message: err.message,
          retryAfter: err.retryAfter
        }
      });
      return false;
    }
    throw err;
  }
}

/**
 * AAMARVA Deterministic Security Layer Middleware
 * Implements S0-S3 severity enforcement, sticky violation history, and resource protection.
 */
export function securityLayer(policyName: string) {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      const payloadOk = await validateSecurityPayload(req, res, policyName);
      if (!payloadOk) return;

      const securityOk = await runSecurityEvaluationOrRespond(req, res, policyName);
      if (!securityOk) return;

      next();
    } catch (err: any) {
      console.error('[SECURITY LAYER ERROR]', err);
      next(err);
    }
  };
}
