import crypto from 'crypto';
import { Request, Response, NextFunction } from 'express';
import { logAgentFootprint } from '../services/auditService';
import { watchtowerActivityService } from '../services/watchtowerActivityService';
import { getSupabaseClient } from '../supabase';
import { computeApiKeyFingerprint, verifyAgentAccessToken, verifyHumanSession, findUserById, HUMAN_SESSION_COOKIE_NAME } from '../authService';
import { MasterAccountService } from '../services/masterAccountService';

export interface AccountIdentity {
  userId: string;
  agentId: string;
  name: string;
  avatar?: string;
  emailVerified?: boolean;
  masterId: string;
  isMaster: boolean;
  isSlave: boolean;
}

export type SlaveAgentIdentity = AccountIdentity;

/**
 * List of prefixes and exact paths that are strictly human-only.
 * Per requirements: "except the human only endpoints".
 */
const HUMAN_ONLY_PATH_PATTERNS = [
  /^\/(?:v1\/)?auth\/human(?:\/|$)/i,
  /^\/(?:v1\/)?auth\/webauthn(?:\/|$)/i,
  /^\/(?:v1\/)?auth\/forgot-password(?:\/|$)/i,
  /^\/(?:v1\/)?auth\/reset-password(?:\/|$)/i,
  /^\/(?:v1\/)?auth\/change-password(?:\/|$)/i,
  /^\/(?:v1\/)?auth\/change-email(?:\/|$)/i,
  /^\/(?:v1\/)?auth\/verify-email(?:\/|$)/i,
  /^\/(?:v1\/)?auth\/master\/accounts(?:\/|$)/i,
  /^\/(?:v1\/)?auth\/master\/plan(?:\/|$)/i,
  /^\/(?:v1\/)?auth\/master\/buy-plan(?:\/|$)/i,
  /^\/(?:v1\/)?auth\/master\/switch(?:\/|$)/i,
  /^\/(?:v1\/)?auth\/master\/rotate-.*$/i,
  /^\/(?:v1\/)?auth\/master\/undeploy-.*$/i,
  /^\/(?:v1\/)?auth\/master\/delete-.*$/i,
  /^\/(?:v1\/)?auth\/master\/logout-.*$/i,
  /^\/(?:v1\/)?auth\/network-whitelist(?:\/|$)/i,
  /^\/(?:v1\/)?auth\/sessions\/logout-all(?:\/|$)/i,
  /^\/(?:v1\/)?secrets(?:\/|$)/i,
  /^\/(?:v1\/)?account\/access-management(?:\/|$)/i,
  /^\/(?:v1\/)?agents\/me\/e2ee\/recovery(?:\/|$)/i,
];

/**
 * Endpoints that represent internal monitoring or streaming queries.
 * We do not record these to avoid infinite monitoring recursion.
 */
const INTERNAL_MONITORING_PATTERNS = [
  /^\/(?:v1\/)?agent\/footprints(?:\/|$)/i,
  /^\/(?:v1\/)?webhooks\/events(?:\/|$)/i,
  /^\/(?:v1\/)?floor\/activity(?:\/|$)/i,
  /^\/(?:v1\/)?floor\/stream(?:\/|$)/i,
  /^\/(?:v1\/)?watchtower\/activity(?:\/|$)/i,
  /^\/(?:v1\/)?watchtower\/stream(?:\/|$)/i,
  /^\/(?:v1\/)?realtime\/stream(?:\/|$)/i,
  /^\/(?:v1\/)?realtime\/events(?:\/|$)/i,
  /^\/(?:v1\/)?stats(?:\/|$)/i,
  /^\/(?:v1\/)?health(?:\/|$)/i,
  /^\/(?:v1\/)?readiness(?:\/|$)/i,
  /^\/(?:v1\/)?liveness(?:\/|$)/i,
  /\.(?:png|jpg|jpeg|gif|svg|ico|css|js|map|json|html|txt)$/i,
];

export function isHumanOnlyEndpoint(method: string, path: string): boolean {
  const normalizedPath = path.replace(/^\/api/, '');
  for (const pattern of HUMAN_ONLY_PATH_PATTERNS) {
    if (pattern.test(normalizedPath)) {
      return true;
    }
  }

  // Cluster administration mutations (PATCH, DELETE) are owner-only human operations
  if (/^\/(?:v1\/)?clusters\/[^/]+(?:\/|$)/i.test(normalizedPath)) {
    if (method === 'PATCH' || method === 'DELETE') {
      return true;
    }
  }

  // Deleting connection is human session exclusive
  if (/^\/(?:v1\/)?connections\/[^/]+$/i.test(normalizedPath) && method === 'DELETE') {
    return true;
  }

  return false;
}

export function isInternalMonitoringEndpoint(path: string): boolean {
  const normalizedPath = path.replace(/^\/api/, '');
  for (const pattern of INTERNAL_MONITORING_PATTERNS) {
    if (pattern.test(normalizedPath)) {
      return true;
    }
  }
  return false;
}

/**
 * Resolves the authenticated account identity (Master, Slave, or Independent Account).
 */
export async function detectAccountIdentity(req: Request): Promise<AccountIdentity | null> {
  // 1. If req.user is already attached (from requireAgentAuth, requireHumanSession, requireUserOrAgentAuth, etc.)
  const authUser = (req as any).user;
  if (authUser && (authUser.id || authUser.userId)) {
    const effectiveUserId = authUser.id || authUser.userId;
    const isMaster = Boolean(
      authUser.is_master_primary === true ||
      authUser.isMasterUser === true ||
      authUser.is_master_slot === true ||
      authUser.account_type === 'master_slot' ||
      authUser.account_type === 'master' ||
      authUser.role === 'master' ||
      (!authUser.master_id && !authUser.masterUserId)
    );
    const isSlave = !isMaster && Boolean(
      (authUser.master_id && authUser.master_id !== effectiveUserId) ||
      (authUser.masterUserId && effectiveUserId !== authUser.masterUserId) ||
      authUser.account_type === 'slave' ||
      authUser.role === 'slave' ||
      authUser.is_slave === true ||
      authUser.isSlave === true ||
      (typeof authUser.email === 'string' && authUser.email.includes('+AMR-'))
    );

    let resolvedMasterId = (authUser.master_id && authUser.master_id !== effectiveUserId)
      ? authUser.master_id
      : (authUser.masterUserId || (isMaster ? effectiveUserId : undefined));

    if (!resolvedMasterId) {
      resolvedMasterId = effectiveUserId;
      if (isSlave) {
        try {
          const supabase = getSupabaseClient();
          const dbUser = await findUserById(supabase, effectiveUserId);
          if (dbUser?.master_id) {
            resolvedMasterId = dbUser.master_id;
          }
        } catch {}
      }
    }

    return {
      userId: effectiveUserId,
      agentId: authUser.agentId || authUser.id || effectiveUserId,
      name: authUser.name || authUser.agentName || authUser.agentId || (isMaster ? 'Master Account' : 'Agent'),
      avatar: authUser.avatar,
      emailVerified: Boolean(authUser.emailVerified),
      masterId: resolvedMasterId,
      isMaster,
      isSlave,
    };
  }

  // 2. Check X-API-KEY header or Bearer sk_amr_... / Bearer amr_live_...
  const apiKeyHeader = req.headers['x-api-key'];
  const authHeader = req.headers.authorization;
  let rawToken: string | undefined;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    rawToken = authHeader.split(' ')[1];
  }

  const candidateApiKey = (typeof apiKeyHeader === 'string' && apiKeyHeader.trim())
    ? apiKeyHeader.trim()
    : (rawToken && (rawToken.startsWith('sk_amr_') || rawToken.startsWith('amr_live_')))
      ? rawToken.trim()
      : null;

  if (!candidateApiKey && !req.cookies?.[HUMAN_SESSION_COOKIE_NAME] && !rawToken) {
    return null;
  }

  if (candidateApiKey) {
    try {
      const fingerprint = computeApiKeyFingerprint(candidateApiKey);
      const masterService = MasterAccountService.getInstance();
      let meta = masterService.getUserByFingerprint(fingerprint);

      const supabase = getSupabaseClient();
      let userRec: any = null;

      if (meta?.id) {
        userRec = await masterService.getUserMetadata(meta.id);
      }

      if (!userRec) {
        const { data } = await supabase
          .from('users')
          .select('id, agentId, name, avatar, email, emailVerified, master_id, is_master_primary, account_type, role, is_slave, is_master_slot')
          .eq('apiKeyFingerprint', fingerprint)
          .maybeSingle();
        userRec = data;
      }

      if (userRec) {
        const isMaster = Boolean(
          userRec.is_master_primary === true ||
          (userRec as any).is_master_slot === true ||
          userRec.account_type === 'master_slot' ||
          userRec.account_type === 'master' ||
          userRec.role === 'master'
        );
        const isSlave = !isMaster && Boolean(
          userRec.account_type === 'slave' ||
          userRec.role === 'slave' ||
          userRec.is_slave === true ||
          (userRec.email && userRec.email.includes('+AMR-')) ||
          (userRec.master_id && userRec.master_id !== userRec.id)
        );

        const effectiveMaster = (await watchtowerActivityService.resolveMasterIdForActor(userRec.id)) || userRec.master_id || userRec.id;
        return {
          userId: userRec.id,
          agentId: userRec.agentId,
          name: userRec.name || userRec.agentId || (isMaster ? 'Master Account' : 'Agent'),
          avatar: userRec.avatar,
          emailVerified: Boolean(userRec.emailVerified),
          masterId: effectiveMaster,
          isMaster,
          isSlave,
        };
      }
    } catch (e) {}
  }

  // 3. Check Bearer Agent Access Token
  if (rawToken && !candidateApiKey) {
    try {
      const payload = verifyAgentAccessToken(rawToken);
      if (payload && payload.type === 'agent' && payload.id) {
        const supabase = getSupabaseClient();
        const userRec = await findUserById(supabase, payload.id);

        if (userRec) {
          const isMaster = Boolean(
            userRec.is_master_primary === true ||
            (userRec as any).is_master_slot === true ||
            userRec.account_type === 'master_slot' ||
            userRec.account_type === 'master' ||
            userRec.role === 'master'
          );
          const isSlave = !isMaster && Boolean(
            userRec.account_type === 'slave' ||
            userRec.role === 'slave' ||
            userRec.is_slave === true ||
            (userRec.email && userRec.email.includes('+AMR-')) ||
            (userRec.master_id && userRec.master_id !== userRec.id)
          );

          const effectiveMaster = (await watchtowerActivityService.resolveMasterIdForActor(userRec.id)) || userRec.master_id || userRec.id;
          return {
            userId: userRec.id,
            agentId: userRec.agentId,
            name: userRec.name || userRec.agentId || (isMaster ? 'Master Account' : 'Agent'),
            avatar: userRec.avatar,
            emailVerified: Boolean(userRec.emailVerified),
            masterId: effectiveMaster,
            isMaster,
            isSlave,
          };
        }
      }
    } catch (e) {}
  }

  // 4. Check human session
  const sessionCookie = req.cookies?.[HUMAN_SESSION_COOKIE_NAME];
  if (sessionCookie) {
    try {
      const payload = await verifyHumanSession(sessionCookie);
      if (payload && payload.userId) {
        const supabase = getSupabaseClient();
        const userRec = await findUserById(supabase, payload.userId);

        const isMaster = Boolean(
          userRec?.is_master_primary === true ||
          userRec?.account_type === 'master_slot' ||
          userRec?.account_type === 'master' ||
          userRec?.role === 'master' ||
          (payload.masterUserId && payload.userId === payload.masterUserId)
        );
        const isSlave = !isMaster && Boolean(
          payload.masterUserId && payload.userId !== payload.masterUserId
        );

        return {
          userId: payload.userId,
          agentId: userRec?.agentId || payload.userId,
          name: userRec?.name || userRec?.agentId || (isMaster ? 'Master Account' : 'Agent'),
          avatar: userRec?.avatar,
          emailVerified: Boolean(userRec?.emailVerified),
          masterId: payload.masterUserId || userRec?.master_id || payload.userId,
          isMaster,
          isSlave,
        };
      }
    } catch (e) {}
  }

  return null;
}

/**
 * Resolves whether the current request is from a slave agent (backward compatible wrapper).
 */
export async function detectSlaveAgentIdentity(req: Request): Promise<SlaveAgentIdentity | null> {
  const ident = await detectAccountIdentity(req);
  if (ident && ident.isSlave) {
    return ident;
  }
  return null;
}

export function parseEndpointAction(method: string, cleanPath: string, req?: Request): {
  actionName: string;
  floorText: string;
  details: string;
  target?: string;
  type: string;
  isNoisy?: boolean;
} | null {
  const norm = cleanPath.replace(/^\/api/, '').replace(/^\/v1/, '');
  const m = method.toUpperCase();

  // Helper to extract peer target from request parameters or body
  let targetParam: string | undefined = undefined;
  if (req) {
    targetParam = (req.params as any)?.accountId ||
      (req.params as any)?.connectionId ||
      (req.params as any)?.clusterId ||
      (req.params as any)?.toolId ||
      (req.params as any)?.requestId ||
      (req.params as any)?.id ||
      req.body?.agentId ||
      req.body?.targetAgentId ||
      req.body?.receiverAgentId ||
      req.body?.peerAgentId ||
      req.body?.peerAccountId;
    if (typeof targetParam === 'string') {
      targetParam = targetParam.trim().replace(/^@+/, '');
    } else {
      targetParam = undefined;
    }
  }

  if (!targetParam) {
    const msgMatch = norm.match(/^\/connections\/(?:messages\/([^/]+)|([^/]+)\/messages)/i);
    if (msgMatch) {
      targetParam = (msgMatch[1] || msgMatch[2] || '').trim().replace(/^@+/, '');
    }
  }

  // 1. Direct Connections, Messaging & Attachments
  if (m === 'POST' && /^\/connections(?:\/messages(?:\/[^/]+)?|\/[^/]+\/messages)$/i.test(norm)) {
    const peerDisplay = targetParam || 'peer';
    return {
      actionName: 'MESSAGE_SENT',
      floorText: `transmitted encrypted message to @${peerDisplay}`,
      details: 'Transmitted secure end-to-end encrypted payload',
      target: targetParam,
      type: 'general',
    };
  }

  if (m === 'POST' && /^\/connections(?:\/attachments(?:\/[^/]+)?|\/[^/]+\/attachments)$/i.test(norm)) {
    const peerDisplay = targetParam || 'peer';
    return {
      actionName: 'ATTACHMENT_SENT',
      floorText: `transmitted encrypted attachment to @${peerDisplay}`,
      details: 'Transmitted secure end-to-end encrypted attachment',
      target: targetParam,
      type: 'general',
    };
  }

  if (m === 'POST' && (/^\/connections\/requests\/[^/]+\/accept$/i.test(norm) || /^\/connections\/[^/]+\/accept$/i.test(norm) || /^\/connections\/accept$/i.test(norm))) {
    const peerDisplay = targetParam || 'peer';
    return {
      actionName: 'CONNECTION_ACCEPTED',
      floorText: `accepted connection link from @${peerDisplay}`,
      details: 'Accepted bilateral connection with peer agent',
      target: targetParam,
      type: 'connection',
    };
  }

  if (m === 'POST' && (/^\/connections\/requests$/i.test(norm) || /^\/connections\/request$/i.test(norm))) {
    const peerDisplay = targetParam || 'peer';
    return {
      actionName: 'CONNECTION_REQUEST_SENT',
      floorText: `sent a connection request to @${peerDisplay}`,
      details: 'Dispatched connection request to peer agent',
      target: targetParam,
      type: 'connection',
    };
  }

  if (m === 'POST' && (/^\/connections(?:\/establish)?$/i.test(norm) || norm === '/connections')) {
    const peerDisplay = targetParam || 'peer';
    return {
      actionName: 'CONNECTION_ESTABLISHED',
      floorText: `connected with peer @${peerDisplay}`,
      details: 'Established connection link with peer agent',
      target: targetParam,
      type: 'connection',
    };
  }

  if (m === 'POST' && /^\/connections\/[^/]+\/dissolve$/i.test(norm)) {
    const peerDisplay = targetParam || 'peer';
    return {
      actionName: 'CONNECTION_DISSOLVED',
      floorText: `dissolved connection link with @${peerDisplay}`,
      details: 'Dissolved connection link with peer agent',
      target: targetParam,
      type: 'connection',
    };
  }

  if (m === 'DELETE' && /^\/connections\/[^/]+$/i.test(norm)) {
    const peerDisplay = targetParam || 'peer';
    return {
      actionName: 'CONNECTION_REMOVED',
      floorText: `terminated connection link with @${peerDisplay}`,
      details: 'Terminated connection link with peer agent',
      target: targetParam,
      type: 'connection',
    };
  }

  // 2. Posts and Feed Activity
  if (m === 'POST' && (/^\/posts\/?$/i.test(norm) || /^\/agents\/[^/]+\/posts\/?$/i.test(norm) || /^\/feed\/?$/i.test(norm))) {
    return {
      actionName: 'POST_CREATED',
      floorText: 'published operational ticket to public feed',
      details: 'Created operational ticket on public network board',
      type: 'general',
    };
  }

  if (m === 'POST' && (/^\/bids\/?$/i.test(norm) || /^\/posts\/[^/]+\/bids\/?$/i.test(norm))) {
    return {
      actionName: 'BID_SUBMITTED',
      floorText: 'submitted response bid on operational ticket',
      details: 'Submitted response bid on network ticket',
      type: 'general',
    };
  }

  // 3. Identity, Keys & Profile
  if (m === 'PUT' && norm === '/agents/me/e2ee') {
    return {
      actionName: 'E2EE_KEYS_UPDATED',
      floorText: 'registered its E2EE cryptographic identity',
      details: 'Updated agent E2EE cryptographic public identity keys',
      type: 'security',
    };
  }

  if (m === 'PATCH' && (norm === '/agents/me' || norm === '/agents/me/profile')) {
    return {
      actionName: 'PROFILE_UPDATED',
      floorText: 'updated its profile',
      details: 'Updated agent profile parameters and metadata',
      type: 'account',
    };
  }

  if (m === 'POST' && (/^\/agents\/me\/api-key\/rotate$/i.test(norm) || /^\/auth\/master\/rotate-/i.test(norm))) {
    return {
      actionName: 'API_KEY_ROTATED',
      floorText: 'rotated API key credentials',
      details: 'Rotated cryptographic API access credentials',
      type: 'security',
    };
  }

  if (m === 'POST' && (/^\/auth\/change-password$/i.test(norm) || /^\/auth\/reset-password$/i.test(norm))) {
    return {
      actionName: 'PASSWORD_CHANGED',
      floorText: 'updated account password',
      details: 'Changed account password credentials',
      type: 'security',
    };
  }

  if (m === 'POST' && /^\/auth\/change-email\/verify$/i.test(norm)) {
    return {
      actionName: 'EMAIL_UPDATED',
      floorText: 'updated account email address',
      details: 'Verified and updated primary email address',
      type: 'account',
    };
  }

  if ((m === 'POST' || m === 'PUT') && /^\/auth\/network-whitelist$/i.test(norm)) {
    return {
      actionName: 'WHITELIST_UPDATED',
      floorText: 'updated network access whitelist',
      details: 'Configured CIDR network access perimeter',
      type: 'security',
    };
  }

  // 4. Cluster Enclaves
  if (m === 'POST' && (/^\/clusters\/?$/i.test(norm) || /^\/clusters\/create\/?$/i.test(norm))) {
    const clusterName = (req?.body && (req.body.name || req.body.clusterName)) || 'Cluster Enclave';
    return {
      actionName: 'CLUSTER_CREATED',
      floorText: `created a new Cluster enclave "${clusterName}"`,
      details: 'Provisioned autonomous cluster enclave',
      type: 'cluster',
    };
  }

  if (m === 'PATCH' && /^\/clusters\/[^/]+$/i.test(norm)) {
    return {
      actionName: 'CLUSTER_UPDATED',
      floorText: 'updated Cluster enclave configuration',
      details: 'Updated cluster enclave parameters and metadata',
      type: 'cluster',
    };
  }

  if (m === 'DELETE' && /^\/clusters\/[^/]+$/i.test(norm)) {
    return {
      actionName: 'CLUSTER_DELETED',
      floorText: 'disbanded Cluster enclave',
      details: 'Disbanded cluster enclave',
      type: 'cluster',
    };
  }

  if (m === 'POST' && /^\/clusters\/[^/]+\/messages$/i.test(norm)) {
    return {
      actionName: 'CLUSTER_MESSAGE_SENT',
      floorText: 'transmitted an encrypted message inside Cluster enclave',
      details: 'Broadcasted encrypted transmission to cluster members',
      target: targetParam,
      type: 'cluster',
    };
  }

  if (m === 'POST' && /^\/clusters\/[^/]+\/join$/i.test(norm)) {
    return {
      actionName: 'CLUSTER_JOINED',
      floorText: 'joined Cluster enclave',
      details: 'Joined cluster enclave as member node',
      type: 'cluster',
    };
  }

  if ((m === 'DELETE' || m === 'POST') && /^\/clusters\/[^/]+\/leave$/i.test(norm)) {
    return {
      actionName: 'CLUSTER_LEFT',
      floorText: 'left Cluster enclave',
      details: 'Departed cluster enclave',
      type: 'cluster',
    };
  }

  if (m === 'POST' && /^\/clusters\/[^/]+\/members$/i.test(norm)) {
    const peerDisplay = targetParam || 'peer';
    return {
      actionName: 'CLUSTER_MEMBER_INVITED',
      floorText: `invited @${peerDisplay} to Cluster enclave`,
      details: 'Invited node to cluster enclave',
      target: targetParam,
      type: 'cluster',
    };
  }

  if (m === 'DELETE' && /^\/clusters\/[^/]+\/members\/[^/]+$/i.test(norm)) {
    const peerDisplay = targetParam || 'peer';
    return {
      actionName: 'CLUSTER_MEMBER_REMOVED',
      floorText: `removed member @${peerDisplay} from Cluster enclave`,
      details: 'Removed member node from cluster enclave',
      target: targetParam,
      type: 'cluster',
    };
  }

  if (m === 'PATCH' && /^\/clusters\/[^/]+\/members\/[^/]+\/role$/i.test(norm)) {
    return {
      actionName: 'CLUSTER_ROLE_UPDATED',
      floorText: 'updated member role in Cluster enclave',
      details: 'Modified cluster enclave member role permissions',
      type: 'cluster',
    };
  }

  if (m === 'POST' && /^\/clusters\/[^/]+\/key-distribution$/i.test(norm)) {
    return {
      actionName: 'CLUSTER_KEY_DISTRIBUTED',
      floorText: 'distributed group encryption key for Cluster enclave',
      details: 'Distributed synchronized cluster group key',
      type: 'cluster',
    };
  }

  if (m === 'POST' && /^\/clusters\/[^/]+\/rotate-key$/i.test(norm)) {
    return {
      actionName: 'CLUSTER_KEY_ROTATED',
      floorText: 'rotated cryptographic key for Cluster enclave',
      details: 'Rotated cluster enclave group cipher key',
      type: 'cluster',
    };
  }

  // 5. Reviews & Reputation
  if (m === 'POST' && norm === '/reviews') {
    return {
      actionName: 'PEER_REVIEW',
      floorText: 'submitted peer review',
      details: 'Submitted review for peer agent',
      type: 'general',
    };
  }

  // 6. FLOOR Tool Operations
  if (m === 'POST' && /^\/floor\/servers\/?$/i.test(norm)) {
    const serverName = (req?.body && req.body.name) || 'MCP Server';
    return {
      actionName: 'MCP_SERVER_REGISTERED',
      floorText: `registered MCP execution server "${serverName}"`,
      details: 'Registered autonomous tool server',
      type: 'tool',
    };
  }

  if (m === 'POST' && /^\/floor\/tools\/[^/]+\/invoke$/i.test(norm)) {
    const toolName = targetParam || 'tool';
    return {
      actionName: 'TOOL_INVOKED',
      floorText: `invoked FLOOR tool "${toolName}"`,
      details: 'Invoked autonomous FLOOR execution tool',
      target: targetParam,
      type: 'tool',
    };
  }

  if (m === 'POST' && /^\/floor\/invocations(?:\/[^/]+)?\/(?:execute|access)$/i.test(norm)) {
    return {
      actionName: 'TOOL_EXECUTED',
      floorText: 'executed authorized tool',
      details: 'Claimed and executed authorized tool credentials',
      target: targetParam,
      type: 'tool',
    };
  }

  if (m === 'POST' && (/^\/floor\/requests\/[^/]+\/approve$/i.test(norm) || /^\/floor\/approvals\/[^/]+$/i.test(norm))) {
    return {
      actionName: 'TOOL_APPROVED',
      floorText: 'approved tool invocation request',
      details: 'Approved autonomous execution request',
      target: targetParam,
      type: 'tool',
    };
  }

  if (m === 'POST' && /^\/floor\/requests\/[^/]+\/reject$/i.test(norm)) {
    return {
      actionName: 'TOOL_DENIED',
      floorText: 'denied tool invocation request',
      details: 'Denied autonomous execution request',
      target: targetParam,
      type: 'tool',
    };
  }

  // 7. Master Account Fleet Operations
  if (m === 'POST' && /^\/auth\/master\/create-(?:sub|slave)-agent$/i.test(norm)) {
    const agentName = (req?.body && (req.body.agentName || req.body.name)) || 'slave agent';
    return {
      actionName: 'SLAVE_DEPLOYED',
      floorText: `deployed slave account @${String(agentName).replace(/^@+/, '')}`,
      details: 'Deployed subordinate slave node to fleet',
      type: 'account',
    };
  }

  if (m === 'POST' && /^\/auth\/master\/undeploy-/i.test(norm)) {
    return {
      actionName: 'SLAVE_UNDEPLOYED',
      floorText: 'undeployed slave account',
      details: 'Undeployed slave account from fleet',
      type: 'account',
    };
  }

  if (m === 'POST' && (/^\/auth\/master\/buy-plan$/i.test(norm) || /^\/auth\/master\/plan\/activate$/i.test(norm))) {
    // Plan purchases (Master Slot, Slave Fleet Capacity, Capability Increment) are explicitly
    // recorded with exact plan-specific metadata by the /auth/master/buy-plan route handler.
    return null;
  }

  if (m === 'POST' && /^\/auth\/master\/copy-settings$/i.test(norm)) {
    return {
      actionName: 'FLEET_SETTINGS_COPIED',
      floorText: 'synchronized fleet configuration settings',
      details: 'Copied master account settings across fleet',
      type: 'account',
    };
  }

  // 8. Non-explicit routine operational endpoints are excluded from Watchtower/Footprints
  return null;
}

/**
 * Express middleware to record account requests across any non-human-only endpoint for slaves,
 * and all relevant actions for masters and independent accounts.
 */
export function slaveActivityMiddleware(req: Request, res: Response, next: NextFunction): void {
  const method = req.method.toUpperCase();
  const rawPath = req.originalUrl || req.url;
  const cleanPath = rawPath.split('?')[0];

  // Immediately ignore OPTIONS, HEAD, static assets, and internal monitoring polling
  if (method === 'OPTIONS' || method === 'HEAD') {
    return next();
  }

  // Fast path: bypass static files, Vite internal paths, and root document
  if (
    cleanPath.startsWith('/@') ||
    cleanPath.startsWith('/src/') ||
    cleanPath.startsWith('/assets/') ||
    cleanPath.startsWith('/node_modules/') ||
    cleanPath.startsWith('/public/') ||
    cleanPath === '/' ||
    cleanPath === '/index.html' ||
    cleanPath === '/favicon.ico' ||
    cleanPath.endsWith('.js') ||
    cleanPath.endsWith('.css') ||
    cleanPath.endsWith('.png') ||
    cleanPath.endsWith('.svg') ||
    cleanPath.endsWith('.ico')
  ) {
    return next();
  }

  if (isInternalMonitoringEndpoint(cleanPath)) {
    return next();
  }

  // Intercept completion of response to record activity
  res.on('finish', async () => {
    // Only record successful requests (status < 400)
    if (res.statusCode >= 400) {
      return;
    }

    if ((req as any).alreadyRecordedSlaveActivity) {
      return;
    }

    try {
      const action = parseEndpointAction(method, cleanPath, req);
      if (!action || (action as any).isNoisy) {
        return;
      }

      const accountIdentity = await detectAccountIdentity(req);
      if (!accountIdentity) {
        return;
      }

      // Slaves are not permitted to log human-only endpoints
      if (accountIdentity.isSlave && isHumanOnlyEndpoint(method, cleanPath)) {
        return;
      }

      (req as any).alreadyRecordedSlaveActivity = true;

      const nowIso = new Date().toISOString();
      const reqId = (req.headers['x-request-id'] || req.headers['x-operation-id'] || req.headers['x-message-id'] || (req.body && typeof req.body === 'object' ? req.body.id : undefined)) as string | undefined;
      const eventId = reqId ? `fp_${reqId}` : `fp_${crypto.randomUUID()}`;
      const activityKey = reqId
        ? `act_canon:${accountIdentity.agentId}:${action.actionName}:${reqId}`
        : `act_canon:${accountIdentity.agentId}:${action.actionName}:${eventId}`;

      // 1. Record single authoritative Watchtower Activity (Idempotently persisted to agent_footprints & streamed)
      watchtowerActivityService.recordWatchtowerActivity({
        id: eventId,
        agentId: accountIdentity.agentId,
        agentName: accountIdentity.name || accountIdentity.agentId,
        avatar: accountIdentity.avatar || '🤖',
        emailVerified: accountIdentity.emailVerified,
        text: action.floorText,
        type: action.actionName,
        category: action.type as any,
        actorUserId: accountIdentity.userId,
        masterId: accountIdentity.masterId,
        peerAgentId: action.target,
        activityKey,
        createdAt: nowIso,
      }).catch((e) => console.warn('[slaveActivityMiddleware] watchtowerActivity error:', e?.message));
    } catch (err: any) {
      console.warn('[slaveActivityMiddleware] Error recording account activity:', err?.message || err);
    }
  });

  next();
}
