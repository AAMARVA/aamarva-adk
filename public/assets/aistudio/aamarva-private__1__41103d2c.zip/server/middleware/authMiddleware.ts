import crypto from 'crypto';
import { Request, Response, NextFunction } from 'express';
import rateLimit, { ipKeyGenerator } from 'express-rate-limit';
import {
  verifyAgentAccessToken,
  verifyHumanSession,
  computeApiKeyFingerprint,
  compareApiKey,
  findUserById,
  getCachedAuthUserById,
  registerExternalAuthCacheInvalidator,
  UserTokenPayload,
  HUMAN_SESSION_COOKIE_NAME,
} from '../authService.js';
import { getSupabaseClient } from '../supabase.js';
import { isIpAllowed, getClientIp } from '../utils/networkWhitelist.js';
import { MasterAccountService } from '../services/masterAccountService.js';
import { CapabilityService } from '../services/capabilityService.js';
import { BillingEntitlementService } from '../services/billingService.js';
import { isSlaveAccount as isSlaveAccountFn } from '../services/connectionService.js';

const API_KEY_VERIFY_CACHE_TTL_MS = 45_000;
const verifiedApiKeyCache = new Map<string, { userId: string; rawSha: Buffer; timestamp: number }>();

registerExternalAuthCacheInvalidator((userId?: string) => {
  if (!userId) {
    verifiedApiKeyCache.clear();
    return;
  }
  for (const [fp, entry] of verifiedApiKeyCache.entries()) {
    if (entry.userId === userId) {
      verifiedApiKeyCache.delete(fp);
    }
  }
});

export interface AuthenticatedRequest extends Request {
  user?: UserTokenPayload;
  authType?: 'human' | 'agent';
}

export function getAgentKey(req: Request): string {
  const authReq = req as AuthenticatedRequest;
  if (authReq.user?.agentId) {
    return `agent:${authReq.user.agentId}`;
  }
  if (authReq.user?.id) {
    return `agent:${authReq.user.id}`;
  }
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.split(' ')[1];
    if (!token.startsWith('sk_amr_') && !token.startsWith('amr_live_')) {
      const payload = verifyAgentAccessToken(token);
      if (payload && payload.agentId) {
        return `agent:${payload.agentId}`;
      }
      if (payload && payload.id) {
        return `agent:${payload.id}`;
      }
    }
  }
  return ipKeyGenerator(req.ip || '127.0.0.1');
}

const defaultSkip = (req: Request) => {
  // Allow test suites to explicitly enforce and verify rate limiting policies
  if (req.headers['x-test-enforce-rate-limit'] === 'true') {
    return false;
  }
  if (process.env.NODE_ENV === 'test') return true;

  // Whitelisted IPs that bypass rate limiting
  const whitelist = ['34.34.254.233', '127.0.0.1', '::1', '::ffff:127.0.0.1'];

  // Helper to check if an IP string matches the whitelist
  const checkIp = (ip: string | undefined): boolean => {
    if (!ip) return false;
    // Normalize IP: remove IPv6 mapping prefix if present
    const normalized = ip.includes(':') ? ip.split(':').pop() : ip;
    return !!normalized && whitelist.includes(normalized);
  };

  // Check the standard Express req.ip (evaluated via trusted proxy boundary)
  return checkIp(req.ip);
};

export function isMasterAccount(req: Request): boolean {
  try {
    const authReq = req as AuthenticatedRequest;
    const user = authReq.user;
    if (!user) return false;
    // Never classify explicit slave accounts as Masters
    if (
      user.is_slave === true ||
      (user as any).isSlave === true ||
      user.account_type === 'slave' ||
      user.role === 'slave'
    ) {
      return false;
    }
    const isMaster =
      user.is_master_primary === true ||
      (user as any).isMasterPrimary === true ||
      user.role === 'master' ||
      user.account_type === 'master' ||
      user.account_type === 'master_slot' ||
      user.is_master_slot === true ||
      (user as any).isMasterSlot === true ||
      (user.isMasterUser === true && authReq.authType === 'human');
    return Boolean(isMaster);
  } catch {
    return false;
  }
}

const skipForMasterAndDefault = (req: Request) => {
  if (isMasterAccount(req)) return true;
  return defaultSkip(req);
};

export const registerRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 3, // 3 / 15 mins / IP
  standardHeaders: true,
  legacyHeaders: false,
  skip: defaultSkip,
  message: { success: false, error: { code: 'RATE_LIMIT_EXCEEDED', message: 'Too many registration attempts from this IP. Please try again later.' } },
});

export const humanLoginRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // 5 / 15 mins / IP
  standardHeaders: true,
  legacyHeaders: false,
  skip: defaultSkip,
  message: { success: false, error: { code: 'RATE_LIMIT_EXCEEDED', message: 'Too many login attempts from this IP. Please try again later.' } },
});

export const agentLoginRateLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  skip: defaultSkip,
  message: { success: false, error: { code: 'RATE_LIMIT_EXCEEDED', message: 'Too many agent authentication attempts. Please slow down.' } },
});

export const passwordResetRateLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 3,
  standardHeaders: true,
  legacyHeaders: false,
  skip: defaultSkip,
  message: { success: false, error: { code: 'RATE_LIMIT_EXCEEDED', message: 'Too many password reset requests. Please try again later.' } },
});

export const agentActionLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 30,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: getAgentKey,
  skip: defaultSkip,
  message: { success: false, error: { code: 'RATE_LIMIT_EXCEEDED', message: 'Rate limit exceeded for agent actions. Please slow down.' } },
});

export const publicReadLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 30, // 30 / min
  standardHeaders: true,
  legacyHeaders: false,
  skip: defaultSkip,
  message: { success: false, error: { code: 'RATE_LIMIT_EXCEEDED', message: 'Too many read requests. Please slow down.' } },
});

export const tokenRefreshLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 10, // 10 / min / account
  standardHeaders: true,
  legacyHeaders: false,
  skip: defaultSkip,
  message: { success: false, error: { code: 'RATE_LIMIT_EXCEEDED', message: 'Too many token refresh attempts. Please try again later.' } },
});

export const emailVerificationLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  skip: defaultSkip,
  message: { success: false, error: { code: 'RATE_LIMIT_EXCEEDED', message: 'Too many email verification attempts. Please try again later.' } },
});

export const connectionRequestLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 3, // 3 / min
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: getAgentKey,
  skip: skipForMasterAndDefault,
  message: { success: false, error: { code: 'RATE_LIMIT_EXCEEDED', message: 'Too many connection requests. Please slow down.' } },
});

export async function getCapabilityMessagingLimit(req: Request, defaultLimit: number): Promise<number> {
  try {
    const authReq = req as AuthenticatedRequest;
    const user = authReq.user;
    const identifier = user?.id || user?.agentId || user?.activeAccountId;
    if (!identifier) return defaultLimit;

    // Fast-path: check explicit req.user Master / non-slave flags BEFORE refreshing remote metadata
    const isReqUserExplicitMaster =
      user?.is_master_primary === true ||
      user?.account_type === 'master' ||
      user?.account_type === 'master_slot' ||
      user?.is_master_slot === true ||
      (user?.id && !user?.master_id && user?.is_slave === false && user?.account_type !== 'slave');
    if (isReqUserExplicitMaster) {
      return defaultLimit;
    }

    // Check if account is Master primary (Master accounts never inherit or qualify for Slave Capability Increment)
    const masterService = MasterAccountService.getInstance();
    let meta = masterService.getUserMetadata(identifier);
    if (!meta && user?.id) meta = masterService.getUserMetadata(user.id);
    if (!meta) meta = await masterService.refreshUserMetadata(identifier);

    const isExplicitMaster =
      user?.is_master_primary === true ||
      meta?.is_master_primary === true ||
      user?.account_type === 'master' ||
      user?.account_type === 'master_slot' ||
      user?.is_master_slot === true ||
      (user?.id && !user?.master_id && !meta?.master_id && !user?.is_slave && user?.account_type !== 'slave');
    if (isExplicitMaster) {
      return defaultLimit;
    }

    // Query isolated per-slave capability entitlement
    const capService = CapabilityService.getInstance();
    const ent = await capService.getAgentCapability(identifier) || (user?.id ? await capService.getAgentCapability(user.id) : null);
    if (ent && ent.status === 'active') {
      const configuredLimit = typeof ent.metadata?.messaging_limit === 'number'
        ? ent.metadata.messaging_limit
        : 600;
      return Math.min(600, Math.max(defaultLimit, configuredLimit));
    }
  } catch (err) {
    // Return defaultLimit on error
  }
  return defaultLimit;
}

/**
 * 1. Direct Messages Sent Limiter
 * Covers all active API route aliases that send direct connection messages.
 * Default limit: 5 req/min. Up to 600 req/min with Capability Increment.
 */
export const directMessageSentLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: async (req: Request) => getCapabilityMessagingLimit(req, 5),
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req: Request) => `dm_sent:${getAgentKey(req)}`,
  skip: skipForMasterAndDefault,
  statusCode: 429,
  message: {
    success: false,
    error: {
      code: 'RATE_LIMIT_EXCEEDED',
      message: 'Rate limit exceeded for direct message sending. Default limit is 5 requests/minute (up to 600 requests/minute with Capability Increment).'
    }
  },
});

/**
 * 2. Cluster Messages Sent Limiter
 * Covers active API endpoints or aliases that send cluster messages.
 * Default limit: 5 req/min. Up to 600 req/min with Capability Increment.
 */
export const clusterMessageSentLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: async (req: Request) => getCapabilityMessagingLimit(req, 5),
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req: Request) => `cluster_sent:${getAgentKey(req)}`,
  skip: skipForMasterAndDefault,
  statusCode: 429,
  message: {
    success: false,
    error: {
      code: 'RATE_LIMIT_EXCEEDED',
      message: 'Rate limit exceeded for cluster message sending. Default limit is 5 requests/minute (up to 600 requests/minute with Capability Increment).'
    }
  },
});

/**
 * 3. Direct Messages Retrieved Limiter
 * Covers all active API route aliases that retrieve direct connection messages.
 * Default limit: 10 req/min. Up to 600 req/min with Capability Increment.
 */
export const directMessageRetrieveLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: async (req: Request) => getCapabilityMessagingLimit(req, 10),
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req: Request) => `dm_retrieve:${getAgentKey(req)}`,
  skip: skipForMasterAndDefault,
  statusCode: 429,
  message: {
    success: false,
    error: {
      code: 'RATE_LIMIT_EXCEEDED',
      message: 'Rate limit exceeded for direct message retrieval. Default limit is 10 requests/minute (up to 600 requests/minute with Capability Increment).'
    }
  },
});

/**
 * 4. Cluster Messages Retrieved Limiter
 * Covers active API endpoints or aliases that retrieve cluster messages.
 * Default limit: 10 req/min. Up to 600 req/min with Capability Increment.
 */
export const clusterMessageRetrieveLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: async (req: Request) => getCapabilityMessagingLimit(req, 10),
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req: Request) => `cluster_retrieve:${getAgentKey(req)}`,
  skip: skipForMasterAndDefault,
  statusCode: 429,
  message: {
    success: false,
    error: {
      code: 'RATE_LIMIT_EXCEEDED',
      message: 'Rate limit exceeded for cluster message retrieval. Default limit is 10 requests/minute (up to 600 requests/minute with Capability Increment).'
    }
  },
});

/**
 * 5. Floor Tool Discovery Limiter
 * Covers GET /api/floor/agent/tools & /api/floor/tools
 * Default limit: 5 req/min. Up to 600 req/min with Capability Increment.
 */
export const floorToolDiscoveryLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: async (req: Request) => getCapabilityMessagingLimit(req, 5),
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req: Request) => `floor_discovery:${getAgentKey(req)}`,
  skip: skipForMasterAndDefault,
  statusCode: 429,
  message: {
    success: false,
    error: {
      code: 'RATE_LIMIT_EXCEEDED',
      message: 'Rate limit exceeded for tool discovery. Default limit is 5 requests/minute (up to 600 requests/minute with Capability Increment).'
    }
  },
});

/**
 * 6. Floor Tool Invoke Limiter
 * Covers POST /api/floor/tools/:toolId/invoke
 * Default limit: 1 req/min. Up to 600 req/min with Capability Increment.
 */
export const floorToolInvokeLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: async (req: Request) => getCapabilityMessagingLimit(req, 1),
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req: Request) => `floor_invoke:${getAgentKey(req)}`,
  skip: skipForMasterAndDefault,
  statusCode: 429,
  message: {
    success: false,
    error: {
      code: 'RATE_LIMIT_EXCEEDED',
      message: 'Rate limit exceeded for tool invoke requests. Default limit is 1 request/minute (up to 600 requests/minute with Capability Increment).'
    }
  },
});

/**
 * 7. Floor Request Status Limiter
 * Covers GET /api/floor/requests/:requestId & /api/floor/requests/status/:requestId
 * Default limit: 5 req/min. Up to 600 req/min with Capability Increment.
 */
export const floorRequestStatusLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: async (req: Request) => getCapabilityMessagingLimit(req, 5),
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req: Request) => `floor_status:${getAgentKey(req)}`,
  skip: skipForMasterAndDefault,
  statusCode: 429,
  message: {
    success: false,
    error: {
      code: 'RATE_LIMIT_EXCEEDED',
      message: 'Rate limit exceeded for tool request status polling. Default limit is 5 requests/minute (up to 600 requests/minute with Capability Increment).'
    }
  },
});

/**
 * 8. Floor Tool Execute Limiter
 * Covers POST /api/floor/invocations/:invocationId/execute & /access
 * Default limit: 1 req/min. Up to 600 req/min with Capability Increment.
 */
export const floorToolExecuteLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: async (req: Request) => getCapabilityMessagingLimit(req, 1),
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req: Request) => `floor_execute:${getAgentKey(req)}`,
  skip: skipForMasterAndDefault,
  statusCode: 429,
  message: {
    success: false,
    error: {
      code: 'RATE_LIMIT_EXCEEDED',
      message: 'Rate limit exceeded for claiming tool execution credentials. Default limit is 1 request/minute (up to 600 requests/minute with Capability Increment).'
    }
  },
});

// Backward compatibility aliases
export const messageSentLimiter = directMessageSentLimiter;
export const messageRetrieveLimiter = directMessageRetrieveLimiter;

export function rejectAgentCredentials(req: Request, res: Response, next: NextFunction): void {
  const apiKeyHeader = req.headers['x-api-key'];
  const authHeader = req.headers.authorization;

  if (apiKeyHeader || (authHeader && authHeader.startsWith('Bearer sk_amr_'))) {
    res.status(403).json({
      success: false,
      error: {
        code: 'AGENT_ACCESS_FORBIDDEN',
        message: 'Forbidden: Autonomous agent credentials cannot access human account management endpoints.',
      },
    });
    return;
  }

  if (authHeader && authHeader.startsWith('Bearer ')) {
    const bearerToken = authHeader.split(' ')[1]?.trim();
    if (bearerToken && !bearerToken.startsWith('sk_amr_')) {
      const agentPayload = verifyAgentAccessToken(bearerToken);
      if (agentPayload && agentPayload.type === 'agent') {
        res.status(403).json({
          success: false,
          error: {
            code: 'AGENT_ACCESS_FORBIDDEN',
            message: 'Forbidden: Autonomous agent credentials cannot access human account management endpoints.',
          },
        });
        return;
      }
    }
  }

  next();
}

/**
 * requireHumanSession:
 * Validates HTTP-only cookie `aamarva_human_session` exclusively.
 * Used ONLY for human account and agent management routes.
 * Human sessions CANNOT perform autonomous agent operations.
 */
export async function requireHumanSession(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
  const apiKeyHeader = req.headers['x-api-key'];
  const authHeader = req.headers.authorization;

  // 1. Explicitly reject agent API keys and agent Bearer tokens
  if (apiKeyHeader || (authHeader && authHeader.startsWith('Bearer sk_amr_'))) {
    res.status(403).json({
      success: false,
      error: {
        code: 'AGENT_ACCESS_FORBIDDEN',
        message: 'Forbidden: Autonomous agent credentials cannot access human account management endpoints.',
      },
    });
    return;
  }

  let bearerToken: string | undefined;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    bearerToken = authHeader.split(' ')[1]?.trim();
  }

  if (bearerToken && !bearerToken.startsWith('sk_amr_')) {
    const agentPayload = verifyAgentAccessToken(bearerToken);
    if (agentPayload && agentPayload.type === 'agent') {
      res.status(403).json({
        success: false,
        error: {
          code: 'AGENT_ACCESS_FORBIDDEN',
          message: 'Forbidden: Autonomous agent credentials cannot access human account management endpoints.',
        },
      });
      return;
    }
  }

  const sessionCookie = req.cookies?.[HUMAN_SESSION_COOKIE_NAME];
  const rawSession = (sessionCookie && typeof sessionCookie === 'string' && sessionCookie.trim()) ? sessionCookie.trim() : bearerToken;

  if (!rawSession) {
    res.status(401).json({
      success: false,
      error: {
        code: 'UNAUTHORIZED',
        message: 'Human account session required. Please sign in with your password.',
      },
    });
    return;
  }

  try {
    const payload = await verifyHumanSession(rawSession);
    if (!payload || payload.type !== 'human') {
      res.status(401).json({
        success: false,
        error: {
          code: 'UNAUTHORIZED',
          message: 'Invalid or expired human account session.',
        },
      });
      return;
    }

    req.user = payload;
    req.authType = 'human';

    // Priority 7: Authoritative Status Check (Banned/Suspended users cannot use existing sessions)
    const supabase = getSupabaseClient();
    const activeAccountId = payload.activeAccountId || payload.id;
    const activeUser = await findUserById(supabase, activeAccountId);

    if (!activeUser || (activeUser.status !== 'active' && activeUser.status !== 'frozen')) {
      res.status(403).json({
        success: false,
        error: {
          code: 'ACCOUNT_ENFORCEMENT',
          message: `This account is currently ${activeUser?.status || 'inactive'}. Access denied.`,
        },
      });
      return;
    }

    // Dynamic Plan Expiration & Master User Check
    let planStatus = 'ACTIVE';
    const isOperatingMasterAccount = activeUser.is_master_primary === true || activeUser.id === (payload.masterUserId || payload.id);

    if (payload.masterId) {
      const masterAcct = await MasterAccountService.getInstance().getMasterAccount(payload.masterId);

      if (masterAcct) {
        planStatus = masterAcct.plan_status || 'ACTIVE';

        // Auto-expiration based on plan_expires_at
        if (planStatus === 'ACTIVE' && masterAcct.plan_expires_at && new Date(masterAcct.plan_expires_at).getTime() <= Date.now()) {
          planStatus = 'EXPIRED';
          try {
            await BillingEntitlementService.getInstance().expireMasterPlan(payload.masterId);
          } catch (e) {
            console.error('[requireHumanSession] Auto-expiration failed:', e);
          }
        }
      }
    }

    // Enforce Frozen Restrictions (Only on sub-accounts, NEVER block the Master user identity context!)
    if (!isOperatingMasterAccount && (activeUser.status === 'frozen' || planStatus === 'EXPIRED')) {
      const requestedPath = req.baseUrl + req.path;
      const isGetAgentsMe = requestedPath.endsWith('/agents/me') && req.method === 'GET';
      const isAllowedManagementRoute = requestedPath.endsWith('/auth/master/accounts') || requestedPath.endsWith('/auth/master/switch') || requestedPath.includes('/auth/master/plan');

      if (!isGetAgentsMe && !isAllowedManagementRoute) {
        res.status(403).json({
          success: false,
          error: {
            code: 'ACCOUNT_FROZEN',
            message: 'This action is disabled because your Master plan is expired. Please ask the Master account owner to renew the plan.',
          },
        });
        return;
      }
    }

    // Attach active account status
    req.user.status = activeUser.status;
    req.user.activeAccountId = activeUser.id;
    // IMPORTANT: req.user.isMasterUser reflects the AUTHENTICATED HUMAN, preserved from payload.
    // It is NOT overwritten by the active account's Master status here.

    next();
  } catch (err: any) {
    res.status(500).json({
      success: false,
      error: {
        code: 'INTERNAL_SERVER_ERROR',
        message: 'An internal error occurred during human session verification.',
      },
    });
  }
}


function isTokenRevokedByPasswordChange(
  passwordChangedAt: string | undefined | null,
  payload: { iat?: number; iatMs?: number } | null | undefined
): boolean {
  if (!passwordChangedAt || !payload) return false;
  const pwdChangedMs = new Date(passwordChangedAt).getTime();
  if (isNaN(pwdChangedMs)) return false;
  if (typeof payload.iatMs === 'number') {
    return payload.iatMs < pwdChangedMs;
  }
  if (typeof payload.iat === 'number') {
    const pwdChangedSeconds = Math.floor(pwdChangedMs / 1000);
    return payload.iat < pwdChangedSeconds;
  }
  return false;
}

function rejectRevokedAgentToken(res: Response): void {
  res.status(401).json({
    success: false,
    error: {
      code: 'UNAUTHORIZED',
      message: 'Agent session has been revoked globally. Please re-authenticate.',
    },
  });
}

/**
 * requireAgentAuth:
 * Validates agent Bearer tokens (`Authorization: Bearer <token>`) or `X-API-KEY`.
 * Used for autonomous agent network operations (posting, messaging, connections).
 * Human session cookies MUST NOT satisfy this middleware.
 */
export async function requireAgentAuth(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
  const authHeader = req.headers.authorization;
  const apiKeyHeader = req.headers['x-api-key'];

  let token: string | undefined;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    token = authHeader.split(' ')[1];
  }

  // 1. Direct API Key authentication via x-api-key header or Bearer sk_amr_... / Bearer amr_live_...
  const rawApiKey = (typeof apiKeyHeader === 'string' && apiKeyHeader.trim())
    ? apiKeyHeader.trim()
    : (token && (token.startsWith('sk_amr_') || token.startsWith('amr_live_')))
      ? token.trim()
      : null;

  if (rawApiKey) {
    try {
      const supabase = getSupabaseClient();
      const fingerprint = computeApiKeyFingerprint(rawApiKey);
      const rawSha = crypto.createHash('sha256').update(rawApiKey).digest();
      const cachedKeyEntry = verifiedApiKeyCache.get(fingerprint);
      let userRecord: any = null;
      let keyAlreadyVerified = false;

      if (
        cachedKeyEntry &&
        (Date.now() - cachedKeyEntry.timestamp) < API_KEY_VERIFY_CACHE_TTL_MS &&
        cachedKeyEntry.rawSha.length === rawSha.length &&
        crypto.timingSafeEqual(cachedKeyEntry.rawSha, rawSha)
      ) {
        const cachedUser = await findUserById(supabase, cachedKeyEntry.userId);
        if (cachedUser && (!cachedUser.apiKeyFingerprint || cachedUser.apiKeyFingerprint === fingerprint)) {
          userRecord = cachedUser;
          keyAlreadyVerified = true;
        } else {
          verifiedApiKeyCache.delete(fingerprint);
        }
      }

      if (!userRecord) {
        // 1. Direct O(1) indexed lookup in public.users by apiKeyFingerprint
        const { data: fpRecord } = await supabase
          .from('users')
          .select('*')
          .eq('apiKeyFingerprint', fingerprint)
          .maybeSingle();
        userRecord = fpRecord;

        if (!userRecord) {
          const meta = MasterAccountService.getInstance().getUserByFingerprint(fingerprint);
          if (meta) {
            userRecord = await findUserById(supabase, meta.id);
          }
        }
      }

      if (!userRecord) {
        res.status(401).json({
          success: false,
          error: {
            code: 'UNAUTHORIZED',
            message: 'Invalid agent API key.',
          },
        });
        return;
      }

      if (userRecord.status === 'deleted') {
        res.status(403).json({
          success: false,
          error: {
            code: 'ACCOUNT_DELETED',
            message: 'Agent account has been deleted.',
          },
        });
        return;
      }

      if (userRecord.status === 'frozen') {
        res.status(403).json({
          success: false,
          error: {
            code: 'ACCOUNT_FROZEN',
            message: 'Agent account is frozen.',
          },
        });
        return;
      }

      if (userRecord.status !== 'active') {
        res.status(403).json({
          success: false,
          error: {
            code: 'ACCOUNT_ENFORCEMENT',
            message: `Agent account is ${userRecord.status}. Access denied.`,
          },
        });
        return;
      }

      const masterService = MasterAccountService.getInstance();
      const meta = masterService.getUserMetadata(userRecord.id) || await masterService.refreshUserMetadata(userRecord.id);

      if (!keyAlreadyVerified) {
        // 2. Direct O(1) cached Auth user lookup by userRecord.id with fallback to metadata store
        let authoritativeHash = (userRecord as any).apiKeyHash || (userRecord as any).apiKey_hash || meta?.apiKeyHash;
        try {
          const authUser = await getCachedAuthUserById(supabase, userRecord.id);
          if (authUser?.app_metadata?.apiKeyHash) {
            authoritativeHash = authUser.app_metadata.apiKeyHash;
          }
        } catch {}

        if (!authoritativeHash) {
          res.status(401).json({
            success: false,
            error: {
              code: 'UNAUTHORIZED',
              message: 'Invalid agent API key.',
            },
          });
          return;
        }

        const isKeyValid = await compareApiKey(rawApiKey, authoritativeHash);
        if (!isKeyValid) {
          res.status(401).json({
            success: false,
            error: {
              code: 'UNAUTHORIZED',
              message: 'Invalid agent API key.',
            },
          });
          return;
        }

        if (verifiedApiKeyCache.size > 2000) verifiedApiKeyCache.clear();
        verifiedApiKeyCache.set(fingerprint, { userId: userRecord.id, rawSha, timestamp: Date.now() });
      }

      // Check Master plan entitlement for Slaves (stale active Slave record cannot bypass expired Master plan)
      const masterId = userRecord.master_id || meta?.master_id;
      const isMasterPrimary = userRecord.is_master_primary === true || meta?.is_master_primary === true;

      if (masterId && !isMasterPrimary) {
        const masterAcct = await masterService.getMasterAccount(masterId);
        if (masterAcct) {
          const isExpired = masterAcct.plan_status === 'EXPIRED' ||
            (masterAcct.plan_expires_at && new Date(masterAcct.plan_expires_at).getTime() <= Date.now());
          if (isExpired) {
            res.status(403).json({
              success: false,
              error: {
                code: 'ACCOUNT_FROZEN',
                message: 'Agent account is frozen because the Master plan is expired.',
              },
            });
            return;
          }
        }
      }

      const clientIp = getClientIp(req);
      const isMasterSlot = userRecord.is_master_slot === true || userRecord.account_type === 'master_slot' || userRecord.account_type === 'master' || userRecord.role === 'master' || userRecord.is_master_primary === true;
      const isSlaveAccount = !isMasterSlot && Boolean(
        userRecord.account_type === 'slave' ||
        userRecord.role === 'slave' ||
        userRecord.is_slave === true ||
        (userRecord.email && typeof userRecord.email === 'string' && userRecord.email.includes('+AMR-')) ||
        (userRecord.master_id && userRecord.master_id !== userRecord.id && !userRecord.is_master_primary)
      );

      if (!isIpAllowed(clientIp, userRecord.whitelisted_networks)) {
        res.status(403).json({
          success: false,
          error: {
            code: 'FORBIDDEN',
            message: 'Access denied: Source IP is not within the agent whitelisted networks perimeter.',
          },
        });
        return;
      }

      req.user = {
        id: userRecord.id,
        agentId: userRecord.agentId,
        name: userRecord.name,
        avatar: userRecord.avatar,
        email: userRecord.email,
        emailVerified: Boolean(userRecord.emailVerified === true),
        type: 'agent',
        master_id: userRecord.master_id,
        masterId: userRecord.master_id,
        is_master_primary: userRecord.is_master_primary === true,
        is_master_slot: userRecord.is_master_slot === true || userRecord.account_type === 'master_slot',
        account_type: isSlaveAccount
          ? 'slave'
          : (userRecord.account_type || (isMasterSlot ? 'master' : 'agent')),
        role: isSlaveAccount ? 'slave' : (userRecord.role || 'agent'),
        is_slave: isSlaveAccount,
        isSlave: isSlaveAccount,
      };
      (req as any).isSlaveAgent = isSlaveAccount;
      req.authType = 'agent';
      next();
      return;
    } catch (e: any) {
      console.error('Agent API key authentication error:', e.message);
      res.status(401).json({
        success: false,
        error: {
          code: 'UNAUTHORIZED',
          message: 'Invalid agent API key.',
        },
      });
      return;
    }
  }

  // 2. Bearer Access Token authentication
  if (!token) {
    res.status(401).json({
      success: false,
      error: {
        code: 'UNAUTHORIZED',
        message: 'Agent authentication required. Missing Bearer token or X-API-KEY header.',
      },
    });
    return;
  }



  const payload = verifyAgentAccessToken(token);
  if (!payload || payload.type !== 'agent') {
    res.status(401).json({
      success: false,
      error: {
        code: 'UNAUTHORIZED',
        message: 'Invalid or expired agent access token. Human sessions cannot perform agent operations.',
      },
    });
    return;
  }

  try {
    const supabase = getSupabaseClient();
    const user = await findUserById(supabase, payload.id);

    if (!user) {
      res.status(401).json({
        success: false,
        error: {
          code: 'UNAUTHORIZED',
          message: 'Invalid agent token.',
        },
      });
      return;
    }

    // Invalidation check: Revoke if user credentials/sessions were globally invalidated after this token was issued
    if (isTokenRevokedByPasswordChange(user.passwordChangedAt, payload)) {
      rejectRevokedAgentToken(res);
      return;
    }


    if (user.status === 'deleted') {
      res.status(403).json({
        success: false,
        error: {
          code: 'ACCOUNT_DELETED',
          message: 'Agent account has been deleted.',
        },
      });
      return;
    }

    if (user.status === 'frozen') {
      res.status(403).json({
        success: false,
        error: {
          code: 'ACCOUNT_FROZEN',
          message: 'Agent account is frozen.',
        },
      });
      return;
    }

    if (user.status !== 'active') {
      res.status(403).json({
        success: false,
        error: {
          code: 'ACCOUNT_ENFORCEMENT',
          message: `Agent account is currently ${user.status}. Access denied.`,
        },
      });
      return;
    }

    // Check Master plan entitlement for Slaves (stale active Slave record cannot bypass expired Master plan)
    const masterService = MasterAccountService.getInstance();
    const meta = masterService.getUserMetadata(user.id) || await masterService.refreshUserMetadata(user.id);
    const masterId = (user as any).master_id || meta?.master_id;
    const isMasterPrimary = (user as any).is_master_primary === true || meta?.is_master_primary === true;

    if (masterId && !isMasterPrimary) {
      const masterAcct = await masterService.getMasterAccount(masterId);
      if (masterAcct) {
        const isExpired = masterAcct.plan_status === 'EXPIRED' ||
          (masterAcct.plan_expires_at && new Date(masterAcct.plan_expires_at).getTime() <= Date.now());
        if (isExpired) {
          res.status(403).json({
            success: false,
            error: {
              code: 'ACCOUNT_FROZEN',
              message: 'Agent account is frozen because the Master plan is expired.',
            },
          });
          return;
        }
      }
    }

    const clientIp = getClientIp(req);
    const resolvedMasterId = masterId;
    const isMasterSlot = (user as any)?.is_master_slot === true || (user as any)?.account_type === 'master_slot' || (user as any)?.account_type === 'master' || user.role === 'master' || isMasterPrimary;
    const isSlaveAccount = !isMasterSlot && Boolean(
      (resolvedMasterId && resolvedMasterId !== user.id && !isMasterPrimary) ||
      user.role === 'slave' ||
      user.account_type === 'slave' ||
      user.is_slave === true ||
      (user as any).isSlave === true ||
      (user.email && typeof user.email === 'string' && user.email.includes('+AMR-'))
    );
    if (!isSlaveAccount) {
      res.status(401).json({
        success: false,
        error: {
          code: 'UNAUTHORIZED',
          message: 'Invalid agent token.',
        },
      });
      return;
    }
    if (!isIpAllowed(clientIp, user.whitelisted_networks)) {
      res.status(403).json({
        success: false,
        error: {
          code: 'FORBIDDEN',
          message: 'Access denied: Source IP is not within the agent whitelisted networks perimeter.',
        },
      });
      return;
    }

    req.user = {
      ...payload,
      id: user.id,
      agentId: user.agentId,
      name: (user as any).name || payload.name,
      avatar: (user as any).avatar || payload.avatar,
      email: (user as any).email || payload.email,
      emailVerified: Boolean(user.emailVerified === true),
      master_id: resolvedMasterId,
      masterId: resolvedMasterId,
      is_master_primary: isMasterPrimary,
      account_type: isSlaveAccount ? 'slave' : ((user as any).account_type || 'master'),
      role: isSlaveAccount ? 'slave' : ((user as any).role || 'agent'),
      is_slave: isSlaveAccount,
      isSlave: isSlaveAccount,
    };
    (req as any).isSlaveAgent = isSlaveAccount;
    req.authType = 'agent';
    next();
  } catch (err: any) {
    res.status(500).json({
      success: false,
      error: {
        code: 'INTERNAL_SERVER_ERROR',
        message: 'An internal error occurred during agent token authentication.',
      },
    });
  }
}

export function requireAgent(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  if (!req.user || req.authType !== 'agent') {
    res.status(403).json({
      success: false,
      error: {
        code: 'FORBIDDEN',
        message: 'Forbidden: Only autonomous agent accounts can perform network activities.',
      },
    });
    return;
  }
  next();
}

/**
 * enforceSlavePostGuard:
 * Strictly enforces that if an authenticated caller is a slave agent (or agent API user),
 * they MUST have registered their cryptographic identity (E2EE public key) before making any POST requests.
 * 
 * Applies ONLY to POST endpoints (mutating/talking/initiating actions).
 * GET (inspection/reads) and PUT (such as PUT /api/agents/me/e2ee for registration) are permitted.
 */
export async function enforceSlavePostGuard(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
  if (req.method !== 'POST' || !req.user?.id) {
    return next();
  }
  const path = (req.baseUrl || '') + (req.path || '');
  if (path.includes('/auth/login') || path.includes('/auth/register') || path.includes('/auth/refresh') || path.includes('/auth/logout') || path.includes('/account/access-management') || path.includes('/access-management')) {
    return next();
  }
  try {
    const reqUserIsSlave = isSlaveAccountFn(req.user);
    if (reqUserIsSlave && req.authType === 'human' && (path.includes('/messages') || path.includes('/chat') || path.includes('/attachments'))) {
      res.status(403).json({
        success: false,
        error: {
          code: 'SLAVE_UI_MESSAGING_DISABLED',
          message: 'Slave accounts cannot send messages via the UI. Messaging must be performed via the agent runtime API.'
        }
      });
      return;
    }

    // Fast-path: skip redundant findUserById query when req.user already has authoritative role flags indicating non-slave
    const hasExplicitRoleFlags = Boolean(
      req.user.is_master_primary === true ||
      (req.user as any).isMasterPrimary === true ||
      req.user.account_type === 'master' ||
      req.user.account_type === 'master_slot' ||
      req.user.is_slave === false
    );
    if (!reqUserIsSlave && hasExplicitRoleFlags) {
      return next();
    }

    const supabase = getSupabaseClient();
    const dbUser = await findUserById(supabase, req.user.id);

    const resolvedUser = dbUser ? { ...(req.user || {}), ...dbUser } : req.user;
    const isSlave = isSlaveAccountFn(resolvedUser);

    if (isSlave) {
      if (req.authType === 'human' && (path.includes('/messages') || path.includes('/chat') || path.includes('/attachments'))) {
        res.status(403).json({
          success: false,
          error: {
            code: 'SLAVE_UI_MESSAGING_DISABLED',
            message: 'Slave accounts cannot send messages via the UI. Messaging must be performed via the agent runtime API.'
          }
        });
        return;
      }

      const cachedDbPubKey = dbUser?.e2eePublicKey;
      if (typeof cachedDbPubKey === 'string' && cachedDbPubKey.trim().length > 0) {
        return next();
      }

      const authUser = await getCachedAuthUserById(supabase, req.user.id);
      const meta = authUser?.user_metadata || {};
      if (!meta.e2eePublicKey || typeof meta.e2eePublicKey !== 'string' || meta.e2eePublicKey.trim().length === 0) {
        res.status(403).json({
          success: false,
          error: {
            code: 'E2EE_KEY_REQUIRED',
            message: 'Slave agent identity registration required. Register an E2EE public key via PUT /api/agents/me/e2ee before taking actions or communicating.'
          }
        });
        return;
      }
    }
  } catch (err) {
    console.warn('[enforceSlavePostGuard] verification notice:', err);
  }
  return next();
}

/**
 * requireUserOrAgentAuth:
 * Accepts either a verified human session cookie or valid agent Bearer token / X-API-KEY.
 * Allows human users in web dashboard and autonomous agents to view connections and manage requests.
 */
export async function requireUserOrAgentAuth(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
  if (req.user) {
    return enforceSlavePostGuard(req, res, next);
  }
  const sessionCookie = req.cookies?.[HUMAN_SESSION_COOKIE_NAME];
  const authHeader = req.headers.authorization;
  const bearerToken = (authHeader && authHeader.startsWith('Bearer ')) ? authHeader.split(' ')[1] : undefined;
  const queryToken = (typeof req.query?.token === 'string' && (req.query.token as string).trim()) ? (req.query.token as string).trim() : undefined;

  const candidateSession = (sessionCookie && typeof sessionCookie === 'string' && sessionCookie.trim())
    ? sessionCookie.trim()
    : (bearerToken || queryToken);

  if (candidateSession) {
    try {
      const payload = await verifyHumanSession(candidateSession);
      if (payload && payload.type === 'human') {
        if (!(payload as any).id && payload.userId) {
          (payload as any).id = payload.userId;
        }
        req.user = payload;
        req.authType = 'human';
        return enforceSlavePostGuard(req, res, next);
      }
    } catch (e) {}

    try {
      const agentPayload = verifyAgentAccessToken(candidateSession);
      if (agentPayload && (agentPayload.agentId || agentPayload.id)) {
        const agentUserId = agentPayload.id;
        let masterId = (agentPayload as any).masterId || (agentPayload as any).master_id;
        let userName = agentPayload.name;
        let userAvatar = (agentPayload as any).avatar;
        let emailVerified = (agentPayload as any).emailVerified;
        let accountType = (agentPayload as any).account_type;
        let isMasterPrimary = (agentPayload as any).is_master_primary;

        let agentDbUser: any = null;
        try {
          const supabase = getSupabaseClient();
          agentDbUser = await findUserById(supabase, agentUserId);
        } catch {}

        if (agentDbUser) {
          if (isTokenRevokedByPasswordChange(agentDbUser.passwordChangedAt, agentPayload)) {
            rejectRevokedAgentToken(res);
            return;
          }
          if (agentDbUser.status && agentDbUser.status !== 'active') {
            res.status(403).json({
              success: false,
              error: {
                code: 'ACCOUNT_ENFORCEMENT',
                message: `Agent account is currently ${agentDbUser.status}. Access denied.`,
              },
            });
            return;
          }
          masterId = agentDbUser.master_id || masterId;
          userName = agentDbUser.name || userName;
          userAvatar = agentDbUser.avatar || userAvatar;
          emailVerified = agentDbUser.emailVerified ?? emailVerified;
          accountType = agentDbUser.account_type || accountType;
          isMasterPrimary = agentDbUser.is_master_primary;
        }

        req.user = {
          id: agentUserId,
          agentId: agentPayload.agentId || agentPayload.id,
          name: userName,
          avatar: userAvatar,
          emailVerified: Boolean(emailVerified),
          email: agentPayload.email,
          master_id: masterId,
          masterId: masterId,
          is_master_primary: isMasterPrimary,
          account_type: accountType || 'slave',
          type: 'agent'
        };
        req.authType = 'agent';
        return enforceSlavePostGuard(req, res, next);
      }
    } catch (e) {}
  }

  // Fallback to agent API key auth if an API key was provided
  if (req.headers['x-api-key']) {
    return await requireAgentAuth(req, res, () => enforceSlavePostGuard(req, res, next));
  }

  if (!res.headersSent) {
    res.status(401).json({
      success: false,
      error: {
        code: 'UNAUTHORIZED',
        message: 'Authentication required. Please provide a valid human session or agent API key.',
      },
    });
  }
}

/**
 * requireHumanSecretsAuth:
 * STRICT ISOLATION GUARD FOR SECRETS PRESERVER.
 * 
 * Only human user sessions are permitted to access the Secrets Preserver.
 * Autonomous agents are categorically FORBIDDEN from accessing secrets:
 * - Agents cannot GET secrets or secret metadata
 * - Agents cannot POST / create secrets
 * - Agents cannot DELETE secrets
 * - Any request bearing agent authentication (X-API-KEY, agent Bearer token, or sk_amr_*)
 *   is strictly rejected with 403 Forbidden.
 * Unauthenticated requests receive 401 Unauthorized.
 */
export async function requireHumanSecretsAuth(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
  const authHeader = req.headers.authorization;
  const apiKeyHeader = req.headers['x-api-key'];

  // 1. Explicitly reject agent API keys
  if (apiKeyHeader || (authHeader && (authHeader.startsWith('Bearer sk_amr_') || authHeader.startsWith('Bearer amr_live_')))) {
    res.status(403).json({
      success: false,
      error: {
        code: 'AGENT_ACCESS_FORBIDDEN',
        message: 'Forbidden: Autonomous agent accounts cannot access the Secrets Preserver. Secrets are private to human users.',
      },
    });
    return;
  }

  // 2. Check if Bearer token is an agent token
  let bearerToken: string | undefined;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    bearerToken = authHeader.split(' ')[1]?.trim();
  }

  if (bearerToken && !bearerToken.startsWith('sk_amr_')) {
    const agentPayload = verifyAgentAccessToken(bearerToken);
    if (agentPayload && agentPayload.type === 'agent') {
      res.status(403).json({
        success: false,
        error: {
          code: 'AGENT_ACCESS_FORBIDDEN',
          message: 'Forbidden: Autonomous agent accounts cannot access the Secrets Preserver. Secrets are private to human users.',
        },
      });
      return;
    }
  }

  // 3. Resolve human session from HTTP-only cookie or human Bearer token
  const sessionCookie = req.cookies?.[HUMAN_SESSION_COOKIE_NAME];
  const candidateSession = (sessionCookie && typeof sessionCookie === 'string' && sessionCookie.trim())
    ? sessionCookie.trim()
    : bearerToken;

  if (!candidateSession) {
    res.status(401).json({
      success: false,
      error: {
        code: 'UNAUTHORIZED',
        message: 'Human account authentication required to access the Secrets Preserver.',
      },
    });
    return;
  }

  try {
    const payload = await verifyHumanSession(candidateSession);
    if (!payload || payload.type !== 'human') {
      res.status(401).json({
        success: false,
        error: {
          code: 'UNAUTHORIZED',
          message: 'Invalid or expired human account session.',
        },
      });
      return;
    }

    req.user = payload;
    req.authType = 'human';

    // Priority 7: Authoritative Status Check (Banned/Suspended users cannot use existing sessions)
    const supabase = getSupabaseClient();
    const user = await findUserById(supabase, payload.id);

    if (!user || user.status !== 'active') {
      res.status(403).json({
        success: false,
        error: {
          code: 'ACCOUNT_ENFORCEMENT',
          message: `This account is currently ${user?.status || 'inactive'}. Access denied.`,
        },
      });
      return;
    }

    next();
  } catch (err: any) {
    res.status(500).json({
      success: false,
      error: {
        code: 'INTERNAL_SERVER_ERROR',
        message: 'An internal error occurred during secrets authentication verification.',
      },
    });
  }
}

export function rejectIfFrozen(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  if (req.user?.status === 'frozen') {
    res.status(403).json({
      success: false,
      error: {
        code: 'ACCOUNT_FROZEN',
        message: 'This action is disabled because the Master plan has expired. Please renew the plan to reactivate the account.',
      },
    });
    return;
  }
  next();
}

export function requireMasterOnly(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  const user = req.user;
  const isMaster = user && (
    user.isMasterUser === true ||
    user.is_master_primary === true ||
    user.account_type === 'master' ||
    user.account_type === 'master_slot' ||
    user.is_master_slot === true ||
    (user as any).isMasterSlot === true
  );
  if (!req.user || req.authType !== 'human' || !isMaster) {
    res.status(403).json({
      success: false,
      error: {
        code: 'MASTER_ONLY',
        message: 'Access denied. This operation requires a Master Account session.'
      }
    });
    return;
  }
  next();
}


