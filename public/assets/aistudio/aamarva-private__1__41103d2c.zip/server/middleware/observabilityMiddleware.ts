import { Request, Response, NextFunction } from 'express';
import crypto from 'crypto';

export interface ObservableRequest extends Request {
  requestId?: string;
  startTime?: number;
}

let fastReqCounter = 0;

function isStaticOrDevAssetPath(url: string): boolean {
  const pathOnly = url.split('?')[0];
  return (
    pathOnly.startsWith('/@') ||
    pathOnly.startsWith('/src/') ||
    pathOnly.startsWith('/assets/') ||
    pathOnly.startsWith('/node_modules/') ||
    pathOnly.startsWith('/public/') ||
    /\.(?:js|mjs|ts|tsx|css|png|jpg|jpeg|gif|svg|ico|woff2?|ttf|map)$/i.test(pathOnly)
  );
}

export function observabilityMiddleware(req: ObservableRequest, res: Response, next: NextFunction): void {
  const url = req.originalUrl || req.url || '';
  const isAsset = isStaticOrDevAssetPath(url);
  const requestId =
    (req.headers['x-request-id'] as string) ||
    (isAsset ? `req_${(++fastReqCounter).toString(36)}` : `req_${crypto.randomUUID()}`);
  req.requestId = requestId;
  req.startTime = Date.now();

  res.setHeader('X-Request-ID', requestId);

  if (!isAsset) {
    res.on('finish', () => {
      const duration = req.startTime ? Date.now() - req.startTime : 0;
      const statusCode = res.statusCode;

      // Avoid synchronous JSON log formatting spam for fast routine 2xx/3xx in test/dev unless slow or non-GET API
      if (statusCode < 400 && duration < 250 && req.method === 'GET' && process.env.NODE_ENV !== 'production') {
        return;
      }

      const logEntry = {
        timestamp: new Date().toISOString(),
        requestId,
        method: req.method,
        url,
        statusCode,
        durationMs: duration,
        userAgent: req.headers['user-agent'] || 'unknown',
        ip: req.ip || req.socket.remoteAddress || 'unknown',
      };

      if (statusCode >= 500) {
        console.error(`[HTTP 5XX] ${JSON.stringify(logEntry)}`);
      } else if (statusCode >= 400) {
        console.warn(`[HTTP 4XX] ${JSON.stringify(logEntry)}`);
      } else {
        console.log(`[HTTP 2XX/3XX] ${JSON.stringify(logEntry)}`);
      }
    });
  }

  next();
}
