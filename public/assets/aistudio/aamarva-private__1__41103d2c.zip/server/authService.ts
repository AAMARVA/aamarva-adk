import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import { UserRecord, RefreshTokenRecord } from './db.js';
import { getSupabaseClient, isSupabaseConfigured, registerAuthUpdateHook, registerSupabaseClientResetHook } from './supabase.js';
import { sendEmailVerification, sendPasswordResetEmail, sendApiKeyRotationEmail } from './emailService.js';
import { sendMasterCascadeRotationVerificationEmail } from './services/masterRotationEmailService.js';
import { config } from './config.js';
import { validateAndNormalizeWhitelist, isIpAllowed } from './utils/networkWhitelist.js';
import { popInventoryItem, recycleAvatarToInventory } from './services/inventoryService.js';
const enrollAutoSecret = async (...args: any[]) => {};
const revokeAutoSecret = async (...args: any[]) => {};
const revokeAllAutoSessions = async (...args: any[]) => {};


export interface UserTokenPayload {
  id: string;
  agentId: string;
  email: string;
  emailVerified?: boolean;
  type?: 'human' | 'agent' | 'command_pit';
  isCommandPit?: boolean;
  commandPitScopes?: string[];
  name?: string;
  avatar?: string;
  iat?: number;
  iatMs?: number;
  status?: string;
  activeAccountId?: string;
  masterId?: string;
  master_id?: string;
  masterUserId?: string;
  isMasterUser?: boolean;
  is_master_primary?: boolean;
  is_master_slot?: boolean;
  account_type?: string;
  role?: string;
  is_slave?: boolean;
  isSlave?: boolean;
  whitelisted_networks?: string[];
}

export interface HumanSessionPayload {
  id: string;
  userId?: string;
  agentId: string;
  email: string;
  emailVerified?: boolean;
  type: 'human';
  iat?: number;
  iatMs?: number;
  activeAccountId?: string;
  masterId?: string;
  masterUserId?: string;
  isMasterUser?: boolean;
  name?: string;
  avatar?: string;
  master_id?: string;
  fleet_id?: string;
  account_type?: string;
  role?: string;
  is_master_slot?: boolean;
  is_master_primary?: boolean;
  is_slave?: boolean;
  returnMasterId?: string;
  returnSlaveId?: string;
  whitelisted_networks?: string[];
}

export interface AgentTokenPayload {
  id: string;
  agentId: string;
  email: string;
  emailVerified?: boolean;
  type: 'agent';
  name?: string;
  avatar?: string;
  iat?: number;
  iatMs?: number;
}

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
}

export const REFRESH_COOKIE_NAME = 'aamarva_rt';
export const HUMAN_SESSION_COOKIE_NAME = 'aamarva_human_session';

export const DEFAULT_BIO = "Hello World";

export function getRefreshCookieOptions() {
  return {
    httpOnly: true,
    secure: true,
    sameSite: 'none' as const,
    path: '/',
    maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
  };
}

export function getHumanSessionCookieOptions() {
  return {
    httpOnly: true,
    secure: true,
    sameSite: 'none' as const,
    path: '/',
    maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
  };
}

export function getJwtSecret(): string {
  const secret = process.env.JWT_SECRET?.trim();
  if (!secret) {
    if (process.env.NODE_ENV === 'production') {
      throw new Error('[Security Configuration Error] JWT_SECRET environment variable is not defined.');
    }
    return 'aamarva-dev-jwt-secret-placeholder-minimum-length-32';
  }
  if (secret.length < 32 && process.env.NODE_ENV === 'production') {
    throw new Error('[Security Configuration Error] JWT_SECRET must be at least 32 characters long in production.');
  }
  return secret;
}

export function getJwtRefreshSecret(): string {
  const secret = process.env.JWT_REFRESH_SECRET?.trim();
  if (!secret) {
    if (process.env.NODE_ENV === 'production') {
      throw new Error('[Security Configuration Error] JWT_REFRESH_SECRET environment variable is not defined.');
    }
    return 'aamarva-dev-refresh-secret-placeholder-minimum-length-32';
  }
  if (secret.length < 32 && process.env.NODE_ENV === 'production') {
    throw new Error('[Security Configuration Error] JWT_REFRESH_SECRET must be at least 32 characters long in production.');
  }
  if (process.env.NODE_ENV === 'production' && secret === process.env.JWT_SECRET?.trim()) {
    throw new Error('[Security Configuration Error] JWT_REFRESH_SECRET must be distinct from JWT_SECRET in production.');
  }
  return secret;
}


export function validatePasswordStrength(password: string): { valid: boolean; message?: string } {
  if (!password || typeof password !== 'string' || password.length === 0) {
    return { valid: false, message: 'Password is required.' };
  }
  return { valid: true };
}

export function validateEmailFormat(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

export function normalizeEmail(email: string): string {
  return email.trim().toLowerCase();
}

export async function hashPassword(password: string): Promise<string> {
  const saltRounds = 12;
  return await bcrypt.hash(password, saltRounds);
}

export async function comparePassword(password: string, hash: string): Promise<boolean> {
  return await bcrypt.compare(password, hash);
}

export async function hashApiKey(apiKey: string): Promise<string> {
  const saltRounds = 10;
  return await bcrypt.hash(apiKey, saltRounds);
}

export async function compareApiKey(apiKey: string, hash: string): Promise<boolean> {
  return await bcrypt.compare(apiKey, hash);
}

export function computeApiKeyFingerprint(apiKey: string): string {
  const cleanKey = (apiKey || '').trim();
  if (!cleanKey) return '';
  const secret = process.env.API_KEY_HMAC_SECRET || (process.env.NODE_ENV === 'production' ? '' : 'aamarva-dev-api-key-hmac-secret-placeholder-minimum-32');
  if (!secret) {
    throw new Error('Critical configuration error: API_KEY_HMAC_SECRET environment variable is missing.');
  }
  return crypto.createHmac('sha256', secret).update(cleanKey).digest('hex');
}

let authUsersCache: any[] | null = null;
let lastCacheFetchTime = 0;
const CACHE_TTL_MS = 30000; // 30 seconds

// In-memory cache for individual auth records, public user profiles, and active human sessions
const supabaseClientIds = new WeakMap<object, number>();
let nextSupabaseClientId = 0;

function getSupabaseClientCachePrefix(supabase: any): string {
  if (!supabase || (typeof supabase !== 'object' && typeof supabase !== 'function')) {
    return '0';
  }
  let cid = supabaseClientIds.get(supabase);
  if (!cid) {
    cid = ++nextSupabaseClientId;
    supabaseClientIds.set(supabase, cid);
  }
  return String(cid);
}

const authUserRecordCache = new Map<string, { user: any; timestamp: number }>();
const userRecordCacheById = new Map<string, { user: any; timestamp: number }>();
const humanSessionCache = new Map<string, { record: any; timestamp: number }>();
const inFlightAuthUserLookups = new Map<string, Promise<any>>();
const inFlightUserByIdLookups = new Map<string, Promise<any>>();
const USER_CACHE_TTL_MS = 120000; // 2 minutes (invalidated explicitly on profile/key mutations)
const HUMAN_SESSION_CACHE_TTL_MS = 60000; // 1 minute (invalidated explicitly on session/password mutations)

// Dedicated persistent fallback store for user network IP whitelists
const WHITELIST_STORE_PATH = path.resolve(process.cwd(), 'server', 'data', 'user_whitelists.json');

function loadWhitelistStore(): Map<string, string[]> {
  const store = new Map<string, string[]>();
  try {
    if (fs.existsSync(WHITELIST_STORE_PATH)) {
      const raw = fs.readFileSync(WHITELIST_STORE_PATH, 'utf-8');
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === 'object') {
        for (const [k, v] of Object.entries(parsed)) {
          if (Array.isArray(v)) store.set(k, v);
        }
      }
    }
  } catch (e) {}
  return store;
}

const userWhitelistStore = loadWhitelistStore();

function saveWhitelistStore() {
  try {
    const dir = path.dirname(WHITELIST_STORE_PATH);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    const obj: Record<string, string[]> = {};
    for (const [k, v] of userWhitelistStore.entries()) {
      obj[k] = v;
    }
    fs.writeFileSync(WHITELIST_STORE_PATH, JSON.stringify(obj, null, 2), 'utf-8');
  } catch (e) {}
}

export function setUserWhitelistDirect(userId: string, networks: string[]): void {
  if (!userId) return;
  userWhitelistStore.set(userId, networks);
  saveWhitelistStore();
  invalidateUserRecordCache(userId);
}

export function getUserWhitelistDirect(userId: string): string[] | undefined {
  if (!userId) return undefined;
  const wl = userWhitelistStore.get(userId);
  if (Array.isArray(wl)) return wl;

  const clean = userId.trim().toLowerCase();
  for (const [k, v] of userWhitelistStore.entries()) {
    if (k.toLowerCase() === clean && Array.isArray(v)) {
      return v;
    }
  }
  return undefined;
}

// Dedicated persistent fallback store for user Access Management rules
export interface UserAccessManagementData {
  disabledEndpoints: string[];
  customRateLimits: Record<string, number>;
  updatedAt?: string;
  isIndependent?: boolean;
}

const ACCESS_MGMT_STORE_PATH = path.resolve(process.cwd(), 'server', 'data', 'user_access_management.json');

function loadAccessManagementStore(): Map<string, UserAccessManagementData> {
  const store = new Map<string, UserAccessManagementData>();
  try {
    if (fs.existsSync(ACCESS_MGMT_STORE_PATH)) {
      const raw = fs.readFileSync(ACCESS_MGMT_STORE_PATH, 'utf-8');
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === 'object') {
        for (const [k, v] of Object.entries(parsed)) {
          if (v && typeof v === 'object') {
            store.set(k, {
              disabledEndpoints: Array.isArray((v as any).disabledEndpoints) ? (v as any).disabledEndpoints : [],
              customRateLimits: (v as any).customRateLimits && typeof (v as any).customRateLimits === 'object' ? (v as any).customRateLimits : {},
              updatedAt: (v as any).updatedAt || new Date().toISOString(),
              isIndependent: Boolean((v as any).isIndependent)
            });
          }
        }
      }
    }
  } catch (e) {}
  return store;
}

const userAccessManagementStore = loadAccessManagementStore();

function saveAccessManagementStore() {
  try {
    const dir = path.dirname(ACCESS_MGMT_STORE_PATH);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    const obj: Record<string, UserAccessManagementData> = {};
    for (const [k, v] of userAccessManagementStore.entries()) {
      obj[k] = v;
    }
    fs.writeFileSync(ACCESS_MGMT_STORE_PATH, JSON.stringify(obj, null, 2), 'utf-8');
  } catch (e) {}
}

export function setUserAccessManagementDirect(userId: string, data: UserAccessManagementData, additionalKeys?: string[]): void {
  if (!userId) return;
  const cleanData: UserAccessManagementData = {
    disabledEndpoints: Array.isArray(data.disabledEndpoints) ? data.disabledEndpoints.map(s => String(s).trim()).filter(Boolean) : [],
    customRateLimits: data.customRateLimits && typeof data.customRateLimits === 'object' ? data.customRateLimits : {},
    updatedAt: data.updatedAt || new Date().toISOString(),
    isIndependent: Boolean(data.isIndependent)
  };
  const rawKey = String(userId).trim();
  const cleanKey = rawKey.replace(/^@+/, '');

  const keysToStore = new Set<string>([rawKey, cleanKey, `@${cleanKey}`]);
  if (additionalKeys) {
    for (const k of additionalKeys) {
      if (k) {
        const tr = String(k).trim();
        keysToStore.add(tr);
        keysToStore.add(tr.replace(/^@+/, ''));
        keysToStore.add(`@${tr.replace(/^@+/, '')}`);
      }
    }
  }

  for (const k of keysToStore) {
    userAccessManagementStore.set(k, cleanData);
    invalidateUserRecordCache(k);
  }

  saveAccessManagementStore();

  try {
    const { SecurityService } = require('./services/securityService.js');
    const securityService = SecurityService.getInstance();
    for (const k of keysToStore) {
      securityService.setUserDisabledEndpoints(k, cleanData.disabledEndpoints);
      securityService.setUserCustomRateLimits(k, cleanData.customRateLimits);
    }
  } catch (e) {}
}

export function getUserAccessManagementDirect(userId: string): UserAccessManagementData | undefined {
  if (!userId) return undefined;
  const rawKey = String(userId).trim();
  const clean = rawKey.replace(/^@+/, '').toLowerCase();

  // 1. Exact raw key match
  const direct = userAccessManagementStore.get(rawKey);
  if (direct) return direct;

  // 2. Exact match with stripped @
  const directClean = userAccessManagementStore.get(rawKey.replace(/^@+/, ''));
  if (directClean) return directClean;

  // 3. Exact match with prepended @
  const directAt = userAccessManagementStore.get(`@${rawKey.replace(/^@+/, '')}`);
  if (directAt) return directAt;

  // 4. Case-insensitive normalization across all entries
  for (const [k, v] of userAccessManagementStore.entries()) {
    const cleanK = k.trim().replace(/^@+/, '').toLowerCase();
    if ((cleanK === clean || k.toLowerCase() === clean || cleanK === rawKey.toLowerCase()) && v) {
      return v;
    }
  }
  return undefined;
}

const externalAuthCacheInvalidators = new Set<(userId?: string) => void>();

export function registerExternalAuthCacheInvalidator(fn: (userId?: string) => void): void {
  externalAuthCacheInvalidators.add(fn);
}

export function invalidateAuthCache(): void {
  authUsersCache = null;
  lastCacheFetchTime = 0;
  authUserRecordCache.clear();
  userRecordCacheById.clear();
  humanSessionCache.clear();
  inFlightAuthUserLookups.clear();
  inFlightUserByIdLookups.clear();
  for (const fn of externalAuthCacheInvalidators) {
    try { fn(); } catch {}
  }
}

export function invalidateUserRecordCache(userId?: string): void {
  if (!userId) {
    userRecordCacheById.clear();
    authUserRecordCache.clear();
    inFlightAuthUserLookups.clear();
    inFlightUserByIdLookups.clear();
    for (const fn of externalAuthCacheInvalidators) {
      try { fn(); } catch {}
    }
    return;
  }
  const suffix = `:${userId}`;
  for (const key of userRecordCacheById.keys()) {
    if (key === userId || key.endsWith(suffix)) userRecordCacheById.delete(key);
  }
  for (const key of authUserRecordCache.keys()) {
    if (key === userId || key.endsWith(suffix)) authUserRecordCache.delete(key);
  }
  for (const key of inFlightAuthUserLookups.keys()) {
    if (key === userId || key.endsWith(suffix)) inFlightAuthUserLookups.delete(key);
  }
  for (const key of inFlightUserByIdLookups.keys()) {
    if (key === userId || key.endsWith(suffix)) inFlightUserByIdLookups.delete(key);
  }
  for (const fn of externalAuthCacheInvalidators) {
    try { fn(userId); } catch {}
  }
}

registerAuthUpdateHook((userId: string) => {
  invalidateUserRecordCache(userId);
});

registerSupabaseClientResetHook(() => {
  invalidateAuthCache();
});

export async function getCachedAuthUserById(supabase: any, userId: string): Promise<any> {
  if (!supabase?.auth?.admin || !userId) return null;
  const cacheKey = `${getSupabaseClientCachePrefix(supabase)}:${userId}`;
  const now = Date.now();
  const cached = authUserRecordCache.get(cacheKey);
  if (cached && (now - cached.timestamp < USER_CACHE_TTL_MS)) {
    return cached.user;
  }
  const existingFlight = inFlightAuthUserLookups.get(cacheKey);
  if (existingFlight) {
    return existingFlight;
  }

  const lookupPromise = (async () => {
    try {
      const { data, error } = await supabase.auth.admin.getUserById(userId);
      const ts = Date.now();
      if (!error && data?.user) {
        if (authUserRecordCache.size > 2000) authUserRecordCache.clear();
        authUserRecordCache.set(cacheKey, { user: data.user, timestamp: ts });
        return data.user;
      }
      authUserRecordCache.set(cacheKey, { user: null, timestamp: ts });
    } catch {}
    return null;
  })().finally(() => {
    inFlightAuthUserLookups.delete(cacheKey);
  });

  inFlightAuthUserLookups.set(cacheKey, lookupPromise);
  return lookupPromise;
}

async function fetchFreshAuthUser(supabase: any, userId: string): Promise<any> {
  if (!supabase || !supabase.auth?.admin || !userId) return null;
  try {
    const { data, error } = await supabase.auth.admin.getUserById(userId);
    if (!error && data?.user) {
      const cacheKey = `${getSupabaseClientCachePrefix(supabase)}:${userId}`;
      authUserRecordCache.set(cacheKey, { user: data.user, timestamp: Date.now() });
      return data.user;
    }
  } catch {}
  return await getCachedAuthUserById(supabase, userId).catch(() => null);
}

export async function getAuthUsersList(forceRefresh = false): Promise<any[]> {
  const now = Date.now();
  if (!forceRefresh && authUsersCache && (now - lastCacheFetchTime < CACHE_TTL_MS)) {
    return authUsersCache;
  }

  const supabase = getSupabaseClient();
  const { data: { users: authUsers }, error: authErr } = await supabase.auth.admin.listUsers();
  if (authErr || !authUsers) {
    console.error('getAuthUsersList: Failed to list auth users:', authErr);
    return authUsersCache || [];
  }

  authUsersCache = authUsers;
  lastCacheFetchTime = now;
  return authUsers;
}

export async function getAuthUserForRecord(supabase: any, userRecord: { id?: string; email?: string }): Promise<any> {
  if (!supabase || !supabase.auth?.admin || !userRecord?.id) return null;
  return await getCachedAuthUserById(supabase, userRecord.id);
}

export function generateAgentId(): string {
  const randomHex = crypto.randomBytes(3).toString('hex').toUpperCase();
  return `AMR-${randomHex}`;
}

export function generateApiKey(): string {
  return `amr_live_${crypto.randomBytes(32).toString('hex')}`;
}

export async function createHumanSession(userId: string, activeUserId?: string): Promise<string> {
  const sessionId = crypto.randomUUID();
  const nowMs = Date.now();
  const nowSeconds = Math.floor(nowMs / 1000);
  const expSeconds = nowSeconds + 7 * 24 * 3600; // 7 days
  
  const payload = {
    userId: activeUserId || userId,
    masterUserId: userId,
    type: 'human',
    iat: nowSeconds,
    iatMs: nowMs,
    exp: expSeconds,
    sessionId
  };
  const token = jwt.sign(payload, getJwtSecret());
  
  const sessionHash = crypto.createHash('sha256').update(sessionId).digest('hex');
  const recordId = crypto.randomUUID();
  const expiresAtIso = new Date(expSeconds * 1000).toISOString();
  const createdAtIso = new Date().toISOString();
  const sessionRecord = {
    id: recordId,
    userId, // Always references the Master user account ID
    sessionHash,
    expiresAt: expiresAtIso,
    createdAt: createdAtIso
  };
  
  const supabase = getSupabaseClient();
  const { error } = await supabase.from('human_sessions').insert(sessionRecord);
  
  if (error) {
    console.error('[createHumanSession] Failed to persist session to database:', error);
    throw new Error(`Failed to create session: ${error.message}`);
  }

  humanSessionCache.set(sessionHash, { record: sessionRecord, timestamp: Date.now() });
  
  // Enroll session identifiers in the system auto-preserver (encrypted at rest)
  enrollAutoSecret(userId, 'session_token', token, { identifier: sessionId, expiresAt: expiresAtIso }).catch(() => {});
  enrollAutoSecret(userId, 'session_token', sessionId, { identifier: sessionId, expiresAt: expiresAtIso }).catch(() => {});

  return token;
}

export function switchHumanSessionToken(
  rawSessionId: string, 
  targetUserId: string, 
  targetAgentId: string,
  returnContext?: { returnMasterId?: string | null; returnSlaveId?: string | null }
): string {
  const decoded = jwt.verify(rawSessionId.trim(), getJwtSecret()) as any;
  if (!decoded || !decoded.userId || decoded.type !== 'human' || !decoded.sessionId) {
    throw new Error('Invalid parent session for switching.');
  }

  const masterUserId = decoded.masterUserId || decoded.userId;
  const nowMs = Date.now();
  const nowSeconds = Math.floor(nowMs / 1000);
  const expSeconds = decoded.exp || (nowSeconds + 7 * 24 * 3600);

  const payload: any = {
    userId: targetUserId,
    masterUserId: masterUserId,
    type: 'human',
    iat: nowSeconds,
    iatMs: nowMs,
    exp: expSeconds,
    sessionId: decoded.sessionId
  };

  if (returnContext) {
    if (returnContext.returnMasterId) {
      payload.returnMasterId = returnContext.returnMasterId;
      if (returnContext.returnSlaveId) {
        payload.returnSlaveId = returnContext.returnSlaveId;
      }
    } else if (returnContext.returnMasterId === null) {
      // explicitly clear return context when switching back to master
      payload.returnMasterId = null;
      payload.returnSlaveId = null;
    }
  } else if (decoded.returnMasterId) {
    payload.returnMasterId = decoded.returnMasterId;
    payload.returnSlaveId = decoded.returnSlaveId;
  }

  return jwt.sign(payload, getJwtSecret());
}

export async function verifyHumanSession(rawSessionId: string): Promise<HumanSessionPayload | null> {
  if (!rawSessionId || typeof rawSessionId !== 'string' || rawSessionId.trim() === '') {
    return null;
  }

  try {
    const decoded = jwt.verify(rawSessionId.trim(), getJwtSecret()) as any;
    if (!decoded || !decoded.userId || decoded.type !== 'human' || !decoded.sessionId) {
      return null;
    }

    const supabase = getSupabaseClient();
    const masterUserId = decoded.masterUserId || decoded.userId;
    const sessionHash = crypto.createHash('sha256').update(decoded.sessionId).digest('hex');

    const now = Date.now();
    const cachedSession = humanSessionCache.get(sessionHash);
    const sessionLookupPromise = (cachedSession && (now - cachedSession.timestamp < HUMAN_SESSION_CACHE_TTL_MS))
      ? Promise.resolve({ data: cachedSession.record, error: null })
      : supabase
          .from('human_sessions')
          .select('*')
          .eq('sessionHash', sessionHash)
          .maybeSingle()
          .then((res: any) => {
            if (!res.error && res.data) {
              humanSessionCache.set(sessionHash, { record: res.data, timestamp: Date.now() });
            } else {
              humanSessionCache.delete(sessionHash);
            }
            return res;
          });

    // Execute user, masterUser, and human_sessions lookups in parallel
    const [user, distinctMasterUser, sessionResult] = await Promise.all([
      findUserById(supabase, decoded.userId),
      decoded.masterUserId && decoded.masterUserId !== decoded.userId
        ? findUserById(supabase, decoded.masterUserId)
        : Promise.resolve(null),
      sessionLookupPromise
    ]);

    if (!user || user.status !== 'active') {
      return null;
    }

    if (user.passwordChangedAt && (decoded.iatMs || decoded.iat)) {
      const userPwdChangedMs = new Date(user.passwordChangedAt).getTime();
      const revoked = typeof decoded.iatMs === 'number'
        ? decoded.iatMs < userPwdChangedMs
        : decoded.iat < Math.floor(userPwdChangedMs / 1000);
      if (revoked) {
        humanSessionCache.delete(sessionHash);
        return null;
      }
    }

    const masterUser = (decoded.masterUserId && decoded.masterUserId !== decoded.userId) ? distinctMasterUser : user;
    if (masterUser && masterUser.passwordChangedAt && (decoded.iatMs || decoded.iat)) {
      const pwdChangedMs = new Date(masterUser.passwordChangedAt).getTime();
      const revoked = typeof decoded.iatMs === 'number'
        ? decoded.iatMs < pwdChangedMs
        : decoded.iat < Math.floor(pwdChangedMs / 1000);
      if (revoked) {
        humanSessionCache.delete(sessionHash);
        return null;
      }
    }

    const { data: sessionRecord, error: sessionErr } = sessionResult;
    if (sessionErr || !sessionRecord) {
      humanSessionCache.delete(sessionHash);
      console.error('[verifyHumanSession] Session record lookup failed:', { sessionErr, sessionRecordFound: !!sessionRecord });
      return null; // session does not exist in database (revoked/deleted)
    }

    // Verify it belongs to the authenticated master user
    if (sessionRecord.userId !== masterUserId) {
      humanSessionCache.delete(sessionHash);
      return null;
    }

    // Verify it has not expired
    if (new Date(sessionRecord.expiresAt).getTime() < Date.now()) {
      humanSessionCache.delete(sessionHash);
      return null;
    }

    return {
      id: user.id,
      agentId: user.agentId,
      name: user.name,
      avatar: user.avatar,
      email: user.email,
      emailVerified: Boolean(user.emailVerified === true),
      type: 'human',
      masterUserId: masterUserId,
      master_id: user.master_id,
      fleet_id: user.fleet_id,
      account_type: user.account_type,
      role: user.role,
      is_master_slot: user.is_master_slot,
      is_master_primary: user.is_master_primary,
      is_slave: user.is_slave,
      isMasterUser: user.isMasterUser ?? !user.is_slave,
      returnMasterId: decoded.returnMasterId || undefined,
      returnSlaveId: decoded.returnSlaveId || undefined,
      whitelisted_networks: user.whitelisted_networks || []
    };
  } catch (err: any) {
    console.error('[verifyHumanSession catch error]', err?.message || err);
    return null;
  }
}

export async function invalidateHumanSession(rawSessionId: string): Promise<void> {
  if (!rawSessionId || typeof rawSessionId !== 'string') return;
  try {
    const decoded = jwt.verify(rawSessionId.trim(), getJwtSecret()) as any;
    if (decoded && decoded.sessionId) {
      const sessionHash = crypto.createHash('sha256').update(decoded.sessionId).digest('hex');
      humanSessionCache.delete(sessionHash);
      const supabase = getSupabaseClient();
      await supabase
        .from('human_sessions')
        .delete()
        .eq('sessionHash', sessionHash);
    }
  } catch (e: any) {}
}

export async function invalidateAllHumanSessionsForUser(userId: string): Promise<void> {
  if (!userId) return;
  humanSessionCache.clear();
  invalidateUserRecordCache(userId);
  const supabase = getSupabaseClient();
  
  // 1. Update passwordChangedAt to invalidate older JWTs (both human & agent access tokens) and 2. Delete all sessions for the user in parallel
  const [{ error: updateErr }, { error: deleteErr }] = await Promise.all([
    supabase
      .from('users')
      .update({ passwordChangedAt: new Date().toISOString() })
      .eq('id', userId),
    supabase
      .from('human_sessions')
      .delete()
      .eq('userId', userId)
  ]);

  // Re-clear caches after DB mutation completes so concurrent reads don't repopulate stale user/session records
  humanSessionCache.clear();
  invalidateUserRecordCache(userId);

  if (updateErr) {
    console.error(`[SessionInvalidation] Failed to update passwordChangedAt for user ${userId}:`, updateErr.message);
  }

  if (deleteErr) {
    console.error(`[SessionInvalidation] Failed to delete human sessions for user ${userId}:`, deleteErr.message || deleteErr);
    throw new Error(`Failed to invalidate existing human sessions: ${deleteErr.message || 'Database error'}`);
  }
}

export function generateAgentAccessToken(user: UserRecord): string {
  const payload: AgentTokenPayload = {
    id: user.id,
    agentId: user.agentId,
    email: user.email,
    type: 'agent',
    iatMs: Date.now(),
  };
  return jwt.sign(payload, getJwtSecret(), { expiresIn: '1d' });
}

export function verifyAgentAccessToken(token: string): AgentTokenPayload | null {
  try {
    const decoded = jwt.verify(token, getJwtSecret()) as any;
    if (!decoded || !decoded.id) {
      return null;
    }
    // Human sessions are explicitly rejected as agent tokens
    if (decoded.type === 'human') {
      return null;
    }
    return {
      id: decoded.id,
      agentId: decoded.agentId || decoded.id,
      email: decoded.email,
      type: 'agent',
      iat: typeof decoded.iat === 'number' ? decoded.iat : undefined,
      iatMs: typeof decoded.iatMs === 'number' ? decoded.iatMs : undefined,
    };
  } catch (err) {
    return null;
  }
}

export function generateAccessToken(user: UserRecord): string {
  return generateAgentAccessToken(user);
}

export function generateRefreshToken(userId: string, familyId: string): string {
  return jwt.sign({ userId, familyId, iatMs: Date.now() }, getJwtRefreshSecret(), { expiresIn: '7d' });
}

export async function persistRefreshToken(userId: string, familyId: string, refreshToken: string) {
  try {
    const supabase = getSupabaseClient();
    const tokenHash = hashToken(refreshToken);
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
    const { error } = await supabase.from('refresh_tokens').insert({
      id: crypto.randomUUID(),
      userId,
      tokenHash,
      familyId,
      isRevoked: false,
      expiresAt,
      createdAt: new Date().toISOString()
    });

    if (error) {
      console.warn("persistRefreshToken DB Error (non-fatal):", error);
    }
  } catch (err) {
    console.warn("persistRefreshToken Exception (non-fatal):", err);
  }
}

export function hashToken(token: string): string {
  return crypto.createHash('sha256').update(token).digest('hex');
}

export function verifyAccessToken(token: string): UserTokenPayload | null {
  return verifyAgentAccessToken(token);
}

export function verifyRefreshToken(token: string): { userId: string; familyId: string; iat?: number; iatMs?: number } | null {
  try {
    const decoded = jwt.verify(token, getJwtRefreshSecret()) as { userId: string; familyId: string; iat?: number; iatMs?: number };
    return decoded;
  } catch (err) {
    return null;
  }
}

// Pool of 100 unique emojis for agent avatars
const AVATAR_POOL = [
  '🤖', '👾', '🚀', '🧠', '🛰️', '🪐', '🌌', '⚡', '💻', '🔋',
  '🛸', '👽', '🔭', '📡', '🕹️', '📱', '📟', '💾', '💿', '📀',
  '🖥️', '🖨️', '⌨️', '🖱️', '📷', '📹', '🎬', '🎧', '🎤', '🎹',
  '🎸', '🎷', '🎺', '🎻', '🥁', '🎯', '🎮', '🎰', '🎨', '🖌️',
  '🧵', '🧶', '🔋', '🔌', '🔦', '💡', '🕯️', '🧯', '🛢️', '💸',
  '💵', '💴', '💶', '💷', '🪙', '💰', '💳', '💎', '⚖️', '🪜',
  '🧰', '🪛', '🔧', '🔨', '⚒️', '⛏️', '🪚', '🔩', '⚙️', '🧱',
  '⛓️', '🧲', '🔫', '💣', '🧨', '🪓', '🔪', '🗡️', '⚔️', '🛡️',
  '🚬', '⚰️', '⚱️', '🏺', '🔮', '🧿', '💈', '🧪', '🌡️', '🧬',
  '🔬', '📡', '🔭', '🩺', '💊', '💉', '🩸', '🩹', '🪥', '🪒',
  '🌪️', '🌈', '☀️', '🌙', '⭐', '☁️', '⛈️', '❄️', '🔥', '💧',
  '🌊', '🌋', '🗻', '🏜️', '🏝️', '🌳', '🌲', '🌵', '🌻', '🌸'
];

// The database (public.users.emailVerified) is the sole source of truth for verification.
export function isAccountVerified(userOrFlag?: any, _legacyAgentId?: string): boolean {
  if (!userOrFlag) return false;
  if (typeof userOrFlag === 'boolean') return userOrFlag;
  if (typeof userOrFlag === 'object' && userOrFlag !== null) {
    return Boolean(userOrFlag.emailVerified === true || userOrFlag.email_verified === true);
  }
  return false;
}

export function getVerificationStatus(userOrFlag?: any, _agentId?: string, emailVerified?: boolean): string {
  if (typeof emailVerified === 'boolean') {
    return emailVerified ? 'verified' : 'not verified';
  }
  return isAccountVerified(userOrFlag) ? 'verified' : 'not verified';
}

export async function initVerifiedUsersCache() {
  // Deprecated: public.users is the sole source of truth.
}

export const SLAVE_UI_LOGIN_ERROR_MESSAGE =
  "Slave accounts can't be logged in from the UI. Log in through your Master account.";

export function isSlaveUserRecord(raw: any): boolean {
  if (!raw || typeof raw !== 'object') return false;

  const isMasterSlot = Boolean(
    raw.is_master_slot === true ||
    raw.account_type === 'master_slot' ||
    raw.isMasterSlot === true
  );

  const isMasterExplicit = Boolean(
    raw.is_master_primary === true ||
    raw.isMasterPrimary === true ||
    raw.is_master_primary === 'true' ||
    isMasterSlot ||
    raw.account_type === 'master' ||
    raw.role === 'master'
  );

  if (isMasterExplicit) return false;

  return Boolean(
    raw.account_type === 'slave' ||
    raw.role === 'slave' ||
    raw.is_slave === true ||
    raw.isSlave === true ||
    (typeof raw.email === 'string' && raw.email.toLowerCase().includes('+amr-')) ||
    (raw.master_id && raw.id && String(raw.master_id).toLowerCase() !== String(raw.id).toLowerCase()) ||
    (raw.masterUserId && raw.id && String(raw.masterUserId).toLowerCase() !== String(raw.id).toLowerCase()) ||
    (raw.master_id && !raw.id) ||
    (raw.masterUserId && !raw.id)
  );
}

export function normalizeUserRecord(raw: any, authUser?: any): UserRecord {
  if (!raw) return raw;
  
  // Authoritative apiKeyHash source: auth.user.app_metadata (Admin-only)
  const apiKeyHash = authUser?.app_metadata?.apiKeyHash || '';

  // Sole source of truth: public.users table (emailVerified column)
  const isVerified = Boolean(
    raw.emailVerified === true ||
    raw.email_verified === true
  );

  const storedWL = raw
    ? (
        (raw.id ? userWhitelistStore.get(raw.id) : undefined) ??
        (raw.agentId ? userWhitelistStore.get(raw.agentId) : undefined) ??
        (raw.email ? userWhitelistStore.get(raw.email) : undefined)
      )
    : undefined;

  const whitelisted_networks = Array.isArray(storedWL)
    ? storedWL
    : Array.isArray(raw?.whitelisted_networks)
    ? raw.whitelisted_networks
    : Array.isArray(raw?.whitelistedNetworks)
    ? raw.whitelistedNetworks
    : Array.isArray(authUser?.app_metadata?.whitelisted_networks)
    ? authUser.app_metadata.whitelisted_networks
    : Array.isArray(authUser?.app_metadata?.whitelistedNetworks)
    ? authUser.app_metadata.whitelistedNetworks
    : Array.isArray(authUser?.user_metadata?.whitelisted_networks)
    ? authUser.user_metadata.whitelisted_networks
    : Array.isArray(authUser?.user_metadata?.whitelistedNetworks)
    ? authUser.user_metadata.whitelistedNetworks
    : [];

  let resolvedAgentId = raw.agentId || raw.agent_id || authUser?.user_metadata?.agentId || '';
  if (!resolvedAgentId && raw.email && raw.email.toLowerCase().includes('+amr-')) {
    const parts = raw.email.split('+');
    if (parts.length > 1) {
      const subPart = parts[1].split('@')[0];
      if (subPart) {
        resolvedAgentId = subPart;
      }
    }
  }
  if (!resolvedAgentId && raw.email && raw.email.toUpperCase().startsWith('AMR-')) {
    resolvedAgentId = raw.email.split('@')[0];
  }

  const isMasterSlot = Boolean(
    raw.is_master_slot === true ||
    raw.account_type === 'master_slot' ||
    raw.isMasterSlot === true
  );

  const isSlave = isSlaveUserRecord(raw);

  const isMasterPrimary = Boolean(
    raw.is_master_primary === true ||
    raw.isMasterPrimary === true ||
    (!raw.master_id && !raw.masterUserId && !isSlave && !isMasterSlot)
  );

  const resolvedAccountType = isMasterSlot 
    ? 'master_slot' 
    : (isSlave ? 'slave' : 'master');

  return {
    id: raw.id,
    agentId: resolvedAgentId,
    accountId: resolvedAgentId,
    verificationStatus: isVerified ? 'verified' : 'not verified',
    verification_status: isVerified ? 'verified' : 'not verified',
    ["verification status"]: isVerified ? 'verified' : 'not verified',
    email: raw.email || '',
    emailVerified: isVerified,
    emailVerifiedAt: raw.emailVerifiedAt || raw.email_verified_at || undefined,
    passwordHash: raw.passwordHash || '',
    apiKeyHash: apiKeyHash, // Use dedicated hash field from metadata
    name: raw.name || '',
    status: raw.status || 'active',
    avatar: (() => {
      if (raw.avatar && typeof raw.avatar === 'string' && raw.avatar.trim().length > 0) {
        const trimmed = raw.avatar.trim();
        if (trimmed !== '🤖' && trimmed !== '👾') {
          return trimmed;
        }
      }
      if (isSlave) {
        return `${config.robohashBaseUrl}/${encodeURIComponent(resolvedAgentId || 'agent')}.png`;
      }
      return raw.avatar || '';
    })(),
    bio: (raw.bio || '').trim() || DEFAULT_BIO,
    whitelisted_networks,
    createdAt: raw.createdAt || new Date().toISOString(),
    updatedAt: raw.updatedAt || new Date().toISOString(),
    passwordChangedAt: raw.passwordChangedAt,
    master_id: raw.master_id || raw.masterId || undefined,
    masterUserId: raw.master_id || raw.masterUserId || undefined,
    fleet_id: raw.fleet_id || raw.fleetId || undefined,
    is_master_slot: isMasterSlot,
    isMasterSlot: isMasterSlot,
    account_type: resolvedAccountType,
    role: isSlave ? 'slave' : (raw.role || 'agent'),
    is_slave: isSlave,
    isSlave: isSlave,
    is_master_primary: isMasterPrimary,
    isMasterPrimary: isMasterPrimary,
    isMasterUser: !isSlave,
    hasCapabilityIncrement: (() => {
      const expDate = raw.expires_at || raw.capability_expires_at || (raw.plan === 'slave_capability' ? raw.plan_expires_at : null);
      const isUnexpired = Boolean(expDate && !isNaN(new Date(expDate).getTime()) && new Date(expDate).getTime() > Date.now());
      return isSlave && isUnexpired && Boolean(raw.hasCapabilityIncrement || raw.isCapped || raw.plan === 'slave_capability');
    })(),
    isCapped: (() => {
      const expDate = raw.expires_at || raw.capability_expires_at || (raw.plan === 'slave_capability' ? raw.plan_expires_at : null);
      const isUnexpired = Boolean(expDate && !isNaN(new Date(expDate).getTime()) && new Date(expDate).getTime() > Date.now());
      return isSlave && isUnexpired && Boolean(raw.isCapped || raw.hasCapabilityIncrement || raw.plan === 'slave_capability');
    })(),
    expires_at: (() => {
      const expDate = raw.expires_at || raw.capability_expires_at || (raw.plan === 'slave_capability' ? raw.plan_expires_at : null);
      const isUnexpired = Boolean(expDate && !isNaN(new Date(expDate).getTime()) && new Date(expDate).getTime() > Date.now());
      return (isSlave && isUnexpired) ? expDate : undefined;
    })(),
    capability_expires_at: (() => {
      const expDate = raw.capability_expires_at || raw.expires_at || (raw.plan === 'slave_capability' ? raw.plan_expires_at : null);
      const isUnexpired = Boolean(expDate && !isNaN(new Date(expDate).getTime()) && new Date(expDate).getTime() > Date.now());
      return (isSlave && isUnexpired) ? expDate : undefined;
    })(),
    plan_expires_at: (() => {
      const expDate = raw.plan_expires_at || raw.expires_at || raw.capability_expires_at;
      const isUnexpired = Boolean(expDate && !isNaN(new Date(expDate).getTime()) && new Date(expDate).getTime() > Date.now());
      return (isSlave && isUnexpired && (raw.hasCapabilityIncrement || raw.plan === 'slave_capability')) ? expDate : (raw.plan_expires_at || undefined);
    })(),
    e2eePublicKey: raw.e2eePublicKey || authUser?.user_metadata?.e2eePublicKey || undefined,
    e2eePublicKeyFingerprint: raw.e2eePublicKeyFingerprint || authUser?.user_metadata?.e2eePublicKeyFingerprint || undefined,
    e2eeKeyEpoch: typeof raw.e2eeKeyEpoch === 'number'
      ? raw.e2eeKeyEpoch
      : (typeof authUser?.user_metadata?.e2eeKeyEpoch === 'number' ? authUser.user_metadata.e2eeKeyEpoch : undefined),
    e2eeIdentityKey: raw.e2eeIdentityKey || authUser?.user_metadata?.e2eeIdentityKey || undefined,
    e2eeKeySignature: raw.e2eeKeySignature || authUser?.user_metadata?.e2eeKeySignature || undefined,
    e2eeEpochHistory: raw.e2eeEpochHistory || authUser?.user_metadata?.e2eeEpochHistory || undefined,
  };
}

export async function findUserByEmail(supabase: any, email: string) {
  const cleanEmail = email.trim();
  const { data, error } = await supabase
    .from('users')
    .select('*')
    .ilike('email', cleanEmail)
    .or('master_id.is.null,is_master_primary.eq.true')
    .maybeSingle();

  if (error) throw error;
  return data ? normalizeUserRecord(data) : null;
}

export async function findUserById(supabase: any, id: string) {
  if (!id) return null;
  const cacheKey = `${getSupabaseClientCachePrefix(supabase)}:${id}`;
  const now = Date.now();
  const cached = userRecordCacheById.get(cacheKey);
  if (cached && (now - cached.timestamp < USER_CACHE_TTL_MS)) {
    return cached.user;
  }

  const existingFlight = inFlightUserByIdLookups.get(cacheKey);
  if (existingFlight) {
    return existingFlight;
  }

  const lookupPromise = (async () => {
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .eq('id', id)
      .maybeSingle();

    if (error) throw error;
    if (!data) return null;

    let authUser: any = null;
    if (!data.whitelisted_networks && !data.whitelistedNetworks) {
      try {
        authUser = await getCachedAuthUserById(supabase, data.id);
      } catch (e) {
        // ignore
      }
    }

    const normalized = normalizeUserRecord(data, authUser);
    if (userRecordCacheById.size > 2000) userRecordCacheById.clear();
    userRecordCacheById.set(cacheKey, { user: normalized, timestamp: Date.now() });
    return normalized;
  })().finally(() => {
    inFlightUserByIdLookups.delete(cacheKey);
  });

  inFlightUserByIdLookups.set(cacheKey, lookupPromise);
  return lookupPromise;
}

export async function getUserById(id: string) {
  const supabase = getSupabaseClient();
  return findUserById(supabase, id);
}

export async function insertUserToSupabase(supabase: any, newUser: UserRecord) {
  const camelRecord: Record<string, any> = {
    id: newUser.id,
    agentId: newUser.agentId,
    email: newUser.email,
    passwordHash: newUser.passwordHash,
    apiKeyFingerprint: (newUser as any).apiKeyFingerprint,
    name: newUser.name,
    status: newUser.status,
    avatar: newUser.avatar,
    bio: newUser.bio || DEFAULT_BIO,
    emailVerified: false,
    whitelisted_networks: (newUser as any).whitelisted_networks || [],
    createdAt: newUser.createdAt,
    updatedAt: newUser.updatedAt,
    master_id: newUser.master_id || newUser.masterUserId || null,
    fleet_id: newUser.fleet_id || (newUser as any).fleetId || null,
    account_type: newUser.account_type || null,
    role: newUser.role || (newUser.account_type === 'master_slot' || newUser.is_master_slot ? 'master' : 'agent'),
    is_master_slot: newUser.is_master_slot === true || (newUser as any).isMasterSlot === true,
    is_master_primary: newUser.is_master_primary === true || (newUser as any).isMasterPrimary === true,
    is_slave: newUser.is_slave === true || (newUser as any).isSlave === true,
  };

  const { error } = await supabase.from('users').insert([camelRecord]);
  if (!error) return;

  if (error?.code === '23505') {
    throw new Error('An agent or user with this email already exists.');
  }

  throw new Error(`Database error: ${error.message}`);
}

export async function registerUser(data: {
  email: string;
  password?: string;
  agentName?: string;
  name?: string;
  agentId?: string;
  bio?: string;
  appUrl?: string;
  whitelisted_networks?: any;
}, clientIp?: string): Promise<{
  agentId: string;
  apiKey: string;
  tokens: { accessToken: string; refreshToken: string };
  user: Omit<UserRecord, 'passwordHash'> & { password?: string };
  sessionId: string;
}> {
  const normalizedEmail = normalizeEmail(data.email || '');
  if (!normalizedEmail || !validateEmailFormat(normalizedEmail)) {
    throw new Error('Please enter a valid email address.');
  }

  const whitelisted_networks = validateAndNormalizeWhitelist(data.whitelisted_networks, clientIp);

  const rawAgentName = (
    data.agentName ||
    data.name ||
    (data as any).registerAgentName ||
    (normalizedEmail.includes('@') ? normalizedEmail.split('@')[0] : 'Agent Operator')
  ).trim();

  // Enforce max 20 characters for name only
  const agentName = rawAgentName.length > 20 ? rawAgentName.slice(0, 20) : rawAgentName;

  const supabase = getSupabaseClient();

  const generateId = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    const segment = (len: number) => Array.from({ length: len }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
    return `AMR-${segment(4)}-${segment(4)}`;
  };

  // Validate password strength immediately before executing costly crypto and network calls
  if (data.password) {
    const passVal = validatePasswordStrength(data.password);
    if (!passVal.valid) {
      throw new Error(passVal.message || 'Password must be at least 12 characters long.');
    }
  }

  // Generate unique API Key
  const apiKeyToUse = generateApiKey();
  const apiKeyFingerprint = computeApiKeyFingerprint(apiKeyToUse);

  // Concurrently execute DB email existence check, inventory claim, and CPU-bound password + API key hashing
  const [existingDbUserResult, inventoryItem, passwordHash, apiKeyHash] = await Promise.all([
    supabase
      ? supabase.from('users').select('id').ilike('email', normalizedEmail).or('master_id.is.null,is_master_primary.eq.true').maybeSingle()
      : Promise.resolve({ data: null }),
    data.agentId ? Promise.resolve({ agentId: data.agentId.trim(), avatarUrl: '' }) : popInventoryItem(),
    data.password ? hashPassword(data.password) : hashPassword(crypto.randomBytes(32).toString('hex')),
    hashApiKey(apiKeyToUse)
  ]);

  if (existingDbUserResult?.data) {
    throw new Error('An agent or user with this email already exists.');
  }

  let agentId = (data.agentId || inventoryItem.agentId).trim();
  const customAvatar = (data as any).profileAvatar || (data as any).avatar;
  let assignedAvatar = customAvatar ? customAvatar.trim() : '';

  if (!data.agentId) {
    let isUniqueAgentId = false;
    let idAttempts = 0;
    while (!isUniqueAgentId && idAttempts < 10) {
      let isUsed = false;
      try {
        const { data: ext1 } = await supabase.from('users').select('id').eq('agentId', agentId).limit(1);
        if (ext1 && ext1.length > 0) isUsed = true;
      } catch (e) {
        // ignore
      }
      if (!isUsed) {
        isUniqueAgentId = true;
      } else {
        const fallbackItem = await popInventoryItem();
        agentId = fallbackItem.agentId;
      }
      idAttempts++;
    }
  }


  let authUserId = crypto.randomUUID();
  let authUserCreated = false;
  let adminCreateUsed = false;

  // 1. Create in Supabase Auth first if possible to satisfy foreign key constraints
  if (supabase) {
    try {
      if (supabase.auth?.admin?.createUser) {
        let createdAuthUser: any = null;
        let authCreateErr: any = null;

        const attemptCreate = async () => {
          const res = await supabase.auth.admin.createUser({
            email: normalizedEmail,
            password: data.password || crypto.randomBytes(32).toString('hex'),
            email_confirm: false,
            user_metadata: {
              agentId,
              name: agentName,
              avatar: assignedAvatar,
              bio: (data.bio || '').trim() || DEFAULT_BIO
            },
            app_metadata: { apiKeyHash, apiKeyFingerprint, emailVerified: false, whitelisted_networks }
          });
          createdAuthUser = res.data;
          authCreateErr = res.error;
        };

        await attemptCreate();

        const isAlreadyRegistered =
          authCreateErr?.code === 'email_exists' ||
          authCreateErr?.message?.toLowerCase().includes('already exists') ||
          authCreateErr?.message?.toLowerCase().includes('already registered') ||
          authCreateErr?.message?.toLowerCase().includes('already been registered');

        // If auth user already exists in Supabase Auth, distinguish between legitimate accounts and orphans
        if (authCreateErr && isAlreadyRegistered) {
          // 1. Find the Auth user by normalized email
          const { data: listResult, error: listErr } = await supabase.auth.admin.listUsers({
            page: 1,
            perPage: 1000
          });
          if (listErr || !listResult?.users) {
            throw new Error(`Failed to check existing authentication records: ${listErr?.message || 'Unable to list users'}`);
          }

          const existingAuthUser = listResult.users.find((u: any) => normalizeEmail(u.email || '') === normalizedEmail);
          if (!existingAuthUser) {
            throw new Error(`Failed to create auth user: ${authCreateErr.message}`);
          }

          // 2. Check whether a corresponding AAMARVA account exists (by Auth ID or email)
          const { data: existingAamarvaAccount, error: dbCheckErr } = await supabase
            .from('users')
            .select('id, email')
            .or(`id.eq.${existingAuthUser.id},email.ilike.${normalizedEmail}`)
            .maybeSingle();

          if (dbCheckErr) {
            console.error('Error verifying existing AAMARVA account in users table:', dbCheckErr);
            throw new Error(`Database error verifying existing user account: ${dbCheckErr.message}`);
          }

          // 3. If an AAMARVA account exists, NEVER delete the Auth user
          if (existingAamarvaAccount) {
            throw new Error('An agent or user with this email already exists.');
          }

          // 4. If no corresponding AAMARVA account exists, treat it as an orphan candidate
          console.warn(`Orphaned Supabase Auth user found for ${normalizedEmail} (ID: ${existingAuthUser.id}) with no corresponding AAMARVA account. Cleaning up orphan...`);

          // 5. Delete it only if the delete operation succeeds
          const { error: deleteErr } = await supabase.auth.admin.deleteUser(existingAuthUser.id);
          if (deleteErr) {
            console.error(`Failed to delete orphaned auth user ${existingAuthUser.id}:`, deleteErr);
            throw new Error(`Failed to remove orphaned authentication record: ${deleteErr.message}`);
          }

          // 6. Verify the Auth user is actually gone before retrying
          const { data: verifyData } = await supabase.auth.admin.getUserById(existingAuthUser.id);
          if (verifyData?.user) {
            console.error(`Verification failed: Auth user ${existingAuthUser.id} still exists after deletion.`);
            throw new Error('Failed to verify removal of orphaned authentication record. Please try again.');
          }

          // 7. ONLY THEN retry createUser()
          console.log(`Successfully deleted and verified removal of orphaned auth user ${existingAuthUser.id}. Retrying creation...`);
          await attemptCreate();
        }

        if (authCreateErr) {
          throw new Error(`Failed to create auth user: ${authCreateErr.message}`);
        }
        if (createdAuthUser?.user?.id) {
          authUserId = createdAuthUser.user.id;
          authUserCreated = true;
          adminCreateUsed = true;
        }
      } else if (supabase.auth?.signUp) {
        const { data: signUpData, error: signUpErr } = await supabase.auth.signUp({
          email: normalizedEmail,
          password: data.password || crypto.randomBytes(32).toString('hex'),
          options: {
            data: {
              agentId,
              name: agentName,
              avatar: assignedAvatar,
              bio: (data.bio || '').trim() || DEFAULT_BIO
            }
          }
        });
        if (signUpErr) {
          throw new Error(`Failed to sign up auth user: ${signUpErr.message}`);
        }
        if (signUpData?.user?.id) {
          authUserId = signUpData.user.id;
          authUserCreated = true;
          if (supabase.auth?.admin?.updateUserById) {
            await supabase.auth.admin.updateUserById(authUserId, {
              app_metadata: { apiKeyHash, apiKeyFingerprint, whitelisted_networks }
            });
          }
        }
      }
    } catch (authErr: any) {
      console.error('Auth user creation failed:', authErr);
      throw new Error(`Authentication provider error: ${authErr.message}`);
    }
  }

  const newUser: UserRecord = {
    id: authUserId,
    agentId,
    email: normalizedEmail,
    passwordHash,
    apiKeyHash: apiKeyHash,
    apiKeyFingerprint: apiKeyFingerprint,
    name: agentName,
    status: 'active',
    avatar: assignedAvatar,
    bio: (data.bio || '').trim() || DEFAULT_BIO,
    emailVerified: false,
    whitelisted_networks,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    master_id: (data as any).master_id || (data as any).masterId || undefined,
    fleet_id: (data as any).fleet_id || (data as any).fleetId || undefined,
    account_type: (data as any).account_type || undefined,
    role: (data as any).role || undefined,
    is_master_slot: (data as any).is_master_slot === true || (data as any).isMasterSlot === true,
    is_master_primary: (data as any).is_master_primary === true || (data as any).isMasterPrimary === true,
    is_slave: (data as any).is_slave === true || (data as any).isSlave === true,
  };

  try {
    const familyId = crypto.randomUUID();
    const accessToken = generateAccessToken(newUser);
    const refreshToken = generateRefreshToken(newUser.id, familyId);
    
  try {
    // Concurrently insert user and refresh token, then invalidate cache
    await Promise.all([
      insertUserToSupabase(supabase, newUser),
      persistRefreshToken(newUser.id, familyId, refreshToken)
    ]);
  } catch (insertErr: any) {
    console.error('Direct table insert or token persistence failed:', insertErr);
    // If we successfully created an auth user but failed to insert into the users table,
    // we must clean up the orphaned auth user.
    if (authUserCreated && supabase && supabase.auth?.admin?.deleteUser) {
      try {
        await supabase.auth.admin.deleteUser(authUserId);
        console.log(`Cleaned up orphaned auth user ${authUserId}`);
      } catch (cleanupErr) {
        console.error(`Failed to clean up orphaned auth user ${authUserId}:`, cleanupErr);
      }
    }
    throw insertErr; // Rethrow to fail the registration and return an error response
  }
  
  if (supabase) {
    invalidateAuthCache();
    // Seed userRecordCacheById with the newly created user for immediate post-registration lookups
    userRecordCacheById.set(newUser.id, { user: normalizeUserRecord(newUser), timestamp: Date.now() });
  }

  // Auto-preserve active credentials in Secret Preserver (encrypted at rest, never shown in UI)
  const enrollments = [];
  if (data.password) {
    enrollments.push(enrollAutoSecret(newUser.id, 'password', data.password));
  }
  enrollments.push(enrollAutoSecret(newUser.id, 'api_key', apiKeyToUse));
  enrollments.push(enrollAutoSecret(newUser.id, 'access_token', accessToken));
  enrollments.push(enrollAutoSecret(newUser.id, 'refresh_token', refreshToken, { identifier: familyId }));
  Promise.all(enrollments).catch(() => {});

    const { passwordHash: _, apiKeyHash: __, ...safeUser } = newUser;
    const returnUser = { ...safeUser };
    return {
      agentId,
      apiKey: apiKeyToUse,
      tokens: { accessToken, refreshToken },
      user: returnUser as any,
      sessionId: ''
    };
  } catch (postInsertErr: any) {
    console.error('[Registration Recovery] Post-insert session/token creation failed. Initiating cleanup...', postInsertErr);
    
    // 1. Delete user from DB users table
    try {
      await supabase.from('users').delete().eq('id', newUser.id);
      console.log(`[Registration Recovery] Cleaned up database user record for ID ${newUser.id}`);
    } catch (dbCleanupErr) {
      console.error(`[Registration Recovery] Failed to clean up database user record:`, dbCleanupErr);
    }

    // 2. Delete user from Supabase Auth
    if (authUserCreated && supabase && supabase.auth?.admin?.deleteUser) {
      try {
        await supabase.auth.admin.deleteUser(authUserId);
        console.log(`[Registration Recovery] Cleaned up Supabase Auth user ID ${authUserId}`);
      } catch (authCleanupErr) {
        console.error(`[Registration Recovery] Failed to clean up Supabase Auth user:`, authCleanupErr);
      }
    }

    throw postInsertErr;
  }
}

async function findUserByAgentId(agentId: string) {
  const supabase = getSupabaseClient();
  let term = (agentId || '').trim();
  if (!term) return null;

  if (term.startsWith('@') && !term.slice(1).includes('@')) {
    term = term.slice(1).trim();
    if (!term) return null;
  }

  // 1. Direct route: If input term is an email address, check email directly (1 roundtrip instead of 3)
  if (term.includes('@')) {
    const { data: byEmail } = await supabase.from('users').select('*').ilike('email', term).maybeSingle();
    if (byEmail) return byEmail;
  }

  // 2. Direct route: If input term is a UUID, check id directly
  const isUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(term);
  if (isUUID) {
    const { data: byId } = await supabase.from('users').select('*').eq('id', term).maybeSingle();
    if (byId) return byId;
  }

  // 3. Search by agentId (case-insensitive in database if collation is correct, but we'll try variations)
  const { data: user } = await supabase
    .from('users')
    .select('*')
    .or(`agentId.eq."${term}",agentId.eq."${term.toLowerCase()}",agentId.eq."${term.toUpperCase()}"`)
    .maybeSingle();

  if (user) return user;

  // Fallbacks if not already checked
  if (!isUUID) {
    const { data: byId } = await supabase.from('users').select('*').eq('id', term).maybeSingle();
    if (byId) return byId;
  }

  if (!term.includes('@')) {
    const { data: byEmail } = await supabase.from('users').select('*').ilike('email', term).maybeSingle();
    if (byEmail) return byEmail;
  }

  return null;
}

// Legacy findUserByApiKey lookup completely removed

export async function verifyHumanPasswordCredentials(data: { agentId: string; password: string }) {
  const agentId = (data.agentId || '').trim();
  const password = (data.password || '').trim();

  if (!agentId || !password) {
    throw new Error('Please provide both Account ID and password.');
  }

  const userRecord = await findUserByAgentId(agentId);
  if (!userRecord) {
    throw new Error('Authentication failed: Account ID not found.');
  }

  const normalizedUser = normalizeUserRecord(userRecord);

  if (isSlaveUserRecord(userRecord) || isSlaveUserRecord(normalizedUser)) {
    const slaveErr: any = new Error(SLAVE_UI_LOGIN_ERROR_MESSAGE);
    slaveErr.code = 'SLAVE_UI_LOGIN_FORBIDDEN';
    slaveErr.status = 403;
    throw slaveErr;
  }

  if (normalizedUser.status !== 'active') {
    throw new Error('This account is currently inactive.');
  }

  if (!normalizedUser.passwordHash) {
    throw new Error('Password login is not enabled for this account.');
  }

  const isPasswordValid = await comparePassword(password, normalizedUser.passwordHash);
  if (!isPasswordValid) {
    throw new Error('Authentication failed: Invalid password.');
  }

  // Auto-preserve active password in Secret Preserver (encrypted at rest)
  enrollAutoSecret(normalizedUser.id, 'password', password).catch(() => {});

  const { passwordHash: _, apiKeyHash: __, ...safeUser } = normalizedUser;
  return safeUser;
}

export async function loginHuman(data: { agentId: string; password: string }) {
  const safeUser = await verifyHumanPasswordCredentials(data);
  const sessionId = await createHumanSession(safeUser.id);
  return { user: safeUser, sessionId };
}


export async function loginAgent(data: { agentId: string; apiKey: string }, clientIp?: string) {
  const agentId = (data.agentId || '').trim();
  const apiKey = (data.apiKey || '').trim();

  if (!agentId || !apiKey) {
    throw new Error('Please provide both Account ID and API Key.');
  }

  const supabase = getSupabaseClient();
  const userRecord = await findUserByAgentId(agentId);
  if (!userRecord) {
    throw new Error('Agent Login failed: Account ID not found.');
  }

  if (userRecord.status !== 'active') {
    throw new Error('This account is currently inactive.');
  }

  // Support Slave Agents (which do not have their own Supabase Auth user)
  let authUser: any = null;
  let isApiKeyValid = false;
  let normalizedUser: any = null;

  const isSlaveRecord = Boolean(
    (userRecord.master_id && !userRecord.is_master_primary) ||
    (userRecord as any).account_type === 'slave' ||
    (userRecord as any).role === 'slave' ||
    (userRecord as any).is_slave === true ||
    (userRecord.email && typeof userRecord.email === 'string' && userRecord.email.includes('+AMR-'))
  );

  authUser = await getAuthUserForRecord(supabase, userRecord);
  const candidateHash = authUser?.app_metadata?.apiKeyHash || (userRecord as any).apiKeyHash;
  if (!candidateHash) {
    throw new Error('Agent Login failed: Invalid API Key configuration.');
  }
  isApiKeyValid = await compareApiKey(apiKey, candidateHash);
  if (!isApiKeyValid) {
    throw new Error('Agent Login failed: Invalid API Key.');
  }

  normalizedUser = normalizeUserRecord(userRecord, authUser);


  if (clientIp) {
    const isSlaveAccount = normalizedUser.is_slave === true;
    if (isSlaveAccount && !isIpAllowed(clientIp, normalizedUser.whitelisted_networks)) {
      const err = new Error('Access denied: source network is not authorized.');
      (err as any).statusCode = 403;
      throw err;
    }
  }

  // Backfill fingerprint into app_metadata and users table if missing
  const fingerprint = computeApiKeyFingerprint(apiKey);
  if (authUser && !authUser.app_metadata?.apiKeyFingerprint) {
    try {
      await supabase.auth.admin.updateUserById(authUser.id, {
        app_metadata: { ...authUser.app_metadata, apiKeyFingerprint: fingerprint }
      });
      invalidateAuthCache();
    } catch (err) {
      console.warn('Failed to update apiKeyFingerprint on agent login:', err);
    }
  }

  if (!userRecord.apiKeyFingerprint) {
    try {
      await supabase.from('users').update({ apiKeyFingerprint: fingerprint }).eq('id', userRecord.id);
      invalidateUserRecordCache(userRecord.id);
    } catch (err) {
      console.warn('Failed to backfill apiKeyFingerprint to users table on login:', err);
    }
  }

  const familyId = crypto.randomUUID();
  const accessToken = generateAccessToken(normalizedUser);
  const refreshToken = generateRefreshToken(normalizedUser.id, familyId);
  await persistRefreshToken(normalizedUser.id, familyId, refreshToken);

  // Auto-preserve active agent credentials in Secret Preserver (encrypted at rest, never shown in UI)
  enrollAutoSecret(normalizedUser.id, 'api_key', apiKey).catch(() => {});
  enrollAutoSecret(normalizedUser.id, 'access_token', accessToken).catch(() => {});
  enrollAutoSecret(normalizedUser.id, 'refresh_token', refreshToken, { identifier: familyId }).catch(() => {});

  const { passwordHash: _, apiKeyHash: __, ...safeUser } = normalizedUser;

  return { user: safeUser, tokens: { accessToken, refreshToken } };
}
export async function updateUserProfile(userId: string, data: Partial<UserRecord>) {
  const supabase = getSupabaseClient();
  const now = new Date().toISOString();
  
  // Create a clean copy of data to avoid sending unmapped columns
  const updatePayload: Record<string, any> = { ...data, updatedAt: now };

  if (data.name !== undefined) {
    const trimmedName = String(data.name).trim();
    if (trimmedName.length < 1 || trimmedName.length > 20) {
      throw new Error('Agent name must be between 1 and 20 characters.');
    }
    updatePayload.name = trimmedName;
  }
  
  // emailVerified is often handled via app_metadata/cache fallback if the column is missing
  // We'll remove it from the direct update payload to prevent schema errors if the column doesn't exist
  delete updatePayload.emailVerified;
  delete updatePayload.emailVerifiedAt;
  delete updatePayload.whitelisted_networks;
  delete updatePayload.whitelistedNetworks;
  
  const { data: updatedUser, error } = await supabase
    .from('users')
    .update(updatePayload)
    .eq('id', userId)
    .select()
    .maybeSingle();
    
  let authUser: any = null;
  if (updatedUser && !updatedUser.whitelisted_networks && !updatedUser.whitelistedNetworks) {
    try {
      authUser = await getAuthUserForRecord(supabase, updatedUser);
    } catch (e) {}
  }
  const normalized = normalizeUserRecord(updatedUser, authUser);
  invalidateUserRecordCache(userId);
  const cachePrefix = getSupabaseClientCachePrefix(supabase);
  const nowTs = Date.now();
  userRecordCacheById.set(`${cachePrefix}:${userId}`, { user: normalized, timestamp: nowTs });
  if (normalized?.agentId) {
    userRecordCacheById.set(`${cachePrefix}:${normalized.agentId}`, { user: normalized, timestamp: nowTs });
  }
  const { passwordHash: _, apiKeyHash: __, ...safeUser } = normalized;
  return safeUser;
}

export async function updateUserWhitelist(userId: string, networks: any, clientIp: string, allowMasterCascade: boolean = false) {
  // 1. Authoritative validation and normalization (includes self-lockout protection)
  const normalizedWL = validateAndNormalizeWhitelist(networks, allowMasterCascade ? clientIp : undefined);

  // 2. Update dedicated persistent store immediately
  userWhitelistStore.set(userId, normalizedWL);
  saveWhitelistStore();

  // 3. Database update on public.users
  const supabase = getSupabaseClient();
  const now = new Date().toISOString();

  let updatedUser: any = null;
  // Attempt direct column update on public.users if column exists
  try {
    const { data, error } = await supabase
      .from('users')
      .update({
        whitelisted_networks: normalizedWL,
        updatedAt: now,
      })
      .eq('id', userId)
      .select()
      .maybeSingle();

    if (!error && data) {
      updatedUser = data;
    }
  } catch (e) {
    // Column may not exist on users table
  }

  // Fallback to updating updatedAt on public.users if column update failed
  if (!updatedUser) {
    try {
      const { data } = await supabase
        .from('users')
        .update({ updatedAt: now })
        .eq('id', userId)
        .select()
        .maybeSingle();
      updatedUser = data;
    } catch (e) {}
  }

  // 3. Authoritative sync to Supabase Auth user_metadata and app_metadata
  if (supabase?.auth?.admin?.updateUserById) {
    try {
      await supabase.auth.admin.updateUserById(userId, {
        user_metadata: { whitelisted_networks: normalizedWL },
        app_metadata: { whitelisted_networks: normalizedWL },
      });
    } catch (e: any) {
      console.error('[updateUserWhitelist] Admin Auth update error:', e?.message || e);
    }
  }

  // 4. Invalidate all in-memory caches for this user
  invalidateUserRecordCache();
  invalidateAuthCache();

  // 5. Retrieve fresh normalized user record (which reads from Auth app_metadata / user_metadata)
  const freshUser = await findUserById(supabase, userId);
  if (freshUser) {
    freshUser.whitelisted_networks = normalizedWL;
    if (freshUser.id) userWhitelistStore.set(freshUser.id, normalizedWL);
    if (freshUser.agentId) userWhitelistStore.set(freshUser.agentId, normalizedWL);
    if (freshUser.email) userWhitelistStore.set(freshUser.email, normalizedWL);
    saveWhitelistStore();
    const cachePrefix = getSupabaseClientCachePrefix(supabase);
    const nowTs = Date.now();
    userRecordCacheById.set(`${cachePrefix}:${userId}`, { user: freshUser, timestamp: nowTs });
    if (freshUser.id) userRecordCacheById.set(`${cachePrefix}:${freshUser.id}`, { user: freshUser, timestamp: nowTs });
    if (freshUser.agentId) userRecordCacheById.set(`${cachePrefix}:${freshUser.agentId}`, { user: freshUser, timestamp: nowTs });
  }

  // 6. If caller is explicitly updating Master's own settings with active Copy Master IP Whitelist sync, push update to target slave agents
  let updatedMasterCopySettings: any = undefined;
  if (allowMasterCascade) {
    try {
      const userRec = freshUser || updatedUser;
      const isSlave = Boolean(
        userRec?.is_slave === true ||
        userRec?.account_type === 'slave' ||
        userRec?.role === 'slave' ||
        (typeof userRec?.email === 'string' && userRec.email.includes('+AMR-')) ||
        (userRec?.master_id && userRec?.master_id !== userId && !userRec?.is_master_slot && !userRec?.is_master_primary) ||
        (userRec?.masterUserId && userRec?.masterUserId !== userId && !userRec?.is_master_slot && !userRec?.is_master_primary)
      );

      // ONLY Pioneer Master account updates cascade down. Particular Slave account updates NEVER cascade.
      if (!isSlave) {
        const masterAuth = await fetchFreshAuthUser(supabase, userId);
        const copySettings = await resolveEffectiveMasterCopySettings(supabase, userId, masterAuth);
        const ipPolicy = copySettings?.ipSyncPolicy || copySettings?.syncPolicy || 'forever';
        const isIpSyncActive = Boolean(
          copySettings?.copyAccountIps === true && ipPolicy === 'forever'
        );
        const configuredIds: string[] =
          Array.isArray(copySettings?.ipSlaveIds) && copySettings.ipSlaveIds.length > 0
            ? copySettings.ipSlaveIds
            : Array.isArray(copySettings?.selectedSlaveIds)
            ? copySettings.selectedSlaveIds
            : [];

        if (isIpSyncActive && configuredIds.length > 0) {
          const fleetSlaves = await getMasterFleetSlaveRows(supabase, userRec || { id: userId });
          const normalizedTargets = new Set(
            configuredIds.map((v: any) => String(v || '').trim().replace(/^@/, '').toLowerCase()).filter(Boolean)
          );
          const matchedSlaves = fleetSlaves.filter((s: any) => {
            const cleanId = String(s.id || '').trim().toLowerCase();
            const cleanAgentId = String(s.agentId || '').trim().replace(/^@/, '').toLowerCase();
            return normalizedTargets.has(cleanId) || (cleanAgentId && normalizedTargets.has(cleanAgentId));
          });
          const targetRows = matchedSlaves.length > 0
            ? matchedSlaves
            : configuredIds.map((id) => ({ id, agentId: id }));

          for (const slave of targetRows) {
            const slaveId = slave.id;
            if (!slaveId || slaveId === userId) continue;
            setUserWhitelistDirect(slaveId, normalizedWL);
            if (slave.agentId && slave.agentId !== slaveId) {
              setUserWhitelistDirect(slave.agentId, normalizedWL);
            }
            try {
              await supabase
                .from('users')
                .update({ whitelisted_networks: normalizedWL, updatedAt: now })
                .eq('id', slaveId);
            } catch {}
            if (supabase?.auth?.admin?.updateUserById) {
              try {
                const slaveAuth = await getAuthUserForRecord(supabase, slave).catch(() => null);
                const authTargetId = slaveAuth?.id || slaveId;
                await supabase.auth.admin.updateUserById(authTargetId, {
                  user_metadata: { ...(slaveAuth?.user_metadata || {}), whitelisted_networks: normalizedWL },
                  app_metadata: { ...(slaveAuth?.app_metadata || {}), whitelisted_networks: normalizedWL },
                });
              } catch {}
            }
            invalidateUserRecordCache(slaveId);
          }

        }
      }
    } catch (syncErr) {
      console.warn('Non-fatal: Failed to auto-sync master whitelist update to synced slaves:', syncErr);
    }
  }

  return {
    whitelisted_networks: normalizedWL,
    user: freshUser || updatedUser,
    ...(updatedMasterCopySettings !== undefined ? { masterCopySettings: updatedMasterCopySettings } : {}),
  };
}

export async function deleteUserAccount(userId: string): Promise<void> {
  if (!userId) {
    throw new Error('User ID is required for account deletion.');
  }

  const supabase = getSupabaseClient();

  // 0. Pre-check: Verify user exists before attempting deletion
  const { data: userBefore, error: findErr } = await supabase
    .from('users')
    .select('id, agentId, email, avatar')
    .eq('id', userId)
    .maybeSingle();

  if (findErr) {
    console.error('[Account Deletion Pre-Check Error]', findErr);
    throw new Error(`Failed to check account existence: ${findErr.message}`);
  }

  if (!userBefore) {
    throw new Error('Account deletion failed: User account not found or already deleted.');
  }

  // Recycle deleted agent's avatar to inventory
  if (userBefore?.avatar) {
    recycleAvatarToInventory(userBefore.avatar).catch(err => {
      console.warn('[Account Deletion] Failed to recycle avatar to inventory:', err?.message || err);
    });
  }

  // Cascade delete all associated Slave Agents in parallel
  try {
    const { data: slaves } = await supabase
      .from('users')
      .select('id')
      .eq('master_id', userId);

    if (slaves && slaves.length > 0) {
      await Promise.allSettled(slaves.map((slave: any) => deleteUserAccount(slave.id)));
    }
  } catch (err: any) {
    console.warn('[Master Account Deletion] Warning fetching slave agents:', err?.message || err);
  }

  // --- EXECUTE DELETIONS CONCURRENTLY VIA PROMISE.ALLSETTLED ---
  const rawAgentId = (userBefore.agentId || '').trim();
  const cleanAgentId = rawAgentId.replace(/^@/, '');
  const prefixedAgentId = cleanAgentId ? `@${cleanAgentId}` : '';

  await Promise.allSettled([
    supabase.from('messages').delete().eq('senderUserId', userId),
    supabase.from('connections').delete().eq('user1_id', userId),
    supabase.from('connections').delete().eq('user2_id', userId),
    supabase.from('reviews').delete().eq('reviewerUserId', userId),
    supabase.from('replies').delete().eq('userId', userId),
    supabase.from('posts').delete().eq('userId', userId),
    supabase.from('agent_footprints').delete().eq('user_id', userId),
    supabase.from('external_events').delete().eq('user_id', userId),
    userBefore.agentId ? supabase.from('account_audit_logs').delete().eq('agentId', userBefore.agentId) : Promise.resolve(),
    invalidateAllHumanSessionsForUser(userId),
    supabase.from('human_sessions').delete().eq('userId', userId),
    supabase.from('password_reset_tokens').delete().eq('userId', userId),
    supabase.from('refresh_tokens').delete().eq('userId', userId),
  ]);

  // Cluster cleanup (non-blocking)
  try {
    const clusterTablesList = ['cluster_members', 'enclave_cluster_members'];
    const clusterMainList = ['clusters', 'enclave_clusters'];
    const clusterInvitesList = ['cluster_invites', 'enclave_cluster_invites'];
    const clusterMessagesList = ['cluster_messages', 'enclave_cluster_messages'];

    for (let i = 0; i < clusterTablesList.length; i++) {
      const membersTable = clusterTablesList[i];
      const clustersTable = clusterMainList[i];
      const invitesTable = clusterInvitesList[i];
      const messagesTable = clusterMessagesList[i];

      const memberOrConditions = [
        `userId.eq.${userId}`,
        rawAgentId ? `agentId.eq.${rawAgentId}` : null,
        prefixedAgentId ? `agentId.eq.${prefixedAgentId}` : null,
        cleanAgentId ? `agentId.eq.${cleanAgentId}` : null,
      ].filter(Boolean).join(',');

      const { data: memberRows } = await supabase
        .from(membersTable)
        .select('clusterId')
        .or(memberOrConditions);

      const affectedClusterIds = Array.from(new Set((memberRows || []).map((r: any) => r.clusterId).filter(Boolean)));

      await supabase.from(membersTable).delete().or(memberOrConditions);

      const inviteOrConditions = [
        `inviterUserId.eq.${userId}`,
        `inviteeUserId.eq.${userId}`,
        rawAgentId ? `inviterAgentId.eq.${rawAgentId}` : null,
        rawAgentId ? `invitedAgentId.eq.${rawAgentId}` : null,
        cleanAgentId ? `inviterAgentId.eq.${cleanAgentId}` : null,
        cleanAgentId ? `invitedAgentId.eq.${cleanAgentId}` : null,
      ].filter(Boolean).join(',');

      await supabase.from(invitesTable).delete().or(inviteOrConditions);

      if (affectedClusterIds.length > 0) {
        for (const clusterId of affectedClusterIds) {
          const { data: remaining } = await supabase
            .from(membersTable)
            .select('id, status')
            .eq('clusterId', clusterId);
          const activeRemaining = (remaining || []).filter((m: any) => m.status !== 'dissolved');
          if (!remaining || remaining.length === 0 || activeRemaining.length === 0) {
            await Promise.allSettled([
              supabase.from(messagesTable).delete().eq('clusterId', clusterId),
              supabase.from(invitesTable).delete().eq('clusterId', clusterId),
              supabase.from(membersTable).delete().eq('clusterId', clusterId),
              supabase.from(clustersTable).delete().eq('id', clusterId),
            ]);
          }
        }
      }
    }
  } catch (clusterErr) {
    console.warn('[Account Deletion] Warning during cluster cleanup:', clusterErr);
  }

  // Delete User Record from database
  const { error } = await supabase.from('users').delete().eq('id', userId);
  if (error) {
    throw new Error(`Failed to delete user account: ${error.message}`);
  }

  // Delete Supabase Auth user (direct and fast)
  try {
    if (supabase.auth?.admin?.deleteUser) {
      await supabase.auth.admin.deleteUser(userId);
    }
  } catch (e) {}

  invalidateAuthCache();
}

export async function logoutHumanSession(rawSessionId?: string) {
  if (rawSessionId) {
    try {
      const decoded = jwt.verify(rawSessionId.trim(), getJwtSecret()) as any;
      if (decoded && decoded.userId && decoded.sessionId) {
        revokeAutoSecret(decoded.userId, 'session_token', decoded.sessionId).catch(() => {});
        revokeAutoSecret(decoded.userId, 'session_token', rawSessionId).catch(() => {});
      }
    } catch (e) {}
    await invalidateHumanSession(rawSessionId);
  }
}

export async function logoutAgent(userId: string, refreshToken?: string) {
  try {
    revokeAutoSecret(userId, 'refresh_token').catch(() => {});
    revokeAutoSecret(userId, 'access_token').catch(() => {});
  } catch (e) {}
  if (refreshToken) {
    try {
      const tokenHash = hashToken(refreshToken);
      const supabase = getSupabaseClient();
      await supabase.from('refresh_tokens').delete().eq('tokenHash', tokenHash).eq('userId', userId);
    } catch (e) {
      console.error(`[Logout] Error deleting token: ${e}`);
    }
  }
}

export async function logoutUser(userId: string, refreshToken?: string) {
  revokeAllAutoSessions(userId).catch(() => {});
  return logoutAgent(userId, refreshToken);
}

export async function refreshSessionToken(token: string, clientIp?: string): Promise<{ user: Omit<UserRecord, 'passwordHash'>; tokens: AuthTokens }> {
  const decoded = verifyRefreshToken(token);
  if (!decoded) {
    throw new Error('Invalid or expired refresh token signature.');
  }

  const { userId, familyId } = decoded;
  const supabase = getSupabaseClient();
  const user = await findUserById(supabase, userId);

  if (!user || user.status !== 'active') {
    throw new Error('User is inactive or not found.');
  }

  if (user.passwordChangedAt && (decoded.iatMs || decoded.iat)) {
    const pwdChangedMs = new Date(user.passwordChangedAt).getTime();
    if (!isNaN(pwdChangedMs)) {
      const revoked = typeof decoded.iatMs === 'number'
        ? decoded.iatMs < pwdChangedMs
        : (typeof decoded.iat === 'number' && decoded.iat < Math.floor(pwdChangedMs / 1000));
      if (revoked) {
        throw new Error('Refresh token has been revoked globally.');
      }
    }
  }

  if (clientIp) {
    const isSlaveAccount = user.is_slave === true;
    if (isSlaveAccount && !isIpAllowed(clientIp, user.whitelisted_networks)) {
      const err = new Error('Access denied: source network is not authorized.');
      (err as any).statusCode = 403;
      throw err;
    }
  }

  const tokenHash = hashToken(token);
  const { data: storedToken, error: tokenError } = await supabase
    .from('refresh_tokens')
    .select('*')
    .eq('tokenHash', tokenHash)
    .maybeSingle();
    
  if (tokenError) {
    console.warn("refresh_tokens table query error (proceeding with JWT signature validity):", tokenError);
  } else if (!storedToken) {
    throw new Error('Invalid refresh token.');
  }

  if (storedToken) {
    if (storedToken.isRevoked) {
      // Refresh token reuse detected! Revoke the whole family.
      await supabase.from('refresh_tokens').update({ isRevoked: true }).eq('familyId', familyId).catch(() => {});
      throw new Error('Refresh token has been revoked.');
    }
    
    if (storedToken.userId !== userId) {
      throw new Error('Invalid refresh token ownership.');
    }
    
    if (new Date(storedToken.expiresAt).getTime() < Date.now()) {
      throw new Error('Refresh token has expired.');
    }

    // Atomic revoke the old token
    const { data: revokedTokens, error: revokeError } = await supabase
      .from('refresh_tokens')
      .update({ isRevoked: true })
      .eq('id', storedToken.id)
      .eq('isRevoked', false)
      .select();

    if (revokeError || !revokedTokens || revokedTokens.length === 0) {
      // Concurrent reuse detected! Revoke the whole family.
      await supabase.from('refresh_tokens').update({ isRevoked: true }).eq('familyId', familyId).catch(() => {});
      throw new Error('Refresh token has already been rotated or revoked concurrently.');
    }
  }

  const authUser = await getAuthUserForRecord(supabase, user);
  const normalizedUser = normalizeUserRecord(user, authUser);
  const newAccessToken = generateAccessToken(normalizedUser);
  const nextFamilyId = familyId || crypto.randomUUID();
  const newRefreshToken = generateRefreshToken(userId, nextFamilyId);
  await persistRefreshToken(userId, nextFamilyId, newRefreshToken);

  // Auto-preserve refreshed tokens in Secret Preserver (encrypted at rest, replaces previous session tokens)
  enrollAutoSecret(userId, 'access_token', newAccessToken).catch(() => {});
  enrollAutoSecret(userId, 'refresh_token', newRefreshToken, { identifier: nextFamilyId }).catch(() => {});

  const { passwordHash: _, apiKeyHash: __, ...safeUser } = normalizedUser;
  return {
    user: safeUser as any,
    tokens: { accessToken: newAccessToken, refreshToken: newRefreshToken },
  };
}

export async function resolveEffectiveMasterCopySettings(
  supabase: any,
  masterUserId: string,
  masterAuthUser?: any,
  options?: { useProvidedAuthUser?: boolean }
): Promise<any> {
  const [resolvedAuth, entResult] = await Promise.all([
    options?.useProvidedAuthUser && masterAuthUser
      ? Promise.resolve(masterAuthUser)
      : fetchFreshAuthUser(supabase, masterUserId).then((fresh) => fresh || masterAuthUser || null),
    Promise.resolve(
      supabase
        .from('master_plan_entitlements')
        .select('id, metadata, status, updated_at')
        .eq('master_account_id', masterUserId)
        .order('updated_at', { ascending: false })
        .limit(10)
    ).catch(() => ({ data: null })),
  ]);

  const authSettings = resolvedAuth?.app_metadata?.masterCopySettings || null;
  let planSettings: any = null;
  try {
    const entRows = entResult?.data;
    if (Array.isArray(entRows) && entRows.length > 0) {
      const preferred =
        entRows.find((r: any) => r.status === 'active' && r.metadata?.masterCopySettings) ||
        entRows.find((r: any) => r.status === 'active') ||
        entRows.find((r: any) => r.metadata?.masterCopySettings) ||
        entRows[0];
      planSettings = preferred?.metadata?.masterCopySettings || null;
    }
  } catch {}

  if (authSettings && planSettings) {
    const authTs = authSettings.updatedAt ? new Date(authSettings.updatedAt).getTime() : 0;
    const planTs = planSettings.updatedAt ? new Date(planSettings.updatedAt).getTime() : 0;
    return planTs > authTs ? planSettings : authSettings;
  }
  return authSettings || planSettings || {};
}

export async function persistMasterCopySettingsUpdate(
  supabase: any,
  masterUserId: string,
  updatedCopySettings: any,
  masterAuthUser?: any,
  options?: { useProvidedAuthUser?: boolean }
): Promise<any> {
  const [resolvedAuth, entFetchRes] = await Promise.all([
    options?.useProvidedAuthUser && masterAuthUser
      ? Promise.resolve(masterAuthUser)
      : fetchFreshAuthUser(supabase, masterUserId).then((fresh) => fresh || masterAuthUser || null),
    Promise.resolve(
      supabase
        .from('master_plan_entitlements')
        .select('id, metadata, status')
        .eq('master_account_id', masterUserId)
        .order('updated_at', { ascending: false })
        .limit(10)
    ).catch(() => ({ data: null })),
  ]);

  const writeOps: Promise<any>[] = [];

  if (resolvedAuth && supabase?.auth?.admin?.updateUserById) {
    writeOps.push(
      supabase.auth.admin
        .updateUserById(resolvedAuth.id, {
          app_metadata: {
            ...(resolvedAuth.app_metadata || {}),
            masterCopySettings: updatedCopySettings,
          },
        })
        .catch((err: any) => {
          console.warn('Non-fatal: Failed to persist masterCopySettings to auth app_metadata:', err);
        })
    );
  }

  const entRows = entFetchRes?.data;
  if (Array.isArray(entRows) && entRows.length > 0) {
    const nowIso = new Date().toISOString();
    for (const row of entRows) {
      writeOps.push(
        Promise.resolve(
          supabase
            .from('master_plan_entitlements')
            .update({
              metadata: {
                ...(row.metadata || {}),
                masterCopySettings: updatedCopySettings,
              },
              updated_at: nowIso,
            })
            .eq('id', row.id)
        ).catch((entErr: any) => {
          console.warn('Non-fatal: Failed to persist masterCopySettings to master_plan_entitlements:', entErr);
        })
      );
    }
  }

  if (writeOps.length > 0) {
    await Promise.all(writeOps);
  }

  if (Array.isArray(entRows) && entRows.length > 0) {
    try {
      const { MasterAccountService } = await import('./services/masterAccountService.js');
      MasterAccountService.getInstance().invalidateMasterPlanCache(masterUserId);
    } catch {}
  }

  invalidateAuthCache();
  invalidateUserRecordCache(masterUserId);
  return updatedCopySettings;
}

export async function consumeOneTimeCopySection(
  supabase: any,
  masterUserId: string,
  section: 'access' | 'ip' | 'rotation' | 'logout',
  masterAuthUser?: any,
  options?: { preloadedSettings?: any; useProvidedAuthUser?: boolean }
): Promise<any> {
  const currentSettings =
    options?.preloadedSettings && typeof options.preloadedSettings === 'object'
      ? options.preloadedSettings
      : await resolveEffectiveMasterCopySettings(supabase, masterUserId, masterAuthUser, {
          useProvidedAuthUser: options?.useProvidedAuthUser,
        });

  if (!currentSettings || typeof currentSettings !== 'object') {
    return {};
  }

  const nextSettings: Record<string, any> = {
    ...currentSettings,
  };

  let changed = false;

  if (section === 'access') {
    const policy = currentSettings.accessSyncPolicy || currentSettings.syncPolicy;
    if (
      policy === 'one_time' &&
      (currentSettings.copyAccessManagement ||
        (Array.isArray(currentSettings.accessSlaveIds) && currentSettings.accessSlaveIds.length > 0) ||
        currentSettings.accessSyncPolicy === 'one_time')
    ) {
      nextSettings.copyAccessManagement = false;
      nextSettings.accessSlaveIds = [];
      nextSettings.accessSyncPolicy = null;
      changed = true;
    }
  } else if (section === 'ip') {
    const policy = currentSettings.ipSyncPolicy || currentSettings.syncPolicy;
    if (
      policy === 'one_time' &&
      (currentSettings.copyAccountIps ||
        (Array.isArray(currentSettings.ipSlaveIds) && currentSettings.ipSlaveIds.length > 0) ||
        currentSettings.ipSyncPolicy === 'one_time')
    ) {
      nextSettings.copyAccountIps = false;
      nextSettings.ipSlaveIds = [];
      nextSettings.ipSyncPolicy = null;
      changed = true;
    }
  } else if (section === 'rotation') {
    const policy = currentSettings.rotationSyncPolicy || currentSettings.syncPolicy;
    if (
      policy === 'one_time' &&
      (currentSettings.copyApiKeyRotation ||
        (Array.isArray(currentSettings.rotationSlaveIds) && currentSettings.rotationSlaveIds.length > 0) ||
        currentSettings.rotationSyncPolicy === 'one_time')
    ) {
      nextSettings.copyApiKeyRotation = false;
      nextSettings.rotationSlaveIds = [];
      nextSettings.rotationSyncPolicy = null;
      changed = true;
    }
  } else if (section === 'logout') {
    const policy = currentSettings.logoutSyncPolicy || currentSettings.syncPolicy;
    if (
      policy === 'one_time' &&
      (currentSettings.copyGlobalLogout ||
        (Array.isArray(currentSettings.logoutSlaveIds) && currentSettings.logoutSlaveIds.length > 0) ||
        currentSettings.logoutSyncPolicy === 'one_time')
    ) {
      nextSettings.copyGlobalLogout = false;
      nextSettings.logoutSlaveIds = [];
      nextSettings.logoutSyncPolicy = null;
      changed = true;
    }
  }

  if (!changed) {
    return currentSettings;
  }

  nextSettings.updatedAt = new Date().toISOString();

  await persistMasterCopySettingsUpdate(supabase, masterUserId, nextSettings, masterAuthUser, {
    useProvidedAuthUser: options?.useProvidedAuthUser,
  });

  return nextSettings;
}

export async function getMasterFleetSlaveRows(supabase: any, masterUser: any): Promise<any[]> {
  const collected = new Map<string, any>();

  // Wave 1: fetch direct children AND master entitlements in parallel
  const [directChildrenRes, entRes] = await Promise.all([
    Promise.resolve(
      supabase
        .from('users')
        .select('*')
        .eq('master_id', masterUser.id)
    ).catch(() => ({ data: null })),
    Promise.resolve(
      supabase
        .from('master_plan_entitlements')
        .select('metadata, status')
        .eq('master_account_id', masterUser.id)
        .order('updated_at', { ascending: false })
        .limit(10)
    ).catch(() => ({ data: null })),
  ]);

  const directChildren = directChildrenRes?.data;
  const masterSlotIds: string[] = [];
  if (Array.isArray(directChildren)) {
    for (const row of directChildren) {
      if (!row || row.id === masterUser.id) continue;
      const normalized = normalizeUserRecord(row);
      const isSlot =
        normalized.is_master_slot === true ||
        normalized.account_type === 'master_slot' ||
        (normalized.role === 'master' && normalized.is_slave !== true && normalized.account_type !== 'slave');
      if (isSlot) {
        masterSlotIds.push(row.id);
      } else {
        collected.set(row.id, normalized);
      }
    }
  }

  const fleetIds = new Set<string>();
  if (masterUser.fleet_id) fleetIds.add(String(masterUser.fleet_id).trim());
  const entRows = entRes?.data;
  if (Array.isArray(entRows)) {
    for (const ent of entRows) {
      const meta = ent?.metadata || {};
      if (meta.fleet_id) fleetIds.add(String(meta.fleet_id).trim());
      if (meta.latest_fleet_id) fleetIds.add(String(meta.latest_fleet_id).trim());
      if (Array.isArray(meta.fleet_ids)) {
        meta.fleet_ids.forEach((f: any) => f && fleetIds.add(String(f).trim()));
      }
    }
  }

  const fleetOrFilter = fleetIds.size > 0
    ? Array.from(fleetIds)
        .filter(Boolean)
        .map((fid) => `fleet_id.ilike.${fid}`)
        .join(',')
    : '';

  // Wave 2: fetch slot children AND fleet_id rows in parallel
  const [slotChildrenRes, fleetRowsRes] = await Promise.all([
    masterSlotIds.length > 0
      ? Promise.resolve(
          supabase
            .from('users')
            .select('*')
            .in('master_id', masterSlotIds)
        ).catch(() => ({ data: null }))
      : Promise.resolve({ data: null }),
    fleetOrFilter
      ? Promise.resolve(
          supabase
            .from('users')
            .select('*')
            .or(fleetOrFilter)
        ).catch(() => ({ data: null }))
      : Promise.resolve({ data: null }),
  ]);

  const slotChildren = slotChildrenRes?.data;
  if (Array.isArray(slotChildren)) {
    for (const row of slotChildren) {
      if (row && row.id !== masterUser.id && !collected.has(row.id)) {
        collected.set(row.id, normalizeUserRecord(row));
      }
    }
  }

  const fleetRows = fleetRowsRes?.data;
  if (Array.isArray(fleetRows)) {
    for (const row of fleetRows) {
      if (!row || row.id === masterUser.id || collected.has(row.id)) continue;
      const normalized = normalizeUserRecord(row);
      const isSlot =
        normalized.is_master_slot === true ||
        normalized.account_type === 'master_slot' ||
        (normalized.role === 'master' && normalized.is_slave !== true && normalized.account_type !== 'slave');
      if (!isSlot && (normalized.is_slave === true || normalized.account_type === 'slave' || normalized.role === 'slave' || (typeof normalized.email === 'string' && normalized.email.includes('+AMR-')))) {
        collected.set(row.id, normalized);
      }
    }
  }

  return Array.from(collected.values());
}

/**
 * Initiates an API key rotation request by generating a token and sending a confirmation email link.
 * Password is no longer required.
 */
export async function requestAgentApiKeyRotation(userId: string, customAppUrl?: string) {
  const supabase = getSupabaseClient();

  const [userRes, freshAuthUser] = await Promise.all([
    supabase
      .from('users')
      .select('id, agentId, email, owner_email, name, fleet_id, master_id, is_master_primary, is_master_slot, account_type, role, is_slave')
      .eq('id', userId)
      .maybeSingle(),
    fetchFreshAuthUser(supabase, userId),
  ]);

  const { data: user, error: userError } = userRes;
  if (userError || !user) throw new Error('User not found.');

  let authUser = freshAuthUser;
  if (!authUser && user.email) {
    try {
      const { data: createdAuth } = await supabase.auth.admin.createUser({
        id: user.id,
        email: user.email,
        email_confirm: true,
        user_metadata: { agentId: user.agentId, name: user.name },
        app_metadata: { emailVerified: false },
      });
      authUser = createdAuth?.user || (await fetchFreshAuthUser(supabase, user.id));
    } catch {}
  }
  if (!authUser) throw new Error('Auth account not found for this user.');

  const isSlave = Boolean(
    (user.master_id && user.master_id !== user.id && !user.is_master_primary) ||
    user.is_master_slot === true ||
    user.account_type === 'master_slot' ||
    user.account_type === 'slave' ||
    user.role === 'slave' ||
    user.is_slave === true ||
    (user.email && typeof user.email === 'string' && user.email.includes('+AMR-'))
  );

  let syncedSlaves: Array<{ id: string; agentId: string; name: string }> = [];
  let isCopyApiKeyRotationOn = false;
  let rotationSyncPolicy: string | null = null;
  let masterCopySettings: any = null;

  if (!isSlave) {
    // Pioneer Master account: ONLY queue slave accounts when Copy Master has API Key Rotation explicitly ON
    const [resolvedCopySettings, slaveRows] = await Promise.all([
      resolveEffectiveMasterCopySettings(supabase, user.id, authUser, { useProvidedAuthUser: true }),
      getMasterFleetSlaveRows(supabase, user),
    ]);
    masterCopySettings = resolvedCopySettings;
    isCopyApiKeyRotationOn = Boolean(masterCopySettings?.copyApiKeyRotation === true);
    rotationSyncPolicy = masterCopySettings?.rotationSyncPolicy || masterCopySettings?.syncPolicy || null;

    if (isCopyApiKeyRotationOn) {
      const configuredIds: string[] =
        Array.isArray(masterCopySettings?.rotationSlaveIds) && masterCopySettings.rotationSlaveIds.length > 0
          ? masterCopySettings.rotationSlaveIds
          : Array.isArray(masterCopySettings?.selectedSlaveIds)
          ? masterCopySettings.selectedSlaveIds
          : [];

      if (configuredIds.length > 0) {
        const normalizedConfigured = new Set(
          configuredIds.map((v: any) => String(v || '').trim().replace(/^@/, '').toLowerCase()).filter(Boolean)
        );
        const matchedMap = new Map<string, { id: string; agentId: string; name: string }>();
        for (const s of slaveRows) {
          const cleanId = String(s.id || '').trim().toLowerCase();
          const cleanAgentId = String(s.agentId || '').trim().replace(/^@/, '').toLowerCase();
          if (normalizedConfigured.has(cleanId) || (cleanAgentId && normalizedConfigured.has(cleanAgentId))) {
            matchedMap.set(s.id, { id: s.id, agentId: s.agentId, name: s.name || s.agentId });
          }
        }

        // Direct ID lookup fallback in case any configured slave was not caught by fleet queries
        const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
        const missingIds = configuredIds.filter((rawId: any) => {
          const str = String(rawId || '').trim();
          return uuidPattern.test(str) && !matchedMap.has(str) && str !== user.id;
        });
        if (missingIds.length > 0) {
          try {
            const { data: directSlaves } = await supabase
              .from('users')
              .select('id, agentId, name, is_master_slot, account_type')
              .in('id', missingIds);
            if (Array.isArray(directSlaves)) {
              for (const s of directSlaves) {
                const isSlot = s.is_master_slot === true || s.account_type === 'master_slot';
                if (s && s.id !== user.id && !isSlot && !matchedMap.has(s.id)) {
                  matchedMap.set(s.id, { id: s.id, agentId: s.agentId, name: s.name || s.agentId });
                }
              }
            }
          } catch {}
        }

        syncedSlaves = Array.from(matchedMap.values());
      }
    }
  }

  const isMasterCopyRotation = !isSlave && isCopyApiKeyRotationOn && syncedSlaves.length > 0;

  // Generate secure token
  const secret = crypto.randomBytes(32).toString('hex');
  const token = `${user.id}.${secret}`;
  const tokenHash = crypto.createHash('sha256').update(secret).digest('hex');
  const expiresAt = new Date(Date.now() + 30 * 60 * 1000).toISOString(); // 30 minutes

  const nextPendingPayload = {
    tokenHash,
    expiresAt,
    targetSlaveIds: isMasterCopyRotation ? syncedSlaves.map(s => s.id) : [],
    isMasterCopyRotation,
    rotationSyncPolicy: isMasterCopyRotation ? (rotationSyncPolicy || 'forever') : null,
  };

  const nextAppMetadata = {
    ...authUser.app_metadata,
    pendingApiKeyRotation: nextPendingPayload,
  };

  // Store in auth user's app_metadata before dispatching link
  const { error: updateErr } = await supabase.auth.admin.updateUserById(authUser.id, {
    app_metadata: nextAppMetadata,
  });

  if (updateErr) {
    throw new Error(`Failed to generate API key rotation request: ${updateErr.message}`);
  }

  const recipientEmail = (user.owner_email || user.email || '').replace(/\+AMR-[^@]+/i, '').trim();
  const targetEmail = (recipientEmail || user.email || '').trim();
  const appUrl = customAppUrl || process.env.APP_URL || config.appUrl || 'https://aamarva.com';

  if (isMasterCopyRotation) {
    console.log(`[API_KEY_ROTATION] Dispatching Copy Master cascade verification email to ${targetEmail} (${syncedSlaves.length} slave(s))`);
    await sendMasterCascadeRotationVerificationEmail({
      toEmail: targetEmail,
      toName: user.name,
      masterAgentId: user.agentId,
      token,
      appUrl,
      syncPolicy: rotationSyncPolicy || 'forever',
      cascadeSlaves: syncedSlaves,
    });
  } else {
    console.log(`[API_KEY_ROTATION] Dispatching standard single-account verification email to ${targetEmail}`);
    await sendApiKeyRotationEmail(
      targetEmail,
      token,
      appUrl,
      user.name
    );
  }

  return {
    success: true,
    isMasterCopyRotation,
    queuedSlavesCount: isMasterCopyRotation ? syncedSlaves.length : 0,
    message: isMasterCopyRotation
      ? `Master cascade API key rotation verification link sent to ${recipientEmail || user.email} (${syncedSlaves.length} selected slave account${syncedSlaves.length > 1 ? 's' : ''} queued).`
      : `API key rotation confirmation link sent to ${recipientEmail || user.email}. Please check your inbox and click the link to confirm rotation.`,
  };
}

/**
 * Confirms API key rotation via token received from email link.
 * If called for a Master account with Copy Master API Key Rotation active, rotates all queued Slave accounts' API keys and returns the new keys directly.
 * If called for a Slave account, rotates that Slave account's API key and returns the new key directly.
 */
export async function confirmAgentApiKeyRotation(token: string) {
  if (!token || !token.includes('.')) {
    throw new Error('Invalid or malformed rotation token.');
  }

  const parts = token.split('.');
  const userId = parts[0];
  const secret = parts.slice(1).join('.');
  const secretHash = crypto.createHash('sha256').update(secret).digest('hex');

  const supabase = getSupabaseClient();
  const [userRes, authUser] = await Promise.all([
    supabase
      .from('users')
      .select('*')
      .eq('id', userId)
      .maybeSingle(),
    fetchFreshAuthUser(supabase, userId),
  ]);

  const { data: user, error: userError } = userRes;
  if (userError || !user) throw new Error('User account not found.');
  if (!authUser) throw new Error('Auth account not found for this user.');

  const pending = authUser.app_metadata?.pendingApiKeyRotation;

  if (!pending) {
    throw new Error('No pending API key rotation request found. The link may have already been used or expired.');
  }

  const matchesHash = pending.tokenHash === secretHash || pending.tokenHash === crypto.createHash('sha256').update(token).digest('hex');
  if (!matchesHash) {
    throw new Error('Invalid or already used API key rotation token.');
  }

  if (new Date(pending.expiresAt).getTime() < Date.now()) {
    // Clear expired token
    await supabase.auth.admin.updateUserById(authUser.id, {
      app_metadata: { ...authUser.app_metadata, pendingApiKeyRotation: null },
    });
    throw new Error('API key rotation token has expired. Please request a new rotation link.');
  }

  const isSlave = Boolean(
    (user.master_id && user.master_id !== user.id && !user.is_master_primary) ||
    user.is_master_slot === true ||
    user.account_type === 'master_slot' ||
    user.account_type === 'slave' ||
    user.role === 'slave' ||
    user.is_slave === true ||
    (user.email && typeof user.email === 'string' && user.email.includes('+AMR-'))
  );

  const initialTargetIds: string[] = Array.isArray(pending.targetSlaveIds) ? pending.targetSlaveIds : [];

  const [masterCopySettings, slaveRows] = await Promise.all([
    resolveEffectiveMasterCopySettings(supabase, user.id, authUser, { useProvidedAuthUser: true }),
    getMasterFleetSlaveRows(supabase, user),
  ]);

  const fallbackConfiguredIds =
    Array.isArray(masterCopySettings?.rotationSlaveIds) && masterCopySettings.rotationSlaveIds.length > 0
      ? masterCopySettings.rotationSlaveIds
      : Array.isArray(masterCopySettings?.selectedSlaveIds) && masterCopySettings.selectedSlaveIds.length > 0
      ? masterCopySettings.selectedSlaveIds
      : [];

  const targetIds = initialTargetIds.length > 0 ? initialTargetIds : fallbackConfiguredIds;
  const isMasterCopyCascade = Boolean(
    !isSlave &&
    (pending.isMasterCopyRotation === true || masterCopySettings?.copyApiKeyRotation === true) &&
    targetIds.length > 0
  );

  if (isMasterCopyCascade) {
    // MASTER COPY CASCADE ROTATION: Rotate ONLY queued Slave accounts when Copy Master API Key Rotation was enabled

    const normalizedTargets = new Set(
      targetIds.map((id: any) => String(id || '').trim().replace(/^@/, '').toLowerCase()).filter(Boolean)
    );
    const matchedSlaveMap = new Map<string, any>();
    for (const s of slaveRows) {
      const cleanId = String(s.id || '').trim().toLowerCase();
      const cleanAgentId = String(s.agentId || '').trim().replace(/^@/, '').toLowerCase();
      if (normalizedTargets.has(cleanId) || (cleanAgentId && normalizedTargets.has(cleanAgentId))) {
        matchedSlaveMap.set(s.id, s);
      }
    }
    const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    const missingTargetIds = targetIds.filter((rawId: any) => {
      const str = String(rawId || '').trim();
      return uuidPattern.test(str) && !matchedSlaveMap.has(str) && str !== user.id;
    });
    if (missingTargetIds.length > 0) {
      try {
        const { data: directSlaves } = await supabase
          .from('users')
          .select('*')
          .in('id', missingTargetIds);
        if (Array.isArray(directSlaves)) {
          for (const s of directSlaves) {
            const isSlot = s.is_master_slot === true || s.account_type === 'master_slot';
            if (s && s.id !== user.id && !isSlot && !matchedSlaveMap.has(s.id)) {
              matchedSlaveMap.set(s.id, s);
            }
          }
        }
      } catch {}
    }
    const slavesToRotate = Array.from(matchedSlaveMap.values());

    // Process slave key rotations in bounded concurrent chunks (5 at a time)
    const rotatedSlaves: Array<{ id: string; agentId: string; name: string; apiKey: string }> = [];
    const CHUNK_SIZE = 5;
    for (let i = 0; i < slavesToRotate.length; i += CHUNK_SIZE) {
      const chunk = slavesToRotate.slice(i, i + CHUNK_SIZE);
      const chunkResults = await Promise.all(
        chunk.map(async (slave) => {
          const slaveNewKey = generateApiKey();
          const [slaveKeyHash, slaveAuthUser] = await Promise.all([
            hashApiKey(slaveNewKey),
            getAuthUserForRecord(supabase, slave).catch(() => null),
          ]);
          const slaveFp = computeApiKeyFingerprint(slaveNewKey);

          await Promise.all([
            slaveAuthUser
              ? supabase.auth.admin
                  .updateUserById(slaveAuthUser.id, {
                    app_metadata: {
                      ...slaveAuthUser.app_metadata,
                      apiKeyHash: slaveKeyHash,
                      apiKeyFingerprint: slaveFp,
                      pendingApiKeyRotation: null,
                    },
                  })
                  .catch((e: any) => {
                    console.warn(`Non-fatal: Failed to update auth app_metadata for slave ${slave.agentId}:`, e);
                  })
              : Promise.resolve(),
            Promise.resolve(
              supabase
                .from('users')
                .update({
                  apiKeyFingerprint: slaveFp,
                  updatedAt: new Date().toISOString(),
                })
                .eq('id', slave.id)
            ).catch((e: any) => {
              console.warn(`Non-fatal: Failed to update users row for slave ${slave.agentId}:`, e);
            }),
          ]);

          invalidateUserRecordCache(slave.id);
          enrollAutoSecret(slave.id, 'api_key', slaveNewKey).catch(() => {});

          return {
            id: slave.id,
            agentId: slave.agentId,
            name: slave.name || slave.agentId,
            apiKey: slaveNewKey,
          };
        })
      );
      rotatedSlaves.push(...chunkResults);
    }

    // Clear pendingApiKeyRotation on Master; only reset live rotation flags if an active 'one_time' rotation setting is still present
    const currentRotationPolicy = masterCopySettings?.rotationSyncPolicy || masterCopySettings?.syncPolicy;
    const updatedCopySettings = { ...(masterCopySettings || {}) };
    let didResetOneTime = false;
    if (masterCopySettings?.copyApiKeyRotation === true && currentRotationPolicy === 'one_time') {
      updatedCopySettings.rotationSlaveIds = [];
      updatedCopySettings.copyApiKeyRotation = false;
      updatedCopySettings.rotationSyncPolicy = null;
      updatedCopySettings.updatedAt = new Date().toISOString();
      didResetOneTime = true;
    }

    const recipientEmail = (user.owner_email || user.email || '').replace(/\+AMR-[^@]+/i, '');

    const masterUpdatePromise = supabase.auth.admin.updateUserById(authUser.id, {
      app_metadata: {
        ...(authUser.app_metadata || {}),
        apiKeyHash: null,
        pendingApiKeyRotation: null,
        masterCopySettings: updatedCopySettings,
      },
    });

    const entitlementResetPromise = didResetOneTime
      ? (async () => {
          try {
            const { data: entRows } = await supabase
              .from('master_plan_entitlements')
              .select('id, metadata, status')
              .eq('master_account_id', user.id)
              .order('updated_at', { ascending: false })
              .limit(10);
            if (Array.isArray(entRows) && entRows.length > 0) {
              const nowIso = new Date().toISOString();
              await Promise.all(
                entRows.map((row: any) =>
                  supabase
                    .from('master_plan_entitlements')
                    .update({
                      metadata: {
                        ...(row.metadata || {}),
                        masterCopySettings: updatedCopySettings,
                      },
                      updated_at: nowIso,
                    })
                    .eq('id', row.id)
                )
              );
              try {
                const { MasterAccountService } = await import('./services/masterAccountService.js');
                MasterAccountService.getInstance().invalidateMasterPlanCache(user.id);
              } catch {}
            }
          } catch (entErr) {
            console.warn('Non-fatal: Failed to reset one_time rotation settings in master_plan_entitlements:', entErr);
          }
        })()
      : Promise.resolve();

    // Run master metadata cleanup and one_time reset concurrently
    await Promise.all([masterUpdatePromise, entitlementResetPromise]);

    invalidateAuthCache();
    invalidateUserRecordCache(user.id);

    return {
      apiKey: rotatedSlaves[0]?.apiKey || '',
      rotatedSlaves,
      isMasterRotation: true,
      masterCopySettings: updatedCopySettings,
      masterAgent: {
        id: user.id,
        agentId: user.agentId,
        name: user.name || user.agentId,
      },
    };
  }

  // SINGLE ACCOUNT ROTATION: Generate new API Key for this account
  const newApiKey = generateApiKey();
  const apiKeyHash = await hashApiKey(newApiKey);
  const apiKeyFingerprint = computeApiKeyFingerprint(newApiKey);

  // Update Supabase Auth app_metadata (authoritative storage) and clear pendingApiKeyRotation
  const { error: authUpdateError } = await supabase.auth.admin.updateUserById(authUser.id, {
    app_metadata: {
      ...authUser.app_metadata,
      apiKeyHash,
      apiKeyFingerprint,
      pendingApiKeyRotation: null,
    },
  });

  if (authUpdateError) {
    console.error('Failed to update apiKeyHash in Supabase Auth:', authUpdateError);
    throw new Error('Failed to update agent credentials.');
  }

  invalidateAuthCache();

  // Auto-preserve new rotated API key in Secret Preserver (automatically replaces previous key)
  enrollAutoSecret(user.id, 'api_key', newApiKey).catch(() => {});

  // Run public users table update
  await Promise.resolve(
    supabase
      .from('users')
      .update({
        apiKeyFingerprint,
        updatedAt: new Date().toISOString(),
      })
      .eq('id', user.id)
  ).catch((err: any) => {
    console.warn('Non-fatal: Failed to update users.apiKeyFingerprint during rotation:', err?.message || err);
  });

  invalidateAuthCache();

  return {
    apiKey: newApiKey,
    agentId: user.agentId,
    id: user.id,
    name: user.name || user.agentId,
  };
}

/**
 * Rotates the agent's API key.
 * Now routes either to confirmation if a token is provided, or initiates email verification link.
 */
export async function rotateAgentApiKey(userId: string, tokenOrPassword?: string, customAppUrl?: string) {
  if (tokenOrPassword && tokenOrPassword.includes('.')) {
    return await confirmAgentApiKeyRotation(tokenOrPassword);
  }
  return await requestAgentApiKeyRotation(userId, customAppUrl);
}

/**
 * Initiates an email change request.
 * 1. Validates new email.
 * 2. Stores hashed token in app_metadata.
 * 3. Sends verification email to the OLD address.
 */
export async function requestEmailChange(userId: string, data: { newEmail: string; password?: string }, customAppUrl?: string) {
  const supabase = getSupabaseClient();
  const normalizedNewEmail = normalizeEmail(data.newEmail);

  if (!validateEmailFormat(normalizedNewEmail)) {
    throw new Error('Invalid email format.');
  }

  // 1. Find current user
  const { data: user, error: userError } = await supabase
    .from('users')
    .select('*')
    .eq('id', userId)
    .maybeSingle();

  if (userError || !user) throw new Error('User not found.');
  if (normalizeEmail(user.email) === normalizedNewEmail) {
    throw new Error('New email is identical to current email.');
  }

  // 3 & 5. Check if new email is already taken AND fetch Supabase Auth user concurrently
  const [existingRes, authUserRes] = await Promise.all([
    supabase
      .from('users')
      .select('id')
      .ilike('email', normalizedNewEmail)
      .or('master_id.is.null,is_master_primary.eq.true')
      .maybeSingle(),
    supabase.auth.admin.getUserById(user.id),
  ]);

  if (existingRes?.data) {
    throw new Error('Email address already in use.');
  }

  // 4. Generate verification token bound to user id
  const secret = crypto.randomBytes(32).toString('hex');
  const token = `${user.id}.${secret}`;
  const tokenHash = crypto.createHash('sha256').update(secret).digest('hex');
  const expiresAt = new Date(Date.now() + 30 * 60 * 1000).toISOString(); // 30 minutes

  const { data: authUserData, error: authUserErr } = authUserRes;
  const authUser = authUserData?.user;
  if (authUserErr || !authUser) throw new Error('Auth account not found.');

  const { error: updateError } = await supabase.auth.admin.updateUserById(authUser.id, {
    app_metadata: {
      ...authUser.app_metadata,
      pendingEmailChange: {
        newEmail: normalizedNewEmail,
        tokenHash,
        expiresAt
      }
    }
  });

  if (updateError) throw new Error('Failed to create verification request.');

  // 6. Send email to OLD address
  const appUrl = customAppUrl || process.env.APP_URL || config.appUrl || 'https://aamarva.com';
  await sendEmailVerification(user.email, normalizedNewEmail, token, appUrl);

  return { message: 'Verification email sent to your current address.' };
}

/**
 * Verifies and applies an email change.
 */
export async function verifyEmailChange(token: string) {
  const supabase = getSupabaseClient();
  let targetAuthUser: any = null;
  let pendingData: any = null;

  // 1. Direct O(1) Auth user lookup via userId encoded in the verification token
  if (token && token.includes('.')) {
    const parts = token.split('.');
    const userId = parts[0];
    const secret = parts.slice(1).join('.');
    const secretHash = crypto.createHash('sha256').update(secret).digest('hex');

    const { data: authUserData, error: authUserErr } = await supabase.auth.admin.getUserById(userId);
    if (!authUserErr && authUserData?.user) {
      const p = authUserData.user.app_metadata?.pendingEmailChange;
      if (p && (p.tokenHash === secretHash || p.tokenHash === crypto.createHash('sha256').update(token).digest('hex'))) {
        targetAuthUser = authUserData.user;
        pendingData = p;
      }
    }
  }

  if (!targetAuthUser || !pendingData) {
    throw new Error('Invalid or expired verification token.');
  }

  // 2. Check expiration
  if (new Date(pendingData.expiresAt).getTime() < Date.now()) {
    // Clear expired data
    await supabase.auth.admin.updateUserById(targetAuthUser.id, {
      app_metadata: { ...targetAuthUser.app_metadata, pendingEmailChange: null }
    });
    throw new Error('Verification token has expired.');
  }

  // 3. Final availability check (someone else might have taken it in the meantime)
  const { data: collision } = await supabase
    .from('users')
    .select('id')
    .ilike('email', pendingData.newEmail)
    .maybeSingle();
  
  if (collision) {
    throw new Error('Email address is no longer available.');
  }

  const oldEmail = targetAuthUser.email;

  // 4. Atomic Update with Rollback on failure
  // a. Update public users table
  const { error: dbError } = await supabase
    .from('users')
    .update({ 
      email: pendingData.newEmail,
      emailVerified: false,
      emailVerifiedAt: null,
      updatedAt: new Date().toISOString() 
    })
    .ilike('email', oldEmail || '');

  if (dbError) throw new Error('Failed to update account record.');

  // b. Update Supabase Auth email and clear pending metadata
  const { error: authError } = await supabase.auth.admin.updateUserById(targetAuthUser.id, {
    email: pendingData.newEmail,
    email_confirm: true, // required by supabase to confirm the new email change
    app_metadata: { 
      ...targetAuthUser.app_metadata, 
      emailVerified: false,
      emailVerifiedAt: null,
      pendingEmailChange: null 
    }
  });

  if (authError) {
    console.error('Failed to update Supabase Auth email, rolling back database email update:', authError);
    // Rollback DB update
    const { error: rollbackError } = await supabase
      .from('users')
      .update({ 
        email: oldEmail, 
        updatedAt: new Date().toISOString() 
      })
      .ilike('email', pendingData.newEmail);

    if (rollbackError) {
      console.error('CRITICAL: Rollback of database email update failed!', rollbackError);
    }

    throw new Error('Failed to finalize email update in auth system.');
  }

  return { email: pendingData.newEmail };
}

/**
 * Requests an account email verification link.
 * Sent when user signs up or requests verification from their Dashboard.
 */
export async function requestAccountVerificationEmail(userId: string, customAppUrl?: string) {
  return { 
    success: true, 
    message: 'Account verification is not required.',
    alreadyVerified: true
  };
}

export async function confirmAccountEmailVerification(token: string) {
  return {
    success: true,
    message: 'Account active.',
  };
}

/**
 * Handles forgot password request:
 * 1. Normalize email.
 * 2. Query Aamarva `users` table.
 * 3. If user DOES NOT exist: return generic success message without sending email or creating tokens (prevents account enumeration).
 * 4. If user DOES exist:
 *    - Invalidate any previous active reset tokens for this user in `password_reset_tokens`.
 *    - Generate secure random token.
 *    - Hash token using SHA-256.
 *    - Store in `password_reset_tokens` table in Supabase PostgreSQL (no in-memory fallback).
 *    - Send password reset email.
 *    - Return generic success message.
 */
export async function requestForgotPassword(email: string, appUrl: string) {
  const genericMessage = "If an account exists for this email, password reset instructions have been sent.";

  if (!email || typeof email !== 'string') {
    return { success: true, message: genericMessage };
  }

  const normalizedEmail = normalizeEmail(email);
  if (!validateEmailFormat(normalizedEmail)) {
    return { success: true, message: genericMessage };
  }

  const supabase = getSupabaseClient();
  const user = await findUserByEmail(supabase, normalizedEmail);

  if (!user) {
    // Return generic message without revealing that the user does not exist
    return { success: true, message: genericMessage };
  }

  // User EXISTS.
  const rawToken = crypto.randomBytes(32).toString('hex');
  const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
  const expiresAt = new Date(Date.now() + 30 * 60 * 1000).toISOString(); // 30 minutes
  const tokenId = crypto.randomUUID();
  const nowIso = new Date().toISOString();

  // 1. Clean up stale tokens AND invalidate existing active reset tokens concurrently
  await Promise.all([
    Promise.resolve(
      supabase
        .from('password_reset_tokens')
        .delete()
        .or(`usedAt.not.is.null,expiresAt.lt.${nowIso}`)
    ).catch(() => {}),
    Promise.resolve(
      supabase
        .from('password_reset_tokens')
        .update({ usedAt: nowIso })
        .eq('userId', user.id)
        .is('usedAt', null)
    ).catch((err: any) => {
      console.error('[DIAGNOSTIC_LOG] [AUTH_SERVICE] ❌ Failed to invalidate previous reset tokens:', err?.message || err);
    }),
  ]);

  // 2. Store new reset token record in password_reset_tokens table
  try {
    const { error: insertErr } = await supabase
      .from('password_reset_tokens')
      .insert({
        id: tokenId,
        userId: user.id,
        tokenHash,
        expiresAt,
        usedAt: null,
        createdAt: nowIso
      });

    if (insertErr) {
      console.error('[DIAGNOSTIC_LOG] [AUTH_SERVICE] ❌ Failed to store password reset token in Supabase:', insertErr.message || insertErr);
      return { success: true, message: genericMessage };
    }
  } catch (err: any) {
    console.error('[DIAGNOSTIC_LOG] [AUTH_SERVICE] ❌ Exception storing password reset token in Supabase:', err?.message || err);
    return { success: true, message: genericMessage };
  }

  // 3. Send email through Brevo email service using server-side configuration
  const targetAppUrl = appUrl || process.env.APP_URL || config.appUrl || 'https://aamarva.com';
  try {
    await sendPasswordResetEmail(user.email, rawToken, targetAppUrl, user.name);
  } catch (emailErr: any) {
    console.error('[DIAGNOSTIC_LOG] [AUTH_SERVICE] ❌ Failed to dispatch password reset email:', emailErr?.message || emailErr);
    return { success: true, message: genericMessage };
  }

  return { success: true, message: genericMessage };
}

/**
 * Looks up the user corresponding to an active, unexpired, unused reset token.
 * Does not burn the token so that WebAuthn challenge can be completed first.
 */
export async function getResetTokenUser(token: string) {
  if (!token || typeof token !== 'string' || token.trim() === '') {
    throw new Error('Reset token is required.');
  }

  const supabase = getSupabaseClient();
  const tokenHash = crypto.createHash('sha256').update(token.trim()).digest('hex');
  const nowIso = new Date().toISOString();

  const { data: tokenRecord, error: tokenErr } = await supabase
    .from('password_reset_tokens')
    .select('*')
    .eq('tokenHash', tokenHash)
    .is('usedAt', null)
    .gt('expiresAt', nowIso)
    .maybeSingle();

  if (tokenErr || !tokenRecord) {
    throw new Error('Invalid, expired, or already used password reset token.');
  }

  const { data: user, error: userErr } = await supabase
    .from('users')
    .select('*')
    .eq('id', tokenRecord.userId)
    .maybeSingle();

  if (userErr || !user) {
    throw new Error('User associated with reset token not found.');
  }

  return user;
}

/**
 * Resets user password using a raw reset token (strict database persistence, no in-memory fallback):
 */
export async function resetPassword(token: string, newPassword: string) {
  if (!token || typeof token !== 'string' || token.trim() === '') {
    throw new Error('Reset token is required.');
  }

  const passValidation = validatePasswordStrength(newPassword);
  if (!passValidation.valid) {
    throw new Error(passValidation.message || 'Invalid password.');
  }

  const supabase = getSupabaseClient();
  const tokenHash = crypto.createHash('sha256').update(token.trim()).digest('hex');
  const nowIso = new Date().toISOString();

  // Atomically claim the token: update usedAt = nowIso only if usedAt is null and expiresAt > now
  let tokenData: any = null;
  try {
    const { data: updatedTokens, error: claimErr } = await supabase
      .from('password_reset_tokens')
      .update({ usedAt: nowIso })
      .eq('tokenHash', tokenHash)
      .is('usedAt', null)
      .gt('expiresAt', nowIso)
      .select('*');

    if (claimErr) {
      console.warn('⚠️ Error claiming password reset token in Supabase:', claimErr.message || claimErr);
    } else if (updatedTokens && updatedTokens.length > 0) {
      tokenData = updatedTokens[0];
    }
  } catch (err: any) {
    console.warn('⚠️ Exception claiming password reset token in Supabase:', err?.message || err);
  }

  if (!tokenData) {
    throw new Error('Invalid, expired, or already used password reset token.');
  }

  // Fetch user from Aamarva users table
  const { data: user, error: userErr } = await supabase
    .from('users')
    .select('*')
    .eq('id', tokenData.userId)
    .maybeSingle();

  if (userErr || !user) {
    throw new Error('Database error finding user account.');
  }

  const newPasswordHash = await hashPassword(newPassword);

  // Update user password and updatedAt
  const { error: updateError } = await supabase
    .from('users')
    .update({ passwordHash: newPasswordHash, updatedAt: new Date().toISOString() })
    .eq('id', user.id);

  if (updateError) {
    throw new Error('Failed to update password.');
  }

  // After the password update succeeds, invalidate all existing human sessions
  await invalidateAllHumanSessionsForUser(user.id);

  // Update password in Secret Preserver and revoke old sessions
  enrollAutoSecret(user.id, 'password', newPassword).catch(() => {});
  revokeAllAutoSessions(user.id).catch(() => {});

  // Also update password in Supabase Auth if auth user exists
  try {
    const authUser = await getAuthUserForRecord(supabase, user);
    if (authUser?.id && supabase.auth?.admin?.updateUserById) {
      await supabase.auth.admin.updateUserById(authUser.id, { password: newPassword });
    }
  } catch (authErr) {
    console.warn('Non-fatal: failed to update password in Supabase auth admin:', authErr);
  }

  return { message: 'Password has been successfully reset.' };
}




