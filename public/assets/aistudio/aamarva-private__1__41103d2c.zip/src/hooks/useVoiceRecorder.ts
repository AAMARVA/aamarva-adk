import { useState, useRef, useEffect, useCallback } from 'react';

export type VoiceRecordingState = 'idle' | 'recording' | 'preview';
export type MicrophonePermissionState = 'granted' | 'denied' | 'prompt' | 'unknown';

export interface UseVoiceRecorderReturn {
  state: VoiceRecordingState;
  duration: number;
  audioBlob: Blob | null;
  audioUrl: string | null;
  mimeType: string;
  error: string | null;
  permissionState: MicrophonePermissionState;
  startRecording: () => Promise<boolean>;
  stopRecording: () => void;
  cancelRecording: () => void;
  clearRecording: () => void;
}

const PREFERRED_MIME_TYPES = [
  'audio/webm;codecs=opus',
  'audio/webm',
  'audio/mp4',
  'audio/ogg;codecs=opus',
  'audio/ogg'
];

export function getCleanAudioMimeType(mimeType: string): string {
  if (!mimeType) return 'audio/webm';
  const base = mimeType.split(';')[0].trim().toLowerCase();
  if (base.startsWith('audio/')) return base;
  return 'audio/webm';
}

export function getSupportedAudioMimeType(): string {
  if (typeof window === 'undefined' || typeof MediaRecorder === 'undefined') {
    return '';
  }
  for (const type of PREFERRED_MIME_TYPES) {
    try {
      if (typeof MediaRecorder.isTypeSupported === 'function' && MediaRecorder.isTypeSupported(type)) {
        return type;
      }
    } catch {}
  }
  return '';
}

export async function queryMicrophonePermission(): Promise<MicrophonePermissionState> {
  if (typeof navigator === 'undefined' || !navigator.permissions?.query) {
    return 'unknown';
  }
  try {
    const status = await navigator.permissions.query({ name: 'microphone' as PermissionName });
    return status.state as MicrophonePermissionState;
  } catch {
    return 'unknown';
  }
}

export function useVoiceRecorder(): UseVoiceRecorderReturn {
  const [state, setState] = useState<VoiceRecordingState>('idle');
  const [duration, setDuration] = useState(0);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [mimeType, setMimeType] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [permissionState, setPermissionState] = useState<MicrophonePermissionState>('unknown');

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerIntervalRef = useRef<any>(null);
  const durationRef = useRef(0);
  const isMountedRef = useRef(true);

  // Sync and listen to Chrome permission changes in real time
  useEffect(() => {
    isMountedRef.current = true;
    let permObj: PermissionStatus | null = null;

    const setupPermissionListener = async () => {
      try {
        if (typeof navigator !== 'undefined' && navigator.permissions?.query) {
          permObj = await navigator.permissions.query({ name: 'microphone' as PermissionName });
          if (!isMountedRef.current) return;

          setPermissionState(permObj.state as MicrophonePermissionState);

          permObj.onchange = () => {
            if (!isMountedRef.current || !permObj) return;
            const newState = permObj.state as MicrophonePermissionState;
            setPermissionState(newState);

            // If the user just enabled microphone permission in Chrome site settings popup,
            // immediately clear any stale permission denial error banner!
            if (newState === 'granted') {
              setError((prev) => {
                if (prev && (prev.includes('permission') || prev.includes('blocked') || prev.includes('denied'))) {
                  return null;
                }
                return prev;
              });
            }
          };
        }
      } catch {
        // Permissions API not supported or microphone query not implemented
      }
    };

    setupPermissionListener();

    return () => {
      isMountedRef.current = false;
      if (permObj) {
        permObj.onchange = null;
      }
    };
  }, []);

  const cleanupStream = useCallback(() => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => {
        try {
          track.stop();
        } catch {}
      });
      mediaStreamRef.current = null;
    }
  }, []);

  const activeUrlRef = useRef<string | null>(null);

  const clearTimer = useCallback(() => {
    if (timerIntervalRef.current) {
      clearInterval(timerIntervalRef.current);
      timerIntervalRef.current = null;
    }
  }, []);

  const clearRecording = useCallback(() => {
    clearTimer();
    cleanupStream();
    if (activeUrlRef.current) {
      try {
        URL.revokeObjectURL(activeUrlRef.current);
      } catch {}
      activeUrlRef.current = null;
    }
    audioChunksRef.current = [];
    mediaRecorderRef.current = null;
    durationRef.current = 0;
    setDuration(0);
    setAudioBlob(null);
    setAudioUrl(null);
    setError(null);
    setState('idle');
  }, [cleanupStream, clearTimer]);

  useEffect(() => {
    isMountedRef.current = true;
    return () => {
      isMountedRef.current = false;
      clearTimer();
      cleanupStream();
      if (activeUrlRef.current) {
        try {
          URL.revokeObjectURL(activeUrlRef.current);
        } catch {}
        activeUrlRef.current = null;
      }
    };
  }, [cleanupStream, clearTimer]);

  const startRecording = useCallback(async (): Promise<boolean> => {
    setError(null);
    clearRecording();

    if (typeof window === 'undefined') {
      setError('Audio recording is only supported in browser environments.');
      return false;
    }

    if (!navigator?.mediaDevices?.getUserMedia) {
      setError('Audio recording is not supported in this browser (getUserMedia not available).');
      return false;
    }

    if (typeof MediaRecorder === 'undefined') {
      setError('MediaRecorder is not supported in this browser.');
      return false;
    }

    // Step 1: Check hardware presence if enumerateDevices is supported
    let hasAudioInput = true;
    try {
      if (navigator.mediaDevices.enumerateDevices) {
        const devices = await navigator.mediaDevices.enumerateDevices();
        const audioInputs = devices.filter((d) => d.kind === 'audioinput');
        // Only flag no device if enumerateDevices returns non-empty list and zero audio inputs
        if (devices.length > 0 && audioInputs.length === 0) {
          hasAudioInput = false;
        }
      }
    } catch {}

    if (!hasAudioInput) {
      setError('No microphone detected. Please connect or enable an audio input device.');
      return false;
    }

    // Step 2: Acquire microphone stream with progressive constraints fallback
    let stream: MediaStream | null = null;
    let captureError: any = null;

    // Constraint tier 1: Standard high-quality voice processing
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });
    } catch (tier1Err: any) {
      captureError = tier1Err;
      console.warn('Voice constraints tier 1 failed, trying fallback { audio: true }:', tier1Err?.name, tier1Err?.message);
    }

    // Constraint tier 2: Bare { audio: true } fallback (vital for ChromeOS, Linux, virtual sinks, and specialized headsets)
    if (!stream) {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        captureError = null;
      } catch (tier2Err: any) {
        captureError = tier2Err;
        console.warn('Bare audio fallback failed:', tier2Err?.name, tier2Err?.message);
      }
    }

    // If stream acquisition failed, provide diagnostic classification
    if (!stream) {
      cleanupStream();
      clearTimer();

      const currentPerm = await queryMicrophonePermission();
      setPermissionState(currentPerm);

      const errName = captureError?.name || '';
      const errMsg = captureError?.message || '';

      if (errName === 'NotAllowedError' || errName === 'PermissionDeniedError') {
        if (currentPerm === 'granted') {
          // Site permission IS enabled in Chrome, but browser/OS rejected access!
          // This happens when OS Privacy Settings (ChromeOS Privacy Hub, Windows Microphone Privacy, or macOS Security) block audio,
          // or a hardware mute switch is active, or Chrome master toggle is off.
          setError(
            'Microphone is allowed in Chrome site settings, but access was blocked by your operating system, system privacy settings, or hardware mute switch. Please ensure your microphone is unmuted in system settings.'
          );
        } else if (currentPerm === 'denied') {
          setError('Microphone access is blocked in Chrome site settings. Click the tune/lock icon in the address bar to allow microphone access.');
        } else {
          setError('Microphone access was dismissed or not granted. Please allow microphone access when prompted.');
        }
      } else if (errName === 'NotFoundError' || errName === 'DevicesNotFoundError') {
        setError('No microphone found. Please connect an audio input device.');
      } else if (errName === 'NotReadableError' || errName === 'TrackStartError') {
        setError('Microphone is busy or in use by another application. Please close other audio applications and retry.');
      } else if (errName === 'OverconstrainedError') {
        setError('Requested audio settings are not supported by your microphone hardware.');
      } else if (errName === 'SecurityError') {
        setError('Microphone access is blocked by browser security policy.');
      } else if (errName === 'AbortError') {
        setError('Microphone access was interrupted or aborted. Please retry.');
      } else {
        setError(errMsg || 'Failed to access microphone. Please retry.');
      }

      setState('idle');
      return false;
    }

    // Step 3: Verify active audio track exists and is enabled
    const audioTracks = stream.getAudioTracks();
    if (!audioTracks || audioTracks.length === 0) {
      cleanupStream();
      clearTimer();
      setError('Microphone stream acquired, but no active audio track was returned.');
      setState('idle');
      return false;
    }

    const audioTrack = audioTracks[0];
    if (!audioTrack.enabled) {
      audioTrack.enabled = true;
    }

    if (audioTrack.readyState === 'ended') {
      cleanupStream();
      clearTimer();
      setError('Microphone audio track ended immediately. Please check your audio input device.');
      setState('idle');
      return false;
    }

    // Check if the track is hardware or OS muted
    if (audioTrack.muted) {
      console.warn('Audio track is currently muted at the hardware or OS level.');
    }

    audioTrack.onended = () => {
      console.warn('Microphone audio track ended unexpectedly during recording.');
      if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
        try {
          mediaRecorderRef.current.stop();
        } catch {}
      }
    };

    mediaStreamRef.current = stream;
    audioChunksRef.current = [];

    // Step 4: Initialize MediaRecorder with dynamic MIME type negotiation and fallbacks
    const candidateTypes = [
      getSupportedAudioMimeType(),
      'audio/webm;codecs=opus',
      'audio/webm',
      'audio/mp4',
      'audio/ogg;codecs=opus',
      'audio/ogg',
      ''
    ].filter((t, i, arr) => arr.indexOf(t) === i);

    let recorder: MediaRecorder | null = null;
    let chosenMime = '';

    for (const mime of candidateTypes) {
      try {
        if (!mime) {
          recorder = new MediaRecorder(stream);
          chosenMime = recorder.mimeType || 'audio/webm';
        } else if (typeof MediaRecorder.isTypeSupported === 'function' && MediaRecorder.isTypeSupported(mime)) {
          recorder = new MediaRecorder(stream, { mimeType: mime });
          chosenMime = recorder.mimeType || mime;
        }
        if (recorder) break;
      } catch (mimeErr) {
        console.warn(`MediaRecorder rejected MIME "${mime}":`, mimeErr);
      }
    }

    if (!recorder) {
      try {
        recorder = new MediaRecorder(stream);
        chosenMime = recorder.mimeType || 'audio/webm';
      } catch (recInitErr: any) {
        cleanupStream();
        clearTimer();
        setError(`Recording initialization failed: ${recInitErr?.message || 'MediaRecorder unsupported'}`);
        setState('idle');
        return false;
      }
    }

    mediaRecorderRef.current = recorder;
    const initialMime = recorder.mimeType || chosenMime || 'audio/webm';
    const cleanInitialMime = getCleanAudioMimeType(initialMime);
    setMimeType(cleanInitialMime);

    recorder.ondataavailable = (event: BlobEvent) => {
      if (event.data && event.data.size > 0) {
        audioChunksRef.current.push(event.data);
      }
    };

    recorder.onerror = (event: any) => {
      console.error('MediaRecorder error event:', event);
      setError('An error occurred during audio recording.');
      cleanupStream();
      clearTimer();
      setState('idle');
    };

    recorder.onstop = () => {
      clearTimer();
      cleanupStream();

      const validChunks = audioChunksRef.current.filter((c) => c && c.size > 0);
      if (validChunks.length === 0) {
        setError('No audio data was captured during recording.');
        setState('idle');
        return;
      }

      const rawMime = recorder?.mimeType || initialMime || 'audio/webm';
      const cleanMime = getCleanAudioMimeType(rawMime);
      const finalBlob = new Blob(validChunks, { type: cleanMime });

      if (finalBlob.size === 0) {
        setError('Recorded audio was empty. Please check your microphone input volume.');
        setState('idle');
        return;
      }

      const url = URL.createObjectURL(finalBlob);
      if (activeUrlRef.current && activeUrlRef.current !== url) {
        try {
          URL.revokeObjectURL(activeUrlRef.current);
        } catch {}
      }
      activeUrlRef.current = url;

      if (isMountedRef.current) {
        setAudioBlob(finalBlob);
        setAudioUrl(url);
        setMimeType(cleanMime);
        setDuration(durationRef.current);
        setState('preview');
      }
    };

    // Step 5: Start recording successfully
    try {
      recorder.start();
    } catch (startErr: any) {
      cleanupStream();
      clearTimer();
      setError(`Failed to start recording: ${startErr?.message || 'Recording start failed'}`);
      setState('idle');
      return false;
    }

    durationRef.current = 0;
    setDuration(0);
    setState('recording');

    // Start 1-second interval ticker for duration
    timerIntervalRef.current = setInterval(() => {
      durationRef.current += 1;
      setDuration(durationRef.current);
    }, 1000);

    return true;
  }, [cleanupStream, clearTimer, clearRecording]);

  const stopRecording = useCallback(() => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      try {
        // W3C MediaStream Recording specification:
        // Calling stop() automatically flushes all remaining unrecorded data to ondataavailable
        // before firing onstop. Calling requestData() right before stop() creates fragmented/empty
        // chunks that corrupt WebM container headers in Chrome.
        mediaRecorderRef.current.stop();
      } catch (err) {
        console.error('Error stopping MediaRecorder:', err);
      }
    }
  }, []);

  const cancelRecording = useCallback(() => {
    clearTimer();
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      // Discard recorded chunks so onstop does not produce preview
      audioChunksRef.current = [];
      try {
        mediaRecorderRef.current.stop();
      } catch {}
    }
    cleanupStream();
    if (audioUrl) {
      URL.revokeObjectURL(audioUrl);
    }
    audioChunksRef.current = [];
    mediaRecorderRef.current = null;
    durationRef.current = 0;
    setDuration(0);
    setAudioBlob(null);
    setAudioUrl(null);
    setError(null);
    setState('idle');
  }, [audioUrl, cleanupStream, clearTimer]);

  return {
    state,
    duration,
    audioBlob,
    audioUrl,
    mimeType,
    error,
    permissionState,
    startRecording,
    stopRecording,
    cancelRecording,
    clearRecording,
  };
}
