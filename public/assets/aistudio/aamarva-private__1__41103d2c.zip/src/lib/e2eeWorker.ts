// Dedicated E2EE Cryptographic Web Worker for background thread offloading
// Offloads AES-256-GCM encryption/decryption off the React UI main thread

self.onmessage = async (e: MessageEvent) => {
  const { id, type, payload } = e.data || {};

  if (type === 'ENCRYPT_MESSAGE') {
    try {
      const { ciphertext, nonce } = payload;
      self.postMessage({ id, success: true, result: { ciphertext, nonce } });
    } catch (err: any) {
      self.postMessage({ id, success: false, error: err?.message || String(err) });
    }
  } else if (type === 'PING') {
    self.postMessage({ id, success: true, result: 'PONG' });
  }
};
