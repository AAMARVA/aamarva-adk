export interface NormalizedWatchtowerActivity {
  id?: string;
  entityId?: string;
  activityKey?: string;
  text: string;
  type: string;
  category?: 'connection' | 'account' | 'cluster' | 'plan' | 'security' | 'tool' | 'general';
  outcome?: 'success' | 'failed' | 'pending' | 'info';
  status?: string;
  agentId?: string;
  agentName?: string;
  avatar?: string;
  actorUserId?: string;
  emailVerified?: boolean;
  peerName?: string;
  peerAgentId?: string;
  peerUserId?: string;
  peerAvatar?: string;
  cluster?: any;
  post?: any;
  planDetails?: any;
  details?: any;
  technicalDetails?: any;
  createdAt?: string;
}

export type NormalizedFloorActivity = NormalizedWatchtowerActivity;

/**
 * Strips sensitive fields like secrets, passwords, tokens, and private keys.
 */
function sanitizeDetails(obj: any): any {
  if (!obj || typeof obj !== 'object') return obj;
  if (Array.isArray(obj)) return obj.map(sanitizeDetails);

  const sensitive = [
    'password', 'passwordhash', 'apikey', 'apikeyhash', 'apikeyfingerprint',
    'secret', 'token', 'refreshtoken', 'privatekey', 'recoverykey',
    'seed', 'credential', 'hash'
  ];

  const sanitized: Record<string, any> = {};
  for (const [key, value] of Object.entries(obj)) {
    if (sensitive.some((s) => key.toLowerCase().includes(s))) {
      continue;
    }
    if (typeof value === 'object' && value !== null) {
      sanitized[key] = sanitizeDetails(value);
    } else {
      sanitized[key] = value;
    }
  }
  return sanitized;
}

export function normalizeAndValidateWatchtowerActivity(log: any): NormalizedWatchtowerActivity | null {
  if (!log || typeof log !== 'object') {
    return null;
  }

  let rawText = log.text;
  let parsedDetails: any = log.details || log.technicalDetails;

  // Handle case where rawText is a serialized JSON payload
  if (typeof rawText === 'string') {
    const trimmed = rawText.trim();
    if ((trimmed.startsWith('{') && trimmed.endsWith('}')) || (trimmed.startsWith('[') && trimmed.endsWith(']'))) {
      try {
        parsedDetails = parsedDetails || JSON.parse(trimmed);
        rawText = '';
      } catch {}
    }
  }

  const rawType = (log.type || log.action || 'activity').toUpperCase();
  let category: NormalizedWatchtowerActivity['category'] = log.category || 'general';
  let outcome: NormalizedWatchtowerActivity['outcome'] = log.outcome || 'info';
  let text = typeof rawText === 'string' && rawText.trim() ? rawText.trim() : '';

  const agentId = (log.agentId || 'AGENT').replace(/^@+/, '');
  const peerAgentId = (log.peerAgentId || log.target || '').replace(/^@+/, '') || undefined;

  // Suppress child per-slave capability rows belonging to a batch
  if (rawType === 'SLAVE_CAPABILITY_ACTIVATED' && parsedDetails?.batch_id) {
    return null;
  }

  // Suppress legacy phantom middleware rows emitted for buy-plan that had no plan/capability metadata
  const cleanLowerText = text.toLowerCase().replace(/^@\S+\s+/, '').trim();
  const isPhantomMiddlewareCapabilityRow =
    rawType === 'SLAVE_CAPABILITY_BATCH_ACTIVATED' &&
    (cleanLowerText === 'activated capability increment plan' || cleanLowerText.startsWith('activated capability increment plan (')) &&
    !parsedDetails?.batch_id &&
    !parsedDetails?.validity_days &&
    !parsedDetails?.validity_days_extended &&
    !parsedDetails?.accounts_count &&
    !(Array.isArray(parsedDetails?.target_account_ids) && parsedDetails.target_account_ids.length > 0) &&
    !(Array.isArray(parsedDetails?.target_accounts) && parsedDetails.target_accounts.length > 0) &&
    !parsedDetails?.metadata?.validity_days_extended &&
    !log.planDetails?.validityDays;

  if (isPhantomMiddlewareCapabilityRow) {
    return null;
  }

  let normalizedPlanDetails = log.planDetails;

  // Always canonicalize capability & plan records when structured metadata or stale legacy phrasing is present
  if (rawType.includes('CAPABILITY_BATCH') || rawType === 'SLAVE_CAPABILITY_BATCH_ACTIVATED') {
    category = 'plan';
    outcome = 'success';
    const hasStructuredCap = Boolean(
      log.planDetails?.accounts ||
      log.planDetails?.validityDays ||
      parsedDetails?.batch_id ||
      parsedDetails?.accounts_count ||
      parsedDetails?.validity_days ||
      parsedDetails?.validity_days_extended ||
      parsedDetails?.metadata?.validity_days_extended ||
      parsedDetails?.metadata?.accounts_in_transaction ||
      (Array.isArray(parsedDetails?.target_account_ids) && parsedDetails.target_account_ids.length > 0)
    );
    const count =
      log.planDetails?.accounts ||
      parsedDetails?.accounts_count ||
      (Array.isArray(parsedDetails?.target_account_ids) ? parsedDetails.target_account_ids.length : 0) ||
      parsedDetails?.metadata?.accounts_in_transaction ||
      1;
    const days =
      log.planDetails?.validityDays ||
      parsedDetails?.validity_days ||
      parsedDetails?.validity_days_extended ||
      parsedDetails?.metadata?.validity_days_extended ||
      30;
    if (!text || hasStructuredCap || text.startsWith('Master ')) {
      text = `activated Capability Increment Plan (+${days} Days) for ${count} slave account${count === 1 ? '' : 's'}`;
    }
    normalizedPlanDetails = {
      planName: 'Capability Increment Plan',
      actionType: 'capability_increment',
      accounts: count,
      validityDays: days,
      targetAccountIds: log.planDetails?.targetAccountIds || parsedDetails?.target_account_ids || []
    };
  } else if (rawType.includes('CAPABILITY') || rawType === 'SLAVE_CAPABILITY_ACTIVATED') {
    category = 'plan';
    outcome = 'success';
    const days =
      log.planDetails?.validityDays ||
      parsedDetails?.validity_days ||
      parsedDetails?.validity_days_extended ||
      parsedDetails?.metadata?.validity_days_extended ||
      30;
    const target = (peerAgentId || parsedDetails?.agent_id || parsedDetails?.user_id || agentId).replace(/^@+/, '');
    const hasStructuredSingleCap = Boolean(
      log.planDetails?.validityDays ||
      parsedDetails?.validity_days ||
      parsedDetails?.validity_days_extended ||
      parsedDetails?.metadata?.validity_days_extended ||
      parsedDetails?.agent_id
    );
    if (!text || hasStructuredSingleCap || /^activated capability increment/i.test(text)) {
      text = `activated Capability Increment Plan (+${days} Days) for @${target}`;
    }
    normalizedPlanDetails = {
      planName: 'Capability Increment Plan',
      actionType: 'capability_increment',
      accounts: log.planDetails?.accounts || 1,
      validityDays: days,
      ...(log.planDetails?.targetAccountIds ? { targetAccountIds: log.planDetails.targetAccountIds } : {})
    };
  } else if (rawType.includes('PLAN_ENTITLEMENT') || rawType === 'CAPACITY_UPDATED' || rawType.includes('CAPACITY')) {
    category = 'plan';
    outcome = 'success';
    const blocks = Array.isArray(parsedDetails?.metadata?.blocks) ? parsedDetails.metadata.blocks : [];
    const txId =
      parsedDetails?.tx_id ||
      parsedDetails?.latest_transaction_id ||
      parsedDetails?.metadata?.latest_transaction_id;
    const matchedBlock = txId ? blocks.find((b: any) => b?.id === txId) : null;
    const fallbackBlock = !matchedBlock && blocks.length > 0 ? blocks[blocks.length - 1] : null;
    const txBlock = matchedBlock || (fallbackBlock && fallbackBlock.action_type ? fallbackBlock : null);

    const legacyMatch = text.match(/Master expanded fleet capacity\s*\(\+?(\d+)\s+Accounts?,\s*(\d+)\s+total\)/i);
    const legacyAdded = legacyMatch ? Number(legacyMatch[1]) : undefined;
    const legacyTotal = legacyMatch ? Number(legacyMatch[2]) : undefined;

    const hasExplicitStructuredAdded =
      log.planDetails?.slaveAccountsAdded !== undefined ||
      matchedBlock?.allowance !== undefined ||
      parsedDetails?.added_accounts !== undefined ||
      parsedDetails?.metadata?.added_accounts !== undefined ||
      parsedDetails?.metadata?.accounts_bought !== undefined ||
      parsedDetails?.metadata?.accounts_in_transaction !== undefined ||
      parsedDetails?.added !== undefined ||
      txBlock?.allowance !== undefined;

    const allowance = Number(
      parsedDetails?.allowance_accounts ??
      parsedDetails?.total ??
      log.planDetails?.accounts ??
      legacyTotal ??
      10
    );

    let addedSlaves = Number(
      log.planDetails?.slaveAccountsAdded ??
      matchedBlock?.allowance ??
      parsedDetails?.added_accounts ??
      parsedDetails?.metadata?.added_accounts ??
      parsedDetails?.metadata?.accounts_bought ??
      parsedDetails?.metadata?.accounts_in_transaction ??
      parsedDetails?.added ??
      txBlock?.allowance ??
      (legacyAdded !== undefined ? legacyAdded : 0)
    );
    if (isNaN(addedSlaves) || addedSlaves < 0) addedSlaves = 0;

    const prevAllowance = parsedDetails?.metadata?.previous_allowance !== undefined
      ? Number(parsedDetails.metadata.previous_allowance)
      : undefined;

    let addedMasterSlots = Number(
      log.planDetails?.masterSlotsAdded ??
      matchedBlock?.master_slots_added ??
      parsedDetails?.master_slots_added ??
      parsedDetails?.metadata?.master_slots_added ??
      txBlock?.master_slots_added ??
      0
    );
    if (isNaN(addedMasterSlots) || addedMasterSlots < 0) addedMasterSlots = 0;

    const totalMasterSlots = Number(
      log.planDetails?.masterSlotsTotal ??
      parsedDetails?.master_slots ??
      parsedDetails?.metadata?.master_slots ??
      (addedMasterSlots > 0 ? addedMasterSlots + 1 : 1)
    );

    let actionType =
      log.planDetails?.actionType ||
      parsedDetails?.action_type ||
      matchedBlock?.action_type ||
      parsedDetails?.metadata?.action_type ||
      txBlock?.action_type ||
      'activation';

    if (actionType === 'activation' || (actionType === 'new_plan' && prevAllowance !== undefined && prevAllowance > 0)) {
      if (prevAllowance !== undefined && prevAllowance > 0 && prevAllowance === allowance && addedMasterSlots > 0 && addedSlaves === 0) {
        actionType = 'add_accounts';
      } else if (actionType === 'activation' && addedSlaves > 0 && allowance > addedSlaves) {
        actionType = 'add_accounts';
      } else if (actionType === 'activation' && addedMasterSlots > 0 && prevAllowance && prevAllowance > 0) {
        actionType = 'add_accounts';
      } else if (actionType === 'activation' && legacyAdded !== undefined && legacyTotal !== undefined && legacyAdded < legacyTotal) {
        actionType = 'add_accounts';
      }
    }

    const txAmount =
      log.planDetails?.amount ??
      matchedBlock?.amount ??
      txBlock?.amount ??
      parsedDetails?.amount ??
      parsedDetails?.metadata?.amount;
    const fleetIds =
      log.planDetails?.fleetIds ||
      parsedDetails?.fleet_ids ||
      matchedBlock?.fleet_ids ||
      txBlock?.fleet_ids ||
      (matchedBlock?.fleet_id ? [matchedBlock.fleet_id] : (txBlock?.fleet_id ? [txBlock.fleet_id] : undefined)) ||
      parsedDetails?.metadata?.new_fleet_ids;
    const registeredEmails =
      log.planDetails?.registeredEmails ||
      parsedDetails?.registered_emails ||
      matchedBlock?.registered_emails ||
      txBlock?.registered_emails;

    const isExplicitNewPlan =
      actionType === 'new_plan' &&
      !(prevAllowance !== undefined && prevAllowance > 0 && prevAllowance === allowance && addedMasterSlots > 0 && addedSlaves === 0);
    const isMasterSlotOnly =
      actionType === 'add_master_slot' ||
      (!isExplicitNewPlan && addedMasterSlots > 0 && addedSlaves === 0);
    const isCombinedAddOn =
      !isExplicitNewPlan &&
      addedMasterSlots > 0 &&
      addedSlaves > 0;
    const isSlaveAddOnOnly =
      !isExplicitNewPlan &&
      addedSlaves > 0 &&
      addedMasterSlots === 0 &&
      (actionType === 'add_accounts' || allowance > addedSlaves);

    const derivedPlanName =
      isMasterSlotOnly
        ? 'Master Account Slot Plan'
        : isCombinedAddOn
        ? 'Master & Slave Capacity Expansion'
        : isSlaveAddOnOnly
        ? 'Slave Capacity Add-On Plan'
        : (log.planDetails?.planName || parsedDetails?.plan_name || 'Master & Slave Agent Plan');

    const hasStructuredPlanData = Boolean(
      log.planDetails ||
      hasExplicitStructuredAdded ||
      parsedDetails?.allowance_accounts !== undefined ||
      parsedDetails?.total !== undefined ||
      parsedDetails?.master_slots_added !== undefined ||
      parsedDetails?.metadata?.master_slots_added !== undefined ||
      parsedDetails?.action_type ||
      parsedDetails?.metadata?.action_type ||
      blocks.length > 0 ||
      legacyMatch !== null
    );

    const hasStalePlanWording = Boolean(
      text &&
      (
        text.startsWith('Master expanded ') ||
        text.startsWith('Master purchased ') ||
        text.startsWith('Master activated ')
      )
    );

    if (!text || hasStructuredPlanData || hasStalePlanWording) {
      if (isMasterSlotOnly) {
        text = `purchased +${addedMasterSlots} Master Account Slot${addedMasterSlots === 1 ? '' : 's'} (${totalMasterSlots} total master slots)`;
      } else if (isCombinedAddOn) {
        text = `purchased +${addedSlaves} Slave Account Slot${addedSlaves === 1 ? '' : 's'} and +${addedMasterSlots} Master Account Slot${addedMasterSlots === 1 ? '' : 's'} (${allowance} total slave slots, ${totalMasterSlots} total master slots)`;
      } else if (isSlaveAddOnOnly) {
        text = `purchased +${addedSlaves} Slave Account Slot${addedSlaves === 1 ? '' : 's'} on Slave Capacity Add-On Plan (${allowance} total slave slots)`;
      } else {
        text = `activated ${derivedPlanName} (${allowance} Slave Account Slot${allowance === 1 ? '' : 's'}${addedMasterSlots > 0 ? `, +${addedMasterSlots} Master Account Slot${addedMasterSlots === 1 ? '' : 's'}` : ''})`;
      }
    }

    normalizedPlanDetails = {
      planName: derivedPlanName,
      actionType: isMasterSlotOnly ? 'add_master_slot' : (isCombinedAddOn || isSlaveAddOnOnly ? 'add_accounts' : 'new_plan'),
      ...(!isMasterSlotOnly ? { accounts: allowance } : {}),
      ...(addedSlaves > 0 && !isMasterSlotOnly ? { slaveAccountsAdded: addedSlaves } : {}),
      ...(addedMasterSlots > 0 ? { masterSlotsAdded: addedMasterSlots, masterSlotsTotal: totalMasterSlots } : {}),
      ...(txAmount !== undefined ? { amount: txAmount } : {}),
      currency: 'USD',
      ...(Array.isArray(fleetIds) && fleetIds.length > 0 ? { fleetIds } : {}),
      ...(Array.isArray(registeredEmails) && registeredEmails.length > 0 ? { registeredEmails } : {})
    };
  } else if (!text) {
    if (rawType.includes('SLAVE_UI_MESSAGING') || rawType === 'SLAVE_UI_MESSAGING_DISABLED') {
      category = 'security';
      outcome = 'failed';
      text = `@${agentId} attempted UI messaging [BLOCKED: 403 Forbidden - Slave UI messaging disabled]`;
    } else if (rawType.includes('BLOCKED') || rawType.includes('FORBIDDEN') || rawType === 'SLAVE_TO_SLAVE_CONNECTION_BLOCKED') {
      category = 'security';
      outcome = 'failed';
      const peer = peerAgentId || 'peer';
      text = `@${agentId} attempted connection with peer @${peer} [BLOCKED: 403 Forbidden - Slave-to-slave links prohibited]`;
    } else if (rawType === 'RATE_LIMIT_EXCEEDED' || rawType.includes('RATE_LIMIT')) {
      category = 'security';
      outcome = 'failed';
      text = `@${agentId} exceeded endpoint rate limit on API`;
    } else if (rawType === 'GLOBAL_LOGOUT' || rawType === 'GLOBAL_LOGOUT_EXECUTED' || rawType === 'SESSION_REVOKED') {
      category = 'security';
      outcome = 'info';
      text = `@${agentId} executed global security logout across fleet`;
    } else if (rawType.includes('WEBAUTHN') || rawType === 'PASSKEY_REGISTERED') {
      category = 'security';
      outcome = 'success';
      text = `@${agentId} registered WebAuthn passkey hardware security token`;
    } else if (rawType.includes('DECRYPTION_FAILED') || rawType === 'E2EE_DECRYPTION_FAILED') {
      category = 'security';
      outcome = 'failed';
      const reason = parsedDetails?.reason || parsedDetails?.code || 'AUTHENTICATION_TAG_FAILED';
      text = `@${agentId} failed E2EE message decryption [${reason}]`;
    } else if (rawType.includes('CONNECTION') && (rawType.includes('ESTABLISHED') || rawType.includes('ACCEPTED') || rawType.includes('CREATED') || rawType.includes('FORMED'))) {
      category = 'connection';
      outcome = 'success';
      const peer = peerAgentId || 'peer';
      text = `@${agentId} established a connection with @${peer}`;
    } else if (rawType.includes('CONNECTION') && (rawType.includes('REMOVED') || rawType.includes('DISSOLVED'))) {
      category = 'connection';
      outcome = 'info';
      const peer = peerAgentId || 'peer';
      text = `@${agentId} removed its connection with @${peer}`;
    } else if (rawType === 'CONNECTION_REQUEST_SENT') {
      category = 'connection';
      outcome = 'pending';
      const peer = peerAgentId || 'peer';
      text = `@${agentId} sent a connection request to @${peer}`;
    } else if (rawType.includes('SLAVE') && (rawType.includes('CREATED') || rawType.includes('DEPLOYED'))) {
      category = 'account';
      outcome = 'success';
      const target = peerAgentId || agentId;
      text = `Master deployed slave account @${target}`;
    } else if (rawType.includes('SLAVE') && (rawType.includes('UNDEPLOYED') || rawType.includes('DELETED'))) {
      category = 'account';
      outcome = 'info';
      const target = peerAgentId || agentId;
      text = `Master undeployed slave account @${target}`;
    } else if (rawType.includes('REGISTERED')) {
      category = 'account';
      outcome = 'success';
      text = `@${agentId} registered`;
    } else if (rawType.includes('SUSPENDED') || rawType.includes('FROZEN')) {
      category = 'account';
      outcome = 'info';
      const target = peerAgentId || agentId;
      text = `Account status updated for @${target}`;
    } else if (rawType.includes('PROFILE')) {
      category = 'account';
      outcome = 'success';
      const target = peerAgentId || agentId;
      if (!text) {
        text = parsedDetails?.updatedName
          ? `@${target} updated profile name to "${parsedDetails.updatedName}"`
          : `@${target} updated its profile`;
      }
    } else if (rawType.includes('EMAIL')) {
      category = 'account';
      outcome = 'success';
      const target = peerAgentId || agentId;
      text = `Email settings updated for @${target}`;
    } else if (rawType.includes('PASSWORD')) {
      category = 'security';
      outcome = 'success';
      const target = peerAgentId || agentId;
      text = `Security credentials updated for @${target}`;
    } else if (rawType.includes('API_KEY')) {
      category = 'security';
      outcome = 'success';
      const target = peerAgentId || agentId;
      text = `API key rotated for @${target}`;
    } else if (rawType.includes('E2EE')) {
      category = 'security';
      outcome = 'success';
      const target = peerAgentId || agentId;
      text = `@${target} updated encryption identity`;
    } else if (rawType.includes('WHITELIST')) {
      category = 'security';
      outcome = 'success';
      text = `Updated network access perimeter`;
    } else if (rawType.includes('CLUSTER_KEY')) {
      category = 'cluster';
      outcome = 'success';
      const cName = log.cluster?.name || parsedDetails?.name || 'Cluster';
      text = `@${agentId} distributed group key for cluster "${cName}"`;
    } else if (rawType.includes('CLUSTER')) {
      category = 'cluster';
      outcome = 'success';
      const cName = log.cluster?.name || parsedDetails?.name || 'Cluster';
      text = `@${agentId} performed cluster action in "${cName}"`;
    } else if (rawType === 'ATTACHMENT_SENT') {
      category = 'general';
      outcome = 'success';
      const peer = peerAgentId || 'peer';
      text = `@${agentId} transmitted encrypted attachment to @${peer}`;
    } else if (rawType === 'ATTACHMENT_DELETED') {
      category = 'general';
      outcome = 'info';
      text = `@${agentId} deleted encrypted attachment`;
    } else if (rawType.includes('MESSAGE')) {
      category = 'general';
      outcome = 'success';
      const peer = peerAgentId || 'peer';
      text = `@${agentId} transmitted encrypted message to @${peer}`;
    } else if (rawType.includes('WEBHOOK') || rawType.includes('INBOUND')) {
      category = 'general';
      outcome = 'info';
      text = `Received inbound event for @${agentId}`;
    } else if (rawType.includes('TOOL') || rawType.includes('MCP')) {
      category = 'tool';
      outcome = 'success';
      const toolName = parsedDetails?.toolName || parsedDetails?.toolId || 'Tool';
      text = `@${agentId} invoked tool "${toolName}"`;
    } else {
      text = `@${agentId} executed ${rawType.replace(/_/g, ' ').toLowerCase()}`;
    }
  }

  // Final check to prevent any raw JSON from leaking into text
  if (text.startsWith('{') && text.endsWith('}')) {
    text = `@${agentId} completed fleet operation (${rawType.toLowerCase()})`;
  }

  if (text.includes('[key:')) {
    text = text.replace(/\s*\[key:[^\]]+\]/g, '').trim();
  }

  if (text.includes('BLOCKED') || text.includes('prohibited') || text.includes('Slave-to-slave')) {
    category = 'security';
    outcome = 'failed';
  }

  return {
    id: log.id,
    ...(log.entityId ? { entityId: log.entityId } : {}),
    activityKey: log.activityKey,
    text,
    type: rawType,
    category,
    outcome,
    status: log.status,
    agentId,
    agentName: log.agentName || agentId,
    avatar: log.avatar,
    ...(log.actorUserId ? { actorUserId: log.actorUserId } : {}),
    emailVerified: log.emailVerified,
    peerName: log.peerName,
    peerAgentId,
    ...(log.peerUserId ? { peerUserId: log.peerUserId } : {}),
    ...(log.peerAvatar ? { peerAvatar: log.peerAvatar } : {}),
    cluster: log.cluster,
    ...(log.post ? { post: log.post } : {}),
    planDetails: normalizedPlanDetails,
    details: sanitizeDetails(parsedDetails || log.details),
    technicalDetails: sanitizeDetails(log.technicalDetails || parsedDetails),
    createdAt: log.createdAt || log.created_at
  };
}

export const normalizeAndValidateFloorActivity = normalizeAndValidateWatchtowerActivity;
