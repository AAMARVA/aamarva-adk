import { apiFetch, buildApiUrl, getCurrentSessionAuthType } from '../services/authApi';

export interface SubscribeRealtimeStreamOptions {
  targetAgentId?: string | null;
  authType?: 'human' | 'agent';
  onEvent: (event: any) => void;
  onReconnect?: () => void;
}

interface StreamSubscriber {
  onEvent: (event: any) => void;
  onReconnect?: () => void;
}

interface SharedChannel {
  key: string;
  authType: 'human' | 'agent';
  cleanTarget: string;
  subscribers: Set<StreamSubscriber>;
  es: EventSource | null;
  isOpen: boolean;
  isConnecting: boolean;
  hasConnectedOnce: boolean;
  reconnectTimer: ReturnType<typeof setTimeout> | null;
  idleCloseTimer: ReturnType<typeof setTimeout> | null;
}

const channels = new Map<string, SharedChannel>();

export function isRealtimeStreamConnected(): boolean {
  for (const ch of channels.values()) {
    if (ch.isOpen) return true;
  }
  return false;
}

function connectChannel(ch: SharedChannel): void {
  if (ch.subscribers.size === 0 || ch.isConnecting) return;

  if (ch.es) {
    ch.isOpen = false;
    try {
      ch.es.close();
    } catch {}
    ch.es = null;
  }

  ch.isConnecting = true;

  void (async () => {
    try {
      const ticketRes = await apiFetch('/api/realtime/stream-ticket', {
        method: 'POST',
        authType: ch.authType,
        headers: ch.cleanTarget ? { 'x-target-agent-id': ch.cleanTarget } : undefined,
      }).catch(() => null);

      ch.isConnecting = false;
      if (ch.subscribers.size === 0) return;

      const ticket = ticketRes?.ticket;
      let streamPath: string;
      if (ticket) {
        streamPath = `/api/realtime/stream?ticket=${encodeURIComponent(ticket)}`;
      } else if (ch.authType === 'human') {
        streamPath = ch.cleanTarget
          ? `/api/realtime/stream?agentId=${encodeURIComponent(ch.cleanTarget)}`
          : '/api/realtime/stream';
      } else {
        ch.reconnectTimer = setTimeout(() => connectChannel(ch), 3500);
        return;
      }

      const streamUrl = buildApiUrl(streamPath);
      const source = new EventSource(streamUrl, { withCredentials: true });
      ch.es = source;

      source.onopen = () => {
        if (ch.subscribers.size === 0 || ch.es !== source) {
          try {
            source.close();
          } catch {}
          return;
        }
        ch.isOpen = true;
        if (ch.hasConnectedOnce) {
          for (const sub of Array.from(ch.subscribers)) {
            try {
              sub.onReconnect?.();
            } catch {}
          }
        }
        ch.hasConnectedOnce = true;
      };

      source.onmessage = (evt) => {
        if (ch.subscribers.size === 0 || !evt.data) return;
        try {
          const parsed = JSON.parse(evt.data);
          if (parsed && typeof parsed === 'object') {
            for (const sub of Array.from(ch.subscribers)) {
              try {
                sub.onEvent(parsed);
              } catch {}
            }
          }
        } catch {}
      };

      source.onerror = () => {
        ch.isOpen = false;
        try {
          source.close();
        } catch {}
        if (ch.es === source) {
          ch.es = null;
        }
        if (ch.subscribers.size > 0) {
          if (ch.reconnectTimer) clearTimeout(ch.reconnectTimer);
          ch.reconnectTimer = setTimeout(() => connectChannel(ch), 2000);
        }
      };
    } catch {
      ch.isConnecting = false;
      ch.isOpen = false;
      if (ch.subscribers.size > 0) {
        if (ch.reconnectTimer) clearTimeout(ch.reconnectTimer);
        ch.reconnectTimer = setTimeout(() => connectChannel(ch), 3500);
      }
    }
  })();
}

/**
 * Opens or reuses a multiplexed authenticated Server-Sent Events stream using a
 * short-lived stream ticket per (authType, targetAgentId) channel so multiple UI
 * listeners share a single persistent SSE socket instead of saturating HTTP pool slots.
 */
export function subscribeRealtimeStream(options: SubscribeRealtimeStreamOptions): () => void {
  const { targetAgentId, onEvent, onReconnect } = options;
  const resolvedAuthType: 'human' | 'agent' =
    options.authType || getCurrentSessionAuthType() || 'human';
  const cleanTarget =
    targetAgentId && typeof targetAgentId === 'string' ? targetAgentId.trim() : '';
  const channelKey = `${resolvedAuthType}::${cleanTarget || '__default__'}`;

  let ch = channels.get(channelKey);
  if (!ch) {
    ch = {
      key: channelKey,
      authType: resolvedAuthType,
      cleanTarget,
      subscribers: new Set(),
      es: null,
      isOpen: false,
      isConnecting: false,
      hasConnectedOnce: false,
      reconnectTimer: null,
      idleCloseTimer: null,
    };
    channels.set(channelKey, ch);
  }

  if (ch.idleCloseTimer) {
    clearTimeout(ch.idleCloseTimer);
    ch.idleCloseTimer = null;
  }

  const sub: StreamSubscriber = { onEvent, onReconnect };
  ch.subscribers.add(sub);

  if (!ch.es && !ch.isConnecting) {
    connectChannel(ch);
  }

  return () => {
    const channel = channels.get(channelKey);
    if (!channel) return;
    channel.subscribers.delete(sub);
    if (channel.subscribers.size === 0) {
      if (channel.idleCloseTimer) clearTimeout(channel.idleCloseTimer);
      // Grace period prevents connection churn when switching quickly between chat modals
      channel.idleCloseTimer = setTimeout(() => {
        if (channel.subscribers.size > 0) return;
        channel.isOpen = false;
        if (channel.reconnectTimer) {
          clearTimeout(channel.reconnectTimer);
          channel.reconnectTimer = null;
        }
        if (channel.es) {
          try {
            channel.es.close();
          } catch {}
          channel.es = null;
        }
        channels.delete(channelKey);
      }, 250);
    }
  };
}
