// End-to-End Encryption (E2EE) Module for AAMARVA
// Cryptographic Primitives: ECDH (NIST P-256), HKDF (SHA-256), AES-256-GCM with Authenticated Associated Data (AAD)
// Key Storage: Web Crypto API with Non-Exportable Private Keys (extractable: false) + Persistent IndexedDB Keystore
// Identity Binding: Authenticated ECDSA (NIST P-256) Identity Signatures + Secondary TOFU Pinning Defense-in-Depth
// Zero-Knowledge Architecture: Non-extractable operational keys backed up inside a zero-knowledge encrypted recovery vault containing actual key material.
//   - Operational keys remain non-extractable (extractable: false)
//   - Recovery vault contains the actual E2EE and identity private key material encrypted locally using PBKDF2-SHA-256
//   - Transient JWKs exist in local memory only long enough to construct the encrypted vault
//   - Server receives only ciphertext, nonce, and version metadata
//   - If actual key material is missing, creation fails with RECOVERY_VAULT_ERROR instead of deriving a deterministic fallback key.

import { p256 } from '@noble/curves/nist.js';

const DB_NAME = 'aamarva_e2ee_keystore';
const DB_VERSION = 5; // Incremented for cluster shared group-key store
const KEY_STORE_NAME = 'agent_keys';
const EPOCH_STORE_NAME = 'agent_epoch_keys';
const PINNED_STORE_NAME = 'pinned_peer_keys';
const CLUSTER_GROUP_KEY_STORE_NAME = 'cluster_group_keys';


const KEY_ALGO = { name: 'ECDH', namedCurve: 'P-256' };
const SIGN_ALGO = { name: 'ECDSA', namedCurve: 'P-256' };
const ENC_ALGO = 'AES-GCM';
const HKDF_SALT = new TextEncoder().encode('aamarva-e2ee-channel-v1');

function base64url(arr: Uint8Array): string {
  if (typeof Buffer !== 'undefined') {
    return Buffer.from(arr).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }
  let binary = '';
  const len = arr.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(arr[i]);
  }
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

export type E2EEDecryptionErrorCode =
  | 'MISSING_PAYLOAD'
  | 'INVALID_CIPHERTEXT'
  | 'INVALID_NONCE'
  | 'MISSING_RECIPIENT_PRIVATE_KEY'
  | 'MISSING_SENDER_PUBLIC_KEY'
  | 'KEY_EPOCH_NOT_FOUND'
  | 'ECDH_DERIVATION_FAILED'
  | 'HKDF_DERIVATION_FAILED'
  | 'AUTHENTICATION_TAG_FAILED'
  | 'AAD_MISMATCH'
  | 'KEY_PAIR_MISMATCH';

export class E2EEDecryptionError extends Error {
  code: E2EEDecryptionErrorCode;
  constructor(code: E2EEDecryptionErrorCode, message: string) {
    super(message);
    this.name = 'E2EEDecryptionError';
    this.code = code;
  }
}

/**
 * Canonicalizes agent identifiers across all E2EE operations:
 * Trims whitespace, strips leading '@', and converts to uppercase.
 * e.g. '@AMR-C59G-GX6D' -> 'AMR-C59G-GX6D'
 */
export function normalizeAgentId(agentId?: string | null): string {
  if (!agentId || typeof agentId !== 'string') return '';
  let id = agentId.trim();
  if (id.startsWith('@')) {
    id = id.substring(1).trim();
  }
  return id.toUpperCase();
}

export interface StoredAgentKeyEntry {
  publicKey: string; // Exportable JWK string
  privateKey: CryptoKey | string; // Non-exportable CryptoKey (extractable: false)
  fingerprint: string;
  identityPublicKey?: string; // Exportable ECDSA JWK string
  identityPrivateKey?: CryptoKey | string; // Non-exportable ECDSA CryptoKey (extractable: false)
  signature?: string; // Authenticated binding signature (Base64)
  keyEpoch: number; // Cryptographic key epoch (starts at 1, increments on explicit rotation)
}

export type PeerTrustStatus = 'UNKNOWN' | 'UNVERIFIED' | 'VERIFIED' | 'KEY_CHANGED' | 'REJECTED';

export interface PinnedPeerEpochEntry {
  publicKey: string;
  fingerprint: string;
  identityKey?: string;
  signature?: string;
  keyEpoch: number;
  pinnedAt: string;
}

export interface PinnedPeerEntry {
  peerAgentId: string;
  fingerprint: string;
  publicKey: string;
  identityKey?: string;
  signature?: string;
  verified: boolean; // Explicit out-of-band verification flag
  verifiedAt?: string;
  pinnedAt: string;
  keyEpoch?: number;
  epochKeys?: Record<string, PinnedPeerEpochEntry>;
}

export interface PeerVerificationResult {
  verified: boolean;
  fingerprint: string;
  identityVerified: boolean;
  trustStatus: PeerTrustStatus;
  keyChanged?: boolean;
}

// In-memory cache for fast synchronous access and environments where IndexedDB is unavailable or initializing
const memoryKeyCache = new Map<string, StoredAgentKeyEntry>();
const memoryEpochCache = new Map<string, StoredAgentKeyEntry>();
const memoryPinnedCache = new Map<string, PinnedPeerEntry>();
const memoryPeerEpochCache = new Map<string, PinnedPeerEpochEntry>();


let cachedKeyDb: IDBDatabase | null = null;
let openingKeyDbPromise: Promise<IDBDatabase> | null = null;

/**
 * Open IndexedDB connection with schema migration (singleton connection reuse)
 */
function openKeyDatabase(): Promise<IDBDatabase> {
  if (cachedKeyDb) {
    return Promise.resolve(cachedKeyDb);
  }
  if (openingKeyDbPromise) {
    return openingKeyDbPromise;
  }

  openingKeyDbPromise = new Promise<IDBDatabase>((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      openingKeyDbPromise = null;
      return reject(new Error('IndexedDB is not available in this environment.'));
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(KEY_STORE_NAME)) {
        db.createObjectStore(KEY_STORE_NAME, { keyPath: 'agentId' });
      }
      if (!db.objectStoreNames.contains(EPOCH_STORE_NAME)) {
        db.createObjectStore(EPOCH_STORE_NAME, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(PINNED_STORE_NAME)) {
        db.createObjectStore(PINNED_STORE_NAME, { keyPath: 'peerAgentId' });
      }
      if (!db.objectStoreNames.contains(CLUSTER_GROUP_KEY_STORE_NAME)) {
        db.createObjectStore(CLUSTER_GROUP_KEY_STORE_NAME, { keyPath: 'id' });
      }
    };

    request.onsuccess = () => {
      const db = request.result;
      cachedKeyDb = db;
      openingKeyDbPromise = null;
      db.onclose = () => {
        if (cachedKeyDb === db) cachedKeyDb = null;
      };
      db.onversionchange = () => {
        if (cachedKeyDb === db) cachedKeyDb = null;
        try {
          db.close();
        } catch {}
      };
      resolve(db);
    };
    request.onerror = () => {
      openingKeyDbPromise = null;
      reject(request.error || new Error('Failed to open E2EE IndexedDB.'));
    };
  });

  return openingKeyDbPromise;
}

/**
 * Computes canonical JWK string (lexicographically ordered keys)
 */
function canonicalizeJwk(jwk: any): string {
  const parsed = typeof jwk === 'string' ? JSON.parse(jwk) : jwk;
  return JSON.stringify({
    crv: parsed.crv || 'P-256',
    kty: parsed.kty || 'EC',
    x: parsed.x,
    y: parsed.y
  });
}

/**
 * Computes canonical SHA-256 public key fingerprint formatted as hex with colons
 * Example: SHA256:4A:7B:3F:...
 */
export async function computeKeyFingerprint(publicKeyJwk: string): Promise<string> {
  const canonical = canonicalizeJwk(publicKeyJwk);
  const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;
  const digestBuf = await cryptoObj.subtle.digest('SHA-256', new TextEncoder().encode(canonical));
  const hex = Array.from(new Uint8Array(digestBuf))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join(':')
    .toUpperCase();
  return `SHA256:${hex}`;
}

/**
 * Computes canonical SHA-256 fingerprint of raw key bytes formatted as hex with colons
 * Example: SHA256:4A:7B:3F:...
 */
export async function computeRawGroupKeyFingerprint(rawBytes: Uint8Array): Promise<string> {
  const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;
  const digestBuf = await cryptoObj.subtle.digest('SHA-256', rawBytes);
  const hex = Array.from(new Uint8Array(digestBuf))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join(':')
    .toUpperCase();
  return `SHA256:${hex}`;
}

export interface E2EEKeyPair {
  publicKey: string;
  privateKey: CryptoKey;
  fingerprint: string;
  transientPrivateKeyJwk?: object;
}

/**
 * Generates an ECDH P-256 Key Pair for the agent.
 * Operational CryptoKey is imported as non-extractable (extractable: false).
 * Raw private key is NEVER transmitted across the network or stored unencrypted.
 */
export async function generateE2EEKeyPair(): Promise<E2EEKeyPair> {
  const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;
  const tempKeyPair = await cryptoObj.subtle.generateKey(
    KEY_ALGO,
    true, // temporarily extractable to get JWK for recovery vault wrapping
    ['deriveKey', 'deriveBits']
  );

  // Export public key and private JWK for transient vault setup
  const exportedPub = await cryptoObj.subtle.exportKey('jwk', tempKeyPair.publicKey);
  const exportedPriv = await cryptoObj.subtle.exportKey('jwk', tempKeyPair.privateKey);
  const pubStr = JSON.stringify(exportedPub);
  const fingerprint = await computeKeyFingerprint(pubStr);

  // Import operational private key as non-extractable
  const opPrivateKey = await cryptoObj.subtle.importKey(
    'jwk',
    exportedPriv,
    KEY_ALGO,
    false, // extractable: false for operational key
    ['deriveKey', 'deriveBits']
  );

  return {
    publicKey: pubStr,
    privateKey: opPrivateKey,
    fingerprint,
    transientPrivateKeyJwk: exportedPriv
  };
}

export interface IdentitySigningKeyPair {
  identityPublicKey: string;
  identityPrivateKey: CryptoKey;
  transientIdentityPrivateKeyJwk?: object;
}

/**
 * Generates an ECDSA P-256 Signing Key Pair for agent cryptographic identity.
 * Operational CryptoKey is imported as non-extractable (extractable: false).
 */
export async function generateIdentitySigningKeyPair(): Promise<IdentitySigningKeyPair> {
  const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;
  const tempKeyPair = await cryptoObj.subtle.generateKey(
    SIGN_ALGO,
    true, // temporarily extractable to get JWK for recovery vault wrapping
    ['sign', 'verify']
  );

  const exportedPub = await cryptoObj.subtle.exportKey('jwk', tempKeyPair.publicKey);
  const exportedPriv = await cryptoObj.subtle.exportKey('jwk', tempKeyPair.privateKey);

  // Import operational identity signing key as non-extractable
  const opPrivateKey = await cryptoObj.subtle.importKey(
    'jwk',
    exportedPriv,
    SIGN_ALGO,
    false, // extractable: false
    ['sign']
  );

  return {
    identityPublicKey: JSON.stringify(exportedPub),
    identityPrivateKey: opPrivateKey,
    transientIdentityPrivateKeyJwk: exportedPriv
  };
}

/**
 * Cryptographically signs an identity-to-E2EE-key binding statement using ECDSA P-256.
 * Statement format: AAMARVA-KEY-BINDING:v1:<AGENT_ID>:<FINGERPRINT>
 */
export async function signKeyBinding(
  identityPrivateKey: CryptoKey,
  agentId: string,
  fingerprint: string
): Promise<string> {
  const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;
  const canonicalAgentId = agentId.trim().toUpperCase();
  const statement = new TextEncoder().encode(`AAMARVA-KEY-BINDING:v1:${canonicalAgentId}:${fingerprint}`);
  const sigBuf = await cryptoObj.subtle.sign(
    { name: 'ECDSA', hash: 'SHA-256' },
    identityPrivateKey,
    statement
  );
  return bufferToBase64(sigBuf);
}

/**
 * Cryptographically verifies an identity-to-E2EE-key binding statement using ECDSA P-256.
 */
export async function verifyKeyBinding(
  identityPublicKeyJwk: string,
  agentId: string,
  fingerprint: string,
  signatureBase64: string
): Promise<boolean> {
  try {
    const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;
    const canonicalAgentId = agentId.trim().toUpperCase();
    const statement = new TextEncoder().encode(`AAMARVA-KEY-BINDING:v1:${canonicalAgentId}:${fingerprint}`);
    const parsed = typeof identityPublicKeyJwk === 'string' ? JSON.parse(identityPublicKeyJwk) : identityPublicKeyJwk;
    const idKey = await cryptoObj.subtle.importKey(
      'jwk',
      parsed,
      SIGN_ALGO,
      true,
      ['verify']
    );
    const sigBuf = base64ToBuffer(signatureBase64);
    return await cryptoObj.subtle.verify(
      { name: 'ECDSA', hash: 'SHA-256' },
      idKey,
      sigBuf,
      statement
    );
  } catch {
    return false;
  }
}

export interface AgentCryptoIdentity {
  e2eePublicKey: string;
  e2eePrivateKey: CryptoKey;
  fingerprint: string;
  identityPublicKey: string;
  identityPrivateKey: CryptoKey;
  signature: string;
  keyEpoch: number;
  transientPrivateKeyJwk?: object;
  transientIdentityPrivateKeyJwk?: object;
}

/**
 * Generates an initial complete cryptographic identity for an agent:
 * - Non-exportable ECDH exchange key (Epoch 1)
 * - Non-exportable ECDSA identity signing key
 * - Cryptographically signed key binding statement
 */
export async function generateAgentCryptoIdentity(
  agentId: string,
  keyEpoch: number = 1
): Promise<AgentCryptoIdentity> {
  const normalizedAgentId = normalizeAgentId(agentId);
  const epochNum = typeof keyEpoch === 'number' && Number.isFinite(keyEpoch) && keyEpoch > 0 ? Math.floor(keyEpoch) : 1;
  const e2ee = await generateE2EEKeyPair();
  const idSign = await generateIdentitySigningKeyPair();
  const signature = await signKeyBinding(idSign.identityPrivateKey, normalizedAgentId, e2ee.fingerprint);

  return {
    e2eePublicKey: e2ee.publicKey,
    e2eePrivateKey: e2ee.privateKey,
    fingerprint: e2ee.fingerprint,
    identityPublicKey: idSign.identityPublicKey,
    identityPrivateKey: idSign.identityPrivateKey,
    signature,
    keyEpoch: epochNum,
    transientPrivateKeyJwk: e2ee.transientPrivateKeyJwk,
    transientIdentityPrivateKeyJwk: idSign.transientIdentityPrivateKeyJwk
  };
}

/**
 * Derives an initial agent cryptographic identity from their password or API credential.
 * Used during first-time registration when no recovery vault is available yet.
 * Any subsequent backup/recovery relies strictly on the encrypted recovery vault containing the actual keys;
 * no deterministic derivation or fallback is used during recovery-vault restoration.
 */
export async function deriveAgentCryptoIdentity(
  agentId: string,
  credential: string,
  keyEpoch: number = 1
): Promise<AgentCryptoIdentity> {
  const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;
  const canonicalAgentId = agentId.trim().toUpperCase();

  // 1. Derive ECDH exchange key seed using native WebCrypto PBKDF2
  const ecdhSalt = new TextEncoder().encode(`AAMARVA-ECDH-VAULT:v1:${canonicalAgentId}:epoch:${keyEpoch}`);
  const baseKey = await cryptoObj.subtle.importKey(
    'raw',
    new TextEncoder().encode(credential),
    'PBKDF2',
    false,
    ['deriveBits']
  );
  const ecdhSeed = new Uint8Array(
    await cryptoObj.subtle.deriveBits(
      { name: 'PBKDF2', salt: ecdhSalt, iterations: 100000, hash: 'SHA-256' },
      baseKey,
      256
    )
  );

  const ecdhPubBytes = p256.getPublicKey(ecdhSeed, false);
  const ecdhX = ecdhPubBytes.slice(1, 33);
  const ecdhY = ecdhPubBytes.slice(33, 65);

  const ecdhPrivJwk = {
    kty: 'EC',
    crv: 'P-256',
    d: base64url(ecdhSeed),
    x: base64url(ecdhX),
    y: base64url(ecdhY)
  };
  const ecdhPubJwk = {
    kty: 'EC',
    crv: 'P-256',
    x: base64url(ecdhX),
    y: base64url(ecdhY)
  };

  const e2eePrivateKey = await cryptoObj.subtle.importKey(
    'jwk',
    ecdhPrivJwk,
    KEY_ALGO,
    false, // extractable: false for operational non-extractable key
    ['deriveKey', 'deriveBits']
  );
  const e2eePublicKey = canonicalizeJwk(JSON.stringify(ecdhPubJwk));
  const fingerprint = await computeKeyFingerprint(e2eePublicKey);

  // 2. Derive ECDSA identity signing key seed
  const ecdsaSalt = new TextEncoder().encode(`AAMARVA-ECDSA-IDENTITY:v1:${canonicalAgentId}`);
  const ecdsaSeed = new Uint8Array(
    await cryptoObj.subtle.deriveBits(
      { name: 'PBKDF2', salt: ecdsaSalt, iterations: 100000, hash: 'SHA-256' },
      baseKey,
      256
    )
  );

  const ecdsaPubBytes = p256.getPublicKey(ecdsaSeed, false);
  const ecdsaX = ecdsaPubBytes.slice(1, 33);
  const ecdsaY = ecdsaPubBytes.slice(33, 65);

  const ecdsaPrivJwk = {
    kty: 'EC',
    crv: 'P-256',
    d: base64url(ecdsaSeed),
    x: base64url(ecdsaX),
    y: base64url(ecdsaY)
  };
  const ecdsaPubJwk = {
    kty: 'EC',
    crv: 'P-256',
    x: base64url(ecdsaX),
    y: base64url(ecdsaY)
  };

  const identityPrivateKey = await cryptoObj.subtle.importKey(
    'jwk',
    ecdsaPrivJwk,
    SIGN_ALGO,
    false, // extractable: false for operational non-extractable key
    ['sign']
  );
  const identityPublicKey = canonicalizeJwk(JSON.stringify(ecdsaPubJwk));
  const signature = await signKeyBinding(identityPrivateKey, canonicalAgentId, fingerprint);

  return {
    e2eePublicKey,
    e2eePrivateKey,
    fingerprint,
    identityPublicKey,
    identityPrivateKey,
    signature,
    keyEpoch,
    transientPrivateKeyJwk: ecdhPrivJwk,
    transientIdentityPrivateKeyJwk: ecdsaPrivJwk
  };
}

/**
 * Performs explicit, safe key rotation for an agent:
 * 1. Increments key epoch: nextEpoch = currentEpoch + 1
 * 2. Generates new ECDH key pair with extractable: false
 * 3. Uses existing identity signing key to sign the new binding (preserving identity trust anchor)
 * 4. Saves new key under nextEpoch while preserving previous epoch keys in historical store
 * 5. Returns new identity material ready for authorized server update
 */
export async function rotateAgentCryptoIdentity(
  agentId: string,
  currentEpoch?: number,
  options?: {
    existingVault?: { ciphertext: string; nonce: string; version?: number; kdfVersion?: number } | null;
    credential?: string;
    preserveIdentityOnlyIfRecoverable?: boolean;
  }
): Promise<AgentCryptoIdentity> {
  const normalizedAgentId = agentId.trim().toUpperCase();
  const currentKey = await getLocalKeyPair(normalizedAgentId);
  const allEpochs = await getAllLocalEpochKeys(normalizedAgentId);
  const maxStoredEpoch = allEpochs.reduce((max, ep) => Math.max(max, ep.keyEpoch || 1), 1);

  const effectiveEpoch = typeof currentEpoch === 'number' && currentEpoch > 0
    ? currentEpoch
    : Math.max(currentKey?.keyEpoch || 1, maxStoredEpoch);
  const nextEpoch = effectiveEpoch + 1;

  // If an existing vault + credential are supplied, pre-populate transientJwkMap so identity JWK is known
  if (options?.existingVault?.ciphertext && options?.existingVault?.nonce && options?.credential) {
    try {
      const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;
      const vaultKdfVersion = options.existingVault.kdfVersion !== undefined ? Number(options.existingVault.kdfVersion) : 1;
      const nonceBytes = new Uint8Array(base64ToBuffer(options.existingVault.nonce));
      const ciphertextBytes = new Uint8Array(base64ToBuffer(options.existingVault.ciphertext));
      let decryptedBuffer: ArrayBuffer;
      try {
        const wrappingKey = await deriveKeyWrappingKey(normalizedAgentId, options.credential, vaultKdfVersion);
        decryptedBuffer = await cryptoObj.subtle.decrypt(
          { name: 'AES-GCM', iv: nonceBytes },
          wrappingKey,
          ciphertextBytes
        );
      } catch {
        const altKdfVersion = vaultKdfVersion === 2 ? 1 : 2;
        const wrappingKey = await deriveKeyWrappingKey(normalizedAgentId, options.credential, altKdfVersion);
        decryptedBuffer = await cryptoObj.subtle.decrypt(
          { name: 'AES-GCM', iv: nonceBytes },
          wrappingKey,
          ciphertextBytes
        );
      }
      const payload = JSON.parse(new TextDecoder().decode(decryptedBuffer));
      if (payload?.activeKey?.identityPrivateKeyJwk) {
        const akEp = payload.activeKey.keyEpoch || payload.keyEpoch || 1;
        if (!transientJwkMap.has(`${normalizedAgentId}:${akEp}:identity`)) {
          transientJwkMap.set(`${normalizedAgentId}:${akEp}:identity`, payload.activeKey.identityPrivateKeyJwk);
        }
        if (payload.activeKey.privateKeyJwk && !transientJwkMap.has(`${normalizedAgentId}:${akEp}:e2ee`)) {
          transientJwkMap.set(`${normalizedAgentId}:${akEp}:e2ee`, payload.activeKey.privateKeyJwk);
        }
      }
      if (Array.isArray(payload?.epochs)) {
        for (const ep of payload.epochs) {
          if (ep?.keyEpoch) {
            if (ep.privateKeyJwk && !transientJwkMap.has(`${normalizedAgentId}:${ep.keyEpoch}:e2ee`)) {
              transientJwkMap.set(`${normalizedAgentId}:${ep.keyEpoch}:e2ee`, ep.privateKeyJwk);
            }
            if (ep.identityPrivateKeyJwk && !transientJwkMap.has(`${normalizedAgentId}:${ep.keyEpoch}:identity`)) {
              transientJwkMap.set(`${normalizedAgentId}:${ep.keyEpoch}:identity`, ep.identityPrivateKeyJwk);
            }
          }
        }
      }
    } catch {
      // Non-fatal: caller may pass preserveIdentityOnlyIfRecoverable
    }
  }

  // Generate fresh ECDH key pair (operational key extractable: false)
  const newE2ee = await generateE2EEKeyPair();

  // Check if any identity private key JWK is recoverable in transientJwkMap or extractable
  let hasRecoverableIdentityJwk = false;
  if (currentKey?.identityPrivateKey && typeof (currentKey.identityPrivateKey as any)?.algorithm === 'object') {
    if ((currentKey.identityPrivateKey as CryptoKey).extractable) {
      hasRecoverableIdentityJwk = true;
    }
  } else if (currentKey?.identityPrivateKey) {
    hasRecoverableIdentityJwk = true;
  }
  if (!hasRecoverableIdentityJwk) {
    for (const k of transientJwkMap.keys()) {
      if (k.startsWith(`${normalizedAgentId}:`) && k.endsWith(':identity')) {
        hasRecoverableIdentityJwk = true;
        break;
      }
    }
  }

  // Retrieve or regenerate identity signing key
  let idSignKey: CryptoKey;
  let idPubStr: string;
  let transientIdPrivJwk: any = undefined;

  if (
    currentKey?.identityPrivateKey &&
    currentKey?.identityPublicKey &&
    (!options?.preserveIdentityOnlyIfRecoverable || hasRecoverableIdentityJwk)
  ) {
    idSignKey = await importSigningKey(currentKey.identityPrivateKey, 'private', false);
    idPubStr = typeof currentKey.identityPublicKey === 'string'
      ? currentKey.identityPublicKey
      : JSON.stringify(currentKey.identityPublicKey);
  } else {
    const freshIdSign = await generateIdentitySigningKeyPair();
    idSignKey = freshIdSign.identityPrivateKey;
    idPubStr = freshIdSign.identityPublicKey;
    transientIdPrivJwk = freshIdSign.transientIdentityPrivateKeyJwk;
  }

  // Sign binding with identity key
  const signature = await signKeyBinding(idSignKey, normalizedAgentId, newE2ee.fingerprint);

  // Save into local keystore and epoch historical archive
  await saveLocalKeyPair(
    normalizedAgentId,
    newE2ee.publicKey,
    newE2ee.privateKey,
    newE2ee.fingerprint,
    idPubStr,
    idSignKey,
    signature,
    nextEpoch,
    newE2ee.transientPrivateKeyJwk,
    transientIdPrivJwk
  );

  return {
    e2eePublicKey: newE2ee.publicKey,
    e2eePrivateKey: newE2ee.privateKey,
    fingerprint: newE2ee.fingerprint,
    identityPublicKey: idPubStr,
    identityPrivateKey: idSignKey,
    signature,
    keyEpoch: nextEpoch,
    transientPrivateKeyJwk: newE2ee.transientPrivateKeyJwk,
    transientIdentityPrivateKeyJwk: transientIdPrivJwk
  };
}

// In-memory transient map for ephemeral recovery vault creation during key setup/rotation
const transientJwkMap = new Map<string, any>();

/**
 * Clears transient JWK representations for a specific agent after successful vault construction and upload.
 */
export function clearTransientJwkKeys(agentId: string): void {
  const normalizedAgentId = agentId.trim().toUpperCase();
  const prefix = `${normalizedAgentId}:`;
  for (const key of transientJwkMap.keys()) {
    if (key.startsWith(prefix)) {
      transientJwkMap.delete(key);
    }
  }
}

// In-process lock map to serialize concurrent saves per agent/epoch and prevent write races
const agentEpochSaveLocks = new Map<string, Promise<any>>();

async function withAgentSaveLock<T>(lockKey: string, fn: () => Promise<T>): Promise<T> {
  const currentLock = agentEpochSaveLocks.get(lockKey) || Promise.resolve();
  let releaseLock: () => void = () => {};
  const newLock = new Promise<void>((resolve) => {
    releaseLock = resolve;
  });
  agentEpochSaveLocks.set(lockKey, currentLock.then(() => newLock, () => newLock));

  try {
    await currentLock;
    return await fn();
  } finally {
    releaseLock();
    if (agentEpochSaveLocks.get(lockKey) === newLock) {
      agentEpochSaveLocks.delete(lockKey);
    }
  }
}

function normalizeJwkKeyString(k: any): string {
  if (!k) return '';
  if (typeof k === 'string') {
    try {
      const parsed = JSON.parse(k);
      return JSON.stringify(parsed);
    } catch {
      return k.trim();
    }
  }
  try {
    return JSON.stringify(k);
  } catch {
    return String(k);
  }
}

function isSameKeyMaterial(
  storedFp?: string,
  storedPub?: any,
  incomingFp?: string,
  incomingPub?: any
): boolean {
  if (storedFp && incomingFp && storedFp === incomingFp) {
    return true;
  }
  if (storedPub && incomingPub) {
    const normStored = normalizeJwkKeyString(storedPub);
    const normIncoming = normalizeJwkKeyString(incomingPub);
    if (normStored && normIncoming && normStored === normIncoming) {
      return true;
    }
  }
  return false;
}

/**
 * Saves agent's local keys into persistent IndexedDB keystore.
 * Stores native CryptoKey objects (non-exportable) directly via IndexedDB structured clone.
 * Also archives entry in historical epoch store.
 * Strictly enforces epoch immutability:
 * - If requested epoch already exists with the SAME key -> treated as idempotent (success).
 * - If requested epoch already exists with a DIFFERENT key -> strictly rejected with E2EE_EPOCH_ALREADY_EXISTS.
 * Concurrency safe: Serialized per agent/epoch and executes within an atomic IndexedDB transaction.
 */
export async function saveLocalKeyPair(
  agentId: string,
  publicKey: string,
  privateKey: CryptoKey | string,
  fingerprint?: string,
  identityPublicKey?: string,
  identityPrivateKey?: CryptoKey | string,
  signature?: string,
  keyEpoch: number = 1,
  transientPrivateKeyJwk?: object,
  transientIdentityPrivateKeyJwk?: object
): Promise<void> {
  const normalizedAgentId = agentId.trim().toUpperCase();
  const fp = fingerprint || (await computeKeyFingerprint(publicKey));
  const epoch = typeof keyEpoch === 'number' && keyEpoch > 0 ? keyEpoch : 1;
  const lockKey = `${normalizedAgentId}#epoch#${epoch}`;

  return withAgentSaveLock(lockKey, async () => {
    // 1. Strict epoch immutability check in memory cache
    const epochCacheKey = `${normalizedAgentId}#epoch#${epoch}`;
    const existingMemory = memoryEpochCache.get(epochCacheKey);
    if (existingMemory) {
      const isSame = isSameKeyMaterial(existingMemory.fingerprint, existingMemory.publicKey, fp, publicKey);
      if (!isSame) {
        throw new Error(`E2EE_EPOCH_ALREADY_EXISTS: Key epoch ${epoch} already exists for agent ${normalizedAgentId} with a different key. Existing epochs are immutable.`);
      }
      // Same key: update transient representations if available and proceed idempotently
      if (transientPrivateKeyJwk) {
        transientJwkMap.set(`${normalizedAgentId}:${epoch}:e2ee`, transientPrivateKeyJwk);
      }
      if (transientIdentityPrivateKeyJwk) {
        transientJwkMap.set(`${normalizedAgentId}:${epoch}:identity`, transientIdentityPrivateKeyJwk);
      }
      return;
    }

    const entry: StoredAgentKeyEntry = {
      publicKey,
      privateKey,
      fingerprint: fp,
      identityPublicKey,
      identityPrivateKey,
      signature,
      keyEpoch: epoch
    };

    // 2. Atomic read-and-conditional-write in a single IndexedDB transaction
    try {
      const db = await openKeyDatabase();
      await new Promise<void>((resolve, reject) => {
        let settled = false;
        const safeReject = (err: any) => {
          if (!settled) {
            settled = true;
            reject(err);
          }
        };
        const safeResolve = () => {
          if (!settled) {
            settled = true;
            resolve();
          }
        };

        const tx = db.transaction([KEY_STORE_NAME, EPOCH_STORE_NAME], 'readwrite');
        const epochStore = tx.objectStore(EPOCH_STORE_NAME);
        const keyStore = tx.objectStore(KEY_STORE_NAME);
        const epochId = `${normalizedAgentId}#epoch#${epoch}`;

        const epochReq = epochStore.get(epochId);
        epochReq.onsuccess = () => {
          const existing = epochReq.result;
          if (existing) {
            const isSame = isSameKeyMaterial(existing.fingerprint, existing.publicKey, fp, publicKey);
            if (!isSame) {
              try {
                tx.abort();
              } catch {}
              safeReject(new Error(`E2EE_EPOCH_ALREADY_EXISTS: Key epoch ${epoch} already exists for agent ${normalizedAgentId} with a different key in persistent storage.`));
              return;
            }
            // Same key: Idempotent! Do not overwrite historical epoch record.
            const curKeyReq = keyStore.get(normalizedAgentId);
            curKeyReq.onsuccess = () => {
              const cur = curKeyReq.result;
              if (!cur || !cur.keyEpoch || epoch >= cur.keyEpoch) {
                keyStore.put({
                  agentId: normalizedAgentId,
                  publicKey,
                  privateKey,
                  fingerprint: fp,
                  identityPublicKey,
                  identityPrivateKey,
                  signature,
                  keyEpoch: epoch,
                  updatedAt: new Date().toISOString()
                });
              }
            };
            return;
          }

          // Epoch does NOT exist yet: store in historical epoch archive
          epochStore.put({
            id: epochId,
            agentId: normalizedAgentId,
            keyEpoch: epoch,
            publicKey,
            privateKey,
            fingerprint: fp,
            identityPublicKey,
            identityPrivateKey,
            signature,
            archivedAt: new Date().toISOString()
          });

          // Check and update active key if epoch >= existing active epoch
          const curKeyReq = keyStore.get(normalizedAgentId);
          curKeyReq.onsuccess = () => {
            const cur = curKeyReq.result;
            if (!cur || !cur.keyEpoch || epoch >= cur.keyEpoch) {
              keyStore.put({
                agentId: normalizedAgentId,
                publicKey,
                privateKey,
                fingerprint: fp,
                identityPublicKey,
                identityPrivateKey,
                signature,
                keyEpoch: epoch,
                updatedAt: new Date().toISOString()
              });
            }
          };
        };

        epochReq.onerror = () => {
          safeReject(epochReq.error);
        };

        tx.oncomplete = () => {
          // Transaction committed successfully: update in-memory caches
          memoryEpochCache.set(epochCacheKey, entry);
          const curMem = memoryKeyCache.get(normalizedAgentId);
          if (!curMem || !curMem.keyEpoch || epoch >= curMem.keyEpoch) {
            memoryKeyCache.set(normalizedAgentId, entry);
          }
          if (transientPrivateKeyJwk) {
            transientJwkMap.set(`${normalizedAgentId}:${epoch}:e2ee`, transientPrivateKeyJwk);
          }
          if (transientIdentityPrivateKeyJwk) {
            transientJwkMap.set(`${normalizedAgentId}:${epoch}:identity`, transientIdentityPrivateKeyJwk);
          }
          safeResolve();
        };

        tx.onerror = () => {
          safeReject(tx.error || new Error('IndexedDB transaction error'));
        };

        tx.onabort = () => {
          safeReject(new Error(`E2EE_EPOCH_ALREADY_EXISTS: Key epoch ${epoch} already exists for agent ${normalizedAgentId} with a different key in persistent storage.`));
        };
      });
    } catch (idbErr: any) {
      if (idbErr?.message?.includes('E2EE_EPOCH_ALREADY_EXISTS')) {
        throw idbErr;
      }
      // If IndexedDB is unavailable in current runtime, memory cache fallback
      console.warn('E2EE Keystore: IndexedDB unavailable or write error, using session memory cache:', idbErr);
      memoryEpochCache.set(epochCacheKey, entry);
      const curMem = memoryKeyCache.get(normalizedAgentId);
      if (!curMem || !curMem.keyEpoch || epoch >= curMem.keyEpoch) {
        memoryKeyCache.set(normalizedAgentId, entry);
      }
      if (transientPrivateKeyJwk) {
        transientJwkMap.set(`${normalizedAgentId}:${epoch}:e2ee`, transientPrivateKeyJwk);
      }
      if (transientIdentityPrivateKeyJwk) {
        transientJwkMap.set(`${normalizedAgentId}:${epoch}:identity`, transientIdentityPrivateKeyJwk);
      }
    }
  });
}

/**
 * Retrieves agent's local keys from persistent IndexedDB keystore.
 * If epoch is specified, retrieves the specific historical key for that epoch.
 * Automatically imports legacy string JWKs to non-exportable CryptoKey objects if encountered.
 */
export async function getLocalKeyPair(
  agentId: string,
  epoch?: number,
  _credential?: string
): Promise<StoredAgentKeyEntry | null> {
  const normalizedAgentId = agentId.trim().toUpperCase();

  // If specific epoch requested, check memory epoch cache first
  if (typeof epoch === 'number' && epoch > 0) {
    const epochCacheKey = `${normalizedAgentId}#epoch#${epoch}`;
    if (memoryEpochCache.has(epochCacheKey)) {
      return memoryEpochCache.get(epochCacheKey)!;
    }
  } else {
    // Check main memory cache
    if (memoryKeyCache.has(normalizedAgentId)) {
      return memoryKeyCache.get(normalizedAgentId)!;
    }
  }

  try {
    const db = await openKeyDatabase();

    // If specific epoch requested, look in EPOCH_STORE_NAME first
    if (typeof epoch === 'number' && epoch > 0) {
      const epochId = `${normalizedAgentId}#epoch#${epoch}`;
      const epochResult = await new Promise<any>((resolve, reject) => {
        const tx = db.transaction(EPOCH_STORE_NAME, 'readonly');
        const store = tx.objectStore(EPOCH_STORE_NAME);
        const req = store.get(epochId);
        req.onsuccess = () => resolve(req.result || null);
        req.onerror = () => reject(req.error);
      });

      if (epochResult && epochResult.publicKey && epochResult.privateKey) {
        let privKey = epochResult.privateKey;
        let idPrivKey = epochResult.identityPrivateKey;

        if (typeof privKey === 'string' || (privKey && typeof privKey === 'object' && !('algorithm' in privKey))) {
          privKey = await importCryptoKey(privKey, 'private', false);
        }
        if (typeof idPrivKey === 'string' || (idPrivKey && typeof idPrivKey === 'object' && !('algorithm' in idPrivKey))) {
          idPrivKey = await importSigningKey(idPrivKey, 'private', false);
        }

        const entry: StoredAgentKeyEntry = {
          publicKey: epochResult.publicKey,
          privateKey: privKey,
          fingerprint: epochResult.fingerprint || (await computeKeyFingerprint(epochResult.publicKey)),
          identityPublicKey: epochResult.identityPublicKey,
          identityPrivateKey: idPrivKey,
          signature: epochResult.signature,
          keyEpoch: epochResult.keyEpoch || epoch
        };

        memoryEpochCache.set(epochId, entry);
        return entry;
      }
    }

    // Default: Retrieve current active key
    const result = await new Promise<any>((resolve, reject) => {
      const tx = db.transaction(KEY_STORE_NAME, 'readonly');
      const store = tx.objectStore(KEY_STORE_NAME);
      const req = store.get(normalizedAgentId);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });

    if (result && result.publicKey && result.privateKey) {
      let privKey = result.privateKey;
      let idPrivKey = result.identityPrivateKey;
      let needsMigration = false;

      // Backward compatibility and secure migration: If legacy string JWK was found, convert to non-exportable CryptoKey
      if (typeof privKey === 'string' || (privKey && typeof privKey === 'object' && !('algorithm' in privKey))) {
        try {
          privKey = await importCryptoKey(privKey, 'private', false);
          needsMigration = true;
        } catch (migErr) {
          throw new Error(`E2EE_MIGRATION_FAILURE: Failed to import legacy private key: ${migErr instanceof Error ? migErr.message : String(migErr)}`);
        }
      }
      if (typeof idPrivKey === 'string' || (idPrivKey && typeof idPrivKey === 'object' && !('algorithm' in idPrivKey))) {
        try {
          idPrivKey = await importSigningKey(idPrivKey, 'private', false);
          needsMigration = true;
        } catch (migErr) {
          throw new Error(`E2EE_MIGRATION_FAILURE: Failed to import legacy signing key: ${migErr instanceof Error ? migErr.message : String(migErr)}`);
        }
      }

      const currentEpoch = result.keyEpoch || 1;
      const entry: StoredAgentKeyEntry = {
        publicKey: result.publicKey,
        privateKey: privKey,
        fingerprint: result.fingerprint || (await computeKeyFingerprint(result.publicKey)),
        identityPublicKey: result.identityPublicKey,
        identityPrivateKey: idPrivKey,
        signature: result.signature,
        keyEpoch: currentEpoch
      };

      // If migration occurred, persist the cleaned non-exportable CryptoKey entry back to IndexedDB
      if (needsMigration) {
        try {
          const writeDb = await openKeyDatabase();
          await new Promise<void>((resolveWrite, rejectWrite) => {
            const tx = writeDb.transaction([KEY_STORE_NAME, EPOCH_STORE_NAME], 'readwrite');
            const store = tx.objectStore(KEY_STORE_NAME);
            store.put({
              agentId: normalizedAgentId,
              publicKey: entry.publicKey,
              privateKey: entry.privateKey,
              fingerprint: entry.fingerprint,
              identityPublicKey: entry.identityPublicKey,
              identityPrivateKey: entry.identityPrivateKey,
              signature: entry.signature,
              keyEpoch: entry.keyEpoch,
              updatedAt: new Date().toISOString()
            });

            const epochStore = tx.objectStore(EPOCH_STORE_NAME);
            epochStore.put({
              id: `${normalizedAgentId}#epoch#${entry.keyEpoch}`,
              agentId: normalizedAgentId,
              keyEpoch: entry.keyEpoch,
              publicKey: entry.publicKey,
              privateKey: entry.privateKey,
              fingerprint: entry.fingerprint,
              identityPublicKey: entry.identityPublicKey,
              identityPrivateKey: entry.identityPrivateKey,
              signature: entry.signature,
              archivedAt: new Date().toISOString()
            });

            tx.oncomplete = () => resolveWrite();
            tx.onerror = () => rejectWrite(tx.error);
          });
        } catch (migPersistErr) {
          console.warn('E2EE Keystore: Failed to persist migrated non-exportable keys:', migPersistErr);
        }
      }

      memoryKeyCache.set(normalizedAgentId, entry);
      memoryEpochCache.set(`${normalizedAgentId}#epoch#${currentEpoch}`, entry);
      return entry;
    }
  } catch (e) {
    console.warn('E2EE Keystore: IndexedDB read error:', e);
  }

  return null;
}

/**
 * Derives a dedicated key-wrapping key (AES-256-GCM) from the user's credential.
 * Used exclusively for encrypting the client-side recovery artifact.
 * AAMARVA server NEVER possesses this wrapping key or the user's plaintext credential.
 */
export async function deriveKeyWrappingKey(agentId: string, credential: string, kdfVersion: number = 2): Promise<CryptoKey> {
  const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;
  const canonicalAgentId = agentId.trim().toUpperCase();
  const salt = new TextEncoder().encode(`AAMARVA-RECOVERY-VAULT:v1:${canonicalAgentId}`);
  const baseKey = await cryptoObj.subtle.importKey(
    'raw',
    new TextEncoder().encode(credential),
    'PBKDF2',
    false,
    ['deriveKey']
  );
  const iterations = kdfVersion === 1 ? 100000 : 210000;
  return await cryptoObj.subtle.deriveKey(
    { name: 'PBKDF2', salt, iterations, hash: 'SHA-256' },
    baseKey,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

/**
 * Retrieves all local historical and active epoch key entries stored for an agent from IndexedDB.
 */
export async function getAllLocalEpochKeys(agentId: string): Promise<StoredAgentKeyEntry[]> {
  const normalizedAgentId = agentId.trim().toUpperCase();
  const entries: StoredAgentKeyEntry[] = [];
  const seenEpochs = new Set<number>();

  try {
    const db = await openKeyDatabase();
    const records = await new Promise<any[]>((resolve, reject) => {
      const tx = db.transaction(EPOCH_STORE_NAME, 'readonly');
      const store = tx.objectStore(EPOCH_STORE_NAME);
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });

    for (const r of records) {
      if (r && r.agentId === normalizedAgentId && r.publicKey && r.privateKey) {
        let privKey = r.privateKey;
        let idPrivKey = r.identityPrivateKey;
        if (typeof privKey === 'string' || (privKey && typeof privKey === 'object' && !('algorithm' in privKey))) {
          privKey = await importCryptoKey(privKey, 'private', false);
        }
        if (typeof idPrivKey === 'string' || (idPrivKey && typeof idPrivKey === 'object' && !('algorithm' in idPrivKey))) {
          idPrivKey = await importSigningKey(idPrivKey, 'private', false);
        }
        const epochNum = r.keyEpoch || 1;
        seenEpochs.add(epochNum);
        entries.push({
          publicKey: r.publicKey,
          privateKey: privKey,
          fingerprint: r.fingerprint || (await computeKeyFingerprint(r.publicKey)),
          identityPublicKey: r.identityPublicKey,
          identityPrivateKey: idPrivKey,
          signature: r.signature,
          keyEpoch: epochNum
        });
      }
    }
  } catch (e) {
    console.warn('E2EE Keystore: getAllLocalEpochKeys IndexedDB query error:', e);
  }

  // Include any in-memory epoch cache entries if not already collected
  for (const [key, val] of memoryEpochCache.entries()) {
    if (key.startsWith(`${normalizedAgentId}#epoch#`) && val && val.publicKey && val.privateKey && !seenEpochs.has(val.keyEpoch)) {
      seenEpochs.add(val.keyEpoch);
      entries.push(val);
    }
  }

  // Also verify active key is included
  try {
    const active = await getLocalKeyPair(normalizedAgentId);
    if (active && active.privateKey && !seenEpochs.has(active.keyEpoch)) {
      entries.push(active);
    }
  } catch (e) {
    console.warn('E2EE Keystore: active key inclusion check notice:', e);
  }

  // Sort ascending by keyEpoch
  entries.sort((a, b) => a.keyEpoch - b.keyEpoch);
  return entries;
}

/**
 * Creates an encrypted recovery artifact containing the ACTUAL active and historical E2EE key material.
 * Implementation Details:
 *   - The recovery vault contains the ACTUAL private key material of the current cryptographic identity.
 *   - Transient JWK material is used only temporarily in local memory to construct the encrypted vault.
 *   - All transient JWK representations are discarded after encryption is completed.
 *   - Operational CryptoKeys remain non-extractable (extractable: false).
 *   - The server receives ONLY the encrypted recovery-vault ciphertext and necessary metadata (nonce, version).
 *   - If the actual private key material is unavailable, creation fails with RECOVERY_VAULT_ERROR.
 *   - No replacement or deterministic private keys are generated or derived when actual material is missing.
 */
export async function createEncryptedRecoveryVault(
  agentId: string,
  credential: string,
  _targetEpoch?: number,
  existingVault?: { ciphertext: string; nonce: string; version?: number; kdfVersion?: number }
): Promise<{ ciphertext: string; nonce: string; version: number; kdfVersion?: number }> {
  const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;
  const canonicalAgentId = agentId.trim().toUpperCase();

  const preservedVaultEpochs: any[] = [];

  // If an existing vault is supplied, opportunistically decrypt it and restore
  // any missing historical key material to the transient map.
  if (existingVault && existingVault.ciphertext && existingVault.nonce) {
    try {
      const vaultKdfVersion = existingVault.kdfVersion !== undefined ? Number(existingVault.kdfVersion) : 1;
      const nonceBytes = new Uint8Array(base64ToBuffer(existingVault.nonce));
      const ciphertextBytes = new Uint8Array(base64ToBuffer(existingVault.ciphertext));
      
      let decryptedBuffer: ArrayBuffer;
      try {
        const wrappingKey = await deriveKeyWrappingKey(canonicalAgentId, credential, vaultKdfVersion);
        decryptedBuffer = await cryptoObj.subtle.decrypt(
          { name: 'AES-GCM', iv: nonceBytes },
          wrappingKey,
          ciphertextBytes
        );
      } catch (firstErr) {
        // Fallback: try alternative KDF version
        const altKdfVersion = vaultKdfVersion === 2 ? 1 : 2;
        const wrappingKey = await deriveKeyWrappingKey(canonicalAgentId, credential, altKdfVersion);
        decryptedBuffer = await cryptoObj.subtle.decrypt(
          { name: 'AES-GCM', iv: nonceBytes },
          wrappingKey,
          ciphertextBytes
        );
      }

      const payload = JSON.parse(new TextDecoder().decode(decryptedBuffer));
      if (payload?.activeKey && payload.activeKey.privateKeyJwk) {
        const akEp = Number(payload.activeKey.keyEpoch || payload.keyEpoch || 1);
        const e2eeKey = `${canonicalAgentId}:${akEp}:e2ee`;
        const identityKey = `${canonicalAgentId}:${akEp}:identity`;
        if (!transientJwkMap.has(e2eeKey)) {
          transientJwkMap.set(e2eeKey, payload.activeKey.privateKeyJwk);
        }
        if (payload.activeKey.identityPrivateKeyJwk && !transientJwkMap.has(identityKey)) {
          transientJwkMap.set(identityKey, payload.activeKey.identityPrivateKeyJwk);
        }
        preservedVaultEpochs.push({
          keyEpoch: akEp,
          publicKey: payload.activeKey.publicKey,
          privateKeyJwk: payload.activeKey.privateKeyJwk,
          fingerprint: payload.activeKey.fingerprint,
          identityPublicKey: payload.activeKey.identityPublicKey,
          identityPrivateKeyJwk: payload.activeKey.identityPrivateKeyJwk,
          signature: payload.activeKey.signature
        });
      }
      if (payload && Array.isArray(payload.epochs)) {
        for (const ep of payload.epochs) {
          if (ep && ep.keyEpoch) {
            const e2eeKey = `${canonicalAgentId}:${ep.keyEpoch}:e2ee`;
            const identityKey = `${canonicalAgentId}:${ep.keyEpoch}:identity`;
            if (ep.privateKeyJwk && !transientJwkMap.has(e2eeKey)) {
              transientJwkMap.set(e2eeKey, ep.privateKeyJwk);
            }
            if (ep.identityPrivateKeyJwk && !transientJwkMap.has(identityKey)) {
              transientJwkMap.set(identityKey, ep.identityPrivateKeyJwk);
            }
            if (ep.privateKeyJwk && !preservedVaultEpochs.some(p => Number(p.keyEpoch) === Number(ep.keyEpoch))) {
              preservedVaultEpochs.push(ep);
            }
          }
        }
      }
    } catch (decryptErr) {
      console.warn('E2EE: Failed to decrypt existing vault during recovery vault creation:', decryptErr);
    }
  }

  // 1. Retrieve the actual current active key from the local keystore
  let activeEntry = await getLocalKeyPair(canonicalAgentId);
  if (!activeEntry || !activeEntry.privateKey) {
    throw new Error(`RECOVERY_VAULT_ERROR: No local private key found in keystore for agent ${canonicalAgentId}`);
  }

  // 2. Retrieve all actual historical epoch keys stored locally
  const allEpochs = await getAllLocalEpochKeys(canonicalAgentId);
  if (allEpochs.length === 0) {
    allEpochs.push(activeEntry);
  }

  // 3. Obtain JWKs for each epoch (via transient memory or extractable export if applicable; no deterministic fallback is used)
  const epochsData: any[] = [];
  for (const ep of allEpochs) {
    let privJwk: any = undefined;
    let idPrivJwk: any = undefined;

    // Check if key is extractable
    if (typeof (ep.privateKey as any)?.algorithm === 'object') {
      const pKey = ep.privateKey as CryptoKey;
      if (pKey.extractable) {
        try {
          privJwk = await cryptoObj.subtle.exportKey('jwk', pKey);
        } catch {
          // non-extractable
        }
      }
    } else {
      privJwk = typeof ep.privateKey === 'string' ? JSON.parse(ep.privateKey) : ep.privateKey;
    }

    if (ep.identityPrivateKey) {
      if (typeof (ep.identityPrivateKey as any)?.algorithm === 'object') {
        const idPKey = ep.identityPrivateKey as CryptoKey;
        if (idPKey.extractable) {
          try {
            idPrivJwk = await cryptoObj.subtle.exportKey('jwk', idPKey);
          } catch {
            // non-extractable
          }
        }
      } else {
        idPrivJwk = typeof ep.identityPrivateKey === 'string' ? JSON.parse(ep.identityPrivateKey) : ep.identityPrivateKey;
      }
    }

    // Check transient memory JWK map
    if (!privJwk && (ep as any).transientPrivateKeyJwk) {
      privJwk = (ep as any).transientPrivateKeyJwk;
    }
    if (!privJwk && transientJwkMap.has(`${canonicalAgentId}:${ep.keyEpoch}:e2ee`)) {
      privJwk = transientJwkMap.get(`${canonicalAgentId}:${ep.keyEpoch}:e2ee`);
    }
    if (!idPrivJwk && transientJwkMap.has(`${canonicalAgentId}:${ep.keyEpoch}:identity`)) {
      idPrivJwk = transientJwkMap.get(`${canonicalAgentId}:${ep.keyEpoch}:identity`);
    }
    if (!idPrivJwk) {
      // Identity keys are often recycled/preserved across E2EE key epochs during rotation.
      // If a specific epoch does not have an identity key in the transient map, search the map
      // for any identity key belonging to this agent.
      for (const [k, v] of transientJwkMap.entries()) {
        if (k.startsWith(`${canonicalAgentId}:`) && k.endsWith(':identity')) {
          idPrivJwk = v;
          break;
        }
      }
    }

    if (!privJwk || !idPrivJwk) {
      if (ep.keyEpoch === activeEntry.keyEpoch) {
        throw new Error(`RECOVERY_VAULT_ERROR: Actual private key material for epoch ${ep.keyEpoch} is unavailable for backup.`);
      }
      // Legacy non-extractable historical epoch without prior vault: omit from vault rather than failing active epoch backup
      continue;
    }

    epochsData.push({
      keyEpoch: ep.keyEpoch,
      publicKey: ep.publicKey,
      privateKeyJwk: privJwk,
      fingerprint: ep.fingerprint,
      identityPublicKey: ep.identityPublicKey,
      identityPrivateKeyJwk: idPrivJwk,
      signature: ep.signature
    });
  }

  // Merge any historical epochs recovered from existingVault that weren't present locally
  for (const prevEp of preservedVaultEpochs) {
    if (
      prevEp?.keyEpoch &&
      prevEp?.privateKeyJwk &&
      !epochsData.some(e => Number(e.keyEpoch) === Number(prevEp.keyEpoch))
    ) {
      epochsData.push({
        keyEpoch: Number(prevEp.keyEpoch),
        publicKey: prevEp.publicKey,
        privateKeyJwk: prevEp.privateKeyJwk,
        fingerprint: prevEp.fingerprint,
        identityPublicKey: prevEp.identityPublicKey,
        identityPrivateKeyJwk: prevEp.identityPrivateKeyJwk,
        signature: prevEp.signature
      });
    }
  }
  epochsData.sort((a, b) => Number(a.keyEpoch || 0) - Number(b.keyEpoch || 0));

  // Active key JWK resolution
  const activeEpochData = epochsData.find(e => e.keyEpoch === activeEntry.keyEpoch);
  if (!activeEpochData || !activeEpochData.privateKeyJwk || !activeEpochData.identityPrivateKeyJwk) {
    throw new Error(`RECOVERY_VAULT_ERROR: Actual private key material for active epoch ${activeEntry.keyEpoch} is unavailable for backup.`);
  }

  let activePrivJwk: any = activeEpochData.privateKeyJwk;
  let activeIdPrivJwk: any = activeEpochData.identityPrivateKeyJwk;

  const payload = JSON.stringify({
    version: 1,
    agentId: canonicalAgentId,
    keyEpoch: activeEntry.keyEpoch,
    activeKey: {
      keyEpoch: activeEntry.keyEpoch,
      publicKey: activeEntry.publicKey,
      privateKeyJwk: activePrivJwk,
      fingerprint: activeEntry.fingerprint,
      identityPublicKey: activeEntry.identityPublicKey,
      identityPrivateKeyJwk: activeIdPrivJwk,
      signature: activeEntry.signature
    },
    epochs: epochsData,
    createdAt: new Date().toISOString()
  });

  const wrappingKey = await deriveKeyWrappingKey(canonicalAgentId, credential, 2);
  const nonce = cryptoObj.getRandomValues(new Uint8Array(12));
  const ciphertextBuffer = await cryptoObj.subtle.encrypt(
    { name: 'AES-GCM', iv: nonce },
    wrappingKey,
    new TextEncoder().encode(payload)
  );

  // Transient JWK references are retained for potential retry of the network upload in this session
  // and must be cleared explicitly via clearTransientJwkKeys(agentId) after successful upload.

  return {
    ciphertext: bufferToBase64(ciphertextBuffer),
    nonce: bufferToBase64(nonce.buffer),
    version: 1,
    kdfVersion: 2
  };
}

/**
 * Restores the EXACT active and historical E2EE key pairs on a new browser/device from the encrypted recovery artifact.
 * Performs atomic all-or-nothing recovery: decrypts, validates structure, imports all keys in memory, and persists
 * via a single atomic IndexedDB multi-store transaction only if all validation succeeds. Zero keys are written on failure.
 */
export async function restoreFromEncryptedRecoveryVault(
  agentId: string,
  credential: string,
  vault: { ciphertext: string; nonce: string; version?: number; kdfVersion?: number }
): Promise<{ activeKey: StoredAgentKeyEntry; restoredEpochCount: number }> {
  if (!vault || typeof vault !== 'object' || !vault.ciphertext || !vault.nonce) {
    throw new Error('INVALID_RECOVERY_VAULT: Vault must contain ciphertext and nonce.');
  }
  if (!credential || typeof credential !== 'string' || !credential.trim()) {
    throw new Error('RECOVERY_CREDENTIAL_REQUIRED: Recovery credential is required to decrypt recovery vault.');
  }

  const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;
  const canonicalAgentId = agentId.trim().toUpperCase();

  const nonceBytes = new Uint8Array(base64ToBuffer(vault.nonce));
  const ciphertextBytes = new Uint8Array(base64ToBuffer(vault.ciphertext));

  let decryptedBuffer: ArrayBuffer;
  const initialKdfVersion = vault.kdfVersion || 2;
  try {
    const wrappingKey = await deriveKeyWrappingKey(canonicalAgentId, credential, initialKdfVersion);
    decryptedBuffer = await cryptoObj.subtle.decrypt(
      { name: 'AES-GCM', iv: nonceBytes },
      wrappingKey,
      ciphertextBytes
    );
  } catch (err) {
    if (initialKdfVersion === 2) {
      try {
        const fallbackWrappingKey = await deriveKeyWrappingKey(canonicalAgentId, credential, 1);
        decryptedBuffer = await cryptoObj.subtle.decrypt(
          { name: 'AES-GCM', iv: nonceBytes },
          fallbackWrappingKey,
          ciphertextBytes
        );
      } catch (fallbackErr) {
        throw new Error('RECOVERY_DECRYPT_FAILED: Failed to decrypt recovery vault. Invalid credential or corrupted ciphertext.');
      }
    } else {
      throw new Error('RECOVERY_DECRYPT_FAILED: Failed to decrypt recovery vault. Invalid credential or corrupted ciphertext.');
    }
  }

  let payload: any;
  try {
    payload = JSON.parse(new TextDecoder().decode(decryptedBuffer));
  } catch {
    throw new Error('INVALID_VAULT_PAYLOAD: Decrypted recovery payload is not valid JSON.');
  }

  if (payload.agentId && payload.agentId.toUpperCase() !== canonicalAgentId) {
    throw new Error('RECOVERY_IDENTITY_MISMATCH: Recovered identity does not match current agent.');
  }

  const epochs: any[] = Array.isArray(payload.epochs) && payload.epochs.length > 0
    ? payload.epochs
    : (payload.activeKey ? [payload.activeKey] : []);

  if (epochs.length === 0) {
    throw new Error('RECOVERY_EMPTY_VAULT: No valid epochs found in recovery artifact.');
  }

  // ATOMIC VALIDATION PASS: Import and validate all keys in memory first.
  const preparedEntries: Array<{ entry: StoredAgentKeyEntry; privJwk: any; idPrivJwk: any }> = [];
  let lastActiveEntry: StoredAgentKeyEntry | null = null;

  for (const ep of epochs) {
    if (!ep || !ep.privateKeyJwk || !ep.publicKey) {
      throw new Error('INVALID_VAULT_EPOCH: Epoch missing required key material.');
    }

    const e2eePrivateKey = await cryptoObj.subtle.importKey(
      'jwk',
      ep.privateKeyJwk,
      KEY_ALGO,
      false, // extractable: false
      ['deriveKey', 'deriveBits']
    );

    let identityPrivateKey: CryptoKey | undefined = undefined;
    if (ep.identityPrivateKeyJwk) {
      identityPrivateKey = await cryptoObj.subtle.importKey(
        'jwk',
        ep.identityPrivateKeyJwk,
        SIGN_ALGO,
        false, // extractable: false
        ['sign']
      );
    }

    // CRYPTOGRAPHIC RELATIONSHIP VALIDATION:
    // 1. Verify ECDH exchange key-pair relationship
    try {
      const recExchangePubKey = await importCryptoKey(ep.publicKey, 'public', false);
      const ephemeralExchangePair = await cryptoObj.subtle.generateKey(KEY_ALGO, true, ['deriveKey', 'deriveBits']);
      
      const bits1 = await cryptoObj.subtle.deriveBits(
        { name: 'ECDH', public: ephemeralExchangePair.publicKey },
        e2eePrivateKey,
        256
      );
      const bits2 = await cryptoObj.subtle.deriveBits(
        { name: 'ECDH', public: recExchangePubKey },
        ephemeralExchangePair.privateKey,
        256
      );
      
      const buf1 = new Uint8Array(bits1);
      const buf2 = new Uint8Array(bits2);
      let bitsMatch = buf1.length === buf2.length;
      if (bitsMatch) {
        for (let i = 0; i < buf1.length; i++) {
          if (buf1[i] !== buf2[i]) {
            bitsMatch = false;
            break;
          }
        }
      }
      if (!bitsMatch) {
        throw new Error('Mismatched exchange key relationship.');
      }
    } catch (err) {
      throw new Error('INVALID_KEY_RELATIONSHIP: Recovered ECDH private key does not match its corresponding public key.');
    }

    // 2. Verify ECDSA signature key-pair relationship
    if (identityPrivateKey && ep.identityPublicKey) {
      try {
        const pubKey = await importSigningKey(ep.identityPublicKey, 'public', false);
        const testBuffer = new TextEncoder().encode('KeyRelationshipValidationChallenge');
        const signatureBytes = await cryptoObj.subtle.sign(
          { name: 'ECDSA', hash: { name: 'SHA-256' } },
          identityPrivateKey,
          testBuffer
        );
        const isValid = await cryptoObj.subtle.verify(
          { name: 'ECDSA', hash: { name: 'SHA-256' } },
          pubKey,
          signatureBytes,
          testBuffer
        );
        if (!isValid) {
          throw new Error('Mismatched signing signature.');
        }
      } catch (err) {
        throw new Error('INVALID_KEY_RELATIONSHIP: Recovered ECDSA private key does not match its corresponding public key.');
      }
    }

    const entry: StoredAgentKeyEntry = {
      publicKey: ep.publicKey,
      privateKey: e2eePrivateKey,
      fingerprint: ep.fingerprint || (await computeKeyFingerprint(ep.publicKey)),
      identityPublicKey: ep.identityPublicKey,
      identityPrivateKey,
      signature: ep.signature,
      keyEpoch: ep.keyEpoch || 1
    };

    preparedEntries.push({ entry, privJwk: ep.privateKeyJwk, idPrivJwk: ep.identityPrivateKeyJwk });

    if (!lastActiveEntry || entry.keyEpoch >= lastActiveEntry.keyEpoch) {
      lastActiveEntry = entry;
    }
  }

  if (payload.activeKey && payload.activeKey.privateKeyJwk) {
    const act = payload.activeKey;
    if (!lastActiveEntry || (act.keyEpoch || 1) >= lastActiveEntry.keyEpoch) {
      const e2eePrivateKey = await cryptoObj.subtle.importKey(
        'jwk',
        act.privateKeyJwk,
        KEY_ALGO,
        false,
        ['deriveKey', 'deriveBits']
      );
      let idPrivKey: CryptoKey | undefined = undefined;
      if (act.identityPrivateKeyJwk) {
        idPrivKey = await cryptoObj.subtle.importKey(
          'jwk',
          act.identityPrivateKeyJwk,
          SIGN_ALGO,
          false,
          ['sign']
        );
      }
      lastActiveEntry = {
        publicKey: act.publicKey,
        privateKey: e2eePrivateKey,
        fingerprint: act.fingerprint || (await computeKeyFingerprint(act.publicKey)),
        identityPublicKey: act.identityPublicKey,
        identityPrivateKey: idPrivKey,
        signature: act.signature,
        keyEpoch: act.keyEpoch || 1
      };
    }
  }

  if (!lastActiveEntry) {
    throw new Error('RECOVERY_EMPTY_VAULT: No valid active key found in recovery artifact.');
  }

  // ATOMIC PERSISTENCE PASS: Commit all keys in a single multi-store transaction or memory cache fallback.
  try {
    const db = await openKeyDatabase();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction([KEY_STORE_NAME, EPOCH_STORE_NAME], 'readwrite');
      const keyStore = tx.objectStore(KEY_STORE_NAME);
      const epochStore = tx.objectStore(EPOCH_STORE_NAME);
      const now = new Date().toISOString();

      keyStore.put({
        agentId: canonicalAgentId,
        publicKey: lastActiveEntry!.publicKey,
        privateKey: lastActiveEntry!.privateKey,
        fingerprint: lastActiveEntry!.fingerprint,
        identityPublicKey: lastActiveEntry!.identityPublicKey,
        identityPrivateKey: lastActiveEntry!.identityPrivateKey,
        signature: lastActiveEntry!.signature,
        keyEpoch: lastActiveEntry!.keyEpoch,
        updatedAt: now
      });

      for (const item of preparedEntries) {
        epochStore.put({
          id: `${canonicalAgentId}#epoch#${item.entry.keyEpoch}`,
          agentId: canonicalAgentId,
          keyEpoch: item.entry.keyEpoch,
          publicKey: item.entry.publicKey,
          privateKey: item.entry.privateKey,
          fingerprint: item.entry.fingerprint,
          identityPublicKey: item.entry.identityPublicKey,
          identityPrivateKey: item.entry.identityPrivateKey,
          signature: item.entry.signature,
          archivedAt: now
        });
      }

      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (idbErr) {
    console.warn('E2EE Keystore: IndexedDB unavailable or persistence failed, using memory cache fallback:', idbErr);
  }

  memoryKeyCache.set(canonicalAgentId, lastActiveEntry);
  for (const item of preparedEntries) {
    memoryEpochCache.set(`${canonicalAgentId}#epoch#${item.entry.keyEpoch}`, item.entry);
    if (item.privJwk) {
      transientJwkMap.set(`${canonicalAgentId}:${item.entry.keyEpoch}:e2ee`, item.privJwk);
    }
    if (item.idPrivJwk) {
      transientJwkMap.set(`${canonicalAgentId}:${item.entry.keyEpoch}:identity`, item.idPrivJwk);
    }
  }

  return {
    activeKey: lastActiveEntry,
    restoredEpochCount: preparedEntries.length
  };
}

/**
 * Re-encrypts an existing recovery vault with a new credential during password changes.
 * Preserves the complete historical key epoch history without losing any keys.
 */
export async function reEncryptRecoveryVaultWithNewCredential(
  agentId: string,
  oldCredential: string,
  newCredential: string,
  existingVault: { ciphertext: string; nonce: string; version?: number; kdfVersion?: number }
): Promise<{ ciphertext: string; nonce: string; version: number; kdfVersion?: number }> {
  const normalizedAgentId = agentId.trim().toUpperCase();

  // 1. Decrypt existing vault locally using oldCredential and restore all epochs into memory/transient map
  const restored = await restoreFromEncryptedRecoveryVault(normalizedAgentId, oldCredential, existingVault);

  // 2. Re-encrypt all historical and active epochs using newCredential with KDF version 2
  const updatedVault = await createEncryptedRecoveryVault(
    normalizedAgentId,
    newCredential,
    restored.activeKey.keyEpoch,
    existingVault
  );

  return updatedVault;
}

/**
 * Removes local key pair from keystore (e.g. on complete agent deletion)
 */
export async function removeLocalKeyPair(agentId: string): Promise<void> {
  const normalizedAgentId = agentId.trim().toUpperCase();
  memoryKeyCache.delete(normalizedAgentId);
  clearDerivedChannelKeyCache();
  for (const key of Array.from(memoryEpochCache.keys())) {
    if (key.startsWith(`${normalizedAgentId}#epoch#`)) {
      memoryEpochCache.delete(key);
    }
  }
  try {
    const db = await openKeyDatabase();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction([KEY_STORE_NAME, EPOCH_STORE_NAME], 'readwrite');
      const store = tx.objectStore(KEY_STORE_NAME);
      store.delete(normalizedAgentId);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (e) {
    console.warn('E2EE Keystore: Failed to delete key from IndexedDB:', e);
  }
}

/**
 * Retrieves pinned peer record from memory or IndexedDB
 */
export async function getPinnedPeerKey(peerAgentId: string): Promise<PinnedPeerEntry | null> {
  const normalizedPeerId = peerAgentId.trim().toUpperCase();
  if (memoryPinnedCache.has(normalizedPeerId)) {
    return memoryPinnedCache.get(normalizedPeerId)!;
  }

  try {
    const db = await openKeyDatabase();
    const pinned = await new Promise<PinnedPeerEntry | null>((resolve, reject) => {
      const tx = db.transaction(PINNED_STORE_NAME, 'readonly');
      const store = tx.objectStore(PINNED_STORE_NAME);
      const req = store.get(normalizedPeerId);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
    if (pinned) {
      memoryPinnedCache.set(normalizedPeerId, pinned);
    }
    return pinned;
  } catch (e) {
    console.warn('E2EE Pinning: IndexedDB pin read error:', e);
    return null;
  }
}

/**
 * Pins a peer agent's public key (TOFU - Trust On First Use)
 * First contact is UNVERIFIED by default unless isExplicitlyVerified is explicitly set.
 */
export async function pinPeerKey(
  peerAgentId: string,
  peerPublicKeyJwk: string,
  peerIdentityKeyJwk?: string,
  signature?: string,
  isExplicitlyVerified: boolean = false,
  keyEpoch: number = 1
): Promise<PinnedPeerEntry> {
  const normalizedPeerId = peerAgentId.trim().toUpperCase();
  const fingerprint = await computeKeyFingerprint(peerPublicKeyJwk);
  const now = new Date().toISOString();
  const epoch = typeof keyEpoch === 'number' && keyEpoch > 0 ? keyEpoch : 1;

  const existingPinned = memoryPinnedCache.get(normalizedPeerId) || await getPinnedPeerKey(normalizedPeerId);
  const epochKeys = existingPinned?.epochKeys ? { ...existingPinned.epochKeys } : {};
  epochKeys[String(epoch)] = {
    publicKey: peerPublicKeyJwk,
    fingerprint,
    identityKey: peerIdentityKeyJwk,
    signature,
    keyEpoch: epoch,
    pinnedAt: now
  };

  const samePinnedFingerprint = existingPinned?.fingerprint === fingerprint;
  const entry: PinnedPeerEntry = {
    peerAgentId: normalizedPeerId,
    fingerprint,
    publicKey: peerPublicKeyJwk,
    identityKey: peerIdentityKeyJwk,
    signature,
    keyEpoch: epoch,
    verified: isExplicitlyVerified || (samePinnedFingerprint ? Boolean(existingPinned?.verified) : false),
    verifiedAt: isExplicitlyVerified ? now : (samePinnedFingerprint ? existingPinned?.verifiedAt : undefined),
    pinnedAt: existingPinned?.pinnedAt || now,
    epochKeys
  };

  memoryPinnedCache.set(normalizedPeerId, entry);
  memoryPeerEpochCache.set(`${normalizedPeerId}#epoch#${epoch}`, epochKeys[String(epoch)]);

  try {
    const db = await openKeyDatabase();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(PINNED_STORE_NAME, 'readwrite');
      const store = tx.objectStore(PINNED_STORE_NAME);
      const req = store.put(entry);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (e) {
    console.warn('E2EE Pinning: IndexedDB pin write error:', e);
  }

  return entry;
}

/**
 * Explicitly marks a peer agent's key as cryptographically verified (e.g. after user confirms fingerprint out-of-band)
 */
export async function markPeerAsVerified(
  peerAgentId: string,
  fingerprint?: string
): Promise<PinnedPeerEntry> {
  const normalizedPeerId = peerAgentId.trim().toUpperCase();
  let pinned = await getPinnedPeerKey(normalizedPeerId);

  if (!pinned) {
    throw new Error(`Cannot verify peer ${peerAgentId}: No pinned key exists.`);
  }

  if (fingerprint && pinned.fingerprint !== fingerprint) {
    throw new Error(
      `Cannot verify peer ${peerAgentId}: Fingerprint mismatch! Expected ${pinned.fingerprint}, got ${fingerprint}.`
    );
  }

  const now = new Date().toISOString();
  pinned.verified = true;
  pinned.verifiedAt = now;

  memoryPinnedCache.set(normalizedPeerId, pinned);

  try {
    const db = await openKeyDatabase();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(PINNED_STORE_NAME, 'readwrite');
      const store = tx.objectStore(PINNED_STORE_NAME);
      const req = store.put(pinned);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (e) {
    console.warn('E2EE Pinning: IndexedDB verify write error:', e);
  }

  return pinned;
}

/**
 * Saves a historical public key for a peer for a specific epoch
 */
export async function savePeerEpochKey(
  peerAgentId: string,
  epoch: number,
  publicKey: string,
  fingerprint?: string,
  identityKey?: string,
  signature?: string
): Promise<void> {
  const normalizedPeerId = peerAgentId.trim().toUpperCase();
  const fp = fingerprint || (await computeKeyFingerprint(publicKey));
  const epochNum = typeof epoch === 'number' && epoch > 0 ? epoch : 1;
  const now = new Date().toISOString();

  const epochEntry: PinnedPeerEpochEntry = {
    publicKey,
    fingerprint: fp,
    identityKey,
    signature,
    keyEpoch: epochNum,
    pinnedAt: now
  };

  memoryPeerEpochCache.set(`${normalizedPeerId}#epoch#${epochNum}`, epochEntry);

  let pinned = await getPinnedPeerKey(normalizedPeerId);
  if (pinned) {
    if (!pinned.epochKeys) pinned.epochKeys = {};
    pinned.epochKeys[String(epochNum)] = epochEntry;
    memoryPinnedCache.set(normalizedPeerId, pinned);

    try {
      const db = await openKeyDatabase();
      await new Promise<void>((resolve, reject) => {
        const tx = db.transaction(PINNED_STORE_NAME, 'readwrite');
        const store = tx.objectStore(PINNED_STORE_NAME);
        const req = store.put(pinned);
        req.onsuccess = () => resolve();
        req.onerror = () => reject(req.error);
      });
    } catch (e) {
      console.warn('E2EE: Failed to update peer epoch in IndexedDB:', e);
    }
  }
}

/**
 * Retrieves a peer's public key for a specific epoch
 */
export async function getPeerEpochKey(
  peerAgentId: string,
  epoch: number
): Promise<PinnedPeerEpochEntry | null> {
  const normalizedPeerId = peerAgentId.trim().toUpperCase();
  const epochNum = typeof epoch === 'number' && epoch > 0 ? epoch : 1;
  const cacheKey = `${normalizedPeerId}#epoch#${epochNum}`;

  if (memoryPeerEpochCache.has(cacheKey)) {
    return memoryPeerEpochCache.get(cacheKey)!;
  }

  const pinned = await getPinnedPeerKey(normalizedPeerId);
  if (pinned?.epochKeys && pinned.epochKeys[String(epochNum)]) {
    const ep = pinned.epochKeys[String(epochNum)];
    memoryPeerEpochCache.set(cacheKey, ep);
    return ep;
  }

  return null;
}

/**
 * Resolves the public key for a sender/peer for a given epoch.
 * Strictly checks historical epoch mappings and local cache for the EXACT requested epoch.
 * Fails closed if the specific epoch key is not found (never substitutes keys from other epochs).
 */
export async function resolveSenderPublicKey(
  senderAgentId: string,
  epoch: number,
  peerEpochMap?: Record<string, any>,
  currentPeerKey?: string | null,
  currentPeerKeyEpoch?: number | null
): Promise<string | null> {
  const epochNum = typeof epoch === 'number' && epoch > 0 ? epoch : 1;

  // 1. Check peerEpochMap if provided by API (exact epoch match)
  if (peerEpochMap && Object.keys(peerEpochMap).length > 0) {
    const match = peerEpochMap[String(epochNum)] || peerEpochMap[epochNum];
    if (match?.publicKey) {
      return typeof match.publicKey === 'string' ? match.publicKey : JSON.stringify(match.publicKey);
    }
  }

  // 2. Check local peer epoch keystore (exact epoch match)
  const localEpochPeer = await getPeerEpochKey(senderAgentId, epochNum);
  if (localEpochPeer?.publicKey) {
    return typeof localEpochPeer.publicKey === 'string' ? localEpochPeer.publicKey : JSON.stringify(localEpochPeer.publicKey);
  }

  // 3. Check pinned peer (exact epoch match in epochKeys or pinned active keyEpoch)
  const pinned = await getPinnedPeerKey(senderAgentId);
  if (pinned && pinned.epochKeys && pinned.epochKeys[String(epochNum)]) {
    const epKey = pinned.epochKeys[String(epochNum)].publicKey;
    if (epKey) return typeof epKey === 'string' ? epKey : JSON.stringify(epKey);
  }
  if (pinned?.publicKey && (pinned.keyEpoch === epochNum || (!pinned.keyEpoch && epochNum === 1))) {
    return typeof pinned.publicKey === 'string' ? pinned.publicKey : JSON.stringify(pinned.publicKey);
  }

  // 4. Candidate fallback to currentPeerKey only if epoch matches or currentPeerKeyEpoch is unspecified
  if (currentPeerKey && (currentPeerKeyEpoch === undefined || currentPeerKeyEpoch === null || currentPeerKeyEpoch === epochNum)) {
    return typeof currentPeerKey === 'string' ? currentPeerKey : JSON.stringify(currentPeerKey);
  }

  // Exact epoch key not found: fail closed
  return null;
}

/**
 * Verifies peer agent's public key with explicit trust semantics:
 * 1. UNKNOWN -> UNVERIFIED on first contact (TOFU pinned, verified: false)
 * 2. UNVERIFIED -> VERIFIED after explicit verification (matching expectedFingerprint or markPeerAsVerified)
 * 3. KEY_CHANGED if key differs from pinned record (fails closed until explicit re-verification)
 */
export async function verifyPeerKey(
  peerAgentId: string,
  peerPublicKeyJwk: string,
  peerIdentityKeyJwk?: string | null,
  peerSignature?: string | null,
  expectedFingerprint?: string | null,
  keyEpoch: number = 1
): Promise<PeerVerificationResult> {
  const normalizedPeerId = peerAgentId.trim().toUpperCase();
  const currentFingerprint = await computeKeyFingerprint(peerPublicKeyJwk);

  // 1. Cryptographic Identity Signature Verification
  let identityVerified = false;
  if (peerIdentityKeyJwk && peerSignature) {
    const isSigValid = await verifyKeyBinding(peerIdentityKeyJwk, normalizedPeerId, currentFingerprint, peerSignature);
    if (!isSigValid) {
      throw new Error(
        `INVALID_KEY_SIGNATURE: Cryptographic identity verification failed for agent ${peerAgentId}. ` +
          `The public key was not signed by this agent's identity key. Potential spoofing or MITM attack.`
      );
    }
    identityVerified = true;
  }

  // 2. Check existing pinned record
  const pinned = await getPinnedPeerKey(normalizedPeerId);

  if (!pinned) {
    // FIRST CONTACT:
    // If expectedFingerprint was explicitly provided and matches, mark VERIFIED.
    // Otherwise, TOFU-pin as UNVERIFIED (verified: false).
    if (expectedFingerprint) {
      if (currentFingerprint !== expectedFingerprint) {
        throw new Error(
          `FIRST_CONTACT_VERIFICATION_FAILED: Peer agent (${peerAgentId}) public key does not match expected fingerprint! ` +
            `Expected ${expectedFingerprint}, but received ${currentFingerprint}. Transmission blocked.`
        );
      }
      await pinPeerKey(normalizedPeerId, peerPublicKeyJwk, peerIdentityKeyJwk || undefined, peerSignature || undefined, true, keyEpoch);
      return {
        verified: true,
        fingerprint: currentFingerprint,
        identityVerified,
        trustStatus: 'VERIFIED'
      };
    }

    // Normal first contact without explicit fingerprint comparison: UNVERIFIED
    await pinPeerKey(normalizedPeerId, peerPublicKeyJwk, peerIdentityKeyJwk || undefined, peerSignature || undefined, false, keyEpoch);
    return {
      verified: false,
      fingerprint: currentFingerprint,
      identityVerified,
      trustStatus: 'UNVERIFIED'
    };
  }

  // If pinned key has changed:
  if (pinned.fingerprint !== currentFingerprint) {
    if (expectedFingerprint && currentFingerprint === expectedFingerprint) {
      // User explicitly re-verified the key change!
      await pinPeerKey(normalizedPeerId, peerPublicKeyJwk, peerIdentityKeyJwk || undefined, peerSignature || undefined, true, keyEpoch);
      return {
        verified: true,
        fingerprint: currentFingerprint,
        identityVerified,
        trustStatus: 'VERIFIED',
        keyChanged: true
      };
    }

    throw new Error(
      `KEY_SUBSTITUTION_DETECTED: Peer agent (${peerAgentId}) public key has changed! ` +
        `Expected fingerprint ${pinned.fingerprint}, but received ${currentFingerprint}. ` +
        `Potential Man-In-The-Middle attack detected. Re-verification required.`
    );
  }

  // Key matches pinned fingerprint:
  // Check if explicit verification is being performed now
  if (expectedFingerprint && expectedFingerprint === currentFingerprint && !pinned.verified) {
    await markPeerAsVerified(normalizedPeerId, currentFingerprint);
    return {
      verified: true,
      fingerprint: currentFingerprint,
      identityVerified,
      trustStatus: 'VERIFIED'
    };
  }

  const isVerified = pinned.verified === true;
  return {
    verified: isVerified,
    fingerprint: currentFingerprint,
    identityVerified,
    trustStatus: isVerified ? 'VERIFIED' : 'UNVERIFIED'
  };
}

const importedPublicKeyCache = new Map<string, CryptoKey>();
const MAX_IMPORTED_PUBLIC_KEYS = 500;
const derivedChannelKeyCache = new Map<string, CryptoKey>();
const derivedAttachmentKeyCache = new Map<string, CryptoKey>();
const MAX_DERIVED_KEYS = 1000;

/**
 * Imports an ECDH JWK into a Web Crypto CryptoKey object (caches public CryptoKey imports)
 */
async function importCryptoKey(
  jwkOrKey: string | object | CryptoKey,
  type: 'public' | 'private',
  extractable = false
): Promise<CryptoKey> {
  if (typeof (jwkOrKey as any)?.algorithm === 'object') {
    return jwkOrKey as CryptoKey;
  }
  const cacheKey = type === 'public'
    ? `${extractable ? '1' : '0'}:${typeof jwkOrKey === 'string' ? jwkOrKey : JSON.stringify(jwkOrKey)}`
    : null;
  if (cacheKey && importedPublicKeyCache.has(cacheKey)) {
    return importedPublicKeyCache.get(cacheKey)!;
  }

  const jwk = typeof jwkOrKey === 'string' ? JSON.parse(jwkOrKey) : jwkOrKey;
  const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;
  const imported = await cryptoObj.subtle.importKey(
    'jwk',
    jwk,
    KEY_ALGO,
    extractable,
    type === 'private' ? ['deriveKey', 'deriveBits'] : []
  );

  if (cacheKey) {
    if (importedPublicKeyCache.size >= MAX_IMPORTED_PUBLIC_KEYS) {
      const oldestKey = importedPublicKeyCache.keys().next().value;
      if (oldestKey !== undefined) importedPublicKeyCache.delete(oldestKey);
    }
    importedPublicKeyCache.set(cacheKey, imported);
  }
  return imported;
}

/**
 * Imports an ECDSA JWK into a Web Crypto CryptoKey object
 */
async function importSigningKey(
  jwkOrKey: string | object | CryptoKey,
  type: 'public' | 'private',
  extractable = false
): Promise<CryptoKey> {
  if (typeof (jwkOrKey as any)?.algorithm === 'object') {
    return jwkOrKey as CryptoKey;
  }
  const jwk = typeof jwkOrKey === 'string' ? JSON.parse(jwkOrKey) : jwkOrKey;
  const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;
  return await cryptoObj.subtle.importKey(
    'jwk',
    jwk,
    SIGN_ALGO,
    extractable,
    type === 'private' ? ['sign'] : ['verify']
  );
}

const privateKeyCacheIds = new WeakMap<object, string>();
let privateKeyCounter = 0;

function getPrivateKeyId(priv: CryptoKey | string | object): string {
  if (typeof priv === 'string') return priv;
  if (typeof priv === 'object' && priv !== null) {
    if (!privateKeyCacheIds.has(priv)) {
      privateKeyCacheIds.set(priv, `pk_${++privateKeyCounter}`);
    }
    return privateKeyCacheIds.get(priv)!;
  }
  return String(priv);
}

export function clearDerivedChannelKeyCache(): void {
  derivedChannelKeyCache.clear();
  derivedAttachmentKeyCache.clear();
  importedPublicKeyCache.clear();
}

/**
 * Derives a symmetric AES-256-GCM channel key bound to connectionId using ECDH and HKDF.
 * Supports native non-exportable CryptoKey objects directly. Caches derived keys in memory.
 */
export async function deriveChannelKey(
  privateKey: CryptoKey | string,
  publicKeyJwk: string | object | CryptoKey,
  connectionId: string
): Promise<CryptoKey> {
  const pubStr = typeof publicKeyJwk === 'string'
    ? publicKeyJwk
    : (typeof publicKeyJwk === 'object' && publicKeyJwk !== null
        ? JSON.stringify(publicKeyJwk)
        : String(publicKeyJwk));
  const privId = getPrivateKeyId(privateKey);
  const cacheKey = `${connectionId}:${privId}:${pubStr}`;
  if (derivedChannelKeyCache.has(cacheKey)) {
    return derivedChannelKeyCache.get(cacheKey)!;
  }

  const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;
  const privKey = await importCryptoKey(privateKey, 'private', false);
  const pubKey = await importCryptoKey(publicKeyJwk, 'public', true);

  // 1. Derive 256 bits of shared secret using ECDH
  const sharedBits = await cryptoObj.subtle.deriveBits(
    { name: 'ECDH', public: pubKey },
    privKey,
    256
  );

  // 2. Import raw shared secret as HKDF master key
  const hkdfKey = await cryptoObj.subtle.importKey('raw', sharedBits, 'HKDF', false, ['deriveKey']);

  // 3. Derive AES-256-GCM symmetric key mathematically bound to connectionId
  const channelInfo = new TextEncoder().encode(`aamarva-channel:${connectionId}`);
  const channelKey = await cryptoObj.subtle.deriveKey(
    {
      name: 'HKDF',
      hash: 'SHA-256',
      salt: HKDF_SALT,
      info: channelInfo
    },
    hkdfKey,
    { name: ENC_ALGO, length: 256 },
    false,
    ['encrypt', 'decrypt']
  );

  if (derivedChannelKeyCache.size >= MAX_DERIVED_KEYS) {
    const oldestKey = derivedChannelKeyCache.keys().next().value;
    if (oldestKey !== undefined) derivedChannelKeyCache.delete(oldestKey);
  }
  derivedChannelKeyCache.set(cacheKey, channelKey);
  return channelKey;
}

export function bufferToBase64(buf: ArrayBuffer): string {
  if (typeof Buffer !== 'undefined') {
    return Buffer.from(buf).toString('base64');
  }
  const bytes = new Uint8Array(buf);
  const CHUNK_SIZE = 0x8000;
  let binary = '';
  for (let i = 0; i < bytes.length; i += CHUNK_SIZE) {
    const chunk = bytes.subarray(i, i + CHUNK_SIZE);
    binary += String.fromCharCode.apply(null, chunk as unknown as number[]);
  }
  return btoa(binary);
}

/**
 * Decodes a Base64 string into a binary ArrayBuffer.
 * CRITICAL: This is strictly a serialization/deserialization transport helper for binary
 * AES-256-GCM ciphertexts and nonces. It NEVER recovers plaintext by itself.
 * Actual message plaintext is recovered exclusively via WebCrypto crypto.subtle.decrypt().
 */
export function base64ToBuffer(b64: string): ArrayBuffer {
  if (!b64 || typeof b64 !== 'string') {
    return new ArrayBuffer(0);
  }
  // Sanitize: strip whitespace/newlines, convert URL-safe base64 (-/_), and restore missing '=' padding
  const sanitized = b64.replace(/\s+/g, '').replace(/-/g, '+').replace(/_/g, '/');
  let padded = sanitized;
  while (padded.length % 4 !== 0) {
    padded += '=';
  }
  if (typeof Buffer !== 'undefined') {
    const buf = Buffer.from(padded, 'base64');
    return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);
  }
  const binaryString = atob(padded);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes.buffer;
}


/**
 * Constructs Authenticated Associated Data (AAD) binding message to channel, version, and sender identity.
 * Canonical format: AAMARVA:E2EE:v1:<connectionId>:<senderAgentId>
 */
export function constructAAD(
  connectionId: string,
  _version: number = 1,
  senderAgentId: string = '',
  _keyEpoch: number = 1
): Uint8Array {
  const cId = (connectionId || '').trim();
  const sId = normalizeAgentId(senderAgentId);
  return new TextEncoder().encode(`AAMARVA:E2EE:v1:${cId}:${sId}`);
}

/**
 * Encrypts a private-channel message locally before transmission.
 * Returns only ciphertext, nonce, version, and keyEpoch.
 */
export async function encryptMessage(
  message: string,
  senderPrivateKey: CryptoKey | string,
  receiverPublicKeyJwk: string | object | CryptoKey,
  connectionId: string,
  senderAgentId: string,
  keyEpoch: number = 1
): Promise<{ ciphertext: string; nonce: string; version: number; keyEpoch: number }> {
  if (!message || typeof message !== 'string') {
    throw new Error('E2EE Error: Message content cannot be empty.');
  }
  if (!senderPrivateKey || !receiverPublicKeyJwk) {
    throw new Error('E2EE Error: Missing cryptographic key pair for channel encryption.');
  }

  const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;
  const channelKey = await deriveChannelKey(senderPrivateKey, receiverPublicKeyJwk, connectionId);

  // Generate cryptographically secure 12-byte random IV
  const iv = cryptoObj.getRandomValues(new Uint8Array(12));
  const version = 1;
  const epoch = typeof keyEpoch === 'number' && keyEpoch > 0 ? keyEpoch : 1;
  const additionalData = constructAAD(connectionId, version, senderAgentId, epoch);

  const encodedPlaintext = new TextEncoder().encode(message);
  const ciphertextBuf = await cryptoObj.subtle.encrypt(
    {
      name: ENC_ALGO,
      iv,
      additionalData
    },
    channelKey,
    encodedPlaintext
  );

  return {
    ciphertext: bufferToBase64(ciphertextBuf),
    nonce: bufferToBase64(iv.buffer),
    version,
    keyEpoch: epoch
  };
}

/**
 * Decrypts a private-channel message locally.
 * Throws an E2EEDecryptionError on authentication failure (tampering, wrong key, wrong epoch, or wrong channel).
 */
export async function decryptMessage(
  encryptedPayload: { ciphertext: string; nonce: string; version?: number; keyEpoch?: number },
  receiverPrivateKey: CryptoKey | string,
  senderPublicKeyJwk: string | object | CryptoKey,
  connectionId: string,
  senderAgentId: string
): Promise<string> {
  if (!encryptedPayload) {
    throw new E2EEDecryptionError('MISSING_PAYLOAD', 'E2EE Error: Invalid encrypted payload. Ciphertext and nonce are required.');
  }
  if (!encryptedPayload.ciphertext || typeof encryptedPayload.ciphertext !== 'string' || encryptedPayload.ciphertext.trim().length === 0) {
    throw new E2EEDecryptionError('INVALID_CIPHERTEXT', 'E2EE Error: Ciphertext is missing or invalid.');
  }
  if (!encryptedPayload.nonce || typeof encryptedPayload.nonce !== 'string' || encryptedPayload.nonce.trim().length === 0) {
    throw new E2EEDecryptionError('INVALID_NONCE', 'E2EE Error: Nonce is missing or invalid.');
  }
  if (!receiverPrivateKey) {
    throw new E2EEDecryptionError('MISSING_RECIPIENT_PRIVATE_KEY', 'E2EE Error: Missing recipient private key required for decryption.');
  }
  if (!senderPublicKeyJwk) {
    throw new E2EEDecryptionError('MISSING_SENDER_PUBLIC_KEY', 'E2EE Error: Missing sender public key required for decryption.');
  }

  const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;
  
  let channelKey: CryptoKey;
  try {
    channelKey = await deriveChannelKey(receiverPrivateKey, senderPublicKeyJwk, connectionId);
  } catch (err: any) {
    throw new E2EEDecryptionError('ECDH_DERIVATION_FAILED', `E2EE Error: Key derivation failed: ${err?.message || String(err)}`);
  }

  let ivBuf: ArrayBuffer;
  try {
    ivBuf = base64ToBuffer(encryptedPayload.nonce);
    if (ivBuf.byteLength !== 12) {
      throw new Error('Nonce length is not 12 bytes');
    }
  } catch {
    throw new E2EEDecryptionError('INVALID_NONCE', 'E2EE Error: Failed to decode 12-byte initialization vector.');
  }

  let ciphertextBuf: ArrayBuffer;
  try {
    ciphertextBuf = base64ToBuffer(encryptedPayload.ciphertext);
    if (ciphertextBuf.byteLength === 0) {
      throw new Error('Ciphertext buffer is empty');
    }
  } catch {
    throw new E2EEDecryptionError('INVALID_CIPHERTEXT', 'E2EE Error: Failed to decode ciphertext payload.');
  }

  const version = encryptedPayload.version || 1;
  const keyEpoch = encryptedPayload.keyEpoch || 1;

  // Primary canonical AAD
  const primaryAAD = constructAAD(connectionId, version, senderAgentId, keyEpoch);

  // Robust candidate list to handle both canonical AAD and legacy JSON variations without weakening security
  const cId = (connectionId || '').trim();
  const sIdNormalized = normalizeAgentId(senderAgentId);
  const sIdRaw = (senderAgentId || '').trim().toUpperCase();

  const aadCandidates: Uint8Array[] = [
    primaryAAD,
    new TextEncoder().encode(`AAMARVA:E2EE:v1:${cId}:${sIdRaw}`),
    new TextEncoder().encode(`AAMARVA:E2EE:v1:${cId}:${sIdNormalized}`),
    new TextEncoder().encode(`AAMARVA:E2EE:v1:${cId}:`),
    new TextEncoder().encode(`AAMARVA:E2EE:v1:${cId}:${sIdNormalized.toLowerCase()}`),
    new TextEncoder().encode(JSON.stringify({ connectionId: cId, version, keyEpoch, senderAgentId: sIdNormalized })),
    new TextEncoder().encode(JSON.stringify({ connectionId: cId, version, keyEpoch, senderAgentId: sIdRaw })),
    new TextEncoder().encode(`AAMARVA:E2EE:v1:${cId}:${sIdNormalized}:epoch:${keyEpoch}`)
  ];

  let decryptedBuf: ArrayBuffer | null = null;
  let lastErr: any = null;

  for (const candidateAAD of aadCandidates) {
    try {
      decryptedBuf = await cryptoObj.subtle.decrypt(
        {
          name: ENC_ALGO,
          iv: new Uint8Array(ivBuf),
          additionalData: candidateAAD
        },
        channelKey,
        ciphertextBuf
      );
      if (decryptedBuf) break;
    } catch (err: any) {
      lastErr = err;
    }
  }

  if (!decryptedBuf) {
    throw new E2EEDecryptionError(
      'AUTHENTICATION_TAG_FAILED',
      `E2EE Error: AES-GCM authentication verification failed (${lastErr?.message || 'Ciphertext or AAD tag mismatch'}).`
    );
  }

  return new TextDecoder().decode(decryptedBuf);
}

const RECOVERY_VAULT_STASH_PREFIX = 'aamarva_e2ee_vault_backup:';

export function stashEncryptedRecoveryVault(
  agentId: string,
  vault: { ciphertext: string; nonce: string; version: number; kdfVersion?: number }
): void {
  if (typeof localStorage === 'undefined' || !agentId || !vault?.ciphertext || !vault?.nonce) return;
  try {
    const key = `${RECOVERY_VAULT_STASH_PREFIX}${normalizeAgentId(agentId)}`;
    localStorage.setItem(key, JSON.stringify(vault));
  } catch {}
}

export function getStashedEncryptedRecoveryVault(
  agentId: string
): { ciphertext: string; nonce: string; version: number; kdfVersion?: number } | null {
  if (typeof localStorage === 'undefined' || !agentId) return null;
  try {
    const key = `${RECOVERY_VAULT_STASH_PREFIX}${normalizeAgentId(agentId)}`;
    const raw = localStorage.getItem(key);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed.ciphertext === 'string' && typeof parsed.nonce === 'string') {
      return parsed;
    }
  } catch {}
  return null;
}

export function clearStashedEncryptedRecoveryVault(agentId: string): void {
  if (typeof localStorage === 'undefined' || !agentId) return;
  try {
    localStorage.removeItem(`${RECOVERY_VAULT_STASH_PREFIX}${normalizeAgentId(agentId)}`);
  } catch {}
}

/**
 * Ensures an agent has a local cryptographic identity in protected storage.
 * If identity exists, retrieves it; if not, generates a new one.
 * Never generates a replacement if a valid identity already exists.
 */
export async function bootstrapAgentIdentity(
  agentId: string,
  credential?: string
): Promise<{ identity: StoredAgentKeyEntry; isNew: boolean }> {
  const normalizedAgentId = normalizeAgentId(agentId);
  
  // 1. Check for existing identity
  const existing = await getLocalKeyPair(normalizedAgentId, undefined, credential);
  if (existing && existing.privateKey) {
    return { identity: existing, isNew: false };
  }

  // 2. Generate new independently random cryptographic identity
  const newIdentity = await generateAgentCryptoIdentity(normalizedAgentId);
  
  // 3. Persist private key locally
  await saveLocalKeyPair(
    normalizedAgentId,
    newIdentity.e2eePublicKey,
    newIdentity.e2eePrivateKey,
    newIdentity.fingerprint,
    newIdentity.identityPublicKey,
    newIdentity.identityPrivateKey,
    newIdentity.signature,
    newIdentity.keyEpoch,
    newIdentity.transientPrivateKeyJwk,
    newIdentity.transientIdentityPrivateKeyJwk
  );

  // If credential is provided (e.g. during registration before email verification or reload),
  // immediately create and stash the zero-knowledge encrypted recovery vault locally so
  // the first authenticated login can upload it even after a page reload.
  if (credential && credential.trim()) {
    try {
      const stashedVault = await createEncryptedRecoveryVault(normalizedAgentId, credential);
      stashEncryptedRecoveryVault(normalizedAgentId, stashedVault);
    } catch {}
  }
  
  // Convert AgentCryptoIdentity to StoredAgentKeyEntry
  const identity: StoredAgentKeyEntry = {
    publicKey: newIdentity.e2eePublicKey,
    privateKey: newIdentity.e2eePrivateKey,
    fingerprint: newIdentity.fingerprint,
    identityPublicKey: newIdentity.identityPublicKey,
    identityPrivateKey: newIdentity.identityPrivateKey,
    signature: newIdentity.signature,
    keyEpoch: newIdentity.keyEpoch
  };
  
  return { identity, isNew: true };
}

/**
 * Maps the E2EE status code and identity state to a server-side registration payload.
 */
export function constructIdentityRegistrationPayload(identity: StoredAgentKeyEntry) {
  return {
    publicKey: identity.publicKey,
    fingerprint: identity.fingerprint,
    identityKey: identity.identityPublicKey,
    signature: identity.signature,
    keyEpoch: identity.keyEpoch,
    allowRotation: false
  };
}

export interface FormattedDecryptionStatus {
  title: string;
  detail?: string;
  explanation?: string;
}

/**
 * Maps internal E2EE decryption error codes to clear, non-leaking user-facing status indicators.
 * Retains safe generic lock fallback while providing actionable status.
 */
export function formatDecryptionErrorStatus(
  errorCode?: E2EEDecryptionErrorCode | string | null
): FormattedDecryptionStatus {
  switch (errorCode) {
    case 'MISSING_SENDER_PUBLIC_KEY':
      return {
        title: 'Cannot be decrypted because the peer has not published their E2EE public key',
        detail: "Waiting for peer's encryption key",
        explanation: 'The other agent has not published its E2EE public key via PUT /api/agents/me/e2ee yet.'
      };
    case 'MISSING_RECIPIENT_PRIVATE_KEY':
      return {
        title: 'Cannot be decrypted because the recipient private key is missing on this device',
        detail: 'Enter account password above to restore encryption keys',
        explanation: 'Operational keys missing on this device. Restore keys to view message.'
      };
    case 'KEY_EPOCH_NOT_FOUND':
      return {
        title: 'Cannot be decrypted because the historical encryption key for this epoch is unavailable',
        detail: 'Older encryption key epoch unavailable',
        explanation: 'The historical encryption key for this epoch is not stored in the local key store.'
      };
    case 'AUTHENTICATION_TAG_FAILED':
      return {
        title: 'Cannot be decrypted because the AES-GCM authentication tag verification failed (bit-flip / payload modified)',
        detail: 'Cryptographic authentication tag mismatch',
        explanation: 'Ciphertext integrity check failed. The payload was corrupted or modified in transit.'
      };
    case 'AAD_MISMATCH':
      return {
        title: 'Cannot be decrypted because the Additional Authenticated Data (AAD) channel binding does not match',
        detail: 'Channel binding AAD mismatch',
        explanation: 'Message was encrypted with a different channel or sender identity binding context.'
      };
    case 'INVALID_CIPHERTEXT':
      return {
        title: 'Cannot be decrypted because the ciphertext payload is malformed or invalid Base64',
        detail: 'Malformed ciphertext envelope',
        explanation: 'Ciphertext string is not valid Base64 or is truncated.'
      };
    case 'INVALID_NONCE':
      return {
        title: 'Cannot be decrypted because the cryptographic nonce is invalid or not 12 bytes',
        detail: 'Invalid initialization vector (nonce)',
        explanation: 'Nonce must be exactly 12 bytes (96 bits) of random entropy.'
      };
    case 'ECDH_DERIVATION_FAILED':
    case 'HKDF_DERIVATION_FAILED':
    default:
      return {
        title: 'Cannot be decrypted because cryptographic verification failed',
        detail: 'Message integrity verification failed',
        explanation: 'Cryptographic message authentication could not be verified.'
      };
  }
}

export interface StoredClusterGroupKeyEntry {
  id: string; // `${clusterId}:${epoch}`
  clusterId: string;
  epoch: number;
  key: CryptoKey;
  rawKeyBase64?: string;
  fingerprint?: string;
  audienceHash?: string;
  createdAt: string;
}

export const memoryClusterGroupKeyCache = new Map<string, StoredClusterGroupKeyEntry>();

function buildClusterGroupKeyStorageId(clusterId: string, epoch: number, audienceHash?: string): string {
  const cId = (clusterId || '').trim();
  const aud = (audienceHash || '').trim();
  if (aud && aud !== 'ALL') {
    return `${cId}:${epoch}:${aud}`;
  }
  return `${cId}:${epoch}`;
}

/**
 * Persists a cluster group key in memory cache and protected IndexedDB storage (cluster_group_keys)
 */
export async function saveClusterGroupKey(
  clusterId: string,
  epoch: number,
  groupKey: CryptoKey | Uint8Array | string,
  fingerprint?: string,
  audienceHash?: string
): Promise<void> {
  const cId = (clusterId || '').trim();
  if (!cId) throw new Error('Cluster ID cannot be empty.');
  if (typeof epoch !== 'number' || !Number.isFinite(epoch) || epoch < 1) {
    throw new Error('Key epoch must be a positive integer >= 1.');
  }

  const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;
  let opKey: CryptoKey;
  let rawBase64: string | undefined;

  if (typeof groupKey === 'string') {
    rawBase64 = groupKey.trim();
    const rawBuf = base64ToBuffer(rawBase64);
    opKey = await cryptoObj.subtle.importKey(
      'raw',
      rawBuf,
      { name: ENC_ALGO, length: 256 },
      true,
      ['encrypt', 'decrypt']
    );
  } else if (groupKey instanceof Uint8Array || groupKey instanceof ArrayBuffer) {
    const u8 = groupKey instanceof Uint8Array ? groupKey : new Uint8Array(groupKey);
    rawBase64 = bufferToBase64(u8.buffer);
    opKey = await cryptoObj.subtle.importKey(
      'raw',
      u8,
      { name: ENC_ALGO, length: 256 },
      true,
      ['encrypt', 'decrypt']
    );
  } else {
    opKey = groupKey;
    try {
      const exp = await cryptoObj.subtle.exportKey('raw', opKey);
      rawBase64 = bufferToBase64(exp);
    } catch {}
  }

  let fp = fingerprint;
  if (!fp && rawBase64) {
    const rawBuf = base64ToBuffer(rawBase64);
    const digestBuf = await cryptoObj.subtle.digest('SHA-256', rawBuf);
    const hex = Array.from(new Uint8Array(digestBuf))
      .map((b) => b.toString(16).padStart(2, '0'))
      .join(':')
      .toUpperCase();
    fp = `SHA256:${hex}`;
  }

  const normalizedAud = audienceHash && audienceHash.trim() && audienceHash.trim() !== 'ALL' ? audienceHash.trim() : 'ALL';
  const id = buildClusterGroupKeyStorageId(cId, epoch, normalizedAud);
  const now = new Date().toISOString();
  const entry: StoredClusterGroupKeyEntry = {
    id,
    clusterId: cId,
    epoch,
    key: opKey,
    rawKeyBase64: rawBase64,
    fingerprint: fp,
    audienceHash: normalizedAud,
    createdAt: now
  };

  memoryClusterGroupKeyCache.set(id, entry);

  try {
    const db = await openKeyDatabase();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(CLUSTER_GROUP_KEY_STORE_NAME, 'readwrite');
      const store = tx.objectStore(CLUSTER_GROUP_KEY_STORE_NAME);
      store.put({
        id,
        clusterId: cId,
        epoch,
        rawKeyBase64: rawBase64,
        fingerprint: fp,
        audienceHash: normalizedAud,
        createdAt: now
      });
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (e) {
    // Fallback to memory cache
  }
}

/**
 * Retrieves the full stored cluster group key entry (including fingerprint and raw key)
 * from memory cache or protected IndexedDB storage (cluster_group_keys)
 */
export async function getClusterGroupKeyEntry(
  clusterId: string,
  epoch: number,
  audienceHash?: string
): Promise<StoredClusterGroupKeyEntry | null> {
  const cId = (clusterId || '').trim();
  const normalizedAud = audienceHash && audienceHash.trim() && audienceHash.trim() !== 'ALL' ? audienceHash.trim() : 'ALL';
  const id = buildClusterGroupKeyStorageId(cId, epoch, normalizedAud);

  if (memoryClusterGroupKeyCache.has(id)) {
    return memoryClusterGroupKeyCache.get(id)!;
  }

  try {
    const db = await openKeyDatabase();
    const stored = await new Promise<any>((resolve, reject) => {
      const tx = db.transaction(CLUSTER_GROUP_KEY_STORE_NAME, 'readonly');
      const store = tx.objectStore(CLUSTER_GROUP_KEY_STORE_NAME);
      const req = store.get(id);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });

    if (stored) {
      const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;
      let key = stored.key;
      if (!key && stored.rawKeyBase64) {
        const rawBuf = base64ToBuffer(stored.rawKeyBase64);
        key = await cryptoObj.subtle.importKey(
          'raw',
          rawBuf,
          { name: ENC_ALGO, length: 256 },
          true,
          ['encrypt', 'decrypt']
        );
      }
      if (key) {
        const entry: StoredClusterGroupKeyEntry = {
          id,
          clusterId: cId,
          epoch,
          key,
          rawKeyBase64: stored.rawKeyBase64,
          fingerprint: stored.fingerprint,
          audienceHash: stored.audienceHash || normalizedAud,
          createdAt: stored.createdAt || new Date().toISOString()
        };
        memoryClusterGroupKeyCache.set(id, entry);
        return entry;
      }
    }
  } catch (e) {}

  return null;
}

/**
 * Retrieves a cluster group key from memory cache or protected IndexedDB storage (cluster_group_keys).
 * If expectedFingerprint is provided, validates that the cached key's fingerprint matches.
 * If the fingerprint does not match, automatically evicts the stale key from both memory cache
 * and IndexedDB to prevent decryption authentication failures.
 */
export async function getClusterGroupKey(
  clusterId: string,
  epoch: number,
  expectedFingerprint?: string,
  audienceHash?: string
): Promise<CryptoKey | null> {
  const entry = await getClusterGroupKeyEntry(clusterId, epoch, audienceHash);
  if (!entry) return null;

  if (expectedFingerprint) {
    if (!entry.fingerprint || entry.fingerprint !== expectedFingerprint) {
      // Stale, missing, or mismatched key detected. Evict from memory and persistent storage.
      await deleteClusterGroupKey(clusterId, epoch, audienceHash);
      return null;
    }
  }

  return entry.key;
}

/**
 * Checks whether the cluster group key for a given epoch is available locally
 */
export async function hasClusterGroupKey(
  clusterId: string,
  epoch: number,
  audienceHash?: string
): Promise<boolean> {
  const key = await getClusterGroupKey(clusterId, epoch, undefined, audienceHash);
  return key !== null;
}

/**
 * Deletes a cluster group key from memory cache and IndexedDB
 */
export async function deleteClusterGroupKey(
  clusterId: string,
  epoch: number,
  audienceHash?: string
): Promise<void> {
  const cId = (clusterId || '').trim();
  const id = buildClusterGroupKeyStorageId(cId, epoch, audienceHash);
  memoryClusterGroupKeyCache.delete(id);
  try {
    const db = await openKeyDatabase();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(CLUSTER_GROUP_KEY_STORE_NAME, 'readwrite');
      const store = tx.objectStore(CLUSTER_GROUP_KEY_STORE_NAME);
      store.delete(id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (e) {}
}

// ============================================================================
// SERVER-BLIND END-TO-END ENCRYPTED ATTACHMENT SUBSYSTEM
// ============================================================================

export interface EncryptedAttachmentPayload {
  attachmentId: string;
  ciphertext: string; // Base64 encoded AES-256-GCM encrypted envelope
  nonce: string; // Base64 encoded 12-byte IV
  version: number;
  keyEpoch: number;
  ciphertextSize: number;
}

export interface DecryptedAttachmentFile {
  attachmentId: string;
  filename: string;
  mimeType: string;
  size: number;
  data: Uint8Array;
  blob: Blob;
  checksum: string;
  timestamp: string;
}

export interface AttachmentFileInput {
  name: string;
  type?: string;
  size?: number;
  arrayBuffer?: () => Promise<ArrayBuffer>;
  data?: Uint8Array | ArrayBuffer;
}

/**
 * Constructs Authenticated Associated Data (AAD) binding an attachment to connection,
 * sender, attachment identifier, and key epoch.
 * Canonical format: AAMARVA:E2EE:ATTACHMENT:v1:<connectionId>:<senderAgentId>:<attachmentId>:<keyEpoch>
 */
export function constructAttachmentAAD(
  connectionId: string,
  _version: number = 1,
  senderAgentId: string = '',
  keyEpoch: number = 1,
  attachmentId: string = ''
): Uint8Array {
  const cId = (connectionId || '').trim();
  const sId = normalizeAgentId(senderAgentId);
  const aId = (attachmentId || '').trim();
  return new TextEncoder().encode(`AAMARVA:E2EE:ATTACHMENT:v1:${cId}:${sId}:${aId}:${keyEpoch}`);
}

/**
 * Derives a domain-separated 256-bit AES-GCM channel key specifically for attachments.
 * Info string: 'aamarva-channel-attachment:<connectionId>'
 */
export async function deriveAttachmentChannelKey(
  privateKey: CryptoKey | string,
  publicKeyJwk: string | object | CryptoKey,
  connectionId: string,
  customInfoStr?: string
): Promise<CryptoKey> {
  const infoStr = customInfoStr || `aamarva-channel-attachment:${(connectionId || '').trim()}`;
  const pubStr = typeof publicKeyJwk === 'string'
    ? publicKeyJwk
    : (typeof publicKeyJwk === 'object' && publicKeyJwk !== null
        ? JSON.stringify(publicKeyJwk)
        : String(publicKeyJwk));
  const privId = getPrivateKeyId(privateKey);
  const cacheKey = `${infoStr}:${privId}:${pubStr}`;
  if (derivedAttachmentKeyCache.has(cacheKey)) {
    return derivedAttachmentKeyCache.get(cacheKey)!;
  }

  const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;
  const privKey = await importCryptoKey(privateKey, 'private', false);
  const pubKey = await importCryptoKey(publicKeyJwk, 'public', true);

  // 1. Derive 256 bits of shared secret using ECDH
  const sharedBits = await cryptoObj.subtle.deriveBits(
    { name: 'ECDH', public: pubKey },
    privKey,
    256
  );

  const hkdfKey = await cryptoObj.subtle.importKey(
    'raw',
    sharedBits,
    { name: 'HKDF' },
    false,
    ['deriveKey']
  );

  const attachmentInfo = new TextEncoder().encode(infoStr);

  const derivedKey = await cryptoObj.subtle.deriveKey(
    {
      name: 'HKDF',
      hash: 'SHA-256',
      salt: HKDF_SALT,
      info: attachmentInfo
    },
    hkdfKey,
    { name: ENC_ALGO, length: 256 },
    false,
    ['encrypt', 'decrypt']
  );

  if (derivedAttachmentKeyCache.size >= MAX_DERIVED_KEYS) {
    const oldestKey = derivedAttachmentKeyCache.keys().next().value;
    if (oldestKey !== undefined) derivedAttachmentKeyCache.delete(oldestKey);
  }
  derivedAttachmentKeyCache.set(cacheKey, derivedKey);
  return derivedKey;
}

/**
 * Encrypts an attachment file locally on the client's device using P-256 ECDH,
 * HKDF domain-separated key derivation, and authenticated AES-256-GCM.
 * The server never receives plaintext file data, filenames, or MIME types.
 */
export async function encryptAttachmentFile(
  fileInput: AttachmentFileInput,
  senderPrivateKey: CryptoKey | string,
  receiverPublicKeyJwk: string | object | CryptoKey,
  connectionId: string,
  senderAgentId: string,
  keyEpoch: number = 1,
  explicitAttachmentId?: string
): Promise<EncryptedAttachmentPayload> {
  if (!fileInput) {
    throw new Error('E2EE Error: File input cannot be null or undefined.');
  }

  let rawBytes: Uint8Array;
  if (fileInput.data instanceof Uint8Array) {
    rawBytes = fileInput.data;
  } else if (fileInput.data instanceof ArrayBuffer) {
    rawBytes = new Uint8Array(fileInput.data);
  } else if (typeof fileInput.arrayBuffer === 'function') {
    const ab = await fileInput.arrayBuffer();
    rawBytes = new Uint8Array(ab);
  } else {
    throw new Error('E2EE Error: File data must provide an ArrayBuffer or Uint8Array.');
  }

  const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;

  // 1. Compute SHA-256 integrity checksum of raw plaintext bytes
  const checksumBuf = await cryptoObj.subtle.digest('SHA-256', rawBytes);
  const checksumHex = Array.from(new Uint8Array(checksumBuf))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');

  // 2. Derive domain-separated attachment encryption key
  const attachmentKey = await deriveAttachmentChannelKey(senderPrivateKey, receiverPublicKeyJwk, connectionId);

  // 3. Generate opaque unique attachment identifier
  const randomBytes = cryptoObj.getRandomValues(new Uint8Array(16));
  const attachmentId = explicitAttachmentId || `att_${Array.from(randomBytes).map((b) => b.toString(16).padStart(2, '0')).join('')}`;

  // 4. Construct envelope hiding filename, MIME type, size, and checksum inside ciphertext
  const envelope = {
    filename: fileInput.name || 'attachment.bin',
    mimeType: fileInput.type || 'application/octet-stream',
    size: fileInput.size !== undefined ? fileInput.size : rawBytes.byteLength,
    checksum: checksumHex,
    data: bufferToBase64(rawBytes.buffer.slice(rawBytes.byteOffset, rawBytes.byteOffset + rawBytes.byteLength)),
    timestamp: new Date().toISOString()
  };

  const encodedEnvelope = new TextEncoder().encode(JSON.stringify(envelope));

  // 5. Generate cryptographically secure 12-byte random IV
  const iv = cryptoObj.getRandomValues(new Uint8Array(12));
  const version = 1;
  const epoch = typeof keyEpoch === 'number' && keyEpoch > 0 ? keyEpoch : 1;
  const additionalData = constructAttachmentAAD(connectionId, version, senderAgentId, epoch, attachmentId);

  // 6. Encrypt envelope with authenticated AES-256-GCM
  const ciphertextBuf = await cryptoObj.subtle.encrypt(
    {
      name: ENC_ALGO,
      iv,
      additionalData
    },
    attachmentKey,
    encodedEnvelope
  );

  return {
    attachmentId,
    ciphertext: bufferToBase64(ciphertextBuf),
    nonce: bufferToBase64(iv.buffer),
    version,
    keyEpoch: epoch,
    ciphertextSize: ciphertextBuf.byteLength
  };
}

/**
 * Decrypts an encrypted attachment locally on the recipient's device.
 * Enforces AES-256-GCM authentication verification and rejects any corrupted or tampered ciphertext.
 * Never falls back to plaintext.
 */
export async function decryptAttachmentFile(
  encryptedPayload: {
    attachmentId: string;
    ciphertext: string;
    nonce: string;
    version?: number;
    keyEpoch?: number;
  },
  receiverPrivateKey: CryptoKey | string,
  senderPublicKeyJwk: string | object | CryptoKey,
  connectionId: string,
  senderAgentId: string
): Promise<DecryptedAttachmentFile> {
  if (!encryptedPayload) {
    throw new E2EEDecryptionError('MISSING_PAYLOAD', 'E2EE Error: Invalid encrypted attachment payload.');
  }
  if (!encryptedPayload.ciphertext || typeof encryptedPayload.ciphertext !== 'string' || !encryptedPayload.ciphertext.trim()) {
    throw new E2EEDecryptionError('INVALID_CIPHERTEXT', 'E2EE Error: Encrypted attachment ciphertext is missing or invalid.');
  }
  if (!encryptedPayload.nonce || typeof encryptedPayload.nonce !== 'string' || !encryptedPayload.nonce.trim()) {
    throw new E2EEDecryptionError('INVALID_NONCE', 'E2EE Error: Encrypted attachment nonce is missing or invalid.');
  }
  if (!receiverPrivateKey) {
    throw new E2EEDecryptionError('MISSING_RECIPIENT_PRIVATE_KEY', 'E2EE Error: Missing recipient private key required for decryption.');
  }
  if (!senderPublicKeyJwk) {
    throw new E2EEDecryptionError('MISSING_SENDER_PUBLIC_KEY', 'E2EE Error: Missing sender public key required for decryption.');
  }

  const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;

  // 1. Decode nonce (must be exactly 12 bytes for AES-256-GCM)
  let ivBuf: ArrayBuffer;
  try {
    ivBuf = base64ToBuffer(encryptedPayload.nonce);
    if (ivBuf.byteLength !== 12) {
      throw new Error('Nonce is not 12 bytes');
    }
  } catch {
    throw new E2EEDecryptionError('INVALID_NONCE', 'E2EE Error: Failed to decode 12-byte initialization vector.');
  }

  // 2. Decode ciphertext buffer
  let ciphertextBuf: ArrayBuffer;
  try {
    ciphertextBuf = base64ToBuffer(encryptedPayload.ciphertext);
    if (ciphertextBuf.byteLength === 0) {
      throw new Error('Ciphertext buffer is empty');
    }
  } catch {
    throw new E2EEDecryptionError('INVALID_CIPHERTEXT', 'E2EE Error: Failed to decode attachment ciphertext buffer.');
  }

  const version = encryptedPayload.version || 1;
  const keyEpoch = encryptedPayload.keyEpoch || 1;
  const aId = (encryptedPayload.attachmentId || '').trim();

  // 3. Candidate connection IDs to try (passed connectionId + stored record connectionId)
  const candidateConnIds = Array.from(
    new Set([connectionId, (encryptedPayload as any)?.connectionId].filter((x): x is string => typeof x === 'string' && Boolean(x.trim())))
  );

  let decryptedBuf: ArrayBuffer | null = null;
  let lastError: any = null;

  for (const cidCandidate of candidateConnIds) {
    if (decryptedBuf) break;
    const cId = cidCandidate.trim();

    // Candidate derivation info strings
    const candidateInfoStrings = [
      `aamarva-channel-attachment:${cId}`,
      `aamarva-attachment:${cId}`,
      `aamarva-channel:${cId}`
    ];

    // Candidate AADs for authenticated verification
    const sIdNorm = normalizeAgentId(senderAgentId);
    const sIdRaw = (senderAgentId || '').trim().toUpperCase();

    const candidateAADs = [
      constructAttachmentAAD(cId, version, senderAgentId, keyEpoch, aId),
      new TextEncoder().encode(`AAMARVA:E2EE:ATTACHMENT:v1:${cId}:${sIdNorm}:${aId}:${keyEpoch}`),
      new TextEncoder().encode(`AAMARVA:E2EE:ATTACHMENT:v1:${cId}:${sIdRaw}:${aId}:${keyEpoch}`),
      new TextEncoder().encode(`AAMARVA:E2EE:ATTACHMENT:v1:${cId}:${aId}:${keyEpoch}`),
      new TextEncoder().encode(`AAMARVA:E2EE:ATTACHMENT:v1:${cId}:${sIdNorm}:${aId}`),
      new TextEncoder().encode(`AAMARVA:E2EE:ATTACHMENT:v1:${cId}:${aId}`),
      new TextEncoder().encode(`AAMARVA:E2EE:v1:${cId}:${sIdNorm}`)
    ];

    for (const infoStr of candidateInfoStrings) {
      let attachmentKey: CryptoKey;
      try {
        attachmentKey = await deriveAttachmentChannelKey(receiverPrivateKey, senderPublicKeyJwk, cId, infoStr);
      } catch {
        continue;
      }

      for (const aad of candidateAADs) {
        try {
          decryptedBuf = await cryptoObj.subtle.decrypt(
            {
              name: ENC_ALGO,
              iv: new Uint8Array(ivBuf),
              additionalData: aad
            },
            attachmentKey,
            ciphertextBuf
          );
          if (decryptedBuf) break;
        } catch (err: any) {
          lastError = err;
        }
      }
      if (decryptedBuf) break;
    }
  }

  if (!decryptedBuf) {
    throw new E2EEDecryptionError(
      'AUTHENTICATION_TAG_FAILED',
      `E2EE Error: AES-256-GCM attachment authentication tag verification failed (${lastError?.message || 'Ciphertext or AAD tag mismatch - attachment is corrupted or tampered'}).`
    );
  }

  // 5. Parse decrypted envelope
  let envelope: any;
  try {
    const envelopeJson = new TextDecoder().decode(decryptedBuf);
    envelope = JSON.parse(envelopeJson);
  } catch (err: any) {
    throw new E2EEDecryptionError('INVALID_CIPHERTEXT', `E2EE Error: Decrypted attachment envelope is malformed: ${err?.message || err}`);
  }

  if (!envelope || typeof envelope !== 'object' || !envelope.data || typeof envelope.data !== 'string') {
    throw new E2EEDecryptionError('INVALID_CIPHERTEXT', 'E2EE Error: Decrypted attachment envelope missing file payload data.');
  }

  // 6. Decode base64 file data and verify SHA-256 checksum
  const rawBytes = new Uint8Array(base64ToBuffer(envelope.data));
  const computedChecksumBuf = await cryptoObj.subtle.digest('SHA-256', rawBytes);
  const computedChecksumHex = Array.from(new Uint8Array(computedChecksumBuf))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');

  if (envelope.checksum && envelope.checksum.toLowerCase() !== computedChecksumHex.toLowerCase()) {
    throw new E2EEDecryptionError(
      'AUTHENTICATION_TAG_FAILED',
      'E2EE Error: Attachment integrity checksum mismatch. File has been tampered with or corrupted.'
    );
  }

  const mimeType = envelope.mimeType || 'application/octet-stream';
  const blob = typeof Blob !== 'undefined' ? new Blob([rawBytes], { type: mimeType }) : ({} as Blob);

  return {
    attachmentId: aId,
    filename: envelope.filename || 'attachment.bin',
    mimeType,
    size: typeof envelope.size === 'number' ? envelope.size : rawBytes.byteLength,
    data: rawBytes,
    blob,
    checksum: computedChecksumHex,
    timestamp: envelope.timestamp || new Date().toISOString()
  };
}


