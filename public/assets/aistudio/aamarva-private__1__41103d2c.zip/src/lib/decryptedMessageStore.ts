/**
 * Decrypted Message Store for AAMARVA
 * Ensures that once a message has been decrypted on the client for the UI,
 * it is persisted across polling intervals, tab switches, and modal reopens.
 * "Once decrypted for the UI, we never go back to the encrypted phase."
 */

const memoryStore = new Map<string, string>();

/**
 * Checks if a string represents an error status or unresolved ciphertext placeholder
 * rather than real decrypted message content.
 */
export function isDecryptionErrorPlaceholder(text?: string | null): boolean {
  if (!text || typeof text !== 'string') return true;
  const trimmed = text.trim();
  if (trimmed.length === 0) return true;
  if (trimmed.startsWith('🔒')) return true;
  if (trimmed.startsWith('🔐')) return true;
  if (trimmed.startsWith('[Encrypted')) return true;
  if (trimmed === '[Your encrypted message]') return true;
  if (trimmed.includes('Cannot be decrypted')) return true;
  if (trimmed.includes('Enter account password above to restore')) return true;
  return false;
}

/**
 * Clean a key for storage lookup
 */
function isValidKey(key: any): boolean {
  if (!key || typeof key !== 'string') return false;
  const trimmed = key.trim();
  if (!trimmed || trimmed === 'null' || trimmed === 'undefined') return false;
  if (trimmed.endsWith('_undefined') || trimmed.endsWith('_null') || trimmed.includes(':undefined') || trimmed.includes(':null')) return false;
  if (trimmed.startsWith('seq_null') || trimmed.startsWith('seq_undefined')) return false;
  return true;
}

function normalizeKey(key: string): string {
  return key.trim();
}

/**
 * Retrieve cached decrypted plaintext for any matching key
 */
export function getCachedDecryptedMessage(keys: (string | undefined | null)[]): string | null {
  for (const rawKey of keys) {
    if (!isValidKey(rawKey)) continue;
    const k = normalizeKey(rawKey as string);

    // 1. Check in-memory map
    const inMem = memoryStore.get(k);
    if (inMem && !isDecryptionErrorPlaceholder(inMem)) {
      return inMem;
    }

    // 2. Check localStorage
    try {
      if (typeof localStorage !== 'undefined') {
        const stored = localStorage.getItem(`aamarva_dec_${k}`);
        if (stored && !isDecryptionErrorPlaceholder(stored)) {
          memoryStore.set(k, stored);
          return stored;
        }
      }
    } catch {}

    // 3. Check sessionStorage
    try {
      if (typeof sessionStorage !== 'undefined') {
        const stored = sessionStorage.getItem(`aamarva_dec_${k}`) || sessionStorage.getItem(`aamarva_plain_${k}`);
        if (stored && !isDecryptionErrorPlaceholder(stored)) {
          memoryStore.set(k, stored);
          return stored;
        }
      }
    } catch {}
  }

  return null;
}

/**
 * Cache decrypted plaintext across all associated keys in memory and persistent storage
 */
export function cacheDecryptedMessage(
  plaintext: string,
  keys: (string | undefined | null)[]
): void {
  if (isDecryptionErrorPlaceholder(plaintext)) {
    return;
  }

  for (const rawKey of keys) {
    if (!isValidKey(rawKey)) continue;
    const k = normalizeKey(rawKey as string);

    memoryStore.set(k, plaintext);

    setTimeout(() => {
      try {
        if (typeof localStorage !== 'undefined') {
          localStorage.setItem(`aamarva_dec_${k}`, plaintext);
        }
      } catch {}

      try {
        if (typeof sessionStorage !== 'undefined') {
          sessionStorage.setItem(`aamarva_dec_${k}`, plaintext);
        }
      } catch {}
    }, 0);
  }
}

/**
 * Convenience helper to store message plaintext with all standard key combinations
 */
export function rememberDecryptedMessage(
  msgId: string,
  plaintext: string,
  channelId?: string,
  extraKeys?: (string | undefined | null)[]
): void {
  if (isDecryptionErrorPlaceholder(plaintext)) return;

  const keys: (string | undefined | null)[] = [
    msgId,
    channelId ? `${channelId}_${msgId}` : undefined,
    ...(extraKeys || [])
  ];

  cacheDecryptedMessage(plaintext, keys);
}

const connectionMessagesCache = new Map<string, any[]>();
const clusterMessagesCache = new Map<string, any[]>();

function makeScopedChannelKey(channelId: string, accountKey?: string): string {
  const cleanId = (channelId || '').trim();
  const cleanScope = (accountKey || '').trim();
  return cleanScope ? `${cleanScope}::${cleanId}` : cleanId;
}

function makeStorageChannelKey(prefix: string, channelId: string, accountKey?: string): string {
  const cleanId = (channelId || '').trim();
  const cleanScope = (accountKey || '').trim();
  return cleanScope ? `${prefix}_${cleanScope}_${cleanId}` : `${prefix}_${cleanId}`;
}

export function getCachedConnectionMessages(connectionId: string, accountKey?: string): any[] {
  if (!connectionId) return [];
  const memKey = makeScopedChannelKey(connectionId, accountKey);
  if (connectionMessagesCache.has(memKey)) {
    return connectionMessagesCache.get(memKey) || [];
  }
  try {
    if (typeof sessionStorage !== 'undefined') {
      const storageKey = makeStorageChannelKey('aamarva_chat_msgs', connectionId, accountKey);
      const raw = sessionStorage.getItem(storageKey);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          connectionMessagesCache.set(memKey, parsed);
          return parsed;
        }
      }
    }
  } catch {}
  return [];
}

export function makePeerAliasKey(peerAgentId?: string | null): string | null {
  if (!peerAgentId || typeof peerAgentId !== 'string') return null;
  const clean = peerAgentId.trim().replace(/^@+/, '').toUpperCase();
  if (!clean || clean === 'PEER' || clean === 'AGENT' || clean === 'UNKNOWN' || clean === 'ANON') {
    return null;
  }
  return `peer:${clean}`;
}

export function getLatestCachedMessageTimestamp(messages: any[]): number {
  if (!Array.isArray(messages) || messages.length === 0) return 0;
  let latest = 0;
  for (const m of messages) {
    if (!m) continue;
    const rawTs = m.createdAt || m.created_at || m.timestamp;
    if (!rawTs) continue;
    const ts = typeof rawTs === 'number' ? rawTs : new Date(rawTs).getTime();
    if (Number.isFinite(ts) && ts > latest) {
      latest = ts;
    }
  }
  return latest;
}

export function getCachedConnectionMessagesByAliases(
  candidateIds: (string | undefined | null)[],
  accountKey?: string,
  peerAgentId?: string | null
): any[] {
  const peerAlias = makePeerAliasKey(peerAgentId);
  const ids = Array.from(
    new Set(
      [...candidateIds, peerAlias].filter((id): id is string => Boolean(id && typeof id === 'string' && id.trim())).map((id) => id.trim())
    )
  );
  let best: any[] = [];
  let bestTs = -1;
  for (const id of ids) {
    const msgs = getCachedConnectionMessages(id, accountKey);
    if (msgs.length === 0) continue;
    const latestTs = getLatestCachedMessageTimestamp(msgs);
    if (latestTs > bestTs || (latestTs === bestTs && msgs.length > best.length)) {
      best = msgs;
      bestTs = latestTs;
    }
  }
  return best;
}

export function setCachedConnectionMessages(connectionId: string, messages: any[], accountKey?: string): void {
  if (!connectionId || !Array.isArray(messages)) return;
  const memKey = makeScopedChannelKey(connectionId, accountKey);
  connectionMessagesCache.set(memKey, messages);
  setTimeout(() => {
    try {
      if (typeof sessionStorage !== 'undefined') {
        const storageKey = makeStorageChannelKey('aamarva_chat_msgs', connectionId, accountKey);
        sessionStorage.setItem(storageKey, JSON.stringify(messages.slice(-50)));
      }
    } catch {}
  }, 0);
}

export function getCachedClusterMessages(clusterId: string, accountKey?: string): any[] {
  if (!clusterId) return [];
  const memKey = makeScopedChannelKey(clusterId, accountKey);
  if (clusterMessagesCache.has(memKey)) {
    return clusterMessagesCache.get(memKey) || [];
  }
  try {
    if (typeof sessionStorage !== 'undefined') {
      const storageKey = makeStorageChannelKey('aamarva_cluster_msgs', clusterId, accountKey);
      const raw = sessionStorage.getItem(storageKey);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          clusterMessagesCache.set(memKey, parsed);
          return parsed;
        }
      }
    }
  } catch {}
  return [];
}

export function setCachedClusterMessages(clusterId: string, messages: any[], accountKey?: string): void {
  if (!clusterId || !Array.isArray(messages)) return;
  const memKey = makeScopedChannelKey(clusterId, accountKey);
  clusterMessagesCache.set(memKey, messages);
  setTimeout(() => {
    try {
      if (typeof sessionStorage !== 'undefined') {
        const storageKey = makeStorageChannelKey('aamarva_cluster_msgs', clusterId, accountKey);
        sessionStorage.setItem(storageKey, JSON.stringify(messages.slice(-50)));
      }
    } catch {}
  }, 0);
}
