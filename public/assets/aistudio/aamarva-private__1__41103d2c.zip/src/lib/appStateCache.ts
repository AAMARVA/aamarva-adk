// Application-wide state preservation and cache management
// Scoped by authenticated account identity for 100% security and isolation

export interface LogItem {
  id: string;
  category?: 'footprint' | 'event';
  action?: string;
  endpoint?: string;
  details?: any;
  type?: string;
  senderId?: string;
  target?: string;
  targetId?: string;
  targetAgentId?: string;
  targetAgentName?: string;
  targetAvatar?: string;
  requestId?: string;
  timestamp: string;
  createdAt?: string;
  created_at?: string;
}

export interface ActivityCacheItem {
  footprints: LogItem[];
  webhooks: LogItem[];
  activeTab: 'footprints' | 'webhooks' | 'outbound';
  lastFetchedFootprints?: number;
  lastFetchedWebhooks?: number;
}

export interface GenericCacheEntry<T = any> {
  data: T;
  timestamp: number;
}

// In-memory store keyed by account identity (e.g. "usr_123:slave_456" or "usr_123")
const activityCacheMap = new Map<string, ActivityCacheItem>();
const queryCacheMap = new Map<string, GenericCacheEntry>();
const uiStateCacheMap = new Map<string, Map<string, any>>();

export function getAccountKey(userId?: string | null, activeAccountId?: string | null): string {
  const u = (userId || 'anon').trim();
  const a = (activeAccountId || u).trim();
  return `${u}::${a}`;
}

// Activity Logs (Footprints & Webhooks)
export function getActivityCache(accountKey: string): ActivityCacheItem {
  const existing = activityCacheMap.get(accountKey);
  if (existing) return existing;
  const initial: ActivityCacheItem = {
    footprints: [],
    webhooks: [],
    activeTab: 'footprints',
  };
  activityCacheMap.set(accountKey, initial);
  return initial;
}

export function setActivityCache(
  accountKey: string, 
  partial: Partial<ActivityCacheItem>
): ActivityCacheItem {
  const current = getActivityCache(accountKey);
  const updated: ActivityCacheItem = {
    ...current,
    ...partial,
  };
  activityCacheMap.set(accountKey, updated);
  return updated;
}

// Generic Query Response Cache (stale-while-revalidate / TTL)
export function getQueryCache<T = any>(
  accountKey: string, 
  endpoint: string, 
  ttlMs: number = 30000
): { data: T; isStale: boolean } | null {
  const key = `${accountKey}@@${endpoint}`;
  const entry = queryCacheMap.get(key);
  if (!entry) return null;
  const age = Date.now() - entry.timestamp;
  return {
    data: entry.data as T,
    isStale: age > ttlMs,
  };
}

export function setQueryCache<T = any>(
  accountKey: string, 
  endpoint: string, 
  data: T
): void {
  const key = `${accountKey}@@${endpoint}`;
  queryCacheMap.set(key, {
    data,
    timestamp: Date.now(),
  });
}

export function invalidateQuery(endpointPrefix: string): void {
  for (const key of Array.from(queryCacheMap.keys())) {
    if (key.includes(`@@${endpointPrefix}`)) {
      queryCacheMap.delete(key);
    }
  }
}

// UI State Cache (subtabs, filters, forms, scroll values)
export function getUiState<T = any>(accountKey: string, stateKey: string, defaultValue: T): T {
  const accountMap = uiStateCacheMap.get(accountKey);
  if (!accountMap) return defaultValue;
  const val = accountMap.get(stateKey);
  return val !== undefined ? (val as T) : defaultValue;
}

export function setUiState(accountKey: string, stateKey: string, value: any): void {
  let accountMap = uiStateCacheMap.get(accountKey);
  if (!accountMap) {
    accountMap = new Map<string, any>();
    uiStateCacheMap.set(accountKey, accountMap);
  }
  accountMap.set(stateKey, value);
}

// Prepared Account Context Cache (Master & Slave profiles indexed by id and agentId)
const preparedAccountProfilesMap = new Map<string, GenericCacheEntry<any>>();

export function setPreparedAccountProfile(profile: any): void {
  if (!profile || typeof profile !== 'object') return;
  const now = Date.now();
  if (profile.id) {
    preparedAccountProfilesMap.set(String(profile.id).trim().toLowerCase(), { data: profile, timestamp: now });
  }
  if (profile.agentId) {
    preparedAccountProfilesMap.set(String(profile.agentId).trim().toUpperCase(), { data: profile, timestamp: now });
  }
}

export function getPreparedAccountProfile(identifier?: string | null, ttlMs: number = 60000): { data: any; isStale: boolean } | null {
  if (!identifier) return null;
  const trimmed = String(identifier).trim();
  const entry = preparedAccountProfilesMap.get(trimmed.toLowerCase()) || preparedAccountProfilesMap.get(trimmed.toUpperCase());
  if (!entry) return null;
  return {
    data: entry.data,
    isStale: Date.now() - entry.timestamp > ttlMs,
  };
}

export function seedFleetAccountsCache(masterAccountsData: any): void {
  if (!masterAccountsData || typeof masterAccountsData !== 'object') return;
  setQueryCache('master_accounts', '/api/auth/master/accounts', masterAccountsData);
  if (masterAccountsData.masterAgent) {
    setPreparedAccountProfile({
      ...masterAccountsData.masterAgent,
      account_type: 'master',
      isMasterUser: true,
      is_master_primary: true,
      isMasterPrimary: true,
      is_slave: false,
      isSlave: false,
    });
  }
  const masterSlots = masterAccountsData.masterSlotAgents || [];
  if (Array.isArray(masterSlots)) {
    for (const m of masterSlots) {
      if (m && typeof m === 'object') {
        setPreparedAccountProfile({
          ...m,
          account_type: 'master_slot',
          role: 'master',
          is_master_slot: true,
          isMasterSlot: true,
          isMasterUser: true,
          is_master_primary: false,
          isMasterPrimary: false,
          is_slave: false,
          isSlave: false,
        });
      }
    }
  }
  const slaves = masterAccountsData.subAgents || masterAccountsData.slaveAgents || [];
  if (Array.isArray(slaves)) {
    for (const s of slaves) {
      if (s && typeof s === 'object') {
        setPreparedAccountProfile({
          ...s,
          account_type: 'slave',
          role: 'slave',
          is_slave: true,
          isSlave: true,
          isMasterUser: false,
          is_master_primary: false,
          isMasterPrimary: false,
        });
      }
    }
  }
}

export function buildCommandPitFleetList(connList: any[], masterAccountsData: any, activeAccountIdOverride?: string, accountKeyOverride?: string): any[] {
  const connectionsMap = new Map<string, any>();
  const normalizeId = (id: string) => (id || '').toString().trim().replace(/^@+/, '').toUpperCase();

  const rawActiveId = (activeAccountIdOverride || masterAccountsData?.activeAgentId || '').toString();
  const readReceiptScopeKey = accountKeyOverride || (rawActiveId ? `${rawActiveId}::${rawActiveId}` : '');
  const currentActiveId = normalizeId(rawActiveId);

  const masterIdentifiers = new Set<string>();
  const slaveIdentifiers = new Set<string>();

  if (masterAccountsData && typeof masterAccountsData === 'object') {
    const masterAgent = masterAccountsData.masterAgent;
    const masterSlotAgents = masterAccountsData.masterSlotAgents || [];
    const slaveAgents = masterAccountsData.subAgents || masterAccountsData.slaveAgents || [];

    const addIdent = (acc: any, set: Set<string>) => {
      if (!acc) return;
      if (acc.id) set.add(normalizeId(acc.id));
      if (acc.agentId) set.add(normalizeId(acc.agentId));
      if (acc.name) set.add(normalizeId(acc.name));
    };

    addIdent(masterAgent, masterIdentifiers);
    if (Array.isArray(masterSlotAgents)) {
      masterSlotAgents.forEach((ms: any) => addIdent(ms, masterIdentifiers));
    }
    if (Array.isArray(slaveAgents)) {
      slaveAgents.forEach((s: any) => addIdent(s, slaveIdentifiers));
    }
  }

  if (Array.isArray(connList)) {
    connList.forEach((c: any) => {
      if (c && c.status !== 'dissolved') {
        const aid = (c.agentId || c.agentName || c.id || '').toString();
        const normAid = normalizeId(aid);
        if (normAid) {
          let isMaster = false;
          let isSlave = false;

          if (slaveIdentifiers.has(normAid)) {
            isSlave = true;
            isMaster = false;
          } else if (masterIdentifiers.has(normAid)) {
            isMaster = true;
            isSlave = false;
          } else {
            isSlave = Boolean(c.isSlave || c.account_type === 'slave' || c.is_slave === true || c.role === 'slave');
            isMaster = !isSlave && Boolean(c.isMaster || c.account_type === 'master' || c.account_type === 'master_slot' || c.is_master_slot === true || c.is_master_primary === true);
          }

          const rawUnread = typeof c.unreadCount === 'number' ? c.unreadCount : (c.unread_count || 0);
          const lastMsg = c.lastMessageAt || c.lastActivity || c.updatedAt || c.updated_at || c.createdAt || c.created_at || c.timestamp;
          const lastMsgTs = lastMsg ? (typeof lastMsg === 'number' ? lastMsg : new Date(lastMsg).getTime()) : 0;
          const lastReadTs = Math.max(
            readReceiptScopeKey ? getEntityLastReadTimestamp(readReceiptScopeKey, c.id, c.connectionId, c.agentId) : 0,
            rawActiveId ? getEntityLastReadTimestamp(rawActiveId, c.id, c.connectionId, c.agentId) : 0
          );

          const unreadCount = (lastReadTs > 0 && lastMsgTs > 0 && lastReadTs >= lastMsgTs) ? 0 : rawUnread;

          const prevItem = connectionsMap.get(normAid);
          const prevLastTs = prevItem?.lastMessageAt ? new Date(prevItem.lastMessageAt).getTime() : 0;
          const mergedLastMsg = (lastMsgTs >= prevLastTs ? lastMsg : prevItem?.lastMessageAt) || lastMsg || prevItem?.lastMessageAt;

          const mergedConnAliases = Array.from(new Set([
            ...(Array.isArray(prevItem?.allConnectionIds) ? prevItem.allConnectionIds : []),
            ...(Array.isArray(c.allConnectionIds) ? c.allConnectionIds : []),
            c.id,
            c.connectionId,
          ].filter(Boolean)));

          const item = {
            id: prevItem?.id || c.id || c.connectionId,
            connectionId: prevItem?.connectionId || c.connectionId || c.id,
            agentId: c.agentId || prevItem?.agentId,
            agentName: c.agentName || c.agentId || prevItem?.agentName,
            avatar: c.avatar || prevItem?.avatar,
            peerE2eePublicKey: c.peerE2eePublicKey || prevItem?.peerE2eePublicKey,
            isMaster: isMaster || Boolean(prevItem?.isMaster),
            isSlave: isSlave || Boolean(prevItem?.isSlave),
            status: c.status || prevItem?.status || 'active',
            unreadCount: Math.max(unreadCount, prevItem?.unreadCount || 0),
            lastMessageAt: mergedLastMsg,
            allConnectionIds: mergedConnAliases,
          };

          connectionsMap.set(normAid, item);
          registerConnectionAlias(readReceiptScopeKey || 'anon', item);
          mergedConnAliases.forEach((aliasId: string) => {
            if (aliasId) registerConnectionAlias(readReceiptScopeKey || 'anon', { ...item, id: aliasId, connectionId: aliasId });
          });
        }
      }
    });
  }

  if (masterAccountsData && typeof masterAccountsData === 'object') {
    const masterAgent = masterAccountsData.masterAgent;
    const masterSlotAgents = masterAccountsData.masterSlotAgents || [];
    const slaveAgents = masterAccountsData.subAgents || masterAccountsData.slaveAgents || [];

    const addAccountIfEligible = (acc: any, expectedIsMaster: boolean, expectedIsSlave: boolean) => {
      if (!acc || (!acc.agentId && !acc.id)) return;
      const accIdClean = normalizeId(acc.id || '');
      const accAgentIdClean = normalizeId(acc.agentId || '');
      const accNameClean = normalizeId(acc.name || '');

      // Exclude if this account is the currently active identity
      if (currentActiveId && (accIdClean === currentActiveId || accAgentIdClean === currentActiveId || accNameClean === currentActiveId)) {
        return;
      }

      let existingKey: string | null = null;
      let existing: any = null;
      for (const [mapKey, item] of Array.from(connectionsMap.entries())) {
        const itemAgentId = normalizeId(item.agentId || '');
        const itemId = normalizeId(item.id || item.connectionId || '');
        const itemName = normalizeId(item.agentName || '');
        if (
          mapKey === accAgentIdClean || mapKey === accIdClean ||
          (accAgentIdClean && itemAgentId === accAgentIdClean) ||
          (accIdClean && itemId === accIdClean) ||
          (accNameClean && itemName === accNameClean)
        ) {
          existingKey = mapKey;
          existing = item;
          break;
        }
      }

      const key = accAgentIdClean || accIdClean || accNameClean;
      const targetId = (acc.id || acc.agentId || '').toString().toLowerCase();
      const fallbackConnId = rawActiveId ? `conn_${rawActiveId.toLowerCase()}_${targetId}` : `conn_${targetId}_fleet`;

      const existingLastMsg = existing?.lastMessageAt;
      const existingLastTs = existingLastMsg ? (typeof existingLastMsg === 'number' ? existingLastMsg : new Date(existingLastMsg).getTime()) : 0;
      const accMsg = acc.lastMessageAt || acc.lastActivity;
      const accMsgTs = accMsg ? (typeof accMsg === 'number' ? accMsg : new Date(accMsg).getTime()) : 0;
      const resolvedLastMessageAt =
        (accMsgTs > existingLastTs ? accMsg : existingLastMsg) ||
        accMsg ||
        acc.updated_at ||
        acc.created_at ||
        acc.timestamp;

      const mergedItem = {
        id: existing?.id || existing?.connectionId || fallbackConnId,
        connectionId: existing?.connectionId || existing?.id || fallbackConnId,
        agentId: acc.agentId || existing?.agentId,
        agentName: acc.name || acc.agentName || acc.agentId || existing?.agentName,
        avatar: acc.avatar || existing?.avatar,
        peerE2eePublicKey: existing?.peerE2eePublicKey || acc.peerE2eePublicKey,
        isMaster: expectedIsMaster,
        isSlave: expectedIsSlave,
        status: existing?.status || 'active',
        unreadCount: typeof existing?.unreadCount === 'number' ? existing.unreadCount : (typeof acc.unreadCount === 'number' ? acc.unreadCount : 0),
        lastMessageAt: resolvedLastMessageAt,
        allConnectionIds: existing?.allConnectionIds,
      };

      if (existingKey && existingKey !== key) {
        connectionsMap.delete(existingKey);
      }
      connectionsMap.set(key, mergedItem);
      registerConnectionAlias(readReceiptScopeKey || 'anon', mergedItem);
    };

    // Add Pioneer Master Agent (unless active)
    if (masterAgent) {
      addAccountIfEligible(masterAgent, true, false);
    }

    // Add Master Slot Accounts (unless active)
    if (Array.isArray(masterSlotAgents)) {
      masterSlotAgents.forEach((ms: any) => addAccountIfEligible(ms, true, false));
    }

    // Add Slave Agents (unless active)
    if (Array.isArray(slaveAgents)) {
      slaveAgents.forEach((s: any) => addAccountIfEligible(s, false, true));
    }

    // Delete active account entry if present in map
    if (currentActiveId) {
      for (const [key, item] of Array.from(connectionsMap.entries())) {
        const itemId = normalizeId(item.id || '');
        const itemAgentId = normalizeId(item.agentId || '');
        const itemName = normalizeId(item.agentName || '');
        if (key === currentActiveId || itemId === currentActiveId || itemAgentId === currentActiveId || itemName === currentActiveId) {
          connectionsMap.delete(key);
        }
      }
    }
  }

  const mergedList = Array.from(connectionsMap.values());
  mergedList.sort((a, b) => {
    if (a.isMaster && !b.isMaster) return -1;
    if (!a.isMaster && b.isMaster) return 1;
    return (a.agentName || '').localeCompare(b.agentName || '');
  });
  return mergedList;
}

// Security: Full clearance on logout
export function clearAllAppCaches(): void {
  activityCacheMap.clear();
  queryCacheMap.clear();
  uiStateCacheMap.clear();
  preparedAccountProfilesMap.clear();
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.removeItem('aamarva_watchtower_events_cache');
      window.localStorage.removeItem('aamarva_floor_events_cache');
    }
  } catch {}
}

// Clear account-specific state
export function clearAccountCache(accountKey: string): void {
  activityCacheMap.delete(accountKey);
  for (const key of Array.from(queryCacheMap.keys())) {
    if (key.startsWith(`${accountKey}@@`)) {
      queryCacheMap.delete(key);
    }
  }
  uiStateCacheMap.delete(accountKey);
  unreadCountsMap.delete(accountKey);
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.removeItem(`aamarva_unread_${accountKey}`);
    }
  } catch (e) {}
}

// Unread Message Counts Cache & Event Dispatcher
const unreadCountsMap = new Map<string, Record<string, number>>();

export function getUnreadCounts(accountKey: string): Record<string, number> {
  const existing = unreadCountsMap.get(accountKey);
  if (existing) return existing;
  const cached = getQueryCache(accountKey, 'aamarva_unread_counts')?.data;
  if (cached && typeof cached === 'object') {
    unreadCountsMap.set(accountKey, cached);
    return cached;
  }
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      const stored = window.localStorage.getItem(`aamarva_unread_${accountKey}`);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed && typeof parsed === 'object') {
          unreadCountsMap.set(accountKey, parsed);
          setQueryCache(accountKey, 'aamarva_unread_counts', parsed);
          return parsed;
        }
      }
    }
  } catch (e) {}
  const initial: Record<string, number> = {};
  unreadCountsMap.set(accountKey, initial);
  return initial;
}

export function setUnreadCountsStore(accountKey: string, counts: Record<string, number>): void {
  unreadCountsMap.set(accountKey, counts);
  setQueryCache(accountKey, 'aamarva_unread_counts', counts);
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.setItem(`aamarva_unread_${accountKey}`, JSON.stringify(counts));
    }
  } catch (e) {}
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('unread-counts-updated', { detail: { accountKey, counts } }));
  }
}

// Last Activity Timestamps for ranking items by recency
const lastActivityMap = new Map<string, number>();

export function setLastActivityTimestamp(accountKey: string, ids: (string | undefined | null)[], timestamp: number = Date.now()): void {
  const validIds = ids.filter((id): id is string => Boolean(id && typeof id === 'string' && id.trim()));
  validIds.forEach((rawId) => {
    const id = rawId.trim();
    const clean = id.replace(/^@+/, '');
    const canonical = resolveCanonicalKey(accountKey, id);
    const keys = [
      id,
      clean,
      `@${clean}`,
      id.toLowerCase(),
      clean.toLowerCase(),
      clean.toUpperCase(),
      canonical,
      canonical ? canonical.toLowerCase() : '',
      canonical ? canonical.toUpperCase() : ''
    ].filter((k): k is string => Boolean(k));

    keys.forEach((k) => {
      if (accountKey) lastActivityMap.set(`${accountKey}@@${k}`, timestamp);
      lastActivityMap.set(`anon@@${k}`, timestamp);
      lastActivityMap.set(`global@@${k}`, timestamp);
    });
  });
}

export function getLastActivityTimestamp(accountKey: string, connOrCluster: any): number {
  if (!connOrCluster) return 0;
  const ids: string[] = [];
  if (typeof connOrCluster === 'string') {
    ids.push(connOrCluster);
  } else {
    if (connOrCluster.id) ids.push(connOrCluster.id);
    if (connOrCluster.connectionId) ids.push(connOrCluster.connectionId);
    if (connOrCluster.agentId) ids.push(connOrCluster.agentId);
    if (connOrCluster.agentName) ids.push(connOrCluster.agentName);
  }

  for (const rawId of ids) {
    const id = rawId.trim();
    const clean = id.replace(/^@+/, '');
    const canonical = resolveCanonicalKey(accountKey, id);
    const keysToTry = [
      id,
      clean,
      `@${clean}`,
      id.toLowerCase(),
      clean.toLowerCase(),
      clean.toUpperCase(),
      canonical,
      canonical ? canonical.toLowerCase() : '',
      canonical ? canonical.toUpperCase() : ''
    ].filter((k): k is string => Boolean(k));

    for (const k of keysToTry) {
      const val = (accountKey ? lastActivityMap.get(`${accountKey}@@${k}`) : undefined) ||
                  lastActivityMap.get(`anon@@${k}`) ||
                  lastActivityMap.get(`global@@${k}`);
      if (val) return val;
    }
  }

  if (typeof connOrCluster === 'object') {
    const rawTs =
      connOrCluster.lastMessageAt ||
      connOrCluster.lastActivity ||
      connOrCluster.updatedAt ||
      connOrCluster.updated_at ||
      connOrCluster.createdAt ||
      connOrCluster.created_at ||
      connOrCluster.timestamp;

    if (rawTs) {
      const parsed = typeof rawTs === 'number' ? rawTs : new Date(rawTs).getTime();
      if (!isNaN(parsed)) return parsed;
    }
  }

  return 0;
}

// Persistent Read Receipts Cache & Helpers
const readReceiptsMap = new Map<string, number>();
const loadedReadReceiptScopes = new Set<string>();

if (typeof window !== 'undefined') {
  window.addEventListener('storage', (evt) => {
    if (evt.key && evt.key.startsWith('aamarva_read_receipts_')) {
      const scopeKey = evt.key.slice('aamarva_read_receipts_'.length);
      loadedReadReceiptScopes.delete(scopeKey);
    }
  });
}

function hydrateReadReceiptsScope(validAccountKey: string): void {
  if (loadedReadReceiptScopes.has(validAccountKey)) return;
  loadedReadReceiptScopes.add(validAccountKey);
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      const raw = window.localStorage.getItem(`aamarva_read_receipts_${validAccountKey}`);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === 'object') {
          for (const [k, v] of Object.entries(parsed)) {
            if (typeof v === 'number' && v > 0) {
              const memKey = `${validAccountKey}@@${k}`;
              const prev = readReceiptsMap.get(memKey) || 0;
              if (v > prev) {
                readReceiptsMap.set(memKey, v);
              }
            }
          }
        }
      }
    }
  } catch (e) {}
}

export function markEntityAsRead(accountKey: string, ids: (string | undefined | null)[], timestamp: number = Date.now()): void {
  const flatIds = ids.flat(Infinity).filter((id): id is string => Boolean(id && typeof id === 'string' && id.trim()));
  if (flatIds.length === 0) return;

  const validAccountKey = accountKey || 'anon';
  hydrateReadReceiptsScope(validAccountKey);

  let stored: Record<string, number> = {};
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      const existing = window.localStorage.getItem(`aamarva_read_receipts_${validAccountKey}`);
      if (existing) {
        stored = JSON.parse(existing) || {};
      }
    }
  } catch (e) {}

  flatIds.forEach((rawId) => {
    const id = rawId.trim();
    const clean = id.replace(/^@+/, '');
    const canonical = resolveCanonicalKey(accountKey, id) || clean.toUpperCase();
    const keys = [
      id,
      clean,
      `@${clean}`,
      id.toLowerCase(),
      clean.toLowerCase(),
      clean.toUpperCase(),
      canonical,
      canonical.toLowerCase(),
      canonical.toUpperCase()
    ];
    keys.forEach((k) => {
      readReceiptsMap.set(`${validAccountKey}@@${k}`, timestamp);
      if (validAccountKey === 'anon') {
        readReceiptsMap.set(`anon@@${k}`, timestamp);
      }
      stored[k] = timestamp;
    });
  });

  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.setItem(`aamarva_read_receipts_${validAccountKey}`, JSON.stringify(stored));
    }
  } catch (e) {}
}

export function getEntityLastReadTimestamp(accountKey: string, ...ids: (string | undefined | null)[]): number {
  const flatIds = ids.flat(Infinity).filter((id): id is string => Boolean(id && typeof id === 'string' && id.trim()));
  if (flatIds.length === 0) return 0;
  const validAccountKey = accountKey || 'anon';
  hydrateReadReceiptsScope(validAccountKey);
  if (validAccountKey === 'anon') {
    hydrateReadReceiptsScope('anon');
  }

  let maxRead = 0;
  for (const rawId of flatIds) {
    const id = rawId.trim();
    const clean = id.replace(/^@+/, '');
    const canonical = resolveCanonicalKey(accountKey, id) || clean.toUpperCase();
    const keys = [
      id,
      clean,
      `@${clean}`,
      id.toLowerCase(),
      clean.toLowerCase(),
      clean.toUpperCase(),
      canonical,
      canonical.toLowerCase(),
      canonical.toUpperCase()
    ];

    for (const k of keys) {
      const memTs = readReceiptsMap.get(`${validAccountKey}@@${k}`) || (validAccountKey === 'anon' ? readReceiptsMap.get(`anon@@${k}`) : 0);
      if (memTs && memTs > maxRead) maxRead = memTs;
    }
  }

  return maxRead;
}

// Canonical entity mapping: maps any alias (connId, agentId, agentName, targetId, handle) to a single Canonical Key
const aliasToCanonicalMap = new Map<string, string>();

export function registerConnectionAlias(accountKey: string, conn: any): string {
  if (!conn || typeof conn !== 'object') return '';
  const canonicalKey = (conn.agentId || conn.agentName || conn.id || conn.connectionId || '').toString().trim();
  if (!canonicalKey) return '';

  const cleanCanonical = canonicalKey.replace(/^@+/, '').toUpperCase();

  const aliases = [
    conn.id,
    conn.connectionId,
    conn.agentId,
    conn.agentName,
    cleanCanonical,
    `@${cleanCanonical}`,
  ].filter((a): a is string => Boolean(a && typeof a === 'string' && a.trim()));

  aliases.forEach((a) => {
    const raw = a.trim();
    const clean = raw.replace(/^@+/, '');
    [raw, clean, `@${clean}`, raw.toLowerCase(), clean.toLowerCase(), clean.toUpperCase()].forEach((k) => {
      if (accountKey) {
        aliasToCanonicalMap.set(`${accountKey}@@${k}`, cleanCanonical);
      }
      aliasToCanonicalMap.set(`anon@@${k}`, cleanCanonical);
      aliasToCanonicalMap.set(`global@@${k}`, cleanCanonical);
    });
  });

  return cleanCanonical;
}

export function resolveCanonicalKey(accountKey: string, rawId?: string | null): string {
  if (!rawId || typeof rawId !== 'string' || !rawId.trim()) return '';
  const id = rawId.trim();
  const clean = id.replace(/^@+/, '');
  const keysToTry = [id, clean, `@${clean}`, id.toLowerCase(), clean.toLowerCase(), clean.toUpperCase()];

  for (const k of keysToTry) {
    const canonical =
      (accountKey ? aliasToCanonicalMap.get(`${accountKey}@@${k}`) : undefined) ||
      aliasToCanonicalMap.get(`anon@@${k}`) ||
      aliasToCanonicalMap.get(`global@@${k}`);
    if (canonical) return canonical;
  }

  // Cross-account lookup fallback
  for (const [mapKey, canonical] of aliasToCanonicalMap.entries()) {
    const parts = mapKey.split('@@');
    const key = parts[1];
    if (key && (key.toLowerCase() === id.toLowerCase() || key.toLowerCase() === clean.toLowerCase())) {
      return canonical;
    }
  }

  return clean.toUpperCase();
}

function hasRegisteredAlias(accountKey: string, rawId?: string | null): boolean {
  if (!rawId || typeof rawId !== 'string' || !rawId.trim()) return false;
  const id = rawId.trim();
  const clean = id.replace(/^@+/, '');
  const keysToTry = [id, clean, `@${clean}`, id.toLowerCase(), clean.toLowerCase(), clean.toUpperCase()];

  for (const k of keysToTry) {
    if (
      (accountKey && aliasToCanonicalMap.has(`${accountKey}@@${k}`)) ||
      aliasToCanonicalMap.has(`anon@@${k}`) ||
      aliasToCanonicalMap.has(`global@@${k}`)
    ) {
      return true;
    }
  }
  return false;
}

export function getConnUnreadCount(counts: Record<string, number>, conn: any, accountKey?: string): number {
  if (!conn || !counts) return 0;

  const extraAliasIds = Array.isArray(conn.allConnectionIds) ? conn.allConnectionIds : [];
  const idsToTest = [
    conn.id,
    conn.connectionId,
    conn.agentId,
    conn.agentName,
    ...extraAliasIds,
    conn.id ? conn.id.replace(/^@+/, '') : '',
    conn.connectionId ? conn.connectionId.replace(/^@+/, '') : '',
    conn.agentId ? conn.agentId.replace(/^@+/, '') : '',
    conn.agentName ? conn.agentName.replace(/^@+/, '') : '',
  ].filter(Boolean);

  let maxFound = 0;
  for (const rawId of idsToTest) {
    const id = String(rawId).trim();
    const clean = id.replace(/^@+/, '');
    const canonical = resolveCanonicalKey(accountKey || '', id) || clean.toUpperCase();
    const keys = [
      canonical,
      canonical.toLowerCase(),
      canonical.toUpperCase(),
      id,
      clean,
      `@${clean}`,
      id.toLowerCase(),
      clean.toLowerCase(),
      `@${clean}`.toLowerCase()
    ];
    for (const k of keys) {
      if (k && counts[k] && counts[k] > maxFound) {
        maxFound = counts[k];
      }
    }
  }

  if (maxFound > 0 && accountKey) {
    const lastReadTs = getEntityLastReadTimestamp(accountKey, conn.id, conn.connectionId, conn.agentId);
    if (lastReadTs > 0) {
      const lastActivityTs = getLastActivityTimestamp(accountKey, conn);
      if (lastActivityTs > 0 && lastActivityTs > lastReadTs) {
        return maxFound;
      }
      const lastMsg = conn.lastMessageAt || conn.lastActivity || conn.updatedAt || conn.updated_at || conn.createdAt || conn.created_at || conn.timestamp;
      const lastMsgTs = lastMsg ? (typeof lastMsg === 'number' ? lastMsg : new Date(lastMsg).getTime()) : 0;
      if (lastMsgTs > 0 && lastReadTs >= lastMsgTs && (!lastActivityTs || lastActivityTs <= lastReadTs)) {
        return 0;
      }
    }
  }

  return maxFound;
}

export function registerClusterAlias(accountKey: string, cluster: any): string {
  if (!cluster || typeof cluster !== 'object') return '';
  const canonicalKey = (cluster.id || cluster.clusterId || cluster.name || '').toString().trim();
  if (!canonicalKey) return '';

  const cleanCanonical = canonicalKey.replace(/^@+/, '').toUpperCase();

  const aliases = [
    cluster.id,
    cluster.clusterId,
    cluster.name,
    cleanCanonical,
    `@${cleanCanonical}`,
  ].filter((a): a is string => Boolean(a && typeof a === 'string' && a.trim()));

  aliases.forEach((a) => {
    const raw = a.trim();
    const clean = raw.replace(/^@+/, '');
    [raw, clean, `@${clean}`, raw.toLowerCase(), clean.toLowerCase(), clean.toUpperCase()].forEach((k) => {
      if (accountKey) {
        aliasToCanonicalMap.set(`${accountKey}@@${k}`, cleanCanonical);
      }
      aliasToCanonicalMap.set(`anon@@${k}`, cleanCanonical);
      aliasToCanonicalMap.set(`global@@${k}`, cleanCanonical);
    });
  });

  return cleanCanonical;
}

export function getClusterUnreadCount(counts: Record<string, number>, cluster: any, accountKey?: string): number {
  if (!cluster || !counts) return 0;

  const idsToTest = [
    cluster.id,
    cluster.clusterId,
    cluster.name,
    cluster.id ? cluster.id.replace(/^@+/, '') : '',
    cluster.clusterId ? cluster.clusterId.replace(/^@+/, '') : '',
    cluster.name ? cluster.name.replace(/^@+/, '') : '',
  ].filter(Boolean);

  let maxFound = 0;
  for (const rawId of idsToTest) {
    const id = String(rawId).trim();
    const clean = id.replace(/^@+/, '');
    const canonical = resolveCanonicalKey(accountKey || '', id) || clean.toUpperCase();
    const keys = [
      canonical,
      canonical.toLowerCase(),
      canonical.toUpperCase(),
      id,
      clean,
      `@${clean}`,
      id.toLowerCase(),
      clean.toLowerCase(),
      `@${clean}`.toLowerCase()
    ];
    for (const k of keys) {
      if (k && counts[k] && counts[k] > maxFound) {
        maxFound = counts[k];
      }
    }
  }

  if (maxFound > 0 && accountKey) {
    const lastReadTs = getEntityLastReadTimestamp(accountKey, cluster.id, cluster.clusterId, cluster.name);
    if (lastReadTs > 0) {
      const lastActivityTs = getLastActivityTimestamp(accountKey, cluster.id) ||
                             getLastActivityTimestamp(accountKey, cluster.clusterId) ||
                             getLastActivityTimestamp(accountKey, cluster.name);
      if (lastActivityTs > 0 && lastActivityTs > lastReadTs) {
        return maxFound;
      }
      const lastMsg = cluster.lastMessageAt || cluster.lastActivity || cluster.updatedAt || cluster.updated_at || cluster.createdAt || cluster.created_at || cluster.timestamp;
      const lastMsgTs = lastMsg ? (typeof lastMsg === 'number' ? lastMsg : new Date(lastMsg).getTime()) : 0;
      if (lastMsgTs > 0 && lastReadTs >= lastMsgTs && (!lastActivityTs || lastActivityTs <= lastReadTs)) {
        return 0;
      }
    }
  }

  return maxFound;
}

// Lazy AudioContext & notification audio element so unplayed sessions never trigger eager external downloads
let audioCtx: AudioContext | null = null;
let preloadedAudio: HTMLAudioElement | null = null;

if (typeof window !== 'undefined') {
  const unlockAudio = () => {
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass && (!audioCtx || audioCtx.state === 'closed')) {
        audioCtx = new AudioContextClass();
      }
      if (audioCtx && audioCtx.state === 'suspended') {
        audioCtx.resume().catch(() => {});
      }
    } catch (e) {}
  };

  window.addEventListener('click', unlockAudio, { passive: true, once: true });
  window.addEventListener('keydown', unlockAudio, { passive: true, once: true });
  window.addEventListener('touchstart', unlockAudio, { passive: true, once: true });
}

export function playSynthesizedRoboticChimp(): void {
  try {
    if (typeof window === 'undefined') return;
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;

    if (!audioCtx || audioCtx.state === 'closed') {
      audioCtx = new AudioContextClass();
    }
    if (audioCtx.state === 'suspended') {
      audioCtx.resume().catch(() => {});
    }

    const now = audioCtx.currentTime;

    const playChimpHoot = (
      startOffset: number,
      duration: number,
      startFreq: number,
      peakFreq: number,
      endFreq: number,
      gainLevel: number,
      isScreech: boolean = false
    ) => {
      if (!audioCtx) return;
      const t = now + startOffset;

      const osc = audioCtx.createOscillator();
      const osc2 = audioCtx.createOscillator();
      const filter = audioCtx.createBiquadFilter();
      const gain = audioCtx.createGain();

      osc.type = isScreech ? 'sawtooth' : 'triangle';
      osc2.type = 'square';

      osc.frequency.setValueAtTime(startFreq, t);
      osc.frequency.exponentialRampToValueAtTime(peakFreq, t + duration * 0.4);
      osc.frequency.exponentialRampToValueAtTime(endFreq, t + duration);

      osc2.frequency.setValueAtTime(startFreq * 0.5, t);
      osc2.frequency.exponentialRampToValueAtTime(peakFreq * 0.75, t + duration * 0.4);

      filter.type = isScreech ? 'bandpass' : 'lowpass';
      filter.frequency.setValueAtTime(isScreech ? 1800 : 900, t);
      filter.Q.setValueAtTime(isScreech ? 8.0 : 4.0, t);

      gain.gain.setValueAtTime(0.001, t);
      gain.gain.linearRampToValueAtTime(gainLevel, t + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + duration);

      osc.connect(filter);
      osc2.connect(filter);
      filter.connect(gain);
      gain.connect(audioCtx.destination);

      osc.start(t);
      osc2.start(t);
      osc.stop(t + duration);
      osc2.stop(t + duration);
    };

    // Joe Rogan Chimpanzee hoot sequence (pant-hoots building into wild screeches)
    playChimpHoot(0.00, 0.15, 250, 420, 300, 0.25, false); // hoot 1
    playChimpHoot(0.16, 0.15, 300, 500, 350, 0.28, false); // hoot 2
    playChimpHoot(0.33, 0.18, 400, 750, 550, 0.32, false); // hoot 3 (rising)
    playChimpHoot(0.53, 0.22, 600, 1400, 950, 0.38, true);  // screech 1 (Joe Rogan style whoop)
    playChimpHoot(0.77, 0.25, 750, 1800, 1200, 0.42, true); // screech 2 (climax)
  } catch (err) {}
}

export function playRoboticChimpanzeeSound(): void {
  try {
    if (typeof window === 'undefined') return;
    
    // 1. Play zero-latency synthesized robotic chimp sound immediately
    playSynthesizedRoboticChimp();

    // 2. Lazily initialize & play audio sample only when playback is actually requested
    if (!preloadedAudio) {
      try {
        preloadedAudio = new Audio('https://upload.wikimedia.org/wikipedia/commons/b/b5/Pan_troglodytes_pant-hoot.ogg');
        preloadedAudio.preload = 'none';
        preloadedAudio.volume = 0.8;
      } catch (e) {}
    }
    if (preloadedAudio) {
      preloadedAudio.currentTime = 0;
      preloadedAudio.play().catch(() => {});
    }
  } catch (err) {
    playSynthesizedRoboticChimp();
  }
}

export const playMessageNotificationSound = playRoboticChimpanzeeSound;

const recentEventIds = new Set<string>();

export function incrementUnreadCount(accountKey: string, eventId?: string | null, ...args: any[]): void {
  if (eventId && typeof eventId === 'string' && eventId.trim()) {
    const raw = eventId.trim();
    const cleanId = raw.replace(/^evt_msg_/, '').replace(/^evt_clu_/, '').replace(/^evt_/, '');
    const dedupeKey1 = `${accountKey}@@${raw}`;
    const dedupeKey2 = `${accountKey}@@${cleanId}`;

    if (recentEventIds.has(dedupeKey1) || recentEventIds.has(dedupeKey2)) {
      return; // Already processed this message event
    }
    recentEventIds.add(dedupeKey1);
    recentEventIds.add(dedupeKey2);
    setTimeout(() => {
      recentEventIds.delete(dedupeKey1);
      recentEventIds.delete(dedupeKey2);
    }, 45000);
  }

  const current = { ...getUnreadCounts(accountKey) };
  const flatIds = args.flat(Infinity).filter((id): id is string => Boolean(id && typeof id === 'string' && id.trim()));
  if (flatIds.length === 0) return;

  let canonicalKey = '';
  for (const id of flatIds) {
    if (hasRegisteredAlias(accountKey, id)) {
      const mapped = resolveCanonicalKey(accountKey, id);
      if (mapped && !mapped.startsWith('USR_')) {
        canonicalKey = mapped;
        break;
      }
    }
  }
  if (!canonicalKey) {
    for (const id of flatIds) {
      const mapped = resolveCanonicalKey(accountKey, id);
      if (mapped && !mapped.startsWith('USR_')) {
        canonicalKey = mapped;
        break;
      }
    }
  }
  if (!canonicalKey) {
    for (const id of flatIds) {
      const mapped = resolveCanonicalKey(accountKey, id);
      if (mapped) {
        canonicalKey = mapped;
        break;
      }
    }
  }
  if (!canonicalKey) {
    const nonUsr = flatIds.find(id => !id.startsWith('usr_') && !id.startsWith('USR_'));
    const target = nonUsr || flatIds[0];
    canonicalKey = target.trim().replace(/^@+/, '').toUpperCase();
  }

  setLastActivityTimestamp(accountKey, [...flatIds, canonicalKey], Date.now());

  const prevCount = current[canonicalKey] || 0;
  const nextCount = prevCount + 1;

  current[canonicalKey] = nextCount;

  setUnreadCountsStore(accountKey, current);
  playMessageNotificationSound();
}

export function clearUnreadCount(accountKey: string, ...args: any[]): void {
  const current = { ...getUnreadCounts(accountKey) };
  const flatIds = args.flat(Infinity).filter((id): id is string => Boolean(id && typeof id === 'string' && id.trim()));
  if (flatIds.length === 0) return;

  markEntityAsRead(accountKey, flatIds, Date.now());

  flatIds.forEach((id) => {
    const raw = id.trim();
    const cleanId = raw.replace(/^@+/, '').toUpperCase();
    const canonicalKey = resolveCanonicalKey(accountKey, raw);

    const keysToDelete = [
      canonicalKey,
      canonicalKey ? canonicalKey.toLowerCase() : '',
      canonicalKey ? canonicalKey.toUpperCase() : '',
      cleanId,
      cleanId.toLowerCase(),
      raw,
      raw.toLowerCase(),
      `@${cleanId}`,
      `@${cleanId}`.toLowerCase(),
    ].filter(Boolean);

    keysToDelete.forEach((k) => {
      if (current[k] !== undefined) {
        delete current[k];
      }
    });

    for (const k of Object.keys(current)) {
      const upperK = normalizeEntityToken(k);
      const upperCanon = canonicalKey ? normalizeEntityToken(canonicalKey) : '';
      if (
        upperK === cleanId ||
        (upperCanon && upperK === upperCanon)
      ) {
        delete current[k];
      }
    }
  });

  setUnreadCountsStore(accountKey, current);
  if (accountKey !== 'anon::anon') {
    unreadCountsMap.delete('anon::anon');
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.removeItem('aamarva_unread_anon::anon');
      }
    } catch (e) {}
  }
}

interface SyncedEntityState {
  connections: any[];
  clusters: any[];
  selfIds: Set<string>;
  connectionsSynced: boolean;
  clustersSynced: boolean;
}

const syncedEntitiesMap = new Map<string, SyncedEntityState>();

function normalizeEntityToken(val?: any): string {
  return String(val || '').trim().replace(/^@+/, '').toUpperCase();
}

export function isClusterActiveForAccount(accountKey: string, clusterId?: string | null): boolean {
  const synced = syncedEntitiesMap.get(accountKey);
  if (!synced || !synced.clustersSynced) return true;
  const target = normalizeEntityToken(clusterId);
  if (!target) return false;
  return synced.clusters.some((clu: any) => {
    if (!clu || clu.status === 'dissolved') return false;
    return [clu.id, clu.clusterId, clu.name].some((id) => normalizeEntityToken(id) === target);
  });
}

export function isConnectionActiveForAccount(accountKey: string, candidateIds: (string | undefined | null)[]): boolean {
  const synced = syncedEntitiesMap.get(accountKey);
  if (!synced || !synced.connectionsSynced) return true;
  const targets = candidateIds.map(normalizeEntityToken).filter(Boolean);
  if (targets.length === 0) return false;
  return synced.connections.some((c: any) => {
    if (!c || c.status === 'dissolved') return false;
    const extraIds = Array.isArray(c.allConnectionIds) ? c.allConnectionIds : [];
    const cTokens = [c.id, c.connectionId, c.agentId, c.agentName, ...extraIds].map(normalizeEntityToken).filter(Boolean);
    if (cTokens.some((t) => synced.selfIds.has(t))) return false;
    return cTokens.some((t) => targets.includes(t));
  });
}

export function reconcileUnreadEntities(
  accountKey: string,
  opts: {
    connections?: any[];
    clusters?: any[];
    selfIds?: (string | undefined | null)[];
  }
): void {
  if (!accountKey || accountKey === 'anon::anon') return;

  const existingState = syncedEntitiesMap.get(accountKey) || {
    connections: [],
    clusters: [],
    selfIds: new Set<string>(),
    connectionsSynced: false,
    clustersSynced: false,
  };

  if (Array.isArray(opts.selfIds)) {
    const nextSelf = new Set<string>();
    opts.selfIds.forEach((id) => {
      const n = normalizeEntityToken(id);
      if (n) nextSelf.add(n);
    });
    existingState.selfIds = nextSelf;
  }

  if (Array.isArray(opts.connections)) {
    existingState.connections = opts.connections.filter((c) => c && c.status !== 'dissolved');
    existingState.connectionsSynced = true;
  }

  if (Array.isArray(opts.clusters)) {
    existingState.clusters = opts.clusters.filter((c) => c && c.status !== 'dissolved');
    existingState.clustersSynced = true;
  }

  syncedEntitiesMap.set(accountKey, existingState);

  const currentCounts = { ...getUnreadCounts(accountKey) };
  let countChanged = false;
  const validAliasTokens = new Set<string>();

  if (Array.isArray(opts.connections) || existingState.connectionsSynced) {
    existingState.connections.forEach((c: any) => {
      const cTokens = [c.id, c.connectionId, c.agentId, c.agentName].map(normalizeEntityToken).filter(Boolean);
      if (cTokens.some((t) => existingState.selfIds.has(t))) {
        return;
      }

      const canonical = registerConnectionAlias(accountKey, c) || resolveCanonicalKey(accountKey, c.agentId || c.connectionId || c.id);
      const lastReadTs = getEntityLastReadTimestamp(accountKey, canonical, c.agentId, c.connectionId, c.id);
      const lastMsg = c.lastMessageAt || c.lastActivity || c.updatedAt || c.updated_at || c.createdAt || c.created_at || c.timestamp;
      const lastMsgTs = lastMsg ? (typeof lastMsg === 'number' ? lastMsg : new Date(lastMsg).getTime()) : 0;
      const isAlreadyRead = lastReadTs > 0 && lastMsgTs > 0 && lastReadTs >= lastMsgTs;

      const cAliases = [
        canonical,
        c.id,
        c.connectionId,
        c.agentId,
        c.agentName,
        ...(Array.isArray(c.allConnectionIds) ? c.allConnectionIds : []),
        c.agentId ? String(c.agentId).replace(/^@+/, '') : '',
        c.agentName ? String(c.agentName).replace(/^@+/, '') : '',
        c.id ? String(c.id).replace(/^@+/, '') : '',
        c.connectionId ? String(c.connectionId).replace(/^@+/, '') : '',
      ].filter(Boolean);

      cAliases.forEach((a) => {
        const tok = normalizeEntityToken(a);
        if (tok) validAliasTokens.add(tok);
      });

      const lastActivity =
        getLastActivityTimestamp(accountKey, canonical) ||
        getLastActivityTimestamp(accountKey, c.id) ||
        getLastActivityTimestamp(accountKey, c.agentId);
      const hasRecentRealtimeActivity = lastActivity > 0 && lastActivity > lastReadTs;

      if ((isAlreadyRead || !c.unreadCount) && !hasRecentRealtimeActivity) {
        for (const alias of cAliases) {
          const uAlias = normalizeEntityToken(alias);
          for (const k of Object.keys(currentCounts)) {
            const uK = normalizeEntityToken(k);
            if (uK === uAlias || (canonical && uK === normalizeEntityToken(canonical))) {
              delete currentCounts[k];
              countChanged = true;
            }
          }
        }
      } else if (typeof c.unreadCount === 'number' && c.unreadCount > 0 && !isAlreadyRead) {
        if (currentCounts[canonical] !== c.unreadCount) {
          currentCounts[canonical] = c.unreadCount;
          countChanged = true;
        }
      }
    });
  }

  if (Array.isArray(opts.clusters) || existingState.clustersSynced) {
    existingState.clusters.forEach((cluster: any) => {
      const canonical = registerClusterAlias(accountKey, cluster) || resolveCanonicalKey(accountKey, cluster.id || cluster.name) || cluster.id;
      const rawUnread = typeof cluster.unreadCount === 'number' ? cluster.unreadCount : (cluster.unread_count || 0);
      const lastMsg = cluster.lastMessageAt || cluster.lastActivity || cluster.updatedAt || cluster.updated_at || cluster.createdAt || cluster.created_at || cluster.timestamp;
      const lastMsgTs = lastMsg ? (typeof lastMsg === 'number' ? lastMsg : new Date(lastMsg).getTime()) : 0;
      const lastReadTs = getEntityLastReadTimestamp(accountKey, cluster.id, cluster.clusterId, cluster.name);
      const isAlreadyRead = lastReadTs > 0 && lastMsgTs > 0 && lastReadTs >= lastMsgTs;

      const cluAliases = [
        canonical,
        cluster.id,
        cluster.clusterId,
        cluster.name,
        cluster.id ? String(cluster.id).replace(/^@+/, '') : '',
        cluster.name ? String(cluster.name).replace(/^@+/, '') : '',
      ].filter(Boolean);

      cluAliases.forEach((a) => {
        const tok = normalizeEntityToken(a);
        if (tok) validAliasTokens.add(tok);
      });

      const lastCluActivity =
        getLastActivityTimestamp(accountKey, canonical) ||
        getLastActivityTimestamp(accountKey, cluster.id) ||
        getLastActivityTimestamp(accountKey, cluster.name);
      const hasRecentCluActivity = lastCluActivity > 0 && lastCluActivity > lastReadTs;

      if ((isAlreadyRead || rawUnread === 0) && !hasRecentCluActivity) {
        for (const alias of cluAliases) {
          const uAlias = normalizeEntityToken(alias);
          for (const k of Object.keys(currentCounts)) {
            const uK = normalizeEntityToken(k);
            if (uK === uAlias || (canonical && uK === normalizeEntityToken(canonical))) {
              delete currentCounts[k];
              countChanged = true;
            }
          }
        }
      } else if (rawUnread > 0 && !isAlreadyRead) {
        if (currentCounts[canonical] !== rawUnread) {
          currentCounts[canonical] = rawUnread;
          countChanged = true;
        }
      }
    });
  }

  // Prune any orphaned, stale, or self-targeting keys once both connections and clusters have been synced
  if (existingState.connectionsSynced && existingState.clustersSynced) {
    for (const k of Object.keys(currentCounts)) {
      const val = currentCounts[k];
      if (typeof val !== 'number' || val <= 0) {
        delete currentCounts[k];
        countChanged = true;
        continue;
      }
      const normK = normalizeEntityToken(k);
      const resolvedK = normalizeEntityToken(resolveCanonicalKey(accountKey, k));
      if (
        existingState.selfIds.has(normK) ||
        (resolvedK && existingState.selfIds.has(resolvedK)) ||
        (!validAliasTokens.has(normK) && (!resolvedK || !validAliasTokens.has(resolvedK)))
      ) {
        delete currentCounts[k];
        countChanged = true;
      }
    }
  }

  if (countChanged) {
    setUnreadCountsStore(accountKey, currentCounts);
  }
}

export function getTotalUnreadCount(accountKey: string): number {
  if (!accountKey || accountKey === 'anon::anon') return 0;
  const counts = getUnreadCounts(accountKey);
  const synced = syncedEntitiesMap.get(accountKey);

  if (synced && synced.connectionsSynced && synced.clustersSynced) {
    const entityTotals = new Map<string, number>();

    for (const conn of synced.connections) {
      if (!conn || conn.status === 'dissolved') continue;
      const cId = normalizeEntityToken(conn.id);
      const cAid = normalizeEntityToken(conn.agentId);
      if ((cId && synced.selfIds.has(cId)) || (cAid && synced.selfIds.has(cAid))) {
        continue;
      }
      const connCount = getConnUnreadCount(counts, conn, accountKey);
      if (connCount > 0) {
        const canonical = registerConnectionAlias(accountKey, conn) || resolveCanonicalKey(accountKey, conn.agentId || conn.id);
        const existing = entityTotals.get(canonical) || 0;
        if (connCount > existing) {
          entityTotals.set(canonical, connCount);
        }
      }
    }

    for (const clu of synced.clusters) {
      if (!clu || clu.status === 'dissolved') continue;
      const cluCount = getClusterUnreadCount(counts, clu, accountKey);
      if (cluCount > 0) {
        const canonical = registerClusterAlias(accountKey, clu) || resolveCanonicalKey(accountKey, clu.id || clu.name);
        const existing = entityTotals.get(canonical) || 0;
        if (cluCount > existing) {
          entityTotals.set(canonical, cluCount);
        }
      }
    }

    let total = 0;
    for (const val of entityTotals.values()) {
      total += val;
    }
    return total;
  }

  const canonicalEntityCounts = new Map<string, number>();

  const processCounts = (src: Record<string, number>) => {
    for (const [k, v] of Object.entries(src)) {
      if (typeof v === 'number' && v > 0) {
        const canonical = resolveCanonicalKey(accountKey, k) || k.trim().replace(/^@+/, '').toUpperCase();
        
        // If entity was marked read and no newer activity exists in this session, skip it
        const lastRead = getEntityLastReadTimestamp(accountKey, k, canonical);
        const lastActivity = getLastActivityTimestamp(accountKey, k) || getLastActivityTimestamp(accountKey, canonical);
        if (lastRead > 0 && (lastActivity === 0 || lastRead >= lastActivity)) {
          continue;
        }

        const existing = canonicalEntityCounts.get(canonical) || 0;
        if (v > existing) {
          canonicalEntityCounts.set(canonical, v);
        }
      }
    }
  };

  processCounts(counts);

  let total = 0;
  for (const val of canonicalEntityCounts.values()) {
    total += val;
  }
  return total;
}
