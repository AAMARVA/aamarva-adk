import { normalizeAndValidateWatchtowerActivity } from './watchtowerActivitySpec';

export function stripAllPrefixes(id?: string): string {
  if (!id || typeof id !== 'string') return '';
  let current = id.trim();
  let changed = true;
  while (changed) {
    changed = false;
    const stripped = current.replace(/^(fp_|wt_cap_|wt_plan_(?!box_)|wt_|sf_|evt_|conn_|recip_|inv_|act_)/i, '');
    if (stripped !== current) {
      current = stripped;
      changed = true;
    }
  }
  return current.toLowerCase();
}

function getCleanId(id?: string): string {
  if (!id || typeof id !== 'string') return '';
  // Ignore purely random client-side placeholders
  if (id.startsWith('sf-0.') || id.startsWith('sf-Math') || id.includes('Math.random')) {
    return '';
  }
  // Strip all legacy & system prefixes recursively
  return stripAllPrefixes(id);
}

export function getActivityKey(item: any): string {
  if (!item || typeof item !== 'object') return '';

  if (item.activityKey) {
    return `key:${item.activityKey.toLowerCase()}`;
  }

  const cleanId = getCleanId(item.id);
  const type = (item.type || item.action || 'activity').toLowerCase().trim();
  const hasUniqueCleanId = Boolean(cleanId && cleanId.length >= 6 && !cleanId.includes('0.') && !cleanId.includes('math'));

  if (item.entityId && item.type && !type.includes('cluster')) {
    return `entity:${item.entityId}-${type}`;
  }

  const agent = (item.agentId || item.agentName || '').replace(/^@+/, '').toLowerCase().trim();
  const peer = (item.peerAgentId || item.peerName || item.target || '').replace(/^@+/, '').toLowerCase().trim();
  const pair = [agent, peer].filter(Boolean).sort().join('<->');

  if (type.includes('connection')) {
    const act = type.includes('dissolv') || type.includes('remov') ? 'dissolved' : 'established';
    return `conn:${pair}:${act}`;
  }

  if (type.includes('message') || type.includes('attachment')) {
    const actionGroup = type.includes('attach') ? 'attachment' : 'message';
    if (hasUniqueCleanId) {
      return `msg:${cleanId}`;
    }
    return `msg:${pair}:${actionGroup}`;
  }

  if (type.includes('capability') || type.includes('plan')) {
    const batchId = item.details?.batch_id || item.planDetails?.batch_id || item.details?.tx_id || item.details?.latest_transaction_id || item.details?.metadata?.latest_transaction_id;
    if (batchId) {
      return `plan:${String(batchId).toLowerCase()}`;
    }
    if (hasUniqueCleanId) {
      return `plan:${cleanId}`;
    }
    const ts = item.createdAt || item.created_at || '';
    return `plan:${agent}:${type}:${ts}`;
  }

  if (type.includes('cluster')) {
    if (hasUniqueCleanId) {
      return `cluster:${cleanId}:${type}`;
    }
    const cId = item.cluster?.id || item.cluster?.name || peer || '';
    return `cluster:${agent}:${type}:${cId}`;
  }

  if (type.includes('slave') || type.includes('registered')) {
    const target = peer || agent;
    return `account:${target}:${type}`;
  }

  if (type.includes('profile')) {
    if (cleanId && cleanId.length >= 6 && !cleanId.includes('0.') && !cleanId.includes('math')) {
      return `profile:${cleanId}`;
    }
    const textNorm = (item.text || '').replace(/^@+/, '').toLowerCase().trim().slice(0, 40);
    const ts = item.createdAt || item.created_at || '';
    return `profile:${agent}:${textNorm}:${ts}`;
  }

  if (cleanId && cleanId.length >= 6 && !cleanId.includes('0.') && !cleanId.includes('math')) {
    return `id:${cleanId}`;
  }

  const textNorm = (item.text || '').replace(/^@+/, '').toLowerCase().trim().slice(0, 40);
  return `hash:${agent}:${type}:${textNorm}`;
}

export function deduplicateAndMergeWatchtowerActivities(activities: any[]): any[] {
  if (!Array.isArray(activities)) return [];

  const seenKeys = new Set<string>();
  const seenIds = new Set<string>();
  const seenPlanTxIds = new Set<string>();
  const seenPlanSignatures: Array<{ signature: string; ts: number; txId: string }> = [];
  const result: any[] = [];

  // Sort activities chronologically (newest first); use details/outbound flags as tie-breaker for same timestamp
  const sorted = [...activities].sort((a, b) => {
    const timeA = new Date(a.createdAt || a.created_at || 0).getTime();
    const timeB = new Date(b.createdAt || b.created_at || 0).getTime();
    if (timeA !== timeB) return timeB - timeA;

    const typeA = (a.type || a.action || '').toUpperCase();
    const typeB = (b.type || b.action || '').toUpperCase();
    const isSentA = typeA.includes('SENT') || typeA.includes('DEPLOYED') || typeA.includes('CREATED');
    const isSentB = typeB.includes('SENT') || typeB.includes('DEPLOYED') || typeB.includes('CREATED');
    if (isSentA && !isSentB) return -1;
    if (!isSentA && isSentB) return 1;

    const detailsA = (a.planDetails || (a.details && typeof a.details === 'object' && Object.keys(a.details).length > 0)) ? 1 : 0;
    const detailsB = (b.planDetails || (b.details && typeof b.details === 'object' && Object.keys(b.details).length > 0)) ? 1 : 0;
    if (detailsA !== detailsB) return detailsB - detailsA;

    return 0;
  });

  // Build batch coverage windows to suppress legacy standalone SLAVE_CAPABILITY_ACTIVATED child duplicates
  const batchCoverage = sorted
    .filter((item) => item && ((item.type || item.action || '').toUpperCase() === 'SLAVE_CAPABILITY_BATCH_ACTIVATED'))
    .map((b) => {
      const ts = new Date(b.createdAt || b.created_at || 0).getTime();
      const targets = new Set<string>(
        (b.planDetails?.targetAccountIds || b.details?.target_account_ids || [])
          .map((t: any) => String(t || '').replace(/^@+/, '').toLowerCase().trim())
          .filter(Boolean)
      );
      return { ts, targets };
    });

  for (const rawItem of sorted) {
    if (!rawItem || typeof rawItem !== 'object') continue;

    const item = normalizeAndValidateWatchtowerActivity(rawItem);
    if (!item || !item.text) continue;

    const itemType = (item.type || '').toUpperCase();
    const rawItemText = typeof item.text === 'string' ? item.text.toLowerCase().trim() : '';
    const cleanLowerText = rawItemText.replace(/^@\S+\s+/, '').trim();
    const itemDetails = item.details || item.technicalDetails;

    // Suppress child SLAVE_CAPABILITY_ACTIVATED rows that belong to a capability batch
    if (itemType === 'SLAVE_CAPABILITY_ACTIVATED') {
      if (itemDetails?.batch_id) continue;
      const itemTs = new Date(item.createdAt || 0).getTime();
      const targetCand = String(item.peerAgentId || itemDetails?.agent_id || item.actorUserId || '').replace(/^@+/, '').toLowerCase().trim();
      const covered = batchCoverage.some((bc) => {
        if (Math.abs(bc.ts - itemTs) > 30_000) return false;
        return !targetCand || bc.targets.size === 0 || bc.targets.has(targetCand);
      });
      if (covered) continue;
    }

    // Purge legacy phantom middleware rows that logged "activated Capability Increment Plan"
    // on Master Slot / Slave Fleet buy-plan calls with zero capability metadata
    if (
      itemType === 'SLAVE_CAPABILITY_BATCH_ACTIVATED' &&
      (cleanLowerText === 'activated capability increment plan' || cleanLowerText.startsWith('activated capability increment plan (')) &&
      !itemDetails?.batch_id &&
      !itemDetails?.validity_days &&
      !itemDetails?.validity_days_extended &&
      !itemDetails?.accounts_count &&
      !(Array.isArray(itemDetails?.target_account_ids) && itemDetails.target_account_ids.length > 0) &&
      !(Array.isArray(itemDetails?.target_accounts) && itemDetails.target_accounts.length > 0) &&
      !itemDetails?.metadata?.validity_days_extended &&
      !item.planDetails?.validityDays
    ) {
      continue;
    }

    const cleanId = getCleanId(item.id);
    const key = getActivityKey(item);
    const explicitPlanTxId = String(
      itemDetails?.batch_id ||
      itemDetails?.tx_id ||
      itemDetails?.latest_transaction_id ||
      itemDetails?.metadata?.latest_transaction_id ||
      ''
    ).toLowerCase().trim();

    if (cleanId && cleanId.length >= 6 && seenIds.has(cleanId)) {
      continue;
    }
    if (explicitPlanTxId && seenPlanTxIds.has(explicitPlanTxId)) {
      continue;
    }
    if (key && seenKeys.has(key)) {
      continue;
    }

    let planSignatureKey = '';
    const itemTs = new Date(item.createdAt || 0).getTime();
    if (item.category === 'plan' || itemType.includes('PLAN_ENTITLEMENT') || itemType.includes('CAPABILITY') || itemType.includes('CAPACITY')) {
      const actorNorm = (item.agentId || item.agentName || '').replace(/^@+/, '').toLowerCase().trim();
      const pd = item.planDetails || {};
      const groupType = itemType.includes('CAPABILITY') ? 'cap' : 'entitlement';
      planSignatureKey = [
        actorNorm,
        groupType,
        pd.actionType || '',
        pd.accounts ?? '',
        pd.slaveAccountsAdded ?? 0,
        pd.masterSlotsAdded ?? 0,
        pd.masterSlotsTotal ?? '',
        pd.validityDays ?? ''
      ].join('|');

      const isLegacyDuplicatePlan = seenPlanSignatures.some((prev) => {
        if (prev.signature !== planSignatureKey) return false;
        if (Math.abs(prev.ts - itemTs) > 15_000) return false;
        if (explicitPlanTxId && prev.txId && explicitPlanTxId !== prev.txId) return false;
        return true;
      });
      if (isLegacyDuplicatePlan) {
        continue;
      }
    }

    if (cleanId && cleanId.length >= 6) {
      seenIds.add(cleanId);
    }
    if (explicitPlanTxId) {
      seenPlanTxIds.add(explicitPlanTxId);
    }
    if (key) {
      seenKeys.add(key);
    }
    if (planSignatureKey) {
      seenPlanSignatures.push({ signature: planSignatureKey, ts: itemTs, txId: explicitPlanTxId });
    }

    result.push(item);
  }

  result.sort((a, b) => new Date(b.createdAt || b.created_at || 0).getTime() - new Date(a.createdAt || a.created_at || 0).getTime());

  return result;
}

export const deduplicateAndMergeFloorActivities = deduplicateAndMergeWatchtowerActivities;

const WATCHTOWER_CACHE_KEY = 'aamarva_watchtower_events_cache';
const MAX_WATCHTOWER_CACHE_COUNT = 100;

export function getCachedWatchtowerEvents(): any[] {
  try {
    const raw = localStorage.getItem(WATCHTOWER_CACHE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      const healed = parsed
        .map((item) => normalizeAndValidateWatchtowerActivity(item))
        .filter((item): item is NonNullable<typeof item> => item !== null);
      return deduplicateAndMergeWatchtowerActivities(healed).slice(0, MAX_WATCHTOWER_CACHE_COUNT);
    }
  } catch {}
  return [];
}

export function saveCachedWatchtowerEvents(events: any[]): void {
  try {
    if (!Array.isArray(events)) return;
    const deduplicated = deduplicateAndMergeWatchtowerActivities(events);
    const capped = deduplicated.slice(0, MAX_WATCHTOWER_CACHE_COUNT);
    localStorage.setItem(WATCHTOWER_CACHE_KEY, JSON.stringify(capped));
  } catch (e) {
    console.warn('[WatchtowerCache] Failed to save Watchtower activities:', e);
  }
}

export function clearCachedWatchtowerEvents(): void {
  try {
    localStorage.removeItem(WATCHTOWER_CACHE_KEY);
    localStorage.removeItem('aamarva_floor_events_cache');
  } catch {}
}



