import { apiFetch, getCurrentSessionAuthType, isSlaveAccount, syncOwnLocalKeysWithServer } from '../services/authApi';
import {
  computeRawGroupKeyFingerprint,
  decryptMessage,
  deleteClusterGroupKey,
  getAllLocalEpochKeys,
  getClusterGroupKey,
  getLocalKeyPair,
  normalizeAgentId,
  pinPeerKey,
  resolveSenderPublicKey,
  saveClusterGroupKey,
  savePeerEpochKey,
  StoredAgentKeyEntry,
} from './e2ee';
import { decryptClusterMessage, unwrapClusterGroupKeyFromPackage } from './clusterCrypto';
import { fetchConnectionPeerKey, getCachedPeerKey, isPeerKeyStale } from './e2eePrefetch';
import {
  cacheDecryptedMessage,
  getCachedClusterMessages,
  getCachedConnectionMessages,
  getCachedConnectionMessagesByAliases,
  getCachedDecryptedMessage,
  getLatestCachedMessageTimestamp,
  isDecryptionErrorPlaceholder,
  makePeerAliasKey,
  setCachedClusterMessages,
  setCachedConnectionMessages,
} from './decryptedMessageStore';
import { getClusterUnreadCount, getConnUnreadCount, getQueryCache, getUnreadCounts, setQueryCache } from './appStateCache';

const connectionWarmupInFlight = new Map<string, Promise<any[]>>();
const connectionWarmupAliases = new Map<string, string>();
const connectionWarmupPending = new Set<string>();
const clusterWarmupInFlight = new Map<string, Promise<any[]>>();
const clusterWarmupPending = new Set<string>();
const lastWarmupCompletedAt = new Map<string, number>();

export const clusterKeyDistributionInFlight = new Map<string, Promise<any>>();

function recordWarmupCompleted(accountKey: string, type: 'connection' | 'cluster', ids: (string | undefined | null)[]): void {
  const now = Date.now();
  const prefix = type === 'connection' ? `${accountKey}::conn::` : `${accountKey}::clu::`;
  for (const id of ids) {
    if (id && typeof id === 'string' && id.trim()) {
      lastWarmupCompletedAt.set(`${prefix}${id.trim()}`, now);
      lastWarmupCompletedAt.set(`${prefix}${id.trim().toLowerCase()}`, now);
    }
  }
}

export function wasRecentlyWarmed(
  accountKey: string,
  type: 'connection' | 'cluster',
  entityIds: (string | undefined | null)[],
  withinMs: number = 800
): boolean {
  const now = Date.now();
  const prefix = type === 'connection' ? `${accountKey}::conn::` : `${accountKey}::clu::`;
  for (const id of entityIds) {
    if (!id || typeof id !== 'string' || !id.trim()) continue;
    const ts =
      lastWarmupCompletedAt.get(`${prefix}${id.trim()}`) ||
      lastWarmupCompletedAt.get(`${prefix}${id.trim().toLowerCase()}`);
    if (ts && now - ts <= withinMs) return true;
  }
  return false;
}

export function getInFlightWarmupPromise(
  accountKey: string,
  type: 'connection' | 'cluster',
  entityIds: (string | undefined | null)[]
): Promise<any[]> | null {
  if (!accountKey) return null;
  if (type === 'cluster') {
    for (const id of entityIds) {
      if (!id || typeof id !== 'string' || !id.trim()) continue;
      const clean = id.trim();
      const p =
        clusterWarmupInFlight.get(`${accountKey}::clu::${clean}`) ||
        clusterWarmupInFlight.get(`${accountKey}::clu::${clean.toLowerCase()}`);
      if (p) return p;
    }
    return null;
  }
  for (const id of entityIds) {
    if (!id || typeof id !== 'string' || !id.trim()) continue;
    const clean = id.trim();
    const direct = connectionWarmupInFlight.get(`${accountKey}::conn::${clean}`);
    if (direct) return direct;
    const mappedKey =
      connectionWarmupAliases.get(`${accountKey}::conn::${clean}`) ||
      connectionWarmupAliases.get(`${accountKey}::conn::${clean.toLowerCase()}`);
    if (mappedKey && connectionWarmupInFlight.has(mappedKey)) {
      return connectionWarmupInFlight.get(mappedKey)!;
    }
  }
  return null;
}

export async function awaitInFlightWarmup(
  accountKey: string,
  type: 'connection' | 'cluster',
  entityIds: (string | undefined | null)[]
): Promise<any[] | null> {
  const p = getInFlightWarmupPromise(accountKey, type, entityIds);
  if (!p) return null;
  try {
    return await p;
  } catch {
    return null;
  }
}

export async function getClusterKeyDistributionCached(
  clusterId: string,
  epoch: number,
  audienceHash: string = 'ALL',
  authType: 'human' | 'agent' = 'human'
): Promise<any> {
  const aud = (audienceHash || 'ALL').trim() || 'ALL';
  const cacheKey = `${clusterId}:${epoch}:${aud}:${authType}`;
  if (!clusterKeyDistributionInFlight.has(cacheKey)) {
    const fetchPromise = apiFetch(
      `/api/clusters/${clusterId}/key-distribution?epoch=${epoch}&audienceHash=${encodeURIComponent(aud)}`,
      { authType, cache: 'no-store' }
    )
      .then((res) => {
        if (!res?.success || res?.data?.recipientKeyMismatch || !res?.data?.encryptedKeyPackage) {
          clusterKeyDistributionInFlight.delete(cacheKey);
        } else {
          setTimeout(() => clusterKeyDistributionInFlight.delete(cacheKey), 5000);
        }
        return res;
      })
      .catch((err) => {
        clusterKeyDistributionInFlight.delete(cacheKey);
        throw err;
      });
    clusterKeyDistributionInFlight.set(cacheKey, fetchPromise);
  }
  return clusterKeyDistributionInFlight.get(cacheKey);
}

function resolvePackageDistributorPublicKey(distData: any, membersList?: any[]): any {
  if (!distData) return null;
  let parsedPkg: any = null;
  try {
    parsedPkg = typeof distData.encryptedKeyPackage === 'string'
      ? JSON.parse(distData.encryptedKeyPackage)
      : distData.encryptedKeyPackage;
  } catch {}

  const directKey =
    distData.senderPublicKeyJwk ||
    distData.senderPublicKey ||
    parsedPkg?.senderPublicKey ||
    parsedPkg?.senderPublicKeyJwk ||
    parsedPkg?.wrappingParams?.senderPublicKey;
  if (directKey) return directKey;

  const distSenderId = distData.senderAgentId || parsedPkg?.senderAgentId;
  if (distSenderId && Array.isArray(membersList)) {
    const cleanDistId = String(distSenderId).trim().replace(/^@+/, '').toLowerCase();
    const matched = membersList.find(
      (m: any) => String(m.agentId || '').trim().replace(/^@+/, '').toLowerCase() === cleanDistId
    );
    if (matched?.e2eePublicKey || matched?.publicKey) {
      return matched.e2eePublicKey || matched.publicKey;
    }
  }

  return null;
}

export async function unwrapClusterPackageAcrossEpochs(
  distData: any,
  currentLocalKeys: StoredAgentKeyEntry | null,
  userAgentId: string,
  userPassword: string | null | undefined,
  clusterId: string,
  keyEpoch: number,
  audienceHash: string,
  membersList?: any[]
): Promise<{ groupKey: CryptoKey; rawKey: Uint8Array; base64: string }> {
  let pkgObj: any = null;
  try {
    pkgObj = typeof distData.encryptedKeyPackage === 'string'
      ? JSON.parse(distData.encryptedKeyPackage)
      : distData.encryptedKeyPackage;
  } catch {}

  const primaryDistributorKey = resolvePackageDistributorPublicKey(distData, membersList);
  const distributorCandidates: any[] = [];
  const seenDistKeys = new Set<string>();
  const pushDistributorKey = (k: any) => {
    if (!k) return;
    const serialized = typeof k === 'string' ? k : JSON.stringify(k);
    if (!serialized || seenDistKeys.has(serialized)) return;
    seenDistKeys.add(serialized);
    distributorCandidates.push(k);
  };

  pushDistributorKey(primaryDistributorKey);
  pushDistributorKey(pkgObj?.senderPublicKey || pkgObj?.senderPublicKeyJwk || pkgObj?.wrappingParams?.senderPublicKey);
  pushDistributorKey(distData?.senderPublicKeyJwk || distData?.senderPublicKey);
  if (Array.isArray(distData?.senderPublicKeyHistory)) {
    for (const h of distData.senderPublicKeyHistory) {
      pushDistributorKey(h?.publicKey || h);
    }
  }

  const distSenderId = distData?.senderAgentId || pkgObj?.senderAgentId || pkgObj?.wrappingParams?.senderAgentId;
  if (distSenderId && Array.isArray(membersList)) {
    const cleanDistId = String(distSenderId).trim().replace(/^@+/, '').toLowerCase();
    const matched = membersList.find(
      (m: any) => String(m.agentId || '').trim().replace(/^@+/, '').toLowerCase() === cleanDistId
    );
    if (matched?.e2eePublicKey || matched?.publicKey) {
      pushDistributorKey(matched.e2eePublicKey || matched.publicKey);
    }
  }

  const hintedRecipEpoch =
    distData.recipientKeyEpoch || pkgObj?.recipientKeyEpoch || pkgObj?.wrappingParams?.recipientKeyEpoch;
  const targetRecipFp =
    distData.recipientKeyFingerprint || pkgObj?.recipientKeyFingerprint || pkgObj?.wrappingParams?.recipientKeyFingerprint || null;

  const candidateKeys: StoredAgentKeyEntry[] = [];
  const seenFp = new Set<string>();
  const pushKey = (k: StoredAgentKeyEntry | null | undefined) => {
    if (!k?.privateKey) return;
    const fp = k.fingerprint || k.publicKey || `ep-${k.keyEpoch || 1}-${candidateKeys.length}`;
    if (seenFp.has(fp)) return;
    seenFp.add(fp);
    candidateKeys.push(k);
  };

  if (typeof hintedRecipEpoch === 'number' && hintedRecipEpoch > 0) {
    try {
      pushKey(await getLocalKeyPair(userAgentId, hintedRecipEpoch, userPassword || undefined));
    } catch {}
  }

  pushKey(currentLocalKeys);

  try {
    const allLocal = await getAllLocalEpochKeys(userAgentId);
    for (const entry of allLocal) {
      pushKey(entry);
    }
  } catch {}

  const maxEpoch = Math.max(
    Number(currentLocalKeys?.keyEpoch || 1),
    typeof hintedRecipEpoch === 'number' ? hintedRecipEpoch : 1
  );
  for (let ep = maxEpoch; ep >= 1; ep--) {
    try {
      pushKey(await getLocalKeyPair(userAgentId, ep, userPassword || undefined));
    } catch {}
  }

  if (targetRecipFp) {
    candidateKeys.sort((a, b) => {
      const aMatch = a.fingerprint === targetRecipFp ? 0 : 1;
      const bMatch = b.fingerprint === targetRecipFp ? 0 : 1;
      return aMatch - bMatch;
    });
  }

  let lastErr: any = null;
  for (const distPubKey of distributorCandidates) {
    for (const keyEntry of candidateKeys) {
      try {
        return await unwrapClusterGroupKeyFromPackage(
          distData.encryptedKeyPackage,
          keyEntry.privateKey,
          distPubKey,
          clusterId,
          keyEpoch,
          audienceHash
        );
      } catch (err: any) {
        lastErr = err;
      }
    }
  }

  // Fallback: distributor may have rotated their personal key since sealing a legacy package without embedded senderPublicKey
  if (distSenderId && candidateKeys.length > 0) {
    try {
      const cleanDist = String(distSenderId).trim().replace(/^@+/, '');
      const distInfoRes = await apiFetch(`/api/agents/${encodeURIComponent(cleanDist)}/e2ee`, {
        authType: getCurrentSessionAuthType() || 'human',
        cache: 'no-store',
        skipDedupe: true,
      });
      const extraDistKeys: any[] = [];
      const historyObj = distInfoRes?.data?.epochHistory || distInfoRes?.epochHistory;
      if (historyObj && typeof historyObj === 'object') {
        for (const epEntry of Object.values(historyObj) as any[]) {
          if (epEntry?.publicKey) extraDistKeys.push(epEntry.publicKey);
        }
      }
      if (distInfoRes?.data?.publicKey) {
        extraDistKeys.push(distInfoRes.data.publicKey);
      }
      for (const extraPub of extraDistKeys) {
        const serialized = typeof extraPub === 'string' ? extraPub : JSON.stringify(extraPub);
        if (!serialized || seenDistKeys.has(serialized)) continue;
        seenDistKeys.add(serialized);
        for (const keyEntry of candidateKeys) {
          try {
            return await unwrapClusterGroupKeyFromPackage(
              distData.encryptedKeyPackage,
              keyEntry.privateKey,
              extraPub,
              clusterId,
              keyEpoch,
              audienceHash
            );
          } catch (err: any) {
            lastErr = err;
          }
        }
      }
    } catch {}
  }

  // Multi-device fallback: pull latest or missing historical epochs from recovery vault
  let hasTargetAfterVaultCheck = !targetRecipFp || candidateKeys.some((k) => k.fingerprint && k.fingerprint === targetRecipFp);
  try {
    const ownSync = await syncOwnLocalKeysWithServer(
      userAgentId,
      userPassword || undefined,
      getCurrentSessionAuthType() || 'human',
      {
        force: true,
        checkVaultForMissingEpochs: true,
        targetFingerprint: targetRecipFp || undefined,
        targetEpoch: typeof hintedRecipEpoch === 'number' ? hintedRecipEpoch : undefined,
      }
    );
    if (ownSync.status === 'recovery_required') {
      const recErr: any = new Error('E2EE_RECOVERY_REQUIRED: Unlock encryption recovery vault to unwrap cluster group key.');
      recErr.code = 'E2EE_RECOVERY_REQUIRED';
      throw recErr;
    }
    if (ownSync.restoredNewEpochs) {
      const refreshedCandidates: StoredAgentKeyEntry[] = [];
      if (ownSync.localKeys?.privateKey) refreshedCandidates.push(ownSync.localKeys);
      const refreshedAll = await getAllLocalEpochKeys(userAgentId).catch(() => [] as StoredAgentKeyEntry[]);
      for (const ep of refreshedAll) {
        if (ep?.privateKey && !refreshedCandidates.some((c) => c.fingerprint && c.fingerprint === ep.fingerprint)) {
          refreshedCandidates.push(ep);
        }
      }
      if (targetRecipFp) {
        hasTargetAfterVaultCheck = refreshedCandidates.some((c) => c.fingerprint && c.fingerprint === targetRecipFp);
      }
      for (const distPubKey of Array.from(seenDistKeys)) {
        for (const keyEntry of refreshedCandidates) {
          try {
            return await unwrapClusterGroupKeyFromPackage(
              distData.encryptedKeyPackage,
              keyEntry.privateKey,
              distPubKey,
              clusterId,
              keyEpoch,
              audienceHash
            );
          } catch (err: any) {
            lastErr = err;
          }
        }
      }
    }
  } catch (syncErr: any) {
    if (syncErr?.code === 'E2EE_RECOVERY_REQUIRED') {
      throw syncErr;
    }
  }

  if (distData?.recipientKeyMismatch && !hasTargetAfterVaultCheck) {
    const rekeyErr: any = new Error(
      `E2EE_REKEY_REQUIRED: Package for epoch ${keyEpoch} was wrapped for a different device key (Epoch ${hintedRecipEpoch || '?'} -> ${distData.callerCurrentKeyEpoch || currentLocalKeys?.keyEpoch || '?'}).`
    );
    rekeyErr.code = 'E2EE_REKEY_REQUIRED';
    rekeyErr.recipientKeyEpoch = hintedRecipEpoch || null;
    rekeyErr.callerCurrentKeyEpoch = distData.callerCurrentKeyEpoch || currentLocalKeys?.keyEpoch || null;
    throw rekeyErr;
  }

  if (distributorCandidates.length === 0) {
    throw new Error(`Missing key distributor public key for epoch ${keyEpoch}.`);
  }

  throw lastErr || new Error(`Failed to unwrap cluster group key for epoch ${keyEpoch}.`);
}

function dispatchMessagesUpdated(detail: {
  type: 'connection' | 'cluster';
  accountKey: string;
  connectionId?: string;
  canonicalConnectionId?: string;
  allConnectionIds?: string[];
  peerAgentId?: string;
  clusterId?: string;
  messages: any[];
  fetchedAt?: number;
}): void {
  if (typeof window === 'undefined') return;
  try {
    window.dispatchEvent(new CustomEvent('aamarva-chat-messages-updated', {
      detail: {
        ...detail,
        fetchedAt: detail.fetchedAt ?? Date.now(),
      },
    }));
  } catch {}
}

export interface WarmupConnectionParams {
  connectionId: string;
  allConnectionIds?: string[];
  peerAgentId?: string;
  peerPublicKey?: string | null;
  accountKey: string;
  userAgentId?: string | null;
  userPassword?: string | null;
  authType?: 'human' | 'agent';
}

export async function warmupConnectionChat(params: WarmupConnectionParams): Promise<any[]> {
  const {
    connectionId,
    allConnectionIds,
    peerAgentId,
    peerPublicKey,
    accountKey,
    userAgentId,
    userPassword,
  } = params;

  if (!connectionId || !userAgentId || !accountKey || accountKey === 'anon::anon') return [];

  const dedupeKey = `${accountKey}::conn::${connectionId}`;
  const aliasCandidates = [
    connectionId,
    ...(allConnectionIds || []),
    makePeerAliasKey(peerAgentId),
  ].filter((x): x is string => Boolean(x && typeof x === 'string' && x.trim()));
  for (const alias of aliasCandidates) {
    const existingAliasKey =
      connectionWarmupAliases.get(`${accountKey}::conn::${alias}`) ||
      connectionWarmupAliases.get(`${accountKey}::conn::${alias.toLowerCase()}`);
    const targetKey = existingAliasKey || `${accountKey}::conn::${alias}`;
    const existingPromise = connectionWarmupInFlight.get(targetKey);
    if (existingPromise) {
      connectionWarmupPending.add(targetKey);
      return existingPromise;
    }
  }

  const resolvedAuthType: 'human' | 'agent' = params.authType || getCurrentSessionAuthType() || 'human';

  const run = async (): Promise<any[]> => {
    try {
      const cachedPeer = getCachedPeerKey(connectionId);
      let currentPeerKey = peerPublicKey || cachedPeer?.peerPublicKey || null;
      let currentPeerEpochKeys = cachedPeer?.peerEpochKeys || {};
      let currentPeerId = peerAgentId || cachedPeer?.peerAgentId;
      let currentPeerEpoch = cachedPeer?.peerKeyEpoch || 1;
      let canonicalConnId = cachedPeer?.connectionId || connectionId;

      const existingPrewarmed = getCachedConnectionMessagesByAliases(
        [connectionId, canonicalConnId, ...(allConnectionIds || [])],
        accountKey,
        currentPeerId || peerAgentId
      );
      let sinceIso: string | undefined;
      if (existingPrewarmed.length > 0 && existingPrewarmed.every((m) => m?.isDecrypted)) {
        let maxTs = 0;
        for (const m of existingPrewarmed) {
          if (!m || typeof m.id !== 'string' || m.id.startsWith('temp_')) continue;
          const ts = m.createdAt ? new Date(m.createdAt).getTime() : 0;
          if (Number.isFinite(ts) && ts > maxTs) maxTs = ts;
        }
        if (maxTs > 0) {
          sinceIso = new Date(Math.max(0, maxTs - 1000)).toISOString();
        }
      }

      const peerQueryParts = ['prefetch=1'];
      if (currentPeerId) {
        peerQueryParts.push(`receiverAgentId=${encodeURIComponent(currentPeerId)}`);
      }
      if (sinceIso) {
        peerQueryParts.push(`since=${encodeURIComponent(sinceIso)}`);
      }
      const queryStr = `?${peerQueryParts.join('&')}`;

      const warmupStartedAt = Date.now();
      const needsKeyFetch =
        !currentPeerKey ||
        !currentPeerId ||
        Object.keys(currentPeerEpochKeys).length === 0 ||
        isPeerKeyStale(connectionId, 15000);
      const peerKeyFetchPromise = needsKeyFetch
        ? fetchConnectionPeerKey(connectionId, {
            receiverAgentId: currentPeerId,
            authType: resolvedAuthType,
            forceRefresh: isPeerKeyStale(connectionId, 15000),
            bypassCooldown: true,
          }).catch(() => null)
        : Promise.resolve(null);

      const [localKeys, responseData] = await Promise.all([
        getLocalKeyPair(userAgentId, undefined, userPassword || undefined),
        apiFetch(`/api/connections/${connectionId}/messages${queryStr}`, {
          authType: resolvedAuthType,
          cache: 'no-store',
          skipDedupe: true,
        }).catch(() => null),
      ]);

      const keyDataResult = currentPeerKey
        ? await Promise.race([peerKeyFetchPromise, new Promise<null>((r) => setTimeout(() => r(null), 150))])
        : await peerKeyFetchPromise;

      if (!localKeys?.privateKey) {
        return getCachedConnectionMessages(connectionId, accountKey);
      }

      if (keyDataResult) {
        if (keyDataResult.connectionId) canonicalConnId = keyDataResult.connectionId;
        if (keyDataResult.peerPublicKey) currentPeerKey = keyDataResult.peerPublicKey;
        if (keyDataResult.peerKeyEpoch) currentPeerEpoch = keyDataResult.peerKeyEpoch;
        if (keyDataResult.peerEpochKeys) currentPeerEpochKeys = keyDataResult.peerEpochKeys;
        if (keyDataResult.peerAgentId) currentPeerId = keyDataResult.peerAgentId;
      }

      const rawList = Array.isArray(responseData?.data)
        ? responseData.data
        : Array.isArray(responseData)
          ? responseData
          : null;

      if (!Array.isArray(rawList)) {
        return getCachedConnectionMessages(connectionId, accountKey);
      }

      const historicalKeyCache = new Map<number, CryptoKey | string>();
      const allLocalKeysList = await getAllLocalEpochKeys(userAgentId).catch(() => [] as StoredAgentKeyEntry[]);
      for (const epEntry of allLocalKeysList) {
        if (epEntry?.privateKey) {
          historicalKeyCache.set(epEntry.keyEpoch || 1, epEntry.privateKey);
        }
      }
      if (localKeys.privateKey) {
        historicalKeyCache.set(localKeys.keyEpoch || 1, localKeys.privateKey);
      }
      const peerLookupPromises = new Map<string, Promise<{ peerPublicKey: string | null; peerEpochKeys?: Record<string, any> }>>();

      const resolvePeerFallbackBundle = (
        targetPeer: string,
        forceRefresh = false
      ): Promise<{ peerPublicKey: string | null; peerEpochKeys?: Record<string, any> }> => {
        const clean = normalizeAgentId(targetPeer);
        if (!clean || clean === 'PEER') return Promise.resolve({ peerPublicKey: null });
        const mapKey = forceRefresh ? `${clean}#force` : clean;
        const existing = peerLookupPromises.get(mapKey);
        if (existing) return existing;

        const p = (async () => {
          try {
            const peerInfo = await fetchConnectionPeerKey(connectionId, {
              receiverAgentId: targetPeer,
              authType: resolvedAuthType,
              forceRefresh,
              bypassCooldown: forceRefresh,
            });
            if (peerInfo?.peerPublicKey || (peerInfo?.peerEpochKeys && Object.keys(peerInfo.peerEpochKeys).length > 0)) {
              return { peerPublicKey: peerInfo.peerPublicKey || null, peerEpochKeys: peerInfo.peerEpochKeys };
            }
          } catch {}
          try {
            const agentKeyRes = await apiFetch(`/api/agents/${targetPeer}/e2ee`, {
              authType: resolvedAuthType,
              cache: 'no-store',
              skipDedupe: forceRefresh,
            });
            return {
              peerPublicKey: agentKeyRes?.data?.publicKey || agentKeyRes?.publicKey || null,
              peerEpochKeys: agentKeyRes?.data?.epochHistory || agentKeyRes?.data?.epochKeys || agentKeyRes?.epochHistory || agentKeyRes?.epochKeys,
            };
          } catch {
            return { peerPublicKey: null };
          }
        })();

        peerLookupPromises.set(mapKey, p);
        return p;
      };

      const processed = await Promise.all(
        rawList.map(async (m: any) => {
          const sender = m.senderAgentId || 'Agent';
          const ciphertext = m.ciphertext;
          const nonce = m.nonce;
          const msgEpoch = m.keyEpoch || 1;
          const isPublicContext = m.id && (m.id.startsWith('msg_post_') || m.id.startsWith('msg_reply_'));

          if (isPublicContext && m.content) {
            return {
              id: m.id,
              connectionId: m.connectionId || connectionId,
              senderAgentId: sender,
              content: m.content,
              isDecrypted: true,
              keyEpoch: msgEpoch,
              sequence: typeof m.sequence === 'number' ? m.sequence : undefined,
              createdAt: m.createdAt,
            };
          }

          const cachedPlain = getCachedDecryptedMessage([
            m.id,
            m.messageId,
            m.nonce,
            m.ciphertext,
            `${connectionId}_${m.id}`,
            `${canonicalConnId}_${m.id}`,
            `${connectionId}_${m.nonce}`,
            `${connectionId}_${m.ciphertext}`,
          ]);

          if (cachedPlain && !isDecryptionErrorPlaceholder(cachedPlain)) {
            return {
              id: m.id,
              connectionId: m.connectionId || connectionId,
              senderAgentId: sender,
              content: cachedPlain,
              isDecrypted: true,
              keyEpoch: msgEpoch,
              sequence: typeof m.sequence === 'number' ? m.sequence : undefined,
              createdAt: m.createdAt,
            };
          }

          let resolvedPlaintext: string | null = null;
          if (ciphertext && nonce) {
            try {
              const candidateLocalKeys: (CryptoKey | string)[] = [];
              const pushLocalCandidate = (k?: CryptoKey | string | null) => {
                if (k && !candidateLocalKeys.includes(k)) candidateLocalKeys.push(k);
              };

              let exactEpochKey = historicalKeyCache.get(msgEpoch);
              if (!exactEpochKey && msgEpoch !== (localKeys.keyEpoch || 1)) {
                const historical = await getLocalKeyPair(userAgentId, msgEpoch, userPassword || undefined);
                if (historical?.privateKey) {
                  exactEpochKey = historical.privateKey;
                  historicalKeyCache.set(msgEpoch, exactEpochKey);
                }
              }
              pushLocalCandidate(exactEpochKey);
              pushLocalCandidate(localKeys.privateKey);
              const sortedLocal = Array.from(historicalKeyCache.entries()).sort(
                ([a], [b]) => Math.abs(a - msgEpoch) - Math.abs(b - msgEpoch)
              );
              for (const [, k] of sortedLocal) {
                pushLocalCandidate(k);
              }

              const isMyMessage = normalizeAgentId(m.senderAgentId) === normalizeAgentId(userAgentId);
              const targetPeer = isMyMessage ? (currentPeerId || peerAgentId || 'peer') : m.senderAgentId;

              let senderPubKey = await resolveSenderPublicKey(
                targetPeer,
                msgEpoch,
                currentPeerEpochKeys,
                currentPeerKey,
                currentPeerEpoch
              );

              let didForceRefresh = false;
              let refreshedBundle: { peerPublicKey: string | null; peerEpochKeys?: Record<string, any> } | null = null;
              if (!senderPubKey && targetPeer && targetPeer !== 'peer') {
                didForceRefresh = true;
                refreshedBundle = await resolvePeerFallbackBundle(targetPeer, true);
                senderPubKey = refreshedBundle.peerPublicKey;
              }

              const candidatePeerKeys: any[] = [];
              const pushPeerKey = (pk: any) => {
                if (!pk) return;
                const s = typeof pk === 'string' ? pk : JSON.stringify(pk);
                if (s && !candidatePeerKeys.includes(s)) candidatePeerKeys.push(s);
              };
              pushPeerKey(senderPubKey);
              pushPeerKey(currentPeerKey);
              pushPeerKey(peerPublicKey);
              const appendEpochKeys = (epMap?: Record<string, any>) => {
                if (!epMap || typeof epMap !== 'object') return;
                const ordered = Object.entries(epMap).sort(
                  ([a], [b]) => Math.abs(Number(a) - msgEpoch) - Math.abs(Number(b) - msgEpoch)
                );
                for (const [, epVal] of ordered) {
                  pushPeerKey(epVal?.publicKey);
                }
              };
              appendEpochKeys(currentPeerEpochKeys);
              appendEpochKeys(refreshedBundle?.peerEpochKeys);

              const candidateConnIds = Array.from(
                new Set([m.connectionId, canonicalConnId, connectionId, ...(allConnectionIds || [])].filter(Boolean))
              );

              const tryCombos = async (peerKeysToTry: any[]) => {
                for (const privCand of candidateLocalKeys) {
                  if (resolvedPlaintext) break;
                  for (const keyCandidate of peerKeysToTry) {
                    if (resolvedPlaintext) break;
                    for (const cid of candidateConnIds) {
                      try {
                        resolvedPlaintext = await decryptMessage(
                          { ciphertext, nonce, version: m.version || 1, keyEpoch: msgEpoch },
                          privCand,
                          keyCandidate,
                          cid,
                          m.senderAgentId || 'AGENT'
                        );
                        if (resolvedPlaintext) break;
                      } catch {}
                    }
                  }
                }
              };

              await tryCombos(candidatePeerKeys);

              if (!resolvedPlaintext && !didForceRefresh && targetPeer && targetPeer !== 'peer') {
                const freshBundle = await resolvePeerFallbackBundle(targetPeer, true);
                const freshPeerKeys: any[] = [];
                const pushFresh = (pk: any) => {
                  if (!pk) return;
                  const s = typeof pk === 'string' ? pk : JSON.stringify(pk);
                  if (s && !candidatePeerKeys.includes(s) && !freshPeerKeys.includes(s)) {
                    freshPeerKeys.push(s);
                  }
                };
                if (freshBundle.peerEpochKeys?.[String(msgEpoch)]?.publicKey) {
                  pushFresh(freshBundle.peerEpochKeys[String(msgEpoch)].publicKey);
                }
                pushFresh(freshBundle.peerPublicKey);
                if (freshBundle.peerEpochKeys && typeof freshBundle.peerEpochKeys === 'object') {
                  for (const epVal of Object.values(freshBundle.peerEpochKeys)) {
                    pushFresh((epVal as any)?.publicKey);
                  }
                }
                if (freshPeerKeys.length > 0) {
                  await tryCombos(freshPeerKeys);
                }
              }
            } catch {}
          }

          if (typeof resolvedPlaintext === 'string' && !isDecryptionErrorPlaceholder(resolvedPlaintext)) {
            cacheDecryptedMessage(resolvedPlaintext, [
              m.id,
              m.messageId,
              m.nonce,
              m.ciphertext,
              `${connectionId}_${m.id}`,
              `${canonicalConnId}_${m.id}`,
              `${connectionId}_${m.nonce}`,
              `${connectionId}_${m.ciphertext}`,
            ]);
            return {
              id: m.id,
              connectionId: m.connectionId || canonicalConnId || connectionId,
              senderAgentId: sender,
              content: resolvedPlaintext,
              isDecrypted: true,
              keyEpoch: msgEpoch,
              sequence: typeof m.sequence === 'number' ? m.sequence : undefined,
              createdAt: m.createdAt,
            };
          }

          return {
            id: m.id,
            connectionId: m.connectionId || canonicalConnId || connectionId,
            senderAgentId: sender,
            content: '🔒 [Encrypted message - verifying keys]',
            isDecrypted: false,
            keyEpoch: msgEpoch,
            sequence: typeof m.sequence === 'number' ? m.sequence : undefined,
            createdAt: m.createdAt,
          };
        })
      );

      if (processed.some((p) => !p.isDecrypted)) {
        try {
          const ownSync = await syncOwnLocalKeysWithServer(userAgentId, userPassword || undefined, resolvedAuthType, { force: true });
          if (ownSync.restoredNewEpochs && ownSync.localKeys?.privateKey) {
            const refreshedAll = await getAllLocalEpochKeys(userAgentId).catch(() => [] as StoredAgentKeyEntry[]);
            for (const epEntry of refreshedAll) {
              if (epEntry?.privateKey) {
                historicalKeyCache.set(epEntry.keyEpoch || 1, epEntry.privateKey);
              }
            }
            historicalKeyCache.set(ownSync.localKeys.keyEpoch || 1, ownSync.localKeys.privateKey);

            await Promise.all(
              processed.map(async (item, idx) => {
                if (item.isDecrypted) return;
                const m = rawList[idx];
                if (!m?.ciphertext || !m?.nonce) return;
                const msgEpoch = m.keyEpoch || 1;
                const isMyMessage = normalizeAgentId(m.senderAgentId) === normalizeAgentId(userAgentId);
                const targetPeer = isMyMessage ? (currentPeerId || peerAgentId || 'peer') : m.senderAgentId;
                const freshBundle = targetPeer && targetPeer !== 'peer' ? await resolvePeerFallbackBundle(targetPeer, true) : null;
                const candidateLocalKeys: (CryptoKey | string)[] = [];
                if (historicalKeyCache.has(msgEpoch)) candidateLocalKeys.push(historicalKeyCache.get(msgEpoch)!);
                if (!candidateLocalKeys.includes(ownSync.localKeys.privateKey)) candidateLocalKeys.push(ownSync.localKeys.privateKey);
                for (const [, k] of historicalKeyCache.entries()) {
                  if (!candidateLocalKeys.includes(k)) candidateLocalKeys.push(k);
                }
                const candidatePeerKeys: any[] = [];
                const pushPk = (pk: any) => {
                  if (!pk) return;
                  const s = typeof pk === 'string' ? pk : JSON.stringify(pk);
                  if (s && !candidatePeerKeys.includes(s)) candidatePeerKeys.push(s);
                };
                pushPk(freshBundle?.peerEpochKeys?.[String(msgEpoch)]?.publicKey);
                pushPk(freshBundle?.peerPublicKey);
                pushPk(currentPeerKey);
                if (freshBundle?.peerEpochKeys) {
                  for (const epVal of Object.values(freshBundle.peerEpochKeys)) pushPk((epVal as any)?.publicKey);
                }
                if (currentPeerEpochKeys) {
                  for (const epVal of Object.values(currentPeerEpochKeys)) pushPk((epVal as any)?.publicKey);
                }
                const candidateConnIds = Array.from(
                  new Set([m.connectionId, canonicalConnId, connectionId, ...(allConnectionIds || [])].filter(Boolean))
                );
                for (const privCand of candidateLocalKeys) {
                  for (const keyCandidate of candidatePeerKeys) {
                    for (const cid of candidateConnIds) {
                      try {
                        const plain = await decryptMessage(
                          { ciphertext: m.ciphertext, nonce: m.nonce, version: m.version || 1, keyEpoch: msgEpoch },
                          privCand,
                          keyCandidate,
                          cid,
                          m.senderAgentId || 'AGENT'
                        );
                        if (typeof plain === 'string' && !isDecryptionErrorPlaceholder(plain)) {
                          cacheDecryptedMessage(plain, [
                            m.id,
                            m.messageId,
                            m.nonce,
                            m.ciphertext,
                            `${connectionId}_${m.id}`,
                            `${canonicalConnId}_${m.id}`,
                            `${connectionId}_${m.nonce}`,
                            `${connectionId}_${m.ciphertext}`,
                          ]);
                          processed[idx] = { ...item, content: plain, isDecrypted: true };
                          return;
                        }
                      } catch {}
                    }
                  }
                }
              })
            );
          }
        } catch {}
      }

      // Reconcile with any previously cached decrypted or optimistic messages
      const existingPrev = getCachedConnectionMessagesByAliases(
        [connectionId, canonicalConnId, ...(allConnectionIds || [])],
        accountKey,
        currentPeerId || peerAgentId
      );
      const prevDecryptedMap = new Map<string, any>();
      for (const p of existingPrev) {
        if (p?.isDecrypted && p.content && !isDecryptionErrorPlaceholder(p.content)) {
          if (p.id) prevDecryptedMap.set(p.id, p);
          if (typeof p.sequence === 'number') prevDecryptedMap.set(`seq_${p.sequence}`, p);
        }
      }

      const merged = processed.map((newMsg) => {
        if (!newMsg.isDecrypted) {
          const prevMsg =
            prevDecryptedMap.get(newMsg.id) ||
            (typeof newMsg.sequence === 'number' ? prevDecryptedMap.get(`seq_${newMsg.sequence}`) : undefined);
          if (prevMsg && prevMsg.isDecrypted && !isDecryptionErrorPlaceholder(prevMsg.content)) {
            return {
              ...newMsg,
              content: prevMsg.content,
              isDecrypted: true,
            };
          }
        }
        return newMsg;
      });

      const mergedIds = new Set(merged.map((m) => m.id).filter(Boolean));
      const nowMs = Date.now();
      const recentSseMessages = existingPrev.filter((p) => {
        if (!p || typeof p.id !== 'string' || p.id.startsWith('temp_') || mergedIds.has(p.id)) return false;
        if (!p.isDecrypted || isDecryptionErrorPlaceholder(p.content)) return false;
        if (sinceIso) return true;
        const ts = p.createdAt ? new Date(p.createdAt).getTime() : 0;
        return Number.isFinite(ts) && nowMs - ts < 30000;
      });

      const inFlightOptimistic = existingPrev.filter(
        (p) =>
          typeof p?.id === 'string' &&
          p.id.startsWith('temp_') &&
          !merged.some((m) => m.content === p.content && m.senderAgentId === p.senderAgentId)
      );

      const combined = [...merged, ...recentSseMessages, ...inFlightOptimistic].sort((a, b) => {
        const timeDiff = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
        if (timeDiff !== 0) return timeDiff;
        if (typeof a.sequence === 'number' && typeof b.sequence === 'number' && a.sequence !== b.sequence) {
          return a.sequence - b.sequence;
        }
        return String(a.id).localeCompare(String(b.id));
      });

      const peerAliasKey = makePeerAliasKey(currentPeerId || peerAgentId);
      const targetCacheIds = new Set<string>(
        [
          connectionId,
          canonicalConnId,
          peerAliasKey,
          ...(allConnectionIds || []),
          ...combined.map((m) => m.connectionId),
        ].filter((id): id is string => Boolean(id && typeof id === 'string' && id.trim()))
      );
      const targetCacheList = Array.from(targetCacheIds);
      targetCacheList.forEach((cid) => setCachedConnectionMessages(cid, combined, accountKey));
      recordWarmupCompleted(accountKey, 'connection', targetCacheList);

      dispatchMessagesUpdated({
        type: 'connection',
        accountKey,
        connectionId,
        canonicalConnectionId: canonicalConnId,
        allConnectionIds: targetCacheList,
        peerAgentId: currentPeerId,
        messages: combined,
        fetchedAt: warmupStartedAt,
      });

      return combined;
    } catch {
      return getCachedConnectionMessagesByAliases(
        [connectionId, ...(allConnectionIds || [])],
        accountKey,
        peerAgentId
      );
    } finally {
      connectionWarmupInFlight.delete(dedupeKey);
      for (const alias of aliasCandidates) {
        connectionWarmupAliases.delete(`${accountKey}::conn::${alias}`);
        connectionWarmupAliases.delete(`${accountKey}::conn::${alias.toLowerCase()}`);
      }
      if (connectionWarmupPending.has(dedupeKey)) {
        connectionWarmupPending.delete(dedupeKey);
        setTimeout(() => {
          warmupConnectionChat(params).catch(() => {});
        }, 0);
      }
    }
  };

  const promise = run();
  connectionWarmupInFlight.set(dedupeKey, promise);
  for (const alias of aliasCandidates) {
    connectionWarmupAliases.set(`${accountKey}::conn::${alias}`, dedupeKey);
    connectionWarmupAliases.set(`${accountKey}::conn::${alias.toLowerCase()}`, dedupeKey);
  }
  return promise;
}

export interface WarmupClusterParams {
  clusterId: string;
  clusterName?: string;
  accountKey: string;
  accountId: string;
  userAgentId?: string | null;
  userPassword?: string | null;
  authType?: 'human' | 'agent';
  members?: any[];
  activeCluster?: any;
}

export async function warmupClusterChat(params: WarmupClusterParams): Promise<any[]> {
  const { clusterId, clusterName, accountKey, accountId, userAgentId, userPassword } = params;
  if (!clusterId || !userAgentId || !accountKey || accountKey === 'anon::anon') return [];

  const dedupeKey = `${accountKey}::clu::${clusterId}`;
  const existingPromise = clusterWarmupInFlight.get(dedupeKey);
  if (existingPromise) {
    clusterWarmupPending.add(dedupeKey);
    return existingPromise;
  }

  const resolvedAuthType: 'human' | 'agent' = params.authType || getCurrentSessionAuthType() || 'human';

  const run = async (): Promise<any[]> => {
    try {
      const localKeys = await getLocalKeyPair(userAgentId, undefined, userPassword || undefined);
      if (!localKeys?.privateKey) {
        return getCachedClusterMessages(clusterId, accountKey);
      }

      const cachedClusters = getQueryCache(accountKey, '/api/clusters')?.data;
      const clusterMeta =
        params.activeCluster ||
        (Array.isArray(cachedClusters)
          ? cachedClusters.find((c: any) => String(c.id || '').toLowerCase() === clusterId.toLowerCase())
          : null);
      const cachedMembersEntry = getQueryCache(accountKey, `/api/clusters/public/${clusterId}/members`)?.data;
      let membersList: any[] =
        params.members ||
        (Array.isArray(cachedMembersEntry) ? cachedMembersEntry : cachedMembersEntry?.members) ||
        [];
      let clusterMemberFetchPromise: Promise<any[]> | null = null;
      const ensureMembersLoaded = async (): Promise<any[]> => {
        if (membersList.length > 0) return membersList;
        if (!clusterMemberFetchPromise) {
          clusterMemberFetchPromise = apiFetch(`/api/clusters/public/${clusterId}/members`, { authType: 'none' })
            .then((res) => {
              const list = Array.isArray(res?.data?.members)
                ? res.data.members
                : Array.isArray(res?.data)
                  ? res.data
                  : [];
              if (list.length > 0) {
                membersList = list;
                setQueryCache(accountKey, `/api/clusters/public/${clusterId}/members`, list);
              }
              return list;
            })
            .catch(() => []);
        }
        return clusterMemberFetchPromise;
      };

      const existingClusterPrewarmed = getCachedClusterMessages(clusterId, accountKey);
      let clusterSinceIso: string | undefined;
      if (existingClusterPrewarmed.length > 0 && existingClusterPrewarmed.every((m) => m?.isDecrypted)) {
        let maxTs = 0;
        for (const m of existingClusterPrewarmed) {
          if (!m || typeof m.id !== 'string' || m.id.startsWith('temp_')) continue;
          const ts = m.createdAt ? new Date(m.createdAt).getTime() : 0;
          if (Number.isFinite(ts) && ts > maxTs) maxTs = ts;
        }
        if (maxTs > 0) {
          clusterSinceIso = new Date(Math.max(0, maxTs - 1000)).toISOString();
        }
      }

      const clusterMsgsUrl = clusterSinceIso
        ? `/api/clusters/${clusterId}/messages?since=${encodeURIComponent(clusterSinceIso)}`
        : `/api/clusters/${clusterId}/messages`;

      const msgsRes = await apiFetch(clusterMsgsUrl, {
        authType: resolvedAuthType,
      }).catch(() => null);

      if (!msgsRes?.success || !Array.isArray(msgsRes.data)) {
        return existingClusterPrewarmed;
      }

      const rawList = msgsRes.data;
      const myAgentNorm = normalizeAgentId(userAgentId);
      const resolvedClusterName =
        clusterName || clusterMeta?.name || clusterMeta?.clusterName || clusterMeta?.cluster?.name || '';

      const decryptedList = await Promise.all(
        rawList.map(async (m: any) => {
          const msgId = m.id || m.messageId;
          const cacheKey = `${accountId}:${clusterId}:${msgId}`;
          const memberMeta = membersList.find(
            (mem: any) => mem?.agentId && m?.senderAgentId && mem.agentId.toLowerCase() === m.senderAgentId.toLowerCase()
          );

          const keyCandidates = [
            cacheKey,
            msgId ? `${clusterId}_${msgId}` : null,
            msgId,
            m.nonce ? `${clusterId}_${m.nonce}` : null,
            m.ciphertext ? `${clusterId}_${m.ciphertext}` : null,
            m.nonce,
            m.ciphertext,
          ].filter(Boolean);

          const cachedPlaintext = getCachedDecryptedMessage(keyCandidates);
          const isSenderMe = myAgentNorm && normalizeAgentId(m.senderAgentId) === myAgentNorm;
          const isSenderMaster = Boolean((isSenderMe && !isSlaveAccount({ agentId: userAgentId })) || (memberMeta && !memberMeta.isSlave));
          let resolvedSenderAvatar = memberMeta?.avatar || memberMeta?.agentAvatar || m.senderAgentAvatar;
          if (isSenderMaster && (!resolvedSenderAvatar || resolvedSenderAvatar.includes('robohash') || resolvedSenderAvatar === '🤖')) {
            resolvedSenderAvatar = undefined;
          }

          if (cachedPlaintext && !isDecryptionErrorPlaceholder(cachedPlaintext)) {
            return {
              id: msgId,
              clusterId: m.clusterId || clusterId,
              senderAgentId: m.senderAgentId,
              senderAgentName: memberMeta?.agentName || memberMeta?.name || m.senderAgentName || m.senderAgentId,
              senderAgentAvatar: resolvedSenderAvatar,
              content: cachedPlaintext,
              ciphertext: m.ciphertext,
              nonce: m.nonce,
              sequence: m.sequence,
              recipients: m.recipients || [],
              isDecrypted: true,
              createdAt: m.createdAt,
            };
          }

          const ciphertext = typeof m.ciphertext === 'string' ? m.ciphertext.trim() : '';
          const nonce = typeof m.nonce === 'string' ? m.nonce.trim() : '';
          const content = typeof m.content === 'string' ? m.content.trim() : '';
          const senderAgentId = m.senderAgentId || 'Agent';
          const keyEpoch = m.keyEpoch || 1;
          const version = m.version || 2;
          const audienceHash = String(m.audienceHash || m.keys?.audienceHash || 'ALL').trim() || 'ALL';
          const senderDisplayName =
            m.senderAgentName ||
            m.senderDisplayName ||
            m.senderName ||
            memberMeta?.name ||
            memberMeta?.agentName ||
            '';

          if (content && content !== '🔒 [E2EE Encrypted Payload]' && !ciphertext) {
            return {
              id: msgId,
              clusterId: m.clusterId || clusterId,
              senderAgentId,
              senderAgentName: senderDisplayName || senderAgentId,
              senderAgentAvatar: resolvedSenderAvatar,
              content,
              ciphertext: m.ciphertext,
              nonce: m.nonce,
              sequence: m.sequence,
              recipients: m.recipients || [],
              isDecrypted: true,
              createdAt: m.createdAt,
            };
          }

          let resolvedPlaintext: string | null = null;
          let decryptionStatus: any = undefined;
          if (ciphertext && nonce) {
            try {
              // Fast-path: attempt local group key FIRST (avoids /key-distribution round-trip if already cached)
              const localGroupKey = await getClusterGroupKey(clusterId, keyEpoch, undefined, audienceHash);
              if (localGroupKey) {
                try {
                  resolvedPlaintext = await decryptClusterMessage(
                    ciphertext,
                    nonce,
                    localGroupKey,
                    senderAgentId,
                    clusterId,
                    keyEpoch,
                    version,
                    senderDisplayName,
                    resolvedClusterName,
                    audienceHash
                  );
                } catch {
                  await deleteClusterGroupKey(clusterId, keyEpoch, audienceHash);
                  resolvedPlaintext = null;
                }
              }

              // Server distribution fallback ONLY when local key missing or rotated
              if (!resolvedPlaintext) {
                const distRes = await getClusterKeyDistributionCached(clusterId, keyEpoch, audienceHash, resolvedAuthType).catch(
                  () => null
                );
                const authoritativeFp = distRes?.success && distRes.data?.keyFingerprint ? distRes.data.keyFingerprint : undefined;
                let groupKey = await getClusterGroupKey(clusterId, keyEpoch, authoritativeFp, audienceHash);
                if (!groupKey && distRes?.success && distRes.data?.encryptedKeyPackage) {
                  let activeMembers = membersList;
                  if (!resolvePackageDistributorPublicKey(distRes.data, activeMembers)) {
                    activeMembers = await ensureMembersLoaded();
                  }
                  const unwrapped = await unwrapClusterPackageAcrossEpochs(
                    distRes.data,
                    localKeys,
                    userAgentId,
                    userPassword,
                    clusterId,
                    keyEpoch,
                    audienceHash,
                    activeMembers
                  );
                  const calculatedFp = await computeRawGroupKeyFingerprint(unwrapped.rawKey);
                  if (!authoritativeFp || calculatedFp === authoritativeFp) {
                    groupKey = unwrapped.groupKey;
                    await saveClusterGroupKey(clusterId, keyEpoch, unwrapped.rawKey, calculatedFp, audienceHash);
                  }
                } else if (!groupKey && distRes?.data?.recipientKeyMismatch) {
                  const ownSync = await syncOwnLocalKeysWithServer(userAgentId, userPassword || undefined, resolvedAuthType, {
                    force: true,
                    checkVaultForMissingEpochs: true,
                    targetFingerprint: distRes.data.recipientKeyFingerprint || undefined,
                    targetEpoch: typeof distRes.data.recipientKeyEpoch === 'number' ? distRes.data.recipientKeyEpoch : undefined,
                  }).catch(() => null);
                  if (ownSync?.status === 'recovery_required') {
                    decryptionStatus = {
                      code: 'E2EE_RECOVERY_REQUIRED',
                      title: '🔒 Encrypted message awaiting key sync',
                      detail: 'Encryption key for this epoch is unavailable on this device',
                      explanation: 'Sign in with your account password on this device or have a cluster admin re-wrap historical keys.',
                    };
                  }
                }
                if (groupKey) {
                  resolvedPlaintext = await decryptClusterMessage(
                    ciphertext,
                    nonce,
                    groupKey,
                    senderAgentId,
                    clusterId,
                    keyEpoch,
                    version,
                    senderDisplayName,
                    resolvedClusterName,
                    audienceHash
                  );
                }
              }
            } catch (err: any) {
              if (err?.code === 'E2EE_RECOVERY_REQUIRED' || String(err?.message || '').includes('E2EE_RECOVERY_REQUIRED')) {
                decryptionStatus = {
                  code: 'E2EE_RECOVERY_REQUIRED',
                  title: '🔒 Encrypted message awaiting key sync',
                  detail: 'Encryption key for this epoch is unavailable on this device',
                  explanation: 'Sign in with your account password on this device or have a cluster admin re-wrap historical keys.',
                };
              } else if (err?.code === 'E2EE_REKEY_REQUIRED' || String(err?.message || '').includes('E2EE_REKEY_REQUIRED')) {
                decryptionStatus = {
                  code: 'E2EE_REKEY_REQUIRED',
                  title: '🔒 Waiting for cluster key sync for this device',
                  detail: err?.message || 'Package sealed for prior device key epoch',
                  explanation: 'Have a cluster admin open this chat to re-wrap historical keys for your current device key.',
                };
              }
            }
          }

          if (resolvedPlaintext && !isDecryptionErrorPlaceholder(resolvedPlaintext)) {
            cacheDecryptedMessage(resolvedPlaintext, keyCandidates);
            return {
              id: msgId,
              clusterId: m.clusterId || clusterId,
              senderAgentId,
              senderAgentName: senderDisplayName || senderAgentId,
              senderAgentAvatar: resolvedSenderAvatar,
              content: resolvedPlaintext,
              ciphertext: m.ciphertext,
              nonce: m.nonce,
              sequence: m.sequence,
              recipients: m.recipients || [],
              isDecrypted: true,
              createdAt: m.createdAt,
            };
          }

          return {
            id: msgId,
            clusterId: m.clusterId || clusterId,
            senderAgentId,
            senderAgentName: senderDisplayName || senderAgentId,
            senderAgentAvatar: resolvedSenderAvatar,
            content: decryptionStatus?.title || '🔒 [Encrypted message - verifying keys]',
            ciphertext: m.ciphertext,
            nonce: m.nonce,
            sequence: m.sequence,
            recipients: m.recipients || [],
            isDecrypted: false,
            ...(decryptionStatus ? { decryptionStatus } : {}),
            createdAt: m.createdAt,
          };
        })
      );

      const existingPrev = getCachedClusterMessages(clusterId, accountKey);
      const prevDecryptedMap = new Map<string, any>();
      for (const p of existingPrev) {
        if (p?.isDecrypted && p.content && !isDecryptionErrorPlaceholder(p.content)) {
          if (p.id) prevDecryptedMap.set(p.id, p);
          if (typeof p.sequence === 'number' && Number.isFinite(p.sequence)) {
            prevDecryptedMap.set(`seq_${p.sequence}`, p);
          }
        }
      }

      const merged = decryptedList.map((newMsg) => {
        if (!newMsg.isDecrypted) {
          const prevMsg =
            prevDecryptedMap.get(newMsg.id) ||
            (typeof newMsg.sequence === 'number' && Number.isFinite(newMsg.sequence)
              ? prevDecryptedMap.get(`seq_${newMsg.sequence}`)
              : undefined);
          if (prevMsg && prevMsg.isDecrypted && !isDecryptionErrorPlaceholder(prevMsg.content)) {
            return {
              ...newMsg,
              content: prevMsg.content,
              isDecrypted: true,
            };
          }
        }
        return newMsg;
      });

      const mergedIds = new Set(merged.map((m) => m.id).filter(Boolean));
      const nowMs = Date.now();
      const recentSseMessages = existingPrev.filter((p) => {
        if (!p || typeof p.id !== 'string' || p.id.startsWith('temp_cluster_') || mergedIds.has(p.id)) return false;
        if (!p.isDecrypted || isDecryptionErrorPlaceholder(p.content)) return false;
        if (clusterSinceIso) return true;
        const ts = p.createdAt ? new Date(p.createdAt).getTime() : 0;
        return Number.isFinite(ts) && nowMs - ts < 30000;
      });

      const inFlightOptimistic = existingPrev.filter(
        (p) =>
          typeof p?.id === 'string' &&
          p.id.startsWith('temp_cluster_') &&
          !merged.some((m) => m.content === p.content && m.senderAgentId === p.senderAgentId)
      );
      const combined = [...merged, ...recentSseMessages, ...inFlightOptimistic].sort((a, b) => {
        const timeDiff = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
        if (timeDiff !== 0) return timeDiff;
        if (typeof a.sequence === 'number' && typeof b.sequence === 'number' && a.sequence !== b.sequence) {
          return a.sequence - b.sequence;
        }
        return String(a.id).localeCompare(String(b.id));
      });
      setCachedClusterMessages(clusterId, combined, accountKey);
      recordWarmupCompleted(accountKey, 'cluster', [clusterId]);

      dispatchMessagesUpdated({
        type: 'cluster',
        accountKey,
        clusterId,
        messages: combined,
      });

      return combined;
    } catch {
      return getCachedClusterMessages(clusterId, accountKey);
    } finally {
      clusterWarmupInFlight.delete(dedupeKey);
      if (clusterWarmupPending.has(dedupeKey)) {
        clusterWarmupPending.delete(dedupeKey);
        setTimeout(() => {
          warmupClusterChat(params).catch(() => {});
        }, 0);
      }
    }
  };

  const promise = run();
  clusterWarmupInFlight.set(dedupeKey, promise);
  return promise;
}

export async function ingestRealtimeConnectionMessage(params: {
  connectionId: string;
  allConnectionIds?: string[];
  messageId?: string | null;
  senderAgentId?: string | null;
  peerAgentId?: string | null;
  peerPublicKey?: string | null;
  senderPublicKey?: string | null;
  senderKeyEpoch?: number | null;
  ciphertext?: string | null;
  nonce?: string | null;
  version?: number | null;
  keyEpoch?: number | null;
  sequence?: number | null;
  createdAt?: string | null;
  accountKey: string;
  userAgentId?: string | null;
  userPassword?: string | null;
  authType?: 'human' | 'agent';
}): Promise<boolean> {
  const {
    connectionId,
    allConnectionIds,
    messageId,
    senderAgentId,
    peerAgentId,
    peerPublicKey,
    senderPublicKey,
    ciphertext,
    nonce,
    version,
    keyEpoch,
    sequence,
    createdAt,
    accountKey,
    userAgentId,
    userPassword,
    authType,
  } = params;

  if (!connectionId || !userAgentId || !accountKey || accountKey === 'anon::anon') return false;

  const fallbackWarmup = () =>
    warmupConnectionChat({
      connectionId,
      allConnectionIds,
      peerAgentId: peerAgentId || senderAgentId || undefined,
      peerPublicKey: senderPublicKey || peerPublicKey,
      accountKey,
      userAgentId,
      userPassword,
      authType,
    }).catch(() => []);

  if (!ciphertext || !nonce || !messageId) {
    await fallbackWarmup();
    return false;
  }

  const candidateIds = Array.from(
    new Set([connectionId, ...(allConnectionIds || [])].filter((id): id is string => Boolean(id && typeof id === 'string' && id.trim())))
  );
  const existingPrev = getCachedConnectionMessagesByAliases(
    candidateIds,
    accountKey,
    peerAgentId || senderAgentId
  );

  // If this exact message is already cached and decrypted, just ensure alias caches & notify listeners
  const alreadyCached = existingPrev.find(
    (m) => m && m.isDecrypted && !isDecryptionErrorPlaceholder(m.content) && (m.id === messageId || (nonce && m.nonce === nonce))
  );
  if (alreadyCached) {
    dispatchMessagesUpdated({
      type: 'connection',
      accountKey,
      connectionId,
      canonicalConnectionId: connectionId,
      allConnectionIds: candidateIds,
      peerAgentId: peerAgentId || senderAgentId || undefined,
      messages: existingPrev,
    });
    return true;
  }

  try {
    const msgEpoch = typeof keyEpoch === 'number' && keyEpoch >= 1 ? keyEpoch : 1;
    const effectiveSenderEpoch =
      typeof params.senderKeyEpoch === 'number' && params.senderKeyEpoch >= 1
        ? params.senderKeyEpoch
        : msgEpoch;
    const candidateLocalKeys: (CryptoKey | string)[] = [];
    const pushLocalKey = (k?: CryptoKey | string | null) => {
      if (k && !candidateLocalKeys.includes(k)) candidateLocalKeys.push(k);
    };
    const exactLocal = await getLocalKeyPair(userAgentId, msgEpoch, userPassword || undefined);
    pushLocalKey(exactLocal?.privateKey);
    const activeLocal = await getLocalKeyPair(userAgentId, undefined, userPassword || undefined);
    pushLocalKey(activeLocal?.privateKey);
    const allLocal = await getAllLocalEpochKeys(userAgentId).catch(() => [] as StoredAgentKeyEntry[]);
    for (const entry of allLocal) {
      pushLocalKey(entry.privateKey);
    }

    if (candidateLocalKeys.length === 0) {
      await fallbackWarmup();
      return false;
    }

    const cachedPeer =
      getCachedPeerKey(connectionId) ||
      candidateIds.map((id) => getCachedPeerKey(id)).find(Boolean) ||
      null;
    const isMyMessage = normalizeAgentId(senderAgentId) === normalizeAgentId(userAgentId);
    const targetPeer = isMyMessage ? (peerAgentId || cachedPeer?.peerAgentId || 'peer') : (senderAgentId || peerAgentId || 'peer');

    if (senderPublicKey && targetPeer && targetPeer !== 'peer') {
      try {
        await pinPeerKey(targetPeer, senderPublicKey, undefined, undefined, false, effectiveSenderEpoch);
        await savePeerEpochKey(targetPeer, effectiveSenderEpoch, senderPublicKey);
      } catch {}
    }

    let resolvedPeerPubKey = await resolveSenderPublicKey(
      targetPeer,
      msgEpoch,
      cachedPeer?.peerEpochKeys || {},
      senderPublicKey || cachedPeer?.peerPublicKey || peerPublicKey || null,
      senderPublicKey ? effectiveSenderEpoch : (cachedPeer?.peerKeyEpoch || msgEpoch)
    );

    const candidatePeerKeys: any[] = [];
    const pushPeerKey = (pk: any) => {
      if (!pk) return;
      const s = typeof pk === 'string' ? pk : JSON.stringify(pk);
      if (s && !candidatePeerKeys.includes(s)) candidatePeerKeys.push(s);
    };
    pushPeerKey(senderPublicKey);
    pushPeerKey(resolvedPeerPubKey);
    pushPeerKey(cachedPeer?.peerPublicKey);
    pushPeerKey(peerPublicKey);
    if (cachedPeer?.peerEpochKeys && typeof cachedPeer.peerEpochKeys === 'object') {
      for (const epVal of Object.values(cachedPeer.peerEpochKeys)) {
        pushPeerKey((epVal as any)?.publicKey);
      }
    }

    if (candidatePeerKeys.length === 0) {
      await fallbackWarmup();
      return false;
    }

    let resolvedPlaintext: string | null = null;
    const tryDecryptRealtime = async (privs: (CryptoKey | string)[], pubs: any[]) => {
      for (const localPrivCandidate of privs) {
        if (resolvedPlaintext) break;
        for (const keyCandidate of pubs) {
          if (resolvedPlaintext) break;
          for (const cid of candidateIds) {
            try {
              resolvedPlaintext = await decryptMessage(
                { ciphertext, nonce, version: version || 1, keyEpoch: msgEpoch },
                localPrivCandidate,
                keyCandidate,
                cid,
                senderAgentId || 'AGENT'
              );
              if (resolvedPlaintext) break;
            } catch {}
          }
        }
      }
    };

    await tryDecryptRealtime(candidateLocalKeys, candidatePeerKeys);

    // If fast-path fails, sync own local keys against recovery vault (multi-device rotation) and retry
    if (typeof resolvedPlaintext !== 'string' || isDecryptionErrorPlaceholder(resolvedPlaintext)) {
      try {
        const ownSync = await syncOwnLocalKeysWithServer(userAgentId, userPassword || undefined, authType || 'human', { force: true });
        if (ownSync.restoredNewEpochs && ownSync.localKeys?.privateKey) {
          const freshLocalKeys: (CryptoKey | string)[] = [ownSync.localKeys.privateKey];
          const refreshedAll = await getAllLocalEpochKeys(userAgentId).catch(() => [] as StoredAgentKeyEntry[]);
          for (const ep of refreshedAll) {
            if (ep?.privateKey && !freshLocalKeys.includes(ep.privateKey)) freshLocalKeys.push(ep.privateKey);
          }
          await tryDecryptRealtime(freshLocalKeys, candidatePeerKeys);
        }
      } catch {}
    }

    if (typeof resolvedPlaintext !== 'string' || isDecryptionErrorPlaceholder(resolvedPlaintext)) {
      await fallbackWarmup();
      return false;
    }

    cacheDecryptedMessage(resolvedPlaintext, [
      messageId,
      nonce,
      ciphertext,
      `${connectionId}_${messageId}`,
      `${connectionId}_${nonce}`,
      `${connectionId}_${ciphertext}`,
    ]);

    const newEntry = {
      id: messageId,
      connectionId,
      senderAgentId: senderAgentId || peerAgentId || 'Agent',
      content: resolvedPlaintext,
      isDecrypted: true,
      keyEpoch: msgEpoch,
      sequence: typeof sequence === 'number' ? sequence : undefined,
      createdAt: createdAt || new Date().toISOString(),
    };

    const prevMaxSeq = existingPrev.reduce(
      (max, m) => (typeof m?.sequence === 'number' && m.sequence > max ? m.sequence : max),
      -1
    );

    const dedupedPrev = existingPrev.filter((m) => m && m.id !== messageId);
    const combined = [...dedupedPrev, newEntry].sort((a, b) => {
      const timeDiff = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      if (timeDiff !== 0) return timeDiff;
      if (typeof a.sequence === 'number' && typeof b.sequence === 'number' && a.sequence !== b.sequence) {
        return a.sequence - b.sequence;
      }
      return String(a.id).localeCompare(String(b.id));
    });

    const peerAliasKey = makePeerAliasKey(peerAgentId || senderAgentId || cachedPeer?.peerAgentId);
    const targetCacheIds = Array.from(
      new Set([...candidateIds, peerAliasKey].filter((x): x is string => Boolean(x && typeof x === 'string' && x.trim())))
    );
    targetCacheIds.forEach((cid) => setCachedConnectionMessages(cid, combined, accountKey));
    recordWarmupCompleted(accountKey, 'connection', targetCacheIds);

    dispatchMessagesUpdated({
      type: 'connection',
      accountKey,
      connectionId,
      canonicalConnectionId: connectionId,
      allConnectionIds: targetCacheIds,
      peerAgentId: peerAgentId || senderAgentId || cachedPeer?.peerAgentId,
      messages: combined,
    });

    // If history isn't loaded locally yet or a sequence gap was skipped while disconnected, backfill in background
    const hasSeqGap = typeof sequence === 'number' && prevMaxSeq >= 0 && sequence > prevMaxSeq + 1;
    if (existingPrev.length === 0 || hasSeqGap) {
      fallbackWarmup();
    }

    return true;
  } catch {
    await fallbackWarmup();
    return false;
  }
}

export async function ingestRealtimeClusterMessage(params: {
  clusterId: string;
  clusterName?: string | null;
  messageId?: string | null;
  senderAgentId?: string | null;
  senderAgentName?: string | null;
  senderAgentAvatar?: string | null;
  ciphertext?: string | null;
  nonce?: string | null;
  version?: number | null;
  keyEpoch?: number | null;
  audienceHash?: string | null;
  sequence?: number | null;
  recipients?: any[];
  createdAt?: string | null;
  accountKey: string;
  accountId: string;
  userAgentId?: string | null;
  userPassword?: string | null;
  authType?: 'human' | 'agent';
  activeCluster?: any;
}): Promise<boolean> {
  const {
    clusterId,
    clusterName,
    messageId,
    senderAgentId,
    senderAgentName,
    senderAgentAvatar,
    ciphertext,
    nonce,
    version,
    keyEpoch,
    audienceHash,
    sequence,
    recipients,
    createdAt,
    accountKey,
    accountId,
    userAgentId,
    userPassword,
    authType,
    activeCluster,
  } = params;

  if (!clusterId || !userAgentId || !accountKey || accountKey === 'anon::anon') return false;

  const fallbackWarmup = () =>
    warmupClusterChat({
      clusterId,
      clusterName: clusterName || activeCluster?.name,
      activeCluster,
      accountKey,
      accountId,
      userAgentId,
      userPassword,
      authType,
    }).catch(() => []);

  if (!ciphertext || !nonce || !messageId) {
    await fallbackWarmup();
    return false;
  }

  const existingPrev = getCachedClusterMessages(clusterId, accountKey);
  const alreadyCached = existingPrev.find(
    (m) => m && m.isDecrypted && !isDecryptionErrorPlaceholder(m.content) && (m.id === messageId || (nonce && m.nonce === nonce))
  );
  if (alreadyCached) {
    dispatchMessagesUpdated({
      type: 'cluster',
      accountKey,
      clusterId,
      messages: existingPrev,
    });
    return true;
  }

  try {
    const msgEpoch = typeof keyEpoch === 'number' && keyEpoch >= 1 ? keyEpoch : 1;
    const msgVer = typeof version === 'number' && version >= 1 ? version : 2;
    const aud = String(audienceHash || 'ALL').trim() || 'ALL';
    const localGroupKey = await getClusterGroupKey(clusterId, msgEpoch, undefined, aud);
    if (!localGroupKey) {
      await fallbackWarmup();
      return false;
    }

    const cachedClusters = getQueryCache(accountKey, '/api/clusters')?.data;
    const clusterMeta =
      activeCluster ||
      (Array.isArray(cachedClusters)
        ? cachedClusters.find((c: any) => String(c.id || '').toLowerCase() === clusterId.toLowerCase())
        : null);
    const resolvedClusterName = clusterName || clusterMeta?.name || clusterMeta?.clusterName || '';
    const cachedMembersEntry = getQueryCache(accountKey, `/api/clusters/public/${clusterId}/members`)?.data;
    const membersList: any[] =
      (Array.isArray(cachedMembersEntry) ? cachedMembersEntry : cachedMembersEntry?.members) || [];
    const memberMeta = membersList.find(
      (mem: any) => mem?.agentId && senderAgentId && String(mem.agentId).toLowerCase() === String(senderAgentId).toLowerCase()
    );
    const displayName = senderAgentName || memberMeta?.agentName || memberMeta?.name || senderAgentId || 'Agent';

    const resolvedPlaintext = await decryptClusterMessage(
      ciphertext,
      nonce,
      localGroupKey,
      senderAgentId || 'Agent',
      clusterId,
      msgEpoch,
      msgVer,
      displayName,
      resolvedClusterName,
      aud
    );

    if (typeof resolvedPlaintext !== 'string' || isDecryptionErrorPlaceholder(resolvedPlaintext)) {
      await fallbackWarmup();
      return false;
    }

    cacheDecryptedMessage(resolvedPlaintext, [
      `${accountId}:${clusterId}:${messageId}`,
      `${clusterId}_${messageId}`,
      messageId,
      `${clusterId}_${nonce}`,
      `${clusterId}_${ciphertext}`,
      nonce,
      ciphertext,
    ]);

    const newEntry = {
      id: messageId,
      clusterId,
      senderAgentId: senderAgentId || 'Agent',
      senderAgentName: displayName,
      senderAgentAvatar: senderAgentAvatar || memberMeta?.avatar || memberMeta?.agentAvatar,
      content: resolvedPlaintext,
      ciphertext,
      nonce,
      sequence: typeof sequence === 'number' ? sequence : undefined,
      recipients: Array.isArray(recipients) ? recipients : [],
      isDecrypted: true,
      createdAt: createdAt || new Date().toISOString(),
    };

    const prevMaxSeq = existingPrev.reduce(
      (max, m) => (typeof m?.sequence === 'number' && m.sequence > max ? m.sequence : max),
      -1
    );

    const dedupedPrev = existingPrev.filter((m) => m && m.id !== messageId);
    const combined = [...dedupedPrev, newEntry].sort((a, b) => {
      const timeDiff = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      if (timeDiff !== 0) return timeDiff;
      if (typeof a.sequence === 'number' && typeof b.sequence === 'number' && a.sequence !== b.sequence) {
        return a.sequence - b.sequence;
      }
      return String(a.id).localeCompare(String(b.id));
    });

    setCachedClusterMessages(clusterId, combined, accountKey);
    recordWarmupCompleted(accountKey, 'cluster', [clusterId]);

    dispatchMessagesUpdated({
      type: 'cluster',
      accountKey,
      clusterId,
      messages: combined,
    });

    const hasSeqGap = typeof sequence === 'number' && prevMaxSeq >= 0 && sequence > prevMaxSeq + 1;
    if (existingPrev.length === 0 || hasSeqGap) {
      fallbackWarmup();
    }

    return true;
  } catch {
    try {
      const msgEpoch = typeof keyEpoch === 'number' && keyEpoch >= 1 ? keyEpoch : 1;
      const aud = String(audienceHash || 'ALL').trim() || 'ALL';
      await deleteClusterGroupKey(clusterId, msgEpoch, aud);
    } catch {}
    await fallbackWarmup();
    return false;
  }
}

function parseEntityServerMsgTs(entity: any): number {
  if (!entity || typeof entity !== 'object') return 0;
  const raw = entity.lastMessageAt || entity.lastActivity || entity.updatedAt || entity.updated_at;
  if (!raw) return 0;
  const ts = typeof raw === 'number' ? raw : new Date(raw).getTime();
  return Number.isFinite(ts) ? ts : 0;
}

export async function warmupUnreadChats(params: {
  connections?: any[];
  clusters?: any[];
  accountKey: string;
  accountId: string;
  userAgentId?: string | null;
  userPassword?: string | null;
  authType?: 'human' | 'agent';
}): Promise<void> {
  const { connections = [], clusters = [], accountKey, accountId, userAgentId, userPassword, authType } = params;
  if (!accountKey || accountKey === 'anon::anon' || !userAgentId) return;

  const counts = getUnreadCounts(accountKey);
  const unreadTasks: Array<() => Promise<any>> = [];
  const staleEntries: Array<{ ts: number; fn: () => Promise<any> }> = [];

  for (const conn of connections) {
    if (!conn || conn.status === 'dissolved' || !conn.id) continue;
    const connId = conn.id || conn.connectionId;
    const localCount = getConnUnreadCount(counts, conn, accountKey);
    const hasUnread = (typeof conn.unreadCount === 'number' && conn.unreadCount > 0) || localCount > 0;
    const serverTs = parseEntityServerMsgTs(conn);
    let isStale = false;
    if (!hasUnread) {
      const cachedMsgs = getCachedConnectionMessagesByAliases(
        [connId, ...(Array.isArray(conn.allConnectionIds) ? conn.allConnectionIds : [])],
        accountKey,
        conn.agentId
      );
      const cachedTs = getLatestCachedMessageTimestamp(cachedMsgs);
      if (serverTs > 0 && (cachedTs === 0 || serverTs > cachedTs + 500)) {
        isStale = true;
      }
    }
    if (!hasUnread && !isStale) continue;
    const taskFn = () =>
      warmupConnectionChat({
        connectionId: connId,
        allConnectionIds: conn.allConnectionIds,
        peerAgentId: conn.agentId,
        peerPublicKey: conn.peerE2eePublicKey,
        accountKey,
        userAgentId,
        userPassword,
        authType,
      });
    if (hasUnread) {
      unreadTasks.push(taskFn);
    } else {
      staleEntries.push({ ts: serverTs, fn: taskFn });
    }
  }

  for (const clu of clusters) {
    if (!clu || clu.status === 'dissolved' || !clu.id) continue;
    const localCount = getClusterUnreadCount(counts, clu, accountKey);
    const hasUnread = (typeof clu.unreadCount === 'number' && clu.unreadCount > 0) || localCount > 0;
    const serverTs = parseEntityServerMsgTs(clu);
    let isStale = false;
    if (!hasUnread) {
      const cachedMsgs = getCachedClusterMessages(clu.id, accountKey);
      const cachedTs = getLatestCachedMessageTimestamp(cachedMsgs);
      if (serverTs > 0 && (cachedTs === 0 || serverTs > cachedTs + 500)) {
        isStale = true;
      }
    }
    if (!hasUnread && !isStale) continue;
    const taskFn = () =>
      warmupClusterChat({
        clusterId: clu.id,
        clusterName: clu.name,
        accountKey,
        accountId,
        userAgentId,
        userPassword,
        authType,
        activeCluster: clu,
      });
    if (hasUnread) {
      unreadTasks.push(taskFn);
    } else {
      staleEntries.push({ ts: serverTs, fn: taskFn });
    }
  }

  staleEntries.sort((a, b) => b.ts - a.ts);
  const tasks = [...unreadTasks, ...staleEntries.slice(0, 10).map((e) => e.fn)];
  if (tasks.length === 0) return;

  let cursor = 0;
  const concurrency = Math.min(4, tasks.length);
  const workers = Array.from({ length: concurrency }, async () => {
    while (cursor < tasks.length) {
      const fn = tasks[cursor++];
      await fn().catch(() => {});
    }
  });
  await Promise.all(workers);
}
