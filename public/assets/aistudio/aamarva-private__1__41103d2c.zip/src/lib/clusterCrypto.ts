import { normalizeAgentId, deriveChannelKey, bufferToBase64, base64ToBuffer } from './e2ee';

const ENC_ALGO = 'AES-GCM';

function canonicalizeAgentSet(agentIds: string[]): string[] {
  return Array.from(
    new Set(
      (agentIds || [])
        .map((id) => normalizeAgentId(id))
        .filter(Boolean)
    )
  ).sort();
}

async function sha256HexUpper(input: string): Promise<string> {
  const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;
  const buf = await cryptoObj.subtle.digest('SHA-256', new TextEncoder().encode(input));
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('')
    .toUpperCase();
}

/**
 * Computes a deterministic roster hash across all active cluster member agentIds.
 */
export async function computeClusterRosterHash(activeMemberAgentIds: string[]): Promise<string> {
  const sorted = canonicalizeAgentSet(activeMemberAgentIds);
  const hex = await sha256HexUpper(sorted.join(','));
  return `RST:${hex.slice(0, 32)}`;
}

/**
 * Computes a deterministic audience hash for cluster recipient scoping.
 * Returns 'ALL' if recipientAgentIds covers all active members (or when allActiveMemberAgentIds is omitted/empty),
 * or 'AUD:<32-hex>' for strict subsets so subset keys stay O(1) while cryptographically isolating non-recipients.
 */
export async function computeClusterAudienceHash(
  recipientAgentIds: string[],
  allActiveMemberAgentIds?: string[]
): Promise<string> {
  const recips = canonicalizeAgentSet(recipientAgentIds);
  if (recips.length === 0) return 'ALL';

  if (Array.isArray(allActiveMemberAgentIds) && allActiveMemberAgentIds.length > 0) {
    const allActive = canonicalizeAgentSet(allActiveMemberAgentIds);
    const allCovered = allActive.length > 0 && allActive.every((id) => recips.includes(id));
    if (allCovered) return 'ALL';
  }

  const hex = await sha256HexUpper(recips.join(','));
  return `AUD:${hex.slice(0, 32)}`;
}

/**
 * Constructs canonical Cluster v2 AAD binding ciphertext to cluster, version, sender, epoch, and optional subset audience.
 */
export function constructClusterAAD(
  clusterId: string,
  version: number = 2,
  senderAgentId: string = '',
  keyEpoch: number = 1,
  audienceHash?: string
): Uint8Array {
  const cId = (clusterId || '').trim();
  const sId = normalizeAgentId(senderAgentId);
  const aud = (audienceHash || '').trim();
  if (aud && aud !== 'ALL') {
    return new TextEncoder().encode(`AAMARVA:E2EE:v${version}:${cId}:${sId}:${keyEpoch}:${aud}`);
  }
  return new TextEncoder().encode(`AAMARVA:E2EE:v${version}:${cId}:${sId}:${keyEpoch}`);
}

export function buildClusterMessageSigningPayload(params: {
  clusterId: string;
  keyEpoch: number;
  senderAgentId: string;
  audienceHash?: string;
  rosterHash?: string;
  sequence?: number | null;
  keyFingerprint?: string;
  nonce: string;
  ciphertext: string;
}): string {
  const aud = params.audienceHash && params.audienceHash.trim() ? params.audienceHash.trim() : 'ALL';
  const seqStr = params.sequence !== undefined && params.sequence !== null ? String(params.sequence) : '';
  return [
    'AAMARVA:CLUSTER_MSG:v2',
    (params.clusterId || '').trim(),
    String(params.keyEpoch),
    normalizeAgentId(params.senderAgentId),
    aud,
    (params.rosterHash || '').trim(),
    seqStr,
    (params.keyFingerprint || '').trim(),
    (params.nonce || '').trim(),
    (params.ciphertext || '').trim()
  ].join('|');
}

export async function signClusterMessageEnvelope(
  identityPrivateKey: CryptoKey | string,
  params: {
    clusterId: string;
    keyEpoch: number;
    senderAgentId: string;
    audienceHash?: string;
    rosterHash?: string;
    sequence?: number | null;
    keyFingerprint?: string;
    nonce: string;
    ciphertext: string;
  }
): Promise<string> {
  const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;
  let signingKey: CryptoKey;
  if (typeof identityPrivateKey === 'string') {
    const jwk = JSON.parse(identityPrivateKey);
    signingKey = await cryptoObj.subtle.importKey(
      'jwk',
      jwk,
      { name: 'ECDSA', namedCurve: 'P-256' },
      false,
      ['sign']
    );
  } else {
    signingKey = identityPrivateKey;
  }
  const payload = buildClusterMessageSigningPayload(params);
  const sigBuf = await cryptoObj.subtle.sign(
    { name: 'ECDSA', hash: { name: 'SHA-256' } },
    signingKey,
    new TextEncoder().encode(payload)
  );
  return bufferToBase64(sigBuf);
}

/**
 * Generates a fresh 256-bit symmetric AES-GCM encryption key for a cluster epoch or audience subgroup.
 */
export async function generateClusterGroupKey(): Promise<{
  key: CryptoKey;
  rawKey: Uint8Array;
  base64: string;
  fingerprint: string;
}> {
  const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;
  const rawBytes = cryptoObj.getRandomValues(new Uint8Array(32));
  const key = await cryptoObj.subtle.importKey(
    'raw',
    rawBytes,
    { name: ENC_ALGO, length: 256 },
    true,
    ['encrypt', 'decrypt']
  );
  const base64 = bufferToBase64(rawBytes.buffer);
  const digestBuf = await cryptoObj.subtle.digest('SHA-256', rawBytes);
  const hex = Array.from(new Uint8Array(digestBuf))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join(':')
    .toUpperCase();
  const fingerprint = `SHA256:${hex}`;
  return { key, rawKey: rawBytes, base64, fingerprint };
}

/**
 * Encrypts a cluster message once using the cluster's shared symmetric group key (or audience-scoped subgroup key).
 * Message encryption cost is O(1) regardless of member count.
 * Returns Base64 ciphertext, unique 12-byte nonce (IV), protocol version (2), keyEpoch, and audienceHash.
 */
export async function encryptClusterMessage(
  plaintext: string,
  groupKey: CryptoKey | string | Uint8Array,
  senderAgentId: string,
  clusterId: string = 'general',
  keyEpoch: number = 1,
  audienceHash?: string
): Promise<{
  ciphertext: string;
  nonce: string;
  version: number;
  keyEpoch: number;
  audienceHash: string;
}> {
  if (!plaintext || typeof plaintext !== 'string') {
    throw new Error('E2EE Error: Plaintext message content cannot be empty.');
  }
  if (!groupKey) {
    throw new Error('E2EE Error: Missing cluster group key for encryption.');
  }
  if (
    keyEpoch === undefined ||
    keyEpoch === null ||
    typeof keyEpoch !== 'number' ||
    !Number.isFinite(keyEpoch) ||
    !Number.isInteger(keyEpoch) ||
    keyEpoch < 1
  ) {
    throw new Error('E2EE Error: Missing or invalid keyEpoch. keyEpoch must be a positive integer (>= 1).');
  }

  const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;
  const version = 2;
  const sId = normalizeAgentId(senderAgentId);
  const cId = (clusterId || '').trim();
  const epoch = keyEpoch;
  const resolvedAudienceHash = audienceHash && audienceHash.trim() && audienceHash.trim() !== 'ALL' ? audienceHash.trim() : 'ALL';

  // Resolve group key as CryptoKey
  let aesKey: CryptoKey;
  if (typeof groupKey === 'string') {
    const rawBuf = base64ToBuffer(groupKey.trim());
    aesKey = await cryptoObj.subtle.importKey(
      'raw',
      rawBuf,
      { name: ENC_ALGO, length: 256 },
      false,
      ['encrypt']
    );
  } else if (groupKey instanceof Uint8Array || groupKey instanceof ArrayBuffer) {
    const u8 = groupKey instanceof Uint8Array ? groupKey : new Uint8Array(groupKey);
    aesKey = await cryptoObj.subtle.importKey(
      'raw',
      u8,
      { name: ENC_ALGO, length: 256 },
      false,
      ['encrypt']
    );
  } else {
    aesKey = groupKey;
  }

  // Generate unique 12-byte (96-bit) initialization vector
  const iv = cryptoObj.getRandomValues(new Uint8Array(12));
  const aad = constructClusterAAD(cId, version, sId, epoch, resolvedAudienceHash);

  const cipherBuf = await cryptoObj.subtle.encrypt(
    {
      name: ENC_ALGO,
      iv,
      additionalData: aad
    },
    aesKey,
    new TextEncoder().encode(plaintext)
  );

  return {
    ciphertext: bufferToBase64(cipherBuf),
    nonce: bufferToBase64(iv.buffer),
    version,
    keyEpoch: epoch,
    audienceHash: resolvedAudienceHash
  };
}

/**
 * Decrypts a cluster message using the cluster's shared symmetric group key.
 * Authenticates AAD context (clusterId, version, senderAgentId, keyEpoch) and ciphertext integrity.
 */
export async function decryptClusterMessage(
  ciphertext: string,
  nonce: string,
  groupKey: CryptoKey | string | Uint8Array,
  senderAgentId: string,
  clusterId: string = 'general',
  keyEpoch: number = 1,
  version: number = 2,
  senderDisplayName?: string,
  clusterName?: string,
  audienceHash?: string
): Promise<string> {
  if (!ciphertext || typeof ciphertext !== 'string' || ciphertext.trim().length === 0) {
    throw new Error('E2EE Error: Missing ciphertext payload.');
  }
  if (!nonce || typeof nonce !== 'string' || nonce.trim().length === 0) {
    throw new Error('E2EE Error: Missing nonce (IV).');
  }
  if (!groupKey) {
    throw new Error('E2EE Error: Missing cluster group key for decryption.');
  }
  if (typeof version !== 'number' || version !== 2) {
    throw new Error(`E2EE Error: Unsupported protocol version (${version}). Only version 2 is supported.`);
  }
  if (
    typeof keyEpoch !== 'number' ||
    !Number.isFinite(keyEpoch) ||
    !Number.isInteger(keyEpoch) ||
    keyEpoch < 1
  ) {
    throw new Error('E2EE Error: Missing or invalid keyEpoch. keyEpoch must be a positive integer (>= 1).');
  }

  const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;
  const sId = normalizeAgentId(senderAgentId);
  const cId = (clusterId || '').trim();
  const epoch = keyEpoch;
  const aud = audienceHash && audienceHash.trim() && audienceHash.trim() !== 'ALL' ? audienceHash.trim() : '';

  let aesKey: CryptoKey;
  if (typeof groupKey === 'string') {
    const rawBuf = base64ToBuffer(groupKey.trim());
    aesKey = await cryptoObj.subtle.importKey(
      'raw',
      rawBuf,
      { name: ENC_ALGO, length: 256 },
      false,
      ['decrypt']
    );
  } else if (groupKey instanceof Uint8Array || groupKey instanceof ArrayBuffer) {
    const u8 = groupKey instanceof Uint8Array ? groupKey : new Uint8Array(groupKey);
    aesKey = await cryptoObj.subtle.importKey(
      'raw',
      u8,
      { name: ENC_ALGO, length: 256 },
      false,
      ['decrypt']
    );
  } else {
    aesKey = groupKey;
  }

  let ivBuf: ArrayBuffer;
  let cipherBuf: ArrayBuffer;
  try {
    ivBuf = base64ToBuffer(nonce.trim());
    cipherBuf = base64ToBuffer(ciphertext.trim());
  } catch (err: any) {
    throw new Error(`E2EE Error: Failed to decode base64 buffer: ${err?.message || 'Invalid encoding'}`);
  }

  if (ivBuf.byteLength !== 12) {
    throw new Error('E2EE Error: Invalid nonce. Nonce must be 12 bytes.');
  }

  const sIdRaw = (senderAgentId || '').trim();
  const sIdClean = sIdRaw.replace(/^@+/, '').trim();
  const nameClean = (senderDisplayName || '').replace(/^@+/, '').trim();
  const clusterNameClean = (clusterName || '').trim();

  const clusterCandidates = Array.from(new Set([
    cId,
    clusterNameClean,
    clusterNameClean.toUpperCase(),
    clusterNameClean.toLowerCase()
  ])).filter(Boolean);

  const senderCandidates = Array.from(new Set([
    sId,
    sIdClean,
    sIdRaw,
    sIdClean.toUpperCase(),
    sIdClean.toLowerCase(),
    ...(nameClean ? [nameClean, nameClean.toUpperCase(), nameClean.toLowerCase()] : [])
  ])).filter(Boolean);

  const aadCandidates: Uint8Array[] = [];

  // Primary canonical audience-scoped v2 AAD when audienceHash is present
  if (aud) {
    for (const cCand of clusterCandidates) {
      for (const sCand of senderCandidates) {
        aadCandidates.push(new TextEncoder().encode(`AAMARVA:E2EE:v2:${cCand}:${sCand}:${epoch}:${aud}`));
      }
    }
  }

  // Canonical cluster-wide v2 AADs across cluster and sender candidates
  for (const cCand of clusterCandidates) {
    for (const sCand of senderCandidates) {
      aadCandidates.push(new TextEncoder().encode(`AAMARVA:E2EE:v2:${cCand}:${sCand}:${epoch}`));
    }
  }

  // Legacy stored v1 AAD compatibility (never unauthenticated/undefined)
  for (const cCand of clusterCandidates) {
    for (const sCand of senderCandidates) {
      aadCandidates.push(new TextEncoder().encode(`AAMARVA:E2EE:v1:${cCand}:${sCand}`));
      aadCandidates.push(new TextEncoder().encode(`aamarva-cluster-group-key:${cCand}:${epoch}`));
    }
  }

  let decryptedBuf: ArrayBuffer | null = null;
  let lastErr: any = null;
  for (const candidateAAD of aadCandidates) {
    try {
      decryptedBuf = await cryptoObj.subtle.decrypt(
        { name: ENC_ALGO, iv: new Uint8Array(ivBuf), additionalData: candidateAAD },
        aesKey,
        cipherBuf
      );
      if (decryptedBuf) break;
    } catch (err: any) {
      lastErr = err;
    }
  }

  if (!decryptedBuf) {
    throw new Error(`E2EE Error: Cluster message decryption/authentication failed: ${lastErr?.message || 'Authentication tag failed'}`);
  }

  return new TextDecoder().decode(decryptedBuf);
}

export interface ClusterKeyWrapOptions {
  senderPublicKey?: any;
  senderAgentId?: string;
  recipientAgentId?: string;
  recipientKeyFingerprint?: string;
  recipientKeyEpoch?: number;
  audienceHash?: string;
  keyFingerprint?: string;
  rosterHash?: string;
}

export interface WrappedClusterKeyPackage {
  iv: string;
  key: string;
  epoch: number;
  clusterId: string;
  audienceHash?: string;
  keyFingerprint?: string;
  rosterHash?: string;
  senderAgentId?: string;
  senderPublicKey?: any;
  recipientAgentId?: string;
  recipientPublicKey?: any;
  recipientKeyFingerprint?: string;
  recipientKeyEpoch?: number;
  aad?: string;
  hkdfSalt?: string;
  hkdfInfo?: string;
  wrappingParams?: {
    algorithm: string;
    kdf: string;
    curve: string;
    hkdfHash: string;
    hkdfSalt: string;
    hkdfInfo: string;
    aad: string;
    iv: string;
    audienceHash?: string;
    keyFingerprint?: string;
    rosterHash?: string;
    senderAgentId?: string;
    senderPublicKey?: any;
    recipientAgentId?: string;
    recipientPublicKey?: any;
    recipientKeyFingerprint?: string;
    recipientKeyEpoch?: number;
  };
}

/**
 * Wraps the raw symmetric group key for a member using pairwise ECDH + HKDF.
 * Supports cluster-wide ('ALL') and cached audience-scoped subgroup keys ('AUD:...').
 */
export async function wrapClusterGroupKeyForMember(
  rawGroupKeyBytes: Uint8Array | string,
  senderPrivateKey: CryptoKey | string,
  recipientPublicKeyJwk: any,
  clusterId: string,
  epoch: number,
  options?: ClusterKeyWrapOptions
): Promise<WrappedClusterKeyPackage> {
  const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;
  const cId = (clusterId || '').trim();
  const rawBytes = typeof rawGroupKeyBytes === 'string' ? new Uint8Array(base64ToBuffer(rawGroupKeyBytes)) : rawGroupKeyBytes;
  const audienceHash = options?.audienceHash && options.audienceHash.trim() && options.audienceHash.trim() !== 'ALL'
    ? options.audienceHash.trim()
    : 'ALL';

  const channelKey = await deriveChannelKey(senderPrivateKey, recipientPublicKeyJwk, cId);
  const wrapIv = cryptoObj.getRandomValues(new Uint8Array(12));
  const aadStr = audienceHash !== 'ALL'
    ? `aamarva-cluster-group-key:${cId}:${epoch}:${audienceHash}`
    : `aamarva-cluster-group-key:${cId}:${epoch}`;
  const wrapAAD = new TextEncoder().encode(aadStr);

  const wrappedBuf = await cryptoObj.subtle.encrypt(
    {
      name: ENC_ALGO,
      iv: wrapIv,
      additionalData: wrapAAD
    },
    channelKey,
    rawBytes
  );

  const ivB64 = bufferToBase64(wrapIv.buffer);
  const keyB64 = bufferToBase64(wrappedBuf);
  const hkdfSaltStr = 'aamarva-e2ee-channel-v1';
  const hkdfInfoStr = `aamarva-channel:${cId}`;

  let parsedSenderPub: any = undefined;
  if (options?.senderPublicKey) {
    try {
      parsedSenderPub = typeof options.senderPublicKey === 'string'
        ? JSON.parse(options.senderPublicKey)
        : options.senderPublicKey;
    } catch {
      parsedSenderPub = options.senderPublicKey;
    }
  }

  let parsedRecipientPub: any = undefined;
  if (recipientPublicKeyJwk) {
    try {
      parsedRecipientPub = typeof recipientPublicKeyJwk === 'string'
        ? JSON.parse(recipientPublicKeyJwk)
        : recipientPublicKeyJwk;
    } catch {
      parsedRecipientPub = recipientPublicKeyJwk;
    }
  }

  const normSenderId = options?.senderAgentId ? normalizeAgentId(options.senderAgentId) : undefined;
  const normRecipId = options?.recipientAgentId ? normalizeAgentId(options.recipientAgentId) : undefined;

  return {
    iv: ivB64,
    key: keyB64,
    epoch,
    clusterId: cId,
    audienceHash,
    ...(options?.keyFingerprint ? { keyFingerprint: options.keyFingerprint } : {}),
    ...(options?.rosterHash ? { rosterHash: options.rosterHash } : {}),
    ...(normSenderId ? { senderAgentId: normSenderId } : {}),
    ...(parsedSenderPub ? { senderPublicKey: parsedSenderPub } : {}),
    ...(normRecipId ? { recipientAgentId: normRecipId } : {}),
    ...(parsedRecipientPub ? { recipientPublicKey: parsedRecipientPub } : {}),
    ...(options?.recipientKeyFingerprint ? { recipientKeyFingerprint: options.recipientKeyFingerprint } : {}),
    ...(typeof options?.recipientKeyEpoch === 'number' ? { recipientKeyEpoch: options.recipientKeyEpoch } : {}),
    aad: aadStr,
    hkdfSalt: hkdfSaltStr,
    hkdfInfo: hkdfInfoStr,
    wrappingParams: {
      algorithm: 'AES-256-GCM',
      kdf: 'ECDH-P256-HKDF-SHA256',
      curve: 'P-256',
      hkdfHash: 'SHA-256',
      hkdfSalt: hkdfSaltStr,
      hkdfInfo: hkdfInfoStr,
      aad: aadStr,
      iv: ivB64,
      audienceHash,
      ...(options?.keyFingerprint ? { keyFingerprint: options.keyFingerprint } : {}),
      ...(options?.rosterHash ? { rosterHash: options.rosterHash } : {}),
      ...(normSenderId ? { senderAgentId: normSenderId } : {}),
      ...(parsedSenderPub ? { senderPublicKey: parsedSenderPub } : {}),
      ...(normRecipId ? { recipientAgentId: normRecipId } : {}),
      ...(parsedRecipientPub ? { recipientPublicKey: parsedRecipientPub } : {}),
      ...(options?.recipientKeyFingerprint ? { recipientKeyFingerprint: options.recipientKeyFingerprint } : {}),
      ...(typeof options?.recipientKeyEpoch === 'number' ? { recipientKeyEpoch: options.recipientKeyEpoch } : {})
    }
  };
}

/**
 * Unwraps an encrypted group key distribution package using the recipient member's private key.
 * Strictly requires authenticated AAD verification (no unauthenticated undefined-AAD fallback).
 */
export async function unwrapClusterGroupKeyFromPackage(
  packageData: { iv: string; key: string; [k: string]: any } | string,
  recipientPrivateKey: CryptoKey | string,
  senderPublicKeyJwk: any,
  clusterId: string,
  epoch: number,
  audienceHash?: string
): Promise<{ groupKey: CryptoKey; rawKey: Uint8Array; base64: string }> {
  const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;
  const cId = (clusterId || '').trim();

  let parsed: { iv: string; key: string; [k: string]: any };
  if (typeof packageData === 'string') {
    parsed = JSON.parse(packageData);
  } else {
    parsed = packageData;
  }

  const wrapIvBuf = base64ToBuffer(parsed.iv || parsed.nonce);
  const wrappedBuf = base64ToBuffer(parsed.key || parsed.ciphertext);

  // Collect candidate sender public keys (preferring the exact senderPublicKey embedded in the package)
  const senderKeyCandidates: any[] = [];
  const embeddedSenderKey = parsed.senderPublicKey || parsed.senderPublicKeyJwk || parsed.wrappingParams?.senderPublicKey;
  if (embeddedSenderKey) {
    senderKeyCandidates.push(embeddedSenderKey);
  }
  if (senderPublicKeyJwk) {
    senderKeyCandidates.push(senderPublicKeyJwk);
  }

  if (senderKeyCandidates.length === 0) {
    throw new Error(`E2EE Error: Missing senderPublicKey required to unwrap cluster group key for epoch ${epoch}.`);
  }

  const effectiveAudience = (audienceHash || parsed.audienceHash || parsed.wrappingParams?.audienceHash || 'ALL').trim();
  const canonicalAAD = effectiveAudience && effectiveAudience !== 'ALL'
    ? new TextEncoder().encode(`aamarva-cluster-group-key:${cId}:${epoch}:${effectiveAudience}`)
    : new TextEncoder().encode(`aamarva-cluster-group-key:${cId}:${epoch}`);

  const aadCandidates: Uint8Array[] = [canonicalAAD];
  const baseEpochAAD = `aamarva-cluster-group-key:${cId}:${epoch}`;
  if (effectiveAudience && effectiveAudience !== 'ALL') {
    aadCandidates.push(new TextEncoder().encode(baseEpochAAD));
  }
  if (typeof parsed.aad === 'string' && parsed.aad !== baseEpochAAD) {
    aadCandidates.push(new TextEncoder().encode(parsed.aad));
  }
  if (typeof parsed.wrappingParams?.aad === 'string') {
    aadCandidates.push(new TextEncoder().encode(parsed.wrappingParams.aad));
  }

  let rawBytesBuf: ArrayBuffer | null = null;
  let lastErr: any = null;

  for (const candidatePubKey of senderKeyCandidates) {
    try {
      const channelKey = await deriveChannelKey(recipientPrivateKey, candidatePubKey, cId);
      for (const candidateAAD of aadCandidates) {
        try {
          rawBytesBuf = await cryptoObj.subtle.decrypt(
            { name: ENC_ALGO, iv: new Uint8Array(wrapIvBuf), additionalData: candidateAAD },
            channelKey,
            wrappedBuf
          );
          if (rawBytesBuf) break;
        } catch (decErr: any) {
          lastErr = decErr;
        }
      }
      if (rawBytesBuf) break;
    } catch (keyErr: any) {
      lastErr = keyErr;
    }
  }

  if (!rawBytesBuf) {
    throw new Error(`E2EE Error: Failed to unwrap cluster group key for epoch ${epoch}: ${lastErr?.message || 'OperationError'}`);
  }

  const rawBytes = new Uint8Array(rawBytesBuf);
  const groupKey = await cryptoObj.subtle.importKey(
    'raw',
    rawBytes,
    { name: ENC_ALGO, length: 256 },
    true,
    ['encrypt', 'decrypt']
  );

  return {
    groupKey,
    rawKey: rawBytes,
    base64: bufferToBase64(rawBytesBuf)
  };
}
