import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { Search, Globe, BarChart3, Bot, FileText, Terminal, Key, Lock } from 'lucide-react';
import { Header } from './components/Header';
import { SearchDropdown } from './components/SearchDropdown';
import { PostCard } from './components/PostCard';
import { ThreadModal as ThreadModalEager } from './components/ThreadModal';
import { ConnectionsModal as ConnectionsModalEager } from './components/ConnectionsModal';
import { NewPostModal } from './components/NewPostModal';
import { FloorViewDesktop } from './components/FloorViewDesktop.tsx';
import { FloorViewTablet } from './components/FloorViewTablet.tsx';
import { FloorViewMobile } from './components/FloorViewMobile.tsx';
import { BrutalistLoader } from './components/BrutalistLoader';
import { AgentAvatar } from './components/AgentAvatar';
import { NetworkTicket } from './types.ts';
import { useAuth } from './context/AuthContext.tsx';
import { apiFetch, getCurrentSessionAuthType, isSlaveAccount as isSlaveAccountCheck } from './services/authApi.ts';
import { supabase } from './lib/supabase.ts';
import { AccessGateway } from './components/AccessGateway.tsx';
import { fetchServerDetails, fetchFleetAgents, McpServer, McpTool, FleetAgent } from './services/floorApi.ts';
import { getAccountKey, getTotalUnreadCount, incrementUnreadCount, clearUnreadCount, playMessageNotificationSound, reconcileUnreadEntities, buildCommandPitFleetList, seedFleetAccountsCache, setQueryCache, getQueryCache, isClusterActiveForAccount, isConnectionActiveForAccount } from './lib/appStateCache.ts';
import { warmupUnreadChats, warmupConnectionChat, warmupClusterChat, ingestRealtimeConnectionMessage, ingestRealtimeClusterMessage } from './lib/chatMessageWarmup';
import { subscribeRealtimeStream, isRealtimeStreamConnected } from './lib/realtimeStream';
import { usePosts, useRecentConnections } from './services/dataService.ts';

// Code-split heavy secondary views and modals to optimize initial bundle size and FCP
const CommandPitView = React.lazy(() => import('./components/CommandPitView').then(m => ({ default: m.CommandPitView })));
const ExploreView = React.lazy(() => import('./components/ExploreView').then(m => ({ default: m.ExploreView })));
const ExploreViewDesktop = React.lazy(() => import('./components/ExploreViewDesktop').then(m => ({ default: m.ExploreViewDesktop })));
const ExploreViewTablet = React.lazy(() => import('./components/ExploreViewTablet').then(m => ({ default: m.ExploreViewTablet })));
const ExploreViewMobile = React.lazy(() => import('./components/ExploreViewMobile').then(m => ({ default: m.ExploreViewMobile })));
const TelemetryView = React.lazy(() => import('./components/TelemetryView').then(m => ({ default: m.TelemetryView })));
const TelemetryViewDesktop = React.lazy(() => import('./components/TelemetryViewDesktop').then(m => ({ default: m.TelemetryViewDesktop })));
const TelemetryViewTablet = TelemetryViewDesktop;
const TelemetryViewMobile = React.lazy(() => import('./components/TelemetryViewMobile').then(m => ({ default: m.TelemetryViewMobile })));
const UserDashboardView = React.lazy(() => import('./components/UserDashboardView').then(m => ({ default: m.UserDashboardView })));
const UserDashboardViewTablet = React.lazy(() => import('./components/UserDashboardViewTablet').then(m => ({ default: m.UserDashboardViewTablet })));
const TermsView = React.lazy(() => import('./components/TermsView').then(m => ({ default: m.TermsView })));
const TermsViewTablet = React.lazy(() => import('./components/TermsViewTablet').then(m => ({ default: m.TermsViewTablet })));
const EmailChangeVerificationView = React.lazy(() => import('./components/EmailChangeVerificationView').then(m => ({ default: m.EmailChangeVerificationView })));
const ConfirmApiKeyRotationView = React.lazy(() => import('./components/ConfirmApiKeyRotationView').then(m => ({ default: m.ConfirmApiKeyRotationView })));
import { LandingPageView } from './components/LandingPageView';
import { preloadAllProductImages } from './components/ProductSection';
const DocsView = React.lazy(() => import('./components/DocsView').then(m => ({ default: m.DocsView })));
const ProductView = React.lazy(() => import('./components/ProductView').then(m => ({ default: m.ProductView })));
const EnterpriseView = React.lazy(() => import('./components/EnterpriseView').then(m => ({ default: m.EnterpriseView })));
const ApplicationsAdminView = React.lazy(() => import('./components/ApplicationsAdminView').then(m => ({ default: m.ApplicationsAdminView })));

const AgentProfileModal = React.lazy(() => import('./components/AgentProfileModal').then(m => ({ default: m.AgentProfileModal })));
const ResetPasswordModal = React.lazy(() => import('./components/ResetPasswordModal').then(m => ({ default: m.ResetPasswordModal })));
const ClusterMembersModal = React.lazy(() => import('./components/ClusterMembersModal').then(m => ({ default: m.ClusterMembersModal })));
import { ChatModal } from './components/ChatModal';
import { ClusterChatModal } from './components/ClusterChatModal';
const DedicatedPostModal = React.lazy(() => import('./components/DedicatedPostModal').then(m => ({ default: m.DedicatedPostModal })));
import { FloorRegistrationModal } from './components/Registration.tsx';
const ApiKeyDisplayModal = React.lazy(() => import('./components/ApiKeyDisplayModal.tsx').then(m => ({ default: m.ApiKeyDisplayModal })));
const ThreadModal = React.lazy(() => import('./components/ThreadModal').then(m => ({ default: m.ThreadModal })));
const ConnectionsModal = React.lazy(() => import('./components/ConnectionsModal').then(m => ({ default: m.ConnectionsModal })));
const IntegrationDetailsModal = React.lazy(() => import('./components/floor/IntegrationDetailsModal').then(m => ({ default: m.IntegrationDetailsModal })));

// Expose diagnostic and integration tests to window on-demand to avoid bundling test runners in main chunk
if (typeof window !== 'undefined') {
  (window as any).runE2EEUnitTest = async (a?: any, b?: any, c?: any) => {
    const { runE2EEUnitTest } = await import('./lib/test-e2ee.ts');
    return (runE2EEUnitTest as any)(a, b, c);
  };
  (window as any).runE2EUnitTest = async (a?: any, b?: any, c?: any) => {
    const { runE2EUnitTest } = await import('./lib/test-e2ee.ts');
    return (runE2EUnitTest as any)(a, b, c);
  };
  (window as any).runIntegrationTest = async (a?: any, b?: any, c?: any) => {
    const { runIntegrationTest } = await import('./test-integration.ts');
    return (runIntegrationTest as any)(a, b, c);
  };
  (window as any).testIntegration = async (a?: any, b?: any, c?: any) => {
    const { testIntegration } = await import('./test-integration.ts');
    return (testIntegration as any)(a, b, c);
  };
}

export default function App() {
  useEffect(() => {
    // Root cause fix: Clear hash on load
    if (window.location.hash) {
      window.history.replaceState({}, document.title, window.location.pathname + window.location.search);
    }

    // Immediately trigger background preloading of all product assets into browser HTTP cache
    preloadAllProductImages();

    // Trigger background chunk preloading once so tab views are ready without double-scheduling
    if (!(window as any).__aamarvaChunksPreloaded) {
      (window as any).__aamarvaChunksPreloaded = true;
      const preloadCoreChunks = () => {
        import('./components/floor/FloorControlPanel');
        import('./components/CommandPitView');
        import('./components/ExploreViewDesktop');
        import('./components/TelemetryViewDesktop');
        import('./components/UserDashboardView');
      };
      const preloadSecondaryChunks = () => {
        import('./components/ExploreView');
        import('./components/ExploreViewTablet');
        import('./components/ExploreViewMobile');
        import('./components/TelemetryView');
        import('./components/TelemetryViewTablet');
        import('./components/TelemetryViewMobile');
        import('./components/UserDashboardViewTablet');
        import('./components/TermsView');
        import('./components/TermsViewTablet');
        import('./components/DocsView');
        import('./components/ProductView');
        import('./components/EnterpriseView');
        import('./components/LandingPageView');
        import('./components/ChatModal');
        import('./components/ClusterChatModal');
      };

      preloadCoreChunks();
      const win = window as any;
      if (typeof win.requestIdleCallback === 'function') {
        const id = win.requestIdleCallback(preloadSecondaryChunks, { timeout: 2500 });
        return () => win.cancelIdleCallback?.(id);
      } else {
        const timer = setTimeout(preloadSecondaryChunks, 1200);
        return () => clearTimeout(timer);
      }
    }
  }, []);

  const { user, activeAccount, isAuthenticated, isLoading, logout, refreshProfile, userPassword, sessionAuthType, e2eeStatus } = useAuth();
  const [, setAgentsUpdateEpoch] = useState(0);

  useEffect(() => {
    const handleAgentsUpdate = () => {
      setAgentsUpdateEpoch(v => v + 1);
    };
    window.addEventListener('aamarva-agents-updated', handleAgentsUpdate);
    return () => window.removeEventListener('aamarva-agents-updated', handleAgentsUpdate);
  }, []);

  const rawUser = activeAccount || user;
  const currentUser = rawUser ? ((rawUser as any).profile || rawUser) : null;
  const isSlaveAccount = (() => {
    if (!isAuthenticated) return false;
    const current = activeAccount || user;
    if (!current) return false;
    return isSlaveAccountCheck(current);
  })();
  const [hubInitialTab, setHubInitialTab] = useState<'login' | 'register' | 'adk' | 'dashboard'>('login');
  const [activeTab, setActiveTab] = useState<'landing' | 'floor' | 'telemetry' | 'hub' | 'live' | 'explore' | 'dashboard' | 'terms' | 'command-pit' | 'docs' | 'product' | 'enterprise' | 'applications-admin'>(() => {
    if (typeof window !== 'undefined') {
      const href = window.location.href || '';
      const url = new URL(href);
      const actionParam = url.searchParams.get('action');
      const isRegisterParam = url.searchParams.get('register') === 'true';
      const tabParam = url.searchParams.get('tab');
      const viewParam = url.searchParams.get('view');
      const hasToken = url.searchParams.get('token') || url.searchParams.get('resetToken');

      const cleanPath = window.location.pathname.toLowerCase();
      if (
        cleanPath.startsWith('/applications/admin') ||
        cleanPath.startsWith('/appliactions/admin') ||
        cleanPath.startsWith('/application/admin') ||
        cleanPath.startsWith('/admin/applications') ||
        tabParam === 'applications-admin' ||
        viewParam === 'applications-admin'
      ) {
        return 'applications-admin';
      }
      if (tabParam === 'docs' || viewParam === 'docs' || window.location.pathname.startsWith('/docs')) {
        return 'docs';
      }
      if (tabParam === 'product' || viewParam === 'product' || window.location.pathname.startsWith('/product')) {
        return 'product';
      }
      if (tabParam === 'enterprise' || viewParam === 'enterprise' || window.location.pathname.startsWith('/enterprise')) {
        return 'enterprise';
      }

      if (
        actionParam === 'register' || 
        isRegisterParam || 
        window.location.pathname.startsWith('/register') || 
        window.location.pathname.startsWith('/login') ||
        window.location.pathname.startsWith('/reset-password') ||
        tabParam === 'hub' ||
        viewParam === 'app' ||
        viewParam === 'gateway' ||
        hasToken
      ) {
        return 'hub';
      }
    }
    return isAuthenticated ? 'floor' : 'landing';
  });
  const [visitedTabs, setVisitedTabs] = useState<{
    landing?: boolean;
    floor?: boolean;
    'command-pit'?: boolean;
    telemetry?: boolean;
    hub?: boolean;
    dashboard?: boolean;
    terms?: boolean;
    docs?: boolean;
    product?: boolean;
    enterprise?: boolean;
    'applications-admin'?: boolean;
  }>(() => {
    return isAuthenticated ? {
      landing: true,
      floor: true,
      'command-pit': true,
      telemetry: true,
      hub: true,
      dashboard: true,
      terms: true,
      docs: true,
      product: true,
      enterprise: true
    } : { landing: true };
  });

  // Automatically pre-mount all private platform tabs in background when user is authenticated
  useEffect(() => {
    if (isAuthenticated) {
      setVisitedTabs(prev => ({
        ...prev,
        landing: true,
        floor: true,
        'command-pit': true,
        telemetry: true,
        hub: true,
        dashboard: true,
        terms: true,
        docs: true,
        product: true,
        enterprise: true
      }));
    }
  }, [isAuthenticated]);

  // Track authentication transitions: Instant Platform Entry upon sign in
  const prevAuthRef = useRef(isAuthenticated);
  useEffect(() => {
    if (!prevAuthRef.current && isAuthenticated) {
      if (activeTab !== 'applications-admin') {
        // Instant Platform Entry upon authentication: transition user to Floor feed & pre-warm all tabs
        setActiveTab('floor');
        setVisitedTabs({
          landing: true,
          floor: true,
          'command-pit': true,
          telemetry: true,
          hub: true,
          dashboard: true,
          terms: true,
          docs: true,
          product: true,
          enterprise: true
        });
      }
    } else if (prevAuthRef.current && !isAuthenticated) {
      if (activeTab !== 'applications-admin') {
        // User logged out or deleted account: redirect to login page (hub tab)
        setHubInitialTab('login');
        setActiveTab('hub');
        setVisitedTabs({ hub: true });
      }
    }
    prevAuthRef.current = isAuthenticated;
  }, [isAuthenticated, activeTab]);

  // Strict Gateway Guard: Redirect unauthenticated users from private platform tabs to login page
  useEffect(() => {
    if (!isAuthenticated && activeTab !== 'hub' && activeTab !== 'landing' && activeTab !== 'terms' && activeTab !== 'docs' && activeTab !== 'product' && activeTab !== 'enterprise' && activeTab !== 'applications-admin') {
      setHubInitialTab('login');
      setActiveTab('hub');
    }
  }, [isAuthenticated, activeTab]);

  useEffect(() => {
    const tabKey = activeTab === 'live' ? 'floor' : activeTab === 'explore' ? 'hub' : activeTab;
    setVisitedTabs(prev => (prev as any)[tabKey] ? prev : { ...prev, [tabKey]: true });
  }, [activeTab]);

  useEffect(() => {
    const tabKey = activeTab === 'live' ? 'floor' : activeTab === 'explore' ? 'hub' : activeTab;
    setVisitedTabs(prev => (prev as any)[tabKey] ? prev : { ...prev, [tabKey]: true });
  }, [user?.id, activeAccount?.id]);

  useEffect(() => {
    if (isSlaveAccount && (activeTab === 'command-pit' || activeTab === 'floor' || activeTab === 'live')) {
      setActiveTab('hub');
    }
  }, [isSlaveAccount, activeTab]);
  const [posts, setPosts] = useState<NetworkTicket[]>([]);
  const [recentConnections, setRecentConnections] = useState<any[]>([]);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [isInitialLoading, setIsInitialLoading] = useState(true);
  const hasInitialLoadedRef = useRef(false);
  const [activeThreadPost, setActiveThreadPost] = useState<NetworkTicket | null>(null);
  const [activeConnectionsPost, setActiveConnectionsPost] = useState<NetworkTicket | null>(null);
  const [activeDedicatedPost, setActiveDedicatedPost] = useState<NetworkTicket | null>(null);
  const [activeAgentProfile, setActiveAgentProfile] = useState<{ name: string; avatar?: string; agentId?: string } | null>(null);
  const [activeChat, setActiveChat] = useState<any | null>(null);
  const [activeClusterChat, setActiveClusterChat] = useState<{ id: string; name: string; symbol?: string } | null>(null);
  const activeChatRef = useRef<any | null>(null);
  const activeClusterChatRef = useRef<any | null>(null);

  useEffect(() => {
    activeChatRef.current = activeChat;
  }, [activeChat]);

  useEffect(() => {
    activeClusterChatRef.current = activeClusterChat;
  }, [activeClusterChat]);

  const accountKey = getAccountKey(user?.id, activeAccount?.id);
  const accountKeyRef = useRef(accountKey);
  const userRef = useRef(user);
  const activeAccountRef = useRef(activeAccount);
  const userPasswordRef = useRef(userPassword);
  const sessionAuthTypeRef = useRef(sessionAuthType);
  const e2eeStatusRef = useRef(e2eeStatus);
  const latestEntitiesRef = useRef<{ connections: any[]; clusters: any[] }>({ connections: [], clusters: [] });
  useEffect(() => {
    accountKeyRef.current = accountKey;
  }, [accountKey]);
  useEffect(() => {
    userRef.current = user;
  }, [user]);
  useEffect(() => {
    activeAccountRef.current = activeAccount;
  }, [activeAccount]);
  useEffect(() => {
    userPasswordRef.current = userPassword;
  }, [userPassword]);
  useEffect(() => {
    sessionAuthTypeRef.current = sessionAuthType;
  }, [sessionAuthType]);
  useEffect(() => {
    e2eeStatusRef.current = e2eeStatus;
  }, [e2eeStatus]);

  useEffect(() => {
    if (!isAuthenticated || e2eeStatus !== 'ready') return;
    const curUser = activeAccount || user;
    if (!curUser?.agentId) return;
    const fleetConns = getQueryCache(accountKey, '/api/command-pit/fleet')?.data;
    const rawConns = getQueryCache(accountKey, '/api/connections')?.data;
    const cachedConns = (Array.isArray(fleetConns) && fleetConns.length > 0 ? fleetConns : rawConns) || [];
    const cachedClusters = getQueryCache(accountKey, '/api/clusters')?.data || [];
    const conns = latestEntitiesRef.current.connections.length > 0 ? latestEntitiesRef.current.connections : cachedConns;
    const clusters = latestEntitiesRef.current.clusters.length > 0 ? latestEntitiesRef.current.clusters : cachedClusters;
    if (conns.length > 0 || clusters.length > 0) {
      warmupUnreadChats({
        connections: conns,
        clusters: clusters,
        accountKey,
        accountId: curUser.id || curUser.agentId || 'anon',
        userAgentId: curUser.agentId,
        userPassword: userPasswordRef.current,
        authType: sessionAuthTypeRef.current || getCurrentSessionAuthType() || 'human',
      }).catch(() => {});
    }
  }, [isAuthenticated, e2eeStatus, userPassword, accountKey, activeAccount, user]);

  useEffect(() => {
    if (isAuthenticated && activeTab === 'command-pit') {
      window.dispatchEvent(new CustomEvent('command-pit-activated'));
    }
  }, [isAuthenticated, activeTab]);

  const [totalUnreadCount, setTotalUnreadCount] = useState<number>(() => getTotalUnreadCount(accountKey));

  const updateDocumentTitle = useCallback((count: number) => {
    const baseTitle = 'AAMARVA — Autonomous Agent Command Protocol & Infrastructure';
    if (count > 0) {
      const displayCount = count > 99 ? '99+' : count;
      document.title = `(${displayCount}) ${baseTitle}`;
    } else {
      document.title = baseTitle;
    }
  }, []);

  useEffect(() => {
    const syncUnread = (e?: Event) => {
      const detailKey = (e as CustomEvent)?.detail?.accountKey;
      const currentKey = detailKey || accountKeyRef.current || accountKey || getAccountKey(user?.id, activeAccount?.id);
      const count = getTotalUnreadCount(currentKey);
      setTotalUnreadCount(count);
      updateDocumentTitle(count);
    };
    syncUnread();
    window.addEventListener('unread-counts-updated', syncUnread);
    return () => window.removeEventListener('unread-counts-updated', syncUnread);
  }, [accountKey, user?.id, activeAccount?.id, updateDocumentTitle]);

  useEffect(() => {
    updateDocumentTitle(totalUnreadCount);
  }, [totalUnreadCount, updateDocumentTitle]);

  // Synchronize unread counts against authoritative server state when authenticated
  useEffect(() => {
    if (!isAuthenticated) return;
    const syncServerUnread = async () => {
      try {
        const resolvedAuthType = sessionAuthTypeRef.current || getCurrentSessionAuthType() || 'human';
        const [connRes, cluRes, masterRes] = await Promise.allSettled([
          apiFetch('/api/connections?limit=100', { authType: resolvedAuthType }),
          apiFetch('/api/clusters', { authType: resolvedAuthType }),
          apiFetch('/api/auth/master/accounts', { authType: resolvedAuthType }),
        ]);
        const currentKey = accountKeyRef.current || accountKey || getAccountKey(user?.id, activeAccount?.id);
        const curUser = activeAccountRef.current || activeAccount || userRef.current || user;
        const selfIds = [
          activeAccountRef.current?.id,
          activeAccountRef.current?.agentId,
          curUser?.id,
          curUser?.agentId,
        ].filter((x): x is string => Boolean(x && typeof x === 'string'));

        const connList =
          connRes.status === 'fulfilled' && connRes.value?.success
            ? (Array.isArray(connRes.value.data?.connections)
                ? connRes.value.data.connections
                : Array.isArray(connRes.value.data)
                  ? connRes.value.data
                  : null)
            : null;
        const cluList =
          cluRes.status === 'fulfilled' && cluRes.value?.success && Array.isArray(cluRes.value.data)
            ? cluRes.value.data
            : null;

        if (masterRes.status === 'fulfilled' && masterRes.value?.success && masterRes.value?.data) {
          seedFleetAccountsCache(masterRes.value.data);
        }

        const masterData =
          masterRes.status === 'fulfilled' && masterRes.value?.success && masterRes.value?.data
            ? masterRes.value.data
            : getQueryCache('master_accounts', '/api/auth/master/accounts')?.data;

        let mergedConns: any[] | undefined = undefined;
        if (connList !== null) {
          setQueryCache(currentKey, '/api/connections', connList);
          const activeId = activeAccountRef.current?.id || activeAccount?.id || userRef.current?.id || user?.id;
          mergedConns = buildCommandPitFleetList(connList, masterData, activeId, currentKey);
          setQueryCache(currentKey, '/api/command-pit/fleet', mergedConns);
        }

        if (cluList !== null) {
          setQueryCache(currentKey, '/api/clusters', cluList);
        }

        reconcileUnreadEntities(currentKey, {
          connections: mergedConns,
          clusters: cluList ?? undefined,
          selfIds,
        });

        const latestCount = getTotalUnreadCount(currentKey);
        setTotalUnreadCount(latestCount);
        updateDocumentTitle(latestCount);

        latestEntitiesRef.current = {
          connections: mergedConns || [],
          clusters: cluList || [],
        };

        if (curUser?.agentId) {
          warmupUnreadChats({
            connections: mergedConns || [],
            clusters: cluList || [],
            accountKey: currentKey,
            accountId: curUser.id || curUser.agentId || 'anon',
            userAgentId: curUser.agentId,
            userPassword: userPasswordRef.current,
            authType: resolvedAuthType,
          }).catch(() => {});
        }
      } catch (e) {}
    };

    let lastUnreadSyncAt = Date.now();
    const runSyncServerUnread = () => {
      lastUnreadSyncAt = Date.now();
      return syncServerUnread();
    };

    runSyncServerUnread();

    const handleVisibilityOrFocus = () => {
      if (typeof document === 'undefined' || document.visibilityState === 'visible') {
        if (Date.now() - lastUnreadSyncAt >= 10000) {
          runSyncServerUnread();
        }
      }
    };
    const pollInterval = setInterval(() => {
      if (typeof document === 'undefined' || document.visibilityState === 'visible') {
        const elapsed = Date.now() - lastUnreadSyncAt;
        if (isRealtimeStreamConnected() && elapsed < 60000) {
          return;
        }
        runSyncServerUnread();
      }
    }, 15000);

    window.addEventListener('account-changed', runSyncServerUnread);
    window.addEventListener('cluster-updated', runSyncServerUnread);
    window.addEventListener('aamarva-realtime-resync', runSyncServerUnread);
    window.addEventListener('focus', handleVisibilityOrFocus);
    document.addEventListener('visibilitychange', handleVisibilityOrFocus);
    return () => {
      clearInterval(pollInterval);
      window.removeEventListener('account-changed', runSyncServerUnread);
      window.removeEventListener('cluster-updated', runSyncServerUnread);
      window.removeEventListener('aamarva-realtime-resync', runSyncServerUnread);
      window.removeEventListener('focus', handleVisibilityOrFocus);
      document.removeEventListener('visibilitychange', handleVisibilityOrFocus);
    };
  }, [isAuthenticated, accountKey, activeAccount?.id, user?.id, updateDocumentTitle]);

  useEffect(() => {
    if (!isAuthenticated) return;
    const activeTargetAgent = activeAccount?.agentId || activeAccount?.id || user?.agentId || user?.id;
    const resolvedAuthType = sessionAuthType || getCurrentSessionAuthType() || 'human';

    const lastReadPostAt = new Map<string, number>();
    const postReadThrottled = (key: string, url: string, bodyObj: any, authTypeVal: 'human' | 'agent') => {
      const now = Date.now();
      const prevAt = lastReadPostAt.get(key) || 0;
      if (now - prevAt < 3000) return;
      lastReadPostAt.set(key, now);
      apiFetch(url, {
        method: 'POST',
        authType: authTypeVal,
        body: JSON.stringify(bodyObj),
      }).catch(() => {});
    };

    const unsubscribe = subscribeRealtimeStream({
      targetAgentId: activeTargetAgent,
      authType: resolvedAuthType,
      onReconnect: () => {
        window.dispatchEvent(new CustomEvent('aamarva-realtime-resync'));
      },
      onEvent: (data) => {
        try {
          if (!data || typeof data !== 'object') return;

          const eventType = data.type || data.event || data.eventType;
          let details: any = data.details || {};
          if (typeof details === 'string') {
            try {
              details = JSON.parse(details);
            } catch {
              details = { message: details };
            }
          }

          if (eventType === 'MESSAGE_RECEIVED') {
            const activePersona = activeAccountRef.current || userRef.current;
            const currentKey = accountKeyRef.current || accountKey || getAccountKey(userRef.current?.id, activeAccountRef.current?.id);
            const connId =
              details?.connectionId ||
              details?.connId ||
              data.connectionId ||
              data.connId ||
              data.entityId ||
              details?.entityId ||
              (data.targetId && !data.targetId.startsWith('msg_') ? data.targetId : null);

            const senderId =
              details?.senderAgentId ||
              details?.senderId ||
              details?.agentId ||
              data.actorId ||
              data.senderAgentId ||
              data.senderId ||
              data.agentId;

            const myId = (activePersona?.id || '').toLowerCase();
            const myAgentId = (activePersona?.agentId || '').toLowerCase().replace(/^@+/, '');
            const sIdLower = (senderId || '').toLowerCase().replace(/^@+/, '');
            if ((myId && (sIdLower === myId || (senderId || '').toLowerCase() === myId)) || (myAgentId && sIdLower === myAgentId)) {
              // Outbound message from self - do not count as unread
              return;
            }

            // Strict recipient isolation: do not count messages addressed to other fleet slaves/slots
            const recUserId = (details?.recipientId || details?.recipientUserId || '').toString().trim().toLowerCase();
            const recAgentId = (details?.recipientAgentId || '').toString().trim().toLowerCase().replace(/^@+/, '');
            if (recUserId || recAgentId) {
              const matchesUser = Boolean(recUserId && myId && recUserId === myId);
              const matchesAgent = Boolean(recAgentId && myAgentId && recAgentId === myAgentId);
              if (!matchesUser && !matchesAgent) {
                return;
              }
            }

            const candidateEntityIds = [connId, senderId, details?.connectionId, details?.connId, data.actorId, details?.senderAgentId, details?.senderId].filter(Boolean);
            if (!recUserId && !recAgentId && !isConnectionActiveForAccount(currentKey, candidateEntityIds)) {
              return;
            }

            const currentActive = activeChatRef.current;
            const currentConnId = currentActive?.id || currentActive?.connectionId;
            const currentAgentId = currentActive?.agentId;

            const rawMsgId =
              details?.messageId ||
              details?.id ||
              (data.targetId && data.targetId.startsWith('msg_') ? data.targetId : null) ||
              data.id ||
              data.eventId;

            const currentActiveConnIds = [
              currentConnId,
              ...(Array.isArray(currentActive?.allConnectionIds) ? currentActive.allConnectionIds : []),
            ].filter(Boolean);

            const isChatCurrentlyOpen = Boolean(
              currentConnId &&
              (currentActiveConnIds.includes(connId) ||
                (senderId && currentAgentId && senderId.toLowerCase().replace(/^@+/, '') === currentAgentId.toLowerCase().replace(/^@+/, '')) ||
                (connId && currentAgentId && connId.replace(/^usr_/, '').toLowerCase() === currentAgentId.replace(/^@+/, '').toLowerCase()))
            );

            // Enrich warmup with all known connection ID aliases from fleet/connections cache
            const fleetCached = getQueryCache(currentKey, '/api/command-pit/fleet')?.data;
            const rawConnsCached = getQueryCache(currentKey, '/api/connections')?.data;
            const pool = [...(Array.isArray(fleetCached) ? fleetCached : []), ...(Array.isArray(rawConnsCached) ? rawConnsCached : [])];
            const cleanSender = (senderId || '').toString().trim().replace(/^@+/, '').toLowerCase();
            const matchedConn = pool.find((c: any) => {
              const cId = String(c?.id || c?.connectionId || '').toLowerCase();
              const cAgent = String(c?.agentId || '').trim().replace(/^@+/, '').toLowerCase();
              const cAliases = Array.isArray(c?.allConnectionIds) ? c.allConnectionIds.map((x: any) => String(x).toLowerCase()) : [];
              return (connId && (cId === String(connId).toLowerCase() || cAliases.includes(String(connId).toLowerCase()))) || (cleanSender && cAgent === cleanSender);
            });
            const targetWarmConnId = connId || matchedConn?.id || matchedConn?.connectionId || senderId;
            const enrichedAllIds = Array.from(
              new Set([
                connId,
                matchedConn?.id,
                matchedConn?.connectionId,
                ...(Array.isArray(matchedConn?.allConnectionIds) ? matchedConn.allConnectionIds : []),
              ].filter((x): x is string => Boolean(x && typeof x === 'string' && x.trim())))
            );

            const effectivePostAuth = sessionAuthTypeRef.current || getCurrentSessionAuthType() || 'human';
            if (isChatCurrentlyOpen) {
              clearUnreadCount(currentKey, [connId, senderId, ...currentActiveConnIds, currentAgentId]);
              postReadThrottled(
                `conn:${currentConnId || connId}`,
                `/api/connections/${currentConnId || connId}/read`,
                { connectionId: currentConnId || connId, agentId: currentAgentId || senderId },
                effectivePostAuth
              );
              playMessageNotificationSound();
            } else {
              incrementUnreadCount(
                currentKey,
                rawMsgId,
                candidateEntityIds
              );
            }
            const latestCount = getTotalUnreadCount(currentKey);
            setTotalUnreadCount(latestCount);
            updateDocumentTitle(latestCount);

            void (async () => {
              let ingested = false;
              if (details?.ciphertext && targetWarmConnId && activePersona?.agentId) {
                ingested = await ingestRealtimeConnectionMessage({
                  connectionId: targetWarmConnId,
                  allConnectionIds: enrichedAllIds.length > 0 ? enrichedAllIds : undefined,
                  messageId: rawMsgId,
                  senderAgentId: senderId,
                  peerAgentId: matchedConn?.agentId || senderId,
                  peerPublicKey: matchedConn?.peerE2eePublicKey,
                  senderPublicKey: details?.senderPublicKey,
                  senderKeyEpoch: details?.senderKeyEpoch,
                  ciphertext: details.ciphertext,
                  nonce: details.nonce,
                  version: details.version,
                  keyEpoch: details.keyEpoch,
                  sequence: details.sequence,
                  createdAt: details.createdAt || data.createdAt,
                  accountKey: currentKey,
                  userAgentId: activePersona.agentId,
                  userPassword: userPasswordRef.current,
                }).catch(() => false);
              }

              if (!isChatCurrentlyOpen && !ingested && targetWarmConnId && activePersona?.agentId) {
                warmupConnectionChat({
                  connectionId: targetWarmConnId,
                  allConnectionIds: enrichedAllIds.length > 0 ? enrichedAllIds : undefined,
                  peerAgentId: senderId || matchedConn?.agentId,
                  peerPublicKey: matchedConn?.peerE2eePublicKey,
                  accountKey: currentKey,
                  userAgentId: activePersona.agentId,
                  userPassword: userPasswordRef.current,
                  authType: effectivePostAuth,
                }).catch(() => {});
              }

              window.dispatchEvent(new CustomEvent('aamarva-realtime-message', {
                detail: {
                  type: 'connection',
                  connectionId: connId,
                  senderAgentId: senderId,
                  actorId: data.actorId,
                  accountKey: currentKey,
                  messageId: rawMsgId,
                  ingested,
                },
              }));
            })();
          } else if (eventType === 'CLUSTER_MESSAGE_RECEIVED') {
            const activePersona = activeAccountRef.current || userRef.current;
            const currentKey = accountKeyRef.current || accountKey || getAccountKey(userRef.current?.id, activeAccountRef.current?.id);
            const clusterId =
              details?.clusterId ||
              details?.id ||
              data.clusterId ||
              (data.targetId && !data.targetId.startsWith('msg_') ? data.targetId : null) ||
              data.entityId;

            const senderId = details?.senderAgentId || details?.senderId || data.actorId;
            const myId = (activePersona?.id || '').toLowerCase();
            const myAgentId = (activePersona?.agentId || '').toLowerCase().replace(/^@+/, '');
            const sIdLower = (senderId || '').toLowerCase().replace(/^@+/, '');
            if ((myId && (sIdLower === myId || (senderId || '').toLowerCase() === myId)) || (myAgentId && sIdLower === myAgentId)) {
              // Outbound message from self - do not count as unread
              return;
            }

            if (!isClusterActiveForAccount(currentKey, clusterId)) {
              return;
            }

            const rawClusterMsgId =
              details?.messageId ||
              details?.id ||
              (data.targetId && data.targetId.startsWith('msg_') ? data.targetId : null) ||
              data.id ||
              data.eventId;

            const cachedClusters = getQueryCache(currentKey, '/api/clusters')?.data;
            const matchedCluster = Array.isArray(cachedClusters)
              ? cachedClusters.find((c: any) => String(c?.id || '').toLowerCase() === String(clusterId).toLowerCase())
              : undefined;

            const currentCluster = activeClusterChatRef.current;
            const isClusterCurrentlyOpen = Boolean(
              currentCluster &&
              clusterId &&
              String(currentCluster.id || '').toLowerCase() === String(clusterId).toLowerCase()
            );
            const effectivePostAuth = sessionAuthTypeRef.current || getCurrentSessionAuthType() || 'human';
            if (isClusterCurrentlyOpen) {
              clearUnreadCount(currentKey, [clusterId, currentCluster.id, currentCluster.name]);
              postReadThrottled(
                `clu:${clusterId}`,
                `/api/clusters/${clusterId}/read`,
                { clusterId },
                effectivePostAuth
              );
              playMessageNotificationSound();
            } else {
              incrementUnreadCount(currentKey, rawClusterMsgId, clusterId);
            }
            const latestCount = getTotalUnreadCount(currentKey);
            setTotalUnreadCount(latestCount);
            updateDocumentTitle(latestCount);

            void (async () => {
              let ingested = false;
              if (details?.ciphertext && clusterId && activePersona?.agentId) {
                ingested = await ingestRealtimeClusterMessage({
                  clusterId,
                  clusterName: matchedCluster?.name || details?.clusterName,
                  messageId: rawClusterMsgId,
                  senderAgentId: senderId,
                  senderAgentName: details?.senderAgentName,
                  senderAgentAvatar: details?.senderAgentAvatar,
                  ciphertext: details.ciphertext,
                  nonce: details.nonce,
                  version: details.version,
                  keyEpoch: details.keyEpoch,
                  audienceHash: details.audienceHash,
                  sequence: details.sequence,
                  recipients: details.recipients,
                  createdAt: details.createdAt || data.createdAt,
                  accountKey: currentKey,
                  accountId: activePersona.id || activePersona.agentId || 'anon',
                  userAgentId: activePersona.agentId,
                  userPassword: userPasswordRef.current,
                }).catch(() => false);
              }

              if (!isClusterCurrentlyOpen && !ingested && clusterId && activePersona?.agentId) {
                warmupClusterChat({
                  clusterId,
                  clusterName: matchedCluster?.name || details?.clusterName,
                  activeCluster: matchedCluster,
                  accountKey: currentKey,
                  accountId: activePersona.id || activePersona.agentId || 'anon',
                  userAgentId: activePersona.agentId,
                  userPassword: userPasswordRef.current,
                  authType: effectivePostAuth,
                }).catch(() => {});
              }

              window.dispatchEvent(new CustomEvent('aamarva-realtime-message', {
                detail: {
                  type: 'cluster',
                  clusterId,
                  senderAgentId: senderId,
                  actorId: data.actorId,
                  accountKey: currentKey,
                  messageId: rawClusterMsgId,
                  ingested,
                },
              }));
            })();
          }
        } catch (e) {
          // Ignore SSE parse errors
        }
      },
    });

    return unsubscribe;
  }, [isAuthenticated, accountKey, updateDocumentTitle, sessionAuthType, user?.id, user?.agentId, activeAccount?.id, activeAccount?.agentId]);
  const [modalHistory, setModalHistory] = useState<{
    type: 'thread' | 'connections' | 'profile' | 'cluster' | 'dedicated_post' | 'chat' | 'cluster_chat';
    data: any;
  }[]>([]);
  const [isNewPostOpen, setIsNewPostOpen] = useState(false);
  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);
  const [selectedSearchMcpServer, setSelectedSearchMcpServer] = useState<McpServer | null>(null);
  const [selectedSearchMcpTools, setSelectedSearchMcpTools] = useState<McpTool[]>([]);
  const [isSearchMcpModalOpen, setIsSearchMcpModalOpen] = useState(false);
  const [searchMcpFleetAgents, setSearchMcpFleetAgents] = useState<FleetAgent[]>([]);
  const [isResetPasswordOpen, setIsResetPasswordOpen] = useState(false);
  const initialRegUrlState = useMemo(() => {
    if (typeof window === 'undefined') {
      return { open: false, email: '', fleetId: '', slotToken: '', fromLink: false };
    }
    try {
      const url = new URL(window.location.href);
      const actionParam = url.searchParams.get('action');
      const isRegisterParam = url.searchParams.get('register') === 'true';
      const isReg =
        actionParam === 'register' ||
        isRegisterParam ||
        window.location.pathname === '/register' ||
        window.location.href.includes('action=register');
      if (!isReg) {
        return { open: false, email: '', fleetId: '', slotToken: '', fromLink: false };
      }
      return {
        open: true,
        email: url.searchParams.get('email') || '',
        fleetId: (url.searchParams.get('fleetId') || url.searchParams.get('fleet_id') || '').trim().toUpperCase(),
        slotToken: (url.searchParams.get('slotToken') || '').trim(),
        fromLink: true,
      };
    } catch {
      return { open: false, email: '', fleetId: '', slotToken: '', fromLink: false };
    }
  }, []);
  const [isFloorRegisterOpen, setIsFloorRegisterOpen] = useState(() => initialRegUrlState.open);
  const [floorRegisterEmail, setFloorRegisterEmail] = useState(() => initialRegUrlState.email);
  const [floorRegisterFleetId, setFloorRegisterFleetId] = useState(() => initialRegUrlState.fleetId);
  const [floorRegisterSlotToken, setFloorRegisterSlotToken] = useState(() => initialRegUrlState.slotToken);
  const [floorRegisterFromLink, setFloorRegisterFromLink] = useState(() => initialRegUrlState.fromLink);
  const [registeredCredentials, setRegisteredCredentials] = useState<{ agentId: string; apiKey: string } | null>(null);
  const [showApiKeyModal, setShowApiKeyModal] = useState(false);
  const [activeCluster, setActiveCluster] = useState<any | null>(null);
  const [resetPasswordToken, setResetPasswordToken] = useState<string | null>(null);
  const [emailVerificationToken, setEmailVerificationToken] = useState<string | null>(null);
  const [apiKeyRotationToken, setApiKeyRotationToken] = useState<string | null>(null);
  const [deviceSize, setDeviceSize] = useState<'mobile' | 'tablet' | 'desktop'>('desktop');
  const [showDesktopTabs, setShowDesktopTabs] = useState(true);
  const lastScrollY = useRef(0);

  // Screen-size detection
  useEffect(() => {
    const handleResize = () => {
      const width = window.innerWidth;
      if (width < 768) {
        setDeviceSize('mobile');
      } else if (width <= 1024) {
        setDeviceSize('tablet');
      } else {
        setDeviceSize('desktop');
      }
    };
    
    handleResize(); // Initial call
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Smart header scroll tracking for all devices
  useEffect(() => {
    const threshold = 10; // minimum scroll movement to trigger a change
    const safeZone = 120; // safe zone from top of page where header is always shown

    const handleScroll = (e: Event) => {
      // Only track the main page window/document scrolling
      // Ignore scroll events originating from inner modals, chat lists, or overflow containers
      if (e.target && e.target !== document && e.target !== window && e.target !== document.documentElement) {
        return;
      }

      const currentScrollY = window.scrollY || 0;
      const difference = Math.abs(currentScrollY - lastScrollY.current);
      
      // If we are close to the top, keep the header always visible
      if (currentScrollY <= safeZone) {
        setShowDesktopTabs(true);
        lastScrollY.current = currentScrollY;
        return;
      }

      // Only toggle if the scroll difference exceeds our threshold
      if (difference > threshold) {
        if (currentScrollY > lastScrollY.current) {
          // Scrolling down -> hide
          setShowDesktopTabs(false);
        } else {
          // Scrolling up -> show
          setShowDesktopTabs(true);
        }
        lastScrollY.current = currentScrollY;
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    
    // Enable CSS :active state on touch devices (Chromebooks, tablets, mobiles)
    const handleTouchStart = () => {};
    window.addEventListener('touchstart', handleTouchStart, { passive: true });

    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('touchstart', handleTouchStart);
    };
  }, []);

  // URL handling for email verification & password reset
  useEffect(() => {
    const handleUrlSession = async () => {
      const href = window.location.href || '';
      const url = new URL(href);
      const cleanPath = window.location.pathname.toLowerCase();

      if (
        cleanPath.startsWith('/applications/admin') ||
        cleanPath.startsWith('/appliactions/admin') ||
        cleanPath.startsWith('/application/admin') ||
        cleanPath.startsWith('/admin/applications') ||
        url.searchParams.get('tab') === 'applications-admin' ||
        url.searchParams.get('view') === 'applications-admin'
      ) {
        setActiveTab('applications-admin');
        return;
      }
      
      // Handle Email Change Verification
      const emailToken = url.searchParams.get('token');
      if (href.includes('verify-email-change') && emailToken) {
        setEmailVerificationToken(emailToken);
        return;
      }

      // Handle Account Email Verification (for Verified Tick Mark)
      if ((href.includes('verify-email') || href.includes('account-verification')) && emailToken) {
        setEmailVerificationToken(emailToken);
        return;
      }

      // Handle API Key Rotation Confirmation URL
      if (href.includes('confirm-api-key-rotation') && emailToken) {
        setApiKeyRotationToken(emailToken);
        return;
      }

      // Handle Password Reset URL
      const resetToken = url.searchParams.get('token') || url.searchParams.get('resetToken');
      if (href.includes('reset-password') || resetToken) {
        if (resetToken) {
          setResetPasswordToken(resetToken);
        }
        setIsResetPasswordOpen(true);
        return;
      }

      // Handle Direct Web Floor Registration (e.g. from approval email: /?action=register&email=...&fleetId=...)
      const actionParam = url.searchParams.get('action');
      const isRegisterParam = url.searchParams.get('register') === 'true';
      const registerEmailParam = url.searchParams.get('email') || '';
      const registerFleetIdParam = url.searchParams.get('fleetId') || url.searchParams.get('fleet_id') || '';
      const registerSlotTokenParam = url.searchParams.get('slotToken') || '';

      if (actionParam === 'register' || isRegisterParam || window.location.pathname === '/register' || href.includes('action=register')) {
        if (registerEmailParam) {
          setFloorRegisterEmail(registerEmailParam);
        }
        if (registerFleetIdParam) {
          setFloorRegisterFleetId(registerFleetIdParam.trim().toUpperCase());
        }
        if (registerSlotTokenParam) {
          setFloorRegisterSlotToken(registerSlotTokenParam.trim());
        }
        setFloorRegisterFromLink(true);
        setIsFloorRegisterOpen(true);
      }
    };

    handleUrlSession();
  }, []);
  // Infinite scroll observer setup
  const observer = useRef<IntersectionObserver | null>(null);
  const lastPostElementRef = useCallback((node: HTMLDivElement) => {
    if (isLoadingMore) return;
    if (observer.current) observer.current.disconnect();
    
    observer.current = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting && hasMore) {
        fetchPosts(page + 1, true);
      }
    });
    
    if (node) observer.current.observe(node);
  }, [isLoadingMore, hasMore, page]);



  const fetchRecentConnections = async () => {
    try {
      const res = await apiFetch('/api/connections/recent', { authType: 'none' });
      if (res && res.success) {
        setRecentConnections(res.data || []);
      }
    } catch {
      // Background guest fetch gracefully falls back to empty list
    }
  };

  // Fetch posts from backend
  const fetchPosts = async (pageNum = 1, append = false) => {
    try {
      if (append) {
        setIsLoadingMore(true);
      } else if (!hasInitialLoadedRef.current) {
        setIsInitialLoading(true);
      }
      // Ticket endpoint removed
      const res = { success: false, data: null };
      const rawList = Array.isArray(res?.data?.tickets)
        ? res.data.tickets
        : (Array.isArray(res?.data?.posts) ? res.data.posts : null);
      if (res && res.success && rawList) {
        const mappedPosts: NetworkTicket[] = rawList.map((p: any) => ({
          id: p.id,
          ticketId: p.ticketId || p.id,
          postId: p.postId || p.id,
          agentName: p.agentName || 'Agent',
          agentId: p.agentId,
          avatar: p.avatar || undefined,
          content: p.content,
          timestamp: p.createdAt ? new Date(p.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Just now',
          createdAt: p.createdAt,
          rawMinutesAgo: p.createdAt ? Math.max(0, Math.floor((Date.now() - new Date(p.createdAt).getTime()) / 60000)) : 0,
          bidsCount: p.bidsCount ?? p.repliesCount ?? (p.bids ? p.bids.length : 0),
          repliesCount: p.repliesCount ?? p.bidsCount ?? (p.bids ? p.bids.length : 0),
          connectionsCount: typeof p.connectionsCount === 'number' ? p.connectionsCount : (Array.isArray(p.connectionsList) ? p.connectionsList.length : 0),
          verified: p.emailVerified === true,
          emailVerified: p.emailVerified === true,
          verificationStatus: p.verificationStatus || (p.emailVerified ? 'verified' : 'not verified'),
          status: 'active',
          type: p.type || 'intake',
          category: p.category,
          bids: Array.isArray(p.bids || p.replies) ? (p.bids || p.replies).map((r: any) => ({
            id: r.id,
            bidId: r.bidId || r.id,
            replyId: r.replyId || r.id,
            agentName: r.agentName || r.author?.displayName || 'Agent',
            agentId: r.agentId || r.author?.agentId,
            avatar: r.avatar || r.author?.avatar || undefined,
            content: r.content,
            timestamp: r.createdAt ? new Date(r.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : (r.timestamp || 'Just now'),
            createdAt: r.createdAt,
            emailVerified: r.emailVerified === true,
            verificationStatus: r.verificationStatus || (r.emailVerified ? 'verified' : 'not verified'),
          })) : [],
          connectionsList: Array.isArray(p.connectionsList) ? p.connectionsList.map((c: any) => ({
            id: c.id,
            postId: c.postId,
            ticketId: c.ticketId || c.postId,
            replyId: c.replyId,
            bidId: c.bidId || c.replyId,
            agentName: c.agentName || c.replyAuthorAgentName || 'Connected Agent',
            agentId: c.agentId || c.replyAuthorAgentId,
            avatar: c.avatar || c.replyAuthorAvatar || undefined,
            postOwnerAgentName: c.postOwnerAgentName,
            postOwnerAgentId: c.postOwnerAgentId,
            postOwnerEmailVerified: c.postOwnerEmailVerified === true,
            replyAuthorEmailVerified: c.replyAuthorEmailVerified === true,
            emailVerified: c.emailVerified === true,
            verificationStatus: c.verificationStatus || (c.emailVerified ? 'verified' : 'not verified'),
            createdAt: c.createdAt,
          })) : [],
        }));
        
        if (append) {
          setPosts(prev => [...prev, ...mappedPosts]);
          setPage(pageNum);
        } else if (pageNum === 1) {
          setPosts(prev => {
            if (prev.length === 0) return mappedPosts;
            const existingIds = new Set(prev.map(p => p.id));
            const newPosts = mappedPosts.filter(p => !existingIds.has(p.id));
            const updatedPrev = prev.map(p => {
              const updated = mappedPosts.find(m => m.id === p.id);
              return updated || p;
            });
            return [...newPosts, ...updatedPrev];
          });
        }
        
        if (rawList.length < 20) {
          setHasMore(false);
        } else {
          setHasMore(true);
        }
      }
    } catch (e: any) {
      if (e.message && e.message.includes('Failed to fetch')) {
        console.warn('Network issue loading posts (likely dev server restarting):', e);
      } else {
        console.warn('Failed to load posts:', e);
      }
    } finally {
      if (append) setIsLoadingMore(false);
      setIsInitialLoading(false);
      hasInitialLoadedRef.current = true;
    }
  };

  const { data: postsData, isLoading: isPostsLoading, refetch: refetchPosts } = usePosts(isAuthenticated, true);
  const { data: recentConnectionsData, refetch: refetchRecentConnections } = useRecentConnections(isAuthenticated, true);

  useEffect(() => {
    if (postsData) {
      // Map postsData to NetworkTicket format as done previously
      const mappedPosts: NetworkTicket[] = postsData.map((p: any) => ({
        id: p.id,
        ticketId: p.ticketId || p.id,
        postId: p.postId || p.id,
        agentName: p.agentName || 'Agent',
        agentId: p.agentId,
        avatar: p.avatar || undefined,
        content: p.content,
        timestamp: p.createdAt ? new Date(p.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Just now',
        createdAt: p.createdAt,
        rawMinutesAgo: p.createdAt ? Math.max(0, Math.floor((Date.now() - new Date(p.createdAt).getTime()) / 60000)) : 0,
        bidsCount: p.bidsCount ?? p.repliesCount ?? (p.bids ? p.bids.length : 0),
        repliesCount: p.repliesCount ?? p.bidsCount ?? (p.bids ? p.bids.length : 0),
        connectionsCount: typeof p.connectionsCount === 'number' ? p.connectionsCount : (Array.isArray(p.connectionsList) ? p.connectionsList.length : 0),
        verified: p.emailVerified === true,
        emailVerified: p.emailVerified === true,
        verificationStatus: p.verificationStatus || (p.emailVerified ? 'verified' : 'not verified'),
        status: 'active',
        type: p.type || 'intake',
        category: p.category,
        bids: Array.isArray(p.bids || p.replies) ? (p.bids || p.replies).map((r: any) => ({
          id: r.id,
          bidId: r.bidId || r.id,
          replyId: r.replyId || r.id,
          agentName: r.agentName || r.author?.displayName || 'Agent',
          agentId: r.agentId || r.author?.agentId,
          avatar: r.avatar || r.author?.avatar || undefined,
          content: r.content,
          timestamp: r.createdAt ? new Date(r.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : (r.timestamp || 'Just now'),
          createdAt: r.createdAt,
          emailVerified: r.emailVerified === true,
          verificationStatus: r.verificationStatus || (r.emailVerified ? 'verified' : 'not verified'),
        })) : [],
        connectionsList: Array.isArray(p.connectionsList) ? p.connectionsList.map((c: any) => ({
          id: c.id,
          postId: c.postId,
          ticketId: c.ticketId || c.postId,
          replyId: c.replyId,
          bidId: c.bidId || c.replyId,
          agentName: c.agentName || c.replyAuthorAgentName || 'Connected Agent',
          agentId: c.agentId || c.replyAuthorAgentId,
          avatar: c.avatar || c.replyAuthorAvatar || undefined,
          postOwnerAgentName: c.postOwnerAgentName,
          postOwnerAgentId: c.postOwnerAgentId,
          postOwnerEmailVerified: c.postOwnerEmailVerified === true,
          replyAuthorEmailVerified: c.replyAuthorEmailVerified === true,
          emailVerified: c.emailVerified === true,
          verificationStatus: c.verificationStatus || (c.emailVerified ? 'verified' : 'not verified'),
          createdAt: c.createdAt,
        })) : [],
      }));
      setPosts(mappedPosts);
      setIsInitialLoading(false);
      hasInitialLoadedRef.current = true;
    }
  }, [postsData]);

  useEffect(() => {
    if (recentConnectionsData) {
      setRecentConnections(recentConnectionsData);
    }
  }, [recentConnectionsData]);



  // Handler for adding a reply
  const handleAddReply = async (postId: string, replyContent: string) => {
    const maskedContent = replyContent;

    const newReply = {
      id: `rep-${Date.now()}`,
      agentName: currentUser ? (currentUser.name || currentUser.agentName) : 'User Agent',
      agentId: currentUser ? currentUser.agentId : 'agent-base',
      avatar: currentUser?.avatar || 'UA',
      badge: 'Verified User',
      content: maskedContent,
      timestamp: 'Just now',
      likes: 1,
    };

    setPosts((prevPosts) =>
      prevPosts.map((p) => {
        if (p.id === postId) {
          const updatedReplies = [...(p.bids || []), newReply];
          const updatedPost = {
            ...p,
            bidsCount: p.bidsCount + 1,
            bids: updatedReplies,
          };
          if (activeThreadPost && activeThreadPost.id === postId) {
            setActiveThreadPost(updatedPost);
          }
          return updatedPost;
        }
        return p;
      })
    );
  };

  // Handler for posting a new broadcast
  const handleCreatePost = async (
    agentName: string,
    avatar: string,
    content: string,
    postType: 'intake' | 'emit' = 'intake'
  ) => {
    const maskedContent = content;

    const finalName = currentUser ? (currentUser.name || currentUser.agentName) : agentName;
    const finalAvatar = currentUser?.avatar || avatar || 'U';

    const newPost: NetworkTicket = {
      id: `post-${Date.now()}`,
      agentName: finalName,
      agentId: currentUser ? currentUser.agentId : 'agent-base',
      avatar: finalAvatar,
      content: maskedContent,
      timestamp: 'Just now',
      rawMinutesAgo: 0,
      bidsCount: 0,
      connectionsCount: 0,
      verified: Boolean(currentUser?.emailVerified === true),
      emailVerified: Boolean(currentUser?.emailVerified === true),
      verificationStatus: currentUser?.emailVerified === true ? 'verified' : 'not verified',
      status: 'active',
      modelInfo: currentUser ? 'Authenticated User Agent' : 'Agent',
      type: postType,
      bids: [],
      connectionsList: [],
    };

    setPosts((prev) => [newPost, ...prev]);
  };

  const handleOpenNewPostWithPreset = () => {
    setActiveTab('floor');
    setIsNewPostOpen(true);
  };

  const handleOpenAgentProfile = (name: string, avatar?: string, agentId?: string) => {
    const newItem = { type: 'profile' as const, data: { name, avatar, agentId } };
    setModalHistory((prev) => [...prev, newItem]);
    
    // Switch active state to the new profile
    setActiveThreadPost(null);
    setActiveConnectionsPost(null);
    setActiveDedicatedPost(null);
    setActiveCluster(null);
    setActiveChat(null);
    setActiveClusterChat(null);
    setActiveAgentProfile({ name, avatar, agentId });
  };

  const handleOpenChat = (chat: any) => {
    if (!chat || !chat.id || typeof chat.id !== 'string' || !chat.id.trim()) {
      console.warn('[handleOpenChat] Blocked opening chat with missing or invalid connection ID:', chat);
      return;
    }
    const currentKey = accountKeyRef.current || accountKey || getAccountKey(userRef.current?.id, activeAccountRef.current?.id);
    const fleetCached = getQueryCache(currentKey, '/api/command-pit/fleet')?.data;
    const rawConnsCached = getQueryCache(currentKey, '/api/connections')?.data;
    const pool = [...(Array.isArray(fleetCached) ? fleetCached : []), ...(Array.isArray(rawConnsCached) ? rawConnsCached : [])];
    const targetIdLower = String(chat.id).trim().toLowerCase();
    const targetAgentLower = String(chat.agentId || '').trim().replace(/^@+/, '').toLowerCase();
    const matched = pool.find((c: any) => {
      const cId = String(c?.id || c?.connectionId || '').trim().toLowerCase();
      const cAgent = String(c?.agentId || '').trim().replace(/^@+/, '').toLowerCase();
      const cAliases = Array.isArray(c?.allConnectionIds) ? c.allConnectionIds.map((x: any) => String(x).trim().toLowerCase()) : [];
      return (cId && cId === targetIdLower) || cAliases.includes(targetIdLower) || (targetAgentLower && cAgent === targetAgentLower);
    });
    const mergedAliases = Array.from(
      new Set([
        chat.id,
        chat.connectionId,
        matched?.id,
        matched?.connectionId,
        ...(Array.isArray(chat.allConnectionIds) ? chat.allConnectionIds : []),
        ...(Array.isArray(matched?.allConnectionIds) ? matched.allConnectionIds : []),
      ].filter((x): x is string => Boolean(x && typeof x === 'string' && x.trim())))
    );
    const enrichedChat = {
      ...chat,
      allConnectionIds: mergedAliases.length > 0 ? mergedAliases : chat.allConnectionIds,
      agentId: chat.agentId || matched?.agentId,
      peerE2eePublicKey: chat.peerE2eePublicKey || matched?.peerE2eePublicKey,
      isMaster: chat.isMaster ?? matched?.isMaster,
      isSlave: chat.isSlave ?? matched?.isSlave,
    };

    clearUnreadCount(currentKey, [enrichedChat.id, enrichedChat.connectionId, enrichedChat.agentId, enrichedChat.agentName, ...(mergedAliases || [])]);
    const newItem = { type: 'chat' as const, data: enrichedChat };
    setModalHistory((prev) => [...prev, newItem]);
    
    setActiveAgentProfile(null);
    setActiveThreadPost(null);
    setActiveConnectionsPost(null);
    setActiveDedicatedPost(null);
    setActiveCluster(null);
    setActiveClusterChat(null);
    setActiveChat(enrichedChat);
  };

  const handleOpenClusterChat = (cluster: { id: string; name: string; clusterId?: string }) => {
    if (isSlaveAccount) {
      console.warn('[handleOpenClusterChat] Blocked opening cluster chat: slave UI messaging is disabled');
      return;
    }
    const currentKey = accountKeyRef.current || accountKey || getAccountKey(userRef.current?.id, activeAccountRef.current?.id);
    const curAgentId = activeAccountRef.current?.agentId || userRef.current?.agentId;
    const curAccountId = activeAccountRef.current?.id || userRef.current?.id || 'anon';
    if (cluster.id && curAgentId) {
      warmupClusterChat({
        clusterId: cluster.id,
        clusterName: cluster.name,
        accountKey: currentKey,
        accountId: curAccountId,
        userAgentId: curAgentId,
        userPassword: userPasswordRef.current,
        authType: sessionAuthTypeRef.current || getCurrentSessionAuthType() || 'human',
      }).catch(() => {});
    }
    clearUnreadCount(currentKey, [cluster.id, cluster.clusterId, cluster.name].filter(Boolean));
    const newItem = { type: 'cluster_chat' as const, data: cluster };
    setModalHistory((prev) => [...prev, newItem]);
    
    setActiveAgentProfile(null);
    setActiveThreadPost(null);
    setActiveConnectionsPost(null);
    setActiveDedicatedPost(null);
    setActiveCluster(null);
    setActiveChat(null);
    setActiveClusterChat(cluster);
  };

  const handleOpenClusterMembers = (cluster: any) => {
    const newItem = { type: 'cluster' as const, data: cluster };
    setModalHistory((prev) => [...prev, newItem]);
    
    setActiveAgentProfile(null);
    setActiveThreadPost(null);
    setActiveConnectionsPost(null);
    setActiveDedicatedPost(null);
    setActiveChat(null);
    setActiveClusterChat(null);
    setActiveCluster(cluster);
  };

  const handleOpenThread = (post: NetworkTicket) => {
    const newItem = { type: 'thread' as const, data: post };
    setModalHistory((prev) => [...prev, newItem]);
    setActiveAgentProfile(null);
    setActiveConnectionsPost(null);
    setActiveDedicatedPost(null);
    setActiveChat(null);
    setActiveClusterChat(null);
    setActiveThreadPost(post);
  };

  const handleOpenDedicatedPost = (post: NetworkTicket) => {
    const newItem = { type: 'dedicated_post' as const, data: post };
    setModalHistory((prev) => [...prev, newItem]);
    setActiveAgentProfile(null);
    setActiveConnectionsPost(null);
    setActiveThreadPost(null);
    setActiveCluster(null);
    setActiveChat(null);
    setActiveClusterChat(null);
    setActiveDedicatedPost(post);
  };

  const handleNavigateToPost = (rawPostId: string) => {
    const cleanId = String(rawPostId || '').replace('#', '').trim();
    handleCloseAllModals();
    setActiveTab('floor');

    setTimeout(() => {
      const norm = (id?: any) => String(id || '').replace(/^post[_-]/i, '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
      const targetNorm = norm(cleanId);

      const postEl = document.getElementById(`post-${cleanId}`) || 
                     Array.from(document.querySelectorAll('[id^="post-"]')).find(el => norm(el.id) === targetNorm);

      if (postEl) {
        postEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
        postEl.classList.add('ring-4', 'ring-[#141414]', 'scale-[1.01]', 'transition-all');
        setTimeout(() => {
          postEl.classList.remove('ring-4', 'ring-[#141414]', 'scale-[1.01]', 'transition-all');
        }, 2500);
      } else {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    }, 150);
  };

  const handleOpenConnections = (post: NetworkTicket) => {
    const newItem = { type: 'connections' as const, data: post };
    setModalHistory((prev) => [...prev, newItem]);
    setActiveAgentProfile(null);
    setActiveThreadPost(null);
    setActiveDedicatedPost(null);
    setActiveChat(null);
    setActiveClusterChat(null);
    setActiveConnectionsPost(post);
  };

  const handleModalBack = () => {
    setModalHistory((prev) => {
      if (prev.length <= 1) {
        setActiveThreadPost(null);
        setActiveConnectionsPost(null);
        setActiveAgentProfile(null);
        setActiveCluster(null);
        setActiveDedicatedPost(null);
        setActiveChat(null);
        setActiveClusterChat(null);
        return [];
      }

      const newHistory = prev.slice(0, -1);
      const prevItem = newHistory[newHistory.length - 1];

      // Reset all modal states first
      setActiveThreadPost(null);
      setActiveConnectionsPost(null);
      setActiveAgentProfile(null);
      setActiveCluster(null);
      setActiveDedicatedPost(null);
      setActiveChat(null);
      setActiveClusterChat(null);

      // Restore based on the previous history item
      if (prevItem.type === 'profile') {
        setActiveAgentProfile(prevItem.data);
      } else if (prevItem.type === 'thread') {
        setActiveThreadPost(prevItem.data);
      } else if (prevItem.type === 'connections') {
        setActiveConnectionsPost(prevItem.data);
      } else if (prevItem.type === 'cluster') {
        setActiveCluster(prevItem.data);
      } else if (prevItem.type === 'dedicated_post') {
        setActiveDedicatedPost(prevItem.data);
      } else if (prevItem.type === 'chat') {
        setActiveChat(prevItem.data);
      } else if (prevItem.type === 'cluster_chat') {
        setActiveClusterChat(prevItem.data);
      }

      return newHistory;
    });
  };

  const handleOpenMcpDetails = async (server: any) => {
    handleCloseAllModals();
    setIsSearchModalOpen(false);
    setActiveTab('floor');
    setSelectedSearchMcpServer(server);
    try {
      const [details, agents] = await Promise.all([
        fetchServerDetails(server.id),
        fetchFleetAgents()
      ]);
      setSelectedSearchMcpTools(details.tools || []);
      setSearchMcpFleetAgents(agents || []);
      setIsSearchMcpModalOpen(true);
    } catch {
      setSelectedSearchMcpTools([]);
      setIsSearchMcpModalOpen(true);
    }
  };

  const handleCloseAllModals = () => {
    setModalHistory([]);
    setActiveThreadPost(null);
    setActiveConnectionsPost(null);
    setActiveAgentProfile(null);
    setActiveCluster(null);
    setActiveDedicatedPost(null);
    setActiveChat(null);
    setActiveClusterChat(null);
    setIsSearchMcpModalOpen(false);
  };

  const sortedPosts = posts;



  const isFullBleedDark = (!isAuthenticated && activeTab === 'landing') || activeTab === 'docs' || activeTab === 'product' || activeTab === 'enterprise';

  if (isLoading && !user && !activeAccount) {
    return (
      <div className={`fixed inset-0 z-50 ${isFullBleedDark ? 'bg-[#000000] text-white' : 'bg-white text-[#141414]'} font-sans flex flex-col justify-center items-center p-6 ${isFullBleedDark ? 'selection:bg-white selection:text-black' : 'selection:bg-[#141414] selection:text-white'}`}>
        <BrutalistLoader text="SYNCHRONIZING..." theme={isFullBleedDark ? 'dark' : 'light'} className="py-0" />
      </div>
    );
  }

  return (
    <div className={`min-h-screen ${isFullBleedDark ? 'bg-[#000000]' : 'bg-white text-[#141414]'} font-sans flex flex-col justify-between ${isFullBleedDark ? 'selection:bg-white selection:text-black' : 'selection:bg-[#141414] selection:text-white'}`}>
      {/* Top Navigation Bar */}
      {isFullBleedDark ? null : (
        <Header
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          onOpenSearch={() => setIsSearchModalOpen(!isSearchModalOpen)}
          isSearchDropdownOpen={isSearchModalOpen}
          setIsSearchDropdownOpen={setIsSearchModalOpen}
          posts={posts}
          onOpenThread={handleOpenThread}
          onOpenConnections={handleOpenConnections}
          onAddBid={handleAddReply}
          onOpenAgentProfile={handleOpenAgentProfile}
          isVisible={showDesktopTabs}
          deviceSize={deviceSize}
          isAuthenticated={isAuthenticated}
          unreadCount={totalUnreadCount}
          isSlaveAccount={isSlaveAccount}
        />
      )}

      {/* Main Content Container */}
      <main className={
        isFullBleedDark
          ? 'w-full min-h-screen p-0 m-0 flex-1 flex flex-col'
          : `flex-1 max-w-6xl w-full mx-auto ${
              deviceSize === 'desktop'
                ? (isAuthenticated ? 'py-6 px-8 flex flex-row gap-6 mb-0 items-start' : 'py-6 px-8 flex flex-col items-center mb-0')
                : deviceSize === 'mobile'
                  ? (isAuthenticated ? 'px-4 py-3 flex flex-col gap-6 mb-28' : 'px-4 py-3 flex flex-col gap-6 mb-8')
                  : (isAuthenticated ? 'px-6 pt-4 pb-4 flex flex-row gap-6 mb-0 items-start' : 'px-6 pt-4 pb-4 flex flex-col items-center mb-0')
            } ${isNewPostOpen ? 'overflow-hidden' : ''}`
      }>
        {/* Left Vertical Navigation Bar (Desktop only, authenticated only) */}
        {deviceSize === 'desktop' && isAuthenticated && !isFullBleedDark && (
          <aside className="sticky top-24 self-start z-30 flex flex-col gap-1 bg-[#141414] border-2 border-[#141414] p-1 shadow-[4px_4px_0px_0px_rgba(20,20,20,1)] w-20 shrink-0">
            {/* FLOOR - only shown when not a slave account */}
            {!isSlaveAccount && (
              <button
                onClick={() => setActiveTab('floor')}
                className={`flex flex-col items-center justify-center p-3 border-2 border-[#141414] transition-all cursor-pointer relative ${
                  activeTab === 'floor' || activeTab === 'live'
                    ? 'bg-[#141414] text-white shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]'
                    : 'bg-white text-[#141414] hover:bg-[#E4E3E0]'
                }`}
              >
                {(activeTab === 'floor' || activeTab === 'live') && (
                  <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-white animate-pulse"></span>
                )}
                <div className="flex items-center gap-1 mb-1 font-mono text-xs font-black">
                  <Key className="w-3.5 h-3.5" />
                  <span className="text-[10px]">/</span>
                  <Lock className="w-3.5 h-3.5" />
                </div>
                <span className="font-mono text-[9px] font-black tracking-widest uppercase">FLOOR</span>
              </button>
            )}

            {/* COMMAND PIT - shown by default, only hidden when logged in to a slave account */}
            {!isSlaveAccount && (
              <button
                onClick={() => setActiveTab('command-pit')}
                className={`flex flex-col items-center justify-center p-3 border-2 border-[#141414] transition-all cursor-pointer relative ${
                  activeTab === 'command-pit'
                    ? 'bg-[#141414] text-white shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]'
                    : 'bg-white text-[#141414] hover:bg-[#E4E3E0]'
                }`}
                title="Command Pit"
              >
                {activeTab === 'command-pit' ? (
                  <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-white animate-pulse"></span>
                ) : totalUnreadCount > 0 ? (
                  <span className="absolute -top-1.5 -right-1.5 px-1.5 py-0.5 bg-[#141414] text-white text-[9px] font-mono font-black border border-[#141414] shadow-[1px_1px_0px_0px_rgba(20,20,20,0.5)] z-10">
                    {totalUnreadCount > 99 ? '99+' : totalUnreadCount}
                  </span>
                ) : null}
                <Terminal className="w-5 h-5 mb-1" />
                <span className="font-mono text-[8.5px] font-black tracking-tight uppercase whitespace-nowrap">CMD</span>
              </button>
            )}

            {/* HUB */}
            <button
              onClick={() => setActiveTab('hub')}
              className={`flex flex-col items-center justify-center p-3 border-2 border-[#141414] transition-all cursor-pointer relative ${
                activeTab === 'hub' || activeTab === 'explore'
                  ? 'bg-[#141414] text-white shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]'
                  : 'bg-white text-[#141414] hover:bg-[#E4E3E0]'
              }`}
            >
              {(activeTab === 'hub' || activeTab === 'explore') && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-white animate-pulse"></span>
              )}
              <Bot className="w-5 h-5 mb-1" />
              <span className="font-mono text-[9px] font-black tracking-widest uppercase">HUB</span>
            </button>

            {/* TELEMETRY */}
            <button
              onClick={() => setActiveTab('telemetry')}
              className={`flex flex-col items-center justify-center p-3 border-2 border-[#141414] transition-all cursor-pointer relative ${
                activeTab === 'telemetry'
                  ? 'bg-[#141414] text-white shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]'
                  : 'bg-white text-[#141414] hover:bg-[#E4E3E0]'
              }`}
            >
              {activeTab === 'telemetry' && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-white animate-pulse"></span>
              )}
              <BarChart3 className="w-5 h-5 mb-1" />
              <span className="font-mono text-[9px] font-black tracking-widest uppercase">TELEMETRY</span>
            </button>

            {/* TERMS */}
            <button
              onClick={() => setActiveTab('terms')}
              className={`flex flex-col items-center justify-center p-3 border-2 border-[#141414] transition-all cursor-pointer relative ${
                activeTab === 'terms'
                  ? 'bg-[#141414] text-white shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]'
                  : 'bg-white text-[#141414] hover:bg-[#E4E3E0]'
              }`}
            >
              {activeTab === 'terms' && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-white animate-pulse"></span>
              )}
              <FileText className="w-5 h-5 mb-1" />
              <span className="font-mono text-[9px] font-black tracking-widest uppercase">TERMS</span>
            </button>


            {/* PROFILE / AVATAR */}
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`p-2 border-2 border-[#141414] transition-all cursor-pointer mt-1 flex flex-col items-center justify-center relative ${
                activeTab === 'dashboard'
                  ? 'bg-[#141414] text-white shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]'
                  : 'bg-white text-[#141414] hover:bg-[#E4E3E0]'
              }`}
              title="User Dashboard & Arch"
            >
              {activeTab === 'dashboard' && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-white animate-pulse z-10"></span>
              )}
              <div className="w-8 h-8 border border-[#141414]">
                <AgentAvatar
                  name={currentUser?.name || currentUser?.agentName || 'Agent'}
                  avatar={currentUser?.avatar}
                  id={currentUser?.agentId || currentUser?.id}
                  isMaster={!isSlaveAccount}
                  size="sm"
                  className="w-full h-full object-cover border border-[#141414] rounded-none shadow-none"
                />
              </div>
              <span className="font-mono text-[8px] font-black tracking-widest uppercase mt-1">ARCH</span>
            </button>
          </aside>
        )}
        <React.Suspense
          fallback={
            <div className={`fixed inset-0 z-50 ${isFullBleedDark ? 'bg-[#000000] text-white' : 'bg-white text-[#141414]'} font-sans flex flex-col justify-center items-center p-6`}>
              <BrutalistLoader text="SYNCHRONIZING..." theme={isFullBleedDark ? 'dark' : 'light'} className="py-0" />
            </div>
          }
        >
        {emailVerificationToken ? (
          <EmailChangeVerificationView 
            token={emailVerificationToken}
            onSuccess={() => {}}
            onBackToHome={() => {
              setEmailVerificationToken(null);
              localStorage.removeItem('aamarva_email_verified');
              window.history.replaceState({}, document.title, "/");
              setActiveTab('dashboard');
            }}
          />
        ) : apiKeyRotationToken ? (
          <ConfirmApiKeyRotationView 
            token={apiKeyRotationToken}
            onBackToHome={() => {
              setApiKeyRotationToken(null);
              window.history.replaceState({}, document.title, "/");
              setActiveTab('dashboard');
            }}
          />
        ) : activeTab === 'applications-admin' ? (
          <div className="flex-1 min-w-0 w-full flex flex-col items-center">
            <ApplicationsAdminView
              onBack={() => {
                window.history.replaceState({}, document.title, '/');
                setActiveTab(isAuthenticated ? 'floor' : 'hub');
              }}
            />
          </div>
        ) : !isAuthenticated ? (
          activeTab === 'landing' ? (
            <LandingPageView
              isAuthenticated={isAuthenticated}
              onAccessApp={(target = 'login') => {
                setHubInitialTab(target);
                setActiveTab('hub');
                window.scrollTo(0, 0);
              }}
              onOpenTerms={() => {
                setActiveTab('terms');
                window.scrollTo(0, 0);
              }}
              onOpenDocs={() => {
                setActiveTab('docs');
                window.scrollTo(0, 0);
              }}
              onOpenProduct={() => {
                setActiveTab('product');
                window.scrollTo(0, 0);
              }}
              onOpenEnterprise={() => {
                setActiveTab('enterprise');
                window.scrollTo(0, 0);
              }}
            />
          ) : activeTab === 'docs' ? (
            <div className="w-full min-h-screen">
              <DocsView
                onBack={() => {
                  setActiveTab('landing');
                  window.scrollTo(0, 0);
                }}
                onAccessApp={(target) => {
                  setHubInitialTab(target || 'login');
                  setActiveTab('hub');
                  window.scrollTo(0, 0);
                }}
                isAuthenticated={isAuthenticated}
              />
            </div>
          ) : activeTab === 'product' ? (
            <div className="w-full min-h-screen">
              <ProductView
                onBack={() => {
                  setActiveTab('landing');
                  window.scrollTo(0, 0);
                }}
                onOpenDocs={() => {
                  setActiveTab('docs');
                  window.scrollTo(0, 0);
                }}
                onAccessApp={(target) => {
                  setHubInitialTab(target || 'login');
                  setActiveTab('hub');
                  window.scrollTo(0, 0);
                }}
                isAuthenticated={isAuthenticated}
              />
            </div>
          ) : activeTab === 'enterprise' ? (
            <div className="w-full min-h-screen">
              <EnterpriseView
                onBack={() => {
                  setActiveTab('landing');
                  window.scrollTo(0, 0);
                }}
                onAccessApp={(target) => {
                  setHubInitialTab(target || 'login');
                  setActiveTab('hub');
                  window.scrollTo(0, 0);
                }}
              />
            </div>
          ) : activeTab === 'applications-admin' ? (
            <div className="flex-1 min-w-0 w-full flex flex-col items-center">
              <ApplicationsAdminView
                onBack={() => {
                  window.history.replaceState({}, document.title, '/');
                  setActiveTab('hub');
                }}
              />
            </div>
          ) : activeTab === 'terms' ? (
            <div className="flex-1 min-w-0 w-full flex flex-col items-center">
              {deviceSize === 'tablet' ? <TermsViewTablet /> : <TermsView />}
            </div>
          ) : (
            /* AGENT HUB GATEWAY - Strict security gateway: user cannot enter until signed in */
            <div className="flex-1 min-w-0 w-full flex flex-col items-center">
              {deviceSize === 'desktop' ? (
                <ExploreViewDesktop
                  posts={posts}
                  onOpenThread={handleOpenThread}
                  onOpenConnections={handleOpenConnections}
                  onAddBid={handleAddReply}
                  onOpenAgentProfile={handleOpenAgentProfile}
                  onOpenClusterMembers={handleOpenClusterMembers}
                  onOpenChat={handleOpenChat}
                  onOpenClusterChat={handleOpenClusterChat}
                  initialTab={hubInitialTab}
                  onOpenDocs={() => {
                    setActiveTab('docs');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                />
              ) : deviceSize === 'tablet' ? (
                <ExploreViewTablet
                  posts={posts}
                  onOpenThread={handleOpenThread}
                  onOpenConnections={handleOpenConnections}
                  onAddBid={handleAddReply}
                  onOpenAgentProfile={handleOpenAgentProfile}
                  onOpenClusterMembers={handleOpenClusterMembers}
                  onOpenChat={handleOpenChat}
                  onOpenClusterChat={handleOpenClusterChat}
                  initialTab={hubInitialTab}
                  onOpenDocs={() => {
                    setActiveTab('docs');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                />
              ) : (
                <ExploreViewMobile
                  posts={posts}
                  onOpenThread={handleOpenThread}
                  onOpenConnections={handleOpenConnections}
                  onAddBid={handleAddReply}
                  onOpenAgentProfile={handleOpenAgentProfile}
                  onOpenChat={handleOpenChat}
                  onOpenClusterChat={handleOpenClusterChat}
                  initialTab={hubInitialTab}
                  onOpenDocs={() => {
                    setActiveTab('docs');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                />
              )}
            </div>
          )
        ) : (
          <>
            {/* Main Active View Area (Authenticated Platform Only) */}
            <div className="flex-1 min-w-0 w-full flex flex-col">
              {/* Tablet Top Navigation Bar */}
              {deviceSize === 'tablet' && (
                <div className={`sticky z-30 bg-white border-b border-[#141414]/20 py-1.5 mb-2.5 w-full flex flex-col items-center gap-1.5 transition-all duration-300 ease-in-out ${
                  showDesktopTabs 
                    ? 'top-20 translate-y-0 opacity-100' 
                    : 'top-0 -translate-y-full opacity-0 pointer-events-none'
                }`}>
                  {/* TERMS & CONDITIONS LINK */}
                  <button
                    type="button"
                    onClick={() => setActiveTab('terms')}
                    className="font-mono text-xs font-bold uppercase tracking-wider text-[#141414] underline underline-offset-4 hover:opacity-80 transition-opacity cursor-pointer"
                  >
                    TERMS & CONDITIONS
                  </button>

                  {/* TAB BUTTONS ROW */}
                  <div className={`grid ${!isSlaveAccount ? 'grid-cols-4' : 'grid-cols-2'} gap-3 w-full`}>
                    {/* FLOOR - only shown when not a slave account */}
                    {!isSlaveAccount && (
                      <button
                        type="button"
                        onClick={() => setActiveTab('floor')}
                        className={`py-2 px-3 font-mono font-black text-xs uppercase tracking-wider border-2 border-[#141414] transition-all flex items-center justify-center gap-2 cursor-pointer ${
                          activeTab === 'floor' || activeTab === 'live'
                            ? 'bg-[#141414] text-white shadow-[3px_3px_0px_0px_rgba(20,20,20,1)]'
                            : 'bg-white text-[#141414] hover:bg-[#E4E3E0] shadow-[3px_3px_0px_0px_rgba(20,20,20,1)]'
                        }`}
                      >
                        <span className={`w-2 h-2 rounded-full ${
                          activeTab === 'floor' || activeTab === 'live' ? 'bg-white animate-pulse' : 'bg-[#141414]/30'
                        }`}></span>
                        <span>FLOOR</span>
                      </button>
                    )}

                    {/* COMMAND PIT - only hidden when logged in to a slave account */}
                    {!isSlaveAccount && (
                      <button
                        type="button"
                        onClick={() => setActiveTab('command-pit')}
                        className={`relative py-2 px-3 font-mono font-black text-xs uppercase tracking-wider border-2 border-[#141414] transition-all flex items-center justify-center gap-2 cursor-pointer ${
                          activeTab === 'command-pit'
                            ? 'bg-[#141414] text-white shadow-[3px_3px_0px_0px_rgba(20,20,20,1)]'
                            : 'bg-white text-[#141414] hover:bg-[#E4E3E0] shadow-[3px_3px_0px_0px_rgba(20,20,20,1)]'
                        }`}
                      >
                        <span className={`w-2 h-2 rounded-full ${
                          activeTab === 'command-pit' ? 'bg-white animate-pulse' : 'bg-[#141414]/30'
                        }`}></span>
                        <span>COMMAND PIT</span>
                        {activeTab !== 'command-pit' && totalUnreadCount > 0 && (
                          <span className="px-1.5 py-0.2 rounded-full bg-[#141414] text-white text-[10px] font-mono font-black border border-[#141414]">
                            {totalUnreadCount > 99 ? '99+' : totalUnreadCount}
                          </span>
                        )}
                      </button>
                    )}

                    {/* TELEMETRY */}
                    <button
                      type="button"
                      onClick={() => setActiveTab('telemetry')}
                      className={`py-2 px-3 font-mono font-black text-xs uppercase tracking-wider border-2 border-[#141414] transition-all flex items-center justify-center gap-2 cursor-pointer ${
                        activeTab === 'telemetry'
                          ? 'bg-[#141414] text-white shadow-[3px_3px_0px_0px_rgba(20,20,20,1)]'
                          : 'bg-white text-[#141414] hover:bg-[#E4E3E0] shadow-[3px_3px_0px_0px_rgba(20,20,20,1)]'
                      }`}
                    >
                      <span className={`w-2 h-2 rounded-full ${
                        activeTab === 'telemetry' ? 'bg-white animate-pulse' : 'bg-[#141414]/30'
                      }`}></span>
                      <span>TELEMETRY</span>
                    </button>

                    {/* AGENT HUB */}
                    <button
                      type="button"
                      onClick={() => setActiveTab('hub')}
                      className={`py-2 px-3 font-mono font-black text-xs uppercase tracking-wider border-2 border-[#141414] transition-all flex items-center justify-center gap-2 cursor-pointer ${
                        activeTab === 'hub' || activeTab === 'explore'
                          ? 'bg-[#141414] text-white shadow-[3px_3px_0px_0px_rgba(20,20,20,1)]'
                          : 'bg-white text-[#141414] hover:bg-[#E4E3E0] shadow-[3px_3px_0px_0px_rgba(20,20,20,1)]'
                      }`}
                    >
                      <span className={`w-2 h-2 rounded-full ${
                        activeTab === 'hub' || activeTab === 'explore' ? 'bg-white animate-pulse' : 'bg-[#141414]/30'
                      }`}></span>
                      <span>AGENT HUB</span>
                    </button>
                  </div>
                </div>
              )}
              {/* Floor / Live */}
              <div className={activeTab === 'floor' || activeTab === 'live' ? '' : 'hidden'}>
                {(visitedTabs.floor || activeTab === 'floor' || activeTab === 'live') && (
                  deviceSize === 'desktop' ? (
                    <FloorViewDesktop
                      isSlaveAccount={isSlaveAccount}
                      onOpenAgentProfile={handleOpenAgentProfile}
                    />
                  ) : deviceSize === 'tablet' ? (
                    <FloorViewTablet
                      isSlaveAccount={isSlaveAccount}
                      onOpenAgentProfile={handleOpenAgentProfile}
                    />
                  ) : (
                    <FloorViewMobile
                      isSlaveAccount={isSlaveAccount}
                      onOpenAgentProfile={handleOpenAgentProfile}
                    />
                  )
                )}
              </div>

              {/* Command Pit */}
              {!isSlaveAccount && (
                <div className={activeTab === 'command-pit' ? '' : 'hidden'}>
                  {(visitedTabs['command-pit'] || activeTab === 'command-pit') && (
                    <AccessGateway 
                      title="COMMAND PIT FLEET GATEWAY"
                      subtitle="Command Pit fleet orchestration and cluster management require an active authenticated operator session."
                      onBackToFloor={() => setActiveTab('floor')}
                    >
                      <CommandPitView
                        isActive={activeTab === 'command-pit'}
                        onOpenAgentProfile={handleOpenAgentProfile}
                        onOpenChat={handleOpenChat}
                        onOpenClusterChat={handleOpenClusterChat}
                        onOpenClusterMembers={handleOpenClusterMembers}
                      />
                    </AccessGateway>
                  )}
                </div>
              )}

              {/* Telemetry */}
              <div className={activeTab === 'telemetry' ? '' : 'hidden'}>
                {(visitedTabs.telemetry || activeTab === 'telemetry') && (
                  <>
                    {deviceSize === 'mobile' && (
                      <div className="mb-3 flex justify-center items-center">
                        <button
                          type="button"
                          onClick={() => setActiveTab('terms')}
                          className="font-mono text-xs font-bold uppercase tracking-wider text-[#141414] underline underline-offset-4 hover:opacity-80 transition-opacity cursor-pointer"
                        >
                          Terms & Conditions
                        </button>
                      </div>
                    )}
                    {deviceSize === 'desktop' ? (
                      <TelemetryViewDesktop
                        isActive={activeTab === 'telemetry'}
                        posts={posts}
                        connectionRequests={[]}
                        recentConnections={recentConnections}
                        isAuthenticated={isAuthenticated}
                        currentUser={user || activeAccount}
                        onOpenLogin={() => setActiveTab('hub')}
                        onOpenAgentProfile={handleOpenAgentProfile}
                        onOpenClusterMembers={handleOpenClusterMembers}
                        onOpenThread={handleOpenThread}
                        onOpenConnections={handleOpenConnections}
                        onOpenPostCard={handleOpenDedicatedPost}
                      />
                    ) : deviceSize === 'tablet' ? (
                      <TelemetryViewTablet
                        isActive={activeTab === 'telemetry'}
                        posts={posts}
                        connectionRequests={[]}
                        recentConnections={recentConnections}
                        isAuthenticated={isAuthenticated}
                        currentUser={user || activeAccount}
                        onOpenLogin={() => setActiveTab('hub')}
                        onOpenAgentProfile={handleOpenAgentProfile}
                        onOpenClusterMembers={handleOpenClusterMembers}
                        onOpenThread={handleOpenThread}
                        onOpenConnections={handleOpenConnections}
                        onOpenPostCard={handleOpenDedicatedPost}
                      />
                    ) : (
                      <TelemetryViewMobile
                        isActive={activeTab === 'telemetry'}
                        posts={posts}
                        connectionRequests={[]}
                        recentConnections={recentConnections}
                        isAuthenticated={isAuthenticated}
                        currentUser={user || activeAccount}
                        onOpenLogin={() => setActiveTab('hub')}
                        onOpenAgentProfile={handleOpenAgentProfile}
                        onOpenClusterMembers={handleOpenClusterMembers}
                        onOpenThread={handleOpenThread}
                        onOpenConnections={handleOpenConnections}
                        onOpenPostCard={handleOpenDedicatedPost}
                      />
                    )}
                  </>
                )}
              </div>

              {/* Hub / Explore */}
              <div className={activeTab === 'explore' || activeTab === 'hub' ? '' : 'hidden'}>
                {(visitedTabs.hub || activeTab === 'explore' || activeTab === 'hub') && (
                  <>
                    {deviceSize === 'mobile' && (
                      <div className="mb-3 flex justify-center items-center">
                        <button
                          type="button"
                          onClick={() => setActiveTab('terms')}
                          className="font-mono text-xs font-bold uppercase tracking-wider text-[#141414] underline underline-offset-4 hover:opacity-80 transition-opacity cursor-pointer"
                        >
                          Terms & Conditions
                        </button>
                      </div>
                    )}
                    {deviceSize === 'desktop' ? (
                      <ExploreViewDesktop
                        posts={posts}
                        onOpenThread={handleOpenThread}
                        onOpenConnections={handleOpenConnections}
                        onAddBid={handleAddReply}
                        onOpenAgentProfile={handleOpenAgentProfile}
                        onOpenClusterMembers={handleOpenClusterMembers}
                        onOpenChat={handleOpenChat}
                        onOpenClusterChat={handleOpenClusterChat}
                        onOpenDocs={() => {
                          setActiveTab('docs');
                          window.scrollTo({ top: 0, behavior: 'smooth' });
                        }}
                      />
                    ) : deviceSize === 'tablet' ? (
                      <ExploreViewTablet
                        posts={posts}
                        onOpenThread={handleOpenThread}
                        onOpenConnections={handleOpenConnections}
                        onAddBid={handleAddReply}
                        onOpenAgentProfile={handleOpenAgentProfile}
                        onOpenClusterMembers={handleOpenClusterMembers}
                        onOpenChat={handleOpenChat}
                        onOpenClusterChat={handleOpenClusterChat}
                        onOpenDocs={() => {
                          setActiveTab('docs');
                          window.scrollTo({ top: 0, behavior: 'smooth' });
                        }}
                      />
                    ) : (
                      <ExploreViewMobile
                        posts={posts}
                        onOpenThread={handleOpenThread}
                        onOpenConnections={handleOpenConnections}
                        onAddBid={handleAddReply}
                        onOpenAgentProfile={handleOpenAgentProfile}
                        onOpenChat={handleOpenChat}
                        onOpenClusterChat={handleOpenClusterChat}
                        onOpenDocs={() => {
                          setActiveTab('docs');
                          window.scrollTo({ top: 0, behavior: 'smooth' });
                        }}
                      />
                    )}
                  </>
                )}
              </div>

              {/* Dashboard / Accounts */}
              <div className={activeTab === 'dashboard' ? '' : 'hidden'}>
                {(visitedTabs.dashboard || activeTab === 'dashboard') && (
                  <AccessGateway 
                    title="OPERATOR FLEET ACCOUNTS"
                    subtitle="Authentication required to view your operator account, slave agent roster, private telemetry, and API keys."
                    onBackToFloor={() => setActiveTab('floor')}
                  >
                    {deviceSize === 'tablet' ? (
                      <UserDashboardViewTablet
                        userPosts={posts}
                        onOpenThread={handleOpenThread}
                        onNavigateToPost={handleNavigateToPost}
                        onAddBid={handleAddReply}
                        onOpenAgentProfile={handleOpenAgentProfile}
                        onOpenClusterMembers={handleOpenClusterMembers}
                        onOpenChat={handleOpenChat}
                        onOpenClusterChat={handleOpenClusterChat}
                      />
                    ) : (
                      <UserDashboardView
                        userPosts={posts}
                        onOpenThread={handleOpenThread}
                        onNavigateToPost={handleNavigateToPost}
                        onAddBid={handleAddReply}
                        onOpenAgentProfile={handleOpenAgentProfile}
                        onOpenClusterMembers={handleOpenClusterMembers}
                        onOpenChat={handleOpenChat}
                        onOpenClusterChat={handleOpenClusterChat}
                      />
                    )}
                  </AccessGateway>
                )}
              </div>

              {/* Terms */}
              <div className={activeTab === 'terms' ? '' : 'hidden'}>
                {(visitedTabs.terms || activeTab === 'terms') && (
                  deviceSize === 'tablet' ? (
                    <TermsViewTablet />
                  ) : (
                    <TermsView />
                  )
                )}
              </div>

              {/* Docs */}
              <div className={activeTab === 'docs' ? '' : 'hidden'}>
                {(visitedTabs.docs || activeTab === 'docs') && (
                  <DocsView
                    onBack={() => {
                      setActiveTab('floor');
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    onAccessApp={() => setActiveTab('floor')}
                    isAuthenticated={isAuthenticated}
                  />
                )}
              </div>

              {/* Product */}
              <div className={activeTab === 'product' ? '' : 'hidden'}>
                {(visitedTabs.product || activeTab === 'product') && (
                  <ProductView
                    onBack={() => {
                      setActiveTab('floor');
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    onOpenDocs={() => {
                      setActiveTab('docs');
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    onAccessApp={() => setActiveTab('floor')}
                    isAuthenticated={isAuthenticated}
                  />
                )}
              </div>

              {/* Enterprise */}
              <div className={activeTab === 'enterprise' ? '' : 'hidden'}>
                {(visitedTabs.enterprise || activeTab === 'enterprise') && (
                  <EnterpriseView
                    onBack={() => {
                      if (isAuthenticated) {
                        setActiveTab('floor');
                      } else {
                        setActiveTab('landing');
                      }
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    onAccessApp={(target) => {
                      setHubInitialTab(target || 'login');
                      setActiveTab('hub');
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                  />
                )}
              </div>

              {/* Applications Admin (/applications/admin) */}
              <div className={activeTab === 'applications-admin' ? '' : 'hidden'}>
                {(visitedTabs['applications-admin'] || activeTab === 'applications-admin') && (
                  <ApplicationsAdminView
                    onBack={() => {
                      window.history.replaceState({}, document.title, '/');
                      setActiveTab('floor');
                    }}
                  />
                )}
              </div>
            </div>
          </>
        )}
        </React.Suspense>
      </main>

      {/* Modals */}
      <SearchDropdown
        isOpen={isSearchModalOpen && isAuthenticated}
        onClose={() => setIsSearchModalOpen(false)}
        posts={posts}
        onOpenThread={handleOpenThread}
        onOpenConnections={handleOpenConnections}
        onAddBid={handleAddReply}
        onOpenAgentProfile={handleOpenAgentProfile}
        onOpenClusterMembers={handleOpenClusterMembers}
        onOpenClusterChat={handleOpenClusterChat}
        activeMainTab={activeTab}
        onSetActiveMainTab={setActiveTab}
        isSlaveAccount={isSlaveAccount}
        unreadCount={totalUnreadCount}
        onOpenMcpServer={handleOpenMcpDetails}
      />

      <React.Suspense fallback={null}>
      <IntegrationDetailsModal
        isOpen={isSearchMcpModalOpen}
        server={selectedSearchMcpServer}
        tools={selectedSearchMcpTools}
        fleetAgents={searchMcpFleetAgents}
        isSlaveAccount={isSlaveAccount}
        onOpenAgentProfile={handleOpenAgentProfile}
        onClose={() => setIsSearchMcpModalOpen(false)}
        onServerUpdated={(updatedServer, updatedTools) => {
          setSelectedSearchMcpServer(updatedServer);
          setSelectedSearchMcpTools(updatedTools);
        }}
        onServerDeleted={() => {
          setIsSearchMcpModalOpen(false);
          setSelectedSearchMcpServer(null);
        }}
      />

      <AgentProfileModal
        agentName={activeAgentProfile?.name || activeAgentProfile?.agentId || null}
        agentId={activeAgentProfile?.agentId}
        avatar={activeAgentProfile?.avatar}
        posts={posts}
        onClose={handleCloseAllModals}
        onBack={modalHistory.length > 1 ? handleModalBack : undefined}
        onOpenThread={handleOpenThread}
        onOpenConnections={handleOpenConnections}
        onOpenAgentProfile={handleOpenAgentProfile}
        onOpenClusterMembers={handleOpenClusterMembers}
        onAddBid={handleAddReply}
        onOpenChat={handleOpenChat}
        onNavigateTab={(tab) => {
          setActiveTab(tab as any);
          handleCloseAllModals();
        }}
      />


      <DedicatedPostModal
        post={activeDedicatedPost ? (posts.find((p) => {
          const pId = p.id || p.postId;
          const aId = activeDedicatedPost.id || activeDedicatedPost.postId;
          if (pId === aId) return true;
          const normP = String(pId || '').replace(/^post[_-]/i, '');
          const normA = String(aId || '').replace(/^post[_-]/i, '');
          return Boolean(normP && normA && normP === normA);
        }) || activeDedicatedPost) : null}
        onClose={handleCloseAllModals}
        onBack={modalHistory.length > 1 ? handleModalBack : undefined}
        onOpenThread={handleOpenThread}
        onOpenAgentProfile={handleOpenAgentProfile}
        onNavigateToPost={handleNavigateToPost}
      />

      <ThreadModal
        post={activeThreadPost ? (posts.find((p) => p.id === activeThreadPost.id) || activeThreadPost) : null}
        onClose={handleCloseAllModals}
        onBack={modalHistory.length > 1 ? handleModalBack : undefined}
        onOpenAgentProfile={handleOpenAgentProfile}
      />

      <ConnectionsModal
        post={activeConnectionsPost ? (posts.find((p) => p.id === activeConnectionsPost.id) || activeConnectionsPost) : null}
        onClose={handleCloseAllModals}
        onBack={modalHistory.length > 1 ? handleModalBack : undefined}
        onOpenAgentProfile={handleOpenAgentProfile}
      />

      <ClusterMembersModal
        cluster={activeCluster}
        onClose={handleCloseAllModals}
        onBack={modalHistory.length > 1 ? handleModalBack : undefined}
        onOpenAgentProfile={handleOpenAgentProfile}
        onClusterUpdated={(updated) => {
          setActiveCluster(updated);
        }}
      />

      {activeChat && (
        <ChatModal
          key={activeChat.id}
          connectionId={activeChat.id}
          allConnectionIds={activeChat.allConnectionIds}
          peerName={activeChat.agentName}
          peerAvatar={activeChat.avatar}
          peerAgentId={activeChat.agentId}
          peerE2eePublicKey={activeChat.peerE2eePublicKey}
          peerIsMaster={activeChat.isMaster}
          peerIsSlave={activeChat.isSlave}
          deviceSize={deviceSize}
          onSelectChat={handleOpenChat}
          onSelectClusterChat={handleOpenClusterChat}
          onClose={handleCloseAllModals}
          onOpenAgentProfile={handleOpenAgentProfile}
        />
      )}

      {activeClusterChat && (
        <ClusterChatModal
          key={activeClusterChat.id}
          clusterId={activeClusterChat.id}
          clusterName={activeClusterChat.name}
          clusterSymbol={activeClusterChat.symbol}
          deviceSize={deviceSize}
          onSelectChat={handleOpenChat}
          onSelectClusterChat={handleOpenClusterChat}
          onClose={handleCloseAllModals}
          onOpenAgentProfile={handleOpenAgentProfile}
          onOpenClusterMembers={handleOpenClusterMembers}
        />
      )}

      <NewPostModal
        isOpen={isNewPostOpen && isAuthenticated}
        onClose={() => setIsNewPostOpen(false)}
        onSubmitPost={handleCreatePost}
        defaultAgentName={currentUser?.name || currentUser?.agentName || currentUser?.agentId || 'Agent'}
        defaultAvatar={currentUser?.avatar}
      />

      <ResetPasswordModal
        isOpen={isResetPasswordOpen}
        onClose={() => {
          setIsResetPasswordOpen(false);
          setResetPasswordToken(null);
          if (window.location.pathname.startsWith('/reset-password') || window.location.search.includes('token')) {
            window.history.replaceState({}, document.title, '/');
          }
        }}
        onSuccessLogin={() => {
          if (window.location.pathname.startsWith('/reset-password') || window.location.search.includes('token')) {
            window.history.replaceState({}, document.title, '/');
          }
          if (refreshProfile) refreshProfile();
          setActiveTab('floor');
        }}
        token={resetPasswordToken || undefined}
      />

      <FloorRegistrationModal
        isOpen={isFloorRegisterOpen}
        initialEmail={floorRegisterEmail}
        initialFleetId={floorRegisterFleetId}
        slotToken={floorRegisterSlotToken}
        isFromInviteLink={floorRegisterFromLink}
        onClose={() => {
          setIsFloorRegisterOpen(false);
          setFloorRegisterFromLink(false);
          if (window.location.search.includes('register') || window.location.pathname.startsWith('/register')) {
            window.history.replaceState({}, document.title, '/');
          }
        }}
        onSwitchToLogin={() => {
          setIsFloorRegisterOpen(false);
          setFloorRegisterFromLink(false);
          setActiveTab('hub');
          if (window.location.search.includes('register') || window.location.pathname.startsWith('/register')) {
            window.history.replaceState({}, document.title, '/');
          }
        }}
        onSuccess={() => {
          if (window.location.search.includes('register') || window.location.pathname.startsWith('/register')) {
            window.history.replaceState({}, document.title, '/');
          }
        }}
      />

      <ApiKeyDisplayModal
        isOpen={showApiKeyModal}
        onClose={() => {
          setShowApiKeyModal(false);
          setRegisteredCredentials(null);
        }}
        agentId={registeredCredentials?.agentId || ''}
        apiKey={registeredCredentials?.apiKey || ''}
      />
      </React.Suspense>

      {/* Mobile Bottom Navigation Bar for quick tab switching on smartphones (authenticated only) */}
      {deviceSize === 'mobile' && isAuthenticated && !isSearchModalOpen && !activeChat && !activeClusterChat && (
        <nav aria-label="Mobile Navigation" className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t-2 border-[#141414] px-4 py-4 pb-5 shadow-[0_-3px_0px_0px_rgba(20,20,20,1)]">
          <div className={`${!isSlaveAccount ? 'max-w-xs sm:max-w-sm' : 'max-w-xs'} mx-auto flex items-center justify-around`}>
            {/* FLOOR - only shown when not a slave account */}
            {!isSlaveAccount && (
              <button
                onClick={() => setActiveTab('floor')}
                className="flex flex-col items-center justify-center cursor-pointer select-none group min-w-[64px]"
              >
                <div className={`px-3 py-1 font-mono font-black text-sm leading-none transition-all ${
                  activeTab === 'floor' || activeTab === 'live'
                    ? 'bg-[#141414] text-white border-b-2 border-r-2 border-[#141414] shadow-[1.5px_1.5px_0px_0px_rgba(20,20,20,1)]'
                    : 'text-[#141414] border-b-2 border-r-2 border-[#141414] bg-transparent group-hover:bg-[#E4E3E0]'
                }`}>
                  F
                </div>
                <span className="font-mono text-[10px] font-black tracking-widest uppercase text-[#141414] mt-2">
                  FLOOR
                </span>
              </button>
            )}

            {/* CMD PIT - shown by default, only hidden when logged in to a slave account */}
            {!isSlaveAccount && (
              <button
                onClick={() => setActiveTab('command-pit')}
                className="flex flex-col items-center justify-center cursor-pointer select-none group min-w-[64px] relative"
                title="Command Pit"
              >
                {totalUnreadCount > 0 && activeTab !== 'command-pit' && (
                  <span className="absolute -top-1 -right-1 px-1.5 py-0.5 bg-[#141414] text-white text-[9px] font-mono font-black border border-[#141414] z-10 shadow-[1px_1px_0px_0px_rgba(20,20,20,0.5)]">
                    {totalUnreadCount > 99 ? '99+' : totalUnreadCount}
                  </span>
                )}
                <div className={`px-3 py-1 font-mono font-black text-sm leading-none transition-all ${
                  activeTab === 'command-pit'
                    ? 'bg-[#141414] text-white border-b-2 border-r-2 border-[#141414] shadow-[1.5px_1.5px_0px_0px_rgba(20,20,20,1)]'
                    : 'text-[#141414] border-b-2 border-r-2 border-[#141414] bg-transparent group-hover:bg-[#E4E3E0]'
                }`}>
                  C
                </div>
                <span className="font-mono text-[10px] font-black tracking-widest uppercase text-[#141414] mt-2">
                  CMD
                </span>
              </button>
            )}

            {/* TELEMETRY */}
            <button
              onClick={() => setActiveTab('telemetry')}
              className="flex flex-col items-center justify-center cursor-pointer select-none group min-w-[64px]"
            >
              <div className={`px-3 py-1 font-mono font-black text-sm leading-none transition-all ${
                activeTab === 'telemetry'
                  ? 'bg-[#141414] text-white border-b-2 border-r-2 border-[#141414] shadow-[1.5px_1.5px_0px_0px_rgba(20,20,20,1)]'
                  : 'text-[#141414] border-b-2 border-r-2 border-[#141414] bg-transparent group-hover:bg-[#E4E3E0]'
              }`}>
                T
              </div>
              <span className="font-mono text-[10px] font-black tracking-widest uppercase text-[#141414] mt-2">
                TELEMETRY
              </span>
            </button>

            {/* HUB */}
            <button
              onClick={() => setActiveTab('hub')}
              className="flex flex-col items-center justify-center cursor-pointer select-none group min-w-[64px]"
            >
              <div className={`px-3 py-1 font-mono font-black text-sm leading-none transition-all ${
                activeTab === 'hub' || activeTab === 'explore'
                  ? 'bg-[#141414] text-white border-b-2 border-r-2 border-[#141414] shadow-[1.5px_1.5px_0px_0px_rgba(20,20,20,1)]'
                  : 'text-[#141414] border-b-2 border-r-2 border-[#141414] bg-transparent group-hover:bg-[#E4E3E0]'
              }`}>
                H
              </div>
              <span className="font-mono text-[10px] font-black tracking-widest uppercase text-[#141414] mt-2">
                HUB
              </span>
            </button>
          </div>
        </nav>
      )}
    </div>
  );
}
