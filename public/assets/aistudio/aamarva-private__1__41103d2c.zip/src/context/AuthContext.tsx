import React, { createContext, useContext, useState, useEffect, useRef, useCallback } from 'react';
import { WebAuthnEnableModal } from '../components/WebAuthnEnableModal';
import { WebAuthnVerifyModal } from '../components/WebAuthnVerifyModal';
import {
  UserProfile,
  registerUserApi,
  loginUserApi,
  loginAgentApi,
  logoutUserApi,
  fetchCurrentProfileApi,
  setAccessToken,
  getAccessToken,
  getCurrentSessionAuthType,
  deleteAccountApi,
  updateProfileApi,
  apiFetch,
  isSlaveAccount,
  clearInFlightRequests,
} from '../services/authApi';
import {
  clearAllAppCaches,
  getAccountKey,
  getQueryCache,
  setQueryCache,
  setPreparedAccountProfile,
  getPreparedAccountProfile,
  seedFleetAccountsCache,
  buildCommandPitFleetList,
} from '../lib/appStateCache';
import { clearCachedWatchtowerEvents } from '../lib/watchtowerActivityDeduplication';
import { prefetchPeerKeys, clearPeerKeyCache } from '../lib/e2eePrefetch';
import { 
  generateAgentCryptoIdentity, 
  deriveAgentCryptoIdentity, 
  rotateAgentCryptoIdentity, 
  getLocalKeyPair, 
  getAllLocalEpochKeys,
  saveLocalKeyPair,
  createEncryptedRecoveryVault,
  restoreFromEncryptedRecoveryVault,
  clearTransientJwkKeys,
  normalizeAgentId,
  StoredAgentKeyEntry,
  bootstrapAgentIdentity,
  constructIdentityRegistrationPayload,
  stashEncryptedRecoveryVault,
  getStashedEncryptedRecoveryVault,
  clearStashedEncryptedRecoveryVault,
} from '../lib/e2ee';

export type E2EEStatus = 'initializing' | 'ready' | 'recovery_required' | 'recovery_in_progress' | 'failed';

interface AuthContextType {
  user: UserProfile | null;
  activeAccount: UserProfile | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  sessionAuthType: 'human' | 'agent';
  e2eeStatus: E2EEStatus;
  isE2EEReady: boolean;
  ensureE2EEKeys: (agentId: string, forceRotate?: boolean, credential?: string) => Promise<boolean>;
  userPassword?: string | null;
  updatePassword?: (pwd: string) => void;
  login: (agentId: string, credential: string) => Promise<void>;
  loginAgent: (agentId: string, apiKey: string) => Promise<void>;
  register: (email: string, password: string, agentName?: string, bio?: string, customAgentId?: string, avatar?: string, fleetId?: string) => Promise<{ agentId: string; apiKey: string; user?: any }>;
  logout: () => Promise<void>;
  deleteAccount: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  updateProfile: (updates: Partial<UserProfile>) => Promise<void>;
  updateProfileInMemory?: (updates: Partial<UserProfile>) => void;
  rotateE2EEKeys?: (credential?: string) => Promise<void>;
  switchActiveAccount?: (targetUserId: string) => Promise<void>;
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(() => {
    if (typeof window !== 'undefined') {
      try {
        const stored = localStorage.getItem('aamarva_user');
        if (stored && stored !== 'undefined') {
          const parsed = JSON.parse(stored);
          const clean = (parsed?.data?.id || parsed?.data?.agentId) ? parsed.data : (parsed?.profile || parsed);
          return clean;
        }
      } catch (err) {
        console.warn('Failed to parse aamarva_user from localStorage:', err);
        localStorage.removeItem('aamarva_user');
      }
    }
    return null;
  });
  const [activeAccount, setActiveAccount] = useState<UserProfile | null>(() => {
    if (typeof window !== 'undefined') {
      try {
        const stored = localStorage.getItem('aamarva_active_account');
        if (stored && stored !== 'undefined') {
          const parsed = JSON.parse(stored);
          const clean = (parsed?.data?.id || parsed?.data?.agentId) ? parsed.data : (parsed?.profile || parsed);
          return clean;
        }
      } catch (err) {
        localStorage.removeItem('aamarva_active_account');
      }
    }
    return null;
  });
  const [userPassword, setUserPassword] = useState<string | null>(null);
  const [sessionAuthType, setSessionAuthType] = useState<'human' | 'agent'>(() => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('aamarva_session_auth_type');
      if (stored === 'human' || stored === 'agent') return stored;
    }
    return getAccessToken() ? 'agent' : 'human';
  });
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [e2eeStatus, setE2EEStatus] = useState<E2EEStatus>('initializing');
  const userPasswordRef = useRef<string | null>(null);
  const inFlightE2EERef = useRef<Map<string, { promise: Promise<boolean>; hasCredential: boolean }>>(new Map());
  const verifiedServerKeysRef = useRef<Map<string, string>>(new Map());
  const backedUpVaultRef = useRef<Set<string>>(new Set());
  const authEpochRef = useRef<number>(0);
  const preloadInFlightRef = useRef<Set<string>>(new Set());

  const scheduleAccountPreload = useCallback((profile: any) => {
    if (typeof window === 'undefined' || !profile?.id) return;
    const capturedEpoch = authEpochRef.current;
    const accountId = profile.id;
    const agentId = profile.agentId;
    const accountKey = getAccountKey(accountId, accountId);

    setPreparedAccountProfile(profile);
    if (Array.isArray((profile as any).posts) || Array.isArray((profile as any).connections)) {
      setQueryCache(accountKey, '/api/agents/me', profile);
    }

    const runPreload = () => {
      if (authEpochRef.current !== capturedEpoch) return;
      const preloadAuthType: 'human' | 'agent' = sessionAuthType || getCurrentSessionAuthType() || 'human';

      // 1. Preload Master & Slave fleet accounts and prepare all slave contexts in advance
      const masterCache = getQueryCache('master_accounts', '/api/auth/master/accounts', 20000);
      const masterPromise = (!masterCache || masterCache.isStale) && !preloadInFlightRef.current.has('master_accounts')
        ? (() => {
            preloadInFlightRef.current.add('master_accounts');
            return apiFetch('/api/auth/master/accounts', { authType: preloadAuthType })
              .then((res) => {
                if (authEpochRef.current === capturedEpoch && res?.success && res.data) {
                  seedFleetAccountsCache(res.data);
                  setQueryCache(accountKey, '/api/auth/master/accounts', res.data);
                }
                return res?.data || masterCache?.data || null;
              })
              .catch(() => masterCache?.data || null)
              .finally(() => {
                preloadInFlightRef.current.delete('master_accounts');
              });
          })()
        : Promise.resolve(masterCache?.data || null);

      // 2. Preload authoritative plan for current account
      const planEndpoint = agentId && agentId !== 'AMR-AGENT' ? `/api/auth/master/plan?accountId=${agentId}` : '/api/auth/master/plan';
      const planCache = getQueryCache(accountKey, planEndpoint, 20000);
      if ((!planCache || planCache.isStale) && !preloadInFlightRef.current.has(`plan:${accountKey}`)) {
        preloadInFlightRef.current.add(`plan:${accountKey}`);
        apiFetch(planEndpoint, { authType: preloadAuthType })
          .then((res) => {
            if (authEpochRef.current === capturedEpoch && res?.success && res.data) {
              setQueryCache(accountKey, planEndpoint, res.data);
              setQueryCache(accountKey, '/api/auth/master/plan', res.data);
            }
          })
          .catch(() => {})
          .finally(() => {
            preloadInFlightRef.current.delete(`plan:${accountKey}`);
          });
      }

      // 3. Preload connections, peer E2EE keys, and Command Pit fleet list
      const connCache = getQueryCache(accountKey, '/api/connections', 20000);
      const connPromise = (!connCache || connCache.isStale) && !preloadInFlightRef.current.has(`conn:${accountKey}`)
        ? (() => {
            preloadInFlightRef.current.add(`conn:${accountKey}`);
            return apiFetch('/api/connections?limit=100', { authType: preloadAuthType })
              .then((res) => {
                const list = res?.data?.connections || (Array.isArray(res?.data) ? res.data : null);
                if (authEpochRef.current === capturedEpoch && Array.isArray(list)) {
                  setQueryCache(accountKey, '/api/connections', list);
                  prefetchPeerKeys(list);
                  return list;
                }
                return connCache?.data || [];
              })
              .catch(() => connCache?.data || [])
              .finally(() => {
                preloadInFlightRef.current.delete(`conn:${accountKey}`);
              });
          })()
        : Promise.resolve(connCache?.data || []);

      Promise.all([connPromise, masterPromise]).then(([connList, masterData]) => {
        if (authEpochRef.current === capturedEpoch && (Array.isArray(connList) || masterData)) {
          const fleetList = buildCommandPitFleetList(connList || [], masterData, accountId, accountKey);
          if (fleetList.length > 0 || masterData) {
            setQueryCache(accountKey, '/api/command-pit/fleet', fleetList);
          }
        }
      }).catch(() => {});

      // 4. Preload clusters for Dashboard & Command Pit
      const clusterCache = getQueryCache(accountKey, '/api/clusters', 20000);
      if ((!clusterCache || clusterCache.isStale) && !preloadInFlightRef.current.has(`clusters:${accountKey}`)) {
        preloadInFlightRef.current.add(`clusters:${accountKey}`);
        apiFetch('/api/clusters', { authType: preloadAuthType })
          .then((res) => {
            if (authEpochRef.current === capturedEpoch && res?.success && Array.isArray(res.data)) {
              setQueryCache(accountKey, '/api/clusters', res.data);
            }
          })
          .catch(() => {})
          .finally(() => {
            preloadInFlightRef.current.delete(`clusters:${accountKey}`);
          });
      }
    };

    if (typeof (window as any).requestIdleCallback === 'function') {
      (window as any).requestIdleCallback(runPreload, { timeout: 150 });
    } else {
      setTimeout(runPreload, 15);
    }
  }, []);

  const [webAuthnPrompt, setWebAuthnPrompt] = useState<{
    pendingToken: string;
    options: any;
    userName?: string;
    resolve: (value: any) => void;
    reject: (reason?: any) => void;
  } | null>(null);
  const [webAuthnVerifyPrompt, setWebAuthnVerifyPrompt] = useState<{
    pendingToken: string;
    options: any;
    userName?: string;
    resolve: (value: any) => void;
    reject: (reason?: any) => void;
  } | null>(null);

  const ensureE2EEKeys = useCallback(async (agentId: string, forceRotate: boolean = false, credential?: string): Promise<boolean> => {
    if (typeof window === 'undefined' || !agentId) {
      setE2EEStatus('failed');
      return false;
    }

    const normalizedAgentId = agentId.trim().toUpperCase();
    const activeCredential = credential || userPasswordRef.current || userPassword || undefined;
    const authType: 'human' | 'agent' = sessionAuthType || getCurrentSessionAuthType() || 'human';
    const flightKey = `${normalizedAgentId}:${forceRotate}`;

    const existingFlight = inFlightE2EERef.current.get(flightKey);
    if (existingFlight) {
      if (existingFlight.hasCredential || !activeCredential) {
        return existingFlight.promise;
      }
      // A credential-less initialization is in flight while we now have a credential: wait for it first, then proceed if still needed
      try {
        await existingFlight.promise;
      } catch {}
    }

    const verifyServerKeyRegistration = async (
      expectedPublicKey: string,
      expectedFingerprint: string,
      forceNetworkCheck: boolean = false
    ): Promise<boolean> => {
      const cacheToken = `${expectedPublicKey}:${expectedFingerprint || ''}`;
      if (!forceNetworkCheck && verifiedServerKeysRef.current.get(normalizedAgentId) === cacheToken) {
        return true;
      }
      try {
        const res = await apiFetch('/api/agents/me/e2ee', { authType, cache: 'no-store', skipDedupe: true });
        const remoteKey = res?.data?.publicKey || res?.publicKey;
        const remoteFp = res?.data?.fingerprint || res?.fingerprint;
        if (remoteKey === expectedPublicKey && (!expectedFingerprint || (remoteFp && remoteFp === expectedFingerprint))) {
          verifiedServerKeysRef.current.set(normalizedAgentId, cacheToken);
          return true;
        }
        verifiedServerKeysRef.current.delete(normalizedAgentId);
        return false;
      } catch (err) {
        return false;
      }
    };

    const uploadRecoveryVaultForActiveKeys = async (cred: string): Promise<void> => {
      try {
        let existingVault: any = undefined;
        try {
          const recRes = await apiFetch('/api/agents/me/e2ee/recovery', { authType, cache: 'no-store', skipDedupe: true });
          if (recRes?.data?.recoveryVault?.ciphertext) {
            existingVault = recRes.data.recoveryVault;
          }
        } catch {}

        const stashed = getStashedEncryptedRecoveryVault(normalizedAgentId);
        let vaultToUpload: { ciphertext: string; nonce: string; version: number; kdfVersion?: number } | null = null;
        try {
          vaultToUpload = await createEncryptedRecoveryVault(normalizedAgentId, cred, undefined, existingVault);
        } catch (vaultCreateErr) {
          if (stashed) {
            vaultToUpload = stashed;
          } else {
            throw vaultCreateErr;
          }
        }

        if (vaultToUpload) {
          stashEncryptedRecoveryVault(normalizedAgentId, vaultToUpload);
          const putRes = await apiFetch('/api/agents/me/e2ee/recovery', {
            method: 'PUT',
            authType,
            body: JSON.stringify({ recoveryVault: vaultToUpload })
          });
          if (putRes && putRes.success !== false && !putRes.error) {
            clearTransientJwkKeys(normalizedAgentId);
            clearStashedEncryptedRecoveryVault(normalizedAgentId);
            backedUpVaultRef.current.add(normalizedAgentId);
          }
        }
      } catch (vaultErr: any) {
        console.warn('E2EE recovery vault preservation note:', vaultErr?.message || vaultErr);
      }
    };

    const publishAndSaveIdentity = async (
      identity: Awaited<ReturnType<typeof generateAgentCryptoIdentity>>,
      allowRotation: boolean
    ): Promise<StoredAgentKeyEntry> => {
      // Always publish to server BEFORE persisting to IndexedDB so a 409/network failure never poisons local storage
      await apiFetch('/api/agents/me/e2ee', {
        method: 'PUT',
        authType,
        body: JSON.stringify({
          publicKey: identity.e2eePublicKey,
          fingerprint: identity.fingerprint,
          identityKey: identity.identityPublicKey,
          signature: identity.signature,
          keyEpoch: identity.keyEpoch || 1,
          allowRotation
        })
      });

      const confirmed = await verifyServerKeyRegistration(identity.e2eePublicKey, identity.fingerprint);
      if (!confirmed) {
        throw new Error('SERVER_KEY_CONFIRMATION_FAILED: Public key not confirmed via GET endpoint after registration.');
      }

      await saveLocalKeyPair(
        normalizedAgentId,
        identity.e2eePublicKey,
        identity.e2eePrivateKey,
        identity.fingerprint,
        identity.identityPublicKey,
        identity.identityPrivateKey,
        identity.signature,
        identity.keyEpoch || 1,
        identity.transientPrivateKeyJwk,
        identity.transientIdentityPrivateKeyJwk
      );

      return {
        publicKey: identity.e2eePublicKey,
        privateKey: identity.e2eePrivateKey,
        fingerprint: identity.fingerprint,
        identityPublicKey: identity.identityPublicKey,
        identityPrivateKey: identity.identityPrivateKey,
        signature: identity.signature,
        keyEpoch: identity.keyEpoch || 1
      };
    };

    const restoreVaultAndVerify = async (
      rawVault: any,
      cred: string,
      serverHasPublicKey: boolean
    ): Promise<boolean> => {
      const restored = await restoreFromEncryptedRecoveryVault(normalizedAgentId, cred, rawVault);
      if (!restored?.activeKey || !restored.activeKey.privateKey || !restored.activeKey.publicKey) {
        throw new Error('RECOVERY_RESTORE_INCOMPLETE: Vault restoration did not produce valid operational keys.');
      }

      const restoredKeys = restored.activeKey;
      verifiedServerKeysRef.current.delete(normalizedAgentId);

      let confirmed = await verifyServerKeyRegistration(restoredKeys.publicKey, restoredKeys.fingerprint);
      if (!confirmed && !serverHasPublicKey) {
        await apiFetch('/api/agents/me/e2ee', {
          method: 'PUT',
          authType,
          body: JSON.stringify({
            publicKey: restoredKeys.publicKey,
            fingerprint: restoredKeys.fingerprint,
            identityKey: restoredKeys.identityPublicKey,
            signature: restoredKeys.signature,
            keyEpoch: restoredKeys.keyEpoch || 1,
            allowRotation: false
          })
        });
        confirmed = await verifyServerKeyRegistration(restoredKeys.publicKey, restoredKeys.fingerprint);
      }

      if (!confirmed) {
        clearTransientJwkKeys(normalizedAgentId);
        setE2EEStatus('recovery_required');
        return false;
      }

      // If user recently reset password and unlocked the vault using an older password,
      // re-wrap the recovery vault with the current session password so future logins decrypt automatically.
      const sessionPwd = userPasswordRef.current || userPassword;
      if (authType === 'human' && sessionPwd && sessionPwd !== cred) {
        try {
          const rewrapped = await createEncryptedRecoveryVault(normalizedAgentId, sessionPwd);
          const rewrapRes = await apiFetch('/api/agents/me/e2ee/recovery', {
            method: 'PUT',
            authType,
            body: JSON.stringify({ recoveryVault: rewrapped })
          });
          if (rewrapRes && rewrapRes.success !== false && !rewrapRes.error) {
            clearStashedEncryptedRecoveryVault(normalizedAgentId);
          }
        } catch (rewrapErr) {
          console.warn('E2EE vault re-wrap after password change notice:', rewrapErr);
        }
      }

      clearTransientJwkKeys(normalizedAgentId);
      clearStashedEncryptedRecoveryVault(normalizedAgentId);
      backedUpVaultRef.current.add(normalizedAgentId);
      setE2EEStatus('ready');
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('aamarva-e2ee-keys-synced', { detail: { agentId: normalizedAgentId } }));
      }
      return true;
    };

    const runInitialization = async (): Promise<boolean> => {
      setE2EEStatus('initializing');
      try {
        let keys = await getLocalKeyPair(normalizedAgentId);
        const isCompleteKey = !!(keys && keys.publicKey && keys.privateKey && keys.identityPublicKey && keys.signature);
        let serverKeyConfirmed = false;

        // Determine account role authoritatively
        let profile: any = null;
        if (user?.agentId?.toUpperCase() === normalizedAgentId) {
          profile = user;
        } else if (activeAccount?.agentId?.toUpperCase() === normalizedAgentId) {
          profile = activeAccount;
        } else {
          const prepared = getPreparedAccountProfile(normalizedAgentId);
          if (prepared?.data) {
            profile = prepared.data;
          } else {
            try {
              const profileRes = await apiFetch(`/api/agents/${normalizedAgentId}`, { authType });
              profile = profileRes.data;
            } catch (e) {
              console.error('Failed to resolve authoritative account role:', e);
            }
          }
        }

        const isSlave = isSlaveAccount(profile);

        if (isSlave) {
          if (profile?.e2eePublicKey) {
            setE2EEStatus('ready');
            return true;
          } else {
            console.warn('Slave account E2EE ready check failed: missing registered public key.');
            setE2EEStatus('failed');
            return false;
          }
        }

        if (!profile && !keys) {
          console.error('Cannot resolve account role and no existing keys found. Aborting E2EE setup.');
          setE2EEStatus('failed');
          return false;
        }

        if (!isCompleteKey && !forceRotate) {
          setE2EEStatus('initializing');

          let hasRecoveryVault = false;
          let rawVault: any = null;
          let serverPubKey: string | null = profile?.e2eePublicKey || null;
          let serverEpoch: number = Number(profile?.e2eeKeyEpoch || 1);

          // Fail-closed check for human sessions: recovery check failure MUST NOT fall through to key generation
          if (authType === 'human') {
            let recoveryRes: any = null;
            try {
              recoveryRes = await apiFetch('/api/agents/me/e2ee/recovery', { authType, cache: 'no-store', skipDedupe: true });
            } catch (recFetchErr) {
              console.warn('E2EE recovery vault download failed (fail-closed to recovery_required):', recFetchErr);
              setE2EEStatus('recovery_required');
              return false;
            }

            if (!recoveryRes || recoveryRes.success === false) {
              console.warn('E2EE recovery vault check returned unsuccessful response (fail-closed to recovery_required).');
              setE2EEStatus('recovery_required');
              return false;
            }

            if (recoveryRes.data?.recoveryVault) {
              rawVault = recoveryRes.data.recoveryVault;
              hasRecoveryVault = true;
            }
            if (recoveryRes.data?.publicKey) {
              serverPubKey = recoveryRes.data.publicKey;
            }
            if (recoveryRes.data?.keyEpoch) {
              serverEpoch = Number(recoveryRes.data.keyEpoch) || serverEpoch;
            }
          }

          if (hasRecoveryVault) {
            if (!activeCredential) {
              console.warn('E2EE identity missing in local keystore and recovery vault exists on server; recovery required.');
              setE2EEStatus('recovery_required');
              return false;
            }

            if (typeof rawVault !== 'object' || !rawVault.ciphertext || !rawVault.nonce) {
              console.warn('E2EE recovery vault exists on server but structure is corrupted or missing ciphertext/nonce.');
              setE2EEStatus('recovery_required');
              return false;
            }

            try {
              console.log('Restoring existing E2EE identity from encrypted zero-knowledge recovery vault for agent:', normalizedAgentId);
              return await restoreVaultAndVerify(rawVault, activeCredential, Boolean(serverPubKey));
            } catch (restoreErr: any) {
              console.warn('E2EE recovery vault decryption/restoration notice:', restoreErr?.message || restoreErr);
              setE2EEStatus('recovery_required');
              return false;
            }
          }

          // Check if server already has a registered public key despite no server recoveryVault
          // (e.g. account registered before vault upload was fixed, or registration left a local stashed vault)
          if (serverPubKey) {
            const stashed = getStashedEncryptedRecoveryVault(normalizedAgentId);
            if (stashed && activeCredential) {
              try {
                const ok = await restoreVaultAndVerify(stashed, activeCredential, true);
                if (ok) {
                  await apiFetch('/api/agents/me/e2ee/recovery', {
                    method: 'PUT',
                    authType,
                    body: JSON.stringify({ recoveryVault: stashed })
                  }).catch(() => {});
                  return true;
                }
              } catch {}
            }

            if (authType === 'human') {
              if (!activeCredential) {
                console.warn('Server already has a registered E2EE public key and no recovery vault; credential required to establish synced epoch.');
                setE2EEStatus('recovery_required');
                return false;
              }

              // Establish a fresh synchronized epoch (serverEpoch + 1) and upload encrypted recovery vault
              // so this device and the original device converge on a shared vault-backed identity.
              const nextEpoch = (Number.isFinite(serverEpoch) && serverEpoch >= 1 ? serverEpoch : 1) + 1;
              console.log('Server has legacy E2EE public key without recovery vault; provisioning synced epoch', nextEpoch, 'for agent:', normalizedAgentId);
              verifiedServerKeysRef.current.delete(normalizedAgentId);
              const nextIdentity = await generateAgentCryptoIdentity(normalizedAgentId, nextEpoch);
              keys = await publishAndSaveIdentity(nextIdentity, true);
              serverKeyConfirmed = true;
              await uploadRecoveryVaultForActiveKeys(activeCredential);
            } else {
              // Agent API key session without matching local keys cannot silently overwrite another runtime's key
              setE2EEStatus('failed');
              return false;
            }
          } else {
            // State A: Genuinely first-time setup with no existing server key or recovery vault
            console.log('Establishing initial cryptographic identity for agent (first-time setup):', normalizedAgentId);
            const identity = await generateAgentCryptoIdentity(normalizedAgentId, 1);
            keys = await publishAndSaveIdentity(identity, false);
            serverKeyConfirmed = true;

            if (activeCredential) {
              await uploadRecoveryVaultForActiveKeys(activeCredential);
            }
          }
        } else if (isCompleteKey && !forceRotate && keys) {
          const runBackgroundIntegrityAndRecoverySync = async (activeKeys: StoredAgentKeyEntry): Promise<boolean> => {
            const confirmed = await verifyServerKeyRegistration(activeKeys.publicKey, activeKeys.fingerprint, true);
            if (!confirmed) {
              if (authType === 'human') {
                let recoveryRes: any = null;
                try {
                  recoveryRes = await apiFetch('/api/agents/me/e2ee/recovery', { authType, cache: 'no-store', skipDedupe: true });
                } catch (err) {
                  console.warn('E2EE key verification recovery check notice:', err);
                  setE2EEStatus('recovery_required');
                  return false;
                }

                const remotePubKey = recoveryRes?.data?.publicKey || null;
                const remoteVault = recoveryRes?.data?.recoveryVault || null;
                const remoteEpoch = Number(recoveryRes?.data?.keyEpoch || 1);

                if (!remotePubKey) {
                  await apiFetch('/api/agents/me/e2ee', {
                    method: 'PUT',
                    authType,
                    body: JSON.stringify({
                      publicKey: activeKeys.publicKey,
                      fingerprint: activeKeys.fingerprint,
                      identityKey: activeKeys.identityPublicKey,
                      signature: activeKeys.signature,
                      keyEpoch: activeKeys.keyEpoch || 1,
                      allowRotation: false
                    })
                  });
                  const reconfirmed = await verifyServerKeyRegistration(activeKeys.publicKey, activeKeys.fingerprint, true);
                  if (!reconfirmed) {
                    setE2EEStatus('failed');
                    return false;
                  }
                } else if (remotePubKey === activeKeys.publicKey) {
                  verifiedServerKeysRef.current.set(normalizedAgentId, `${activeKeys.publicKey}:${activeKeys.fingerprint || ''}`);
                } else if (remoteVault && typeof remoteVault === 'object' && remoteVault.ciphertext && remoteVault.nonce) {
                  if (!activeCredential) {
                    setE2EEStatus('recovery_required');
                    return false;
                  }
                  return await restoreVaultAndVerify(remoteVault, activeCredential, true);
                } else {
                  if (!activeCredential) {
                    setE2EEStatus('recovery_required');
                    return false;
                  }
                  const nextEpoch = Math.max(remoteEpoch, activeKeys.keyEpoch || 1) + 1;
                  verifiedServerKeysRef.current.delete(normalizedAgentId);
                  const nextIdentity = await generateAgentCryptoIdentity(normalizedAgentId, nextEpoch);
                  const rotatedKeys = await publishAndSaveIdentity(nextIdentity, true);
                  await uploadRecoveryVaultForActiveKeys(activeCredential);
                  verifiedServerKeysRef.current.set(normalizedAgentId, `${rotatedKeys.publicKey}:${rotatedKeys.fingerprint || ''}`);
                }
              } else {
                await apiFetch('/api/agents/me/e2ee', {
                  method: 'PUT',
                  authType,
                  body: JSON.stringify({
                    publicKey: activeKeys.publicKey,
                    fingerprint: activeKeys.fingerprint,
                    identityKey: activeKeys.identityPublicKey,
                    signature: activeKeys.signature,
                    keyEpoch: activeKeys.keyEpoch || 1,
                    allowRotation: false
                  })
                });
                const reconfirmed = await verifyServerKeyRegistration(activeKeys.publicKey, activeKeys.fingerprint, true);
                if (!reconfirmed) {
                  setE2EEStatus('failed');
                  return false;
                }
              }
            }

            // Silently restore any missing historical epochs from the server recovery vault while credential is available
            if (authType === 'human' && activeCredential) {
              try {
                const localEpochs = await getAllLocalEpochKeys(normalizedAgentId);
                const activeEpochNum = Number(activeKeys.keyEpoch || 1);
                const hasEpochOne = localEpochs.some((ep) => Number(ep.keyEpoch) === 1);
                if (!hasEpochOne || (activeEpochNum > 1 && localEpochs.length < activeEpochNum)) {
                  const recCheck = await apiFetch('/api/agents/me/e2ee/recovery', { authType, cache: 'no-store', skipDedupe: true });
                  const remoteVault = recCheck?.data?.recoveryVault || null;
                  if (remoteVault && typeof remoteVault === 'object' && remoteVault.ciphertext && remoteVault.nonce) {
                    await restoreVaultAndVerify(remoteVault, activeCredential, true).catch(() => false);
                  }
                }
              } catch {
                // Non-fatal: active operational key is already confirmed
              }
            }

            // Ensure existing local identity has its recovery vault backed up on the server (including stashed signup vaults)
            if (authType === 'human' && !backedUpVaultRef.current.has(normalizedAgentId)) {
              const stashedVault = getStashedEncryptedRecoveryVault(normalizedAgentId);
              if (stashedVault || activeCredential) {
                try {
                  const recCheck = await apiFetch('/api/agents/me/e2ee/recovery', { authType, cache: 'no-store', skipDedupe: true });
                  if (recCheck?.data?.recoveryVault?.ciphertext) {
                    backedUpVaultRef.current.add(normalizedAgentId);
                    clearStashedEncryptedRecoveryVault(normalizedAgentId);
                  } else if (stashedVault) {
                    const putRes = await apiFetch('/api/agents/me/e2ee/recovery', {
                      method: 'PUT',
                      authType,
                      body: JSON.stringify({ recoveryVault: stashedVault })
                    });
                    if (putRes && putRes.success !== false && !putRes.error) {
                      clearStashedEncryptedRecoveryVault(normalizedAgentId);
                      clearTransientJwkKeys(normalizedAgentId);
                      backedUpVaultRef.current.add(normalizedAgentId);
                    }
                  } else if (activeCredential) {
                    await uploadRecoveryVaultForActiveKeys(activeCredential);
                  }
                } catch {
                  // Non-fatal
                }
              }
            }

            return true;
          };

          if (profile?.e2eePublicKey && profile.e2eePublicKey === keys.publicKey) {
            // Fast path: authoritative profile confirms our local key matches server registration.
            // Transition immediately to 'ready' and run secondary live integrity/epoch checks asynchronously.
            verifiedServerKeysRef.current.set(normalizedAgentId, `${keys.publicKey}:${keys.fingerprint || ''}`);
            setE2EEStatus('ready');
            void runBackgroundIntegrityAndRecoverySync(keys).catch((err) => {
              console.warn('Background E2EE verification notice:', err);
            });
            return true;
          }

          const verifiedOk = await runBackgroundIntegrityAndRecoverySync(keys);
          if (!verifiedOk) {
            return false;
          }
          keys = (await getLocalKeyPair(normalizedAgentId)) || keys;
          serverKeyConfirmed = true;
        } else if (forceRotate) {
          console.log('Performing authorized key rotation for agent:', normalizedAgentId);
          verifiedServerKeysRef.current.delete(normalizedAgentId);

          let existingVaultForRotation: any = undefined;
          if (authType === 'human' && activeCredential) {
            try {
              const recRes = await apiFetch('/api/agents/me/e2ee/recovery', { authType, cache: 'no-store', skipDedupe: true });
              if (recRes?.data?.recoveryVault?.ciphertext) {
                existingVaultForRotation = recRes.data.recoveryVault;
              }
            } catch {}
          }

          const rotated = await rotateAgentCryptoIdentity(normalizedAgentId, keys?.keyEpoch, {
            existingVault: existingVaultForRotation,
            credential: activeCredential,
            preserveIdentityOnlyIfRecoverable: true
          });
          keys = {
            publicKey: rotated.e2eePublicKey,
            privateKey: rotated.e2eePrivateKey,
            fingerprint: rotated.fingerprint,
            identityPublicKey: rotated.identityPublicKey,
            identityPrivateKey: rotated.identityPrivateKey,
            signature: rotated.signature,
            keyEpoch: rotated.keyEpoch
          };

          await apiFetch('/api/agents/me/e2ee', {
            method: 'PUT',
            authType,
            body: JSON.stringify({
              publicKey: keys.publicKey,
              fingerprint: keys.fingerprint,
              identityKey: keys.identityPublicKey,
              signature: keys.signature,
              keyEpoch: keys.keyEpoch || 1,
              allowRotation: true
            })
          });

          const confirmed = await verifyServerKeyRegistration(keys.publicKey, keys.fingerprint, true);
          if (!confirmed) {
            throw new Error('SERVER_KEY_CONFIRMATION_FAILED: Rotated public key not confirmed via GET endpoint.');
          }
          serverKeyConfirmed = true;

          if (activeCredential) {
            await uploadRecoveryVaultForActiveKeys(activeCredential);
          }
        }

        if (keys && keys.privateKey && keys.publicKey) {
          const finalConfirmed = serverKeyConfirmed || await verifyServerKeyRegistration(keys.publicKey, keys.fingerprint, true);
          if (finalConfirmed) {
            setE2EEStatus('ready');
            return true;
          } else {
            setE2EEStatus('failed');
            return false;
          }
        } else {
          setE2EEStatus('failed');
          return false;
        }
      } catch (e: any) {
        console.warn('E2EE Key initialization notice:', e?.message || e);
        setE2EEStatus('failed');
        return false;
      } finally {
        inFlightE2EERef.current.delete(flightKey);
      }
    };

    const promise = runInitialization();
    inFlightE2EERef.current.set(flightKey, { promise, hasCredential: Boolean(activeCredential) });
    return promise;
  }, [userPassword, sessionAuthType]);

  const rotateE2EEKeys = async (credential?: string) => {
    if (!user?.agentId) throw new Error('No authenticated agent.');
    const activeCredential = credential || userPassword || undefined;
    await ensureE2EEKeys(user.agentId, true, activeCredential);
    await refreshProfile();
  };

  const refreshProfile = async (options?: { skipE2EE?: boolean; credentialOverride?: string }) => {
    const capturedEpoch = authEpochRef.current;
    try {
      const profile = await fetchCurrentProfileApi();
      // Ignore obsolete response if an account switch or logout occurred while request was in flight
      if (authEpochRef.current !== capturedEpoch) return;

      if (profile) {
        const cleanProfile = (profile as any)?.data?.id ? (profile as any).data : ((profile as any)?.profile || profile);
        // The server returns the profile of the ACTIVE account
        setActiveAccount(cleanProfile);
        setUser(cleanProfile);
        if (typeof window !== 'undefined') {
          localStorage.setItem('aamarva_active_account', JSON.stringify(cleanProfile));
          localStorage.setItem('aamarva_user', JSON.stringify(cleanProfile));
        }
        scheduleAccountPreload(cleanProfile);
        
        if (!options?.skipE2EE) {
          await ensureE2EEKeys(cleanProfile.agentId, false, options?.credentialOverride || userPasswordRef.current || userPassword || undefined);
        }
      } else {
        // Explicitly clear unauthenticated or expired state
        setUser(null);
        setActiveAccount(null);
        if (typeof window !== 'undefined') {
          localStorage.removeItem('aamarva_user');
          localStorage.removeItem('aamarva_active_account');
        }
        setE2EEStatus('failed');
      }
    } catch (err: any) {
      if (authEpochRef.current !== capturedEpoch) return;
      setUser(null);
      setActiveAccount(null);
      if (typeof window !== 'undefined') {
        localStorage.removeItem('aamarva_user');
        localStorage.removeItem('aamarva_active_account');
      }
      setE2EEStatus('failed');
    }
  };

  useEffect(() => {
    const handleUnauthorized = () => {
      console.warn('Unauthorized token or deleted user detected. Logging out.');
      clearCachedWatchtowerEvents();
      verifiedServerKeysRef.current.clear();
      backedUpVaultRef.current.clear();
      userPasswordRef.current = null;
      setUser(null);
      setActiveAccount(null);
      setUserPassword(null);
      setE2EEStatus('failed');
      if (typeof window !== 'undefined') {
        localStorage.removeItem('aamarva_user');
        localStorage.removeItem('aamarva_active_account');
      }
    };

    if (typeof window !== 'undefined') {
      window.addEventListener('auth-unauthorized', handleUnauthorized);
    }

    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'aamarva_user') {
        if (e.newValue) {
          try {
            setUser(JSON.parse(e.newValue));
          } catch (err) {
            console.warn('Failed to sync user from storage:', err);
          }
        } else {
          setUser(null);
          setActiveAccount(null);
          setE2EEStatus('failed');
        }
      }
      if (e.key === 'aamarva_active_account') {
        if (e.newValue) {
          try {
            setActiveAccount(JSON.parse(e.newValue));
          } catch (err) {
            console.warn('Failed to sync active account from storage:', err);
          }
        }
      }
    };

    const handleRecoveryRequired = () => {
      verifiedServerKeysRef.current.clear();
      setE2EEStatus('recovery_required');
    };
    const handleKeysSynced = () => {
      setE2EEStatus('ready');
    };

    if (typeof window !== 'undefined') {
      window.addEventListener('storage', handleStorageChange);
      window.addEventListener('aamarva-e2ee-recovery-required', handleRecoveryRequired);
      window.addEventListener('aamarva-e2ee-keys-synced', handleKeysSynced);
    }

    const initAuth = async () => {
      try {
        // Attempt silent profile restoration via HttpOnly cookie or localStorage token
        await refreshProfile();
      } catch {
        // Guest mode fallback
      } finally {
        setIsLoading(false);
      }
    };

    initAuth();

    return () => {
      if (typeof window !== 'undefined') {
        window.removeEventListener('auth-unauthorized', handleUnauthorized);
        window.removeEventListener('storage', handleStorageChange);
        window.removeEventListener('aamarva-e2ee-recovery-required', handleRecoveryRequired);
        window.removeEventListener('aamarva-e2ee-keys-synced', handleKeysSynced);
      }
    };
  }, []);

  const login = async (agentId: string, credential: string) => {
    const result = await loginUserApi({ agentId, password: credential });
    let userToSave = null;

    if (result?.requiresWebAuthnSetup) {
      // Password credentials verified! Prompt popup modal to enable WebAuthn passkey before issuing session.
      userToSave = await new Promise((resolve, reject) => {
        setWebAuthnPrompt({
          pendingToken: result.pendingToken,
          options: result.options,
          userName: result.user?.name || result.user?.agentId || 'User',
          resolve,
          reject,
        });
      });
    } else if (result?.requiresWebAuthnVerify) {
      // Password credentials verified! Prompt popup modal to verify existing WebAuthn passkey.
      userToSave = await new Promise((resolve, reject) => {
        setWebAuthnVerifyPrompt({
          pendingToken: result.pendingToken,
          options: result.options,
          userName: result.user?.name || result.user?.agentId || 'User',
          resolve,
          reject,
        });
      });
    } else {
      userToSave = result.user || result.data?.user || result;
    }

    if (typeof window !== 'undefined') {
      (window as any).__triggerWebAuthnSetup = async (pendingToken: string, options: any, userName: string) => {
        const u = await new Promise((resolve, reject) => {
          setWebAuthnPrompt({
            pendingToken,
            options,
            userName,
            resolve,
            reject,
          });
        });
        return u;
      };
    }

    let rawUser = userToSave;
    if (rawUser && typeof rawUser === 'object') {
      if ('user' in rawUser && rawUser.user) rawUser = rawUser.user;
      else if ('data' in rawUser && rawUser.data?.user) rawUser = rawUser.data.user;
    }
    const finalUser = rawUser || null;
    authEpochRef.current += 1;
    clearCachedWatchtowerEvents();

    setUser(finalUser);
    setActiveAccount(finalUser);
    if (credential) {
      userPasswordRef.current = credential;
      setUserPassword(credential);
    }
    setSessionAuthType('human');
    if (typeof window !== 'undefined') {
      localStorage.setItem('aamarva_session_auth_type', 'human');
      if (finalUser) {
        localStorage.setItem('aamarva_user', JSON.stringify(finalUser));
        localStorage.setItem('aamarva_active_account', JSON.stringify(finalUser));
      } else {
        localStorage.removeItem('aamarva_user');
        localStorage.removeItem('aamarva_active_account');
      }
    }
    if (finalUser) {
      scheduleAccountPreload(finalUser);
    }
    if (finalUser?.agentId) {
      // Run E2EE initialization with password credential and background profile refresh without duplicate E2EE flight
      await Promise.all([
        ensureE2EEKeys(finalUser.agentId, false, credential),
        refreshProfile({ skipE2EE: true })
      ]);
    } else {
      await refreshProfile();
    }
  };

  const loginAgent = async (agentId: string, apiKey: string) => {
    const result = await loginAgentApi({ agentId, apiKey });
    const userToSave = result.user || result.data?.user || result;
    authEpochRef.current += 1;
    clearCachedWatchtowerEvents();
    setUser(userToSave || null);
    setActiveAccount(userToSave || null);
    if (apiKey) {
      userPasswordRef.current = apiKey;
      setUserPassword(apiKey);
    }
    setSessionAuthType('agent');
    if (typeof window !== 'undefined') {
      localStorage.setItem('aamarva_session_auth_type', 'agent');
      if (userToSave) {
        localStorage.setItem('aamarva_user', JSON.stringify(userToSave));
        localStorage.setItem('aamarva_active_account', JSON.stringify(userToSave));
      } else {
        localStorage.removeItem('aamarva_user');
        localStorage.removeItem('aamarva_active_account');
      }
    }
    if (userToSave) {
      scheduleAccountPreload(userToSave);
      await ensureE2EEKeys(userToSave.agentId, false, apiKey);
    }
  };

  const register = async (email: string, password: string, agentName?: string, bio?: string, customAgentId?: string, avatar?: string, fleetId?: string) => {
    const resData = await registerUserApi({ 
      email, 
      password, 
      agentName, 
      name: agentName,
      bio,
      agentId: customAgentId,
      avatar,
      profileAvatar: avatar,
      fleetId,
    } as any);
    
    const user = resData.user || resData.data?.user;
    const agentId = resData.agentId || user?.agentId || '';

    // Automatic E2EE Bootstrap
    const isSlave = isSlaveAccount(user) || resData.account_type === 'slave' || resData.data?.account_type === 'slave';

    if (agentId && !isSlave) {
      const hasActiveToken = Boolean(getAccessToken());
      if (hasActiveToken) {
        try {
          if (password) {
            userPasswordRef.current = password;
            setUserPassword(password);
          }
          const { identity } = await bootstrapAgentIdentity(agentId, password);
          await apiFetch('/api/agents/me/e2ee', {
            method: 'PUT',
            authType: 'human',
            body: JSON.stringify(constructIdentityRegistrationPayload(identity))
          });

          try {
            const normId = normalizeAgentId(agentId);
            const vault = getStashedEncryptedRecoveryVault(normId) || await createEncryptedRecoveryVault(normId, password);
            if (vault) {
              stashEncryptedRecoveryVault(normId, vault);
              const recRes = await apiFetch('/api/agents/me/e2ee/recovery', {
                method: 'PUT',
                authType: 'human',
                body: JSON.stringify({ recoveryVault: vault })
              });
              if (recRes && recRes.success !== false && !recRes.error) {
                clearTransientJwkKeys(normId);
                clearStashedEncryptedRecoveryVault(normId);
                backedUpVaultRef.current.add(normId);
              }
            }
          } catch (vaultErr) {
            console.warn('Recovery vault upload during registration deferred to login:', vaultErr);
          }

          setE2EEStatus('ready');
        } catch (e) {
          console.error('Automatic E2EE bootstrap failed during registration:', e);
          setE2EEStatus('failed');
        }
      } else {
        // Pre-generate local identity and stash encrypted vault synchronously before returning
        // so immediate login/reload/device switch never races missing stashed vault.
        try {
          await bootstrapAgentIdentity(agentId, password);
        } catch (e) {
          console.warn('E2EE identity pre-generation notice:', e);
        }
      }
    } else if (isSlave) {
      console.log('Slave account detected: skipping automatic browser-side E2EE bootstrap.');
      setE2EEStatus('ready');
    }

    return { 
      agentId,
      apiKey: resData.apiKey || '',
      user
    };
  };

  const logout = async () => {
    authEpochRef.current += 1;
    clearInFlightRequests();
    clearPeerKeyCache();
    verifiedServerKeysRef.current.clear();
    backedUpVaultRef.current.clear();
    userPasswordRef.current = null;
    try {
      await logoutUserApi();
    } catch (e) {
      console.warn('Logout API error:', e);
    }
    clearAllAppCaches();
    setUser(null);
    setActiveAccount(null);
    setUserPassword(null);
    setE2EEStatus('failed');
    if (typeof window !== 'undefined') {
      localStorage.removeItem('aamarva_user');
      localStorage.removeItem('aamarva_active_account');
      localStorage.removeItem('aamarva_session_auth_type');
      sessionStorage.removeItem('aamarva_return_master_id');
      sessionStorage.removeItem('aamarva_return_slave_id');
    }
  };

  const deleteAccount = async () => {
    const rawUser = activeAccount || user;
    const currentUser = rawUser ? ((rawUser as any).profile || rawUser) : null;
    const masterId = currentUser?.master_id || currentUser?.masterUserId || user?.id;

    const isSlave = !!(
      (currentUser?.master_id && currentUser?.id && currentUser.master_id !== currentUser.id) ||
      (currentUser?.masterUserId && currentUser?.id && currentUser.masterUserId !== currentUser.id) ||
      currentUser?.account_type === 'slave' ||
      currentUser?.role === 'slave' ||
      (currentUser?.email && currentUser.email.includes('+AMR-')) ||
      (activeAccount?.agentId && user?.agentId && activeAccount.agentId.toUpperCase() !== user.agentId.toUpperCase())
    );

    if (isSlave) {
      const targetSlaveId = currentUser?.id || activeAccount?.id || user?.id || '';

      try {
        await apiFetch('/api/auth/master/undeploy-slave-agent', {
          method: 'POST',
          authType: 'human',
          body: JSON.stringify({ 
            slaveAgentId: targetSlaveId,
            subAgentId: targetSlaveId,
            agentId: targetSlaveId
          })
        });
      } catch (err: any) {
        console.warn('[deleteAccount] undeploy-slave-agent error:', err?.message || err);
        throw err;
      }

      // Auto switch back to master account
      if (masterId && masterId !== targetSlaveId) {
        try {
          await apiFetch('/api/auth/master/switch', {
            method: 'POST',
            authType: 'human',
            body: JSON.stringify({ targetAgentId: masterId })
          });
        } catch (switchErr) {
          console.warn('[deleteAccount] Auto-switch back to master account notice:', switchErr);
        }
      }

      await refreshProfile();
      window.dispatchEvent(new CustomEvent('aamarva-agents-updated'));
      return;
    }

    // Otherwise, master account deletion
    await deleteAccountApi();
    clearAllAppCaches();
    verifiedServerKeysRef.current.clear();
    backedUpVaultRef.current.clear();
    userPasswordRef.current = null;
    setUser(null);
    setActiveAccount(null);
    setUserPassword(null);
    setE2EEStatus('failed');
    if (typeof window !== 'undefined') {
      localStorage.removeItem('aamarva_user');
      localStorage.removeItem('aamarva_active_account');
    }
  };

  const updatePassword = (pwd: string) => {
    if (pwd) {
      userPasswordRef.current = pwd;
      setUserPassword(pwd);
    }
  };

  const updateProfile = async (updates: Partial<UserProfile>) => {
    try {
      const updatedUser = await updateProfileApi(updates);
      // Update active account context
      setActiveAccount(updatedUser);
      if (typeof window !== 'undefined') {
        localStorage.setItem('aamarva_active_account', JSON.stringify(updatedUser));
      }
      // If the updated profile is the Master, sync Master state
      if (!isSlaveAccount(updatedUser)) {
        setUser(updatedUser);
        if (typeof window !== 'undefined') {
          localStorage.setItem('aamarva_user', JSON.stringify(updatedUser));
        }
      }
    } catch (err) {
      console.warn('Failed to update profile:', err);
      throw err;
    }
  };

  const updateProfileInMemory = useCallback((updates: Partial<UserProfile>) => {
    setActiveAccount(prev => {
      if (!prev) return null;
      const next = { ...prev, ...updates };
      if (typeof window !== 'undefined') {
        localStorage.setItem('aamarva_active_account', JSON.stringify(next));
      }
      return next;
    });
    setUser(prev => {
      if (!prev) return null;
      const next = { ...prev, ...updates };
      if (typeof window !== 'undefined') {
        localStorage.setItem('aamarva_user', JSON.stringify(next));
      }
      return next;
    });
  }, []);

  const switchActiveAccount = async (targetUserId: string) => {
    const switchEpoch = ++authEpochRef.current;
    clearInFlightRequests();
    clearPeerKeyCache();
    clearCachedWatchtowerEvents();

    const res = await apiFetch('/api/auth/master/switch', {
      method: 'POST',
      body: JSON.stringify({ targetAgentId: targetUserId }),
      authType: 'human'
    });

    // If another switch or logout happened while this switch was in flight, ignore obsolete response
    if (authEpochRef.current !== switchEpoch) {
      return;
    }

    if (res?.success && res.data?.user) {
      const newUserProfile = res.data.user;
      const prepared = getPreparedAccountProfile(newUserProfile.id || newUserProfile.agentId)?.data;
      const mergedProfile = prepared ? { ...prepared, ...newUserProfile } : newUserProfile;

      const retMasterId = res.data?.returnMasterId || null;
      const retSlaveId = res.data?.returnSlaveId || null;

      if (typeof window !== 'undefined') {
        if (retMasterId) {
          sessionStorage.setItem('aamarva_return_master_id', retMasterId);
        } else {
          sessionStorage.removeItem('aamarva_return_master_id');
        }
        if (retSlaveId) {
          sessionStorage.setItem('aamarva_return_slave_id', retSlaveId);
        } else {
          sessionStorage.removeItem('aamarva_return_slave_id');
        }
      }

      setActiveAccount(mergedProfile);
      setUser(mergedProfile);
      if (typeof window !== 'undefined') {
        localStorage.setItem('aamarva_active_account', JSON.stringify(mergedProfile));
        localStorage.setItem('aamarva_user', JSON.stringify(mergedProfile));
      }

      // Update cached master_accounts activeAgentId and return context immediately
      const cachedMasterAccounts = getQueryCache('master_accounts', '/api/auth/master/accounts', 300000)?.data;
      if (cachedMasterAccounts) {
        seedFleetAccountsCache({
          ...cachedMasterAccounts,
          activeAgentId: mergedProfile.id,
          returnMasterId: retMasterId,
          returnSlaveId: retSlaveId,
        });
      }

      scheduleAccountPreload(mergedProfile);

      // Run E2EE check and full profile revalidation in the background without blocking switch completion
      ensureE2EEKeys(mergedProfile.agentId, false, userPassword || undefined).catch(() => {});
      fetchCurrentProfileApi('human')
        .then((fullProfile) => {
          if (authEpochRef.current === switchEpoch && fullProfile) {
            setActiveAccount(fullProfile);
            setUser(fullProfile);
            if (typeof window !== 'undefined') {
              localStorage.setItem('aamarva_active_account', JSON.stringify(fullProfile));
              localStorage.setItem('aamarva_user', JSON.stringify(fullProfile));
            }
            setPreparedAccountProfile(fullProfile);
            const accKey = getAccountKey(fullProfile.id, fullProfile.id);
            setQueryCache(accKey, '/api/agents/me', fullProfile);
          }
        })
        .catch(() => {});
    } else {
      throw new Error(res?.error?.message || 'Failed to switch account.');
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        activeAccount,
        isAuthenticated: !!(user || activeAccount),
        isLoading,
        sessionAuthType,
        e2eeStatus,
        isE2EEReady: e2eeStatus === 'ready',
        ensureE2EEKeys,
        userPassword,
        updatePassword,
        login,
        loginAgent,
        register,
        logout,
        deleteAccount,
        refreshProfile,
        updateProfile,
        updateProfileInMemory,
        rotateE2EEKeys,
        switchActiveAccount,
      }}
    >
      {children}
      <WebAuthnEnableModal
        isOpen={!!webAuthnPrompt}
        pendingToken={webAuthnPrompt?.pendingToken || ''}
        options={webAuthnPrompt?.options}
        userName={webAuthnPrompt?.userName}
        onSuccess={(userData) => {
          const finalUser = userData?.user || userData?.data?.user || userData;
          webAuthnPrompt?.resolve(finalUser);
          setWebAuthnPrompt(null);
        }}
        onCancel={() => {
          webAuthnPrompt?.reject(new Error('WebAuthn passkey setup is required to complete login.'));
          setWebAuthnPrompt(null);
        }}
      />
      <WebAuthnVerifyModal
        isOpen={!!webAuthnVerifyPrompt}
        pendingToken={webAuthnVerifyPrompt?.pendingToken || ''}
        options={webAuthnVerifyPrompt?.options}
        userName={webAuthnVerifyPrompt?.userName}
        onSuccess={(userData) => {
          const finalUser = userData?.user || userData?.data?.user || userData;
          webAuthnVerifyPrompt?.resolve(finalUser);
          setWebAuthnVerifyPrompt(null);
        }}
        onCancel={() => {
          webAuthnVerifyPrompt?.reject(new Error('Device credential prompt was cancelled or timed out.'));
          setWebAuthnVerifyPrompt(null);
        }}
      />
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
