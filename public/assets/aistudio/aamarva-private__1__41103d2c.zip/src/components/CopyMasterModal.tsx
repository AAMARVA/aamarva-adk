import React, { useState, useEffect } from 'react';
import { Copy, X, Check, Lock } from 'lucide-react';
import { AgentAvatar } from './AgentAvatar';
import { apiFetch } from '../services/authApi';

interface CopyMasterModalProps {
  masterAgent: any;
  slaveAgents: any[];
  user: any;
  isViewOnly?: boolean;
  masterCopySettings?: any;
  onSynced?: (savedSettings: any) => void;
  onClose: () => void;
}

export function formatLastCommitDate(updatedAt?: string | null): string {
  if (!updatedAt) return '0';
  const d = new Date(updatedAt);
  if (isNaN(d.getTime())) return '0';
  const hours = d.getHours().toString().padStart(2, '0');
  const minutes = d.getMinutes().toString().padStart(2, '0');
  const days = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
  const months = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];
  const dayName = days[d.getDay()];
  const dayOfMonth = d.getDate();
  const monthName = months[d.getMonth()];
  const yearShort = d.getFullYear().toString().slice(-2);
  return `${hours}:${minutes} / ${dayName}, ${dayOfMonth} ${monthName} ${yearShort}`;
}

export function CopyMasterModal({ masterAgent, slaveAgents, user, isViewOnly = false, masterCopySettings = null, onSynced, onClose }: CopyMasterModalProps) {
  const hasEditedRef = React.useRef(false);

  const resolvePersistedSlaveIds = () => {
    const validIds = new Set(slaveAgents.map((s: any) => s.id));
    if (masterCopySettings) {
      if (Array.isArray(masterCopySettings.selectedSlaveIds)) {
        const direct = masterCopySettings.selectedSlaveIds.filter((id: string) => validIds.has(id));
        if (direct.length > 0 || masterCopySettings.selectedSlaveIds.length === 0) {
          return Array.from(new Set<string>(direct));
        }
      }
      const combined = [
        ...(Array.isArray(masterCopySettings.accessSlaveIds) ? masterCopySettings.accessSlaveIds : []),
        ...(Array.isArray(masterCopySettings.ipSlaveIds) ? masterCopySettings.ipSlaveIds : []),
        ...(Array.isArray(masterCopySettings.rotationSlaveIds) ? masterCopySettings.rotationSlaveIds : []),
        ...(Array.isArray(masterCopySettings.logoutSlaveIds) ? masterCopySettings.logoutSlaveIds : []),
      ].filter((id: string) => validIds.has(id));
      if (combined.length > 0) {
        return Array.from(new Set<string>(combined));
      }
    }
    const syncedSlaves = slaveAgents
      .filter((s: any) => s.master_sync_policy === 'forever' || s.master_sync_policy === 'one_time')
      .map((s: any) => s.id);
    if (syncedSlaves.length > 0) {
      return syncedSlaves;
    }
    return isViewOnly ? [] : slaveAgents.map((s: any) => s.id);
  };

  const [selectedSlaveIds, setSelectedSlaveIds] = useState<string[]>(() => resolvePersistedSlaveIds());
  const [syncPolicy, setSyncPolicy] = useState<'one_time' | 'forever'>(() =>
    masterCopySettings?.syncPolicy === 'one_time' ? 'one_time' : 'forever'
  );
  const [copyAccessManagement, setCopyAccessManagement] = useState<boolean>(() =>
    Boolean(masterCopySettings?.copyAccessManagement)
  );
  const [copyAccountIps, setCopyAccountIps] = useState<boolean>(() =>
    Boolean(masterCopySettings?.copyAccountIps)
  );
  const [copyApiKeyRotation, setCopyApiKeyRotation] = useState<boolean>(() =>
    Boolean(masterCopySettings?.copyApiKeyRotation)
  );
  const [copyGlobalLogout, setCopyGlobalLogout] = useState<boolean>(() =>
    Boolean(masterCopySettings?.copyGlobalLogout)
  );
  const [syncSuccessMsg, setSyncSuccessMsg] = useState<string | null>(null);
  const [syncErrorMsg, setSyncErrorMsg] = useState<string | null>(null);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [isSpogModalOpen, setIsSpogModalOpen] = useState(false);
  const [spogSearchQuery, setSpogSearchQuery] = useState('');

  const isInitializedRef = React.useRef(false);

  useEffect(() => {
    if (isInitializedRef.current || !masterCopySettings) return;
    isInitializedRef.current = true;
    setSelectedSlaveIds(resolvePersistedSlaveIds());
    setSyncPolicy(masterCopySettings?.syncPolicy === 'one_time' ? 'one_time' : 'forever');
    setCopyAccessManagement(Boolean(masterCopySettings?.copyAccessManagement));
    setCopyAccountIps(Boolean(masterCopySettings?.copyAccountIps));
    setCopyApiKeyRotation(Boolean(masterCopySettings?.copyApiKeyRotation));
    setCopyGlobalLogout(Boolean(masterCopySettings?.copyGlobalLogout));
  }, [masterCopySettings, slaveAgents]);

  const handleApplyToSlave = async () => {
    if (isViewOnly || isSyncing) return;
    setSyncErrorMsg(null);
    setSyncSuccessMsg(null);
    const selectedModules = [];
    if (copyAccessManagement) selectedModules.push('Access Management');
    if (copyAccountIps) selectedModules.push('Network Whitelist IPs');
    if (copyApiKeyRotation) selectedModules.push('API Key Rotation');
    if (copyGlobalLogout) selectedModules.push('Global Logout');

    if (selectedModules.length === 0) {
      setSyncErrorMsg('Please select at least one configuration module to copy.');
      setTimeout(() => setSyncErrorMsg(null), 3500);
      return;
    }

    if (selectedSlaveIds.length === 0) {
      setSyncErrorMsg('Please select at least one target slave agent.');
      setTimeout(() => setSyncErrorMsg(null), 3500);
      return;
    }

    setIsSyncing(true);
    try {
      const res = await apiFetch('/api/auth/master/copy-settings', {
        method: 'POST',
        authType: 'human',
        body: JSON.stringify({
          slaveAgentIds: selectedSlaveIds,
          syncPolicy,
          copyAccessManagement,
          copyAccountIps,
          copyApiKeyRotation,
          copyGlobalLogout
        })
      });

      if (res && res.success) {
        const keepAccessActive = Boolean(copyAccessManagement) && syncPolicy === 'forever';
        const keepIpActive = Boolean(copyAccountIps) && syncPolicy === 'forever';
        const savedSettings = res?.data?.masterCopySettings || {
          syncPolicy,
          copyAccessManagement: keepAccessActive,
          copyAccountIps: keepIpActive,
          copyApiKeyRotation,
          copyGlobalLogout,
          selectedSlaveIds,
          accessSlaveIds: keepAccessActive ? selectedSlaveIds : [],
          accessSyncPolicy: keepAccessActive ? syncPolicy : null,
          ipSlaveIds: keepIpActive ? selectedSlaveIds : [],
          ipSyncPolicy: keepIpActive ? syncPolicy : null,
          rotationSlaveIds: copyApiKeyRotation ? selectedSlaveIds : [],
          rotationSyncPolicy: copyApiKeyRotation ? syncPolicy : null,
          logoutSlaveIds: copyGlobalLogout ? selectedSlaveIds : [],
          logoutSyncPolicy: copyGlobalLogout ? syncPolicy : null,
          updatedAt: new Date().toISOString(),
        };
        hasEditedRef.current = false;
        onSynced?.(savedSettings);
        window.dispatchEvent(new CustomEvent('aamarva-copy-master-updated', { detail: savedSettings }));
        setSyncSuccessMsg(res.message || `Successfully synced configurations to ${selectedSlaveIds.length} slave agents.`);
        setTimeout(() => {
          setSyncSuccessMsg(null);
          onClose();
        }, 1800);
      } else {
        throw new Error(res?.error?.message || 'Failed to sync configurations.');
      }
    } catch (err: any) {
      setSyncErrorMsg(`Failed to sync: ${err.message || 'Unknown error'}`);
      setTimeout(() => setSyncErrorMsg(null), 4000);
    } finally {
      setIsSyncing(false);
    }
  };

  const lastCommitBadgeText = formatLastCommitDate(masterCopySettings?.updatedAt);

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
      <div className="relative w-full max-w-md max-h-[88vh] bg-white border-2 border-[#141414] shadow-[8px_8px_0px_0px_rgba(20,20,20,1)] text-[#141414] flex flex-col overflow-hidden animate-in zoom-in-95 duration-200 font-mono">
        {/* Header */}
        <div className="bg-[#141414] text-white px-4 py-3 flex items-center justify-between border-b-2 border-[#141414] select-none shrink-0">
          <div className="flex items-center gap-2">
            <Copy className="w-4 h-4 text-white" />
            <span className="text-xs font-black uppercase tracking-wider">
              Copy Master Settings
            </span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 bg-white text-[#141414] border border-[#141414] hover:bg-black hover:text-white transition-colors cursor-pointer"
            title="Close"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 sm:p-5 space-y-4 text-left overflow-y-auto flex-1">
          {isViewOnly && (
            <div className="p-2.5 bg-[#F5F4F0] border-2 border-[#141414] flex items-center gap-2 text-[10px] font-bold text-[#141414] shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]">
              <Lock className="w-3.5 h-3.5 shrink-0" />
              <span>View-only mode. Only the Pioneer Master account can modify or commit Copy Master settings.</span>
            </div>
          )}

          {/* Master Details Card */}
          <div className="border-2 border-[#141414] p-3.5 space-y-3 bg-[#FAFAFA] shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]">
            <div className="flex items-center justify-between border-b border-[#141414]/15 pb-1 gap-2 flex-wrap">
              <div className="text-[9px] font-black uppercase text-neutral-500 tracking-wider">
                Source Master Profile
              </div>
              <span className="px-1.5 py-0.5 bg-[#141414] text-white text-[8.5px] font-mono font-black uppercase border border-[#141414] shadow-[1px_1px_0px_0px_rgba(20,20,20,1)]">
                LAST COMMIT: {lastCommitBadgeText}
              </span>
            </div>

            <div className="flex items-center justify-between gap-3 bg-white p-2.5 border-2 border-[#141414]">
              <div className="flex items-center gap-3 min-w-0">
                <AgentAvatar
                  name={masterAgent?.name || 'Master Agent'}
                  avatar={masterAgent?.avatar}
                  id={masterAgent?.agentId || masterAgent?.id}
                  className="w-11 h-11 rounded-none border-2 border-[#141414] shrink-0"
                />
                <div className="min-w-0">
                  <span className="text-xs font-black uppercase text-[#141414] block truncate">
                    {masterAgent?.name || 'Master Agent'}
                  </span>
                  <span className="text-[10px] font-mono font-bold text-[#141414] block truncate mt-0.5">
                    @{masterAgent?.agentId}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Synchronization Strategy */}
          <div className="border-2 border-[#141414] p-3.5 space-y-2.5 bg-[#FAFAFA] shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]">
            <div className="text-[10px] font-black uppercase text-[#141414] border-b border-[#141414] pb-1">
              Synchronization Strategy
            </div>

            <div className="grid grid-cols-2 gap-2 pt-0.5">
              <div
                onClick={() => { if (!isViewOnly) { hasEditedRef.current = true; setSyncPolicy('one_time'); } }}
                className={`p-2.5 border-2 border-[#141414] text-left transition-all ${
                  isViewOnly ? 'cursor-default' : 'cursor-pointer'
                } ${
                  syncPolicy === 'one_time'
                    ? 'bg-[#141414] text-white shadow-[2px_2px_0px_0px_rgba(20,20,20,0.3)]'
                    : `bg-white text-[#141414] ${isViewOnly ? '' : 'hover:bg-neutral-100'}`
                }`}
              >
                <div className="flex items-center justify-between gap-1">
                  <span className="text-xs font-black uppercase">One-Time Copy</span>
                  <div className={`w-3.5 h-3.5 rounded-full border-2 flex items-center justify-center shrink-0 ${
                    syncPolicy === 'one_time' ? 'border-white bg-white text-[#141414]' : 'border-[#141414] bg-white'
                  }`}>
                    {syncPolicy === 'one_time' && <Check className="w-2.5 h-2.5 text-[#141414] stroke-[3]" />}
                  </div>
                </div>
                <p className={`text-[9px] font-sans mt-1 leading-tight ${
                  syncPolicy === 'one_time' ? 'text-white/80' : 'text-neutral-600'
                }`}>
                  Snapshot copy once. No future automatic updates or obligations.
                </p>
              </div>

              <div
                onClick={() => { if (!isViewOnly) { hasEditedRef.current = true; setSyncPolicy('forever'); } }}
                className={`p-2.5 border-2 border-[#141414] text-left transition-all ${
                  isViewOnly ? 'cursor-default' : 'cursor-pointer'
                } ${
                  syncPolicy === 'forever'
                    ? 'bg-[#141414] text-white shadow-[2px_2px_0px_0px_rgba(20,20,20,0.3)]'
                    : `bg-white text-[#141414] ${isViewOnly ? '' : 'hover:bg-neutral-100'}`
                }`}
              >
                <div className="flex items-center justify-between gap-1">
                  <span className="text-xs font-black uppercase flex items-center gap-1">
                    <span>Copy Forever</span>
                    <span className="px-1 py-0.2 bg-white text-[#141414] text-[7px] font-black uppercase border border-white">
                      LIVE
                    </span>
                  </span>
                  <div className={`w-3.5 h-3.5 rounded-full border-2 flex items-center justify-center shrink-0 ${
                    syncPolicy === 'forever' ? 'border-white bg-white text-[#141414]' : 'border-[#141414] bg-white'
                  }`}>
                    {syncPolicy === 'forever' && <Check className="w-2.5 h-2.5 text-[#141414] stroke-[3]" />}
                  </div>
                </div>
                <p className={`text-[9px] font-sans mt-1 leading-tight ${
                  syncPolicy === 'forever' ? 'text-white/80' : 'text-neutral-600'
                }`}>
                  Continuous mirror. Master updates instantly push to slaves.
                </p>
              </div>
            </div>
          </div>

          {/* Checklist Options */}
          <div className="border-2 border-[#141414] p-3.5 space-y-3 bg-white shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]">
            <div className="text-[10px] font-black uppercase text-[#141414] border-b border-[#141414] pb-1.5 flex items-center justify-between gap-2">
              <span>Select Configurations To Copy</span>
              {!isViewOnly && (
                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      hasEditedRef.current = true;
                      const allSelected = copyAccessManagement && copyAccountIps && copyApiKeyRotation && copyGlobalLogout;
                      setCopyAccessManagement(!allSelected);
                      setCopyAccountIps(!allSelected);
                      setCopyApiKeyRotation(!allSelected);
                      setCopyGlobalLogout(!allSelected);
                    }}
                    className="px-2 py-0.5 bg-white text-[#141414] hover:bg-[#141414] hover:text-white text-[8.5px] font-black uppercase border-2 border-[#141414] shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] active:translate-x-[1px] active:translate-y-[1px] active:shadow-none cursor-pointer transition-all"
                  >
                    {(copyAccessManagement && copyAccountIps && copyApiKeyRotation && copyGlobalLogout) ? 'Deselect All' : 'Select All'}
                  </button>
                </div>
              )}
            </div>

            <div className="space-y-2 pt-1">

              <div
                onClick={() => { if (!isViewOnly) { hasEditedRef.current = true; setCopyAccessManagement(!copyAccessManagement); } }}
                className={`p-2.5 border-2 border-[#141414] flex items-start gap-2.5 transition-all ${
                  isViewOnly ? 'cursor-default' : 'cursor-pointer'
                } ${
                  copyAccessManagement
                    ? 'bg-[#FAFAFA] shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]'
                    : (isViewOnly ? 'bg-white' : 'bg-neutral-50 opacity-60')
                }`}
              >
                <input
                  type="checkbox"
                  checked={copyAccessManagement}
                  readOnly={isViewOnly}
                  onChange={(e) => { if (!isViewOnly) { hasEditedRef.current = true; setCopyAccessManagement(e.target.checked); } }}
                  className={`w-4 h-4 accent-black mt-0.5 ${isViewOnly ? 'cursor-default pointer-events-none' : 'cursor-pointer'}`}
                />
                <div className="min-w-0 flex-1">
                  <div className="text-xs font-black uppercase text-[#141414]">Access Management</div>
                  <p className="text-[9.5px] text-neutral-600 font-sans mt-0.5 leading-tight">
                    Operator authority rules, WebAuthn passkey policy, and security scope.
                  </p>
                </div>
              </div>

              <div
                onClick={() => { if (!isViewOnly) { hasEditedRef.current = true; setCopyAccountIps(!copyAccountIps); } }}
                className={`p-2.5 border-2 border-[#141414] flex items-start gap-2.5 transition-all ${
                  isViewOnly ? 'cursor-default' : 'cursor-pointer'
                } ${
                  copyAccountIps
                    ? 'bg-[#FAFAFA] shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]'
                    : (isViewOnly ? 'bg-white' : 'bg-neutral-50 opacity-60')
                }`}
              >
                <input
                  type="checkbox"
                  checked={copyAccountIps}
                  readOnly={isViewOnly}
                  onChange={(e) => { if (!isViewOnly) { hasEditedRef.current = true; setCopyAccountIps(e.target.checked); } }}
                  className={`w-4 h-4 accent-black mt-0.5 ${isViewOnly ? 'cursor-default pointer-events-none' : 'cursor-pointer'}`}
                />
                <div className="min-w-0 flex-1">
                  <div className="text-xs font-black uppercase text-[#141414]">Network Whitelist IPs</div>
                  <p className="text-[9.5px] text-neutral-600 font-sans mt-0.5 leading-tight">
                    Whitelisted IP addresses and network perimeter firewall rules.
                  </p>
                </div>
              </div>

              <div
                onClick={() => { if (!isViewOnly) { hasEditedRef.current = true; setCopyApiKeyRotation(!copyApiKeyRotation); } }}
                className={`p-2.5 border-2 border-[#141414] flex items-start gap-2.5 transition-all ${
                  isViewOnly ? 'cursor-default' : 'cursor-pointer'
                } ${
                  copyApiKeyRotation
                    ? 'bg-[#FAFAFA] shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]'
                    : (isViewOnly ? 'bg-white' : 'bg-neutral-50 opacity-60')
                }`}
              >
                <input
                  type="checkbox"
                  checked={copyApiKeyRotation}
                  readOnly={isViewOnly}
                  onChange={(e) => { if (!isViewOnly) { hasEditedRef.current = true; setCopyApiKeyRotation(e.target.checked); } }}
                  className={`w-4 h-4 accent-black mt-0.5 ${isViewOnly ? 'cursor-default pointer-events-none' : 'cursor-pointer'}`}
                />
                <div className="min-w-0 flex-1">
                  <div className="text-xs font-black uppercase text-[#141414]">API Key Rotation</div>
                  <p className="text-[9.5px] text-neutral-600 font-sans mt-0.5 leading-tight">
                    Automatic API key rotation policies, credential rotation sync, and key security governance.
                  </p>
                </div>
              </div>

              <div
                onClick={() => { if (!isViewOnly) { hasEditedRef.current = true; setCopyGlobalLogout(!copyGlobalLogout); } }}
                className={`p-2.5 border-2 border-[#141414] flex items-start gap-2.5 transition-all ${
                  isViewOnly ? 'cursor-default' : 'cursor-pointer'
                } ${
                  copyGlobalLogout
                    ? 'bg-[#FAFAFA] shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]'
                    : (isViewOnly ? 'bg-white' : 'bg-neutral-50 opacity-60')
                }`}
              >
                <input
                  type="checkbox"
                  checked={copyGlobalLogout}
                  readOnly={isViewOnly}
                  onChange={(e) => { if (!isViewOnly) { hasEditedRef.current = true; setCopyGlobalLogout(e.target.checked); } }}
                  className={`w-4 h-4 accent-black mt-0.5 ${isViewOnly ? 'cursor-default pointer-events-none' : 'cursor-pointer'}`}
                />
                <div className="min-w-0 flex-1">
                  <div className="text-xs font-black uppercase text-[#141414]">Global Logout (Force Logout Selected)</div>
                  <p className="text-[9.5px] text-neutral-600 font-sans mt-0.5 leading-tight">
                    {syncPolicy === 'one_time'
                      ? 'Arms a one-time cascade: your next Master Global Logout will also terminate all sessions and tokens for selected slaves, then turn off.'
                      : 'Instantly terminate all active sessions, access tokens, and refresh tokens for selected slave agents upon sync and on every Master Global Logout.'}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Target Specific Slave Agent Selection */}
          {slaveAgents.length > 0 && (
            <div className="border-2 border-[#141414] p-3.5 space-y-3 bg-white shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]">
              <div className="flex items-center justify-between border-b border-[#141414] pb-1.5 gap-2">
                <div className="text-[10px] font-black uppercase text-[#141414]">
                  Target Specific Slave Agents
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => setIsSpogModalOpen(true)}
                    className="px-2 py-0.5 bg-white text-[#141414] hover:bg-[#141414] hover:text-white text-[8.5px] font-black uppercase border-2 border-[#141414] shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] active:translate-x-[1px] active:translate-y-[1px] active:shadow-none cursor-pointer transition-all"
                  >
                    SPOG
                  </button>
                  {!isViewOnly && (
                    <button
                      type="button"
                      onClick={() => {
                        hasEditedRef.current = true;
                        if (selectedSlaveIds.length === slaveAgents.length) {
                          setSelectedSlaveIds([]);
                        } else {
                          setSelectedSlaveIds(slaveAgents.map((s: any) => s.id));
                        }
                      }}
                      className="px-2 py-0.5 bg-white text-[#141414] hover:bg-[#141414] hover:text-white text-[8.5px] font-black uppercase border-2 border-[#141414] shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] active:translate-x-[1px] active:translate-y-[1px] active:shadow-none cursor-pointer transition-all"
                    >
                      {selectedSlaveIds.length === slaveAgents.length ? 'Deselect All' : 'Select All'}
                    </button>
                  )}
                </div>
              </div>

              <div className="space-y-2 max-h-[195px] overflow-y-auto pr-1 scrollbar-thin scrollbar-thumb-[#141414] scrollbar-track-neutral-100">
                {slaveAgents.map((sub: any) => {
                  const isSelected = selectedSlaveIds.includes(sub.id);
                  return (
                    <div
                      key={sub.id}
                      onClick={() => {
                        if (isViewOnly) return;
                        hasEditedRef.current = true;
                        if (isSelected) {
                          setSelectedSlaveIds(selectedSlaveIds.filter(id => id !== sub.id));
                        } else {
                          setSelectedSlaveIds([...selectedSlaveIds, sub.id]);
                        }
                      }}
                      className={`p-2.5 border-2 border-[#141414] transition-all flex items-center justify-between gap-3 ${
                        isViewOnly ? 'cursor-default' : 'cursor-pointer'
                      } ${
                        isSelected
                          ? 'bg-[#141414] text-white shadow-[2px_2px_0px_0px_rgba(20,20,20,0.3)]'
                          : `bg-white text-[#141414] ${isViewOnly ? '' : 'hover:bg-neutral-50 opacity-60'}`
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <AgentAvatar
                          name={sub.name || 'Slave Agent'}
                          avatar={sub.avatar}
                          id={sub.agentId || sub.id}
                          className="w-8.5 h-8.5 rounded-none border border-[#141414] shrink-0"
                        />
                        <div className="min-w-0">
                          <span className="text-xs font-black uppercase block truncate">
                            {sub.name || 'Slave Agent'}
                          </span>
                          <span className={`text-[10px] font-mono font-bold block truncate ${
                            isSelected ? 'text-white/80' : 'text-neutral-600'
                          }`}>
                            @{sub.agentId}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          readOnly
                          onChange={() => {}}
                          className={`w-4 h-4 accent-black ${isViewOnly ? 'cursor-default pointer-events-none' : 'cursor-pointer'}`}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>

              {!isViewOnly && (
                <button
                  type="button"
                  onClick={handleApplyToSlave}
                  disabled={isSyncing}
                  className="w-full py-2.5 bg-[#141414] text-white hover:bg-black disabled:opacity-60 text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer border-2 border-[#141414] shadow-[2px_2px_0px_0px_rgba(20,20,20,0.3)] active:translate-x-[1px] active:translate-y-[1px]"
                >
                  {isSyncing
                    ? 'Committing Settings...'
                    : `Commit Settings To ${selectedSlaveIds.length} Selected Slave${selectedSlaveIds.length === 1 ? '' : 's'}`}
                </button>
              )}
            </div>
          )}

          {syncErrorMsg && (
            <div className="p-2 bg-red-600 text-white border-2 border-red-900 text-[10px] font-bold uppercase text-center flex items-center justify-center gap-1.5">
              <X className="w-3.5 h-3.5 text-white shrink-0" />
              <span>{syncErrorMsg}</span>
            </div>
          )}

          {syncSuccessMsg && (
            <div className="p-2 bg-[#141414] text-white text-[10px] font-bold uppercase text-center flex items-center justify-center gap-1">
              <Check className="w-3.5 h-3.5 text-white shrink-0" />
              <span>{syncSuccessMsg}</span>
            </div>
          )}
        </div>
      </div>

      {/* SPOG - Slave Selection Protocol Modal */}
      {isSpogModalOpen && (
        <div className="fixed inset-0 z-[60] overflow-y-auto bg-black/80 backdrop-blur-xs p-3 sm:p-6 flex items-center justify-center animate-in fade-in duration-200 font-mono">
          <div className="relative w-full max-w-5xl bg-white border-4 border-[#141414] shadow-[12px_12px_0px_0px_rgba(20,20,20,1)] text-[#141414] max-h-[92vh] flex flex-col">
            {/* Modal Header */}
            <div className="bg-[#141414] text-white px-4 py-3 flex items-center justify-between border-b-4 border-[#141414] select-none shrink-0">
              <div className="flex items-center gap-2">
                <span className="text-xs font-black uppercase tracking-widest">
                  SPOG - FLEET OVERVIEW ({slaveAgents.length} SLAVE ACCOUNTS)
                </span>
                {isViewOnly && (
                  <span className="px-1.5 py-0.5 bg-white text-[#141414] text-[8.5px] font-black uppercase tracking-wider border border-white">
                    View Only
                  </span>
                )}
              </div>
              <button
                type="button"
                onClick={() => setIsSpogModalOpen(false)}
                className="p-1 bg-white text-[#141414] border-2 border-white hover:bg-black hover:text-white transition-colors cursor-pointer"
                title="Close modal"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Slave Selection Protocol Subheader */}
            <div className="bg-[#F5F4F0] px-4 py-2.5 border-b-2 border-[#141414] flex flex-wrap items-center justify-between gap-2 shrink-0">
              <div className="flex items-center gap-3 flex-wrap">
                <span className="text-xs font-black uppercase tracking-wider text-[#141414]">
                  Slave Selection Protocol
                </span>
                {!isViewOnly && (
                  <div className="flex items-center gap-1.5 p-1 bg-white border border-[#141414]/20 shadow-inner">
                    <button
                      type="button"
                      onClick={() => {
                        hasEditedRef.current = true;
                        setSelectedSlaveIds(slaveAgents.map((s: any) => s.id));
                      }}
                      className="text-[9px] font-black uppercase border-2 border-[#141414] px-2 py-0.5 bg-white hover:bg-[#141414] hover:text-white transition-all cursor-pointer"
                    >
                      Select All
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        hasEditedRef.current = true;
                        setSelectedSlaveIds([]);
                      }}
                      className="text-[9px] font-black uppercase border-2 border-[#141414] px-2 py-0.5 bg-white hover:bg-[#141414] hover:text-white transition-all cursor-pointer"
                    >
                      Deselect All
                    </button>
                  </div>
                )}
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  placeholder="Search Slave"
                  value={spogSearchQuery}
                  onChange={(e) => setSpogSearchQuery(e.target.value)}
                  className="px-2.5 py-1 text-xs font-bold uppercase bg-white border-2 border-[#141414] focus:outline-hidden"
                />
              </div>
            </div>

            {/* Slave Grid Body */}
            <div className="p-4 sm:p-6 overflow-y-auto flex-1">
              {(() => {
                const filteredSlaves = slaveAgents.filter((sub: any) => {
                  if (!spogSearchQuery.trim()) return true;
                  const query = spogSearchQuery.toLowerCase();
                  const name = (sub.name || '').toLowerCase();
                  const agentId = (sub.agentId || '').toLowerCase();
                  return name.includes(query) || agentId.includes(query);
                });

                if (filteredSlaves.length === 0) {
                  return (
                    <div className="p-8 border-2 border-dashed border-[#141414]/30 text-center text-xs font-bold text-[#141414]/60 uppercase tracking-widest bg-neutral-50">
                      {slaveAgents.length === 0 ? 'No slave agents deployed' : 'No slave agents match search query'}
                    </div>
                  );
                }

                return (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
                    {filteredSlaves.map((sub: any) => {
                      const isSelected = selectedSlaveIds.includes(sub.id);
                      return (
                        <div
                          key={sub.id}
                          onClick={() => {
                            if (isViewOnly) return;
                            hasEditedRef.current = true;
                            if (isSelected) {
                              setSelectedSlaveIds(selectedSlaveIds.filter((id) => id !== sub.id));
                            } else {
                              setSelectedSlaveIds([...selectedSlaveIds, sub.id]);
                            }
                          }}
                          className={`p-2.5 border-2 border-[#141414] shadow-[3px_3px_0px_0px_rgba(20,20,20,1)] flex flex-col justify-between gap-2 transition-all ${
                            isViewOnly ? 'cursor-default' : 'cursor-pointer'
                          } ${
                            isSelected ? 'bg-[#141414] text-white' : `bg-white text-[#141414] ${isViewOnly ? '' : 'hover:bg-neutral-50'}`
                          }`}
                        >
                          <div className="flex items-center gap-2 min-w-0">
                            <AgentAvatar
                              name={sub.name || 'Slave Agent'}
                              avatar={sub.avatar}
                              id={sub.agentId || sub.id}
                              className="w-8 h-8 rounded-none border border-[#141414] shrink-0"
                            />
                            <div className="min-w-0">
                              <p className="text-xs font-black uppercase truncate">
                                {sub.name || 'Slave Agent'}
                              </p>
                              <p className={`text-[10px] font-mono truncate ${isSelected ? 'text-white/70' : 'text-[#141414]/70'}`}>
                                @{sub.agentId}
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center justify-end pt-2 border-t border-[#141414]/15">
                            <div
                              className={`w-4 h-4 border-2 ${
                                isSelected ? 'border-white bg-white text-[#141414]' : 'border-[#141414] bg-white'
                              } flex items-center justify-center font-mono text-xs`}
                            >
                              {isSelected ? '✓' : ''}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                );
              })()}
            </div>

            {/* Footer */}
            <div className="bg-[#141414] text-white p-4 shrink-0">
              <button
                type="button"
                onClick={() => setIsSpogModalOpen(false)}
                className="w-full bg-white text-[#141414] py-3 font-black uppercase text-xs sm:text-sm tracking-widest border-2 border-white hover:bg-neutral-200 transition-colors cursor-pointer"
              >
                {isViewOnly ? 'CLOSE' : 'APPLY SELECTION & CLOSE'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
