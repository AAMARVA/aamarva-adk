import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Play, Pause, Download, AlertTriangle, Volume2 } from 'lucide-react';
import { getEncryptedAttachmentApi } from '../services/authApi';
import { decryptAttachmentFile, getLocalKeyPair, getAllLocalEpochKeys } from '../lib/e2ee';
import { fetchConnectionPeerKey } from '../lib/e2eePrefetch';
import { useAuth } from '../context/AuthContext';

export interface VoiceMessagePayload {
  aamarva_attachment?: boolean;
  isVoiceMessage?: boolean;
  attachmentId?: string;
  filename?: string;
  size?: number;
  mimeType?: string;
  duration?: number;
  audioBase64?: string;
  text?: string;
}

interface VoiceMessagePlayerProps {
  payload: VoiceMessagePayload;
  isCurrentUser: boolean;
  connectionId?: string;
  senderAgentId?: string;
  keyEpoch?: number;
  localPrivateKey?: CryptoKey | string | null;
  senderPublicKey?: string | null;
  effectiveAuthType?: 'human' | 'agent';
}

function formatDuration(seconds: number): string {
  if (isNaN(seconds) || seconds < 0) return '00:00';
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

export const VoiceMessagePlayer: React.FC<VoiceMessagePlayerProps> = ({
  payload,
  isCurrentUser,
  connectionId,
  senderAgentId,
  keyEpoch = 1,
  localPrivateKey,
  senderPublicKey,
  effectiveAuthType = 'human',
}) => {
  const { user, userPassword } = useAuth();
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(payload.duration || 0);
  const [isDecrypting, setIsDecrypting] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const isMountedRef = useRef(true);

  useEffect(() => {
    isMountedRef.current = true;
    return () => {
      isMountedRef.current = false;
      if (audioUrl) {
        URL.revokeObjectURL(audioUrl);
      }
    };
  }, [audioUrl]);

  // If payload includes direct audioBase64 (e.g. from local optimistic message or cluster message)
  useEffect(() => {
    if (payload.audioBase64 && !audioUrl) {
      try {
        const sanitized = payload.audioBase64.replace(/\s/g, '').replace(/-/g, '+').replace(/_/g, '/');
        const byteCharacters = atob(sanitized);
        const byteArray = new Uint8Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
          byteArray[i] = byteCharacters.charCodeAt(i);
        }
        const cleanType = (payload.mimeType?.split(';')[0] || 'audio/webm').trim().toLowerCase();
        const blob = new Blob([byteArray], { type: cleanType || 'audio/webm' });
        const url = URL.createObjectURL(blob);
        setAudioUrl(url);
      } catch (err) {
        console.error('Failed to parse embedded audio:', err);
      }
    }
  }, [payload.audioBase64, payload.mimeType, audioUrl]);

  // Ensure DOM audio element stays synchronized with audioUrl
  useEffect(() => {
    const audio = audioRef.current;
    if (audio) {
      if (audioUrl) {
        if (audio.src !== audioUrl) {
          audio.src = audioUrl;
        }
        if (audio.readyState === 0) {
          audio.load();
        }
      } else {
        if (audio.src) {
          audio.removeAttribute('src');
        }
      }
    }
  }, [audioUrl]);

  const decryptAudio = useCallback(async (): Promise<string> => {
    if (audioUrl) return audioUrl;

    // Fast-path: if audioBase64 is directly present on payload, decode directly without network request
    if (payload.audioBase64) {
      try {
        const sanitized = payload.audioBase64.replace(/\s/g, '').replace(/-/g, '+').replace(/_/g, '/');
        const byteCharacters = atob(sanitized);
        const byteArray = new Uint8Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
          byteArray[i] = byteCharacters.charCodeAt(i);
        }
        const cleanType = (payload.mimeType?.split(';')[0] || 'audio/webm').trim().toLowerCase();
        const blob = new Blob([byteArray], { type: cleanType || 'audio/webm' });
        const url = URL.createObjectURL(blob);
        if (isMountedRef.current) {
          setAudioUrl(url);
        }
        return url;
      } catch (e) {
        console.error('Embedded audio decoding notice:', e);
      }
    }

    if (!payload.attachmentId || !connectionId) {
      throw new Error('Voice audio payload unavailable.');
    }

    setIsDecrypting(true);
    setError(null);

    try {
      const authTypeArg: 'human' | 'agent' = effectiveAuthType === 'agent' ? 'agent' : 'human';
      const res = await getEncryptedAttachmentApi(connectionId, payload.attachmentId, authTypeArg);
      if (!res?.success || !res?.data) {
        throw new Error(res?.error?.message || 'Failed to retrieve encrypted voice payload from server.');
      }

      const encryptedRecord = res.data;

      const localKeyCandidates: (CryptoKey | string)[] = [];
      const addLocalCand = (k?: CryptoKey | string | null) => {
        if (k && !localKeyCandidates.includes(k)) localKeyCandidates.push(k);
      };
      addLocalCand(localPrivateKey);
      if (user?.agentId) {
        try {
          const kp = await getLocalKeyPair(user.agentId, keyEpoch, userPassword || undefined);
          addLocalCand(kp?.privateKey);
          const allLocal = await getAllLocalEpochKeys(user.agentId);
          for (const entry of allLocal) {
            addLocalCand(entry.privateKey);
          }
        } catch {}
      }
      if (localKeyCandidates.length === 0) {
        throw new Error('Local private key unavailable for voice decryption.');
      }

      const peerKeyCandidates: string[] = [];
      const addPeerCand = (pk?: any) => {
        if (!pk) return;
        const s = typeof pk === 'string' ? pk : JSON.stringify(pk);
        if (s && !peerKeyCandidates.includes(s)) peerKeyCandidates.push(s);
      };
      addPeerCand(senderPublicKey);

      const loadPeerKeys = async (forceRefresh: boolean) => {
        if (!connectionId) return;
        try {
          const peerInfo = await fetchConnectionPeerKey(connectionId, {
            receiverAgentId: senderAgentId,
            authType: authTypeArg,
            forceRefresh,
            bypassCooldown: forceRefresh,
          });
          addPeerCand(peerInfo?.peerPublicKey);
          if (peerInfo?.peerEpochKeys && typeof peerInfo.peerEpochKeys === 'object') {
            if (keyEpoch && peerInfo.peerEpochKeys[String(keyEpoch)]?.publicKey) {
              addPeerCand(peerInfo.peerEpochKeys[String(keyEpoch)].publicKey);
            }
            for (const epData of Object.values(peerInfo.peerEpochKeys)) {
              addPeerCand((epData as any)?.publicKey);
            }
          }
        } catch {}
      };

      if (peerKeyCandidates.length === 0) {
        await loadPeerKeys(false);
      }
      if (peerKeyCandidates.length === 0) {
        throw new Error('Peer public key unavailable for voice message decryption.');
      }

      let decrypted: Awaited<ReturnType<typeof decryptAttachmentFile>> | null = null;
      let lastErr: any = null;
      const attemptDecrypt = async () => {
        for (const privCand of localKeyCandidates) {
          for (const pubCand of peerKeyCandidates) {
            try {
              decrypted = await decryptAttachmentFile(
                encryptedRecord,
                privCand,
                pubCand,
                connectionId,
                senderAgentId || 'peer'
              );
              return;
            } catch (err) {
              lastErr = err;
            }
          }
        }
      };

      await attemptDecrypt();
      if (!decrypted) {
        await loadPeerKeys(true);
        await attemptDecrypt();
      }
      if (!decrypted) {
        throw lastErr || new Error('Voice message decryption failed.');
      }

      // Ensure decrypted Blob has a clean standard audio container MIME type for Chrome playback
      const cleanType = (decrypted.mimeType?.split(';')[0] || 'audio/webm').trim().toLowerCase();
      let playBlob = decrypted.blob;
      if (!playBlob || playBlob.type !== cleanType) {
        playBlob = new Blob([decrypted.data], { type: cleanType });
      }

      const url = URL.createObjectURL(playBlob);
      if (isMountedRef.current) {
        setAudioUrl(url);
      }
      return url;
    } finally {
      if (isMountedRef.current) {
        setIsDecrypting(false);
      }
    }
  }, [audioUrl, payload.attachmentId, connectionId, effectiveAuthType, localPrivateKey, user?.agentId, keyEpoch, userPassword, senderPublicKey, senderAgentId]);

  const handleLoadedMetadata = () => {
    if (audioRef.current && audioRef.current.duration && isFinite(audioRef.current.duration)) {
      setDuration(audioRef.current.duration);
    }
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
    }
  };

  const handleEnded = () => {
    setIsPlaying(false);
    setCurrentTime(0);
  };

  const handleError = (e: React.SyntheticEvent<HTMLAudioElement, Event>) => {
    const audio = audioRef.current;
    // Ignore benign error events triggered when src/currentSrc is empty, missing, uninitialized (readyState 0), or being cleared
    if (
      !audioUrl ||
      !audio ||
      !audio.src ||
      !audio.currentSrc ||
      audio.readyState === 0 ||
      audio.networkState === HTMLMediaElement.NETWORK_EMPTY
    ) {
      return;
    }
    const diag = {
      blobSize: payload.size ?? (payload.audioBase64 ? payload.audioBase64.length : 'unknown'),
      blobType: payload.mimeType ?? 'unknown',
      audioSrc: audio.src,
      audioCurrentSrc: audio.currentSrc,
      audioReadyState: audio.readyState,
      audioNetworkState: audio.networkState,
      audioDuration: audio.duration,
      audioErrorCode: audio.error?.code ?? null,
      audioErrorMessage: audio.error?.message ?? null,
    };
    console.warn('Voice player audio element error:', diag, e);
    setIsPlaying(false);
    if (isPlaying && audio.error && audio.error.code !== 0) {
      setError(audio.error.message ? `Playback error (${audio.error.code}): ${audio.error.message}` : 'Failed to play decrypted audio stream.');
    }
  };

  const togglePlay = async () => {
    setError(null);
    try {
      let url = audioUrl;
      if (!url) {
        url = await decryptAudio();
      }
      if (!url) {
        throw new Error('Audio payload decryption failed.');
      }

      const audio = audioRef.current;
      if (!audio) return;

      // Imperatively guarantee audio.src is immediately bound to DOM element and load() is called if uninitialized
      if (audio.src !== url) {
        audio.src = url;
      }
      if (audio.readyState === 0) {
        audio.load();
      }

      // Diagnostic logging before playback capturing all required fields:
      const diag = {
        blobSize: payload.size ?? (payload.audioBase64 ? payload.audioBase64.length : 'unknown'),
        blobType: payload.mimeType ?? 'unknown',
        canPlayType: audio.canPlayType(payload.mimeType || 'audio/webm'),
        audioSrc: audio.src,
        audioCurrentSrc: audio.currentSrc,
        audioReadyState: audio.readyState,
        audioNetworkState: audio.networkState,
        audioDuration: audio.duration,
        audioErrorCode: audio.error?.code ?? null,
        audioErrorMessage: audio.error?.message ?? null,
      };
      console.log('[VoiceMessagePlayer] Audio playback diagnostics:', diag);

      if (isPlaying) {
        audio.pause();
        setIsPlaying(false);
        return;
      }

      if (audio.ended || (isFinite(audio.duration) && audio.duration > 0 && audio.currentTime >= audio.duration - 0.1)) {
        audio.currentTime = 0;
      }

      await audio.play();
      setIsPlaying(true);
    } catch (err: any) {
      console.error('Audio playback error:', err);
      setIsPlaying(false);
      if (err?.name !== 'AbortError') {
        setError(err?.message || 'Failed to decrypt and play voice message.');
      }
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newTime = parseFloat(e.target.value);
    setCurrentTime(newTime);
    if (audioRef.current) {
      audioRef.current.currentTime = newTime;
    }
  };

  const handleDownload = async () => {
    try {
      const url = audioUrl || (await decryptAudio());
      const a = document.createElement('a');
      a.href = url;
      a.download = payload.filename || `voice_message_${Date.now()}.webm`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } catch (err: any) {
      setError(err?.message || 'Download failed');
    }
  };

  const effectiveDuration = duration > 0 ? duration : (payload.duration || 0);
  const progressRatio = effectiveDuration > 0 ? Math.min(1, Math.max(0, currentTime / effectiveDuration)) : 0;
  const totalBars = 32;

  // Generate deterministic, authentic speech-waveform profile for this voice note
  const waveformSeed = payload.attachmentId || payload.filename || 'voice';
  const barHeights = React.useMemo(() => {
    let hash = 0;
    for (let i = 0; i < waveformSeed.length; i++) {
      hash = (hash << 5) - hash + waveformSeed.charCodeAt(i);
      hash |= 0;
    }
    const heights: number[] = [];
    for (let i = 0; i < totalBars; i++) {
      const v1 = Math.sin((i + Math.abs(hash % 100)) * 0.45);
      const v2 = Math.cos((i * 1.2) + 0.7);
      const normalized = Math.abs((v1 + v2) / 2);
      // Heights between 4px and 18px (20% to 100% of 18px)
      heights.push(Math.round(4 + normalized * 14));
    }
    return heights;
  }, [waveformSeed]);

  const handleWaveformClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const ratio = Math.max(0, Math.min(1, clickX / rect.width));
    const targetTime = ratio * effectiveDuration;
    setCurrentTime(targetTime);
    if (audioRef.current) {
      audioRef.current.currentTime = targetTime;
    }
  };

  return (
    <div className="flex flex-col gap-1.5 font-mono text-xs select-none max-w-[280px] sm:max-w-[320px] py-0.5">
      {/* Hidden DOM-bound HTML5 audio element */}
      <audio
        ref={audioRef}
        src={audioUrl || undefined}
        preload="auto"
        onLoadedMetadata={handleLoadedMetadata}
        onTimeUpdate={handleTimeUpdate}
        onEnded={handleEnded}
        onError={handleError}
        className="hidden"
      />

      {/* WhatsApp-style voice note bubble */}
      <div className="flex items-center gap-2.5">
        {/* Left: Circular Play/Pause button */}
        <button
          type="button"
          onClick={togglePlay}
          disabled={isDecrypting}
          className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 cursor-pointer active:scale-95 transition-all shadow-sm ${
            isCurrentUser
              ? 'bg-white text-[#141414] hover:bg-neutral-200'
              : 'bg-[#141414] text-white hover:bg-neutral-800'
          }`}
          title={isDecrypting ? 'Decrypting voice message...' : isPlaying ? 'Pause' : 'Play voice message'}
        >
          {isDecrypting ? (
            <span className="inline-block w-3.5 h-3.5 border-2 border-current border-t-transparent animate-spin rounded-full" />
          ) : isPlaying ? (
            <Pause className="w-4 h-4 fill-current" />
          ) : (
            <Play className="w-4 h-4 fill-current ml-0.5" />
          )}
        </button>

        {/* Center: Waveform scrubber and duration */}
        <div className="flex-1 min-w-0 flex flex-col gap-1">
          {/* WhatsApp audio waveform track */}
          <div
            onClick={handleWaveformClick}
            className="flex items-center gap-[2.5px] h-6 cursor-pointer group py-1"
            title="Click to seek"
          >
            {barHeights.map((h, idx) => {
              const barRatio = idx / (totalBars - 1);
              const isPlayed = barRatio <= progressRatio;
              return (
                <div
                  key={idx}
                  className={`w-[2px] sm:w-[2.5px] rounded-full transition-colors duration-75 ${
                    isCurrentUser
                      ? isPlayed
                        ? 'bg-white'
                        : 'bg-white/35 group-hover:bg-white/50'
                      : isPlayed
                      ? 'bg-[#141414]'
                      : 'bg-neutral-300 group-hover:bg-neutral-400'
                  }`}
                  style={{ height: `${h}px` }}
                />
              );
            })}
          </div>

          {/* Time */}
          <div className="text-[9.5px] font-bold tabular-nums opacity-80 leading-none">
            <span>
              {isPlaying || currentTime > 0
                ? formatDuration(currentTime)
                : formatDuration(effectiveDuration)}
            </span>
          </div>
        </div>

        {/* Right: Square bordered Download button matching file attachment style */}
        <button
          type="button"
          onClick={handleDownload}
          disabled={isDecrypting}
          className={`p-1.5 border transition-all cursor-pointer flex items-center justify-center shrink-0 active:scale-95 shadow-[1px_1px_0px_0px_rgba(20,20,20,1)] ${
            isCurrentUser
              ? 'border-white bg-white text-[#141414] hover:bg-neutral-200'
              : 'border-[#141414] bg-[#141414] text-white hover:bg-neutral-800'
          }`}
          title="Download audio file"
        >
          {isDecrypting ? (
            <span className="inline-block w-3.5 h-3.5 border-2 border-current border-t-transparent animate-spin rounded-full" />
          ) : (
            <Download className="w-3.5 h-3.5" />
          )}
        </button>
      </div>

      {/* Optional accompanying message text (rendered below recording) */}
      {payload.text && (
        <div className="text-[12px] break-words mt-1 opacity-90 leading-tight">
          {payload.text}
        </div>
      )}

      {error && (
        <div className="text-[9.5px] font-mono text-red-500 opacity-90 flex items-center gap-1 mt-0.5">
          <AlertTriangle className="w-2.5 h-2.5 shrink-0" />
          <span className="truncate">{error}</span>
        </div>
      )}
    </div>
  );
};
