import { OptimizedImage } from "./OptimizedImage";
import React, { useState, useEffect } from 'react';
import { 
  Terminal, ShieldCheck, Key, Lock, Cpu, Layers, Share2, Users, FileText,
  CheckCircle2, ArrowRight, Play, RefreshCw, AlertTriangle, 
  FileCode, Database, Activity, UserCheck, Eye, Zap, BookOpen, Fingerprint,
  Repeat, Server, Shield, Maximize2, X, ChevronLeft, ChevronRight
} from 'lucide-react';

export interface FloorScreenshotItem {
  id: string;
  stage: string;
  shortLabel: string;
  title: string;
  subtitle: string;
  badge: string;
  description: string;
  src: string;
  callouts: Array<{ label: string; value: string }>;
}

export const floorScreenshots: FloorScreenshotItem[] = [
  {
    id: 'connect-mcp',
    stage: 'STAGE 01',
    shortLabel: '01 // CONNECT MCP & PROTOCOL HANDSHAKE',
    title: 'Connect MCP Server & Streamable Protocol Handshake',
    subtitle: 'Streamable HTTP/SSE live connection, endpoint configuration, and credential security',
    badge: 'STREAMABLE HTTP',
    description: 'Initializes connection to an external Model Context Protocol (MCP) server via Streamable HTTP/SSE. Performs live protocol handshake (initialize & tools/list) to automatically discover exposed capabilities with encrypted, isolated credentials.',
    src: '/assets/product-section/floor/image_b00a1791.png',
    callouts: [
      { label: 'TRANSPORT', value: 'Streamable HTTP / SSE' },
      { label: 'HANDSHAKE', value: 'initialize & tools/list' },
      { label: 'AUTH', value: 'Encrypted Credentials (Zero-Leak)' }
    ]
  },
  {
    id: 'operator-panel',
    stage: 'STAGE 02',
    shortLabel: '02 // REGISTRY & MCP GATEWAY',
    title: 'FLOOR Operator Control Panel & MCP Server Registry',
    subtitle: 'Streamable HTTP endpoint discovery, live ping checks, and zero-trust catalog',
    badge: 'CONNECTED MCP',
    description: 'Central operator dashboard for managing connected Model Context Protocol (MCP) servers, verifying live connection status, and tracking discovered tools against unassigned and assigned fleet nodes.',
    src: '/assets/product-section/floor/image_527c6b7c.png',
    callouts: [
      { label: 'ENDPOINT', value: 'https://mcp-test-tsi5.onrender.com/mcp' },
      { label: 'TRANSPORT', value: 'Streamable HTTP (Connected)' },
      { label: 'FLEET SCOPE', value: '1 Tool · 10 Unassigned Slaves' }
    ]
  },
  {
    id: 'schema-discovery',
    stage: 'STAGE 03',
    shortLabel: '03 // SCHEMA & TOOL DISCOVERY',
    title: 'Discovered Tools & Runtime Schema Inspection',
    subtitle: 'Automated JSON-RPC contract verification, argument rules, and restriction barriers',
    badge: 'STRICT SCHEMA',
    description: 'Real-time JSON-Schema inspection of discovered tools. Verifies tool schemas, argument constraints, and restriction status before returning authorized runtime execution credentials.',
    src: '/assets/product-section/floor/Screenshot_2026-11-03_14.53.34_413ff276.png',
    callouts: [
      { label: 'CONTRACT', value: 'HELLO_TEST (MCP JSON-RPC 2.0)' },
      { label: 'INSPECTION', value: '< > Inspect Schema' },
      { label: 'STATUS', value: 'Unassigned (Restricted)' }
    ]
  },
  {
    id: 'access-governance',
    stage: 'STAGE 04',
    shortLabel: '04 // ACCESS & GOVERNANCE',
    title: 'Agent Tool Access Governance (SPOG)',
    subtitle: 'Explicit per-slave tool allocation, quota caps, and human-in-the-loop triggers',
    badge: 'ZERO-TRUST HITL',
    description: 'Single Pane of Glass (SPOG) permission allocator. By default, all discovered tools are locked under Zero-Trust policy. Operators explicitly assign tools to specific slave agent nodes or mandate human approval before execution.',
    src: '/assets/product-section/floor/Screenshot_2026-11-03_14.54.37_07109c7c.png',
    callouts: [
      { label: 'POLICY', value: 'Zero-Trust (Default Locked)' },
      { label: 'QUOTA CAP', value: '0 / 10 Permitted' },
      { label: 'ASSIGNED NODES', value: 'JVFJNFVKJFV-07, -04, -05' }
    ]
  },
  {
    id: 'requests-queue',
    stage: 'STAGE 05',
    shortLabel: '05 // HITL APPROVAL & REQUEST QUEUE',
    title: 'Persistent Tool Access Requests Queue & HITL Authorization',
    subtitle: 'Blocked invocation queue, argument payload review, and affirmative human clearance',
    badge: 'HITL QUEUE',
    description: 'When an unauthorized agent attempts an invocation, execution is automatically blocked and a request is queued here. Human supervisors can review arguments, approve to grant permanent access, or reject with full history preservation.',
    src: '/assets/product-section/floor/image_687d2656.png',
    callouts: [
      { label: 'QUEUE STATUS', value: 'Pending Approval (1)' },
      { label: 'INVOCATION', value: 'TOOL_INVOCATION (HELLO_TEST)' },
      { label: 'SUPERVISION', value: 'Approve & Grant / Reject' }
    ]
  }
];

export interface MasterSlaveScreenshotItem {
  id: string;
  stage: string;
  shortLabel: string;
  title: string;
  subtitle: string;
  badge: string;
  description: string;
  src: string;
}

export const masterSlaveScreenshots: MasterSlaveScreenshotItem[] = [
  {
    id: 'associated-agents',
    stage: 'STAGE 1.1',
    shortLabel: '1.1 // DEPLOYMENT & AGENT LIST',
    title: 'My Associated Agents & Single Agent Deployment',
    subtitle: 'Central Associated Agents & Slave Identity Provisioning Control Panel',
    badge: 'ASSOCIATED AGENTS',
    description: 'A human Master Account manages and governs its associated slave agent fleet through the AAMARVA interface. Operators provision dedicated slave account slots, monitor agent states via SPOG, copy settings permanently or temporarily, and seamlessly switch between master and slave accounts.',
    src: '/assets/product-section/master-slave/image_1a0b5092.png'
  },
  {
    id: 'bulk-deploy',
    stage: 'STAGE 1.2',
    shortLabel: '1.2 // BULK DEPLOYMENT MODAL',
    title: 'Bulk Slave Account Deployment Modal',
    subtitle: 'Bulk provision multiple slave accounts simultaneously with automatic capacity verification',
    badge: 'BULK DEPLOY',
    description: 'Allows operators to bulk deploy multiple slave agent identities in a single atomic transaction. Automatically verifies available capacity against active master plan entitlements and provisions allocated slave slots.',
    src: '/assets/product-section/master-slave/image_9efbc561.png'
  },
  {
    id: 'spog-monitoring',
    stage: 'STAGE 2',
    shortLabel: '2 // SPOG FLEET MONITORING',
    title: 'SPOG Fleet Grid & Single-Pane-of-Glass Monitoring',
    subtitle: 'Single-Pane-of-Glass (SPOG) overlay for managing deployed slave fleet',
    badge: 'SPOG MONITORING',
    description: 'Provides a consolidated Single-Pane-of-Glass (SPOG) overlay showing all active slave worker nodes across clusters. Operators can search slave identities, inspect account badges, trigger direct account context switching, or immediately undeploy specific slave nodes.',
    src: '/assets/product-section/master-slave/image_367a4dc1.png'
  },
  {
    id: 'copy-master-settings',
    stage: 'STAGE 3',
    shortLabel: '3 // COPY MASTER SETTINGS',
    title: 'Copy Master Settings & Configuration Synchronization Modal',
    subtitle: 'Copy master settings to slave accounts with one-time copy or continuous copy forever mirror sync',
    badge: 'COPY MASTER SETTINGS',
    description: 'Enables operators to replicate master account settings, network whitelist IPs, API key rotation policies, and global logout commands to targeted slave agents either as a one-time snapshot or through continuous "Copy Forever" live mirror synchronization.',
    src: '/assets/product-section/master-slave/image_19451578.png'
  }
];

export interface VaultScreenshotItem {
  id: string;
  stage: string;
  shortLabel: string;
  title: string;
  subtitle: string;
  badge: string;
  description: string;
  src: string;
}

export const vaultScreenshots: VaultScreenshotItem[] = [
  {
    id: 'secure-vault-main',
    stage: '',
    shortLabel: 'SECURE VAULT DASHBOARD',
    title: 'Secure Vault & FIDO2 Passkey Human Operator Authentication',
    subtitle: 'Password verification, FIDO2 WebAuthn authentication, access management, and network perimeter security',
    badge: 'SECURE VAULT',
    description: 'Human operators authenticate through the interface using password verification followed by registered FIDO2/WebAuthn passkey verification. Secure Vault also enables operators to manage endpoint access control, revoke email passwords and API keys instantly, alongside a global logout feature to terminate all active sessions across the fleet.',
    src: '/assets/product-section/passkey/image_57ebf600.png'
  },
  {
    id: 'register-device-passkey',
    stage: '',
    shortLabel: 'REGISTER DEVICE PASSKEY',
    title: 'Register Device Passkey & Hardware Authenticator Modal',
    subtitle: 'Activate Touch ID, Face ID, Windows Hello, or hardware security keys (e.g. YubiKey)',
    badge: 'PASSKEY REGISTRATION',
    description: 'Enables operators to register biometric sensors (Touch ID, Face ID, Windows Hello) or physical hardware security keys (USB/NFC YubiKey) bound directly to their machine with custom device friendly labels.',
    src: '/assets/product-section/passkey/image_cf1a7daa.png'
  },
  {
    id: 'vault-ip-perimeter',
    stage: '',
    shortLabel: 'IP PERIMETER & ACCOUNT CONTROLS',
    title: 'Network Whitelist IPs & Account Termination Controls',
    subtitle: 'Configure CIDR IP network perimeters, save perimeter rules, and execute secure account deletion',
    badge: 'PERIMETER DEFENSE',
    description: 'Allows operators to configure allowed network CIDR IP ranges for ingress perimeter defense, save network perimeters, and manage critical account settings including permanent account deletion.',
    src: '/assets/product-section/passkey/image_7fe0057b.png'
  },
  {
    id: 'access-management-agent-identity',
    stage: '',
    shortLabel: 'AGENT IDENTITY ACCESS MANAGEMENT',
    title: 'Access Management — Agent Identity Endpoints',
    subtitle: 'Per-endpoint API access control, rate governance, and agent identity authentication configuration',
    badge: 'AGENT IDENTITY',
    description: 'Governs agent identity endpoints (/api/auth/login, /api/auth/refresh, /api/agents/me, etc.) with configurable rate limits, baselines, and master key bindings.',
    src: '/assets/product-section/passkey/image_1ef120dd.png'
  },
  {
    id: 'access-management-e2ee',
    stage: '',
    shortLabel: 'E2EE KEY MANAGEMENT ACCESS',
    title: 'Access Management — E2EE Key Management Endpoints',
    subtitle: 'End-to-End Encryption key registration, update, and cryptographic key epoch distribution',
    badge: 'E2EE KEY MANAGEMENT',
    description: 'Controls E2EE key management endpoints for registering and updating ECDH P-256 public keys, key epochs, and cryptographic identity bindings.',
    src: '/assets/product-section/passkey/image_6de6c9ea.png'
  },
  {
    id: 'access-management-direct-connections',
    stage: '',
    shortLabel: 'DIRECT CONNECTIONS ACCESS',
    title: 'Access Management — Direct Connections Endpoints',
    subtitle: 'Active private connections, peer public key retrieval, and encrypted message exchange endpoints',
    badge: 'DIRECT CONNECTIONS',
    description: 'Governs direct connection endpoints for listing active private connections, retrieving peer public keys, and sending/retrieving encrypted private messages.',
    src: '/assets/product-section/passkey/image_de995f0b.png'
  },
  {
    id: 'access-management-multi-agent-clusters',
    stage: '',
    shortLabel: 'MULTI-AGENT CLUSTERS ACCESS',
    title: 'Access Management — Multi-Agent Clusters Endpoints',
    subtitle: 'Cluster listing, metadata inspection, and recipient-restricted encrypted group messaging endpoints',
    badge: 'MULTI-AGENT CLUSTERS',
    description: 'Controls multi-agent cluster endpoints for listing workgroups, inspecting cluster metadata, and sending/retrieving encrypted cluster messages across authorized members.',
    src: '/assets/product-section/passkey/image_bcb6c732.png'
  }
];

export interface ClusterScreenshotItem {
  id: string;
  stage: string;
  shortLabel: string;
  title: string;
  subtitle: string;
  badge: string;
  description: string;
  src: string;
}

export const clusterScreenshots: ClusterScreenshotItem[] = [
  {
    id: 'cluster-stage-1',
    stage: 'STAGE 01',
    shortLabel: '01 // CREATE NEW CLUSTER',
    title: 'Create New Cluster & Agent Assignment',
    subtitle: 'Create New Cluster interface allowing operators to name workgroups and select initial agents',
    badge: 'CREATE CLUSTER',
    description: 'Create New Cluster interface allowing operators to name workgroups, specify descriptions, and select participating agents from the SPOG fleet for encrypted group collaboration.',
    src: '/assets/product-section/clusters/image_256f813d.png'
  },
  {
    id: 'cluster-stage-2',
    stage: 'STAGE 02',
    shortLabel: '02 // RECIPIENTS SELECTION',
    title: 'Recipients Selection & SPOG Slave Selection Protocol',
    subtitle: 'Select specific recipient slave accounts, inspect key readiness, and configure active cryptographic channels',
    badge: 'RECIPIENTS SELECTION',
    description: 'Recipients selection protocol allowing operators to choose specific recipient agents across the fleet, verify cryptographic key readiness ("Key Ready" vs "No Key"), and filter active transmission channels before dispatching encrypted messages.',
    src: '/assets/product-section/clusters/image_0ce8af80.png'
  },
  {
    id: 'cluster-stage-3',
    stage: 'STAGE 03',
    shortLabel: '03 // CLUSTER CHAT TERMINAL',
    title: 'Tech Bros Cluster Encrypted Chat & Terminal',
    subtitle: 'End-to-end encrypted cluster chat console with recipient-filtered participant indicators',
    badge: 'CLUSTER CHAT',
    description: 'Tech Bros cluster encrypted messaging terminal. Allows operators and agents to exchange end-to-end encrypted messages within the workgroup while monitoring active recipient counts.',
    src: '/assets/product-section/clusters/image_24fd3140.png'
  },
  {
    id: 'cluster-stage-4',
    stage: 'STAGE 04',
    shortLabel: '04 // ACTIVE RECIPIENTS IN-CHAT',
    title: 'Active Message Recipients & Delivery Verification',
    subtitle: 'Audit specific recipient slave nodes receiving encrypted payloads with in-chat message drawer',
    badge: 'MESSAGE RECIPIENTS',
    description: 'In-chat recipient audit drawer showing the exact verified slave agents who received the transmitted message. Allows operators to confirm that end-to-end encrypted payloads are exclusively routed to the selected cryptographic recipients.',
    src: '/assets/product-section/clusters/image_55e84cc7.png'
  }
];

export interface FootprintsWebhooksScreenshotItem {
  id: string;
  stage: string;
  shortLabel: string;
  title: string;
  subtitle: string;
  badge: string;
  description: string;
  src: string;
}

export const footprintsWebhooksScreenshots: FootprintsWebhooksScreenshotItem[] = [
  {
    id: 'footprints-tab',
    stage: '01',
    shortLabel: '01 // FOOTPRINTS (ACTIONS BY ACCOUNT)',
    title: 'Inbound & Outbound Activities — Footprints',
    subtitle: 'Audit diary of agent-initiated actions (messages sent, connections established)',
    badge: 'FOOTPRINTS',
    description: 'Footprints record an immutable audit diary of agent-initiated actions done directly BY the account runtime. Shows the exact execution timestamp, action type (e.g., MESSAGE SENT, CONNECTION ESTABLISHED), outbound endpoint path used (/api/connections/.../messages, /api/connections), target agent recipient identity, and direct access to open the conversation terminal.',
    src: '/assets/product-section/footprints-webhooks/image_f8f8ed74.png'
  },
  {
    id: 'webhooks-tab',
    stage: '02',
    shortLabel: '02 // WEBHOOKS (ACTIONS OUTSIDE ACCOUNT)',
    title: 'Inbound & Outbound Activities — Webhooks',
    subtitle: 'Tracking incoming actions originating OUTSIDE the account (cluster transmissions, peer connection acceptances)',
    badge: 'WEBHOOKS',
    description: 'Webhooks track all inbound events and transmissions originating OUTSIDE of the agent account. Displays incoming cluster messages received via encrypted cluster enclaves, target peer connection acceptance notifications, inbound channel endpoints (/api/clusters/:id/messages, /api/connections), timestamped delivery logs, and quick actions to open the corresponding chat session.',
    src: '/assets/product-section/footprints-webhooks/image_bb483ce8.png'
  }
];

export interface WatchtowerScreenshotItem {
  id: string;
  stage: string;
  shortLabel: string;
  title: string;
  subtitle: string;
  badge: string;
  description: string;
  src: string;
}

export const watchtowerScreenshots: WatchtowerScreenshotItem[] = [
  {
    id: 'watchtower-telemetry-live',
    stage: '',
    shortLabel: 'WATCHTOWER TELEMETRY & STREAMING FEED',
    title: 'Watchtower Live Telemetry & Streaming Activity Feed',
    subtitle: 'Real-time telemetry metrics and live event stream with security policy enforcement',
    badge: 'LIVE WATCHTOWER',
    description: 'Central Watchtower telemetry terminal displaying live fleet metrics (Clusters, Master Agent, Slave Agents) alongside a streaming event log with instant security policy enforcement (e.g. blocking unauthorized slave-to-slave link requests with HTTP 403 Forbidden).',
    src: '/assets/product-section/watchtower/image_aca3acbd.png'
  }
];

export const ALL_PRODUCT_IMAGE_URLS: string[] = [
  ...floorScreenshots.map((item) => item.src),
  ...masterSlaveScreenshots.map((item) => item.src),
  ...vaultScreenshots.map((item) => item.src),
  ...clusterScreenshots.map((item) => item.src),
  ...footprintsWebhooksScreenshots.map((item) => item.src),
  ...watchtowerScreenshots.map((item) => item.src),
  '/assets/product-section/command-pit/image_aa5b5c1b.png',
  '/assets/product-section/connections/image_8a86eee1.png',
];

export const preloadAllProductImages = (): void => {
  if (typeof window === 'undefined') return;
  const executePreload = () => {
    ALL_PRODUCT_IMAGE_URLS.forEach((url) => {
      const img = new Image();
      img.src = url;
    });
  };

  if ('requestIdleCallback' in window) {
    (window as any).requestIdleCallback(executePreload);
  } else {
    setTimeout(executePreload, 50);
  }
};

interface ProductSectionProps {
  onAccessApp?: (target?: 'login' | 'register' | 'adk') => void;
  onOpenDocs?: () => void;
}

export const ProductSection: React.FC<ProductSectionProps> = ({ onAccessApp, onOpenDocs }) => {
  const [activeModule, setActiveModule] = useState<'command-pit' | 'master-slave' | 'floor' | 'clusters' | 'connections' | 'passkey' | 'watchtower' | 'footprints-webhooks'>('command-pit');
  const [activeFloorImage, setActiveFloorImage] = useState<number>(0);
  const [activeMasterSlaveImage, setActiveMasterSlaveImage] = useState<number>(0);
  const [activeVaultImage, setActiveVaultImage] = useState<number>(0);
  const [activeClusterImage, setActiveClusterImage] = useState<number>(0);

  useEffect(() => {
    preloadAllProductImages();
  }, []);
  const [activeFootprintsImage, setActiveFootprintsImage] = useState<number>(0);
  const [isLightboxOpen, setIsLightboxOpen] = useState<boolean>(false);
  const [lightboxOverride, setLightboxOverride] = useState<{ src: string; title: string; description: string } | null>(null);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsLightboxOpen(false);
        setLightboxOverride(null);
      }
      if (isLightboxOpen && !lightboxOverride) {
        if (e.key === 'ArrowRight') setActiveFloorImage((prev) => (prev + 1) % floorScreenshots.length);
        if (e.key === 'ArrowLeft') setActiveFloorImage((prev) => (prev - 1 + floorScreenshots.length) % floorScreenshots.length);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isLightboxOpen, lightboxOverride]);

  return (
    <section id="product" className="py-20 sm:py-28 bg-[#000000] text-white border-b border-white/15 relative overflow-hidden">
      {/* Background Grid Pattern */}
      <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <div className="flex items-center gap-2 mb-3">
            <span className="font-mono text-xs font-bold text-zinc-400 uppercase tracking-widest">
              Core Platform
            </span>
            <span className="text-zinc-600 font-mono text-xs">/</span>
            <span className="font-mono text-xs text-white uppercase tracking-wider font-semibold">
              AAMARVA — Autonomous Agent Command Protocol &amp; Infrastructure
            </span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-black tracking-tight text-white uppercase leading-[1.08] mb-4">
            Total control over autonomous agents.
          </h2>
          <p className="text-sm sm:text-base text-zinc-300 leading-relaxed font-normal">
            AAMARVA provides the runtime coordination, cryptographic boundaries, and deterministic tool gateways needed to run production-grade autonomous agent fleets without risking data leakage or unmonitored execution.
          </p>
        </div>

        {/* 1. MODULE TABS SELECTOR (8 PLATFORM CARDS) */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2 mb-10 font-mono">
          <button
            type="button"
            onClick={() => setActiveModule('command-pit')}
            className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
              activeModule === 'command-pit'
                ? 'bg-white text-black border-white shadow-[0_4px_20px_rgba(255,255,255,0.2)]'
                : 'bg-[#09090b] text-zinc-300 border-white/15 hover:border-white/40 hover:bg-[#121214]'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <Terminal className="w-4 h-4 shrink-0" />
              <span className="text-[10px] font-black opacity-60">01</span>
            </div>
            <div>
              <span className="text-xs font-black uppercase tracking-tight block truncate">Command Pit</span>
              <span className="text-[10px] opacity-75 mt-0.5 block truncate">Prompt Playground</span>
            </div>
          </button>

          <button
            type="button"
            onClick={() => setActiveModule('master-slave')}
            className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
              activeModule === 'master-slave'
                ? 'bg-white text-black border-white shadow-[0_4px_20px_rgba(255,255,255,0.2)]'
                : 'bg-[#09090b] text-zinc-300 border-white/15 hover:border-white/40 hover:bg-[#121214]'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <Users className="w-4 h-4 shrink-0" />
              <span className="text-[10px] font-black opacity-60">02</span>
            </div>
            <div>
              <span className="text-xs font-black uppercase tracking-tight block truncate">Master &amp; Slave Control</span>
              <span className="text-[10px] opacity-75 mt-0.5 block truncate">Fleet Supervision</span>
            </div>
          </button>

          <button
            type="button"
            onClick={() => setActiveModule('floor')}
            className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
              activeModule === 'floor'
                ? 'bg-white text-black border-white shadow-[0_4px_20px_rgba(255,255,255,0.2)]'
                : 'bg-[#09090b] text-zinc-300 border-white/15 hover:border-white/40 hover:bg-[#121214]'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <Server className="w-4 h-4 shrink-0" />
              <span className="text-[10px] font-black opacity-60">03</span>
            </div>
            <div>
              <span className="text-xs font-black uppercase tracking-tight block truncate">FLOOR</span>
              <span className="text-[10px] opacity-75 mt-0.5 block truncate">MCP Tool Gateway</span>
            </div>
          </button>

          <button
            type="button"
            onClick={() => setActiveModule('clusters')}
            className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
              activeModule === 'clusters'
                ? 'bg-white text-black border-white shadow-[0_4px_20px_rgba(255,255,255,0.2)]'
                : 'bg-[#09090b] text-zinc-300 border-white/15 hover:border-white/40 hover:bg-[#121214]'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <Shield className="w-4 h-4 shrink-0" />
              <span className="text-[10px] font-black opacity-60">04</span>
            </div>
            <div>
              <span className="text-xs font-black uppercase tracking-tight block truncate">Clusters</span>
              <span className="text-[10px] opacity-75 mt-0.5 block truncate">E2EE Workgroups</span>
            </div>
          </button>

          <button
            type="button"
            onClick={() => setActiveModule('connections')}
            className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
              activeModule === 'connections'
                ? 'bg-white text-black border-white shadow-[0_4px_20px_rgba(255,255,255,0.2)]'
                : 'bg-[#09090b] text-zinc-300 border-white/15 hover:border-white/40 hover:bg-[#121214]'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <Repeat className="w-4 h-4 shrink-0" />
              <span className="text-[10px] font-black opacity-60">05</span>
            </div>
            <div>
              <span className="text-xs font-black uppercase tracking-tight block truncate">Connections</span>
              <span className="text-[10px] opacity-75 mt-0.5 block truncate">Peer &amp; Fleet Links</span>
            </div>
          </button>

          <button
            type="button"
            onClick={() => setActiveModule('passkey')}
            className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
              activeModule === 'passkey'
                ? 'bg-white text-black border-white shadow-[0_4px_20px_rgba(255,255,255,0.2)]'
                : 'bg-[#09090b] text-zinc-300 border-white/15 hover:border-white/40 hover:bg-[#121214]'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <Fingerprint className="w-4 h-4 shrink-0" />
              <span className="text-[10px] font-black opacity-60">06</span>
            </div>
            <div>
              <span className="text-xs font-black uppercase tracking-tight block truncate">Secure Vault</span>
              <span className="text-[10px] opacity-75 mt-0.5 block truncate">FIDO2 Passkeys</span>
            </div>
          </button>

          <button
            type="button"
            onClick={() => setActiveModule('watchtower')}
            className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
              activeModule === 'watchtower'
                ? 'bg-white text-black border-white shadow-[0_4px_20px_rgba(255,255,255,0.2)]'
                : 'bg-[#09090b] text-zinc-300 border-white/15 hover:border-white/40 hover:bg-[#121214]'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <Eye className="w-4 h-4 shrink-0" />
              <span className="text-[10px] font-black opacity-60">07</span>
            </div>
            <div>
              <span className="text-xs font-black uppercase tracking-tight block truncate">Watchtower</span>
              <span className="text-[10px] opacity-75 mt-0.5 block truncate">Whole-Fleet Monitor</span>
            </div>
          </button>

          <button
            type="button"
            onClick={() => setActiveModule('footprints-webhooks')}
            className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
              activeModule === 'footprints-webhooks'
                ? 'bg-white text-black border-white shadow-[0_4px_20px_rgba(255,255,255,0.2)]'
                : 'bg-[#09090b] text-zinc-300 border-white/15 hover:border-white/40 hover:bg-[#121214]'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <FileText className="w-4 h-4 shrink-0" />
              <span className="text-[10px] font-black opacity-60">08</span>
            </div>
            <div>
              <span className="text-xs font-black uppercase tracking-tight block truncate">Footprints &amp; Webhooks</span>
              <span className="text-[10px] opacity-75 mt-0.5 block truncate">Node Actions &amp; Events</span>
            </div>
          </button>
        </div>

        {/* 2. ACTIVE MODULE DEEP DIVE CARD */}
        <div className="bg-[#09090b] rounded-2xl border border-white/20 p-6 sm:p-10 mb-16 shadow-[0_10px_30px_rgba(0,0,0,0.8)]">
          {activeModule === 'command-pit' && (
            <div className="space-y-10">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                <div className="lg:col-span-7 space-y-5">
                  <div className="flex items-center gap-2 text-xs font-mono text-zinc-400">
                    <Terminal className="w-4 h-4 text-white" />
                    <span className="uppercase font-bold tracking-wider text-white">Command Pit</span>
                    <span className="text-zinc-600">·</span>
                    <span>Prompt Playground &amp; SPOG Command</span>
                  </div>
                  <h3 className="text-2xl sm:text-3xl font-black uppercase text-white tracking-tight leading-tight">
                    Prompt Playground &amp; Unified SPOG Command Engine
                  </h3>
                  <p className="text-sm text-zinc-300 leading-relaxed font-sans">
                    The Command Pit provides human operators with a unified control environment. Access peer connections and clusters directly from the UI to pass operational commands back and forth via an interactive chat interface, managing all fleet agents in a Single Pane of Glass (SPOG) with auto-registered public key credentials.
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 font-mono text-xs">
                    <div className="p-3.5 bg-black/60 rounded-xl border border-white/10">
                      <span className="font-bold text-white block mb-1">Prompt Playground</span>
                      <span className="text-zinc-400 text-[11px] leading-relaxed block">
                        Craft and tune prompt templates while directly accessing connections and clusters from the UI to pass operational commands to target nodes.
                      </span>
                    </div>
                    <div className="p-3.5 bg-black/60 rounded-xl border border-white/10">
                      <span className="font-bold text-white block mb-1">SPOG Chat Interface</span>
                      <span className="text-zinc-400 text-[11px] leading-relaxed block">
                        Single Pane of Glass (SPOG) back-and-forth chat interface to command, view, and interact with all active fleet agents across connections and clusters.
                      </span>
                    </div>
                    <div className="p-3.5 bg-black/60 rounded-xl border border-white/10">
                      <span className="font-bold text-white block mb-1">Fleet Supervision</span>
                      <span className="text-zinc-400 text-[11px] leading-relaxed block">
                        Full-fleet connections and created clusters unified into one single way to command, direct, and supervise all active worker agents.
                      </span>
                    </div>
                    <div className="p-3.5 bg-black/60 rounded-xl border border-white/10">
                      <span className="font-bold text-white block mb-1">Auto Public Key Registry</span>
                      <span className="text-zinc-400 text-[11px] leading-relaxed block">
                        Automatic public key registration in the browser or local device to enable frictionless E2EE communication across connections and clusters.
                      </span>
                    </div>
                  </div>
                </div>

                <div className="lg:col-span-5 bg-black border border-white/15 rounded-xl p-6 font-mono text-xs shadow-2xl space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-white/10 text-zinc-400 text-[11px]">
                    <div className="flex items-center gap-2">
                      <Terminal className="w-4 h-4 text-white shrink-0" />
                      <span className="text-white font-black uppercase tracking-wider">COMMAND_PIT.SPECIFICATION</span>
                    </div>
                  </div>

                  <div className="space-y-3 pt-1">
                    <div className="p-3.5 bg-zinc-950 rounded-lg border border-white/10">
                      <span className="font-mono font-bold text-[10px] text-zinc-400 uppercase tracking-wider block mb-1">
                        Why It Is There:
                      </span>
                      <p className="text-zinc-200 text-xs font-sans leading-relaxed">
                        To give human operators a single pane of glass interactive chat interface to access connections and clusters directly from the UI, pass operational commands back and forth, manage all fleet agents in one place, and eliminate key exchange friction via auto public key registration.
                      </p>
                    </div>

                    <div className="p-3.5 bg-zinc-950 rounded-lg border border-white/10">
                      <span className="font-mono font-bold text-[10px] text-white uppercase tracking-wider block mb-1">
                        What It Does:
                      </span>
                      <p className="text-zinc-200 text-xs font-sans leading-relaxed">
                        Provides a single unified back-and-forth chat interface for commanding full-fleet connections and clusters, registers device public keys automatically in the browser, and gives a Single Pane of Glass (SPOG).
                      </p>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-white/10 flex items-center justify-between text-[10px] text-zinc-400 font-mono">
                    <span>INTERFACE: UI SPOG CHAT</span>
                    <span className="text-white font-bold">AUTO KEY REGISTERED</span>
                  </div>
                </div>
              </div>

              {/* COMMAND PIT SINGLE INTERFACE IMAGE */}
              <div className="border border-white/20 rounded-2xl bg-[#09090b] p-5 sm:p-7 shadow-[0_20px_60px_rgba(0,0,0,0.9)] space-y-4 relative overflow-hidden">
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-32 bg-white/[0.03] blur-3xl rounded-full pointer-events-none" />

                <div className="flex items-center justify-between font-mono text-xs border-b border-white/10 pb-3 relative z-10">
                  <div className="flex items-center gap-2">
                    <Terminal className="w-4 h-4 text-white" />
                    <span className="font-bold text-white uppercase tracking-wider">Command Pit Interface</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setLightboxOverride({
                        src: '/assets/product-section/command-pit/image_aa5b5c1b.png',
                        title: 'Command Pit Interface',
                        description: 'Unified Fleet Connections & Encrypted Cluster Workgroups Control Engine'
                      });
                      setIsLightboxOpen(true);
                    }}
                    className="px-2.5 py-1 bg-white/10 hover:bg-white text-zinc-300 hover:text-black rounded text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer"
                    title="Expand high-resolution inspection modal"
                  >
                    <Maximize2 className="w-3 h-3" />
                    <span>Full-Res Zoom</span>
                  </button>
                </div>

                <div 
                  onClick={() => {
                    setLightboxOverride({
                      src: '/assets/product-section/command-pit/image_aa5b5c1b.png',
                      title: 'Command Pit Interface',
                      description: 'Unified Fleet Connections & Encrypted Cluster Workgroups Control Engine'
                    });
                    setIsLightboxOpen(true);
                  }}
                  className="relative rounded-xl border border-white/25 bg-black overflow-hidden shadow-2xl group cursor-pointer"
                >
                  <OptimizedImage 
                    src="/assets/product-section/command-pit/image_aa5b5c1b.png" 
                    alt="Command Pit Interface Overview" 
                    className="w-full h-auto max-h-[520px] object-contain mx-auto block transition-transform duration-300 group-hover:scale-[1.005]" 
                    referrerPolicy="no-referrer"
                  />
                </div>

                <div className="p-3 sm:p-4 bg-[#0e0e12] border border-white/10 rounded-xl font-mono text-xs text-zinc-300 flex items-center justify-between gap-4 flex-wrap">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white uppercase">COMMAND PIT OVERVIEW</span>
                    <span className="text-zinc-600">·</span>
                    <span className="text-zinc-400 font-sans text-xs">Unified Fleet Connections &amp; Encrypted Cluster Workgroups Control Engine</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeModule === 'master-slave' && (
            <div className="space-y-10">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                <div className="lg:col-span-7 space-y-5">
                  <div className="flex items-center gap-2 text-xs font-mono text-zinc-400">
                    <Users className="w-4 h-4 text-white" />
                    <span className="uppercase font-bold tracking-wider text-white">Master &amp; Slave Control Panel</span>
                    <span className="text-zinc-600">·</span>
                    <span>Fleet Management &amp; Provisioning</span>
                  </div>
                  <h3 className="text-2xl sm:text-3xl font-black uppercase text-white tracking-tight leading-tight">
                    Central Master &amp; Slave Fleet Management &amp; Provisioning
                  </h3>
                  <p className="text-sm text-zinc-300 leading-relaxed font-sans">
                    A human Master Account manages and governs its associated slave agent fleet through the AAMARVA interface. Operators provision dedicated slave account slots, monitor agent states via SPOG, copy settings permanently or temporarily, and seamlessly switch between master and slave accounts.
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 font-mono text-xs">
                    <div className="p-3.5 bg-black/60 rounded-xl border border-white/10">
                      <span className="font-bold text-white block mb-1">Account &amp; Fleet Management</span>
                      <span className="text-zinc-400 text-[11px] leading-relaxed block">
                        Provision and organize associated slave agent accounts under a central master account hierarchy.
                      </span>
                    </div>
                    <div className="p-3.5 bg-black/60 rounded-xl border border-white/10">
                      <span className="font-bold text-white block mb-1">Agent Visibility</span>
                      <span className="text-zinc-400 text-[11px] leading-relaxed block">
                        Maintain clear visibility across registered agent identities and operational states with a clear monitoring SPOG to either undeploy nodes or switch directly to the slave account.
                      </span>
                    </div>
                    <div className="p-3.5 bg-black/60 rounded-xl border border-white/10">
                      <span className="font-bold text-white block mb-1">Copy Master</span>
                      <span className="text-zinc-400 text-[11px] leading-relaxed block">
                        Copy settings from slave accounts to the master account either permanently or on a one-time basis.
                      </span>
                    </div>
                    <div className="p-3.5 bg-black/60 rounded-xl border border-white/10">
                      <span className="font-bold text-white block mb-1">Account Switching</span>
                      <span className="text-zinc-400 text-[11px] leading-relaxed block">
                        Seamless account switching from master to slave to inspect, verify, and manage all account settings and configurations.
                      </span>
                    </div>
                  </div>
                </div>

                <div className="lg:col-span-5 bg-black border border-white/15 rounded-xl p-6 font-mono text-xs shadow-2xl space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-white/10 text-zinc-400 text-[11px]">
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-white shrink-0" />
                      <span className="text-white font-black uppercase tracking-wider">MASTER_SLAVE.SPECIFICATION</span>
                    </div>
                  </div>

                  <div className="space-y-3 pt-1">
                    <div className="p-3.5 bg-zinc-950 rounded-lg border border-white/10">
                      <span className="font-mono font-bold text-[10px] text-zinc-400 uppercase tracking-wider block mb-1">
                        Why It Is There:
                      </span>
                      <p className="text-zinc-200 text-xs font-sans leading-relaxed">
                        To enforce strict administrative hierarchy, provide a clear monitoring SPOG to undeploy or switch accounts, and allow seamless copying of slave settings to the master account under human supervision.
                      </p>
                    </div>

                    <div className="p-3.5 bg-zinc-950 rounded-lg border border-white/10">
                      <span className="font-mono font-bold text-[10px] text-white uppercase tracking-wider block mb-1">
                        What It Does:
                      </span>
                      <p className="text-zinc-200 text-xs font-sans leading-relaxed">
                        Organizes worker nodes under a central master owner, enables one-time or permanent copying of slave settings to master, supports direct master-to-slave account switching, and provides SPOG monitoring with single-click node undeployment.
                      </p>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-white/10 flex items-center justify-between text-[10px] text-zinc-400 font-mono">
                    <span>HIERARCHY: MASTER / SLAVE</span>
                    <span className="text-white font-bold">HUMAN SUPERVISION</span>
                  </div>
                </div>
              </div>

              {/* MASTER AND SLAVE CONTROL INTERFACE GALLERY (EXACT FLOOR GALLERY FORMAT) */}
              <div className="border border-white/20 rounded-2xl bg-[#09090b] p-5 sm:p-7 shadow-[0_20px_60px_rgba(0,0,0,0.9)] space-y-6 relative overflow-hidden">
                {/* Background Ambient Glow */}
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-32 bg-white/[0.03] blur-3xl rounded-full pointer-events-none" />

                {/* Aesthetic Browser Chrome Shell */}
                <div className="rounded-xl border border-white/20 bg-[#0d0d10] overflow-hidden shadow-2xl relative z-10">
                  {/* Console Header Bar */}
                  <div className="bg-[#141418] px-4 py-2 border-b border-white/10 flex items-center justify-between font-mono text-xs">
                    <span className="text-[10px] uppercase tracking-wider font-bold text-zinc-400">MASTER &amp; SLAVE CONTROL GALLERY</span>
                    <button
                      type="button"
                      onClick={() => {
                        setLightboxOverride({
                          src: masterSlaveScreenshots[activeMasterSlaveImage].src,
                          title: masterSlaveScreenshots[activeMasterSlaveImage].title,
                          description: masterSlaveScreenshots[activeMasterSlaveImage].description
                        });
                        setIsLightboxOpen(true);
                      }}
                      className="px-2.5 py-1 bg-white/10 hover:bg-white text-zinc-300 hover:text-black rounded text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer"
                      title="Expand high-resolution inspection modal"
                    >
                      <Maximize2 className="w-3 h-3" />
                      <span>Full-Res Zoom</span>
                    </button>
                  </div>

                  {/* Studio Viewport Canvas */}
                  <div 
                    onClick={() => {
                      setLightboxOverride({
                        src: masterSlaveScreenshots[activeMasterSlaveImage].src,
                        title: masterSlaveScreenshots[activeMasterSlaveImage].title,
                        description: masterSlaveScreenshots[activeMasterSlaveImage].description
                      });
                      setIsLightboxOpen(true);
                    }}
                    className="relative cursor-pointer bg-gradient-to-b from-[#131316] via-[#09090b] to-[#040405] p-3 sm:p-6 lg:p-8 flex items-center justify-center min-h-[300px] sm:min-h-[460px] overflow-hidden group select-none"
                  >
                    {/* Subtle Radial Lighting Behind Screenshot */}
                    <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(255,255,255,0.08),transparent_65%)] pointer-events-none" />
                    <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:20px_20px] pointer-events-none" />

                    {/* Left/Right Floating Quick Nav Buttons */}
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setActiveMasterSlaveImage((prev) => (prev - 1 + masterSlaveScreenshots.length) % masterSlaveScreenshots.length);
                      }}
                      className="absolute left-2 sm:left-4 z-20 p-2 sm:p-2.5 bg-black/80 hover:bg-white text-white hover:text-black border border-white/20 rounded-lg transition-all cursor-pointer shadow-xl opacity-75 group-hover:opacity-100"
                      title="Previous view"
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </button>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setActiveMasterSlaveImage((prev) => (prev + 1) % masterSlaveScreenshots.length);
                      }}
                      className="absolute right-2 sm:right-4 z-20 p-2 sm:p-2.5 bg-black/80 hover:bg-white text-white hover:text-black border border-white/20 rounded-lg transition-all cursor-pointer shadow-xl opacity-75 group-hover:opacity-100"
                      title="Next view"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>

                    {/* Elevated Display Window */}
                    <div className="relative z-10 w-full max-w-4xl rounded-xl border border-white/25 bg-black shadow-[0_25px_80px_rgba(0,0,0,0.95)] overflow-hidden transition-all duration-300 group-hover:border-white/50 group-hover:shadow-[0_30px_90px_rgba(255,255,255,0.08)]">
                      <OptimizedImage 
                        src={masterSlaveScreenshots[activeMasterSlaveImage].src} 
                        alt={masterSlaveScreenshots[activeMasterSlaveImage].title}
                        className="w-full h-auto max-h-[520px] object-contain mx-auto block transition-transform duration-300 group-hover:scale-[1.008]" 
                      />
                    </div>
                  </div>

                  {/* Contextual Narrative Strip */}
                  <div className="p-4 sm:p-6 bg-[#0e0e12] border-t border-white/10 font-mono text-left space-y-1.5">
                    <div className="flex items-center gap-2 text-xs">
                      <span className="text-zinc-300 font-bold">{masterSlaveScreenshots[activeMasterSlaveImage].stage}</span>
                      <span className="text-zinc-600">·</span>
                      <span className="text-white font-extrabold uppercase tracking-wider">{masterSlaveScreenshots[activeMasterSlaveImage].title}</span>
                    </div>
                    <p className="text-zinc-400 text-xs font-sans leading-relaxed max-w-4xl">
                      {masterSlaveScreenshots[activeMasterSlaveImage].subtitle}. {masterSlaveScreenshots[activeMasterSlaveImage].description}
                    </p>
                  </div>
                </div>

                {/* Horizontal Multi-Stage Switcher Strip */}
                <div className="overflow-x-auto pb-2 -mx-4 px-4 sm:mx-0 sm:px-0 custom-scrollbar">
                  <div className="flex sm:grid sm:grid-cols-4 gap-2 sm:gap-3 w-max sm:w-full min-w-full pt-2">
                    {masterSlaveScreenshots.map((item, idx) => {
                      const isSelected = activeMasterSlaveImage === idx;
                      return (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => setActiveMasterSlaveImage(idx)}
                          className={`w-[145px] sm:w-auto shrink-0 sm:shrink p-1.5 sm:p-2.5 rounded-lg sm:rounded-xl border text-left transition-all cursor-pointer flex flex-col gap-1.5 sm:gap-2 ${
                            isSelected
                              ? 'bg-white/10 border-white ring-1 ring-white/50 shadow-[0_4px_20px_rgba(255,255,255,0.15)] scale-[1.01]'
                              : 'bg-black/70 border-white/10 hover:border-white/30 hover:bg-black/90'
                          }`}
                        >
                          <div className="relative aspect-[16/9] w-full bg-black rounded-md sm:rounded-lg overflow-hidden border border-white/15">
                            <OptimizedImage 
                              src={item.src} 
                              alt={item.title} 
                              className="w-full h-full object-cover object-top opacity-90 transition-opacity" 
                            />
                            <span className="absolute top-1 left-1 sm:top-1.5 sm:left-1.5 px-1 sm:px-1.5 py-0.5 bg-black/85 backdrop-blur-sm border border-white/20 text-[7px] sm:text-[9px] font-mono text-white rounded font-bold">
                              {item.stage}
                            </span>
                            {isSelected && (
                              <span className="absolute bottom-1 right-1 sm:bottom-1.5 sm:right-1.5 px-1 sm:px-1.5 py-0.5 bg-white text-black text-[6.5px] sm:text-[8px] font-mono font-black uppercase rounded shadow">
                                Active View
                              </span>
                            )}
                          </div>
                          <div className="font-mono max-w-full">
                            <span className="text-[10px] sm:text-xs font-bold text-white block truncate uppercase tracking-tight">
                              {item.title}
                            </span>
                            <span className="text-[8px] sm:text-[10px] text-zinc-400 block truncate font-sans mt-0.5">
                              {item.subtitle}
                            </span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeModule === 'floor' && (
            <div className="space-y-10">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                <div className="lg:col-span-7 space-y-5">
                  <div className="flex items-center gap-2 text-xs font-mono text-zinc-400">
                    <Server className="w-4 h-4 text-white" />
                    <span className="uppercase font-bold tracking-wider text-white">FLOOR</span>
                    <span className="text-zinc-600">·</span>
                    <span>MCP Tool Gateway</span>
                  </div>
                  <h3 className="text-2xl sm:text-3xl font-black uppercase text-white tracking-tight leading-tight">
                    Governed Tool Discovery &amp; Access Authorization
                  </h3>
                  <p className="text-sm text-zinc-300 leading-relaxed font-sans">
                    Agents should not possess unmonitored production credentials. AAMARVA manages tool access and authorization while the agent's own runtime communicates with the configured MCP server using the returned authorized connection details.
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 font-mono text-xs">
                    <div className="p-3.5 bg-black/60 rounded-xl border border-white/10">
                      <span className="font-bold text-white block mb-1">Standard MCP Interface</span>
                      <span className="text-zinc-400 text-[11px] leading-relaxed block">
                        Connects standard Model Context Protocol servers with dynamic authentication configuration.
                      </span>
                    </div>
                    <div className="p-3.5 bg-black/60 rounded-xl border border-white/10">
                      <span className="font-bold text-white block mb-1">Four Agent Operations</span>
                      <span className="text-zinc-400 text-[11px] leading-relaxed block">
                        Discover tools, submit requests, check request status, and retrieve authorized tool configuration.
                      </span>
                    </div>
                    <div className="p-3.5 bg-black/60 rounded-xl border border-white/10">
                      <span className="font-bold text-white block mb-1">Governed Authorization</span>
                      <span className="text-zinc-400 text-[11px] leading-relaxed block">
                        Provides a SPOG to assign tools to specific agents, controls human-in-the-loop (HITL) supervisors, and enforces affirmative permission every single time a tool is used.
                      </span>
                    </div>
                    <div className="p-3.5 bg-black/60 rounded-xl border border-white/10">
                      <span className="font-bold text-white block mb-1">Runtime Execution</span>
                      <span className="text-zinc-400 text-[11px] leading-relaxed block">
                        The external tool is executed by the agent's own runtime against the MCP server, not by AAMARVA.
                      </span>
                    </div>
                  </div>
                </div>

                <div className="lg:col-span-5 bg-black border border-white/15 rounded-xl p-6 font-mono text-xs shadow-2xl space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-white/10 text-zinc-400 text-[11px]">
                    <div className="flex items-center gap-2">
                      <Server className="w-4 h-4 text-white shrink-0" />
                      <span className="text-white font-black uppercase tracking-wider">FLOOR_MCP.SPECIFICATION</span>
                    </div>
                  </div>

                  <div className="space-y-3 pt-1">
                    <div className="p-3.5 bg-zinc-950 rounded-lg border border-white/10">
                      <span className="font-mono font-bold text-[10px] text-zinc-400 uppercase tracking-wider block mb-1">
                        Why It Is There:
                      </span>
                      <p className="text-zinc-200 text-xs font-sans leading-relaxed">
                        To eliminate hardcoded production API keys inside agent runtimes, ensuring that agents cannot execute arbitrary external actions or leak master credentials if compromised or prompt-injected.
                      </p>
                    </div>

                    <div className="p-3.5 bg-zinc-950 rounded-lg border border-white/10">
                      <span className="font-mono font-bold text-[10px] text-white uppercase tracking-wider block mb-1">
                        What It Does:
                      </span>
                      <p className="text-zinc-200 text-xs font-sans leading-relaxed">
                        Mediates tool discovery, validates request arguments against authorized schemas, provides a SPOG to assign tools to specific agents, controls who is in the human-in-the-loop for designated agents, and requires explicit permission every single time a tool is invoked before returning temporary scoped connection tokens for execution.
                      </p>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-white/10 flex items-center justify-between text-[10px] text-zinc-400 font-mono">
                    <span>TOOL RUNTIME: AGENT HOST</span>
                    <span className="text-white font-bold">MCP COMPLIANT</span>
                  </div>
                </div>
              </div>

              {/* AESTHETIC FLOOR LIVE CONSOLE INTERFACE GALLERY */}
              <div className="border border-white/20 rounded-2xl bg-[#09090b] p-5 sm:p-7 shadow-[0_20px_60px_rgba(0,0,0,0.9)] space-y-6 relative overflow-hidden">
                {/* Background Ambient Glow */}
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-32 bg-white/[0.03] blur-3xl rounded-full pointer-events-none" />

                {/* Aesthetic Browser Chrome Shell */}
                <div className="rounded-xl border border-white/20 bg-[#0d0d10] overflow-hidden shadow-2xl relative z-10">
                  {/* Console Header Bar */}
                  <div className="bg-[#141418] px-4 py-2 border-b border-white/10 flex items-center justify-between font-mono text-xs">
                    <span className="text-[10px] uppercase tracking-wider font-bold text-zinc-400">FLOOR GATEWAY GALLERY</span>
                    <button
                      type="button"
                      onClick={() => setIsLightboxOpen(true)}
                      className="px-2.5 py-1 bg-white/10 hover:bg-white text-zinc-300 hover:text-black rounded text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer"
                      title="Expand high-resolution inspection modal"
                    >
                      <Maximize2 className="w-3 h-3" />
                      <span>Full-Res Zoom</span>
                    </button>
                  </div>

                  {/* Studio Viewport Canvas */}
                  <div 
                    onClick={() => setIsLightboxOpen(true)}
                    className="relative cursor-pointer bg-gradient-to-b from-[#131316] via-[#09090b] to-[#040405] p-3 sm:p-6 lg:p-8 flex items-center justify-center min-h-[300px] sm:min-h-[460px] overflow-hidden group select-none"
                  >
                    {/* Subtle Radial Lighting Behind Screenshot */}
                    <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(255,255,255,0.08),transparent_65%)] pointer-events-none" />
                    <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:20px_20px] pointer-events-none" />

                    {/* Left/Right Floating Quick Nav Buttons */}
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setActiveFloorImage((prev) => (prev - 1 + floorScreenshots.length) % floorScreenshots.length);
                      }}
                      className="absolute left-2 sm:left-4 z-20 p-2 sm:p-2.5 bg-black/80 hover:bg-white text-white hover:text-black border border-white/20 rounded-lg transition-all cursor-pointer shadow-xl opacity-75 group-hover:opacity-100"
                      title="Previous view"
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </button>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setActiveFloorImage((prev) => (prev + 1) % floorScreenshots.length);
                      }}
                      className="absolute right-2 sm:right-4 z-20 p-2 sm:p-2.5 bg-black/80 hover:bg-white text-white hover:text-black border border-white/20 rounded-lg transition-all cursor-pointer shadow-xl opacity-75 group-hover:opacity-100"
                      title="Next view"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>

                    {/* Elevated Retina Display Window */}
                    <div className="relative z-10 w-full max-w-4xl rounded-xl border border-white/25 bg-black shadow-[0_25px_80px_rgba(0,0,0,0.95)] overflow-hidden transition-all duration-300 group-hover:border-white/50 group-hover:shadow-[0_30px_90px_rgba(255,255,255,0.08)]">
                      <OptimizedImage 
                        src={floorScreenshots[activeFloorImage].src} 
                        alt={floorScreenshots[activeFloorImage].title}
                        className="w-full h-auto max-h-[520px] object-contain mx-auto block transition-transform duration-300 group-hover:scale-[1.008]" 
                      />
                    </div>
                  </div>

                  {/* Contextual Narrative Strip */}
                  <div className="p-4 sm:p-6 bg-[#0e0e12] border-t border-white/10 font-mono text-left space-y-1.5">
                    <div className="flex items-center gap-2 text-xs">
                      <span className="text-zinc-300 font-bold">{floorScreenshots[activeFloorImage].stage}</span>
                      <span className="text-zinc-600">·</span>
                      <span className="text-white font-extrabold uppercase tracking-wider">{floorScreenshots[activeFloorImage].title}</span>
                    </div>
                    <p className="text-zinc-400 text-xs font-sans leading-relaxed max-w-4xl">
                      {floorScreenshots[activeFloorImage].subtitle}. {floorScreenshots[activeFloorImage].description}
                    </p>
                  </div>
                </div>

                {/* Horizontal 5-Stage Switcher Strip (Always in a single horizontal line) */}
                <div className="overflow-x-auto pb-1">
                  <div className="grid grid-cols-5 gap-2 sm:gap-2.5 min-w-[680px] w-full pt-2">
                    {floorScreenshots.map((item, idx) => {
                      const isSelected = activeFloorImage === idx;
                      return (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => setActiveFloorImage(idx)}
                          className={`p-2 sm:p-2.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col gap-2 ${
                            isSelected
                              ? 'bg-white/10 border-white ring-1 ring-white/50 shadow-[0_4px_20px_rgba(255,255,255,0.15)] scale-[1.01]'
                              : 'bg-black/70 border-white/10 hover:border-white/30 hover:bg-black/90'
                          }`}
                        >
                          <div className="relative aspect-[16/9] w-full bg-black rounded-lg overflow-hidden border border-white/15">
                            <OptimizedImage 
                              src={item.src} 
                              alt={item.title} 
                              className="w-full h-full object-cover object-top opacity-90 transition-opacity" 
                            />
                            <span className="absolute top-1 left-1 px-1.5 py-0.5 bg-black/85 backdrop-blur-sm border border-white/20 text-[8px] sm:text-[9px] font-mono text-white rounded font-bold">
                              {item.stage}
                            </span>
                            {isSelected && (
                              <span className="absolute bottom-1 right-1 px-1.5 py-0.5 bg-white text-black text-[7px] sm:text-[8px] font-mono font-black uppercase rounded shadow">
                                Active View
                              </span>
                            )}
                          </div>
                          <div className="font-mono">
                            <span className="text-[11px] sm:text-xs font-bold text-white block truncate uppercase tracking-tight">
                              {item.shortLabel.replace(/^0\d\s\/\/\s/, '')}
                            </span>
                            <span className="text-[9px] sm:text-[10px] text-zinc-400 block truncate font-sans mt-0.5">
                              {item.subtitle}
                            </span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeModule === 'clusters' && (
            <div className="space-y-8">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              <div className="lg:col-span-7 space-y-5">
                <div className="flex items-center gap-2 text-xs font-mono text-zinc-400">
                  <Shield className="w-4 h-4 text-white" />
                  <span className="uppercase font-bold tracking-wider text-white">Clusters</span>
                  <span className="text-zinc-600">·</span>
                  <span>Encrypted Workgroups</span>
                </div>
                <h3 className="text-2xl sm:text-3xl font-black uppercase text-white tracking-tight leading-tight">
                  Recipient-Restricted Encrypted Group Communication
                </h3>
                <p className="text-sm text-zinc-300 leading-relaxed font-sans">
                  AAMARVA organizes agents into collaborative clusters using end-to-end encrypted messaging. Message visibility is restricted by the recipient authorization model: only explicit recipients can retrieve message payloads, with automatic inclusion of the Master Account and Sender Account.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 font-mono text-xs">
                  <div className="p-3.5 bg-black/60 rounded-xl border border-white/10">
                    <span className="font-bold text-white block mb-1">Recipient-Based Visibility</span>
                    <span className="text-zinc-400 text-[11px] leading-relaxed block">
                      The backend validates caller identity against the message recipient list before releasing message payloads.
                    </span>
                  </div>
                  <div className="p-3.5 bg-black/60 rounded-xl border border-white/10">
                    <span className="font-bold text-white block mb-1">Master Account Inclusion</span>
                    <span className="text-zinc-400 text-[11px] leading-relaxed block">
                      The cluster Master Account is automatically included in the recipient set for administrative supervision.
                    </span>
                  </div>
                  <div className="p-3.5 bg-black/60 rounded-xl border border-white/10">
                    <span className="font-bold text-white block mb-1">Sender Account Inclusion</span>
                    <span className="text-zinc-400 text-[11px] leading-relaxed block">
                      The sending agent is always included in the recipient set to maintain round-trip communication history.
                    </span>
                  </div>
                  <div className="p-3.5 bg-black/60 rounded-xl border border-white/10">
                    <span className="font-bold text-white block mb-1">Key Epochs &amp; Distribution</span>
                    <span className="text-zinc-400 text-[11px] leading-relaxed block">
                      Cluster key distribution packages are derived and rotated across authorized membership updates.
                    </span>
                  </div>
                </div>
              </div>

              <div className="lg:col-span-5 bg-black border border-white/15 rounded-xl p-6 font-mono text-xs shadow-2xl space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-white/10 text-zinc-400 text-[11px]">
                  <div className="flex items-center gap-2">
                    <Shield className="w-4 h-4 text-white shrink-0" />
                    <span className="text-white font-black uppercase tracking-wider">CLUSTERS.SPECIFICATION</span>
                  </div>
                </div>

                <div className="space-y-3 pt-1">
                  <div className="p-3.5 bg-zinc-950 rounded-lg border border-white/10">
                    <span className="font-mono font-bold text-[10px] text-zinc-400 uppercase tracking-wider block mb-1">
                      Why It Is There:
                    </span>
                    <p className="text-zinc-200 text-xs font-sans leading-relaxed">
                      To allow multi-agent workgroup collaboration while guaranteeing that payload contents remain end-to-end encrypted and unreadable by unauthorized peers or external relays.
                    </p>
                  </div>

                  <div className="p-3.5 bg-zinc-950 rounded-lg border border-white/10">
                    <span className="font-mono font-bold text-[10px] text-white uppercase tracking-wider block mb-1">
                      What It Does:
                    </span>
                    <p className="text-zinc-200 text-xs font-sans leading-relaxed">
                      Scrambles message payloads client-side using ECDH P-256 and AES-256-GCM, validates recipient identity before releasing ciphertexts, and automatically includes the master operator in all group communications.
                    </p>
                  </div>
                </div>

                <div className="pt-3 border-t border-white/10 flex items-center justify-between text-[10px] text-zinc-400 font-mono">
                  <span>ENCRYPTION: AES-256-GCM</span>
                  <span className="text-white font-bold">RECIPIENT FILTERED</span>
                </div>
              </div>
            </div>

            {/* Clusters 4-Stage Gallery Showcase */}
            <div className="mt-8 border border-white/20 rounded-2xl bg-[#09090b] p-5 sm:p-7 shadow-[0_20px_60px_rgba(0,0,0,0.9)] space-y-6 relative overflow-hidden">
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-32 bg-white/[0.03] blur-3xl rounded-full pointer-events-none" />

              <div className="rounded-xl border border-white/20 bg-[#0d0d10] overflow-hidden shadow-2xl relative z-10">
                <div className="bg-[#141418] px-4 py-2 border-b border-white/10 flex items-center justify-between font-mono text-xs">
                  <span className="text-[10px] uppercase tracking-wider font-bold text-zinc-400">
                    CLUSTERS — {clusterScreenshots[activeClusterImage].stage}
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setLightboxOverride({
                        src: clusterScreenshots[activeClusterImage].src,
                        title: clusterScreenshots[activeClusterImage].title,
                        description: clusterScreenshots[activeClusterImage].description
                      });
                      setIsLightboxOpen(true);
                    }}
                    className="px-2.5 py-1 bg-white/10 hover:bg-white text-zinc-300 hover:text-black rounded text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer"
                    title="Expand high-resolution inspection modal"
                  >
                    <Maximize2 className="w-3 h-3" />
                    <span>Full-Res Zoom</span>
                  </button>
                </div>

                <div 
                  onClick={() => {
                    setLightboxOverride({
                      src: clusterScreenshots[activeClusterImage].src,
                      title: clusterScreenshots[activeClusterImage].title,
                      description: clusterScreenshots[activeClusterImage].description
                    });
                    setIsLightboxOpen(true);
                  }}
                  className="relative cursor-pointer bg-gradient-to-b from-[#131316] via-[#09090b] to-[#040405] p-3 sm:p-6 lg:p-8 flex items-center justify-center min-h-[300px] sm:min-h-[460px] overflow-hidden group select-none"
                >
                  <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(255,255,255,0.08),transparent_65%)] pointer-events-none" />
                  <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:20px_20px] pointer-events-none" />

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveClusterImage((prev) => (prev - 1 + clusterScreenshots.length) % clusterScreenshots.length);
                    }}
                    className="absolute left-2 sm:left-4 z-20 p-2 sm:p-2.5 bg-black/80 hover:bg-white text-white hover:text-black border border-white/20 rounded-lg transition-all cursor-pointer shadow-xl opacity-75 group-hover:opacity-100"
                    title="Previous view"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveClusterImage((prev) => (prev + 1) % clusterScreenshots.length);
                    }}
                    className="absolute right-2 sm:right-4 z-20 p-2 sm:p-2.5 bg-black/80 hover:bg-white text-white hover:text-black border border-white/20 rounded-lg transition-all cursor-pointer shadow-xl opacity-75 group-hover:opacity-100"
                    title="Next view"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>

                  <div className="relative z-10 w-full max-w-4xl rounded-xl border border-white/25 bg-black shadow-[0_25px_80px_rgba(0,0,0,0.95)] overflow-hidden transition-all duration-300 group-hover:border-white/50 group-hover:shadow-[0_30px_90px_rgba(255,255,255,0.08)]">
                    <OptimizedImage 
                      src={clusterScreenshots[activeClusterImage].src} 
                      alt={clusterScreenshots[activeClusterImage].title}
                      className="w-full h-auto max-h-[520px] object-contain mx-auto block transition-transform duration-300 group-hover:scale-[1.008]" 
                    />
                  </div>
                </div>

                <div className="p-4 sm:p-6 bg-[#0e0e12] border-t border-white/10 font-mono text-left space-y-1.5">
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-zinc-300 font-bold">{clusterScreenshots[activeClusterImage].stage}</span>
                    <span className="text-zinc-600">·</span>
                    <span className="text-white font-extrabold uppercase tracking-wider">{clusterScreenshots[activeClusterImage].title}</span>
                  </div>
                  <p className="text-zinc-400 text-xs font-sans leading-relaxed max-w-4xl">
                    {clusterScreenshots[activeClusterImage].subtitle}. {clusterScreenshots[activeClusterImage].description}
                  </p>
                </div>
              </div>

              {/* Horizontal 4-Stage Switcher Strip */}
              <div className="overflow-x-auto pb-1">
                <div className="grid grid-cols-4 gap-2 sm:gap-2.5 min-w-[640px] w-full pt-2">
                  {clusterScreenshots.map((item, idx) => {
                    const isSelected = activeClusterImage === idx;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => setActiveClusterImage(idx)}
                        className={`p-2 sm:p-2.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col gap-2 ${
                          isSelected
                            ? 'bg-white/10 border-white ring-1 ring-white/50 shadow-[0_4px_20px_rgba(255,255,255,0.15)] scale-[1.01]'
                            : 'bg-black/70 border-white/10 hover:border-white/30 hover:bg-black/90'
                        }`}
                      >
                        <div className="relative aspect-[16/9] w-full bg-black rounded-lg overflow-hidden border border-white/15">
                          <OptimizedImage 
                            src={item.src} 
                            alt={item.title} 
                            className="w-full h-full object-cover object-top opacity-90 transition-opacity" 
                          />
                          <span className="absolute top-1 left-1 px-1.5 py-0.5 bg-black/85 backdrop-blur-sm border border-white/20 text-[8px] sm:text-[9px] font-mono text-white rounded font-bold">
                            {item.stage}
                          </span>
                          {isSelected && (
                            <span className="absolute bottom-1 right-1 px-1.5 py-0.5 bg-white text-black text-[7px] sm:text-[8px] font-mono font-black uppercase rounded shadow">
                              Active View
                            </span>
                          )}
                        </div>
                        <div className="font-mono">
                          <span className="text-[11px] sm:text-xs font-bold text-white block truncate uppercase tracking-tight">
                            {item.shortLabel.replace(/^0\d\s\/\/\s/, '')}
                          </span>
                          <span className="text-[9px] sm:text-[10px] text-zinc-400 block truncate font-sans mt-0.5">
                            {item.subtitle}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
            </div>
          )}

          {activeModule === 'connections' && (
            <div className="space-y-8">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              <div className="lg:col-span-7 space-y-5">
                <div className="flex items-center gap-2 text-xs font-mono text-zinc-400">
                  <Repeat className="w-4 h-4 text-white" />
                  <span className="uppercase font-bold tracking-wider text-white">Direct Connections</span>
                  <span className="text-zinc-600">·</span>
                  <span>Authorized Peer Links</span>
                </div>
                <h3 className="text-2xl sm:text-3xl font-black uppercase text-white tracking-tight leading-tight">
                  Governed Master &amp; Peer Handshakes
                </h3>
                <p className="text-sm text-zinc-300 leading-relaxed font-sans">
                  Direct cryptographic links between authorized nodes. Makes it easy for the master operator to communicate with a single slave agent at a time in a dedicated private channel. Crucially, unmonitored slave-to-slave private connections are strictly rejected by the backend to prevent unauthorized lateral spread.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 font-mono text-xs">
                  <div className="p-3.5 bg-black/60 rounded-xl border border-white/10">
                    <span className="font-bold text-white block mb-1">1-on-1 Private Channels</span>
                    <span className="text-zinc-400 text-[11px] leading-relaxed block">
                      Dedicated private command channels allowing the master operator to easily communicate with one single slave agent at a time.
                    </span>
                  </div>
                  <div className="p-3.5 bg-black/60 rounded-xl border border-white/10">
                    <span className="font-bold text-white block mb-1">Peer Key Handshake</span>
                    <span className="text-zinc-400 text-[11px] leading-relaxed block">
                      Mutual exchange of ECDH P-256 public keys for point-to-point encrypted messaging.
                    </span>
                  </div>
                  <div className="p-3.5 bg-black/60 rounded-xl border border-white/10">
                    <span className="font-bold text-white block mb-1">Anti-Lateral Defense</span>
                    <span className="text-zinc-400 text-[11px] leading-relaxed block">
                      Subordinate slave-to-slave direct links are strictly blocked (403 Forbidden). Lateral work must use clusters.
                    </span>
                  </div>
                  <div className="p-3.5 bg-black/60 rounded-xl border border-white/10">
                    <span className="font-bold text-white block mb-1">Instant Revocation</span>
                    <span className="text-zinc-400 text-[11px] leading-relaxed block">
                      Revoking a connection dissolves keys immediately, preventing further message delivery.
                    </span>
                  </div>
                </div>
              </div>

              <div className="lg:col-span-5 bg-black border border-white/15 rounded-xl p-6 font-mono text-xs shadow-2xl space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-white/10 text-zinc-400 text-[11px]">
                  <div className="flex items-center gap-2">
                    <Repeat className="w-4 h-4 text-white shrink-0" />
                    <span className="text-white font-black uppercase tracking-wider">CONNECTIONS.SPECIFICATION</span>
                  </div>
                </div>

                <div className="space-y-3 pt-1">
                  <div className="p-3.5 bg-zinc-950 rounded-lg border border-white/10">
                    <span className="font-mono font-bold text-[10px] text-zinc-400 uppercase tracking-wider block mb-1">
                      Why It Is There:
                    </span>
                    <p className="text-zinc-200 text-xs font-sans leading-relaxed">
                      To eliminate unmonitored private backchannels between worker nodes, preventing rogue agent collusion, secret message passing, or lateral threat propagation while giving master operators a dedicated private channel to communicate with one single slave agent at a time.
                    </p>
                  </div>

                  <div className="p-3.5 bg-zinc-950 rounded-lg border border-white/10">
                    <span className="font-mono font-bold text-[10px] text-white uppercase tracking-wider block mb-1">
                      What It Does:
                    </span>
                    <p className="text-zinc-200 text-xs font-sans leading-relaxed">
                      Performs mutual public key exchanges for authorized master-slave and master-master links, enables seamless 1-on-1 private messaging between a master and a single target slave agent, and automatically rejects direct slave-to-slave link requests with HTTP 403 Forbidden.
                    </p>
                  </div>
                </div>

                <div className="pt-3 border-t border-white/10 flex items-center justify-between text-[10px] text-zinc-400 font-mono">
                  <span>TOPOLOGY: GOVERNED MESH</span>
                  <span className="text-white font-bold">ANTI-LATERAL ENFORCED</span>
                </div>
              </div>
            </div>

            {/* Connections Single Image Gallery Showcase */}
            <div className="mt-8 border border-white/20 rounded-2xl bg-[#09090b] p-5 sm:p-7 shadow-[0_20px_60px_rgba(0,0,0,0.9)] space-y-6 relative overflow-hidden">
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-32 bg-white/[0.03] blur-3xl rounded-full pointer-events-none" />

              <div className="rounded-xl border border-white/20 bg-[#0d0d10] overflow-hidden shadow-2xl relative z-10">
                <div className="bg-[#141418] px-4 py-2 border-b border-white/10 flex items-center justify-between font-mono text-xs">
                  <span className="text-[10px] uppercase tracking-wider font-bold text-zinc-400">DIRECT CONNECTIONS — END-TO-END ENCRYPTION BETWEEN MASTER AND SLAVE COMMAND TERMINAL</span>
                  <button
                    type="button"
                    onClick={() => {
                      setLightboxOverride({
                        src: '/assets/product-section/connections/image_8a86eee1.png',
                        title: 'End-to-End Encryption Between Master and Slave Command Terminal',
                        description: 'End-to-end encryption between master and slave command terminal. Secures direct messaging and command execution between the master operator and slave worker agents with zero-knowledge cryptographic verification.'
                      });
                      setIsLightboxOpen(true);
                    }}
                    className="px-2.5 py-1 bg-white/10 hover:bg-white text-zinc-300 hover:text-black rounded text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer"
                    title="Expand high-resolution inspection modal"
                  >
                    <Maximize2 className="w-3 h-3" />
                    <span>Full-Res Zoom</span>
                  </button>
                </div>

                <div 
                  onClick={() => {
                    setLightboxOverride({
                      src: '/assets/product-section/connections/image_8a86eee1.png',
                      title: 'End-to-End Encryption Between Master and Slave Command Terminal',
                      description: 'End-to-end encryption between master and slave command terminal. Secures direct messaging and command execution between the master operator and slave worker agents with zero-knowledge cryptographic verification.'
                    });
                    setIsLightboxOpen(true);
                  }}
                  className="relative cursor-pointer bg-gradient-to-b from-[#131316] via-[#09090b] to-[#040405] p-3 sm:p-6 lg:p-8 flex items-center justify-center min-h-[300px] sm:min-h-[460px] overflow-hidden group select-none"
                >
                  <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(255,255,255,0.08),transparent_65%)] pointer-events-none" />
                  <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:20px_20px] pointer-events-none" />

                  <div className="relative z-10 w-full max-w-4xl rounded-xl border border-white/25 bg-black shadow-[0_25px_80px_rgba(0,0,0,0.95)] overflow-hidden transition-all duration-300 group-hover:border-white/50 group-hover:shadow-[0_30px_90px_rgba(255,255,255,0.08)]">
                    <OptimizedImage 
                      src="/assets/product-section/connections/image_8a86eee1.png" 
                      alt="End-to-End Encryption Between Master and Slave Command Terminal"
                      className="w-full h-auto max-h-[520px] object-contain mx-auto block transition-transform duration-300 group-hover:scale-[1.008]" 
                    />
                  </div>
                </div>

                <div className="p-4 sm:p-6 bg-[#0e0e12] border-t border-white/10 font-mono text-left space-y-1.5">
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-white font-extrabold uppercase tracking-wider">END-TO-END ENCRYPTION BETWEEN MASTER AND SLAVE COMMAND TERMINAL</span>
                  </div>
                  <p className="text-zinc-400 text-xs font-sans leading-relaxed max-w-4xl">
                    End-to-end encryption between master and slave command terminal. Secures direct messaging and command execution between the master operator and slave worker agents with zero-knowledge cryptographic verification.
                  </p>
                </div>
              </div>
            </div>
            </div>
          )}

          {activeModule === 'passkey' && (
            <div className="space-y-8">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              <div className="lg:col-span-7 space-y-5">
                <div className="flex items-center gap-2 text-xs font-mono text-zinc-400">
                  <Fingerprint className="w-4 h-4 text-white" />
                  <span className="uppercase font-bold tracking-wider text-white">Secure Vault</span>
                  <span className="text-zinc-600">·</span>
                  <span>Human Operator Authentication</span>
                </div>
                <h3 className="text-2xl sm:text-3xl font-black uppercase text-white tracking-tight leading-tight">
                  FIDO2 Passkey Human Operator Authentication
                </h3>
                <p className="text-sm text-zinc-300 leading-relaxed font-sans">
                  Human operators authenticate through the interface using password verification followed by registered FIDO2/WebAuthn passkey verification. Secure Vault also enables operators to revoke email passwords and API keys instantly, alongside a global logout feature to terminate all active sessions across the fleet.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 font-mono text-xs">
                  <div className="p-3.5 bg-black/60 rounded-xl border border-white/10">
                    <span className="font-bold text-white block mb-1">Two-Step Human Sign-In</span>
                    <span className="text-zinc-400 text-[11px] leading-relaxed block">
                      Operators enter account password followed by registered FIDO2 passkey verification.
                    </span>
                  </div>
                  <div className="p-3.5 bg-black/60 rounded-xl border border-white/10">
                    <span className="font-bold text-white block mb-1">Standard WebAuthn &amp; IP Whitelisting</span>
                    <span className="text-zinc-400 text-[11px] leading-relaxed block">
                      Built on standard W3C WebAuthn protocols using device authenticators and security keys, paired with IP network CIDR whitelisting for strict ingress perimeter defense.
                    </span>
                  </div>
                  <div className="p-3.5 bg-black/60 rounded-xl border border-white/10">
                    <span className="font-bold text-white block mb-1">Credential &amp; Key Revocation</span>
                    <span className="text-zinc-400 text-[11px] leading-relaxed block">
                      Instantly revoke email passwords, agent API keys, and session tokens directly from the vault.
                    </span>
                  </div>
                  <div className="p-3.5 bg-black/60 rounded-xl border border-white/10">
                    <span className="font-bold text-white block mb-1">Global Fleet Logout</span>
                    <span className="text-zinc-400 text-[11px] leading-relaxed block">
                      Trigger an immediate global logout to invalidate all active operator and agent sessions fleet-wide.
                    </span>
                  </div>
                </div>
              </div>

              <div className="lg:col-span-5 bg-black border border-white/15 rounded-xl p-6 font-mono text-xs shadow-2xl space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-white/10 text-zinc-400 text-[11px]">
                  <div className="flex items-center gap-2">
                    <Fingerprint className="w-4 h-4 text-white shrink-0" />
                    <span className="text-white font-black uppercase tracking-wider">SECURE_VAULT.SPECIFICATION</span>
                  </div>
                </div>

                <div className="space-y-3 pt-1">
                  <div className="p-3.5 bg-zinc-950 rounded-lg border border-white/10">
                    <span className="font-mono font-bold text-[10px] text-zinc-400 uppercase tracking-wider block mb-1">
                      Why It Is There:
                    </span>
                    <p className="text-zinc-200 text-xs font-sans leading-relaxed">
                      To anchor administrative control over the entire agent fleet to physical human presence, ensuring that automated bots, scripts, or malicious AI runtimes can never hijack administrative operator accounts.
                    </p>
                  </div>

                  <div className="p-3.5 bg-zinc-950 rounded-lg border border-white/10">
                    <span className="font-mono font-bold text-[10px] text-white uppercase tracking-wider block mb-1">
                      What It Does:
                    </span>
                    <p className="text-zinc-200 text-xs font-sans leading-relaxed">
                      Enforces a two-step sign-in requiring account password verification followed by a hardware-bound WebAuthn biometric or physical key assertion before issuing administrative operator sessions, while providing instant controls to revoke email passwords, invalidate API keys, and execute a global logout across all active sessions.
                    </p>
                  </div>
                </div>

                <div className="pt-3 border-t border-white/10 flex items-center justify-between text-[10px] text-zinc-400 font-mono">
                  <span>STANDARD: W3C WEBAUTHN</span>
                  <span className="text-white font-bold">FIDO2 COMPLIANT</span>
                </div>
              </div>
            </div>

            {/* Secure Vault 5-Stage Gallery Showcase */}
            <div className="mt-8 border border-white/20 rounded-2xl bg-[#09090b] p-5 sm:p-7 shadow-[0_20px_60px_rgba(0,0,0,0.9)] space-y-6 relative overflow-hidden">
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-32 bg-white/[0.03] blur-3xl rounded-full pointer-events-none" />

              <div className="rounded-xl border border-white/20 bg-[#0d0d10] overflow-hidden shadow-2xl relative z-10">
                <div className="bg-[#141418] px-4 py-2 border-b border-white/10 flex items-center justify-between font-mono text-xs">
                  <span className="text-[10px] uppercase tracking-wider font-bold text-zinc-400">
                    SECURE VAULT — {vaultScreenshots[activeVaultImage].stage}
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setLightboxOverride({
                        src: vaultScreenshots[activeVaultImage].src,
                        title: vaultScreenshots[activeVaultImage].title,
                        description: vaultScreenshots[activeVaultImage].description
                      });
                      setIsLightboxOpen(true);
                    }}
                    className="px-2.5 py-1 bg-white/10 hover:bg-white text-zinc-300 hover:text-black rounded text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer"
                    title="Expand high-resolution inspection modal"
                  >
                    <Maximize2 className="w-3 h-3" />
                    <span>Full-Res Zoom</span>
                  </button>
                </div>

                <div 
                  onClick={() => {
                    setLightboxOverride({
                      src: vaultScreenshots[activeVaultImage].src,
                      title: vaultScreenshots[activeVaultImage].title,
                      description: vaultScreenshots[activeVaultImage].description
                    });
                    setIsLightboxOpen(true);
                  }}
                  className="relative cursor-pointer bg-gradient-to-b from-[#131316] via-[#09090b] to-[#040405] p-3 sm:p-6 lg:p-8 flex items-center justify-center min-h-[300px] sm:min-h-[460px] overflow-hidden group select-none"
                >
                  <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(255,255,255,0.08),transparent_65%)] pointer-events-none" />
                  <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:20px_20px] pointer-events-none" />

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveVaultImage((prev) => (prev - 1 + vaultScreenshots.length) % vaultScreenshots.length);
                    }}
                    className="absolute left-2 sm:left-4 z-20 p-2 sm:p-2.5 bg-black/80 hover:bg-white text-white hover:text-black border border-white/20 rounded-lg transition-all cursor-pointer shadow-xl opacity-75 group-hover:opacity-100"
                    title="Previous view"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveVaultImage((prev) => (prev + 1) % vaultScreenshots.length);
                    }}
                    className="absolute right-2 sm:right-4 z-20 p-2 sm:p-2.5 bg-black/80 hover:bg-white text-white hover:text-black border border-white/20 rounded-lg transition-all cursor-pointer shadow-xl opacity-75 group-hover:opacity-100"
                    title="Next view"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>

                  <div className="relative z-10 w-full max-w-4xl rounded-xl border border-white/25 bg-black shadow-[0_25px_80px_rgba(0,0,0,0.95)] overflow-hidden transition-all duration-300 group-hover:border-white/50 group-hover:shadow-[0_30px_90px_rgba(255,255,255,0.08)]">
                    <OptimizedImage 
                      src={vaultScreenshots[activeVaultImage].src} 
                      alt={vaultScreenshots[activeVaultImage].title}
                      className="w-full h-auto max-h-[520px] object-contain mx-auto block transition-transform duration-300 group-hover:scale-[1.008]" 
                    />
                  </div>
                </div>

                <div className="p-4 sm:p-6 bg-[#0e0e12] border-t border-white/10 font-mono text-left space-y-1.5">
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-zinc-300 font-bold">{vaultScreenshots[activeVaultImage].stage}</span>
                    <span className="text-zinc-600">·</span>
                    <span className="text-white font-extrabold uppercase tracking-wider">{vaultScreenshots[activeVaultImage].title}</span>
                  </div>
                  <p className="text-zinc-400 text-xs font-sans leading-relaxed max-w-4xl">
                    {vaultScreenshots[activeVaultImage].subtitle}. {vaultScreenshots[activeVaultImage].description}
                  </p>
                </div>
              </div>

              {/* Horizontal 7-Item Switcher Strip */}
              <div className="overflow-x-auto pb-1">
                <div className="grid grid-cols-7 gap-2 sm:gap-2.5 min-w-[1100px] w-full pt-2">
                  {vaultScreenshots.map((item, idx) => {
                    const isSelected = activeVaultImage === idx;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => setActiveVaultImage(idx)}
                        className={`p-2 sm:p-2.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col gap-2 ${
                          isSelected
                            ? 'bg-white/10 border-white ring-1 ring-white/50 shadow-[0_4px_20px_rgba(255,255,255,0.15)] scale-[1.01]'
                            : 'bg-black/70 border-white/10 hover:border-white/30 hover:bg-black/90'
                        }`}
                      >
                        <div className="relative aspect-[16/9] w-full bg-black rounded-lg overflow-hidden border border-white/15">
                          <OptimizedImage 
                            src={item.src} 
                            alt={item.title} 
                            className="w-full h-full object-cover object-top opacity-90 transition-opacity" 
                          />
                          <span className="absolute top-1 left-1 px-1.5 py-0.5 bg-black/85 backdrop-blur-sm border border-white/20 text-[7px] sm:text-[8px] font-mono text-white rounded font-bold uppercase truncate max-w-[90%]">
                            {item.badge}
                          </span>
                          {isSelected && (
                            <span className="absolute bottom-1 right-1 px-1.5 py-0.5 bg-white text-black text-[7px] sm:text-[8px] font-mono font-black uppercase rounded shadow">
                              Active View
                            </span>
                          )}
                        </div>
                        <div className="font-mono">
                          <span className="text-[11px] sm:text-xs font-bold text-white block truncate uppercase tracking-tight">
                            {item.shortLabel.replace(/^0\d\s\/\/\s/, '')}
                          </span>
                          <span className="text-[9px] sm:text-[10px] text-zinc-400 block truncate font-sans mt-0.5">
                            {item.subtitle}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
            </div>
          )}

          {activeModule === 'watchtower' && (
            <div className="space-y-8">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                <div className="lg:col-span-7 space-y-5">
                  <div className="flex items-center gap-2 text-xs font-mono text-zinc-400">
                    <Eye className="w-4 h-4 text-white" />
                    <span className="uppercase font-bold tracking-wider text-white">Watchtower</span>
                    <span className="text-zinc-600">·</span>
                    <span>Fleet Activity Streaming</span>
                  </div>
                  <h3 className="text-2xl sm:text-3xl font-black uppercase text-white tracking-tight leading-tight">
                    Fleet-Wide Streaming Activity View
                  </h3>
                  <p className="text-sm text-zinc-300 leading-relaxed font-sans">
                    Watchtower provides operators with a streaming view of relevant fleet activity. Delivered through Server-Sent Events (SSE), operators can inspect agent authentications, direct connections, cluster communications, and tool-related events across their fleet.
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 font-mono text-xs">
                    <div className="p-3.5 bg-black/60 rounded-xl border border-white/10">
                      <span className="font-bold text-white block mb-1">Streaming Activity Feed</span>
                      <span className="text-zinc-400 text-[11px] leading-relaxed block">
                        Live activity updates delivered via Server-Sent Events (SSE) directly to the operator console.
                      </span>
                    </div>
                    <div className="p-3.5 bg-black/60 rounded-xl border border-white/10">
                      <span className="font-bold text-white block mb-1">Fleet Event Types</span>
                      <span className="text-zinc-400 text-[11px] leading-relaxed block">
                        Streams agent authentication, connection traffic, cluster messages, and tool request statuses.
                      </span>
                    </div>
                    <div className="p-3.5 bg-black/60 rounded-xl border border-white/10">
                      <span className="font-bold text-white block mb-1">Structured Footprints</span>
                      <span className="text-zinc-400 text-[11px] leading-relaxed block">
                        Maintains structured records identifying originating agent, timestamp, action, and outcome.
                      </span>
                    </div>
                    <div className="p-3.5 bg-black/60 rounded-xl border border-white/10">
                      <span className="font-bold text-white block mb-1">Operator Oversight</span>
                      <span className="text-zinc-400 text-[11px] leading-relaxed block">
                        Allows operators to review fleet activity and verify agent operations against assigned policies.
                      </span>
                    </div>
                  </div>
                </div>

                <div className="lg:col-span-5 bg-black border border-white/15 rounded-xl p-6 font-mono text-xs shadow-2xl space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-white/10 text-zinc-400 text-[11px]">
                    <div className="flex items-center gap-2">
                      <Eye className="w-4 h-4 text-white shrink-0" />
                      <span className="text-white font-black uppercase tracking-wider">WATCHTOWER.SPECIFICATION</span>
                    </div>
                    <span className="text-zinc-400 uppercase text-[10px]">RADAR OBSERVABILITY</span>
                  </div>

                  <div className="space-y-3 pt-1">
                    <div className="p-3.5 bg-zinc-950 rounded-lg border border-white/10">
                      <span className="font-mono font-bold text-[10px] text-zinc-400 uppercase tracking-wider block mb-1">
                        Why It Is There:
                      </span>
                      <p className="text-zinc-200 text-xs font-sans leading-relaxed">
                        To give human operators real-time radar visibility over all agent interactions, tool calls, and authentication events happening simultaneously across 100+ fleet nodes.
                      </p>
                    </div>

                    <div className="p-3.5 bg-zinc-950 rounded-lg border border-white/10">
                      <span className="font-mono font-bold text-[10px] text-white uppercase tracking-wider block mb-1">
                        What It Does:
                      </span>
                      <p className="text-zinc-200 text-xs font-sans leading-relaxed">
                        Aggregates fleet telemetry, streams live Server-Sent Events (SSE) updates to the Web Console, audits activity volume, and provides comprehensive oversight of all fleet activity.
                      </p>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-white/10 flex items-center justify-between text-[10px] text-zinc-400 font-mono">
                    <span>TRANSPORT: SSE (HTTP)</span>
                    <span className="text-white font-bold">OPERATOR STREAM</span>
                  </div>
                </div>
              </div>

              {/* SINGLE SCREENSHOT HERO CARD (WATCHTOWER LIVE TELEMETRY) */}
              <div className="border border-white/20 rounded-2xl bg-[#09090b] p-5 sm:p-7 shadow-[0_20px_60px_rgba(0,0,0,0.9)] space-y-6 relative overflow-hidden">
                {/* Background Ambient Glow */}
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-32 bg-white/[0.03] blur-3xl rounded-full pointer-events-none" />

                {/* Aesthetic Browser Chrome Shell */}
                <div className="rounded-xl border border-white/20 bg-[#0d0d10] overflow-hidden shadow-2xl relative z-10">
                  {/* Console Header Bar */}
                  <div className="bg-[#141418] px-4 py-2 border-b border-white/10 flex items-center justify-between font-mono text-xs">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] uppercase tracking-wider font-bold text-zinc-400">INTERFACE SNAPSHOT</span>
                      <span className="text-zinc-600">·</span>
                      <span className="text-[10px] text-zinc-400 font-mono uppercase">WATCHTOWER LIVE TELEMETRY</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setLightboxOverride({
                          src: '/assets/product-section/watchtower/image_aca3acbd.png',
                          title: 'Watchtower Live Telemetry & Streaming Activity Feed',
                          description: 'Real-time Watchtower telemetry terminal displaying live fleet metrics (Clusters, Master Agent, Slave Agents) alongside a streaming event log with instant security policy enforcement (e.g. blocking unauthorized slave-to-slave link requests with HTTP 403 Forbidden).'
                        });
                        setIsLightboxOpen(true);
                      }}
                      className="px-2.5 py-1 bg-white/10 hover:bg-white text-zinc-300 hover:text-black rounded text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer"
                      title="Expand high-resolution inspection modal"
                    >
                      <Maximize2 className="w-3 h-3" />
                      <span>Full-Res Zoom</span>
                    </button>
                  </div>

                  {/* Studio Viewport Canvas */}
                  <div 
                    onClick={() => {
                      setLightboxOverride({
                        src: '/assets/product-section/watchtower/image_aca3acbd.png',
                        title: 'Watchtower Live Telemetry & Streaming Activity Feed',
                        description: 'Real-time Watchtower telemetry terminal displaying live fleet metrics (Clusters, Master Agent, Slave Agents) alongside a streaming event log with instant security policy enforcement (e.g. blocking unauthorized slave-to-slave link requests with HTTP 403 Forbidden).'
                      });
                      setIsLightboxOpen(true);
                    }}
                    className="relative cursor-pointer bg-gradient-to-b from-[#131316] via-[#09090b] to-[#040405] p-3 sm:p-6 lg:p-8 flex items-center justify-center min-h-[300px] sm:min-h-[460px] overflow-hidden group select-none"
                  >
                    {/* Subtle Radial Lighting Behind Screenshot */}
                    <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(255,255,255,0.08),transparent_65%)] pointer-events-none" />
                    <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:20px_20px] pointer-events-none" />

                    {/* Elevated Display Window */}
                    <div className="relative z-10 w-full max-w-4xl rounded-xl border border-white/25 bg-black shadow-[0_25px_80px_rgba(0,0,0,0.95)] overflow-hidden transition-all duration-300 group-hover:border-white/50 group-hover:shadow-[0_30px_90px_rgba(255,255,255,0.08)]">
                      <OptimizedImage 
                        src="/assets/product-section/watchtower/image_aca3acbd.png" 
                        alt="Watchtower Live Telemetry & Streaming Activity Feed" 
                        className="w-full h-auto max-h-[520px] object-contain mx-auto block transition-transform duration-300 group-hover:scale-[1.008]" 
                      />
                    </div>
                  </div>

                  {/* Contextual Narrative Strip */}
                  <div className="p-4 sm:p-6 bg-[#0e0e12] border-t border-white/10 font-mono text-left space-y-1.5">
                    <div className="flex items-center gap-2 text-xs">
                      <span className="text-white font-extrabold uppercase tracking-wider">WATCHTOWER LIVE TELEMETRY &amp; STREAMING ACTIVITY FEED</span>
                    </div>
                    <p className="text-zinc-400 text-xs font-sans leading-relaxed max-w-4xl">
                      Real-time Watchtower telemetry terminal displaying live fleet metrics (Clusters, Master Agent, Slave Agents) alongside a streaming event log with instant security policy enforcement (e.g. automatically rejecting unauthorized slave-to-slave link requests with HTTP 403 Forbidden).
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeModule === 'footprints-webhooks' && (
            <div className="space-y-8">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                <div className="lg:col-span-7 space-y-5">
                  <div className="flex items-center gap-2 text-xs font-mono text-zinc-400">
                    <FileText className="w-4 h-4 text-white" />
                    <span className="uppercase font-bold tracking-wider text-white">Footprints &amp; Webhooks</span>
                    <span className="text-zinc-600">·</span>
                    <span>Single-Node Observability</span>
                  </div>
                  <h3 className="text-2xl sm:text-3xl font-black uppercase text-white tracking-tight leading-tight">
                    Internal Node Footprints &amp; External Webhook Logs
                  </h3>
                  <p className="text-sm text-zinc-300 leading-relaxed font-sans">
                    Granular single-node tracking. Footprints record actions done directly BY the agent account (tool requests, state changes, cluster joins), while Webhooks track actions originating OUTSIDE of the account (such as incoming messages received, trigger callbacks, and outbound delivery receipts).
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 font-mono text-xs">
                    <div className="p-3.5 bg-black/60 rounded-xl border border-white/10">
                      <span className="font-bold text-white block mb-1">Account Footprints</span>
                      <span className="text-zinc-400 text-[11px] leading-relaxed block">
                        Actions done BY the account: tool requests, authentication events, cluster joins, and status changes.
                      </span>
                    </div>
                    <div className="p-3.5 bg-black/60 rounded-xl border border-white/10">
                      <span className="font-bold text-white block mb-1">External Webhooks</span>
                      <span className="text-zinc-400 text-[11px] leading-relaxed block">
                        Actions originating OUTSIDE the account: incoming messages received, external tool responses, and webhook callbacks.
                      </span>
                    </div>
                    <div className="p-3.5 bg-black/60 rounded-xl border border-white/10">
                      <span className="font-bold text-white block mb-1">Outbound Delivery Receipts</span>
                      <span className="text-zinc-400 text-[11px] leading-relaxed block">
                        Tracks delivery status, retry attempts, HTTP response status codes, and latency for dispatched webhooks.
                      </span>
                    </div>
                    <div className="p-3.5 bg-black/60 rounded-xl border border-white/10">
                      <span className="font-bold text-white block mb-1">Audit &amp; Forensic History</span>
                      <span className="text-zinc-400 text-[11px] leading-relaxed block">
                        Immutable second-by-second timeline combining agent choices and external signals for compliance audits.
                      </span>
                    </div>
                  </div>
                </div>

                <div className="lg:col-span-5 bg-black border border-white/15 rounded-xl p-6 font-mono text-xs shadow-2xl space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-white/10 text-zinc-400 text-[11px]">
                    <div className="flex items-center gap-2">
                      <FileText className="w-4 h-4 text-white shrink-0" />
                      <span className="text-white font-black uppercase tracking-wider">FOOTPRINTS_WEBHOOKS.SPECIFICATION</span>
                    </div>
                    <span className="text-zinc-400 uppercase text-[10px]">SINGLE-NODE LOGS</span>
                  </div>

                  <div className="space-y-3 pt-1">
                    <div className="p-3.5 bg-zinc-950 rounded-lg border border-white/10">
                      <span className="font-mono font-bold text-[10px] text-zinc-400 uppercase tracking-wider block mb-1">
                        Why It Is There:
                      </span>
                      <p className="text-zinc-200 text-xs font-sans leading-relaxed">
                        To provide forensic auditability for individual agent nodes, separating internal agent-initiated actions from external incoming triggers for compliance and debugging.
                      </p>
                    </div>

                    <div className="p-3.5 bg-zinc-950 rounded-lg border border-white/10">
                      <span className="font-mono font-bold text-[10px] text-white uppercase tracking-wider block mb-1">
                        What It Does:
                      </span>
                      <p className="text-zinc-200 text-xs font-sans leading-relaxed">
                        Logs an immutable timeline of agent-initiated choices (Footprints) alongside external incoming message signals and outbound webhook delivery receipts (Webhooks) on a second-by-second basis.
                      </p>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-white/10 flex items-center justify-between text-[10px] text-zinc-400 font-mono">
                    <span>AUDITSCOPE: SINGLE NODE</span>
                    <span className="text-white font-bold">TWO-WAY AUDIT LOGGED</span>
                  </div>
                </div>
              </div>

              {/* FOOTPRINTS & WEBHOOKS ACTIVITIES GALLERY (EXACT FLOOR / CLUSTER GALLERY FORMAT) */}
              <div className="border border-white/20 rounded-2xl bg-[#09090b] p-5 sm:p-7 shadow-[0_20px_60px_rgba(0,0,0,0.9)] space-y-6 relative overflow-hidden">
                {/* Background Ambient Glow */}
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-32 bg-white/[0.03] blur-3xl rounded-full pointer-events-none" />

                {/* Aesthetic Browser Chrome Shell */}
                <div className="rounded-xl border border-white/20 bg-[#0d0d10] overflow-hidden shadow-2xl relative z-10">
                  {/* Console Header Bar */}
                  <div className="bg-[#141418] px-4 py-2 border-b border-white/10 flex items-center justify-between font-mono text-xs">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] uppercase tracking-wider font-bold text-zinc-400">INBOUND &amp; OUTBOUND ACTIVITIES GALLERY</span>
                      <span className="text-zinc-600">·</span>
                      <span className="text-[10px] text-zinc-400 font-mono uppercase">{footprintsWebhooksScreenshots[activeFootprintsImage].stage}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setLightboxOverride({
                          src: footprintsWebhooksScreenshots[activeFootprintsImage].src,
                          title: footprintsWebhooksScreenshots[activeFootprintsImage].title,
                          description: footprintsWebhooksScreenshots[activeFootprintsImage].description
                        });
                        setIsLightboxOpen(true);
                      }}
                      className="px-2.5 py-1 bg-white/10 hover:bg-white text-zinc-300 hover:text-black rounded text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer"
                      title="Expand high-resolution inspection modal"
                    >
                      <Maximize2 className="w-3 h-3" />
                      <span>Full-Res Zoom</span>
                    </button>
                  </div>

                  {/* Studio Viewport Canvas */}
                  <div 
                    onClick={() => {
                      setLightboxOverride({
                        src: footprintsWebhooksScreenshots[activeFootprintsImage].src,
                        title: footprintsWebhooksScreenshots[activeFootprintsImage].title,
                        description: footprintsWebhooksScreenshots[activeFootprintsImage].description
                      });
                      setIsLightboxOpen(true);
                    }}
                    className="relative cursor-pointer bg-gradient-to-b from-[#131316] via-[#09090b] to-[#040405] p-3 sm:p-6 lg:p-8 flex items-center justify-center min-h-[300px] sm:min-h-[460px] overflow-hidden group select-none"
                  >
                    {/* Subtle Radial Lighting Behind Screenshot */}
                    <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(255,255,255,0.08),transparent_65%)] pointer-events-none" />
                    <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:20px_20px] pointer-events-none" />

                    {/* Left/Right Floating Quick Nav Buttons */}
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setActiveFootprintsImage((prev) => (prev - 1 + footprintsWebhooksScreenshots.length) % footprintsWebhooksScreenshots.length);
                      }}
                      className="absolute left-2 sm:left-4 z-20 p-2 sm:p-2.5 bg-black/80 hover:bg-white text-white hover:text-black border border-white/20 rounded-lg transition-all cursor-pointer shadow-xl opacity-75 group-hover:opacity-100"
                      title="Previous view"
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </button>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setActiveFootprintsImage((prev) => (prev + 1) % footprintsWebhooksScreenshots.length);
                      }}
                      className="absolute right-2 sm:right-4 z-20 p-2 sm:p-2.5 bg-black/80 hover:bg-white text-white hover:text-black border border-white/20 rounded-lg transition-all cursor-pointer shadow-xl opacity-75 group-hover:opacity-100"
                      title="Next view"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>

                    {/* Elevated Display Window */}
                    <div className="relative z-10 w-full max-w-4xl rounded-xl border border-white/25 bg-black shadow-[0_25px_80px_rgba(0,0,0,0.95)] overflow-hidden transition-all duration-300 group-hover:border-white/50 group-hover:shadow-[0_30px_90px_rgba(255,255,255,0.08)]">
                      <OptimizedImage 
                        src={footprintsWebhooksScreenshots[activeFootprintsImage].src} 
                        alt={footprintsWebhooksScreenshots[activeFootprintsImage].title}
                        className="w-full h-auto max-h-[520px] object-contain mx-auto block transition-transform duration-300 group-hover:scale-[1.008]" 
                      />
                    </div>
                  </div>

                  {/* Contextual Narrative Strip */}
                  <div className="p-4 sm:p-6 bg-[#0e0e12] border-t border-white/10 font-mono text-left space-y-1.5">
                    <div className="flex items-center gap-2 text-xs">
                      <span className="text-zinc-300 font-bold">{footprintsWebhooksScreenshots[activeFootprintsImage].stage}</span>
                      <span className="text-zinc-600">·</span>
                      <span className="text-white font-extrabold uppercase tracking-wider">{footprintsWebhooksScreenshots[activeFootprintsImage].title}</span>
                    </div>
                    <p className="text-zinc-400 text-xs font-sans leading-relaxed max-w-4xl">
                      {footprintsWebhooksScreenshots[activeFootprintsImage].subtitle}. {footprintsWebhooksScreenshots[activeFootprintsImage].description}
                    </p>
                  </div>
                </div>

                {/* Horizontal 2-Tab Switcher Strip */}
                <div className="overflow-x-auto pb-1">
                  <div className="grid grid-cols-2 gap-2 sm:gap-3 w-full pt-2">
                    {footprintsWebhooksScreenshots.map((item, idx) => {
                      const isSelected = activeFootprintsImage === idx;
                      return (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => setActiveFootprintsImage(idx)}
                          className={`p-1.5 sm:p-3.5 rounded-lg sm:rounded-xl border text-left transition-all cursor-pointer flex flex-col gap-1.5 sm:gap-2.5 ${
                            isSelected
                              ? 'bg-white/10 border-white ring-1 ring-white/50 shadow-[0_4px_20px_rgba(255,255,255,0.15)] scale-[1.005]'
                              : 'bg-black/70 border-white/10 hover:border-white/30 hover:bg-black/90'
                          }`}
                        >
                          <div className="relative aspect-[16/9] w-full bg-black rounded-md sm:rounded-lg overflow-hidden border border-white/15">
                            <OptimizedImage 
                              src={item.src} 
                              alt={item.title} 
                              className="w-full h-full object-cover object-top opacity-90 transition-opacity" 
                            />
                            <span className="absolute top-1 left-1 sm:top-2 sm:left-2 px-1 sm:px-2 py-0.5 bg-black/85 backdrop-blur-sm border border-white/20 text-[7px] sm:text-[9px] font-mono text-white rounded font-bold uppercase">
                              {item.badge}
                            </span>
                            {isSelected && (
                              <span className="absolute bottom-2 right-2 px-2 py-0.5 bg-white text-black text-[7px] sm:text-[8px] font-mono font-black uppercase rounded shadow">
                                Active View
                              </span>
                            )}
                          </div>
                          <div className="font-mono">
                            <span className="text-xs sm:text-sm font-bold text-white block truncate uppercase tracking-tight">
                              {item.shortLabel}
                            </span>
                            <span className="text-[10px] sm:text-xs text-zinc-400 block truncate font-sans mt-0.5">
                              {item.subtitle}
                            </span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* 4. COMPARISON MATRIX: AAMARVA VS TRADITIONAL LLM FRAMEWORKS */}
        <div className="mb-16">
          <div className="max-w-2xl mb-8">
            <span className="font-mono text-xs font-bold text-zinc-400 uppercase tracking-widest block mb-1">
              Architectural Standard
            </span>
            <h3 className="text-2xl sm:text-3xl font-black uppercase tracking-tight text-white">
              Why Governed Infrastructure Matters
            </h3>
            <p className="text-xs sm:text-sm text-zinc-300 mt-1">
              Most multi-agent frameworks rely on plain scripts and unbounded network access. AAMARVA introduces explicit authorization boundaries and permission controls built specifically for autonomous agents.
            </p>
          </div>

          <div className="overflow-x-auto border border-white/20 rounded-2xl bg-[#09090b]">
            <table className="w-full text-left font-mono text-xs">
              <thead>
                <tr className="border-b border-white/15 bg-white/5 text-zinc-300">
                  <th className="p-4 sm:p-5 font-bold uppercase">Capability</th>
                  <th className="p-4 sm:p-5 font-black uppercase text-white bg-white/10 border-x border-white/15">
                    AAMARVA Infrastructure
                  </th>
                  <th className="p-4 sm:p-5 font-normal uppercase text-zinc-500">
                    Traditional Scripting / Unmanaged Stacks
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/10 text-zinc-300 text-[11px] sm:text-xs">
                <tr>
                  <td className="p-4 sm:p-5 font-bold text-white">Tool Authorization & Discovery</td>
                  <td className="p-4 sm:p-5 bg-white/5 border-x border-white/15 text-white font-semibold">
                    <span className="text-white font-black">FLOOR MCP:</span> Governed tool access and authorized connection configuration
                  </td>
                  <td className="p-4 sm:p-5 text-zinc-400">
                    Raw API keys hardcoded into environment variables or prompt strings
                  </td>
                </tr>
                <tr>
                  <td className="p-4 sm:p-5 font-bold text-white">Agent-to-Agent Messaging</td>
                  <td className="p-4 sm:p-5 bg-white/5 border-x border-white/15 text-white font-semibold">
                    <span className="text-white font-black">Encrypted Workgroups:</span> Recipient-restricted visibility with Master Account inclusion
                  </td>
                  <td className="p-4 sm:p-5 text-zinc-400">
                    Plaintext HTTP or Redis queues without recipient checks or encryption
                  </td>
                </tr>
                <tr>
                  <td className="p-4 sm:p-5 font-bold text-white">Human Operator Authentication</td>
                  <td className="p-4 sm:p-5 bg-white/5 border-x border-white/15 text-white font-semibold">
                    <span className="text-white font-black">FIDO2 / WebAuthn:</span> Two-step password and passkey verification for operators
                  </td>
                  <td className="p-4 sm:p-5 text-zinc-400">
                    Command line inputs or static unprotected admin endpoints
                  </td>
                </tr>
                <tr>
                  <td className="p-4 sm:p-5 font-bold text-white">Fleet Hierarchy & Roles</td>
                  <td className="p-4 sm:p-5 bg-white/5 border-x border-white/15 text-white font-semibold">
                    <span className="text-white font-black">Master/Slave Architecture:</span> Central master account supervision over associated slave nodes
                  </td>
                  <td className="p-4 sm:p-5 text-zinc-400">
                    Flat unorganized processes with no role enforcement or permission boundaries
                  </td>
                </tr>
                <tr>
                  <td className="p-4 sm:p-5 font-bold text-white">Fleet Activity Monitoring</td>
                  <td className="p-4 sm:p-5 bg-white/5 border-x border-white/15 text-white font-semibold">
                    <span className="text-white font-black">Watchtower:</span> Streaming fleet activity view via SSE with structured footprint records
                  </td>
                  <td className="p-4 sm:p-5 text-zinc-400">
                    Ephemeral console logs without structured fleet records
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>



      </div>

      {/* Lightbox Modal for FLOOR Screenshots */}
      {isLightboxOpen && (
        <div 
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex flex-col justify-between p-4 sm:p-8 animate-in fade-in duration-200"
          onClick={() => setIsLightboxOpen(false)}
        >
          {/* Top Bar */}
          <div 
            className="w-full max-w-6xl mx-auto flex items-center justify-between pb-3 border-b border-white/15 font-mono text-xs text-white"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3">
              <span className="px-2 py-0.5 bg-white text-black font-extrabold uppercase rounded text-[10px]">
                {lightboxOverride ? 'INSPECTION' : floorScreenshots[activeFloorImage].stage}
              </span>
              <span className="font-bold uppercase tracking-wider truncate max-w-md">
                {lightboxOverride ? lightboxOverride.title : floorScreenshots[activeFloorImage].title}
              </span>
            </div>
            
            <button
              type="button"
              onClick={() => {
                setIsLightboxOpen(false);
                setLightboxOverride(null);
              }}
              className="px-3 py-1.5 bg-white text-black font-bold text-xs uppercase tracking-wider rounded-lg hover:bg-zinc-200 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <X className="w-4 h-4" />
              <span>Close (ESC)</span>
            </button>
          </div>

          {/* Main Full-Res Display with Next / Previous controls */}
          <div 
            className="flex-1 flex items-center justify-center relative my-4 w-full max-w-6xl mx-auto"
            onClick={(e) => e.stopPropagation()}
          >
            {!lightboxOverride && (
              <button
                type="button"
                onClick={() => setActiveFloorImage((prev) => (prev - 1 + floorScreenshots.length) % floorScreenshots.length)}
                className="absolute left-2 sm:left-4 z-10 p-3 bg-black/80 hover:bg-white hover:text-black text-white border border-white/20 rounded-xl transition-all cursor-pointer shadow-2xl"
                title="Previous Screenshot"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
            )}

            <OptimizedImage
              src={lightboxOverride ? lightboxOverride.src : floorScreenshots[activeFloorImage].src}
              alt={lightboxOverride ? lightboxOverride.title : floorScreenshots[activeFloorImage].title}
              className="max-h-[92vh] max-w-[96vw] w-auto max-w-full object-contain rounded-xl border border-white/20 shadow-[0_20px_60px_rgba(0,0,0,0.9)]"
            />

            {!lightboxOverride && (
              <button
                type="button"
                onClick={() => setActiveFloorImage((prev) => (prev + 1) % floorScreenshots.length)}
                className="absolute right-2 sm:right-4 z-10 p-3 bg-black/80 hover:bg-white hover:text-black text-white border border-white/20 rounded-xl transition-all cursor-pointer shadow-2xl"
                title="Next Screenshot"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            )}
          </div>

          {/* Bottom Bar with Metadata */}
          <div 
            className="w-full max-w-6xl mx-auto pt-3 border-t border-white/15 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs font-mono text-zinc-400"
            onClick={(e) => e.stopPropagation()}
          >
            <p className="text-zinc-300 text-xs font-sans max-w-2xl leading-relaxed">
              {lightboxOverride ? lightboxOverride.description : floorScreenshots[activeFloorImage].description}
            </p>
            {!lightboxOverride && (
              <div className="flex items-center gap-2">
                {floorScreenshots.map((item, idx) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setActiveFloorImage(idx)}
                    className={`w-3 h-3 rounded-full transition-all cursor-pointer ${
                      activeFloorImage === idx ? 'bg-white scale-125' : 'bg-white/30 hover:bg-white/60'
                    }`}
                    aria-label={`Go to screenshot ${idx + 1}`}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </section>
  );
};
