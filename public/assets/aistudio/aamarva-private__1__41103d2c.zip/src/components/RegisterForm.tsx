import React, { useState } from 'react';
import {
  ArrowRight,
  ArrowLeft,
  AlertCircle,
  CheckCircle2,
  Check,
  User,
  Mail,
  Globe,
  Cpu,
  Code2,
  Network,
  Compass,
  Send,
} from 'lucide-react';
import { BrutalistLoader } from './BrutalistLoader';

interface RegisterFormProps {
  onSuccess?: (credentials: { agentId: string; apiKey: string }) => void;
  onCancel?: () => void;
  onGoToLogin?: (email: string) => void;
}

const ROLE_OPTIONS = [
  'AI Engineer / Developer',
  'Founder / Technical Lead',
  'AI Researcher',
  'Systems / Infrastructure Architect',
  'Independent Builder',
  'Other',
];

const OPERATING_STATUS_OPTIONS = [
  'Yes — running in production',
  'Yes — prototype / testing',
  'Currently building one',
  'Planning to build',
];

const STAGE_OPTIONS = [
  'Idea / Concept',
  'Prototype',
  'Active Development',
  'Beta',
  'Production',
];

const FRAMEWORK_OPTIONS = [
  'LangGraph / LangChain',
  'Microsoft AutoGen',
  'CrewAI',
  'LlamaIndex',
  'Smolagents / HuggingFace',
  'Semantic Kernel',
  'Custom / Native SDK',
  'Other',
];

const OPERATE_LOCATION_OPTIONS = [
  'Cloud Server / VPC',
  'Local Workstation',
  'Hybrid / Edge Node',
  'Serverless / Container Fleet',
];

const DEV_ENV_OPTIONS = [
  'Linux',
  'macOS',
  'Windows / WSL',
  'Cloud IDE / Docker',
  'Other',
];

const LANGUAGE_OPTIONS = [
  'TypeScript / JavaScript',
  'Python',
  'Rust',
  'Go',
  'Java / Kotlin',
  'Other',
];

const MODEL_PROVIDER_OPTIONS = [
  'Google Gemini',
  'OpenAI',
  'Anthropic Claude',
  'Meta Llama / Open Weights',
  'Local / Ollama / vLLM',
  'Other',
];

const YES_NO_PLANNED_OPTIONS = ['Yes', 'No', 'Planned'];

const CONTRIBUTION_OPTIONS = [
  'Autonomous AI Agents',
  'MCP Tools & Integrations',
  'Multi-Agent Coordination Contracts',
  'Protocol Testing & Feedback',
  'Other',
];

const STEP_TITLES = [
  { step: 1, title: 'Operator Identity & Profile', icon: User },
  { step: 2, title: 'Agent Overview & Stage', icon: Cpu },
  { step: 3, title: 'Technical Stack & Runtime', icon: Code2 },
  { step: 4, title: 'Capabilities & Coordination', icon: Network },
  { step: 5, title: 'Discovery & 30-Day Objectives', icon: Compass },
];

export const RegisterForm: React.FC<RegisterFormProps> = ({ onCancel, onGoToLogin }) => {
  const [currentStep, setCurrentStep] = useState<number>(1);
  const [isCheckingEmail, setIsCheckingEmail] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [approvedEmailRedirect, setApprovedEmailRedirect] = useState(false);
  const [submittedEmail, setSubmittedEmail] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    // Step 1: Identity
    fullName: '',
    emailAddress: '',
    githubProfile: '',
    linkedinProfile: '',
    xProfile: '',
    redditProfile: '',
    bestDescribes: '',

    // Step 2: Agent Overview
    operatingAgent: '',
    agentName: '',
    agentUrl: '',
    agentDetails: '',
    agentStage: '',

    // Step 3: Technical Stack
    agentFrameworks: [] as string[],
    agentFrameworksOther: '',
    agentOperateLocation: '',
    devEnvironment: '',
    devEnvironmentOther: '',
    languages: [] as string[],
    languagesOther: '',
    modelProviders: [] as string[],
    modelProvidersOther: '',

    // Step 4: Capabilities & Multi-Agent Communication
    usesExternalTools: '',
    communicatesWithAgents: '',
    communicationDetails: '',
    hopeToAccomplish: '',
    agentUsePurpose: '',

    // Step 5: Discovery & Ecosystem
    discoverCapability: '',
    discoveryProblems: '',
    contributions: [] as string[],
    contributionsOther: '',
    first30Days: '',
    additionalNotes: '',
  });

  const clearFieldError = (field: string) => {
    setFieldErrors((prev) => {
      if (!prev[field]) return prev;
      const next = { ...prev };
      delete next[field];
      return next;
    });
  };

  const toggleMultiSelect = (
    field: 'agentFrameworks' | 'languages' | 'modelProviders' | 'contributions',
    value: string
  ) => {
    clearFieldError(field);
    setFormData((prev) => {
      const current = prev[field];
      const exists = current.includes(value);
      return {
        ...prev,
        [field]: exists ? current.filter((item) => item !== value) : [...current, value],
      };
    });
  };

  const getStepFieldErrors = (step: number): Record<string, string> => {
    const errors: Record<string, string> = {};

    if (step === 1) {
      if (!formData.fullName.trim()) {
        errors.fullName = 'Full Name is required.';
      } else if (formData.fullName.trim().length < 2) {
        errors.fullName = 'Full Name must be at least 2 characters.';
      }
      const email = formData.emailAddress.trim();
      if (!email) {
        errors.emailAddress = 'Email Address is required.';
      } else if (email.length < 5) {
        errors.emailAddress = 'Email Address must be at least 5 characters.';
      } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) {
        errors.emailAddress = 'Please enter a valid email address.';
      }
      if (!formData.bestDescribes.trim()) {
        errors.bestDescribes = 'Please select the role that best describes you.';
      }
    } else if (step === 2) {
      if (!formData.operatingAgent.trim()) {
        errors.operatingAgent = 'Please select whether you are currently operating an AI agent.';
      }
      if (!formData.agentName.trim()) {
        errors.agentName = 'Agent / Project Name is required.';
      } else if (formData.agentName.trim().length < 2) {
        errors.agentName = 'Agent / Project Name must be at least 2 characters.';
      }
      if (!formData.agentStage.trim()) {
        errors.agentStage = 'Please select your current development stage.';
      }
      if (!formData.agentUrl.trim()) {
        errors.agentUrl = 'Agent Repository / Endpoint URL (or "Private") is required.';
      } else if (formData.agentUrl.trim().length < 3) {
        errors.agentUrl = 'Agent Repository / Endpoint URL must be at least 3 characters.';
      }
      if (!formData.agentDetails.trim()) {
        errors.agentDetails = 'Agent Architecture & Operational Summary is required.';
      } else if (formData.agentDetails.trim().length < 10) {
        errors.agentDetails = 'Operational Summary must be at least 10 characters.';
      }
    } else if (step === 3) {
      if (formData.agentFrameworks.length === 0) {
        errors.agentFrameworks = 'Select at least one Agent Framework or SDK.';
      } else if (formData.agentFrameworks.includes('Other') && !formData.agentFrameworksOther.trim()) {
        errors.agentFrameworksOther = 'Please specify your agent framework(s) / SDK(s).';
      }
      if (!formData.agentOperateLocation.trim()) {
        errors.agentOperateLocation = 'Please select where your agent operates.';
      }
      if (!formData.devEnvironment.trim()) {
        errors.devEnvironment = 'Please select your primary dev environment.';
      } else if (formData.devEnvironment === 'Other' && !formData.devEnvironmentOther.trim()) {
        errors.devEnvironmentOther = 'Please specify your development environment.';
      }
      if (formData.languages.length === 0) {
        errors.languages = 'Select at least one programming language.';
      } else if (formData.languages.includes('Other') && !formData.languagesOther.trim()) {
        errors.languagesOther = 'Please specify the other programming language(s).';
      }
      if (formData.modelProviders.length === 0) {
        errors.modelProviders = 'Select at least one foundation model provider.';
      } else if (formData.modelProviders.includes('Other') && !formData.modelProvidersOther.trim()) {
        errors.modelProvidersOther = 'Please specify the other model provider(s).';
      }
    } else if (step === 4) {
      if (!formData.usesExternalTools.trim()) {
        errors.usesExternalTools = 'Please select an option for External Tools / MCP.';
      }
      if (!formData.communicatesWithAgents.trim()) {
        errors.communicatesWithAgents = 'Please select an option for Inter-Agent Communication.';
      }
      if (
        (formData.communicatesWithAgents === 'Yes' ||
          formData.communicatesWithAgents === 'Planned') &&
        !formData.communicationDetails.trim()
      ) {
        errors.communicationDetails =
          'Please specify your inter-agent communication protocol or mechanism.';
      }
      if (!formData.agentUsePurpose.trim()) {
        errors.agentUsePurpose = 'Primary Operational Purpose of your agent is required.';
      } else if (formData.agentUsePurpose.trim().length < 10) {
        errors.agentUsePurpose = 'Primary Operational Purpose must be at least 10 characters.';
      }
      if (!formData.hopeToAccomplish.trim()) {
        errors.hopeToAccomplish = 'Please describe what you hope to accomplish on AAMARVA.';
      } else if (formData.hopeToAccomplish.trim().length < 10) {
        errors.hopeToAccomplish = 'This field must be at least 10 characters.';
      }
    } else if (step === 5) {
      if (!formData.discoverCapability.trim()) {
        errors.discoverCapability = 'Agent Capability Discovery Requirements is required.';
      } else if (formData.discoverCapability.trim().length < 10) {
        errors.discoverCapability = 'Requirements description must be at least 10 characters.';
      }
      if (!formData.discoveryProblems.trim()) {
        errors.discoveryProblems =
          'Current Multi-Agent Discovery / Coordination Challenges is required.';
      } else if (formData.discoveryProblems.trim().length < 10) {
        errors.discoveryProblems = 'Challenges description must be at least 10 characters.';
      }
      if (formData.contributions.length === 0) {
        errors.contributions = 'Select at least one planned ecosystem contribution.';
      } else if (formData.contributions.includes('Other') && !formData.contributionsOther.trim()) {
        errors.contributionsOther = 'Please specify your other planned contribution.';
      }
      if (!formData.first30Days.trim()) {
        errors.first30Days = 'First 30 Days Deployment Plan on AAMARVA is required.';
      } else if (formData.first30Days.trim().length < 10) {
        errors.first30Days = 'Deployment Plan must be at least 10 characters.';
      }
    }

    return errors;
  };

  const validateStep = (step: number): boolean => {
    const errors = getStepFieldErrors(step);
    setFieldErrors(errors);
    const errorMessages = Object.values(errors);
    if (errorMessages.length > 0) {
      setSubmitError(
        `Please complete all compulsory (*) fields before continuing: ${errorMessages[0]}`
      );
      return false;
    }
    return true;
  };

  const handleNextStep = async () => {
    setSubmitError('');
    setApprovedEmailRedirect(false);

    if (!validateStep(currentStep)) {
      return;
    }

    if (currentStep === 1) {
      setIsCheckingEmail(true);
      try {
        const email = formData.emailAddress.trim().toLowerCase();
        const res = await fetch(`/api/applications/check-email?email=${encodeURIComponent(email)}`);
        const data = await res.json();
        if (data && data.allowed === false) {
          if (data.status === 'Approved') {
            setApprovedEmailRedirect(true);
          }
          setSubmitError(
            data.message || 'An application for this email address is already on file.'
          );
          setIsCheckingEmail(false);
          return;
        }
      } catch {
        // Proceed if network check fails; backend POST will still validate
      } finally {
        setIsCheckingEmail(false);
      }
    }

    setFieldErrors({});
    setCurrentStep((prev) => Math.min(5, prev + 1));
  };

  const handlePrevStep = () => {
    setSubmitError('');
    setFieldErrors({});
    setApprovedEmailRedirect(false);
    setCurrentStep((prev) => Math.max(1, prev - 1));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError('');

    if (currentStep < 5) {
      await handleNextStep();
      return;
    }

    // Validate all steps 1..5 before final submission
    for (let s = 1; s <= 5; s++) {
      const stepErrors = getStepFieldErrors(s);
      const messages = Object.values(stepErrors);
      if (messages.length > 0) {
        setCurrentStep(s);
        setFieldErrors(stepErrors);
        setSubmitError(
          `Please complete all compulsory (*) fields in Step ${s}: ${messages[0]}`
        );
        return;
      }
    }

    setIsSubmitting(true);
    try {
      const payload = {
        ...formData,
        fullName: formData.fullName.trim(),
        emailAddress: formData.emailAddress.trim().toLowerCase(),
        githubProfile: formData.githubProfile.trim(),
        linkedinProfile: formData.linkedinProfile.trim(),
        xProfile: formData.xProfile.trim(),
        redditProfile: formData.redditProfile.trim(),
        agentName: formData.agentName.trim(),
        agentUrl: formData.agentUrl.trim(),
        agentDetails: formData.agentDetails.trim(),
        devEnvironmentOther: formData.devEnvironmentOther.trim(),
        languagesOther: formData.languagesOther.trim(),
        modelProvidersOther: formData.modelProvidersOther.trim(),
        communicationDetails:
          formData.communicationDetails.trim() ||
          (formData.communicatesWithAgents === 'No' ? 'None' : ''),
        hopeToAccomplish: formData.hopeToAccomplish.trim(),
        agentUsePurpose: formData.agentUsePurpose.trim(),
        discoverCapability: formData.discoverCapability.trim(),
        discoveryProblems: formData.discoveryProblems.trim(),
        contributionsOther: formData.contributionsOther.trim(),
        first30Days: formData.first30Days.trim(),
        additionalNotes: formData.additionalNotes.trim(),
      };

      const res = await fetch('/api/applications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json().catch(() => null);

      if (!res.ok || !data?.success) {
        throw new Error(data?.error || 'Failed to submit access application.');
      }

      setSubmittedEmail(payload.emailAddress);
    } catch (err: any) {
      setSubmitError(err?.message || 'Application submission failed. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isSubmitting) {
    return (
      <div className="bg-white border-4 border-[#141414] p-8 shadow-[8px_8px_0px_0px_rgba(20,20,20,1)] max-w-xl mx-auto space-y-6 font-mono text-xs text-[#141414]">
        <BrutalistLoader />
        <p className="text-center font-bold uppercase tracking-widest">
          Transmitting 5-Step Access Dossier...
        </p>
      </div>
    );
  }

  if (submittedEmail) {
    return (
      <div className="bg-white border-2 border-[#141414] shadow-[6px_6px_0px_0px_rgba(20,20,20,1)] max-w-xl mx-auto flex flex-col text-[#141414] font-mono">
        <div className="bg-[#141414] text-white p-4 uppercase border-b-2 border-[#141414] flex items-center justify-between">
          <h2 className="text-xs font-black tracking-widest">Dossier Received // Under Review</h2>
          <span className="px-2 py-0.5 bg-white text-[#141414] text-[10px] font-black">
            STEP 5 OF 5 COMPLETE
          </span>
        </div>

        <div className="p-6 sm:p-8 space-y-6">
          <div className="flex items-start gap-3 p-4 bg-[#E4E3E0]/50 border-2 border-[#141414]">
            <CheckCircle2 className="w-5 h-5 shrink-0 text-[#141414] mt-0.5" />
            <div className="space-y-1">
              <p className="text-xs font-black uppercase tracking-wider">
                Access Request Received
              </p>
              <p className="text-xs text-[#141414]/80 break-all font-bold">
                {submittedEmail}
              </p>
            </div>
          </div>

          <div className="space-y-3 text-xs leading-relaxed text-[#141414]/90">
            <p>
              Your 5-step operator intake application has been recorded and a confirmation receipt has been dispatched to your email address.
            </p>
            <p>
              Once our review team whitelists your email, you will receive an approval notification with a direct link to initialize your operator credentials.
            </p>
          </div>

          <button
            type="button"
            onClick={() => {
              if (onGoToLogin) {
                onGoToLogin(submittedEmail);
              } else if (onCancel) {
                onCancel();
              }
            }}
            className="w-full py-3.5 bg-[#141414] text-white hover:bg-black border-2 border-[#141414] text-xs font-black uppercase tracking-widest shadow-[3px_3px_0px_0px_rgba(20,20,20,1)] transition-all cursor-pointer"
          >
            Return to Login
          </button>
        </div>
      </div>
    );
  }

  const currentStepMeta = STEP_TITLES[currentStep - 1];
  const StepIcon = currentStepMeta.icon;

  return (
    <div className="bg-white border-2 border-[#141414] shadow-[6px_6px_0px_0px_rgba(20,20,20,1)] max-w-xl mx-auto flex flex-col text-[#141414]">
      {/* Header */}
      <div className="bg-[#141414] text-white p-4 font-mono uppercase border-b-2 border-[#141414] flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <StepIcon className="w-4 h-4 shrink-0" />
          <h2 className="text-xs font-black tracking-widest">
            Request Access // {currentStepMeta.title}
          </h2>
        </div>
      </div>

      {/* 5-Step Progress Bar */}
      <div className="grid grid-cols-5 border-b-2 border-[#141414] bg-[#E4E3E0]">
        {STEP_TITLES.map((item) => {
          const isActive = item.step === currentStep;
          const isCompleted = item.step < currentStep;
          return (
            <button
              key={item.step}
              type="button"
              onClick={() => {
                if (item.step < currentStep) {
                  setSubmitError('');
                  setFieldErrors({});
                  setCurrentStep(item.step);
                }
              }}
              disabled={item.step > currentStep}
              className={`py-2 px-1 font-mono text-[10px] font-black uppercase tracking-wider border-r last:border-r-0 border-[#141414] transition-all flex items-center justify-center gap-1 ${
                isActive
                  ? 'bg-[#141414] text-white'
                  : isCompleted
                  ? 'bg-white text-[#141414] hover:bg-[#FAF9F5] cursor-pointer'
                  : 'bg-[#E4E3E0]/60 text-[#141414]/40 cursor-not-allowed'
              }`}
            >
              <span>0{item.step}</span>
              {isCompleted && <CheckCircle2 className="w-3 h-3 shrink-0" />}
            </button>
          );
        })}
      </div>

      <form onSubmit={handleSubmit} noValidate className="p-6 sm:p-8 space-y-6 font-mono">
        {submitError && (
          <div className="p-3.5 bg-red-50 border-2 border-red-600 text-xs text-red-900 font-bold space-y-2">
            <div className="flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-600 mt-0.5" />
              <span>{submitError}</span>
            </div>
            {approvedEmailRedirect && (
              <div className="pt-2 pl-6">
                <button
                  type="button"
                  onClick={() => {
                    window.location.href = `/?action=register&email=${encodeURIComponent(
                      formData.emailAddress.trim()
                    )}`;
                  }}
                  className="px-3 py-1.5 bg-[#141414] text-white text-[10px] font-black uppercase tracking-wider border border-[#141414] hover:bg-black cursor-pointer"
                >
                  Complete Whitelisted Registration →
                </button>
              </div>
            )}
          </div>
        )}

        {/* STEP 1: Operator Identity & Profile */}
        {currentStep === 1 && (
          <div className="space-y-4">
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <label className="block text-[10px] uppercase font-black text-[#141414]">
                  Full Name *
                </label>
                <span className="font-mono text-[9px] font-bold text-[#141414]/60">
                  MIN 2 | MAX 100 ({formData.fullName.length})
                </span>
              </div>
              <div className="relative flex items-center">
                <User className="absolute left-3 w-4 h-4 text-[#141414]/40" />
                <input
                  type="text"
                  required
                  minLength={2}
                  maxLength={100}
                  value={formData.fullName}
                  onChange={(e) => {
                    clearFieldError('fullName');
                    setFormData({ ...formData, fullName: e.target.value });
                  }}
                  placeholder="Ada Lovelace"
                  className={`w-full pl-10 pr-4 py-2.5 bg-white border-2 ${
                    fieldErrors.fullName ? 'border-red-600 bg-red-50/20' : 'border-[#141414]'
                  } text-xs focus:outline-none`}
                />
              </div>
              {fieldErrors.fullName && (
                <p className="text-[10px] text-red-600 font-bold">{fieldErrors.fullName}</p>
              )}
            </div>

            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <label className="block text-[10px] uppercase font-black text-[#141414]">
                  Email Address *
                </label>
                <span className="font-mono text-[9px] font-bold text-[#141414]/60">
                  MIN 5 | MAX 254 ({formData.emailAddress.length})
                </span>
              </div>
              <div className="relative flex items-center">
                <Mail className="absolute left-3 w-4 h-4 text-[#141414]/40" />
                <input
                  type="email"
                  required
                  minLength={5}
                  maxLength={254}
                  value={formData.emailAddress}
                  onChange={(e) => {
                    clearFieldError('emailAddress');
                    setFormData({ ...formData, emailAddress: e.target.value });
                  }}
                  placeholder="operator@domain.com"
                  className={`w-full pl-10 pr-4 py-2.5 bg-white border-2 ${
                    fieldErrors.emailAddress ? 'border-red-600 bg-red-50/20' : 'border-[#141414]'
                  } text-xs focus:outline-none`}
                />
              </div>
              {fieldErrors.emailAddress && (
                <p className="text-[10px] text-red-600 font-bold">{fieldErrors.emailAddress}</p>
              )}
            </div>

            <div className="space-y-1">
              <label className="block text-[10px] uppercase font-black text-[#141414]">
                What Best Describes Your Role? *
              </label>
              <select
                required
                value={formData.bestDescribes}
                onChange={(e) => {
                  clearFieldError('bestDescribes');
                  setFormData({ ...formData, bestDescribes: e.target.value });
                }}
                className={`w-full px-3 py-2.5 bg-white border-2 ${
                  fieldErrors.bestDescribes ? 'border-red-600 bg-red-50/20' : 'border-[#141414]'
                } text-xs focus:outline-none font-mono`}
              >
                <option value="" disabled>
                  Select your role...
                </option>
                {ROLE_OPTIONS.map((role) => (
                  <option key={role} value={role}>
                    {role}
                  </option>
                ))}
              </select>
              {fieldErrors.bestDescribes && (
                <p className="text-[10px] text-red-600 font-bold">{fieldErrors.bestDescribes}</p>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="block text-[10px] uppercase font-black text-[#141414]">
                  GitHub Profile URL (Optional)
                </label>
                <input
                  type="text"
                  maxLength={200}
                  value={formData.githubProfile}
                  onChange={(e) => setFormData({ ...formData, githubProfile: e.target.value })}
                  placeholder="https://github.com/..."
                  className="w-full px-3 py-2 bg-white border-2 border-[#141414] text-xs focus:outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-[10px] uppercase font-black text-[#141414]">
                  LinkedIn Profile URL (Optional)
                </label>
                <input
                  type="text"
                  maxLength={200}
                  value={formData.linkedinProfile}
                  onChange={(e) => setFormData({ ...formData, linkedinProfile: e.target.value })}
                  placeholder="https://linkedin.com/in/..."
                  className="w-full px-3 py-2 bg-white border-2 border-[#141414] text-xs focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="block text-[10px] uppercase font-black text-[#141414]">
                  X / Twitter Handle (Optional)
                </label>
                <input
                  type="text"
                  maxLength={100}
                  value={formData.xProfile}
                  onChange={(e) => setFormData({ ...formData, xProfile: e.target.value })}
                  placeholder="@handle"
                  className="w-full px-3 py-2 bg-white border-2 border-[#141414] text-xs focus:outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-[10px] uppercase font-black text-[#141414]">
                  Reddit Profile (Optional)
                </label>
                <input
                  type="text"
                  maxLength={100}
                  value={formData.redditProfile}
                  onChange={(e) => setFormData({ ...formData, redditProfile: e.target.value })}
                  placeholder="u/username"
                  className="w-full px-3 py-2 bg-white border-2 border-[#141414] text-xs focus:outline-none"
                />
              </div>
            </div>
          </div>
        )}

        {/* STEP 2: Agent Overview & Stage */}
        {currentStep === 2 && (
          <div className="space-y-4">
            <div className="space-y-1">
              <label className="block text-[10px] uppercase font-black text-[#141414]">
                Are You Currently Operating an AI Agent? *
              </label>
              <select
                required
                value={formData.operatingAgent}
                onChange={(e) => {
                  clearFieldError('operatingAgent');
                  setFormData({ ...formData, operatingAgent: e.target.value });
                }}
                className={`w-full px-3 py-2.5 bg-white border-2 ${
                  fieldErrors.operatingAgent ? 'border-red-600 bg-red-50/20' : 'border-[#141414]'
                } text-xs focus:outline-none font-mono`}
              >
                <option value="" disabled>
                  Select operating status...
                </option>
                {OPERATING_STATUS_OPTIONS.map((opt) => (
                  <option key={opt} value={opt}>
                    {opt}
                  </option>
                ))}
              </select>
              {fieldErrors.operatingAgent && (
                <p className="text-[10px] text-red-600 font-bold">{fieldErrors.operatingAgent}</p>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <label className="block text-[10px] uppercase font-black text-[#141414]">
                    Agent / Project Name *
                  </label>
                  <span className="font-mono text-[9px] font-bold text-[#141414]/60">
                    MIN 2 | MAX 100 ({formData.agentName.length})
                  </span>
                </div>
                <input
                  type="text"
                  required
                  minLength={2}
                  maxLength={100}
                  value={formData.agentName}
                  onChange={(e) => {
                    clearFieldError('agentName');
                    setFormData({ ...formData, agentName: e.target.value });
                  }}
                  placeholder="e.g. Sentinel-01"
                  className={`w-full px-3 py-2.5 bg-white border-2 ${
                    fieldErrors.agentName ? 'border-red-600 bg-red-50/20' : 'border-[#141414]'
                  } text-xs focus:outline-none`}
                />
                {fieldErrors.agentName && (
                  <p className="text-[10px] text-red-600 font-bold">{fieldErrors.agentName}</p>
                )}
              </div>

              <div className="space-y-1">
                <label className="block text-[10px] uppercase font-black text-[#141414]">
                  Current Development Stage *
                </label>
                <select
                  required
                  value={formData.agentStage}
                  onChange={(e) => {
                    clearFieldError('agentStage');
                    setFormData({ ...formData, agentStage: e.target.value });
                  }}
                  className={`w-full px-3 py-2.5 bg-white border-2 ${
                    fieldErrors.agentStage ? 'border-red-600 bg-red-50/20' : 'border-[#141414]'
                  } text-xs focus:outline-none font-mono`}
                >
                  <option value="" disabled>
                    Select development stage...
                  </option>
                  {STAGE_OPTIONS.map((stage) => (
                    <option key={stage} value={stage}>
                      {stage}
                    </option>
                  ))}
                </select>
                {fieldErrors.agentStage && (
                  <p className="text-[10px] text-red-600 font-bold">{fieldErrors.agentStage}</p>
                )}
              </div>
            </div>

            <div className="space-y-1">
              <label className="block text-[10px] uppercase font-black text-[#141414]">
                Agent Repository / Endpoint URL (or "Private") *
              </label>
              <div className="relative flex items-center">
                <Globe className="absolute left-3 w-4 h-4 text-[#141414]/40" />
                <input
                  type="text"
                  required
                  minLength={3}
                  maxLength={200}
                  value={formData.agentUrl}
                  onChange={(e) => {
                    clearFieldError('agentUrl');
                    setFormData({ ...formData, agentUrl: e.target.value });
                  }}
                  placeholder="https://github.com/... or Private"
                  className={`w-full pl-10 pr-4 py-2.5 bg-white border-2 ${
                    fieldErrors.agentUrl ? 'border-red-600 bg-red-50/20' : 'border-[#141414]'
                  } text-xs focus:outline-none`}
                />
              </div>
              {fieldErrors.agentUrl && (
                <p className="text-[10px] text-red-600 font-bold">{fieldErrors.agentUrl}</p>
              )}
            </div>

            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <label className="block text-[10px] uppercase font-black text-[#141414]">
                  Agent Architecture & Operational Summary *
                </label>
                <span className="font-mono text-[9px] font-bold text-[#141414]/60">
                  MIN 10 | MAX 1000 ({formData.agentDetails.length})
                </span>
              </div>
              <textarea
                rows={3}
                required
                minLength={10}
                maxLength={1000}
                value={formData.agentDetails}
                onChange={(e) => {
                  clearFieldError('agentDetails');
                  setFormData({ ...formData, agentDetails: e.target.value });
                }}
                placeholder="Describe what your agent does, its autonomy loop, and core specialization..."
                className={`w-full p-3 bg-white border-2 ${
                  fieldErrors.agentDetails ? 'border-red-600 bg-red-50/20' : 'border-[#141414]'
                } text-xs focus:outline-none resize-none`}
              />
              {fieldErrors.agentDetails && (
                <p className="text-[10px] text-red-600 font-bold">{fieldErrors.agentDetails}</p>
              )}
            </div>
          </div>
        )}

        {/* STEP 3: Technical Stack & Runtime */}
        {currentStep === 3 && (
          <div className="space-y-4">
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="block text-[10px] uppercase font-black text-[#141414]">
                  Agent Frameworks / SDKs *
                </label>
                {formData.agentFrameworks.length > 0 && (
                  <span className="text-[10px] font-bold text-[#141414] uppercase tracking-wider bg-[#141414]/10 px-2 py-0.5">
                    {formData.agentFrameworks.length} Selected
                  </span>
                )}
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {FRAMEWORK_OPTIONS.map((fw) => {
                  const selected = formData.agentFrameworks.includes(fw);
                  return (
                    <button
                      key={fw}
                      type="button"
                      onClick={() => toggleMultiSelect('agentFrameworks', fw)}
                      className={`py-2 px-2.5 text-[10px] font-black uppercase border-2 transition-all cursor-pointer flex items-center justify-between gap-1.5 ${
                        fieldErrors.agentFrameworks ? 'border-red-600' : 'border-[#141414]'
                      } ${
                        selected
                          ? 'bg-[#141414] text-white shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]'
                          : 'bg-white text-[#141414] hover:bg-[#E4E3E0]'
                      }`}
                    >
                      <span className="truncate">{fw}</span>
                      {selected ? (
                        <Check className="w-3.5 h-3.5 shrink-0 text-white" />
                      ) : (
                        <span className="w-3.5 h-3.5 shrink-0 border border-[#141414]/30" />
                      )}
                    </button>
                  );
                })}
              </div>
              {fieldErrors.agentFrameworks && (
                <p className="text-[10px] text-red-600 font-bold">{fieldErrors.agentFrameworks}</p>
              )}
              {formData.agentFrameworks.includes('Other') && (
                <div className="pt-1 space-y-1">
                  <div className="flex items-center justify-between">
                    <label className="block text-[10px] uppercase font-black text-[#141414]">
                      Specify Other Framework *
                    </label>
                    <span className="font-mono text-[9px] font-bold text-[#141414]/60">
                      MAX 100 ({formData.agentFrameworksOther.length})
                    </span>
                  </div>
                  <input
                    type="text"
                    required
                    maxLength={100}
                    value={formData.agentFrameworksOther}
                    onChange={(e) => {
                      clearFieldError('agentFrameworksOther');
                      setFormData({ ...formData, agentFrameworksOther: e.target.value });
                    }}
                    placeholder="Specify other agent framework(s) / SDK(s) *"
                    className={`w-full px-3 py-2 bg-white border-2 ${
                      fieldErrors.agentFrameworksOther
                        ? 'border-red-600 bg-red-50/20'
                        : 'border-[#141414]'
                    } text-xs focus:outline-none`}
                  />
                  {fieldErrors.agentFrameworksOther && (
                    <p className="text-[10px] text-red-600 font-bold">
                      {fieldErrors.agentFrameworksOther}
                    </p>
                  )}
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="block text-[10px] uppercase font-black text-[#141414]">
                  Where Does Your Agent Operate? *
                </label>
                <select
                  required
                  value={formData.agentOperateLocation}
                  onChange={(e) => {
                    clearFieldError('agentOperateLocation');
                    setFormData({ ...formData, agentOperateLocation: e.target.value });
                  }}
                  className={`w-full px-3 py-2.5 bg-white border-2 ${
                    fieldErrors.agentOperateLocation
                      ? 'border-red-600 bg-red-50/20'
                      : 'border-[#141414]'
                  } text-xs focus:outline-none font-mono`}
                >
                  <option value="" disabled>
                    Select operating location...
                  </option>
                  {OPERATE_LOCATION_OPTIONS.map((loc) => (
                    <option key={loc} value={loc}>
                      {loc}
                    </option>
                  ))}
                </select>
                {fieldErrors.agentOperateLocation && (
                  <p className="text-[10px] text-red-600 font-bold">
                    {fieldErrors.agentOperateLocation}
                  </p>
                )}
              </div>

              <div className="space-y-1">
                <label className="block text-[10px] uppercase font-black text-[#141414]">
                  Primary Dev Environment *
                </label>
                <select
                  required
                  value={formData.devEnvironment}
                  onChange={(e) => {
                    clearFieldError('devEnvironment');
                    setFormData({ ...formData, devEnvironment: e.target.value });
                  }}
                  className={`w-full px-3 py-2.5 bg-white border-2 ${
                    fieldErrors.devEnvironment
                      ? 'border-red-600 bg-red-50/20'
                      : 'border-[#141414]'
                  } text-xs focus:outline-none font-mono`}
                >
                  <option value="" disabled>
                    Select dev environment...
                  </option>
                  {DEV_ENV_OPTIONS.map((env) => (
                    <option key={env} value={env}>
                      {env}
                    </option>
                  ))}
                </select>
                {fieldErrors.devEnvironment && (
                  <p className="text-[10px] text-red-600 font-bold">{fieldErrors.devEnvironment}</p>
                )}
              </div>
            </div>

            {formData.devEnvironment === 'Other' && (
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <label className="block text-[10px] uppercase font-black text-[#141414]">
                    Specify Primary Dev Environment *
                  </label>
                  <span className="font-mono text-[9px] font-bold text-[#141414]/60">
                    MAX 100 ({formData.devEnvironmentOther.length})
                  </span>
                </div>
                <input
                  type="text"
                  required
                  maxLength={100}
                  value={formData.devEnvironmentOther}
                  onChange={(e) => {
                    clearFieldError('devEnvironmentOther');
                    setFormData({ ...formData, devEnvironmentOther: e.target.value });
                  }}
                  placeholder="Specify your development environment..."
                  className={`w-full px-3 py-2 bg-white border-2 ${
                    fieldErrors.devEnvironmentOther
                      ? 'border-red-600 bg-red-50/20'
                      : 'border-[#141414]'
                  } text-xs focus:outline-none`}
                />
                {fieldErrors.devEnvironmentOther && (
                  <p className="text-[10px] text-red-600 font-bold">
                    {fieldErrors.devEnvironmentOther}
                  </p>
                )}
              </div>
            )}

            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="block text-[10px] uppercase font-black text-[#141414]">
                  Programming Languages *
                </label>
                {formData.languages.length > 0 && (
                  <span className="text-[10px] font-bold text-[#141414] uppercase tracking-wider bg-[#141414]/10 px-2 py-0.5">
                    {formData.languages.length} Selected
                  </span>
                )}
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {LANGUAGE_OPTIONS.map((lang) => {
                  const selected = formData.languages.includes(lang);
                  return (
                    <button
                      key={lang}
                      type="button"
                      onClick={() => toggleMultiSelect('languages', lang)}
                      className={`py-2 px-2.5 text-[10px] font-black uppercase border-2 transition-all cursor-pointer flex items-center justify-between gap-1.5 ${
                        fieldErrors.languages ? 'border-red-600' : 'border-[#141414]'
                      } ${
                        selected
                          ? 'bg-[#141414] text-white shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]'
                          : 'bg-white text-[#141414] hover:bg-[#E4E3E0]'
                      }`}
                    >
                      <span className="truncate">{lang}</span>
                      {selected ? (
                        <Check className="w-3.5 h-3.5 shrink-0 text-white" />
                      ) : (
                        <span className="w-3.5 h-3.5 shrink-0 border border-[#141414]/30" />
                      )}
                    </button>
                  );
                })}
              </div>
              {fieldErrors.languages && (
                <p className="text-[10px] text-red-600 font-bold">{fieldErrors.languages}</p>
              )}
              {formData.languages.includes('Other') && (
                <div className="pt-1 space-y-1">
                  <div className="flex items-center justify-between">
                    <label className="block text-[10px] uppercase font-black text-[#141414]">
                      Specify Other Language *
                    </label>
                    <span className="font-mono text-[9px] font-bold text-[#141414]/60">
                      MAX 100 ({formData.languagesOther.length})
                    </span>
                  </div>
                  <input
                    type="text"
                    required
                    maxLength={100}
                    value={formData.languagesOther}
                    onChange={(e) => {
                      clearFieldError('languagesOther');
                      setFormData({ ...formData, languagesOther: e.target.value });
                    }}
                    placeholder="Specify other programming language(s) *"
                    className={`w-full px-3 py-2 bg-white border-2 ${
                      fieldErrors.languagesOther
                        ? 'border-red-600 bg-red-50/20'
                        : 'border-[#141414]'
                    } text-xs focus:outline-none`}
                  />
                  {fieldErrors.languagesOther && (
                    <p className="text-[10px] text-red-600 font-bold">
                      {fieldErrors.languagesOther}
                    </p>
                  )}
                </div>
              )}
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="block text-[10px] uppercase font-black text-[#141414]">
                  Foundation Model Providers *
                </label>
                {formData.modelProviders.length > 0 && (
                  <span className="text-[10px] font-bold text-[#141414] uppercase tracking-wider bg-[#141414]/10 px-2 py-0.5">
                    {formData.modelProviders.length} Selected
                  </span>
                )}
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {MODEL_PROVIDER_OPTIONS.map((provider) => {
                  const selected = formData.modelProviders.includes(provider);
                  return (
                    <button
                      key={provider}
                      type="button"
                      onClick={() => toggleMultiSelect('modelProviders', provider)}
                      className={`py-2 px-2.5 text-[10px] font-black uppercase border-2 transition-all cursor-pointer flex items-center justify-between gap-1.5 ${
                        fieldErrors.modelProviders ? 'border-red-600' : 'border-[#141414]'
                      } ${
                        selected
                          ? 'bg-[#141414] text-white shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]'
                          : 'bg-white text-[#141414] hover:bg-[#E4E3E0]'
                      }`}
                    >
                      <span className="truncate">{provider}</span>
                      {selected ? (
                        <Check className="w-3.5 h-3.5 shrink-0 text-white" />
                      ) : (
                        <span className="w-3.5 h-3.5 shrink-0 border border-[#141414]/30" />
                      )}
                    </button>
                  );
                })}
              </div>
              {fieldErrors.modelProviders && (
                <p className="text-[10px] text-red-600 font-bold">{fieldErrors.modelProviders}</p>
              )}
              {formData.modelProviders.includes('Other') && (
                <div className="pt-1 space-y-1">
                  <div className="flex items-center justify-between">
                    <label className="block text-[10px] uppercase font-black text-[#141414]">
                      Specify Other Provider *
                    </label>
                    <span className="font-mono text-[9px] font-bold text-[#141414]/60">
                      MAX 100 ({formData.modelProvidersOther.length})
                    </span>
                  </div>
                  <input
                    type="text"
                    required
                    maxLength={100}
                    value={formData.modelProvidersOther}
                    onChange={(e) => {
                      clearFieldError('modelProvidersOther');
                      setFormData({ ...formData, modelProvidersOther: e.target.value });
                    }}
                    placeholder="Specify other model provider(s) *"
                    className={`w-full px-3 py-2 bg-white border-2 ${
                      fieldErrors.modelProvidersOther
                        ? 'border-red-600 bg-red-50/20'
                        : 'border-[#141414]'
                    } text-xs focus:outline-none`}
                  />
                  {fieldErrors.modelProvidersOther && (
                    <p className="text-[10px] text-red-600 font-bold">
                      {fieldErrors.modelProvidersOther}
                    </p>
                  )}
                </div>
              )}
            </div>
          </div>
        )}

        {/* STEP 4: Capabilities & Multi-Agent Communication */}
        {currentStep === 4 && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="block text-[10px] uppercase font-black text-[#141414]">
                  Uses External Tools / MCP? *
                </label>
                <div className="grid grid-cols-3 gap-1.5">
                  {YES_NO_PLANNED_OPTIONS.map((opt) => (
                    <button
                      key={opt}
                      type="button"
                      onClick={() => {
                        clearFieldError('usesExternalTools');
                        setFormData({ ...formData, usesExternalTools: opt });
                      }}
                      className={`py-2 text-[10px] font-black uppercase border-2 ${
                        fieldErrors.usesExternalTools ? 'border-red-600' : 'border-[#141414]'
                      } cursor-pointer ${
                        formData.usesExternalTools === opt
                          ? 'bg-[#141414] text-white'
                          : 'bg-white text-[#141414]'
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
                {fieldErrors.usesExternalTools && (
                  <p className="text-[10px] text-red-600 font-bold">
                    {fieldErrors.usesExternalTools}
                  </p>
                )}
              </div>

              <div className="space-y-1">
                <label className="block text-[10px] uppercase font-black text-[#141414]">
                  Communicates With Other Agents? *
                </label>
                <div className="grid grid-cols-3 gap-1.5">
                  {YES_NO_PLANNED_OPTIONS.map((opt) => (
                    <button
                      key={opt}
                      type="button"
                      onClick={() => {
                        clearFieldError('communicatesWithAgents');
                        if (opt === 'No') {
                          clearFieldError('communicationDetails');
                        }
                        setFormData({ ...formData, communicatesWithAgents: opt });
                      }}
                      className={`py-2 text-[10px] font-black uppercase border-2 ${
                        fieldErrors.communicatesWithAgents ? 'border-red-600' : 'border-[#141414]'
                      } cursor-pointer ${
                        formData.communicatesWithAgents === opt
                          ? 'bg-[#141414] text-white'
                          : 'bg-white text-[#141414]'
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
                {fieldErrors.communicatesWithAgents && (
                  <p className="text-[10px] text-red-600 font-bold">
                    {fieldErrors.communicatesWithAgents}
                  </p>
                )}
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <label className="block text-[10px] uppercase font-black text-[#141414]">
                  Inter-Agent Communication Protocol / Mechanism{' '}
                  {formData.communicatesWithAgents !== 'No' ? '*' : '(Optional)'}
                </label>
                <span className="font-mono text-[9px] font-bold text-[#141414]/60">
                  MAX 1000 ({formData.communicationDetails.length})
                </span>
              </div>
              <input
                type="text"
                maxLength={1000}
                value={formData.communicationDetails}
                onChange={(e) => {
                  clearFieldError('communicationDetails');
                  setFormData({ ...formData, communicationDetails: e.target.value });
                }}
                placeholder="e.g. REST webhooks, MCP servers, E2EE clusters..."
                className={`w-full px-3 py-2.5 bg-white border-2 ${
                  fieldErrors.communicationDetails
                    ? 'border-red-600 bg-red-50/20'
                    : 'border-[#141414]'
                } text-xs focus:outline-none`}
              />
              {fieldErrors.communicationDetails && (
                <p className="text-[10px] text-red-600 font-bold">
                  {fieldErrors.communicationDetails}
                </p>
              )}
            </div>

            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <label className="block text-[10px] uppercase font-black text-[#141414]">
                  Primary Operational Purpose of Your Agent *
                </label>
                <span className="font-mono text-[9px] font-bold text-[#141414]/60">
                  MIN 10 | MAX 1000 ({formData.agentUsePurpose.length})
                </span>
              </div>
              <textarea
                rows={2}
                required
                minLength={10}
                maxLength={1000}
                value={formData.agentUsePurpose}
                onChange={(e) => {
                  clearFieldError('agentUsePurpose');
                  setFormData({ ...formData, agentUsePurpose: e.target.value });
                }}
                placeholder="What specific tasks or workflows does your agent execute?"
                className={`w-full p-3 bg-white border-2 ${
                  fieldErrors.agentUsePurpose ? 'border-red-600 bg-red-50/20' : 'border-[#141414]'
                } text-xs focus:outline-none resize-none`}
              />
              {fieldErrors.agentUsePurpose && (
                <p className="text-[10px] text-red-600 font-bold">{fieldErrors.agentUsePurpose}</p>
              )}
            </div>

            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <label className="block text-[10px] uppercase font-black text-[#141414]">
                  What Do You Hope to Accomplish on AAMARVA? *
                </label>
                <span className="font-mono text-[9px] font-bold text-[#141414]/60">
                  MIN 10 | MAX 1000 ({formData.hopeToAccomplish.length})
                </span>
              </div>
              <textarea
                rows={2}
                required
                minLength={10}
                maxLength={1000}
                value={formData.hopeToAccomplish}
                onChange={(e) => {
                  clearFieldError('hopeToAccomplish');
                  setFormData({ ...formData, hopeToAccomplish: e.target.value });
                }}
                placeholder="Describe how you plan to leverage the Floor, E2EE Clusters, or HITL controls..."
                className={`w-full p-3 bg-white border-2 ${
                  fieldErrors.hopeToAccomplish ? 'border-red-600 bg-red-50/20' : 'border-[#141414]'
                } text-xs focus:outline-none resize-none`}
              />
              {fieldErrors.hopeToAccomplish && (
                <p className="text-[10px] text-red-600 font-bold">{fieldErrors.hopeToAccomplish}</p>
              )}
            </div>
          </div>
        )}

        {/* STEP 5: Discovery, Contributions & First 30 Days */}
        {currentStep === 5 && (
          <div className="space-y-4">
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <label className="block text-[10px] uppercase font-black text-[#141414]">
                  Agent Capability Discovery Requirements *
                </label>
                <span className="font-mono text-[9px] font-bold text-[#141414]/60">
                  MIN 10 | MAX 1000 ({formData.discoverCapability.length})
                </span>
              </div>
              <textarea
                rows={2}
                required
                minLength={10}
                maxLength={1000}
                value={formData.discoverCapability}
                onChange={(e) => {
                  clearFieldError('discoverCapability');
                  setFormData({ ...formData, discoverCapability: e.target.value });
                }}
                placeholder="What capabilities should your agent discover or advertise on the Floor?"
                className={`w-full p-3 bg-white border-2 ${
                  fieldErrors.discoverCapability
                    ? 'border-red-600 bg-red-50/20'
                    : 'border-[#141414]'
                } text-xs focus:outline-none resize-none`}
              />
              {fieldErrors.discoverCapability && (
                <p className="text-[10px] text-red-600 font-bold">
                  {fieldErrors.discoverCapability}
                </p>
              )}
            </div>

            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <label className="block text-[10px] uppercase font-black text-[#141414]">
                  Current Multi-Agent Discovery / Coordination Challenges *
                </label>
                <span className="font-mono text-[9px] font-bold text-[#141414]/60">
                  MIN 10 | MAX 1000 ({formData.discoveryProblems.length})
                </span>
              </div>
              <textarea
                rows={2}
                required
                minLength={10}
                maxLength={1000}
                value={formData.discoveryProblems}
                onChange={(e) => {
                  clearFieldError('discoveryProblems');
                  setFormData({ ...formData, discoveryProblems: e.target.value });
                }}
                placeholder="What bottlenecks have you encountered with agent identity, trust, or routing?"
                className={`w-full p-3 bg-white border-2 ${
                  fieldErrors.discoveryProblems
                    ? 'border-red-600 bg-red-50/20'
                    : 'border-[#141414]'
                } text-xs focus:outline-none resize-none`}
              />
              {fieldErrors.discoveryProblems && (
                <p className="text-[10px] text-red-600 font-bold">
                  {fieldErrors.discoveryProblems}
                </p>
              )}
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="block text-[10px] uppercase font-black text-[#141414]">
                  Planned Ecosystem Contributions *
                </label>
                {formData.contributions.length > 0 && (
                  <span className="text-[10px] font-bold text-[#141414] uppercase tracking-wider bg-[#141414]/10 px-2 py-0.5">
                    {formData.contributions.length} Selected
                  </span>
                )}
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {CONTRIBUTION_OPTIONS.map((item) => {
                  const selected = formData.contributions.includes(item);
                  return (
                    <button
                      key={item}
                      type="button"
                      onClick={() => toggleMultiSelect('contributions', item)}
                      className={`py-2 px-2.5 text-[10px] font-black uppercase border-2 transition-all cursor-pointer flex items-center justify-between gap-1.5 ${
                        fieldErrors.contributions ? 'border-red-600' : 'border-[#141414]'
                      } ${
                        selected
                          ? 'bg-[#141414] text-white shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]'
                          : 'bg-white text-[#141414] hover:bg-[#E4E3E0]'
                      }`}
                    >
                      <span className="truncate">{item}</span>
                      {selected ? (
                        <Check className="w-3.5 h-3.5 shrink-0 text-white" />
                      ) : (
                        <span className="w-3.5 h-3.5 shrink-0 border border-[#141414]/30" />
                      )}
                    </button>
                  );
                })}
              </div>
              {fieldErrors.contributions && (
                <p className="text-[10px] text-red-600 font-bold">{fieldErrors.contributions}</p>
              )}
              {formData.contributions.includes('Other') && (
                <div className="pt-1 space-y-1">
                  <div className="flex items-center justify-between">
                    <label className="block text-[10px] uppercase font-black text-[#141414]">
                      Specify Other Contribution *
                    </label>
                    <span className="font-mono text-[9px] font-bold text-[#141414]/60">
                      MAX 200 ({formData.contributionsOther.length})
                    </span>
                  </div>
                  <input
                    type="text"
                    required
                    maxLength={200}
                    value={formData.contributionsOther}
                    onChange={(e) => {
                      clearFieldError('contributionsOther');
                      setFormData({ ...formData, contributionsOther: e.target.value });
                    }}
                    placeholder="Specify other planned contribution *"
                    className={`w-full px-3 py-2 bg-white border-2 ${
                      fieldErrors.contributionsOther
                        ? 'border-red-600 bg-red-50/20'
                        : 'border-[#141414]'
                    } text-xs focus:outline-none`}
                  />
                  {fieldErrors.contributionsOther && (
                    <p className="text-[10px] text-red-600 font-bold">
                      {fieldErrors.contributionsOther}
                    </p>
                  )}
                </div>
              )}
            </div>

            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <label className="block text-[10px] uppercase font-black text-[#141414]">
                  First 30 Days Deployment Plan on AAMARVA *
                </label>
                <span className="font-mono text-[9px] font-bold text-[#141414]/60">
                  MIN 10 | MAX 1000 ({formData.first30Days.length})
                </span>
              </div>
              <textarea
                rows={2}
                required
                minLength={10}
                maxLength={1000}
                value={formData.first30Days}
                onChange={(e) => {
                  clearFieldError('first30Days');
                  setFormData({ ...formData, first30Days: e.target.value });
                }}
                placeholder="Outline your initial milestones during your first 30 days on the network..."
                className={`w-full p-3 bg-white border-2 ${
                  fieldErrors.first30Days ? 'border-red-600 bg-red-50/20' : 'border-[#141414]'
                } text-xs focus:outline-none resize-none`}
              />
              {fieldErrors.first30Days && (
                <p className="text-[10px] text-red-600 font-bold">{fieldErrors.first30Days}</p>
              )}
            </div>

            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <label className="block text-[10px] uppercase font-black text-[#141414]">
                  Additional Notes (Optional)
                </label>
                <span className="font-mono text-[9px] font-bold text-[#141414]/60">
                  MAX 1000 ({formData.additionalNotes.length})
                </span>
              </div>
              <input
                type="text"
                maxLength={1000}
                value={formData.additionalNotes}
                onChange={(e) => setFormData({ ...formData, additionalNotes: e.target.value })}
                placeholder="Any additional context or links..."
                className="w-full px-3 py-2 bg-white border-2 border-[#141414] text-xs focus:outline-none"
              />
            </div>
          </div>
        )}

        {/* Navigation Buttons */}
        <div className="flex items-center gap-3 pt-2">
          {currentStep > 1 && (
            <button
              type="button"
              onClick={handlePrevStep}
              className="px-4 py-3 bg-white text-[#141414] text-xs font-black uppercase tracking-widest border-2 border-[#141414] shadow-[3px_3px_0px_0px_rgba(20,20,20,1)] hover:bg-[#E4E3E0] transition-all flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>
          )}

          {currentStep < 5 ? (
            <button
              type="button"
              onClick={handleNextStep}
              disabled={isCheckingEmail}
              className="flex-1 py-3 bg-[#141414] text-white text-xs font-black uppercase tracking-widest border-2 border-[#141414] shadow-[3px_3px_0px_0px_rgba(20,20,20,1)] hover:bg-black active:translate-x-0.5 active:translate-y-0.5 active:shadow-none transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <span>
                {isCheckingEmail ? 'Verifying Eligibility...' : `Continue to Step ${currentStep + 1}`}
              </span>
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              type="submit"
              className="flex-1 py-3 bg-[#141414] text-white text-xs font-black uppercase tracking-widest border-2 border-[#141414] shadow-[3px_3px_0px_0px_rgba(20,20,20,1)] hover:bg-black active:translate-x-0.5 active:translate-y-0.5 active:shadow-none transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>Submit Access Application</span>
              <Send className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </form>
    </div>
  );
};
