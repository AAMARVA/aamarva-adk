import React, { useState, useEffect, useCallback, useRef } from 'react';
import { apiFetch, getCurrentSessionAuthType } from '../services/authApi';
import { AgentAvatar } from './AgentAvatar';
import { BrutalistLoader } from './BrutalistLoader';
import { getClusterSymbol } from '../lib/clusterSymbols';
import { Plus, X, Search, Pencil, MessageSquare } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { getAccountKey, getQueryCache, setQueryCache, getUiState, setUiState, buildCommandPitFleetList, seedFleetAccountsCache, getUnreadCounts, clearUnreadCount, getConnUnreadCount, getLastActivityTimestamp, registerConnectionAlias, registerClusterAlias, getClusterUnreadCount, reconcileUnreadEntities } from '../lib/appStateCache';
import { warmupUnreadChats, warmupConnectionChat, warmupClusterChat } from '../lib/chatMessageWarmup';
import { isRealtimeStreamConnected } from '../lib/realtimeStream';

interface CommandPitViewProps {
  isActive?: boolean;
  onOpenAgentProfile?: (agentName: string, avatar?: string, agentId?: string) => void;
  onOpenChat?: (chat: any) => void;
  onOpenClusterChat?: (cluster: { id: string; name: string; symbol?: string }) => void;
  onOpenClusterMembers?: (cluster: any) => void;
}

export const CommandPitView: React.FC<CommandPitViewProps> = ({
  isActive = true,
  onOpenAgentProfile,
  onOpenChat,
  onOpenClusterChat,
  onOpenClusterMembers,
}) => {
  const { user, activeAccount, userPassword, sessionAuthType } = useAuth();
  const accountKey = getAccountKey(user?.id, activeAccount?.id);
  const effectiveAuthType: 'human' | 'agent' = sessionAuthType || getCurrentSessionAuthType() || 'human';

  const recentWarmupTriggerRef = useRef<Map<string, number>>(new Map());

  const triggerConnWarmup = useCallback((conn: any) => {
    const curPersona = activeAccount || user;
    const connId = conn?.id || conn?.connectionId;
    if (!connId || !curPersona?.agentId) return;
    const now = Date.now();
    const key = `conn:${accountKey}:${connId}`;
    const lastTs = recentWarmupTriggerRef.current.get(key) || 0;
    if (now - lastTs < 1200) return;
    recentWarmupTriggerRef.current.set(key, now);
    warmupConnectionChat({
      connectionId: connId,
      allConnectionIds: conn.allConnectionIds,
      peerAgentId: conn.agentId,
      peerPublicKey: conn.peerE2eePublicKey,
      accountKey,
      userAgentId: curPersona.agentId,
      userPassword,
      authType: effectiveAuthType,
    }).catch(() => {});
  }, [activeAccount, user, accountKey, userPassword, effectiveAuthType]);

  const triggerClusterWarmup = useCallback((cluster: any) => {
    const curPersona = activeAccount || user;
    if (!cluster?.id || !curPersona?.agentId) return;
    const now = Date.now();
    const key = `cluster:${accountKey}:${cluster.id}`;
    const lastTs = recentWarmupTriggerRef.current.get(key) || 0;
    if (now - lastTs < 1200) return;
    recentWarmupTriggerRef.current.set(key, now);
    warmupClusterChat({
      clusterId: cluster.id,
      clusterName: cluster.name,
      activeCluster: cluster,
      accountKey,
      accountId: curPersona.id || curPersona.agentId || 'anon',
      userAgentId: curPersona.agentId,
      userPassword,
      authType: effectiveAuthType,
    }).catch(() => {});
  }, [activeAccount, user, accountKey, userPassword, effectiveAuthType]);

  const [activeConnections, setActiveConnections] = useState<any[]>(() => {
    return getQueryCache(accountKey, '/api/command-pit/fleet')?.data || [];
  });
  const [clusters, setClusters] = useState<any[]>(() => {
    return getQueryCache(accountKey, '/api/clusters')?.data || [];
  });
  const [isLoadingConnections, setIsLoadingConnections] = useState<boolean>(() => {
    return !getQueryCache(accountKey, '/api/command-pit/fleet');
  });
  const [isLoadingClusters, setIsLoadingClusters] = useState<boolean>(() => {
    return !getQueryCache(accountKey, '/api/clusters');
  });
  const [mobileTab, setMobileTab] = useState<'connections' | 'clusters'>(() => {
    return getUiState(accountKey, 'cmd_pit_mobile_tab', 'connections');
  });
  const [isNewClusterOpen, setIsNewClusterOpen] = useState(false);
  const [newClusterName, setNewClusterName] = useState('');
  const [newClusterDescription, setNewClusterDescription] = useState('');
  
  // Edit cluster state
  const [editingCluster, setEditingCluster] = useState<any | null>(null);
  const [editClusterName, setEditClusterName] = useState('');
  const [editClusterDescription, setEditClusterDescription] = useState('');
  const [editSelectedAgentIds, setEditSelectedAgentIds] = useState<string[]>([]);
  const [isSavingEdit, setIsSavingEdit] = useState(false);
  const [editClusterError, setEditClusterError] = useState<string | null>(null);

  const [spogMode, setSpogMode] = useState<'connections' | 'cluster' | 'edit-cluster'>(() => {
    return getUiState(accountKey, 'cmd_pit_spog_mode', 'connections');
  });
  const [selectedSpogAgentIds, setSelectedSpogAgentIds] = useState<string[]>([]);
  const [isSpogModalOpen, setIsSpogModalOpen] = useState(false);
  const [spogSearchQuery, setSpogSearchQuery] = useState(() => {
    return getUiState(accountKey, 'cmd_pit_search', '');
  });
  
  const [unreadCounts, setUnreadCounts] = useState<Record<string, number>>(() => {
    return getUnreadCounts(accountKey);
  });
  const processedEventIds = useRef<Set<string>>(new Set());

  const markAsRead = useCallback((id?: string | null, connObj?: any) => {
    const idsToClear = [
      id,
      connObj?.id,
      connObj?.connectionId,
      connObj?.agentId,
      connObj?.agentName
    ].filter((x): x is string => Boolean(x && typeof x === 'string' && x.trim()));

    clearUnreadCount(accountKey, idsToClear);

    // Immediately zero out unreadCount on activeConnections local state
    setActiveConnections((prev) =>
      prev.map((c) => {
        const isMatch = idsToClear.some((clearId) => {
          const clean = clearId.trim().replace(/^@+/, '').toUpperCase();
          const matchCid = String(c.id || '').trim().replace(/^@+/, '').toUpperCase();
          const matchConnId = String(c.connectionId || '').trim().replace(/^@+/, '').toUpperCase();
          const matchAid = String(c.agentId || '').trim().replace(/^@+/, '').toUpperCase();
          const matchAname = String(c.agentName || '').trim().replace(/^@+/, '').toUpperCase();
          return clean && (clean === matchCid || clean === matchConnId || clean === matchAid || clean === matchAname);
        });
        return isMatch ? { ...c, unreadCount: 0 } : c;
      })
    );

    const targetCid = id || connObj?.connectionId || connObj?.id;
    if (targetCid) {
      apiFetch(`/api/connections/${targetCid}/read`, {
        method: 'POST',
        authType: 'human',
        body: JSON.stringify({ connectionId: targetCid, agentId: connObj?.agentId, ids: idsToClear })
      }).catch(() => {});
    }
  }, [accountKey]);

  useEffect(() => {
    const syncCounts = () => {
      const counts = getUnreadCounts(accountKey);
      setUnreadCounts({ ...counts });
      setActiveConnections((prev) =>
        prev.map((c) => {
          const count = getConnUnreadCount(counts, c, accountKey);
          return c.unreadCount !== count ? { ...c, unreadCount: count } : c;
        })
      );
      setClusters((prev) =>
        prev.map((cluster) => {
          const count = getClusterUnreadCount(counts, cluster, accountKey);
          return cluster.unreadCount !== count ? { ...cluster, unreadCount: count } : cluster;
        })
      );
    };
    syncCounts();

    window.addEventListener('unread-counts-updated', syncCounts);
    return () => {
      window.removeEventListener('unread-counts-updated', syncCounts);
    };
  }, [accountKey]);

  const [creatingCluster, setCreatingCluster] = useState(false);
  const [createClusterError, setCreateClusterError] = useState<string | null>(null);

  const fetchClusters = useCallback(async (retries = 3) => {
    const targetKey = accountKey;
    const cached = getQueryCache(targetKey, '/api/clusters')?.data;
    if (Array.isArray(cached)) {
      cached.forEach((c) => registerClusterAlias(targetKey, c));
      setClusters(cached);
      setIsLoadingClusters(false);
    } else {
      setIsLoadingClusters(true);
    }
    try {
      const res = await apiFetch('/api/clusters', { authType: effectiveAuthType });
      if (res?.success && Array.isArray(res.data)) {
        res.data.forEach((cluster: any) => registerClusterAlias(targetKey, cluster));
        setQueryCache(targetKey, '/api/clusters', res.data);
        setClusters(res.data);
        reconcileUnreadEntities(targetKey, {
          clusters: res.data,
          selfIds: [activeAccount?.id, activeAccount?.agentId, user?.id, user?.agentId],
        });
        const curPersona = activeAccount || user;
        if (curPersona?.agentId) {
          warmupUnreadChats({
            clusters: res.data,
            accountKey: targetKey,
            accountId: curPersona.id || curPersona.agentId || 'anon',
            userAgentId: curPersona.agentId,
            userPassword,
            authType: effectiveAuthType,
          }).catch(() => {});
        }
      } else if (retries > 0 && res?.error) {
        console.warn(`[CommandPitView] Retrying cluster fetch, attempts left: ${retries}`);
        setTimeout(() => fetchClusters(retries - 1), 2000);
      }
    } catch (e) {
      if (retries > 0) {
        setTimeout(() => fetchClusters(retries - 1), 2000);
      }
    } finally {
      setIsLoadingClusters(false);
    }
  }, [accountKey]);

  const fetchConnectionsAndFleet = useCallback(async (retries = 3) => {
    const targetKey = accountKey;
    const cachedFleet = getQueryCache(targetKey, '/api/command-pit/fleet')?.data;
    if (Array.isArray(cachedFleet)) {
      setActiveConnections(cachedFleet);
      setIsLoadingConnections(false);
    } else {
      setIsLoadingConnections(true);
    }
    try {
      const [connRes, masterRes] = await Promise.allSettled([
        apiFetch('/api/connections?limit=100', { authType: effectiveAuthType }),
        apiFetch('/api/auth/master/accounts', { authType: effectiveAuthType }),
      ]);

      const serverConnList =
        connRes.status === 'fulfilled' && connRes.value?.success
          ? (Array.isArray(connRes.value?.data?.connections)
              ? connRes.value.data.connections
              : Array.isArray(connRes.value?.data)
                ? connRes.value.data
                : null)
          : null;

      const connList = serverConnList ?? (getQueryCache(targetKey, '/api/connections')?.data || []);

      if (serverConnList !== null) {
        setQueryCache(targetKey, '/api/connections', serverConnList);
      }

      const masterData =
        masterRes.status === 'fulfilled' && masterRes.value?.success && masterRes.value?.data
          ? masterRes.value.data
          : getQueryCache('master_accounts', '/api/auth/master/accounts')?.data;

      if (masterRes.status === 'fulfilled' && masterRes.value?.success && masterRes.value?.data) {
        seedFleetAccountsCache(masterRes.value.data);
      }

      const activeId = activeAccount?.id || user?.id;
      const mergedList = buildCommandPitFleetList(connList, masterData, activeId, targetKey);
      setQueryCache(targetKey, '/api/command-pit/fleet', mergedList);
      setActiveConnections(mergedList);
      if (serverConnList !== null) {
        reconcileUnreadEntities(targetKey, {
          connections: mergedList,
          selfIds: [activeAccount?.id, activeAccount?.agentId, user?.id, user?.agentId],
        });
        const curPersona = activeAccount || user;
        if (curPersona?.agentId) {
          warmupUnreadChats({
            connections: mergedList,
            accountKey: targetKey,
            accountId: curPersona.id || curPersona.agentId || 'anon',
            userAgentId: curPersona.agentId,
            userPassword,
            authType: effectiveAuthType,
          }).catch(() => {});
        }
      }
    } catch (err) {
      console.warn('Failed to fetch connections and fleet:', err);
      if (retries > 0) {
        setTimeout(() => fetchConnectionsAndFleet(retries - 1), 2000);
      }
    } finally {
      setIsLoadingConnections(false);
    }
  }, [accountKey, activeAccount?.id, user?.id]);

  const isActiveRef = useRef(isActive);
  isActiveRef.current = isActive;
  const lastCommandPitSyncAtRef = useRef(0);

  useEffect(() => {
    const refreshBoth = (retries?: number) => {
      lastCommandPitSyncAtRef.current = Date.now();
      fetchConnectionsAndFleet(retries);
      fetchClusters(retries);
    };

    refreshBoth();

    const handleAccountUpdate = () => {
      refreshBoth();
    };

    const handleVisibilityOrFocus = () => {
      if (!isActiveRef.current) return;
      if (typeof document === 'undefined' || document.visibilityState === 'visible') {
        if (Date.now() - lastCommandPitSyncAtRef.current >= 10000) {
          refreshBoth(0);
        }
      }
    };

    const pollInterval = setInterval(() => {
      if (!isActiveRef.current) return;
      if (typeof document === 'undefined' || document.visibilityState === 'visible') {
        const elapsed = Date.now() - lastCommandPitSyncAtRef.current;
        if (isRealtimeStreamConnected() && elapsed < 45000) {
          return;
        }
        refreshBoth(0);
      }
    }, 15000);

    const handleCommandPitActivated = () => {
      refreshBoth(0);
    };

    window.addEventListener('account-changed', handleAccountUpdate);
    window.addEventListener('aamarva-plan-updated', handleAccountUpdate);
    window.addEventListener('cluster-updated', handleAccountUpdate);
    window.addEventListener('command-pit-activated', handleCommandPitActivated);
    window.addEventListener('focus', handleVisibilityOrFocus);
    document.addEventListener('visibilitychange', handleVisibilityOrFocus);

    return () => {
      clearInterval(pollInterval);
      window.removeEventListener('account-changed', handleAccountUpdate);
      window.removeEventListener('aamarva-plan-updated', handleAccountUpdate);
      window.removeEventListener('cluster-updated', handleAccountUpdate);
      window.removeEventListener('command-pit-activated', handleCommandPitActivated);
      window.removeEventListener('focus', handleVisibilityOrFocus);
      document.removeEventListener('visibilitychange', handleVisibilityOrFocus);
    };
  }, [fetchConnectionsAndFleet, fetchClusters]);

  useEffect(() => {
    if (isActive && Date.now() - lastCommandPitSyncAtRef.current > 5000) {
      lastCommandPitSyncAtRef.current = Date.now();
      fetchConnectionsAndFleet(0);
      fetchClusters(0);
    }
  }, [isActive, fetchConnectionsAndFleet, fetchClusters]);

  const handleCreateCluster = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newClusterName.trim()) {
      setCreateClusterError('Cluster name is required.');
      return;
    }
    setCreatingCluster(true);
    setCreateClusterError(null);
    try {
      const res = await apiFetch('/api/clusters', {
        method: 'POST',
        authType: 'human',
        body: JSON.stringify({
          name: newClusterName.trim(),
          description: newClusterDescription.trim() || undefined,
          memberAgentIds: selectedSpogAgentIds,
        }),
      });
      if (res?.success) {
        setIsNewClusterOpen(false);
        setNewClusterName('');
        setNewClusterDescription('');
        setSelectedSpogAgentIds([]);
        fetchClusters();
      } else {
        setCreateClusterError(res?.error?.message || 'Failed to create cluster.');
      }
    } catch (err: any) {
      setCreateClusterError(err?.message || 'Failed to create cluster.');
    } finally {
      setCreatingCluster(false);
    }
  };

  const curActiveId = (activeAccount?.id || user?.id || '').toString().toLowerCase();
  const curActiveAgentId = (activeAccount?.agentId || user?.agentId || '').toString().toLowerCase();
  const filteredConnections = activeConnections.filter((conn: any) => {
    if (!conn) return false;
    const cId = (conn.id || '').toString().toLowerCase();
    const cAgentId = (conn.agentId || '').toString().toLowerCase();
    if (curActiveId && (cId === curActiveId || cAgentId === curActiveId)) return false;
    if (curActiveAgentId && (cId === curActiveAgentId || cAgentId === curActiveAgentId)) return false;
    return true;
  });

  return (
    <div className="h-[calc(100dvh-175px)] sm:h-[calc(100dvh-150px)] md:h-[calc(100dvh-135px)] max-h-[calc(100dvh-135px)] flex flex-col p-2 sm:p-4 md:p-6 overflow-hidden">
      <div className="shrink-0 mb-3 flex items-center justify-between">
        <h2 className="font-mono text-lg sm:text-xl font-black uppercase text-[#141414] inline-block border-b-2 border-[#141414] pb-1">
          Command Pit
        </h2>
      </div>

      {(() => {
        const totalConnUnread = filteredConnections.reduce(
          (acc, conn) => acc + getConnUnreadCount(unreadCounts, conn, accountKey),
          0
        );
        const totalClusterUnread = clusters.reduce(
          (acc, clu) => acc + getClusterUnreadCount(unreadCounts, clu, accountKey),
          0
        );
        return (
          <div className="flex md:hidden items-center border-2 border-[#141414] mb-3 shrink-0 p-0.5 bg-[#E4E3E0]/40 shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]">
            <button
              type="button"
              onClick={() => setMobileTab('connections')}
              className={`flex-1 py-1.5 px-2 font-mono text-xs font-bold uppercase transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                mobileTab === 'connections'
                  ? 'bg-[#141414] text-white shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]'
                  : 'text-[#141414] hover:bg-[#141414]/10'
              }`}
            >
              <span>Connections</span>
              {totalConnUnread > 0 && (
                <span className={`min-w-4 h-4 px-1 rounded-full text-[9px] font-black flex items-center justify-center ${
                  mobileTab === 'connections' ? 'bg-white text-[#141414]' : 'bg-[#141414] text-white'
                }`}>
                  {totalConnUnread > 99 ? '99+' : totalConnUnread}
                </span>
              )}
            </button>
            <button
              type="button"
              onClick={() => setMobileTab('clusters')}
              className={`flex-1 py-1.5 px-2 font-mono text-xs font-bold uppercase transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                mobileTab === 'clusters'
                  ? 'bg-[#141414] text-white shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]'
                  : 'text-[#141414] hover:bg-[#141414]/10'
              }`}
            >
              <span>Clusters</span>
              {totalClusterUnread > 0 && (
                <span className={`min-w-4 h-4 px-1 rounded-full text-[9px] font-black flex items-center justify-center ${
                  mobileTab === 'clusters' ? 'bg-white text-[#141414]' : 'bg-[#141414] text-white'
                }`}>
                  {totalClusterUnread > 99 ? '99+' : totalClusterUnread}
                </span>
              )}
            </button>
          </div>
        );
      })()}

      <div className="flex-1 min-h-0 relative grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6 h-full">
        <div className={`flex-col h-full min-h-0 pr-0 md:pr-6 ${mobileTab !== 'connections' ? 'hidden md:flex' : 'flex'}`}>
          <div className="flex items-center justify-between shrink-0 mb-2.5">
            <h3 className="font-mono text-sm font-black uppercase text-[#141414]">
              Connections ({filteredConnections.length})
            </h3>
            <button
              type="button"
              onClick={() => {
                setSpogMode('connections');
                setIsSpogModalOpen(true);
              }}
              className="flex items-center gap-1 bg-[#141414] text-white px-2.5 py-1 text-xs font-mono font-bold border-2 border-[#141414] shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] hover:translate-x-[1px] hover:translate-y-[1px] hover:shadow-[1px_1px_0px_0px_rgba(20,20,20,1)] active:translate-x-[2px] active:translate-y-[2px] active:shadow-none transition-all cursor-pointer"
            >
              <span>SPOG</span>
            </button>
          </div>
          <div className="flex-1 min-h-0 overflow-y-auto overscroll-contain custom-scrollbar pr-2 space-y-3">
            {(() => {
              const curActiveId = (activeAccount?.id || user?.id || '').toString().toLowerCase();
              const curActiveAgentId = (activeAccount?.agentId || user?.agentId || '').toString().toLowerCase();
              const filteredConnections = activeConnections.filter((conn: any) => {
                if (!conn) return false;
                const cId = (conn.id || '').toString().toLowerCase();
                const cAgentId = (conn.agentId || '').toString().toLowerCase();
                if (curActiveId && (cId === curActiveId || cAgentId === curActiveId)) return false;
                if (curActiveAgentId && (cId === curActiveAgentId || cAgentId === curActiveAgentId)) return false;
                return true;
              });

              if (isLoadingConnections && filteredConnections.length === 0) {
                return (
                  <div className="py-12 flex flex-col items-center justify-center">
                    <BrutalistLoader text="Synchronizing Connections" size="sm" />
                  </div>
                );
              }

              if (filteredConnections.length === 0) {
                return (
                  <div className="p-6 border-2 border-dashed border-[#141414]/30 text-center text-[#141414]/50 font-mono text-xs">
                    NO CONNECTIONS
                  </div>
                );
              }

              filteredConnections.forEach((conn) => registerConnectionAlias(accountKey, conn));

              const sortedConnections = [...filteredConnections].sort((a, b) => {
                const unreadA = getConnUnreadCount(unreadCounts, a, accountKey);
                const unreadB = getConnUnreadCount(unreadCounts, b, accountKey);

                if (unreadA > 0 && unreadB === 0) return -1;
                if (unreadA === 0 && unreadB > 0) return 1;

                if (unreadA > 0 && unreadB > 0 && unreadA !== unreadB) {
                  return unreadB - unreadA;
                }

                const timeA = getLastActivityTimestamp(accountKey, a);
                const timeB = getLastActivityTimestamp(accountKey, b);
                if (timeA !== timeB) {
                  return timeB - timeA;
                }

                if (a.isMaster && !b.isMaster) return -1;
                if (!a.isMaster && b.isMaster) return 1;

                return (a.agentName || '').localeCompare(b.agentName || '');
              });

              return sortedConnections.map((conn) => {
                const connId = conn.id || conn.connectionId;
                const connUnread = getConnUnreadCount(unreadCounts, conn, accountKey);

                return (
                <div
                  key={conn.id || conn.agentId}
                  className="p-3 bg-white border-2 border-[#141414] shadow-[3px_3px_0px_0px_rgba(20,20,20,1)] hover:translate-x-[1px] hover:translate-y-[1px] transition-all"
                >
                  <div className="flex items-center justify-between gap-3">
                    <div
                      onClick={() => onOpenAgentProfile?.(conn.agentName, conn.avatar, conn.agentId)}
                      className="flex items-center gap-3 cursor-pointer min-w-0 flex-1 hover:opacity-85 transition-opacity"
                    >
                      <AgentAvatar
                        name={conn.agentName}
                        avatar={conn.avatar}
                        id={conn.agentId}
                        isMaster={Boolean(conn.isMaster && !conn.isSlave)}
                        isSlave={Boolean(conn.isSlave)}
                        className="w-9 h-9 border border-[#141414] shrink-0"
                      />
                      <div className="flex flex-col min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="font-black text-xs uppercase truncate text-[#141414]">
                            {conn.agentName || conn.agentId || 'Agent'}
                          </span>
                          {conn.isMaster && !conn.isSlave ? (
                            <span className="px-1.5 py-0.5 bg-[#141414] text-white text-[8px] font-black uppercase border border-[#141414] tracking-wider shadow-[1px_1px_0px_0px_rgba(20,20,20,0.5)] shrink-0">
                              MASTER
                            </span>
                          ) : (
                            <span className="px-1.5 py-0.5 bg-[#E4E3E0] text-[#141414] text-[8px] font-black uppercase border border-[#141414]/40 tracking-wider shrink-0">
                              SLAVE
                            </span>
                          )}
                        </div>
                        {conn.agentId && (
                          <span className="font-mono text-[10px] text-[#141414]/60 truncate mt-0.5">
                            @{conn.agentId.replace(/^@/, '')}
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      {Boolean(connUnread > 0) && (
                        <span
                          className="min-w-5 h-5 px-1 rounded-full bg-[#141414] text-white text-[10px] font-mono font-black border border-[#141414] flex items-center justify-center shrink-0 shadow-[1px_1px_0px_0px_rgba(20,20,20,0.3)]"
                          title={`${connUnread} unread messages`}
                        >
                          {connUnread > 99 ? '99+' : connUnread}
                        </span>
                      )}
                      <button
                        type="button"
                        onPointerEnter={() => triggerConnWarmup(conn)}
                        onPointerDown={() => triggerConnWarmup(conn)}
                        onFocus={() => triggerConnWarmup(conn)}
                        onClick={() => {
                          markAsRead(connId, conn);
                          onOpenChat?.({
                            id: connId,
                            allConnectionIds: conn.allConnectionIds,
                            agentName: conn.agentName,
                            avatar: conn.avatar,
                            agentId: conn.agentId,
                            peerE2eePublicKey: conn.peerE2eePublicKey,
                            isMaster: conn.isMaster,
                            isSlave: conn.isSlave,
                          });
                        }}
                        className="bg-[#141414] text-white py-1 px-3 text-[10px] font-mono font-bold hover:bg-black/80 transition-colors shrink-0 cursor-pointer shadow-[1px_1px_0px_0px_rgba(20,20,20,1)] active:translate-x-[1px] active:translate-y-[1px]"
                        title={`Command ${conn.agentName}`}
                      >
                        COMMAND
                      </button>
                    </div>
                  </div>
                </div>
              );
              })
            })()}
          </div>
        </div>

        <div className="hidden md:block absolute left-1/2 inset-y-0 w-[2px] bg-[#141414]/30 -ml-[1px] pointer-events-none" />

        <div className={`flex-col h-full min-h-0 pl-0 md:pl-6 ${mobileTab !== 'clusters' ? 'hidden md:flex' : 'flex'}`}>
          <div className="flex items-center justify-between shrink-0 mb-2.5">
            <h3 className="font-mono text-sm font-black uppercase text-[#141414]">Clusters ({clusters.length})</h3>
            <button
              type="button"
              onClick={() => setIsNewClusterOpen(true)}
              className="flex items-center gap-1 bg-[#141414] text-white px-2.5 py-1 text-xs font-mono font-bold border-2 border-[#141414] shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] hover:translate-x-[1px] hover:translate-y-[1px] hover:shadow-[1px_1px_0px_0px_rgba(20,20,20,1)] active:translate-x-[2px] active:translate-y-[2px] active:shadow-none transition-all cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>NEW CLUSTER</span>
            </button>
          </div>
          <div className="flex-1 min-h-0 overflow-y-auto overscroll-contain custom-scrollbar pr-2 space-y-3">
             {isLoadingClusters && clusters.length === 0 ? (
              <div className="py-12 flex flex-col items-center justify-center">
                <BrutalistLoader text="Synchronizing Clusters" size="sm" />
              </div>
            ) : clusters.length > 0 ? (
              (() => {
                clusters.forEach((c) => registerClusterAlias(accountKey, c));
                const sortedClusters = [...clusters].sort((a, b) => {
                  const unreadA = getClusterUnreadCount(unreadCounts, a, accountKey);
                  const unreadB = getClusterUnreadCount(unreadCounts, b, accountKey);

                  if (unreadA > 0 && unreadB === 0) return -1;
                  if (unreadA === 0 && unreadB > 0) return 1;

                  if (unreadA > 0 && unreadB > 0 && unreadA !== unreadB) {
                    return unreadB - unreadA;
                  }

                  const timeA = getLastActivityTimestamp(accountKey, a);
                  const timeB = getLastActivityTimestamp(accountKey, b);
                  if (timeA !== timeB) {
                    return timeB - timeA;
                  }

                  return (a.name || '').localeCompare(b.name || '');
                });

                return sortedClusters.map((cluster) => {
                  const symbol = cluster.symbol || getClusterSymbol(cluster.id);
                  const clusterUnread = getClusterUnreadCount(unreadCounts, cluster, accountKey);

                  return (
                    <div
                      key={cluster.id}
                      className="p-3 bg-white border-2 border-[#141414] shadow-[3px_3px_0px_0px_rgba(20,20,20,1)] hover:translate-x-[1px] hover:translate-y-[1px] transition-all"
                    >
                      <div className="flex items-center justify-between gap-3">
                        <div
                          onClick={() => {
                            if (onOpenClusterMembers) {
                              onOpenClusterMembers(cluster);
                            } else if (onOpenClusterChat) {
                              onOpenClusterChat({ id: cluster.id, name: cluster.name, symbol });
                            }
                          }}
                          className="flex items-center gap-3 cursor-pointer min-w-0 flex-1 hover:opacity-85 transition-opacity"
                          title="Click to view Cluster Members"
                        >
                          <div className="w-9 h-9 bg-[#141414] text-white border border-[#141414] font-mono text-xs flex items-center justify-center font-black shrink-0 select-none shadow-[1px_1px_0px_0px_rgba(20,20,20,1)]">
                            {symbol}
                          </div>
                          <div className="flex flex-col min-w-0">
                            <span className="font-black text-xs uppercase truncate text-[#141414]">
                              {cluster.name}
                            </span>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          {Boolean(clusterUnread > 0) && (
                            <span
                              className="min-w-5 h-5 px-1 rounded-full bg-[#141414] text-white text-[10px] font-mono font-black border border-[#141414] flex items-center justify-center shrink-0 shadow-[1px_1px_0px_0px_rgba(20,20,20,0.3)]"
                              title={`${clusterUnread} unread messages`}
                            >
                              {clusterUnread > 99 ? '99+' : clusterUnread}
                            </span>
                          )}
                          <button
                            type="button"
                            onClick={() => {
                              if (onOpenClusterMembers) {
                                onOpenClusterMembers({ ...cluster, initialEdit: true });
                              }
                            }}
                            className="bg-white text-[#141414] border-2 border-[#141414] py-1 px-2.5 text-[10px] font-mono font-bold hover:bg-[#141414] hover:text-white transition-colors shrink-0 cursor-pointer shadow-[1px_1px_0px_0px_rgba(20,20,20,1)] active:translate-x-[1px] active:translate-y-[1px]"
                            title={`Edit Cluster ${cluster.name}`}
                          >
                            EDIT
                          </button>
                          <button
                            type="button"
                            onPointerEnter={() => triggerClusterWarmup(cluster)}
                            onPointerDown={() => triggerClusterWarmup(cluster)}
                            onFocus={() => triggerClusterWarmup(cluster)}
                            onClick={() => {
                              const idsToClear = [cluster.id, cluster.clusterId, cluster.name].filter(Boolean);
                              clearUnreadCount(accountKey, idsToClear);
                              setClusters((prev) => prev.map((cl) => (cl.id === cluster.id ? { ...cl, unreadCount: 0 } : cl)));
                              if (cluster.id) {
                                apiFetch(`/api/clusters/${cluster.id}/read`, {
                                  method: 'POST',
                                  authType: effectiveAuthType,
                                  body: JSON.stringify({ clusterId: cluster.id, ids: idsToClear })
                                }).catch(() => {});
                              }
                              onOpenClusterChat?.({ id: cluster.id, name: cluster.name, symbol });
                            }}
                            className="bg-[#141414] text-white py-1 px-3 text-[10px] font-mono font-bold hover:bg-black/80 transition-colors shrink-0 cursor-pointer shadow-[1px_1px_0px_0px_rgba(20,20,20,1)] active:translate-x-[1px] active:translate-y-[1px]"
                            title={`Command Cluster ${cluster.name}`}
                          >
                            COMMAND
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                });
              })()
            ) : (
              <div className="p-6 border-2 border-dashed border-[#141414]/30 text-center text-[#141414]/50 font-mono text-xs">NO CLUSTERS</div>
            )}
          </div>
        </div>
      </div>

      {isNewClusterOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white border-4 border-[#141414] shadow-[6px_6px_0px_0px_rgba(20,20,20,1)] w-full max-w-md p-6 space-y-4">
             <div className="flex items-center justify-between border-b-2 border-[#141414] pb-3">
              <h3 className="font-mono text-base font-black uppercase">Create New Cluster</h3>
              <button
                onClick={() => setIsNewClusterOpen(false)}
                className="p-1 hover:bg-[#141414]/10 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5 text-[#141414]" />
              </button>
            </div>
            {createClusterError && (
              <div className="p-3 bg-red-100 border-2 border-red-500 text-red-700 font-mono text-xs">
                {createClusterError}
              </div>
            )}
            <form onSubmit={handleCreateCluster} className="space-y-4">
              <div className="space-y-1">
                <label className="block font-mono text-xs font-bold uppercase text-[#141414]">Cluster Name</label>
                <input
                  type="text"
                  value={newClusterName}
                  onChange={(e) => setNewClusterName(e.target.value)}
                  placeholder="e.g. ALPHA ENCLAVE"
                  className="w-full border-2 border-[#141414] p-2 font-mono text-xs bg-white text-[#141414] focus:outline-none"
                  maxLength={50}
                  required
                />
              </div>
              <div className="space-y-1">
                <label className="block font-mono text-xs font-bold uppercase text-[#141414]">Description (Optional)</label>
                <textarea
                  value={newClusterDescription}
                  onChange={(e) => setNewClusterDescription(e.target.value)}
                  placeholder="Cluster enclave purpose and directives..."
                  rows={2}
                  className="w-full border-2 border-[#141414] p-2 font-mono text-xs bg-white text-[#141414] focus:outline-none resize-none"
                  maxLength={200}
                />
              </div>
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <label className="block font-mono text-xs font-bold uppercase text-[#141414]">
                    Select Agents to Add
                  </label>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => {
                        setSpogMode('cluster');
                        setIsSpogModalOpen(true);
                      }}
                      className="px-2 py-0.5 bg-white text-[#141414] border-2 border-[#141414] text-[10px] font-mono font-bold uppercase hover:bg-[#141414] hover:text-white transition-colors cursor-pointer shadow-[1px_1px_0px_0px_rgba(20,20,20,1)]"
                    >
                      SPOG
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (selectedSpogAgentIds.length === activeConnections.length && activeConnections.length > 0) {
                          setSelectedSpogAgentIds([]);
                        } else {
                          setSelectedSpogAgentIds(activeConnections.map(c => c.agentId || c.id));
                        }
                      }}
                      className="px-2 py-0.5 bg-white border-2 border-[#141414] font-mono text-[10px] font-bold uppercase text-[#141414] hover:bg-[#141414] hover:text-white transition-colors cursor-pointer shadow-[1px_1px_0px_0px_rgba(20,20,20,1)]"
                    >
                      {selectedSpogAgentIds.length === activeConnections.length && activeConnections.length > 0 ? 'Deselect All' : 'Select All'}
                    </button>
                  </div>
                </div>
                <div className="max-h-36 overflow-y-auto border-2 border-[#141414] p-2 space-y-1.5 bg-[#E4E3E0]/20 custom-scrollbar">
                  {activeConnections.length > 0 ? (
                    activeConnections.map((conn) => {
                      const agentIdentifier = conn.agentId || conn.id;
                      const isSelected = selectedSpogAgentIds.includes(agentIdentifier);
                      return (
                        <div
                          key={agentIdentifier}
                          onClick={() => {
                            if (isSelected) {
                              setSelectedSpogAgentIds(selectedSpogAgentIds.filter(id => id !== agentIdentifier));
                            } else {
                              setSelectedSpogAgentIds([...selectedSpogAgentIds, agentIdentifier]);
                            }
                          }}
                          className={`flex items-center justify-between p-2 border border-[#141414] cursor-pointer transition-colors ${
                            isSelected ? 'bg-[#141414] text-white' : 'bg-white text-[#141414] hover:bg-[#141414]/5'
                          }`}
                        >
                          <div className="flex items-center gap-2 min-w-0">
                            <AgentAvatar
                              name={conn.agentName}
                              avatar={conn.avatar}
                              id={conn.agentId}
                              isMaster={Boolean(conn.isMaster && !conn.isSlave)}
                              isSlave={Boolean(conn.isSlave)}
                              className="w-6 h-6 border border-[#141414] shrink-0"
                            />
                            <div className="flex flex-col min-w-0">
                              <span className="font-bold text-xs truncate uppercase">{conn.agentName}</span>
                              <span className={`font-mono text-[10px] truncate ${isSelected ? 'text-white/80' : 'text-[#141414]/60'}`}>
                                @{conn.agentId || conn.id} {conn.isMaster ? '(Master)' : conn.isSlave ? '(Slave)' : ''}
                              </span>
                            </div>
                          </div>
                          <div className={`w-4 h-4 border-2 border-[#141414] flex items-center justify-center font-mono text-xs ${isSelected ? 'bg-white text-[#141414]' : 'bg-white'}`}>
                            {isSelected ? '✓' : ''}
                          </div>
                        </div>
                      );
                    })
                  ) : (
                    <div className="text-center font-mono text-xs text-[#141414]/50 py-2">
                      No associated agents or fleet members available
                    </div>
                  )}
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsNewClusterOpen(false)}
                  className="px-4 py-2 border-2 border-[#141414] font-mono text-xs font-bold uppercase hover:bg-[#141414]/10 transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={creatingCluster}
                  className="px-4 py-2 bg-[#141414] text-white border-2 border-[#141414] font-mono text-xs font-bold uppercase hover:bg-black/80 transition-colors disabled:opacity-50 cursor-pointer shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] active:translate-x-[1px] active:translate-y-[1px]"
                >
                  {creatingCluster ? 'Creating...' : 'Create Cluster'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {isSpogModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-xs p-3 sm:p-6 flex items-center justify-center animate-in fade-in duration-200">
          <div className="relative w-full max-w-5xl bg-white border-4 border-[#141414] shadow-[12px_12px_0px_0px_rgba(20,20,20,1)] text-[#141414] max-h-[94vh] flex flex-col font-mono">
            <div className="bg-[#141414] text-white px-4 py-3 flex items-center justify-between border-b-4 border-[#141414] select-none shrink-0">
              <span className="text-xs font-black uppercase tracking-widest">
                SPOG - FLEET OVERVIEW ({activeConnections.length} ACTIVE AGENTS)
              </span>
              <button
                type="button"
                onClick={() => setIsSpogModalOpen(false)}
                className="p-1 bg-white text-[#141414] border-2 border-white hover:bg-black hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="bg-[#F5F4F0] px-4 py-2.5 border-b-2 border-[#141414] flex items-center justify-between gap-2 shrink-0">
              <div className="flex items-center gap-3">
                <span className="text-xs font-black uppercase tracking-wider text-[#141414]">
                  {spogMode === 'cluster' ? 'Slave Selection Protocol' : 'Slave command Protocol'}
                </span>
                {spogMode === 'cluster' && (
                  <div className="flex items-center gap-1.5 p-1 bg-white border border-[#141414]/20 shadow-inner">
                    <button
                      type="button"
                      onClick={() => setSelectedSpogAgentIds(activeConnections.map(c => c.agentId || c.id))}
                      className="text-[9px] font-black uppercase border-2 border-[#141414] px-1.5 py-0.5 bg-white hover:bg-[#141414] hover:text-white transition-all cursor-pointer"
                    >
                      Select All
                    </button>
                    <button
                      type="button"
                      onClick={() => setSelectedSpogAgentIds([])}
                      className="text-[9px] font-black uppercase border-2 border-[#141414] px-1.5 py-0.5 bg-white hover:bg-[#141414] hover:text-white transition-all cursor-pointer"
                    >
                      Deselect All
                    </button>
                  </div>
                )}
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  placeholder="Search Slave"
                  value={spogSearchQuery}
                  onChange={(e) => setSpogSearchQuery(e.target.value)}
                  className="px-2.5 py-1 text-xs font-bold uppercase bg-white border-2 border-[#141414] focus:outline-hidden"
                />
              </div>
            </div>

            <div className="p-4 sm:p-6 overflow-y-auto flex-1">
              {(() => {
                const filteredAgents = activeConnections.filter((conn: any) => {
                  if (!spogSearchQuery.trim()) return true;
                  const query = spogSearchQuery.toLowerCase();
                  const name = (conn.agentName || '').toLowerCase();
                  const agentId = (conn.agentId || '').toLowerCase();
                  return name.includes(query) || agentId.includes(query);
                });

                if (filteredAgents.length === 0) {
                  return (
                    <div className="p-8 border-2 border-dashed border-[#141414]/30 text-center text-xs font-bold text-[#141414]/60 uppercase tracking-widest bg-neutral-50">
                      No agents match search query
                    </div>
                  );
                }

                return (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
                    {filteredAgents.map((conn: any) => {
                      const agentId = conn.agentId || conn.id;
                      const isSelected = spogMode === 'cluster' && selectedSpogAgentIds.includes(agentId);
                      const spogUnread = getConnUnreadCount(unreadCounts, conn, accountKey);
                      return (
                      <div
                        key={agentId}
                        onPointerEnter={() => { if (spogMode !== 'cluster') triggerConnWarmup(conn); }}
                        onClick={() => {
                          if (spogMode === 'cluster') {
                            if (isSelected) {
                              setSelectedSpogAgentIds(selectedSpogAgentIds.filter(id => id !== agentId));
                            } else {
                              setSelectedSpogAgentIds([...selectedSpogAgentIds, agentId]);
                            }
                          } else {
                             // Original functionality
                             markAsRead(conn.id || conn.connectionId, conn);
                             onOpenChat?.({
                                id: conn.id || conn.connectionId,
                                allConnectionIds: conn.allConnectionIds,
                                agentName: conn.agentName,
                                avatar: conn.avatar,
                                agentId: conn.agentId,
                                peerE2eePublicKey: conn.peerE2eePublicKey,
                                isMaster: conn.isMaster,
                                isSlave: conn.isSlave,
                              });
                              setIsSpogModalOpen(false);
                          }
                        }}
                        className={`p-2.5 border-2 border-[#141414] shadow-[3px_3px_0px_0px_rgba(20,20,20,1)] flex flex-col justify-between gap-2 cursor-pointer ${isSelected ? 'bg-[#141414] text-white' : 'bg-white'}`}
                      >
                        <div className="flex items-center gap-2 min-w-0">
                          <AgentAvatar
                            name={conn.agentName}
                            avatar={conn.avatar}
                            id={conn.agentId}
                            isMaster={Boolean(conn.isMaster && !conn.isSlave)}
                            isSlave={Boolean(conn.isSlave)}
                            className="w-8 h-8 border border-[#141414] shrink-0"
                          />
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <p className="text-xs font-black uppercase truncate">
                                {conn.agentName || conn.agentId || 'Agent'}
                              </p>
                              {conn.isMaster && !conn.isSlave ? (
                                <span className={`px-1 py-0.2 text-[8px] font-black uppercase tracking-wider border shrink-0 ${isSelected ? 'bg-white text-[#141414] border-white' : 'bg-[#141414] text-white border-[#141414]'}`}>
                                  MASTER
                                </span>
                              ) : (
                                <span className={`px-1 py-0.2 text-[8px] font-black uppercase tracking-wider border shrink-0 ${isSelected ? 'bg-white/20 text-white border-white/30' : 'bg-[#E4E3E0] text-[#141414] border-[#141414]/30'}`}>
                                  SLAVE
                                </span>
                              )}
                            </div>
                            <p className={`text-[10px] font-mono truncate ${isSelected ? 'text-white/70' : 'text-[#141414]/70'}`}>
                              @{agentId}
                            </p>
                          </div>
                        </div>
                        
                        {spogMode === 'cluster' ? (
                          <div className="flex items-center justify-end pt-2 border-t border-[#141414]/15">
                             <div className={`w-4 h-4 border-2 ${isSelected ? 'border-white bg-white text-[#141414]' : 'border-[#141414]'} flex items-center justify-center font-mono text-xs`}>
                               {isSelected ? '✓' : ''}
                             </div>
                          </div>
                        ) : (
                          <div className="flex items-center justify-between pt-2 border-t border-[#141414]/15">
                            {Boolean(spogUnread > 0) && (
                              <span
                                className="min-w-5 h-5 px-1 rounded-full bg-[#141414] text-white text-[9px] font-mono font-black border border-[#141414] flex items-center justify-center shrink-0 shadow-[1px_1px_0px_0px_rgba(20,20,20,0.3)]"
                                title={`${spogUnread} unread messages`}
                              >
                                {spogUnread > 99 ? '99+' : spogUnread}
                              </span>
                            )}
                            <button
                                type="button"
                                onPointerEnter={() => triggerConnWarmup(conn)}
                                onPointerDown={() => triggerConnWarmup(conn)}
                                onFocus={() => triggerConnWarmup(conn)}
                                onClick={(e) => {
                                    e.stopPropagation();
                                    markAsRead(conn.id || conn.connectionId, conn);
                                    setIsSpogModalOpen(false);
                                    onOpenChat?.({
                                        id: conn.id || conn.connectionId,
                                        allConnectionIds: conn.allConnectionIds,
                                        agentName: conn.agentName,
                                        avatar: conn.avatar,
                                        agentId: conn.agentId,
                                        peerE2eePublicKey: conn.peerE2eePublicKey,
                                        isMaster: conn.isMaster,
                                        isSlave: conn.isSlave,
                                    });
                                }}
                                className="px-2 py-0.5 bg-[#141414] text-white text-[9px] font-bold uppercase hover:bg-black/80 transition-colors cursor-pointer ml-auto"
                            >
                                Command
                            </button>
                          </div>
                        )}
                      </div>
                    )})}
                  </div>
                );
              })()}
            </div>
            
            {spogMode === 'cluster' && (
                <div className="bg-[#141414] text-white p-4 shrink-0">
                    <button
                        type="button"
                        onClick={() => {
                            setIsSpogModalOpen(false);
                        }}
                        className="w-full bg-white text-[#141414] py-3 font-black uppercase text-sm tracking-widest border-2 border-white hover:bg-neutral-200 transition-colors"
                    >
                        APPLY SELECTION & CLOSE
                    </button>
                </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};