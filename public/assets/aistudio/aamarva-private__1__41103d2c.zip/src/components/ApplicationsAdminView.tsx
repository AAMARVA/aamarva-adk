import React, { useState, useEffect, useCallback } from 'react';
import {
  FileText,
  CheckCircle2,
  XCircle,
  RefreshCw,
  ArrowLeft,
  Mail,
  User,
  Cpu,
  Clock,
  ChevronDown,
  ChevronUp,
  Plus,
  Trash2,
  AlertCircle,
  ShieldCheck,
  Lock,
  KeyRound,
  Send,
} from 'lucide-react';
import { BrutalistLoader } from './BrutalistLoader';

interface ApplicationItem {
  id: string;
  fullName: string;
  emailAddress: string;
  githubProfile: string;
  linkedinProfile: string;
  xProfile?: string;
  redditProfile?: string;
  bestDescribes: string;
  operatingAgent: string;
  agentName: string;
  agentUrl: string;
  agentDetails: string;
  agentStage: string;
  agentFrameworks: string[];
  agentFrameworksOther?: string;
  agentOperateLocation: string;
  devEnvironment: string;
  devEnvironmentOther: string;
  languages: string[];
  languagesOther: string;
  modelProviders: string[];
  modelProvidersOther: string;
  usesExternalTools: string;
  communicatesWithAgents: string;
  communicationDetails: string;
  hopeToAccomplish: string;
  agentUsePurpose: string;
  discoverCapability: string;
  discoveryProblems: string;
  contributions: string[];
  contributionsOther: string;
  first30Days: string;
  additionalNotes: string;
  createdAt: string;
  status?: 'Under Review' | 'Approved' | 'Declined';
}

interface ApplicationsAdminViewProps {
  onBack?: () => void;
}

const ADMIN_SESSION_STORAGE_KEY = 'aamarva_admin_otp_jwt';
const AUTHORIZED_GATEWAY_EMAIL = 'founder@aamarva.com';

export const ApplicationsAdminView: React.FC<ApplicationsAdminViewProps> = ({ onBack }) => {
  const [adminToken, setAdminToken] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      return sessionStorage.getItem(ADMIN_SESSION_STORAGE_KEY) || '';
    }
    return '';
  });
  const [gatewayEmail, setGatewayEmail] = useState<string>(AUTHORIZED_GATEWAY_EMAIL);
  const [otpSent, setOtpSent] = useState<boolean>(false);
  const [otpCode, setOtpCode] = useState<string>('');
  const [isRequestingOtp, setIsRequestingOtp] = useState<boolean>(false);
  const [isVerifyingOtp, setIsVerifyingOtp] = useState<boolean>(false);
  const [otpMessage, setOtpMessage] = useState<string>('');
  const [otpError, setOtpError] = useState<string>('');

  const [activeTab, setActiveTab] = useState<'applications' | 'approved' | 'reject' | 'whitelist'>('applications');
  const [applications, setApplications] = useState<ApplicationItem[]>([]);
  const [whitelist, setWhitelist] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [actionLoadingId, setActionLoadingId] = useState<string | null>(null);
  const [expandedIds, setExpandedIds] = useState<Record<string, boolean>>({});
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [statusBanner, setStatusBanner] = useState<string>('');
  const [manualEmail, setManualEmail] = useState<string>('');
  const [isAddingWhitelist, setIsAddingWhitelist] = useState<boolean>(false);
  const [removingEmail, setRemovingEmail] = useState<string | null>(null);

  const handleLockSession = useCallback(() => {
    sessionStorage.removeItem(ADMIN_SESSION_STORAGE_KEY);
    setAdminToken('');
    setOtpSent(false);
    setOtpCode('');
    setOtpMessage('');
    setOtpError('');
  }, []);

  const fetchAdminData = useCallback(async (silent = false) => {
    if (!adminToken) return;
    if (!silent) setIsLoading(true);
    setErrorMessage('');
    try {
      const res = await fetch('/api/applications/admin', {
        headers: { Authorization: `Bearer ${adminToken}` },
      });
      if (res.status === 401 || res.status === 403) {
        handleLockSession();
        return;
      }
      const data = await res.json();
      if (!res.ok || !data?.success) {
        throw new Error(data?.error || 'Failed to load applications.');
      }
      setApplications(Array.isArray(data.applications) ? data.applications : []);
      setWhitelist(Array.isArray(data.whitelist) ? data.whitelist : []);
    } catch (err: any) {
      setErrorMessage(err?.message || 'Unable to load applications.');
    } finally {
      if (!silent) setIsLoading(false);
    }
  }, [adminToken, handleLockSession]);

  useEffect(() => {
    if (adminToken) {
      fetchAdminData();
    }
  }, [adminToken, fetchAdminData]);

  const handleRequestOtp = async () => {
    setOtpError('');
    setOtpMessage('');
    setIsRequestingOtp(true);
    try {
      const res = await fetch('/api/applications/admin/request-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: AUTHORIZED_GATEWAY_EMAIL }),
      });
      const data = await res.json();
      if (!res.ok || !data?.success) {
        throw new Error(data?.error || 'Failed to send OTP.');
      }
      setOtpSent(true);
      setOtpMessage('OTP sent');
    } catch (err: any) {
      setOtpError(err?.message || 'Failed to send OTP.');
    } finally {
      setIsRequestingOtp(false);
    }
  };

  const verifyOtpCode = async (codeToVerify: string) => {
    const cleanCode = codeToVerify.trim();
    if (cleanCode.length < 6) {
      setOtpError('Enter 6-digit OTP');
      return;
    }
    setIsVerifyingOtp(true);
    setOtpError('');
    setOtpMessage('');
    try {
      const res = await fetch('/api/applications/admin/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: cleanCode }),
      });
      const data = await res.json();
      if (!res.ok || !data?.success || !data?.token) {
        throw new Error(data?.error || 'Invalid or expired OTP.');
      }
      sessionStorage.setItem(ADMIN_SESSION_STORAGE_KEY, data.token);
      setAdminToken(data.token);
      setOtpCode('');
    } catch (err: any) {
      setOtpError(err?.message || 'OTP verification failed.');
    } finally {
      setIsVerifyingOtp(false);
    }
  };

  const handleOtpInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const digits = e.target.value.replace(/\D/g, '').slice(0, 6);
    setOtpCode(digits);
    setOtpError('');
    if (digits.length === 6) {
      verifyOtpCode(digits);
    }
  };

  const handleGatewaySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (otpCode.trim().length === 6) {
      verifyOtpCode(otpCode);
    } else {
      handleRequestOtp();
    }
  };

  const handleApprove = async (app: ApplicationItem) => {
    setActionLoadingId(app.id);
    setErrorMessage('');
    setStatusBanner('');
    try {
      const res = await fetch('/api/applications/admin/approve', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`,
        },
        body: JSON.stringify({ id: app.id, email: app.emailAddress }),
      });
      if (res.status === 401 || res.status === 403) {
        handleLockSession();
        return;
      }
      const data = await res.json();
      if (!res.ok || !data?.success) {
        throw new Error(data?.error || 'Failed to approve application.');
      }
      setStatusBanner(
        `Approved & whitelisted ${app.emailAddress} (${app.fullName}). Approval email dispatched.`
      );
      await fetchAdminData(true);
    } catch (err: any) {
      setErrorMessage(err?.message || 'Failed to approve application.');
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleReject = async (app: ApplicationItem) => {
    setActionLoadingId(app.id);
    setErrorMessage('');
    setStatusBanner('');
    try {
      const res = await fetch('/api/applications/admin/reject', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`,
        },
        body: JSON.stringify({ id: app.id, email: app.emailAddress }),
      });
      if (res.status === 401 || res.status === 403) {
        handleLockSession();
        return;
      }
      const data = await res.json();
      if (!res.ok || !data?.success) {
        throw new Error(data?.error || 'Failed to reject application.');
      }
      setStatusBanner(
        `Rejected application for ${app.emailAddress} (${app.fullName}). Decision email dispatched.`
      );
      await fetchAdminData(true);
    } catch (err: any) {
      setErrorMessage(err?.message || 'Failed to reject application.');
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleManualWhitelist = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualEmail.trim()) return;
    setIsAddingWhitelist(true);
    setErrorMessage('');
    setStatusBanner('');
    try {
      const res = await fetch('/api/applications/admin/whitelist', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`,
        },
        body: JSON.stringify({ email: manualEmail.trim(), sendEmail: true }),
      });
      if (res.status === 401 || res.status === 403) {
        handleLockSession();
        return;
      }
      const data = await res.json();
      if (!res.ok || !data?.success) {
        throw new Error(data?.error || 'Failed to whitelist email.');
      }
      setStatusBanner(
        `Added ${manualEmail.trim().toLowerCase()} to the registration whitelist and dispatched approval email.`
      );
      setManualEmail('');
      await fetchAdminData(true);
    } catch (err: any) {
      setErrorMessage(err?.message || 'Failed to whitelist email.');
    } finally {
      setIsAddingWhitelist(false);
    }
  };

  const handleRemoveWhitelistEmail = async (email: string) => {
    setRemovingEmail(email);
    setErrorMessage('');
    setStatusBanner('');
    try {
      const res = await fetch('/api/applications/admin/whitelist/remove', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`,
        },
        body: JSON.stringify({ email }),
      });
      if (res.status === 401 || res.status === 403) {
        handleLockSession();
        return;
      }
      const data = await res.json();
      if (!res.ok || !data?.success) {
        throw new Error(data?.error || 'Failed to remove email from whitelist.');
      }
      setStatusBanner(`Removed ${email} from the registration whitelist.`);
      await fetchAdminData(true);
    } catch (err: any) {
      setErrorMessage(err?.message || 'Failed to remove email from whitelist.');
    } finally {
      setRemovingEmail(null);
    }
  };

  const toggleExpand = (id: string) => {
    setExpandedIds((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  // Minimal OTP Gateway for /applications/admin
  if (!adminToken) {
    return (
      <div className="w-full max-w-sm mx-auto py-20 px-4 font-mono text-[#141414]">
        <form
          onSubmit={handleGatewaySubmit}
          className="bg-white border-2 border-[#141414] p-6 shadow-[6px_6px_0px_0px_rgba(20,20,20,1)] space-y-4"
        >
          <input
            type="text"
            inputMode="numeric"
            maxLength={6}
            value={otpCode}
            onChange={handleOtpInputChange}
            placeholder="ENTER OTP"
            className="w-full px-4 py-3 bg-white border-2 border-[#141414] text-sm font-black tracking-[0.3em] text-center focus:outline-none"
          />

          <button
            type="button"
            onClick={() => (otpCode.trim().length === 6 ? verifyOtpCode(otpCode) : handleRequestOtp())}
            disabled={isRequestingOtp || isVerifyingOtp}
            className="w-full py-3 bg-[#141414] hover:bg-black text-white text-xs font-black uppercase tracking-widest border-2 border-[#141414] transition-all cursor-pointer disabled:opacity-50"
          >
            {isVerifyingOtp
              ? 'Verifying...'
              : isRequestingOtp
              ? 'Sending...'
              : otpCode.trim().length === 6
              ? 'Verify OTP'
              : otpSent
              ? 'Resend OTP'
              : 'Send OTP'}
          </button>

          {otpError && (
            <p className="text-[11px] font-bold text-center text-[#141414]">{otpError}</p>
          )}
          {otpMessage && !otpError && (
            <p className="text-[11px] font-bold text-center text-[#141414]/70 uppercase">{otpMessage}</p>
          )}
        </form>
      </div>
    );
  }

  const pendingApps = applications.filter((a) => !a.status || a.status === 'Under Review');
  const approvedApps = applications.filter((a) => a.status === 'Approved');
  const rejectedApps = applications.filter((a) => a.status === 'Declined');

  const displayedList =
    activeTab === 'applications'
      ? pendingApps
      : activeTab === 'approved'
      ? approvedApps
      : rejectedApps;

  return (
    <div className="w-full max-w-5xl mx-auto py-6 px-4 sm:px-6 font-mono text-[#141414] space-y-6">
      {/* Top Header Bar */}
      <div className="bg-white border-2 border-[#141414] p-5 shadow-[4px_4px_0px_0px_rgba(20,20,20,1)] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 bg-[#141414] text-white text-[10px] font-black uppercase tracking-widest">
              /APPLICATIONS/ADMIN
            </span>
            <span className="text-[10px] font-bold uppercase text-[#141414]/60">
              AUTHORIZED: FOUNDER@AAMARVA.COM
            </span>
          </div>
          <h1 className="text-lg sm:text-xl font-black uppercase tracking-tight">
            Operator Access Applications
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => fetchAdminData()}
            className="px-3 py-2 bg-white hover:bg-[#E4E3E0] text-[#141414] text-xs font-black uppercase border-2 border-[#141414] shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] flex items-center gap-1.5 cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>
          <button
            type="button"
            onClick={handleLockSession}
            className="px-3 py-2 bg-white hover:bg-[#E4E3E0] text-[#141414] text-xs font-black uppercase border-2 border-[#141414] shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] flex items-center gap-1.5 cursor-pointer"
          >
            <Lock className="w-3.5 h-3.5" />
            <span>Lock Gateway</span>
          </button>
          {onBack && (
            <button
              type="button"
              onClick={onBack}
              className="px-3 py-2 bg-[#141414] text-white text-xs font-black uppercase border-2 border-[#141414] shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] flex items-center gap-1.5 cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Return</span>
            </button>
          )}
        </div>
      </div>

      {/* Four Primary Section Tabs: Application | Approved | Reject | Whitelist Email */}
      <div className="bg-white border-2 border-[#141414] p-3 shadow-[3px_3px_0px_0px_rgba(20,20,20,1)]">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          <button
            type="button"
            onClick={() => setActiveTab('applications')}
            className={`py-3 px-3 font-mono font-black text-xs uppercase tracking-wider border-2 border-[#141414] transition-all flex items-center justify-center gap-2 cursor-pointer ${
              activeTab === 'applications'
                ? 'bg-[#141414] text-white shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]'
                : 'bg-white text-[#141414] hover:bg-[#E4E3E0]'
            }`}
          >
            <FileText className="w-4 h-4 shrink-0" />
            <span>Application ({pendingApps.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('approved')}
            className={`py-3 px-3 font-mono font-black text-xs uppercase tracking-wider border-2 border-[#141414] transition-all flex items-center justify-center gap-2 cursor-pointer ${
              activeTab === 'approved'
                ? 'bg-[#141414] text-white shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]'
                : 'bg-white text-[#141414] hover:bg-[#E4E3E0]'
            }`}
          >
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>Approved ({approvedApps.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('reject')}
            className={`py-3 px-3 font-mono font-black text-xs uppercase tracking-wider border-2 border-[#141414] transition-all flex items-center justify-center gap-2 cursor-pointer ${
              activeTab === 'reject'
                ? 'bg-[#141414] text-white shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]'
                : 'bg-white text-[#141414] hover:bg-[#E4E3E0]'
            }`}
          >
            <XCircle className="w-4 h-4 shrink-0" />
            <span>Reject ({rejectedApps.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('whitelist')}
            className={`py-3 px-3 font-mono font-black text-xs uppercase tracking-wider border-2 border-[#141414] transition-all flex items-center justify-center gap-2 cursor-pointer ${
              activeTab === 'whitelist'
                ? 'bg-[#141414] text-white shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]'
                : 'bg-white text-[#141414] hover:bg-[#E4E3E0]'
            }`}
          >
            <ShieldCheck className="w-4 h-4 shrink-0" />
            <span>Whitelist Email ({whitelist.length})</span>
          </button>
        </div>
      </div>

      {/* Feedback Banners */}
      {errorMessage && (
        <div className="p-3.5 bg-white border-2 border-[#141414] text-xs font-bold flex items-center gap-2.5 shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {statusBanner && (
        <div className="p-3.5 bg-[#141414] text-white border-2 border-[#141414] text-xs font-bold flex items-center justify-between gap-2.5 shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{statusBanner}</span>
          </div>
          <button
            type="button"
            onClick={() => setStatusBanner('')}
            className="text-[10px] uppercase underline cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Main Content Area */}
      {isLoading ? (
        <div className="bg-white border-2 border-[#141414] p-8 shadow-[4px_4px_0px_0px_rgba(20,20,20,1)]">
          <BrutalistLoader text="LOADING ADMIN DATA..." />
        </div>
      ) : activeTab === 'whitelist' ? (
        <div className="space-y-4">
          {/* Whitelist Summary & Manual Whitelist Form */}
          <div className="bg-white border-2 border-[#141414] p-5 shadow-[4px_4px_0px_0px_rgba(20,20,20,1)] space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b-2 border-[#141414]">
              <div>
                <h2 className="text-sm font-black uppercase tracking-wider">
                  Registration Whitelist Directory
                </h2>
                <p className="text-[11px] text-[#141414]/70">
                  Emails authorized to register an operator identity on the AAMARVA Floor.
                </p>
              </div>
              <div className="px-3.5 py-2 bg-[#141414] text-white text-xs font-black uppercase tracking-wider border-2 border-[#141414] shrink-0">
                Total Whitelisted: {whitelist.length}
              </div>
            </div>

            <form onSubmit={handleManualWhitelist} className="flex flex-col sm:flex-row gap-2.5">
              <div className="relative flex-1 flex items-center">
                <Mail className="absolute left-3 w-4 h-4 text-[#141414]/40" />
                <input
                  type="email"
                  required
                  value={manualEmail}
                  onChange={(e) => setManualEmail(e.target.value)}
                  placeholder="Enter email address to whitelist & dispatch approval email..."
                  className="w-full pl-10 pr-3 py-2.5 bg-white border-2 border-[#141414] text-xs focus:outline-none"
                />
              </div>
              <button
                type="submit"
                disabled={isAddingWhitelist}
                className="px-4 py-2.5 bg-[#141414] hover:bg-black text-white text-xs font-black uppercase border-2 border-[#141414] shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                <Plus className="w-4 h-4" />
                <span>{isAddingWhitelist ? 'Whitelisting...' : 'Add to Whitelist'}</span>
              </button>
            </form>
          </div>

          {/* Whitelisted Emails List */}
          {whitelist.length === 0 ? (
            <div className="bg-white border-2 border-[#141414] p-10 text-center shadow-[4px_4px_0px_0px_rgba(20,20,20,1)] space-y-2">
              <p className="text-xs font-black uppercase tracking-wider">
                0 Emails Currently Whitelisted
              </p>
              <p className="text-[11px] text-[#141414]/60">
                Approve an application or manually add an email above to whitelist an operator.
              </p>
            </div>
          ) : (
            <div className="bg-white border-2 border-[#141414] shadow-[4px_4px_0px_0px_rgba(20,20,20,1)] divide-y-2 divide-[#141414]">
              {whitelist.map((email, index) => (
                <div
                  key={email}
                  className="p-4 flex items-center justify-between gap-3 hover:bg-[#FAF9F5] transition-colors"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <span className="px-2 py-0.5 bg-[#141414] text-white text-[10px] font-black">
                      #{index + 1}
                    </span>
                    <Mail className="w-4 h-4 shrink-0 text-[#141414]/60" />
                    <span className="text-xs sm:text-sm font-black break-all">{email}</span>
                    <span className="hidden sm:inline-block px-2 py-0.5 bg-[#E4E3E0] border border-[#141414] text-[10px] font-bold uppercase">
                      WHITELISTED
                    </span>
                  </div>

                  <button
                    type="button"
                    disabled={removingEmail === email}
                    onClick={() => handleRemoveWhitelistEmail(email)}
                    className="px-3 py-1.5 bg-white hover:bg-red-50 text-red-600 text-[10px] font-black uppercase tracking-wider border-2 border-red-600 shadow-[2px_2px_0px_0px_rgba(220,38,38,1)] flex items-center gap-1 cursor-pointer shrink-0 disabled:opacity-50"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>{removingEmail === email ? 'Removing...' : 'Remove'}</span>
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      ) : displayedList.length === 0 ? (
        <div className="bg-white border-2 border-[#141414] p-10 text-center shadow-[4px_4px_0px_0px_rgba(20,20,20,1)] space-y-2">
          <p className="text-xs font-black uppercase tracking-wider">
            {activeTab === 'applications'
              ? 'No Pending Applications Under Review'
              : activeTab === 'approved'
              ? 'No Approved Applications Yet'
              : 'No Rejected Applications'}
          </p>
          <p className="text-[11px] text-[#141414]/60">
            {activeTab === 'applications'
              ? 'New 5-step intake submissions will appear here immediately.'
              : activeTab === 'approved'
              ? 'Approve an application from the Application tab to whitelist the operator.'
              : 'Rejected applications will be archived in this list.'}
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {displayedList.map((app) => {
            const isExpanded = Boolean(expandedIds[app.id]);
            const isProcessing = actionLoadingId === app.id;
            const statusLabel = app.status || 'Under Review';

            return (
              <div
                key={app.id}
                className="bg-white border-2 border-[#141414] shadow-[4px_4px_0px_0px_rgba(20,20,20,1)] overflow-hidden"
              >
                {/* Application Summary Header */}
                <div className="p-4 sm:p-5 bg-white flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="space-y-1.5">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="px-2 py-0.5 bg-[#141414] text-white text-[10px] font-black uppercase">
                        {statusLabel}
                      </span>
                      <span className="text-sm font-black uppercase">{app.fullName}</span>
                      <span className="text-xs text-[#141414]/70 font-bold">
                        &lt;{app.emailAddress}&gt;
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] text-[#141414]/80">
                      <span className="flex items-center gap-1 font-bold">
                        <User className="w-3.5 h-3.5" />
                        {app.bestDescribes || 'Operator'}
                      </span>
                      <span className="flex items-center gap-1 font-bold">
                        <Cpu className="w-3.5 h-3.5" />
                        Agent: {app.agentName || 'Unnamed'} ({app.agentStage || 'Development'})
                      </span>
                      <span className="flex items-center gap-1 text-[#141414]/60">
                        <Clock className="w-3.5 h-3.5" />
                        {app.createdAt ? new Date(app.createdAt).toLocaleString() : 'Just now'}
                      </span>
                    </div>
                  </div>

                  {/* Action Buttons: View Dossier + Approve + Reject */}
                  <div className="flex flex-wrap items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => toggleExpand(app.id)}
                      className="px-3 py-2 bg-[#E4E3E0] hover:bg-[#d5d4d0] text-[#141414] text-[10px] font-black uppercase border-2 border-[#141414] flex items-center gap-1 cursor-pointer"
                    >
                      <span>{isExpanded ? 'Hide 5-Step Dossier' : 'View 5-Step Dossier'}</span>
                      {isExpanded ? (
                        <ChevronUp className="w-3.5 h-3.5" />
                      ) : (
                        <ChevronDown className="w-3.5 h-3.5" />
                      )}
                    </button>

                    {statusLabel === 'Under Review' && (
                      <>
                        <button
                          type="button"
                          disabled={isProcessing}
                          onClick={() => handleApprove(app)}
                          className="px-3.5 py-2 bg-[#141414] hover:bg-black text-white text-[10px] font-black uppercase tracking-wider border-2 border-[#141414] shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>{isProcessing ? 'Processing...' : 'Approve'}</span>
                        </button>

                        <button
                          type="button"
                          disabled={isProcessing}
                          onClick={() => handleReject(app)}
                          className="px-3.5 py-2 bg-white hover:bg-red-50 text-red-600 text-[10px] font-black uppercase tracking-wider border-2 border-red-600 shadow-[2px_2px_0px_0px_rgba(220,38,38,1)] flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                        >
                          <XCircle className="w-3.5 h-3.5" />
                          <span>{isProcessing ? 'Processing...' : 'Reject'}</span>
                        </button>
                      </>
                    )}
                  </div>
                </div>

                {/* Expanded 5-Step Application Dossier */}
                {isExpanded && (
                  <div className="p-4 sm:p-5 bg-[#FAF9F5] border-t-2 border-[#141414] grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                    {/* Step 1 */}
                    <div className="p-3 bg-white border border-[#141414] space-y-1.5">
                      <p className="text-[10px] font-black uppercase bg-[#141414] text-white px-2 py-0.5 inline-block">
                        Step 1 // Operator Identity
                      </p>
                      <p><strong>Name:</strong> {app.fullName}</p>
                      <p><strong>Email:</strong> {app.emailAddress}</p>
                      <p><strong>Role:</strong> {app.bestDescribes}</p>
                      {app.githubProfile && (
                        <p className="break-all"><strong>GitHub:</strong> {app.githubProfile}</p>
                      )}
                      {app.linkedinProfile && (
                        <p className="break-all"><strong>LinkedIn:</strong> {app.linkedinProfile}</p>
                      )}
                      {app.xProfile && <p><strong>X:</strong> {app.xProfile}</p>}
                      {app.redditProfile && <p><strong>Reddit:</strong> {app.redditProfile}</p>}
                    </div>

                    {/* Step 2 */}
                    <div className="p-3 bg-white border border-[#141414] space-y-1.5">
                      <p className="text-[10px] font-black uppercase bg-[#141414] text-white px-2 py-0.5 inline-block">
                        Step 2 // Agent Overview
                      </p>
                      <p><strong>Operating Agent:</strong> {app.operatingAgent}</p>
                      <p><strong>Agent Name:</strong> {app.agentName}</p>
                      <p><strong>Stage:</strong> {app.agentStage}</p>
                      <p className="break-all"><strong>URL / Repo:</strong> {app.agentUrl || 'N/A'}</p>
                      <p><strong>Summary:</strong> {app.agentDetails}</p>
                    </div>

                    {/* Step 3 */}
                    <div className="p-3 bg-white border border-[#141414] space-y-1.5">
                      <p className="text-[10px] font-black uppercase bg-[#141414] text-white px-2 py-0.5 inline-block">
                        Step 3 // Technical Stack
                      </p>
                      <p>
                        <strong>Frameworks:</strong>{' '}
                        {Array.isArray(app.agentFrameworks) ? app.agentFrameworks.join(', ') : 'N/A'}
                        {app.agentFrameworksOther ? ` (${app.agentFrameworksOther})` : ''}
                      </p>
                      <p><strong>Runtime Location:</strong> {app.agentOperateLocation}</p>
                      <p><strong>Dev Environment:</strong> {app.devEnvironment}</p>
                      <p>
                        <strong>Languages:</strong>{' '}
                        {Array.isArray(app.languages) ? app.languages.join(', ') : 'N/A'}
                      </p>
                      <p>
                        <strong>Models:</strong>{' '}
                        {Array.isArray(app.modelProviders) ? app.modelProviders.join(', ') : 'N/A'}
                      </p>
                    </div>

                    {/* Step 4 */}
                    <div className="p-3 bg-white border border-[#141414] space-y-1.5">
                      <p className="text-[10px] font-black uppercase bg-[#141414] text-white px-2 py-0.5 inline-block">
                        Step 4 // Capabilities & Coordination
                      </p>
                      <p><strong>External Tools / MCP:</strong> {app.usesExternalTools}</p>
                      <p><strong>Multi-Agent Comms:</strong> {app.communicatesWithAgents}</p>
                      {app.communicationDetails && (
                        <p><strong>Comms Protocol:</strong> {app.communicationDetails}</p>
                      )}
                      <p><strong>Operational Purpose:</strong> {app.agentUsePurpose}</p>
                      <p><strong>AAMARVA Objectives:</strong> {app.hopeToAccomplish}</p>
                    </div>

                    {/* Step 5 */}
                    <div className="p-3 bg-white border border-[#141414] space-y-1.5 md:col-span-2">
                      <p className="text-[10px] font-black uppercase bg-[#141414] text-white px-2 py-0.5 inline-block">
                        Step 5 // Discovery & First 30 Days
                      </p>
                      <p><strong>Capability Discovery:</strong> {app.discoverCapability}</p>
                      <p><strong>Discovery Challenges:</strong> {app.discoveryProblems}</p>
                      <p>
                        <strong>Planned Contributions:</strong>{' '}
                        {Array.isArray(app.contributions) ? app.contributions.join(', ') : 'N/A'}
                      </p>
                      <p><strong>First 30 Days Plan:</strong> {app.first30Days}</p>
                      {app.additionalNotes && (
                        <p><strong>Additional Notes:</strong> {app.additionalNotes}</p>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
