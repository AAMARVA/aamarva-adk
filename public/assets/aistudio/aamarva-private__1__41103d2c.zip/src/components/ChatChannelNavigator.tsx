import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { ArrowLeft, Search, X } from 'lucide-react';
import { AgentAvatar } from './AgentAvatar';
import { getClusterSymbol } from '../lib/clusterSymbols';
import { apiFetch, getCurrentSessionAuthType, isSlaveAccount } from '../services/authApi';
import { useAuth } from '../context/AuthContext';
import {
  getAccountKey,
  getQueryCache,
  setQueryCache,
  seedFleetAccountsCache,
  buildCommandPitFleetList,
  getUnreadCounts,
  getConnUnreadCount,
  getClusterUnreadCount,
  getLastActivityTimestamp,
  clearUnreadCount,
  registerConnectionAlias,
  registerClusterAlias,
} from '../lib/appStateCache';

interface ChatChannelNavigatorProps {
  activeType: 'chat' | 'cluster';
  activeId: string;
  onSelectChat?: (chat: any) => void;
  onSelectClusterChat?: (cluster: { id: string; name: string; symbol?: string }) => void;
  onBackToPit: () => void;
  onCloseDrawer?: () => void;
  variant: 'sidebar' | 'drawer';
}

export const ChatChannelNavigator: React.FC<ChatChannelNavigatorProps> = ({
  activeType,
  activeId,
  onSelectChat,
  onSelectClusterChat,
  onBackToPit,
  onCloseDrawer,
  variant,
}) => {
  const { user, activeAccount, sessionAuthType } = useAuth();
  const actingUser = activeAccount || user;
  const accountKey = getAccountKey(user?.id, activeAccount?.id);
  const effectiveAuthType: 'human' | 'agent' = sessionAuthType || getCurrentSessionAuthType() || 'human';
  const isSlave = isSlaveAccount(actingUser);

  const [connections, setConnections] = useState<any[]>(() => {
    const cached = getQueryCache(accountKey, '/api/command-pit/fleet')?.data;
    return Array.isArray(cached) ? cached : [];
  });
  const [clusters, setClusters] = useState<any[]>(() => {
    const cached = getQueryCache(accountKey, '/api/clusters')?.data;
    return Array.isArray(cached) ? cached : [];
  });
  const [unreadCounts, setUnreadCounts] = useState<Record<string, number>>(() =>
    getUnreadCounts(accountKey)
  );
  const [searchQuery, setSearchQuery] = useState('');
  const [filterTab, setFilterTab] = useState<'connections' | 'clusters'>(() =>
    activeType === 'cluster' && !isSlave ? 'clusters' : 'connections'
  );

  useEffect(() => {
    setFilterTab(activeType === 'cluster' && !isSlave ? 'clusters' : 'connections');
  }, [activeType, isSlave]);

  useEffect(() => {
    const syncCounts = () => {
      setUnreadCounts({ ...getUnreadCounts(accountKey) });
    };
    syncCounts();
    window.addEventListener('unread-counts-updated', syncCounts);
    return () => window.removeEventListener('unread-counts-updated', syncCounts);
  }, [accountKey]);

  useEffect(() => {
    let cancelled = false;

    const loadMissing = async () => {
      if (connections.length === 0) {
        try {
          const [connRes, masterRes] = await Promise.allSettled([
            apiFetch('/api/connections?limit=100', { authType: effectiveAuthType }),
            apiFetch('/api/auth/master/accounts', { authType: effectiveAuthType }),
          ]);
          if (cancelled) return;
          const serverConnList =
            connRes.status === 'fulfilled' && connRes.value?.success
              ? Array.isArray(connRes.value?.data?.connections)
                ? connRes.value.data.connections
                : Array.isArray(connRes.value?.data)
                  ? connRes.value.data
                  : null
              : null;
          const connList = serverConnList ?? (getQueryCache(accountKey, '/api/connections')?.data || []);
          if (serverConnList !== null) {
            setQueryCache(accountKey, '/api/connections', serverConnList);
          }
          const masterData =
            masterRes.status === 'fulfilled' && masterRes.value?.success && masterRes.value?.data
              ? masterRes.value.data
              : getQueryCache('master_accounts', '/api/auth/master/accounts')?.data;
          if (masterRes.status === 'fulfilled' && masterRes.value?.success && masterRes.value?.data) {
            seedFleetAccountsCache(masterRes.value.data);
          }
          const activePersonaId = activeAccount?.id || user?.id;
          const mergedList = buildCommandPitFleetList(connList, masterData, activePersonaId, accountKey);
          if (mergedList.length > 0) {
            setQueryCache(accountKey, '/api/command-pit/fleet', mergedList);
            setConnections(mergedList);
          }
        } catch {
          // Silent fallback to existing cache
        }
      }

      if (!isSlave && clusters.length === 0) {
        try {
          const res = await apiFetch('/api/clusters', { authType: effectiveAuthType });
          if (cancelled) return;
          if (res?.success && Array.isArray(res.data)) {
            res.data.forEach((c: any) => registerClusterAlias(accountKey, c));
            setQueryCache(accountKey, '/api/clusters', res.data);
            setClusters(res.data);
          }
        } catch {
          // Silent fallback to existing cache
        }
      }
    };

    loadMissing();
    return () => {
      cancelled = true;
    };
  }, [accountKey, activeAccount?.id, user?.id, effectiveAuthType, isSlave, connections.length, clusters.length]);

  const sortedConnections = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const list = connections.filter((conn) => {
      if (!q) return true;
      const name = String(conn.agentName || '').toLowerCase();
      const aid = String(conn.agentId || '').toLowerCase();
      return name.includes(q) || aid.includes(q);
    });
    list.forEach((c) => registerConnectionAlias(accountKey, c));
    return [...list].sort((a, b) => {
      const uA = getConnUnreadCount(unreadCounts, a, accountKey);
      const uB = getConnUnreadCount(unreadCounts, b, accountKey);
      if (uA > 0 && uB === 0) return -1;
      if (uA === 0 && uB > 0) return 1;
      if (uA !== uB) return uB - uA;
      const tA = getLastActivityTimestamp(accountKey, a);
      const tB = getLastActivityTimestamp(accountKey, b);
      if (tA !== tB) return tB - tA;
      if (a.isMaster && !b.isMaster) return -1;
      if (!a.isMaster && b.isMaster) return 1;
      return String(a.agentName || '').localeCompare(String(b.agentName || ''));
    });
  }, [connections, searchQuery, unreadCounts, accountKey]);

  const sortedClusters = useMemo(() => {
    if (isSlave) return [];
    const q = searchQuery.trim().toLowerCase();
    const list = clusters.filter((c) => {
      if (!q) return true;
      return String(c.name || '').toLowerCase().includes(q);
    });
    list.forEach((c) => registerClusterAlias(accountKey, c));
    return [...list].sort((a, b) => {
      const uA = getClusterUnreadCount(unreadCounts, a, accountKey);
      const uB = getClusterUnreadCount(unreadCounts, b, accountKey);
      if (uA > 0 && uB === 0) return -1;
      if (uA === 0 && uB > 0) return 1;
      if (uA !== uB) return uB - uA;
      const tA = getLastActivityTimestamp(accountKey, a);
      const tB = getLastActivityTimestamp(accountKey, b);
      if (tA !== tB) return tB - tA;
      return String(a.name || '').localeCompare(String(b.name || ''));
    });
  }, [clusters, searchQuery, unreadCounts, accountKey, isSlave]);

  const totalConnUnread = useMemo(
    () => connections.reduce((sum, c) => sum + getConnUnreadCount(unreadCounts, c, accountKey), 0),
    [connections, unreadCounts, accountKey]
  );

  const totalClusterUnread = useMemo(
    () => (isSlave ? 0 : clusters.reduce((sum, c) => sum + getClusterUnreadCount(unreadCounts, c, accountKey), 0)),
    [clusters, unreadCounts, accountKey, isSlave]
  );

  const handleChooseConnection = useCallback(
    (conn: any) => {
      const connId = conn.id || conn.connectionId;
      if (!connId) return;
      const idsToClear = [connId, conn.connectionId, conn.agentId, conn.agentName].filter(
        (x): x is string => Boolean(x && typeof x === 'string' && x.trim())
      );
      clearUnreadCount(accountKey, idsToClear);
      apiFetch(`/api/connections/${connId}/read`, {
        method: 'POST',
        authType: 'human',
        body: JSON.stringify({ connectionId: connId, agentId: conn.agentId, ids: idsToClear }),
      }).catch(() => {});

      onSelectChat?.({
        id: connId,
        allConnectionIds: conn.allConnectionIds,
        agentName: conn.agentName,
        avatar: conn.avatar,
        agentId: conn.agentId,
        peerE2eePublicKey: conn.peerE2eePublicKey,
        isMaster: conn.isMaster,
        isSlave: conn.isSlave,
      });
      onCloseDrawer?.();
    },
    [accountKey, onSelectChat, onCloseDrawer]
  );

  const handleChooseCluster = useCallback(
    (cluster: any) => {
      if (!cluster?.id) return;
      const symbol = cluster.symbol || getClusterSymbol(cluster.id);
      const idsToClear = [cluster.id, cluster.clusterId, cluster.name].filter(Boolean);
      clearUnreadCount(accountKey, idsToClear);
      apiFetch(`/api/clusters/${cluster.id}/read`, {
        method: 'POST',
        authType: effectiveAuthType,
        body: JSON.stringify({ clusterId: cluster.id, ids: idsToClear }),
      }).catch(() => {});

      onSelectClusterChat?.({ id: cluster.id, name: cluster.name, symbol });
      onCloseDrawer?.();
    },
    [accountKey, effectiveAuthType, onSelectClusterChat, onCloseDrawer]
  );

  const normalizedActiveId = String(activeId || '').trim().toLowerCase();

  return (
    <div className="flex flex-col h-full w-full bg-[#E4E3E0] text-[#141414] overflow-hidden select-none">
      {/* Top Bar */}
      <div className="px-3.5 py-3 border-b-2 border-[#141414] flex items-center justify-between gap-2 shrink-0 bg-[#E4E3E0]">
        <button
          type="button"
          onClick={onBackToPit}
          className="inline-flex items-center gap-1.5 border-2 border-[#141414] px-2.5 py-1.5 bg-white text-[#141414] hover:bg-[#141414] hover:text-white transition-colors cursor-pointer font-mono text-[10px] font-black uppercase tracking-wider whitespace-nowrap shrink-0 shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] active:translate-x-0.5 active:translate-y-0.5 active:shadow-none"
        >
          <ArrowLeft className="w-3.5 h-3.5 shrink-0" />
          <span>Command Pit</span>
        </button>

        {variant === 'drawer' && onCloseDrawer && (
          <button
            type="button"
            onClick={onCloseDrawer}
            className="border-2 border-[#141414] p-1.5 bg-white text-[#141414] hover:bg-[#141414] hover:text-white transition-colors cursor-pointer"
            aria-label="Close channel switcher"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Search & Filter */}
      <div className="p-3 border-b-2 border-[#141414] space-y-2.5 bg-[#F5F4F0] shrink-0">
        <div className="relative">
          <Search className="w-3.5 h-3.5 text-white/60 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={filterTab === 'clusters' ? 'Search clusters...' : 'Search connections...'}
            className="w-full pl-8 pr-7 py-1.5 bg-[#141414] text-white border-2 border-[#141414] font-mono text-[11px] font-bold placeholder:text-white/50 caret-white focus:outline-none"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-white/60 hover:text-white cursor-pointer"
              aria-label="Clear search"
            >
              <X className="w-3 h-3" />
            </button>
          )}
        </div>

        {!isSlave && (
          <div className="grid grid-cols-2 border-2 border-[#141414] bg-white">
            <button
              type="button"
              onClick={() => setFilterTab('connections')}
              className={`py-1.5 text-[10px] font-mono font-black uppercase tracking-wider cursor-pointer transition-colors whitespace-nowrap flex items-center justify-center gap-1.5 ${
                filterTab === 'connections' ? 'bg-[#141414] text-white' : 'text-[#141414] hover:bg-[#E4E3E0]'
              }`}
            >
              <span>Connection</span>
              {totalConnUnread > 0 && (
                <span className={`px-1 text-[8px] font-black ${filterTab === 'connections' ? 'bg-white text-[#141414]' : 'bg-[#141414] text-white'}`}>
                  {totalConnUnread}
                </span>
              )}
            </button>
            <button
              type="button"
              onClick={() => setFilterTab('clusters')}
              className={`py-1.5 text-[10px] font-mono font-black uppercase tracking-wider border-l-2 border-[#141414] cursor-pointer transition-colors whitespace-nowrap flex items-center justify-center gap-1.5 ${
                filterTab === 'clusters' ? 'bg-[#141414] text-white' : 'text-[#141414] hover:bg-[#E4E3E0]'
              }`}
            >
              <span>Cluster</span>
              {totalClusterUnread > 0 && (
                <span className={`px-1 text-[8px] font-black ${filterTab === 'clusters' ? 'bg-white text-[#141414]' : 'bg-[#141414] text-white'}`}>
                  {totalClusterUnread}
                </span>
              )}
            </button>
          </div>
        )}
      </div>

      {/* Channels List */}
      <div className="flex-1 min-h-0 overflow-y-auto overscroll-contain custom-scrollbar p-2.5 space-y-4">
        {filterTab === 'connections' && (
          <div>
            <div className="px-1 pb-1.5 flex items-center justify-between">
              <span className="font-mono text-[10px] font-black uppercase tracking-widest text-[#141414]/70">
                Connections ({sortedConnections.length})
              </span>
            </div>
            {sortedConnections.length === 0 ? (
              <div className="p-3 border-2 border-dashed border-[#141414]/25 text-center font-mono text-[10px] text-[#141414]/50 uppercase">
                No connections found
              </div>
            ) : (
              <div className="space-y-1.5">
                {sortedConnections.map((conn) => {
                  const connId = conn.id || conn.connectionId;
                  const aliases = [
                    connId,
                    conn.connectionId,
                    ...(Array.isArray(conn.allConnectionIds) ? conn.allConnectionIds : []),
                  ]
                    .filter(Boolean)
                    .map((x: any) => String(x).trim().toLowerCase());
                  const isActive = activeType === 'chat' && aliases.includes(normalizedActiveId);
                  const unread = isActive ? 0 : getConnUnreadCount(unreadCounts, conn, accountKey);

                  return (
                    <button
                      key={connId || conn.agentId}
                      type="button"
                      onClick={() => handleChooseConnection(conn)}
                      className={`w-full text-left p-2.5 border-2 border-[#141414] flex items-center justify-between gap-2 transition-all cursor-pointer ${
                        isActive
                          ? 'bg-[#141414] text-white shadow-[3px_3px_0px_0px_rgba(20,20,20,0.35)]'
                          : 'bg-white text-[#141414] hover:bg-[#F5F4F0] shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] active:translate-x-[1px] active:translate-y-[1px]'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0 flex-1">
                        <AgentAvatar
                          name={conn.agentName}
                          avatar={conn.avatar}
                          id={conn.agentId}
                          className="w-8 h-8 border border-[#141414] shrink-0"
                        />
                        <div className="flex flex-col min-w-0 flex-1">
                          <div className="flex items-center gap-1.5 min-w-0">
                            <span className="font-mono font-black text-[11px] uppercase truncate">
                              {conn.agentName || conn.agentId || 'Agent'}
                            </span>
                            {conn.isMaster && !conn.isSlave && (
                              <span
                                className={`px-1 py-0.2 text-[7px] font-black uppercase border shrink-0 ${
                                  isActive
                                    ? 'bg-white text-[#141414] border-white'
                                    : 'bg-[#141414] text-white border-[#141414]'
                                }`}
                              >
                                M
                              </span>
                            )}
                          </div>
                          {conn.agentId && (
                            <span
                              className={`font-mono text-[9px] truncate ${
                                isActive ? 'text-white/70' : 'text-[#141414]/60'
                              }`}
                            >
                              @{conn.agentId.replace(/^@/, '')}
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        {unread > 0 && (
                          <span className="min-w-4 h-4 px-1 rounded-full bg-[#141414] text-white text-[8px] font-mono font-black flex items-center justify-center shrink-0">
                            {unread > 99 ? '99+' : unread}
                          </span>
                        )}
                        {!isActive && (
                          <span className="px-2 py-1 text-[9px] font-mono font-bold uppercase border border-[#141414] bg-[#141414] text-white">
                            Command
                          </span>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {!isSlave && filterTab === 'clusters' && (
          <div>
            <div className="px-1 pb-1.5 flex items-center justify-between">
              <span className="font-mono text-[10px] font-black uppercase tracking-widest text-[#141414]/70">
                Clusters ({sortedClusters.length})
              </span>
            </div>
            {sortedClusters.length === 0 ? (
              <div className="p-3 border-2 border-dashed border-[#141414]/25 text-center font-mono text-[10px] text-[#141414]/50 uppercase">
                No clusters found
              </div>
            ) : (
              <div className="space-y-1.5">
                {sortedClusters.map((cluster) => {
                  const symbol = cluster.symbol || getClusterSymbol(cluster.id);
                  const isActive =
                    activeType === 'cluster' &&
                    String(cluster.id || '').trim().toLowerCase() === normalizedActiveId;
                  const unread = isActive ? 0 : getClusterUnreadCount(unreadCounts, cluster, accountKey);

                  return (
                    <button
                      key={cluster.id}
                      type="button"
                      onClick={() => handleChooseCluster(cluster)}
                      className={`w-full text-left p-2.5 border-2 border-[#141414] flex items-center justify-between gap-2 transition-all cursor-pointer ${
                        isActive
                          ? 'bg-[#141414] text-white shadow-[3px_3px_0px_0px_rgba(20,20,20,0.35)]'
                          : 'bg-white text-[#141414] hover:bg-[#F5F4F0] shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] active:translate-x-[1px] active:translate-y-[1px]'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0 flex-1">
                        <div
                          className={`w-8 h-8 border-2 font-mono text-xs flex items-center justify-center font-black shrink-0 ${
                            isActive
                              ? 'bg-white text-[#141414] border-white'
                              : 'bg-[#141414] text-white border-[#141414]'
                          }`}
                        >
                          {symbol}
                        </div>
                        <span className="font-mono font-black text-[11px] uppercase truncate">
                          {cluster.name}
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        {unread > 0 && (
                          <span className="min-w-4 h-4 px-1 rounded-full bg-[#141414] text-white text-[8px] font-mono font-black flex items-center justify-center shrink-0">
                            {unread > 99 ? '99+' : unread}
                          </span>
                        )}
                        {!isActive && (
                          <span className="px-2 py-1 text-[9px] font-mono font-bold uppercase border border-[#141414] bg-[#141414] text-white">
                            Command
                          </span>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
