import React, { useState, useEffect, useRef } from 'react';

interface OptimizedImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  src: string;
  alt: string;
  className?: string;
  containerClassName?: string;
  showSkeleton?: boolean;
}

export const OptimizedImage: React.FC<OptimizedImageProps> = ({
  src,
  alt,
  className = '',
  containerClassName = '',
  showSkeleton = true,
  style,
  ...props
}) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [hasError, setHasError] = useState(false);
  const imgRef = useRef<HTMLImageElement | null>(null);

  useEffect(() => {
    if (imgRef.current && imgRef.current.complete && imgRef.current.naturalWidth > 0) {
      setIsLoaded(true);
      return;
    }

    const testImg = new Image();
    testImg.src = src;
    if (testImg.complete && testImg.naturalWidth > 0) {
      setIsLoaded(true);
    } else {
      setIsLoaded(false);
      setHasError(false);
    }
  }, [src]);

  return (
    <div className={`relative overflow-hidden ${containerClassName}`}>
      {/* Loading Skeleton */}
      {!isLoaded && !hasError && showSkeleton && (
        <div className="absolute inset-0 bg-[#0d0d10] animate-pulse flex flex-col items-center justify-center p-4 text-center z-10 rounded-lg border border-white/10 min-h-[140px]">
          <div className="w-6 h-6 border-2 border-white/20 border-t-white rounded-full animate-spin mb-2" />
          <span className="font-mono text-[10px] text-zinc-400 uppercase tracking-widest font-semibold">
            Loading Telemetry View...
          </span>
        </div>
      )}

      {/* Actual Image */}
      <img
        ref={imgRef}
        src={src}
        alt={alt}
        loading={props.loading || 'eager'}
        decoding={props.decoding || 'async'}
        style={style}
        onLoad={(e) => {
          setIsLoaded(true);
          if (props.onLoad) props.onLoad(e);
        }}
        onError={(e) => {
          setHasError(true);
          setIsLoaded(true);
          if (props.onError) props.onError(e);
        }}
        className={`transition-opacity duration-200 ease-in-out ${
          isLoaded ? 'opacity-100' : 'opacity-0'
        } ${className}`}
        {...props}
      />
    </div>
  );
};
