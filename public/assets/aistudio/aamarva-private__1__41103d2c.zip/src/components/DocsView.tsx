import React, { useState, useMemo } from 'react';
import { 
  Search, BookOpen, Terminal, Layers, ShieldCheck, Key, Zap, 
  Copy, Check, ArrowRight, ArrowLeft, ExternalLink, Code2, 
  FileText, Database, Activity, CheckCircle2, AlertTriangle, ChevronRight, Hash
} from 'lucide-react';

interface DocsViewProps {
  onBack?: () => void;
  onAccessApp?: (target?: 'login' | 'register') => void;
  isAuthenticated?: boolean;
}

interface DocArticle {
  id: string;
  category: string;
  title: string;
  description: string;
  badge?: string;
  content: {
    overview: string;
    sections: {
      heading: string;
      body: string;
      steps?: string[];
      codeSnippet?: {
        curl?: string;
        typescript?: string;
        python?: string;
      };
      responseExample?: string;
      note?: string;
    }[];
  };
}

const DOCS_DATA: DocArticle[] = [
  {
    id: 'quickstart',
    category: 'Getting Started',
    title: '5-Minute Fleet Quickstart',
    description: 'Complete customer onboarding sequence: from Master Account registration and slave deployment to framework integration and Command Pit oversight.',
    badge: 'ONBOARDING',
    content: {
      overview: 'AAMARVA provides sovereign fleet coordination and governance infrastructure for autonomous AI agents. Human Master Operators govern the fleet exclusively through the Web Console using password and registered FIDO2 passkey verification, while customer-hosted slave agent runtimes authenticate programmatically using their assigned Account ID and API Key. The public API base URL is https://aamarva.com.',
      sections: [
        {
          heading: 'Step 1 — Register a Master Account',
          body: 'Master account registration is performed directly through the AAMARVA landing page and Web Console interface. The Master Account represents the root supervisory identity and control plane owner for the human operator, holding sovereign authority over fleet policies, capability loadouts, and subordinate agent nodes.\\n\\nRegistration requires a Master Node Name (1 to 20 characters), an operator email address, and a secure password (minimum 8 characters). Master creation initializes your organization control plane.',
          steps: [
            'Click the "Access" or "Sign In" button in the top navigation bar, then select "Register".',
            'Enter your Master Node Name (1 to 20 characters, e.g. FleetSupervisor-01), operator email address, and master password.',
            'Submit to establish your sovereign master account and initialize your fleet control plane.'
          ],
          note: 'Security Requirement: Master registration is strictly performed by a human operator in the Web Console. Autonomous agents cannot register as master nodes.'
        },
        {
          heading: 'Step 2 — Log In via Web Console (Human WebAuthn)',
          body: 'Human account management happens exclusively through the Web Console, never through an agent API key. Master operators authenticate using two-factor password verification followed by registered FIDO2 / WebAuthn passkey verification.\\n\\nAuthentication Flow:\\n1. The operator enters Master Operator credentials into the secure Web Console login interface.\\n2. The browser prompts for device biometrics (Touch ID, Windows Hello) or a hardware security key (YubiKey).\\n3. Upon successful passkey assertion, an encrypted httpOnly session cookie (aamarva_human_session) is established, granting full access to My Agents, Loadouts, and Command Pit.',
          steps: [
            'Open the Web Console login interface.',
            'Enter your Master Operator email or Account ID and master password.',
            'Complete the registered WebAuthn / FIDO2 passkey challenge via your device biometric sensor or hardware security key (or complete first-time device registration if prompted).',
            'Access your fleet control deck to monitor assigned slaves, manage capability loadouts, and review HITL approval requests.'
          ],
          note: 'Security Requirement: Master accounts do not have or use static API keys. All human administrative actions are bound to authenticated console sessions.'
        },
        {
          heading: 'Step 3 — Deploy Slave Accounts',
          body: 'Slave accounts are deployed in the Web Console within the "My Agents" panel. Deploying a slave account creates a persistent cryptographic account identity registered to your fleet in the database. It consumes an available account slot from your active plan.\\n\\nBoth individual and bulk deployment are fully supported:\\n• Individual Deployment: Click "Deploy Agent", enter an agent identifier (up to 20 characters, e.g. Sentinel-Worker-01), and confirm.\\n• Bulk Deployment: Click "Bulk Deploy", enter the desired quantity within your remaining slot allowance, and confirm.\\n\\nImportant: Deploying a slave account establishes the identity record and access boundaries within AAMARVA; it does not automatically launch an agent runtime, spin up containers, or install an agent framework on your host infrastructure.',
          steps: [
            'Navigate to the "My Agents" card in the Web Console.',
            'Review your available deployment allowance (e.g. 5 slave account slots under the Master & Slave Agent Plan).',
            'Click "Deploy Agent" for single provisioning or "Bulk Deploy" for multiple agents.',
            'Confirm deployment to issue the account records.'
          ],
          note: 'Account Slots: If available slots reach zero, deploy buttons are disabled until additional account capacity is provisioned in the Loadouts panel.'
        },
        {
          heading: 'Step 4 — Obtain Agent Credentials',
          body: 'Immediately upon deploying a slave account, the Web Console opens the Credentials modal containing the newly generated credentials:\\n\\n• Account ID (internal field: agentId, format AMR-XXXX-XXXX): The sovereign public identity of the slave agent within the fleet.\\n• API Key (format aam_live_sec_...): The secret 256-bit key used by the agent runtime to authenticate.\\n\\nThese credentials belong exclusively to the corresponding slave account identity.\\n\\nSafe Credential Storage: The API key is displayed once upon creation and cannot be retrieved or recovered once the modal is closed. Store the API key in a secure secret manager or encrypted environment configuration. Never commit API keys into source code, git repositories, frontend web applications, or log streams.\\n\\nKey Rotation: If an API key is compromised, the operator opens "My Agents" in the Web Console dashboard and clicks "Rotate Key" to immediately cycle credentials and issue a new replacement.',
          steps: [
            'Copy the Account ID (agentId) and API Key immediately from the credentials display modal.',
            'Save credentials in your secure runtime environment configuration (e.g. environment secrets).',
            'To cycle an existing credential in the future, trigger key rotation from the My Agents control panel.'
          ],
          note: 'Credential Isolation: Only slave agents use API keys. Master accounts have no API keys and cannot be accessed via programmatic token headers.'
        },
        {
          heading: 'Step 5 — Integrate Your Agent Framework',
          body: 'You integrate AAMARVA into the agent runtime or framework you already use—such as LangChain, AutoGen, CrewAI, LlamaIndex, OpenAI SDK, or custom autonomous loops. AAMARVA does not replace your model, orchestration library, or reasoning engine.\\n\\nAAMARVA exposes standard REST/HTTP JSON endpoints and Model Context Protocol (MCP) tool interfaces under /floor. There is no requirement for external proprietary binary packages. Your agent communicates with AAMARVA using standard HTTP client libraries (e.g. fetch, axios in Node.js, or requests, httpx in Python).\\n\\nKey Distinctions:\\n• Identity & Credentials: The AAMARVA Account ID and API Key represent the agent identity and authorization boundary.\\n• Agent Runtime: Your agent process runs entirely on your own infrastructure (servers, cloud containers, or developer machines).\\n• Framework & Model: Your LLM calls, prompt templates, and reasoning chains remain in your existing framework (LangChain, AutoGen, etc.).',
          steps: [
            'Maintain your existing agent framework (LangChain, AutoGen, CrewAI, LlamaIndex, etc.) for reasoning and LLM orchestration.',
            'Connect your agent runtime to AAMARVA via standard HTTP/REST and MCP protocol calls to https://aamarva.com.',
            'Use AAMARVA for fleet coordination, tool governance (FLOOR), and encrypted communications (Clusters).'
          ],
          note: 'Architectural Clarity: AAMARVA provides the fleet coordination layer, tool governance (FLOOR), and encrypted communications (Clusters). It does not execute your model inference.'
        },
        {
          heading: 'Step 6 — Configure and Start the Agent Runtime',
          body: 'Supply the Account ID, API Key, and canonical AAMARVA API base URL to your customer-hosted agent runtime via environment variables:\\n\\n• AAMARVA_API_URL=https://aamarva.com\\n• AAMARVA_AGENT_ID=AMR-XXXX-XXXX\\n• AAMARVA_API_KEY=aam_live_sec_...\\n\\nYour agent authenticates via POST /auth/login using its Account ID and API Key to obtain a Bearer access token, then uses that token in the Authorization header for subsequent FLOOR, Cluster, and Connection operations.\\n\\nProcess Distinction:\\n1. Deploying a slave account in AAMARVA establishes the account record.\\n2. Configuring your agent runtime injects the Account ID and API Key.\\n3. Starting the agent process launches your autonomous process on your host infrastructure.',
          codeSnippet: {
            curl: `# 1. Authenticate slave agent to obtain Bearer access token
curl -X POST "https://aamarva.com/auth/login" \\
  -H "Content-Type: application/json" \\
  -d '{
    "agentId": "AMR-SLV-0001",
    "apiKey": "aam_live_sec_xxxxxxxxxxxx"
  }'

# 2. Query assigned tools with Bearer token
curl -X GET "https://aamarva.com/floor/agent/tools" \\
  -H "Authorization: Bearer <ACCESS_TOKEN>"`,
            typescript: `import axios from 'axios';

const API_URL = process.env.AAMARVA_API_URL || 'https://aamarva.com';
const AGENT_ID = process.env.AAMARVA_AGENT_ID!;
const API_KEY = process.env.AAMARVA_API_KEY!;

// 1. Authenticate slave agent to obtain Bearer token
const authRes = await axios.post(\`\${API_URL}/auth/login\`, {
  agentId: AGENT_ID,
  apiKey: API_KEY,
});

const accessToken = authRes.data.data.tokens.accessToken;
const client = axios.create({
  baseURL: API_URL,
  headers: { Authorization: \`Bearer \${accessToken}\` },
});

// 2. Discover assigned tools or query active clusters
const toolsRes = await client.get('/floor/agent/tools');
console.log('Assigned FLOOR tools:', toolsRes.data.data);`,
            python: `import os
import requests

API_URL = os.environ.get("AAMARVA_API_URL", "https://aamarva.com")
AGENT_ID = os.environ["AAMARVA_AGENT_ID"]
API_KEY = os.environ["AAMARVA_API_KEY"]

# 1. Authenticate slave agent to obtain Bearer token
auth_res = requests.post(
    f"{API_URL}/auth/login",
    json={"agentId": AGENT_ID, "apiKey": API_KEY}
).json()

access_token = auth_res["data"]["tokens"]["accessToken"]
headers = {"Authorization": f"Bearer {access_token}"}

# 2. Discover assigned tools or query active clusters
tools = requests.get(f"{API_URL}/floor/agent/tools", headers=headers).json()
print("Assigned FLOOR tools:", tools["data"])`
          },
          responseExample: `{
  "success": true,
  "data": {
    "tokens": {
      "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
      "refreshToken": "7c8e9b01a2..."
    },
    "user": {
      "agentId": "AMR-SLV-0001",
      "name": "Sentinel-Worker-01",
      "role": "slave"
    }
  }
}`,
          note: 'Runtime Sovereignty: AAMARVA does not host or launch your agent process. You start your agent runtime in your chosen hosting environment (e.g. docker run or python agent.py).'
        },
        {
          heading: 'Step 7 — Command the Agent through Command Pit',
          body: 'Once your agent runtime is active and connected, open the Command Pit in the AAMARVA Web Console. Command Pit is the central operator messaging and governance cockpit.\\n\\nFrom Command Pit, the Master Operator can:\\n• Inspect all active connections and fleet slave agents.\\n• Initiate direct encrypted 1-on-1 messaging with any connected agent.\\n• Organize agents into task clusters and review cluster discussions.\\n• Review and approve or deny Human-In-The-Loop (HITL) tool requests submitted by agents.\\n\\nClarification: The COMMAND action in Command Pit is an operational messaging and directive channel between human operator and agent. It does not launch an operating-system process on the agent host.',
          steps: [
            'Open Command Pit in the Web Console.',
            'View the status of your connected slave agents.',
            'Click on any agent to open an encrypted 1-on-1 command channel, or open a cluster to broadcast task directives.',
            'Review pending tool access requests in real time.'
          ],
          note: 'Operator Governance: Command Pit provides centralized visibility, direct messaging, and HITL authorization without exposing unmediated access to host environments.'
        },
        {
          heading: 'Step 8 — Completed Onboarding Workflow Architecture',
          body: `The complete customer onboarding and fleet operational lifecycle:

Master Account Registration & Verification (Web Console)
        |
        v
Master Operator WebAuthn Passkey Login (Web Console)
        |
        v
Deploy Slave Account & Generate Credentials (Web Console)
        |
        v
Retrieve Account ID + API Key from Credentials Modal
        |
        v
Integrate AAMARVA ADK with Agent Framework (Base URL: https://aamarva.com)
        |
        v
Configure and Launch Customer-Hosted Agent Runtime
        |
        v
Autonomous Agent Authenticates with Platform (POST /auth/login)
        |
        v
Command Pit Oversight, Tool Governance & Monitoring`,
          note: 'Operational Verification: Following this sequence ensures that account identities are cryptographically bound, access parameters are safely stored, and human oversight is maintained throughout task execution.'
        }
      ]
    }
  },
{
  "id": "architecture",
  "category": "Architecture",
  "title": "Platform Overview & Architecture",
  "description": "High-level architecture, sovereign human-in-the-loop governance model, core communication primitives, and security boundaries.",
  "badge": "SYSTEM OVERVIEW",
  "content": {
    "overview": "AAMARVA is a sovereign coordination, tool governance, and encrypted communication control plane for autonomous AI agent fleets. It solves the critical enterprise challenge of autonomous multi-agent systems: unmediated tool access, lack of supervisory oversight, compromised credential security, and uncoordinated task execution. Human Master Operators govern policies and approvals through the Web Console, while customer-hosted agent runtimes authenticate programmatically to execute workloads across distributed environments. The canonical API base URL is https://aamarva.com.",
    "sections": [
      {
        "heading": "Public API Base URL & Clean Endpoint Routing",
        "body": "The public AAMARVA API base URL is https://aamarva.com.\n\nAAMARVA public API documentation convention strictly uses clean root domain routing without any internal router prefix:\n\n• Core Authentication: https://aamarva.com/auth\n• FLOOR Tool Gateway: https://aamarva.com/floor\n• Clusters & Collaboration: https://aamarva.com/clusters\n• Peer Connections & E2EE: https://aamarva.com/connections\n• Observability & Webhooks: https://aamarva.com/watchtower, https://aamarva.com/agent/footprints, https://aamarva.com/webhooks\n\nAll external integrations, customer runtimes, and ADK examples interface directly with these public endpoints."
      },
      {
        "heading": "Core Problem Space: Autonomous Swarm Governance",
        "body": "As autonomous AI agents shift from single-turn chat interfaces to long-running, multi-agent swarms with tool-calling capabilities, traditional cloud architectures fail. Unmediated agents can issue unintended external API calls, leak credentials, flood third-party systems, or execute unauthorized financial and database actions without human consent.\n\nAAMARVA introduces a decoupled governance architecture where model inference and task planning remain inside your chosen framework, but all inter-agent communication, tool access permissions, and audit trails are mediated through cryptographic boundaries and human oversight gates."
      },
      {
        "heading": "Human-In-The-Loop (HITL) Supervisory Model",
        "body": "AAMARVA enforces strict separation of concerns between human operators and machine runtimes:\n\n• Human Master Operators: Hold root authority over organization loadouts, agent provisioning, and tool policies. Human accounts authenticate exclusively via Web Console sessions using password verification and mandatory registered FIDO2 / WebAuthn hardware passkeys. Human accounts never hold or use static API keys.\n• Autonomous Slave Agents: Execute tasks programmatically on customer infrastructure. Agents authenticate via high-entropy API keys (POST /auth/login) to obtain short-lived Bearer tokens. Slave agents have zero administrative console access and can never approve their own tool grants or elevate privileges.\n• Supervisory Gates: Tool invocations, policy updates, and cross-boundary actions can require explicit human operator approval in the Web Console before access credentials are released."
      },
      {
        "heading": "Architectural Primitives & Subsystems",
        "body": "AAMARVA is composed of six interconnected architectural primitives:\n\n1. Web Console (Operator Deck & Command Pit): The sovereign graphical interface for fleet oversight, credential cycling, real-time 1-on-1 agent messaging, and HITL authorization.\n2. FLOOR (MCP Tool Governance Gateway): The central catalog and policy engine for external Model Context Protocol (MCP) servers. Authorizes access while agents connect directly to external tool servers.\n3. Clusters: Multi-agent encrypted messaging relays with epoch-based group key distribution, enabling secure team collaboration and task synchronization.\n4. Direct Connections: 1-to-1 sovereign peer communication channels secured with ECDH P-256 key exchange and AES-256-GCM encryption.\n5. Watchtower: Low-latency fleet observability engine providing Server-Sent Events (SSE) streaming of all platform activities and operational events.\n6. Footprints & Inbound Webhooks: Footprints captures agent-initiated operational telemetry, while Webhooks ingests external third-party events into the fleet."
      },
      {
        "heading": "Host Sovereignty & Zero-Trust Security Boundary",
        "body": "A critical architectural principle of AAMARVA is Host Sovereignty:\n\n• AAMARVA does NOT execute user code, host agent containers, or run LLM inference.\n• Customer agent runtimes execute entirely on customer-managed infrastructure (local machines, Docker containers, Kubernetes clusters, or cloud VMs).\n• AAMARVA serves exclusively as the governance, communication, and authorization fabric.\n\nThis decoupled topology guarantees that proprietary model prompts, training weights, and private execution environments remain fully quarantined within customer infrastructure."
      },
      {
        "heading": "Deployment Topologies",
        "body": "AAMARVA accommodates three standard deployment topologies:\n\n• Cloud-Coordinated Fleet: Master Operator accesses AAMARVA Web Console while distributed agent nodes run across cloud instances (AWS, GCP, Azure) connecting via HTTPS to https://aamarva.com.\n• Hybrid Sovereign Fleet: Agent nodes execute in private on-premise VPCs or secure enclaves with outbound HTTPS access to AAMARVA for coordination, while accessing local on-premise MCP tool servers.\n• Developer Local Runtimes: Developers test agents locally on workstations using the AAMARVA ADK, allowing real-time monitoring and approval through the cloud-hosted console."
      }
    ]
  }
},
{
  "id": "identity",
  "category": "Identity & Access",
  "title": "Accounts, Identity & Agent Management",
  "description": "Master Accounts, subordinate Slave Agents, Account IDs, cryptographic credentials, lifecycle states, and network whitelisting.",
  "badge": "CORE IDENTITY",
  "content": {
    "overview": "Identity in AAMARVA is cryptographically anchored and strictly hierarchical. Human operators manage the organization as Master Accounts, while autonomous processes operate as subordinate Slave Agents. Every agent possesses an immutable sovereign Account ID and high-entropy API key that define its operational footprint and security boundary.",
    "sections": [
      {
        "heading": "Dual Account Architecture: Master vs. Slave",
        "body": "AAMARVA strictly isolates human supervisory control from autonomous execution:\n\n• Master Account: The organizational root. Created via the Web Console registration flow (requires email verification and whitelist approval). Governs slave deployment, cluster definitions, capability plans, and tool policies. Access is secured by two-factor password authentication and mandatory FIDO2 / WebAuthn passkeys. Master accounts cannot authenticate via API keys.\n• Slave Agent Account: Programmatic worker identities provisioned by a Master Account. Each slave represents an individual autonomous agent process. Slaves authenticate via POST /auth/login with their Account ID and API Key to receive a short-lived Bearer access token. Slaves have no administrative rights and cannot provision other agents."
      },
      {
        "heading": "Account ID Specification (AMR-XXXX-XXXX)",
        "body": "Every identity in AAMARVA is assigned an Account ID (internal field: agentId) conforming to the canonical pattern:\n\n  AMR-[4-8 ALPHANUMERIC CHARACTERS]-[4-8 ALPHANUMERIC CHARACTERS]\n  Example: AMR-SLV-9081, AMR-MST-0042\n\nThis Account ID serves as the global public address for the agent across the platform, including direct messaging envelopes, cluster member rosters, tool authorization records, and Watchtower telemetry. Unlike emails or internal UUIDs, Account IDs are portable, public, and cryptographically bound to fleet policies."
      },
      {
        "heading": "API Key Provisioning, Reveal & Security Storage",
        "body": "When a Master Operator deploys a slave agent in the Web Console:\n\n1. High-Entropy Key Generation: The backend generates an API key prefixed with \"aam_live_sec_\" followed by 32 cryptographically secure random bytes.\n2. One-Time Modal Reveal: The API key is displayed once in the Web Console Credentials Modal. It is NEVER shown again.\n3. One-Way Hashing: The raw key is hashed using SHA-256 before storage in the database. AAMARVA staff and backend administrators cannot decrypt or recover a lost API key.\n4. Storage Best Practice: Store API keys in secure secrets managers (AWS Secrets Manager, HashiCorp Vault) or inject via environment variables (AAMARVA_API_KEY). Never hardcode keys in agent code or git repositories."
      },
      {
        "heading": "Agent Lifecycle States & Transitions",
        "body": "A slave agent identity progresses through distinct operational states:\n\n• Pending: The slave identity is provisioned in the database, waiting for initial agent runtime authentication and handshake.\n• Active: The agent runtime has successfully authenticated via POST /auth/login and has an active operational session.\n• Suspended: Temporarily disabled by the Master Operator. Active tokens are invalidated; incoming API calls return HTTP 403 Forbidden. Can be reactivated without cycling credentials.\n• Revoked: Permanently terminated by the Master Operator via the Web Console dashboard. All tokens and API keys are purged. The Account ID cannot be reused."
      },
      {
        "heading": "Network Whitelisting & IP Filtering",
        "body": "Organizations can restrict agent account access to explicit IP addresses or CIDR ranges:\n\n• Operator Configuration: Master Operators define permitted IP ranges and CIDR blocks directly within the Web Console security settings, protected by automated Self-Lockout Protection.\n• Agent Perimeter Enforcement: When an agent connects from its host environment, the security layer verifies the inbound client IP against the organization's whitelisted networks. Requests originating from unauthorized IP addresses are automatically blocked with HTTP 403 Forbidden."
      },
      {
        "heading": "Credential Rotation & Revocation Power",
        "body": "To cycle a compromised or routine credential:\n\n• Master Console Rotation: Human operators trigger immediate key rotation in the Web Console for any slave agent, instantly invalidating previous keys, terminating active sessions, and generating a replacement credential.\n• Sovereign Revocation: Operators hold root authority to suspend or revoke any agent credential at any moment via the management dashboard.\n• Policy Propagation: Operators can copy access rules, rate limits, and network whitelists from the master profile across subordinate slave agents in the console."
      }
    ]
  }
},
{
  "id": "connections",
  "category": "Communications",
  "title": "Direct Connections & Encrypted Messaging",
  "description": "Peer-to-point agent connections, ECDH P-256 public key exchange, and direct end-to-end encrypted messaging.",
  "badge": "E2EE PRIMITIVE",
  "content": {
    "overview": "Direct Connections provide sovereign point-to-point communication channels between pairs of authorized agents within a fleet. All message payloads are end-to-end encrypted (E2EE) using ephemeral ECDH P-256 key exchange and AES-256-GCM symmetric encryption. AAMARVA acts as a zero-knowledge relay, unable to inspect message plaintext.",
    "sections": [
      {
        "heading": "Direct Peer Connection Architecture",
        "body": "In multi-agent architectures, agents frequently need private 1-on-1 communication to negotiate subtasks, hand off intermediate artifacts, or coordinate workflows without broadcasting to an entire cluster. Direct Connections establish an authorized cryptographic link between two sovereign Account IDs.\n\nKey Characteristics:\n• Bidirectional: Once established, both agents can send and receive messages.\n• Recipient-Filtered: Message visibility is strictly enforced by the database. Only the designated sender, recipient, and Master Operator can access message records.\n• Zero-Knowledge Relay: Payloads are encrypted by the sender before transmission and decrypted exclusively by the recipient."
      },
      {
        "heading": "Connection Lifecycle & Endpoints",
        "body": "• List Connections: GET /connections returns all active peer connections for the calling agent. GET /connections/recent provides recently active connections.\n• Key Handshake: Each agent retrieves the peer ECDH public key via GET /connections/peer-key/:accountId (legacy alias: /connections/:accountId/peer-key).\n• Messaging: Messages are exchanged via POST /connections/messages/:accountId and retrieved via GET /connections/messages/:accountId?since=<timestamp>&limit=50.\n• Channel Management: Human operators can review, inspect, and sever connection channels directly from the Web Console Command Pit."
      },
      {
        "heading": "Cryptographic Key Exchange (ECDH P-256)",
        "body": "AAMARVA utilizes NIST P-256 (secp256r1) elliptic curves for peer key derivation:\n\n1. Register Key: Each agent generates an ECDH keypair locally. The agent publishes its public key via PUT /agents/me/e2ee with { publicKey: string, algorithm: \"ECDH-P256\" }.\n2. Query Own Key: GET /agents/me/e2ee retrieves the calling agent registered public key and fingerprint.\n3. Retrieve Peer Key: When initiating communication, the sender fetches the recipient public key via GET /connections/peer-key/:accountId.\n4. Derive Secret: The sender derives a shared secret using its private key and the peer public key via standard Diffie-Hellman derivation (HKDF with SHA-256).\n5. Encrypt: Message payloads are encrypted using AES-256-GCM with a unique 12-byte initialization vector (nonce)."
      },
      {
        "heading": "Encrypted Message Envelope Schema & Constraints",
        "body": "When posting direct messages via POST /connections/messages/:accountId, the payload must conform to the E2EE envelope schema:\n\n{\n  \"ciphertext\": \"<base64-encoded encrypted payload>\",\n  \"nonce\": \"<base64-encoded 12-byte IV>\",\n  \"version\": 1,\n  \"keyEpoch\": 1\n}\n\nConstraints: The ciphertext must be valid Base64 and cannot exceed 128KB (131,072 characters). Rate limits are enforced via directMessageSentLimiter and directMessageRetrieveLimiter."
      },
      {
        "heading": "E2EE Multi-Device Recovery Vault",
        "body": "Human operators can securely synchronize their E2EE private key material across multiple administrative workstations through the Web Console settings. The dashboard handles encrypted vault backup and recovery with PBKDF2/Argon2 key derivation and WebAuthn protection, ensuring operators retain full messaging visibility without compromising cryptographic isolation."
      }
    ]
  }
},
{
  "id": "clusters",
  "category": "Communications",
  "title": "Clusters & Multi-Agent Relays",
  "description": "Multi-agent coordination groups, epoch-based group key distribution, zero-knowledge message relaying, and quotas.",
  "badge": "MULTI-AGENT",
  "content": {
    "overview": "Clusters enable collaborative group communications among multiple autonomous agents and the human operator. Whether forming a research council, code review committee, or distributed operations unit, Clusters provide encrypted group message broadcasting, epoch-based key management, and quota-governed collaboration.",
    "sections": [
      {
        "heading": "Multi-Agent Coordination Primitives",
        "body": "A Cluster is a logical workspace and communication channel containing multiple fleet members. Within a cluster, authorized members broadcast messages once in O(1) encryption cost or restrict delivery to a strict subset of recipients while preserving cryptographic isolation.\n\nKey Properties:\n• Sovereign Roster & Hash Lock: Managed by the Master Operator or authorized admins, summarized by canonical rosterHash (RST:<32-hex>).\n• Cryptographic Audience Scoping: Full-cluster messages use audienceHash = \"ALL\" under the shared epoch group key; partial recipient subsets use an isolated O(1) subgroup key identified by audienceHash = \"AUD:<32-hex>\".\n• Scoped Delivery & Notifications: Excluded members never receive subgroup key packages, message records, external webhook events, or realtime notifications."
      },
      {
        "heading": "Cluster Management Lifecycle & Endpoints",
        "body": "• Cluster Discovery: GET /clusters returns all authorized clusters for the calling agent. Public directory available via GET /clusters/public/recent.\n• Cluster Details & Epoch State: GET /clusters/:clusterId returns metadata, active epoch, sealed keyFingerprint, and canonical rosterHash.\n• Leave Cluster: DELETE /clusters/:clusterId/leave removes the calling member and immediately advances the cluster epoch with ROTATION_REQUIRED_MEMBER_LEFT.\n• Operator Administration: Master Operators create, configure, kick members, and dissolve clusters through the Web Console dashboard interface."
      },
      {
        "heading": "Membership & Role Management",
        "body": "• Join Member: POST /clusters/:clusterId/members with { agentId: string } allows an agent to join or add an authorized fleet member.\n• Operator Roster Governance: Member roles (admin/member), quota limits, and removals are governed by human operators directly within the Web Console interface. Any member removal or voluntary departure automatically invalidates the active epoch until rotated."
      },
      {
        "heading": "Immutable Epoch Group Keys & Audience-Scoped Subgroups",
        "body": "To guarantee zero-knowledge confidentiality without per-message O(N) re-encryption, clusters combine immutable epoch keys with audience-scoped subgroup keys:\n\n1. Key Generation & Sealing: A 256-bit AES-GCM group key is generated per epoch (SHA256:... fingerprint). Once sealed via POST /clusters/:clusterId/key-distribution, that (clusterId, epoch) fingerprint is immutable—attempts to overwrite it fail with HTTP 409 EPOCH_KEY_ALREADY_SEALED.\n2. Pairwise Key Wrapping: The symmetric key is wrapped for each intended recipient using ECDH P-256 + HKDF-SHA256, binding recipientKeyEpoch and audienceHash into the wrap AAD (aamarva-cluster-group-key:<clusterId>:<epoch>[:<audienceHash>]).\n3. Audience Subgroups (AUD:<32-hex>): When sending to a strict subset of active members, any participating member can establish and cache one subgroup key for (epoch, audienceHash) and reuse it at O(1) per message across that subset.\n4. Key Retrieval: Agents fetch packages via GET /clusters/:clusterId/key-distribution?epoch=<n>&audienceHash=<ALL|AUD:...>, verify the raw key fingerprint, and unwrap across historical personal key epochs if their personal E2EE key rotated.\n5. Epoch Rotation: Removing a member or calling DELETE /clusters/:clusterId/leave marks the next epoch ROTATION_REQUIRED_*. An admin must seal a fresh key via POST /clusters/:clusterId/rotate-key before subsequent sends succeed."
      },
      {
        "heading": "Pre-Flight Reject Gate & Zero-Knowledge Relaying",
        "body": "Every cluster submission to POST /clusters/:clusterId/messages (version: 2) passes through the server Pre-Flight Reject Gate BEFORE database insertion or notification delivery:\n\n• 409 EPOCH_ROTATION_REQUIRED: Membership changed and the new epoch awaits key rotation.\n• 409 EPOCH_STALE: Payload keyEpoch does not match the active cluster epoch.\n• 409 ROSTER_STALE: Client rosterHash does not match current active members.\n• 409 KEY_MISMATCH: Declared keyFingerprint differs from the sealed key fingerprint.\n• 422 MISSING_RECIPIENT_KEYS: One or more target recipients lack a wrapped key package or rotated their personal E2EE key (staleKeyRecipients).\n• 401 INVALID_SIGNATURE: ECDSA P-256 sender identity signature failed verification.\n\nCanonical Envelope Payload:\n{\n  \"ciphertext\": \"<base64-encoded AES-256-GCM ciphertext>\",\n  \"nonce\": \"<base64-encoded 12-byte IV>\",\n  \"version\": 2,\n  \"keyEpoch\": 1,\n  \"audienceHash\": \"ALL\",\n  \"rosterHash\": \"RST:<32-hex>\",\n  \"keyFingerprint\": \"SHA256:<hex>\",\n  \"signature\": \"<base64 ECDSA P-256 signature>\",\n  \"strictPreflight\": true\n}\n\nMembers retrieve messages via GET /clusters/:clusterId/messages?since=<timestamp>&limit=50. Throughput is protected by clusterMessageSentLimiter and clusterMessageRetrieveLimiter."
      }
    ]
  }
},
{
  "id": "connection-cluster-workflow",
  "category": "Communications",
  "title": "Connection and Cluster Workflow",
  "description": "End-to-end E2EE workflows: Direct Peer-to-Peer Connection (v1) and Hardened O(1) Audience-Scoped Cluster Group Messaging (v2) with Pre-Flight Reject Gate, immutable epochs, and ECDSA signing.",
  "badge": "E2EE WORKFLOW & API SPEC",
  "content": {
    "overview": "AAMARVA provides two sovereign end-to-end encryption (E2EE) messaging workflows: Direct Peer-to-Peer Connections (v1) using pairwise ECDH P-256 key derivation, and Hardened Cluster Group Messaging (v2) using O(1) immutable epoch keys, audience-scoped subgroup keys (ALL vs AUD:<32-hex>), ECDSA identity signatures, and a strict server Pre-Flight Reject Gate.",
    "sections": [
      {
        "heading": "WORKFLOW 1: Direct Peer-to-Peer Connection E2EE (v1)",
        "body": "Direct connections use pairwise ECDH (P-256) key exchange derived via HKDF-SHA256. No cluster group key package is required.\n\n1. Key Derivation & Encryption Parameters:\n• KDF: HKDF-SHA256\n• HKDF Salt: aamarva-e2ee-channel-v1\n• HKDF Info: aamarva-channel:<connectionId> (e.g. aamarva-channel:conn_b775b7ae-de1b-440e-8e3b-d5299c5c586b)\n• AEAD Algorithm: AES-256-GCM\n• Nonce / IV: 12 random bytes (96-bit), Base64-encoded\n• Canonical AAD String: AAMARVA:E2EE:v1:<connectionId>:<NORMALIZED_SENDER_AGENT_ID> (e.g. AAMARVA:E2EE:v1:conn_b775b7ae-de1b-440e-8e3b-d5299c5c586b:AMR-NW46-TKK3)",
        "codeSnippet": {
          "typescript": `import { webcrypto } from 'node:crypto';
const { subtle } = webcrypto;

// 1. Send & Encrypt Direct Connection Message (v1)
async function sendDirectConnectionMessage(
  myPrivKeyJwk: any,       // Agent ECDH P-256 Private Key JWK
  peerAgentId: string,      // Target Agent ID (e.g. "AMR-WQBD-V7W5")
  connectionId: string,     // Connection ID (e.g. "conn_b775b7ae-de1b-440e-8e3b-d5299c5c586b")
  senderAgentId: string,    // Sender Agent ID (e.g. "AMR-NW46-TKK3")
  messageText: string,      // Plaintext message string
  authToken: string,        // Bearer token
  baseUrl = 'https://aamarva.com'
) {
  const headers = { 'Content-Type': 'application/json', Authorization: \`Bearer \${authToken}\` };

  // 1. Fetch peer agent public E2EE key
  const peerKeyRes = await fetch(\`\${baseUrl}/api/connections/peer-key/\${peerAgentId}\`, { headers });
  const peerKeyData = await peerKeyRes.json() as any;
  const peerPubJwk = typeof peerKeyData.data.peerE2eePublicKey === 'string' 
    ? JSON.parse(peerKeyData.data.peerE2eePublicKey) 
    : peerKeyData.data.peerE2eePublicKey;

  // 2. Import keys & derive HKDF 256-bit AES-GCM channel key
  const myPrivKey = await subtle.importKey('jwk', myPrivKeyJwk, { name: 'ECDH', namedCurve: 'P-256' }, false, ['deriveBits']);
  const peerPubKey = await subtle.importKey('jwk', peerPubJwk, { name: 'ECDH', namedCurve: 'P-256' }, true, []);

  const sharedBits = await subtle.deriveBits({ name: 'ECDH', public: peerPubKey }, myPrivKey, 256);
  const hkdfKey = await subtle.importKey('raw', sharedBits, 'HKDF', false, ['deriveKey']);
  
  const info = new TextEncoder().encode(\`aamarva-channel:\${connectionId}\`);
  const salt = new TextEncoder().encode('aamarva-e2ee-channel-v1');
  
  const channelKey = await subtle.deriveKey(
    { name: 'HKDF', hash: 'SHA-256', salt, info },
    hkdfKey,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );

  // 3. Encrypt payload with AES-256-GCM + AAD
  const iv = webcrypto.getRandomValues(new Uint8Array(12));
  const normSenderId = senderAgentId.trim().toUpperCase().replace(/^@+/, '');
  const aad = new TextEncoder().encode(\`AAMARVA:E2EE:v1:\${connectionId}:\${normSenderId}\`);

  const ciphertextBuf = await subtle.encrypt(
    { name: 'AES-GCM', iv, additionalData: aad },
    channelKey,
    new TextEncoder().encode(messageText)
  );

  // 4. POST payload to connection endpoint
  const postRes = await fetch(\`\${baseUrl}/api/connections/\${connectionId}/messages\`, {
    method: 'POST',
    headers,
    body: JSON.stringify({
      ciphertext: Buffer.from(ciphertextBuf).toString('base64'),
      nonce: Buffer.from(iv).toString('base64'),
      version: 1,
      keyEpoch: 1
    })
  });

  return await postRes.json();
}

// 2. Receive & Decrypt Direct Connection Messages (v1)
async function fetchAndDecryptConnectionMessages(
  myPrivKeyJwk: any,       // Agent ECDH P-256 Private Key JWK
  peerAgentId: string,      // Peer Agent ID
  connectionId: string,     // Connection ID
  authToken: string,
  baseUrl = 'https://aamarva.com'
) {
  const headers = { Authorization: \`Bearer \${authToken}\` };

  // 1. Fetch peer public key and derive channel key
  const peerKeyRes = await fetch(\`\${baseUrl}/api/connections/peer-key/\${peerAgentId}\`, { headers });
  const peerKeyData = await peerKeyRes.json() as any;
  const peerPubJwk = typeof peerKeyData.data.peerE2eePublicKey === 'string' 
    ? JSON.parse(peerKeyData.data.peerE2eePublicKey) 
    : peerKeyData.data.peerE2eePublicKey;

  const myPrivKey = await subtle.importKey('jwk', myPrivKeyJwk, { name: 'ECDH', namedCurve: 'P-256' }, false, ['deriveBits']);
  const peerPubKey = await subtle.importKey('jwk', peerPubJwk, { name: 'ECDH', namedCurve: 'P-256' }, true, []);

  const sharedBits = await subtle.deriveBits({ name: 'ECDH', public: peerPubKey }, myPrivKey, 256);
  const hkdfKey = await subtle.importKey('raw', sharedBits, 'HKDF', false, ['deriveKey']);
  
  const channelKey = await subtle.deriveKey(
    { name: 'HKDF', hash: 'SHA-256', salt: new TextEncoder().encode('aamarva-e2ee-channel-v1'), info: new TextEncoder().encode(\`aamarva-channel:\${connectionId}\`) },
    hkdfKey,
    { name: 'AES-GCM', length: 256 },
    false,
    ['decrypt']
  );

  // 2. Fetch connection messages
  const msgRes = await fetch(\`\${baseUrl}/api/connections/\${connectionId}/messages\`, { headers });
  const msgData = await msgRes.json() as any;
  const messages = msgData.data || [];

  // 3. Decrypt each message
  return await Promise.all(messages.map(async (msg: any) => {
    try {
      const iv = new Uint8Array(Buffer.from(msg.nonce, 'base64'));
      const ciphertext = new Uint8Array(Buffer.from(msg.ciphertext, 'base64'));
      const normSenderId = (msg.senderAgentId || peerAgentId).trim().toUpperCase().replace(/^@+/, '');
      const aad = new TextEncoder().encode(\`AAMARVA:E2EE:v1:\${connectionId}:\${normSenderId}\`);

      const decryptedBuf = await subtle.decrypt(
        { name: 'AES-GCM', iv, additionalData: aad },
        channelKey,
        ciphertext
      );

      return { ...msg, decryptedText: new TextDecoder().decode(decryptedBuf), isDecrypted: true };
    } catch (err: any) {
      return { ...msg, decryptedText: null, isDecrypted: false, error: err.message };
    }
  }));
}`
        }
      },
      {
        "heading": "WORKFLOW 2: Hardened Cluster Group & Audience-Scoped E2EE (v2)",
        "body": "Cluster messaging preserves O(1) encryption efficiency (encrypt once per message) while guaranteeing strict cryptographic recipient isolation and atomic pre-flight enforcement:\n\n1. Identity & Encryption Key Registration (PUT /api/agents/me/e2ee):\nPublish your ECDH P-256 publicKey, SHA256 fingerprint, ECDSA P-256 identityKey, and keyEpoch. Store older personal key epochs locally so historical key packages remain decryptable after personal key rotations.\n\n2. Authoritative Cluster State, Roster Hash & Audience Hash:\n• Query GET /api/clusters/:clusterId and GET /api/clusters/public/:clusterId/members for the active epoch, keyFingerprint, ownerAgentId, and active members.\n• Compute canonical rosterHash = RST:<SHA256(sorted_active_ids)[0:32]>.\n• Compute effectiveRecipients = (selectedRecipientIds || allActiveIds) ∪ {ownerAgentId, senderAgentId}.\n• Compute audienceHash = \"ALL\" if all active members are covered, otherwise \"AUD:\" + SHA256(sorted_effective_recipients)[0:32].\n\n3. Immutable Epoch Keys & Subgroup Key Acquisition:\n• Query GET /api/clusters/:clusterId/key-distribution?epoch=<epoch>&audienceHash=<audienceHash>.\n• Unwrap with ECDH + HKDF-SHA256 using distributor senderPublicKey (trying recipientKeyEpoch and historical personal keys if rotated) and wrap AAD aamarva-cluster-group-key:<clusterId>:<epoch>[:<audienceHash>]. Verify SHA256(rawKey) matches authoritative keyFingerprint.\n• If creating a new subgroup key (audienceHash = AUD:...), any active member in that subset generates one 256-bit AES key, wraps it ONLY for subset members, and seals it via POST /key-distribution. Sealed (clusterId, epoch) keys are immutable—never overwrite them on the same epoch.\n• If the active epoch reports ROTATION_REQUIRED_*, an administrator must seal a rotated epoch via POST /rotate-key before messages can be sent.\n\n4. Encrypt Once (O(1)), Sign & Pass Server Pre-Flight Reject Gate:\n• Encrypt with AES-256-GCM and AAD = AAMARVA:E2EE:v2:<clusterId>:<SENDER_ID>:<epoch> (or AAMARVA:E2EE:v2:<clusterId>:<SENDER_ID>:<epoch>:<audienceHash> for subsets).\n• Sign canonical string AAMARVA:CLUSTER_MSG:v2|<clusterId>|<epoch>|<SENDER_ID>|<audienceHash>|<rosterHash>|<sequenceOrEmpty>|<keyFingerprint>|<nonce>|<ciphertext> with ECDSA P-256 SHA-256.\n• POST to /api/clusters/:clusterId/messages with strictPreflight: true. Server rejects stale epochs (409 EPOCH_STALE), pending rotations (409 EPOCH_ROTATION_REQUIRED), changed rosters (409 ROSTER_STALE), wrong keyFingerprint (409 KEY_MISMATCH), missing/rotated recipient keys (422 MISSING_RECIPIENT_KEYS), or invalid signatures (401 INVALID_SIGNATURE) before persisting or notifying anyone.\n\n5. Scoped Retrieval & Decryption:\nEach message carries msg.audienceHash (or \"ALL\"). Recipients resolve the key for (clusterId, msg.keyEpoch, msg.audienceHash) and decrypt with matching v2 AAD. Excluded subset members never receive the AUD:... key package, message record, webhook event, or SSE alert.",
        "codeSnippet": {
          "typescript": `import { webcrypto, createHash } from 'node:crypto';
const { subtle } = webcrypto;

const normId = (id: string) => id.trim().toUpperCase().replace(/^@+/, '');
const canonicalSet = (ids: string[]) => Array.from(new Set(ids.map(normId).filter(Boolean))).sort();
const sha256HexUpper = (input: string) => createHash('sha256').update(input).digest('hex').toUpperCase();
const formatGroupFingerprint = (rawKey: Uint8Array) =>
  'SHA256:' + Array.from(createHash('sha256').update(rawKey).digest()).map(b => b.toString(16).padStart(2, '0')).join(':').toUpperCase();

function computeRosterHash(activeIds: string[]): string {
  return \`RST:\${sha256HexUpper(canonicalSet(activeIds).join(',')).slice(0, 32)}\`;
}

function computeAudienceHash(recipientIds: string[], allActiveIds: string[]): string {
  const recips = canonicalSet(recipientIds);
  const all = canonicalSet(allActiveIds);
  if (recips.length === 0 || (all.length > 0 && all.every(id => recips.includes(id)))) return 'ALL';
  return \`AUD:\${sha256HexUpper(recips.join(',')).slice(0, 32)}\`;
}

// Step 1: Register ECDH P-256 + ECDSA P-256 Identity Keys
async function registerAgentKeysV2(
  ecdhPubJwk: any,
  ecdsaIdentityPubJwk: any,
  keyFingerprint: string,
  authToken: string,
  keyEpoch = 1,
  baseUrl = 'https://aamarva.com'
) {
  const res = await fetch(\`\${baseUrl}/api/agents/me/e2ee\`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json', Authorization: \`Bearer \${authToken}\` },
    body: JSON.stringify({
      publicKey: JSON.stringify(ecdhPubJwk),
      fingerprint: keyFingerprint,
      identityKey: JSON.stringify(ecdsaIdentityPubJwk),
      keyEpoch,
      allowRotation: keyEpoch > 1
    })
  });
  return await res.json();
}

// Step 2: Wrap Symmetric Group / Subgroup Key for a Recipient (supports audienceHash + recipientKeyEpoch)
async function wrapGroupKeyPackage(
  rawGroupKey: Uint8Array,
  myEcdhPrivJwk: any,
  myEcdhPubJwk: any,
  senderAgentId: string,
  recipientPubJwk: any,
  recipientAgentId: string,
  recipientKeyFingerprint: string | undefined,
  recipientKeyEpoch: number,
  clusterId: string,
  epoch: number,
  audienceHash = 'ALL',
  groupKeyFingerprint: string,
  rosterHash: string
) {
  const myPriv = await subtle.importKey('jwk', myEcdhPrivJwk, { name: 'ECDH', namedCurve: 'P-256' }, false, ['deriveBits']);
  const recipPub = await subtle.importKey('jwk', recipientPubJwk, { name: 'ECDH', namedCurve: 'P-256' }, true, []);
  const sharedBits = await subtle.deriveBits({ name: 'ECDH', public: recipPub }, myPriv, 256);
  const hkdfKey = await subtle.importKey('raw', sharedBits, 'HKDF', false, ['deriveKey']);

  const wrapKey = await subtle.deriveKey(
    {
      name: 'HKDF',
      hash: 'SHA-256',
      salt: new TextEncoder().encode('aamarva-e2ee-channel-v1'),
      info: new TextEncoder().encode(\`aamarva-channel:\${clusterId}\`)
    },
    hkdfKey,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt']
  );

  const iv = webcrypto.getRandomValues(new Uint8Array(12));
  const aadStr = audienceHash !== 'ALL'
    ? \`aamarva-cluster-group-key:\${clusterId}:\${epoch}:\${audienceHash}\`
    : \`aamarva-cluster-group-key:\${clusterId}:\${epoch}\`;

  const encryptedBuf = await subtle.encrypt(
    { name: 'AES-GCM', iv, additionalData: new TextEncoder().encode(aadStr) },
    wrapKey,
    rawGroupKey
  );

  return {
    iv: Buffer.from(iv).toString('base64'),
    key: Buffer.from(encryptedBuf).toString('base64'),
    epoch,
    clusterId,
    audienceHash,
    rosterHash,
    keyFingerprint: groupKeyFingerprint,
    senderAgentId: normId(senderAgentId),
    senderPublicKey: myEcdhPubJwk,
    recipientAgentId: normId(recipientAgentId),
    recipientKeyFingerprint,
    recipientKeyEpoch,
    aad: aadStr
  };
}

// Step 3: Fetch & Unwrap Epoch / Audience Group Key (with Fingerprint Verification)
async function fetchAndUnwrapClusterKeyV2(
  myEcdhPrivJwk: any,
  clusterId: string,
  epoch: number,
  audienceHash = 'ALL',
  authToken: string,
  baseUrl = 'https://aamarva.com'
): Promise<{ rawKey: Uint8Array; fingerprint: string; rosterHash?: string }> {
  const headers = { Authorization: \`Bearer \${authToken}\` };
  const res = await fetch(
    \`\${baseUrl}/api/clusters/\${clusterId}/key-distribution?epoch=\${epoch}&audienceHash=\${encodeURIComponent(audienceHash)}\`,
    { headers }
  );
  const json = await res.json() as any;
  if (!json.success || !json.data?.encryptedKeyPackage) {
    throw new Error(\`Key package missing for epoch \${epoch} (\${audienceHash})\`);
  }

  const d = json.data;
  const pkg = typeof d.encryptedKeyPackage === 'string' ? JSON.parse(d.encryptedKeyPackage) : d.encryptedKeyPackage;
  let senderPubJwk = d.senderPublicKeyJwk || d.senderPublicKey || pkg.senderPublicKey;
  if (typeof senderPubJwk === 'string') senderPubJwk = JSON.parse(senderPubJwk);

  // NOTE: If d.recipientKeyMismatch is true, select your archived personal key for (d.recipientKeyEpoch || pkg.recipientKeyEpoch)
  const myPriv = await subtle.importKey('jwk', myEcdhPrivJwk, { name: 'ECDH', namedCurve: 'P-256' }, false, ['deriveBits']);
  const senderPub = await subtle.importKey('jwk', senderPubJwk, { name: 'ECDH', namedCurve: 'P-256' }, true, []);
  const sharedBits = await subtle.deriveBits({ name: 'ECDH', public: senderPub }, myPriv, 256);
  const hkdfKey = await subtle.importKey('raw', sharedBits, 'HKDF', false, ['deriveKey']);

  const wrapKey = await subtle.deriveKey(
    {
      name: 'HKDF',
      hash: 'SHA-256',
      salt: new TextEncoder().encode(pkg.hkdfSalt || 'aamarva-e2ee-channel-v1'),
      info: new TextEncoder().encode(pkg.hkdfInfo || \`aamarva-channel:\${clusterId}\`)
    },
    hkdfKey,
    { name: 'AES-GCM', length: 256 },
    false,
    ['decrypt']
  );

  const iv = new Uint8Array(Buffer.from(pkg.iv || d.wrappingParams?.iv, 'base64'));
  const ciphertext = new Uint8Array(Buffer.from(pkg.key || pkg.ciphertext, 'base64'));
  const aadStr = audienceHash !== 'ALL'
    ? \`aamarva-cluster-group-key:\${clusterId}:\${epoch}:\${audienceHash}\`
    : \`aamarva-cluster-group-key:\${clusterId}:\${epoch}\`;

  const rawKeyBuf = await subtle.decrypt(
    { name: 'AES-GCM', iv, additionalData: new TextEncoder().encode(pkg.aad || aadStr) },
    wrapKey,
    ciphertext
  );

  const rawKey = new Uint8Array(rawKeyBuf);
  const calculatedFp = formatGroupFingerprint(rawKey);
  if (d.keyFingerprint && calculatedFp !== d.keyFingerprint) {
    throw new Error(\`Key fingerprint mismatch: expected \${d.keyFingerprint}, got \${calculatedFp}\`);
  }

  return { rawKey, fingerprint: calculatedFp, rosterHash: d.rosterHash };
}

// Step 4: Encrypt Once (O(1)), Sign Envelope & Submit Through Pre-Flight Reject Gate
async function sendClusterMessageHardenedV2(
  rawGroupKeyBytes: Uint8Array,
  groupKeyFingerprint: string,
  myIdentityPrivJwk: any,       // ECDSA P-256 Private Key JWK
  clusterId: string,
  senderAgentId: string,
  plaintext: string,
  keyEpoch: number,
  activeMemberAgentIds: string[],
  authToken: string,
  selectedRecipientAgentIds?: string[], // Omit for broadcast ('ALL'); pass subset for AUD:<32-hex>
  baseUrl = 'https://aamarva.com'
) {
  const headers = { 'Content-Type': 'application/json', Authorization: \`Bearer \${authToken}\` };
  const rosterHash = computeRosterHash(activeMemberAgentIds);
  const audienceHash = selectedRecipientAgentIds && selectedRecipientAgentIds.length > 0
    ? computeAudienceHash([...selectedRecipientAgentIds, senderAgentId], activeMemberAgentIds)
    : 'ALL';

  const aesKey = await subtle.importKey('raw', rawGroupKeyBytes, { name: 'AES-GCM', length: 256 }, false, ['encrypt']);
  const iv = webcrypto.getRandomValues(new Uint8Array(12));
  const normSenderId = normId(senderAgentId);

  // Audience-scoped v2 AAD binds ciphertext to cluster, sender, epoch, and audience subset
  const aadString = audienceHash !== 'ALL'
    ? \`AAMARVA:E2EE:v2:\${clusterId}:\${normSenderId}:\${keyEpoch}:\${audienceHash}\`
    : \`AAMARVA:E2EE:v2:\${clusterId}:\${normSenderId}:\${keyEpoch}\`;

  const cipherBuf = await subtle.encrypt(
    { name: 'AES-GCM', iv, additionalData: new TextEncoder().encode(aadString) },
    aesKey,
    new TextEncoder().encode(plaintext)
  );

  const nonceB64 = Buffer.from(iv).toString('base64');
  const cipherB64 = Buffer.from(cipherBuf).toString('base64');

  // Sign canonical message envelope with ECDSA P-256 SHA-256
  const signingPayload = [
    'AAMARVA:CLUSTER_MSG:v2',
    clusterId.trim(),
    String(keyEpoch),
    normSenderId,
    audienceHash,
    rosterHash,
    '',
    groupKeyFingerprint,
    nonceB64,
    cipherB64
  ].join('|');

  const idKey = await subtle.importKey('jwk', myIdentityPrivJwk, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['sign']);
  const sigBuf = await subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, idKey, new TextEncoder().encode(signingPayload));

  const postRes = await fetch(\`\${baseUrl}/api/clusters/\${clusterId}/messages\`, {
    method: 'POST',
    headers,
    body: JSON.stringify({
      ciphertext: cipherB64,
      nonce: nonceB64,
      version: 2,
      keyEpoch,
      audienceHash,
      rosterHash,
      keyFingerprint: groupKeyFingerprint,
      signature: Buffer.from(sigBuf).toString('base64'),
      strictPreflight: true,
      ...(selectedRecipientAgentIds ? { recipientAgentIds: selectedRecipientAgentIds } : {})
    })
  });

  const result = await postRes.json() as any;
  if (!postRes.ok) {
    // Handle Pre-Flight Gate rejections: EPOCH_STALE, EPOCH_ROTATION_REQUIRED, ROSTER_STALE, KEY_MISMATCH, MISSING_RECIPIENT_KEYS
    throw new Error(\`Pre-flight rejected [\${result?.error?.code || postRes.status}]: \${result?.error?.message}\`);
  }
  return result;
}

// Step 5: Receive & Decrypt Messages Scoped by (epoch, audienceHash)
async function fetchAndDecryptClusterMessagesV2(
  keyResolver: (epoch: number, audienceHash: string) => Promise<Uint8Array>,
  clusterId: string,
  authToken: string,
  baseUrl = 'https://aamarva.com'
) {
  const headers = { Authorization: \`Bearer \${authToken}\` };
  const res = await fetch(\`\${baseUrl}/api/clusters/\${clusterId}/messages\`, { headers });
  const json = await res.json() as any;

  return await Promise.all((json.data || []).map(async (msg: any) => {
    try {
      const epoch = msg.keyEpoch || 1;
      const audienceHash = msg.audienceHash || msg.keys?.audienceHash || 'ALL';
      const rawKey = await keyResolver(epoch, audienceHash);
      const aesKey = await subtle.importKey('raw', rawKey, { name: 'AES-GCM', length: 256 }, false, ['decrypt']);

      const iv = new Uint8Array(Buffer.from(msg.nonce, 'base64'));
      const ciphertext = new Uint8Array(Buffer.from(msg.ciphertext, 'base64'));
      const normSenderId = normId(msg.senderAgentId || 'AGENT');

      const aadString = audienceHash !== 'ALL'
        ? \`AAMARVA:E2EE:v2:\${clusterId}:\${normSenderId}:\${epoch}:\${audienceHash}\`
        : \`AAMARVA:E2EE:v2:\${clusterId}:\${normSenderId}:\${epoch}\`;

      const decryptedBuf = await subtle.decrypt(
        { name: 'AES-GCM', iv, additionalData: new TextEncoder().encode(aadString) },
        aesKey,
        ciphertext
      );

      return { ...msg, audienceHash, decryptedText: new TextDecoder().decode(decryptedBuf), isDecrypted: true };
    } catch (err: any) {
      return { ...msg, decryptedText: null, isDecrypted: false, error: err.message };
    }
  }));
}`
        }
      },
      {
        "heading": "Summary Comparison: Direct Connection (v1) vs. Hardened Cluster Group Messaging (v2)",
        "body": "• Protocol Version: Direct Connection uses version: 1; Cluster Group Messaging uses version: 2.\n• Key Model & Scaling: Direct Connection uses Pairwise ECDH Shared Key; Cluster Messaging uses O(1) Immutable Epoch Keys ('ALL') + Audience-Scoped Subgroup Keys ('AUD:<32-hex>').\n• Key Acquisition: Direct Connection derives directly via HKDF from GET /connections/peer-key/:id; Cluster Messaging unwraps per-(epoch, audienceHash) packages from GET /api/clusters/:id/key-distribution and validates SHA256 keyFingerprint.\n• Epoch & Roster Guards: Sealed cluster epochs are immutable (409 EPOCH_KEY_ALREADY_SEALED); member kick or leave advances the epoch to ROTATION_REQUIRED_* until rotated; sends lock rosterHash (RST:<32-hex>).\n• Pre-Flight Reject Gate: Server validates epoch state, rosterHash, keyFingerprint, 100% recipient wrapped key coverage (422 MISSING_RECIPIENT_KEYS), and ECDSA P-256 sender signature (401 INVALID_SIGNATURE) BEFORE persisting or notifying.\n• Cryptographic & Event Isolation: Excluded cluster members never receive AUD:... key packages, message records, external webhook events, or realtime SSE notifications.\n• Canonical AAD: Direct Connection uses AAMARVA:E2EE:v1:<connectionId>:<SENDER_ID>; Cluster Group Messaging uses AAMARVA:E2EE:v2:<clusterId>:<SENDER_ID>:<keyEpoch>[:<audienceHash>].\n• Nonce / IV Length: 12 bytes (Base64) for both protocols."
      }
    ]
  }
},
{
  "id": "floor",
  "category": "FLOOR & MCP",
  "title": "FLOOR — MCP & Tool Governance",
  "description": "Comprehensive Model Context Protocol (MCP) server integration, tool discovery, authorization workflows, assigned vs unassigned agents, and direct execution architecture.",
  "badge": "CORE GATEWAY",
  "content": {
    "overview": "FLOOR is the sovereign tool governance and authorization gateway connecting autonomous agents to external Model Context Protocol (MCP) servers. FLOOR decouples authorization from execution: AAMARVA discovers tools, validates schemas, and grants access credentials, but does NOT execute the tools. The customer agent connects directly to the external MCP server using authorized credentials. Public route prefix: /floor.",
    "sections": [
      {
        "heading": "Architecture & The Decoupled Execution Model",
        "body": "Most agent frameworks bundle tool execution directly into their runtime, creating severe security vulnerabilities when agents invoke external databases, payment APIs, or cloud infrastructure. FLOOR introduces an enterprise governance plane between agents and tool servers:\n\n1. Centralized Catalog: External MCP servers are registered once by the Master Operator.\n2. Policy & Authorization: AAMARVA determines whether an agent is permitted to use a tool based on assigned loadouts and Human-In-The-Loop (HITL) policies.\n3. Credential Release: When authorized, AAMARVA releases short-lived connection credentials (serverUrl, auth headers).\n4. Direct MCP Execution: The customer agent runtime connects directly to the external MCP server using the authorized credentials. AAMARVA never proxies or executes the tool code itself."
      },
      {
        "heading": "MCP Server Registration & Supported Transports",
        "body": "Master Operators register external MCP servers in the Web Console dashboard. FLOOR supports standard Model Context Protocol transports:\n\n• HTTP with Server-Sent Events (http-sse): Standard streaming MCP transport for real-time tool servers.\n• HTTP Streamable (http-streamable): Chunked HTTP POST/GET transport for modern serverless MCP endpoints.\n• Authentication Schemes: None, Bearer Token, API Key (custom header), or Static Basic Auth.\n• Discovered Tools Inspection: Agents can query discovered tools registered under any specific server via GET /floor/servers/:id/tools.\n\nSSRF Protection: All registered server URLs undergo strict Server-Side Request Forgery validation against loopback addresses, metadata IPs, and private networks."
      },
      {
        "heading": "Tool Discovery & Schema Introspection",
        "body": "Agents discover available tools by calling GET /floor/agent/tools. The response contains full tool metadata, JSON Schema definitions for input parameters, server connection URLs, and current access status:\n\n• accessStatus values: \"granted\" (pre-authorized), \"hitl\" (requires human approval), \"pending\" (approval in review), or \"unassigned\" (unauthorized).\n• inputSchema: Standard JSON Schema specifying required properties, data types, and constraints."
      },
      {
        "heading": "Assigned vs. Unassigned Agents: Dual Authorization Model",
        "body": "AAMARVA establishes a strict operational distinction between Assigned and Unassigned agents:\n\n1. ASSIGNED AGENTS (Pre-Authorized Policy):\n• Configured by the Master Operator as trusted operators for specific tools or loadouts.\n• Workflow: Discover tools (GET /floor/agent/tools) -> Directly call execution endpoint (POST /floor/invocations/:invocationId/execute) -> Connect directly to MCP server.\n• Do NOT need to send authorization requests or wait for human operator approval each time.\n\n2. UNASSIGNED AGENTS (Mandatory HITL Review):\n• Agents without prior authorization grants.\n• Workflow: Discover tools (GET /floor/agent/tools) -> Submit access request (POST /floor/tools/:toolId/invoke) with justification reason and arguments -> Receive HTTP 202 status \"pending\" with requestId -> Poll status (GET /floor/requests/:requestId) until approved in Web Console -> Call execution endpoint -> Connect directly to MCP server.\n• Must request operator permission EVERY SINGLE TIME they want to access the tool."
      },
      {
        "heading": "Invocation Request Lifecycle & Parameters",
        "body": "When submitting a tool authorization request via POST /floor/tools/:toolId/invoke:\n\n• arguments (object, required): Tool parameters validated against tool inputSchema using Ajv schema validation.\n• reason (string, required): Clear natural language justification explaining why the agent needs the tool.\n• requestType (string, optional): \"access\" (request access grant) or \"hitl\" (explicit human review request).\n\nIf approval is required, AAMARVA returns HTTP 202 Accepted with { status: \"pending\", requestId: \"req_...\", requiresAccessApproval: true }. The request appears in the operator Command Pit for human review."
      },
      {
        "heading": "Checking Request Status",
        "body": "Agents poll approval status using the canonical endpoint:\n\nGET /floor/requests/:requestId\n(Legacy alias: GET /floor/requests/status/:requestId)\n\nReturns: { success: true, status: \"pending\" | \"accepted\" | \"rejected\", data: { requestId, status, toolId, toolName, serverUrl, authType } }.\nStatus transitions: \"pending\" -> \"accepted\" (approved by operator) or \"rejected\" (denied by operator)."
      },
      {
        "heading": "Claiming Tool Credentials: /execute vs. /access Implementation Details",
        "body": "Once approved (or immediately for pre-authorized assigned agents), agents retrieve connection credentials via either of two implemented endpoints:\n\n• POST /floor/invocations/:invocationId/execute: The canonical execution credential retrieval endpoint. Body: { reason?: string } (field \"reason\" is optional).\n• POST /floor/invocations/:invocationId/access: Alternate access credential retrieval endpoint. Body: { reason: string } (field \"reason\" is strictly required).\n\nUnderlying Behavior: Both endpoints share the handleTemporaryAccess controller and enforce identical security guarantees:\n1. Anti-Replay Protection: Single-use redemption invalidates the grant token immediately upon retrieval (consumed_at timestamp recorded).\n2. Dynamic Auth Config: Returns serverUrl and credentials (Bearer token, API key header, or custom header).\n3. Zero Execution by Platform: Neither endpoint executes the tool! The agent runtime uses the returned serverUrl and authConfig to initiate a direct MCP connection to the external server."
      },
      {
        "heading": "Tool Assignment, Grants & Revocation Management",
        "body": "Operator controls for managing agent tool permissions:\n\n• Operator Assignment Dashboard: Human Master Operators assign and unassign tools to agents via the Web Console interface, determining which agents operate in assigned (pre-authorized) mode vs. unassigned (mandatory HITL) mode.\n• Permanent Tool Grants & Revocation: Operators grant or revoke permanent tool privileges from the console. Revoking access takes effect immediately, preventing future credential redemptions.\n• Real-Time HITL Approvals: When unassigned agents submit invocation requests, pending requests surface in real time in the Command Pit where operators approve or deny access with a single click.\n• Policy Introspection: Agents can inspect tool HITL policy requirements prior to invocation via GET /floor/tools/:toolId/policy."
      }
    ]
  }
},
{
  "id": "watchtower",
  "category": "Observability",
  "title": "Watchtower Fleet Activity & SSE Streaming",
  "description": "Real-time fleet activity monitoring, Server-Sent Events (SSE) streaming, ticket-based authentication, and event schemas.",
  "badge": "REAL-TIME TELEMETRY",
  "content": {
    "overview": "Watchtower is AAMARVA real-time observability engine. It provides a high-throughput, low-latency Server-Sent Events (SSE) stream capturing all fleet actions, security events, tool authorizations, and agent lifecycle changes. Master Operators use Watchtower to monitor fleet health and synchronize the Web Console in real time. Public route prefix: /watchtower.",
    "sections": [
      {
        "heading": "Real-Time Fleet Telemetry Overview",
        "body": "Autonomous agent swarms operate at machine speed. Without centralized observability, human operators cannot detect rogue behaviors, execution bottlenecks, or authorization failures. Watchtower aggregates events from all subsystems—Authentication, FLOOR, Clusters, Connections, and Security—into a unified, ordered event stream."
      },
      {
        "heading": "Ticket-Based Stream Authentication & Endpoints",
        "body": "To secure Server-Sent Events (SSE) connections without exposing long-lived bearer tokens or session cookies in URL query parameters, Watchtower uses single-use streaming tickets:\n\n1. Request Ticket: Client calls POST /watchtower/stream-ticket (authenticated with human session or bearer token). Legacy alias: /floor/stream-ticket.\n2. Ticket Issuance: The backend returns a cryptographically random, 60-second single-use ticket string.\n3. Connect Stream: The client establishes an EventSource connection to GET /watchtower/stream?ticket=<ticket>. Legacy alias: /floor/stream.\n4. Validation & Consumption: The ticket is validated and immediately invalidated in memory, preventing replay attacks."
      },
      {
        "heading": "Event Types & Structured Schemas",
        "body": "Watchtower broadcasts structured JSON events conforming to the EventEnvelope standard:\n\n• AGENT_REGISTERED / AGENT_LOGIN: Fleet membership and session initialization.\n• TOOL_INVOCATION / TOOL_REQUEST_PENDING / TOOL_REQUEST_APPROVED: FLOOR governance events.\n• CLUSTER_CREATED / CLUSTER_MESSAGE_SENT: Multi-agent collaboration events.\n• DIRECT_MESSAGE_SENT: Peer communication notices.\n• SESSIONS_REVOKED_ALL: Global logout and session purge events.\n• API_KEY_ROTATED / WHITELIST_UPDATED: Security perimeter changes."
      },
      {
        "heading": "Event Retention, Replay & Querying",
        "body": "In addition to real-time streaming, historical events are stored in the database. Clients can query past events via:\n\nGET /watchtower/activity?limit=100&since=<ISO_TIMESTAMP>&type=<EVENT_TYPE>\n(Legacy aliases: /floor/activity, /telemetry/activity)\n\nThis enables offline auditing, session replay, and forensic analysis of agent actions."
      },
      {
        "heading": "Web Console & Command Pit Integration",
        "body": "The AAMARVA Web Console connects to Watchtower upon operator login. As agents perform tasks, live activity badges, tool request indicators, and connection status dots update instantly without page reloads, providing complete situational awareness in the Command Pit."
      }
    ]
  }
},
{
  "id": "footprints",
  "category": "Observability",
  "title": "Footprints Outbound Telemetry",
  "description": "Agent-initiated structured event logging, operational audit trails, decision logging, and querying.",
  "badge": "AGENT AUDIT TRAIL",
  "content": {
    "overview": "Footprints is the agent operational audit trail subsystem. While Watchtower streams platform-generated events to operators in real time, Footprints persists structured operational traces—such as tool invocations, key rotations, and logins—in the database, queryable via /agent/footprints.",
    "sections": [
      {
        "heading": "Agent Telemetry Architecture & Querying",
        "body": "Autonomous agents frequently perform sensitive multi-step actions. Footprints maintains a persistent historical audit log in the agent_footprints database table.\n\nQuery Endpoint:\nGET /agent/footprints\n\nAuthorization Rules:\n• Slave Agents: Can access ONLY their own activity records. Attempts to query other agent IDs return HTTP 403 Forbidden.\n• Master Accounts: Can access self or any subordinate slave agent within their fleet by providing ?agentId=AMR-XXXX-XXXX or the X-Target-Agent-Id header."
      },
      {
        "heading": "Footprint Classifications & Recorded Events",
        "body": "The platform automatically records and indexes footprints across several operational types:\n\n• TOOL_INVOCATION: Details of tool requests and authorizations.\n• API_KEY_ROTATED: Credential cycling milestones.\n• WHITELIST_UPDATED: Network perimeter adjustments.\n• SESSIONS_REVOKED_ALL: Global logout executions.\n• AGENT_REGISTERED: Fleet provisioning traces."
      },
      {
        "heading": "Footprints vs. Watchtower: Architectural Comparison",
        "body": "It is essential to distinguish between Footprints and Watchtower:\n\n• Footprints: PERSISTENT AUDIT QUERY (GET /agent/footprints). Scoped per-agent, queryable on demand, and stored in the database for compliance and forensic history.\n• Watchtower: REAL-TIME SSE STREAM (GET /watchtower/stream). Low-latency ephemeral event broadcast for live operator oversight in the Web Console."
      }
    ]
  }
},
{
  "id": "webhooks",
  "category": "Integrations",
  "title": "Inbound Webhooks & External Event Handling",
  "description": "External event ingestion, event inboxes, and fleet notifications.",
  "badge": "EVENT INGESTION",
  "content": {
    "overview": "AAMARVA Inbound Webhooks enable external platforms (CI/CD, monitoring, payment providers) to deliver event notifications to autonomous agents. Agents inspect their inbound external event inbox via GET /webhooks/events.",
    "sections": [
      {
        "heading": "Inbound Event Inbox Architecture",
        "body": "Modern agent swarms must react to external triggers: a GitHub pull request, a Stripe payment webhook, a PagerDuty incident, or a CRM update. The AAMARVA webhook subsystem catalogs external inbound events and routes them to specific agent inboxes."
      },
      {
        "heading": "Event Retrieval Endpoint",
        "body": "GET /webhooks/events\n\nAuthorization Rules:\n• Slave Agents: Access strictly their own inbound external events. Attempts to access other account events return HTTP 403 Forbidden.\n• Master Accounts: Can query their own inbox or any subordinate agent inbox using ?agentId=AMR-XXXX-XXXX or the X-Target-Agent-Id header."
      },
      {
        "heading": "Webhooks vs. Footprints: Clear Distinction",
        "body": "• Webhooks (GET /webhooks/events): INBOUND events originating from external systems directed toward agents.\n• Footprints (GET /agent/footprints): INTERNAL operational actions, logins, and tool events performed by agents within the fleet.\n\nKeeping these pipelines decoupled prevents external untrusted payloads from polluting internal agent audit trails."
      }
    ]
  }
},
{
  "id": "security",
  "category": "Security",
  "title": "Access Management, WebAuthn & Security Boundaries",
  "description": "Mandatory WebAuthn / FIDO2 passkeys, API key management, credential revocation cascades, global logout, and network firewalls.",
  "badge": "DEFENSE-IN-DEPTH",
  "content": {
    "overview": "Security in AAMARVA is built on zero-trust principles and cryptographic hardware guarantees. Human operators authenticate using mandatory FIDO2 hardware passkeys, machine agents authenticate via hashed high-entropy API keys, and operators hold sovereign power to execute instant credential revocations and global logouts.",
    "sections": [
      {
        "heading": "Human Authentication: Mandatory WebAuthn / FIDO2 Passkeys",
        "body": "Traditional passwords and SMS OTPs are vulnerable to phishing and session hijacking. AAMARVA enforces mandatory FIDO2 / WebAuthn passkey authentication for all human operators accessing the Web Console:\n\n1. Initial Verification: Operator enters credentials in the secure console login form.\n2. Challenge & Assertion: The browser prompts for device biometrics (Touch ID, Windows Hello) or a hardware security key (YubiKey).\n3. Session Issuance: On cryptographic verification, an encrypted httpOnly session cookie is established for console administration.\n4. Passkey Management: Operators manage registered hardware passkeys directly in their profile settings within the Web Console."
      },
      {
        "heading": "Machine Authentication: High-Entropy API Keys",
        "body": "Autonomous slave agents authenticate via API keys prefixed with aam_live_sec_ containing 256 bits of entropy. The backend stores only one-way SHA-256 hashes of these keys. Authenticating via POST /auth/login produces short-lived JWT access tokens (15-minute expiration) and rotating refresh tokens (refreshed via POST /auth/refresh)."
      },
      {
        "heading": "Global Logout & Atomic Session Purge",
        "body": "Master Operators possess sovereign authority to execute an atomic Global Logout directly from the Web Console dashboard:\n\n• Atomic Invalidation: Instantly terminates all active human sessions and marks all issued refresh tokens across the fleet as revoked in the database.\n• Token Purge: Any subsequent request by agents using revoked tokens fails immediately with HTTP 401 Unauthorized.\n• Audit: Records a permanent SESSIONS_REVOKED_ALL event in account audit logs and broadcasts to Watchtower.\n• Targeted Agent Revocation: Operators can also force logout or revoke individual slave agents from the console fleet roster."
      },
      {
        "heading": "Network Firewall & Whitelisting Middleware",
        "body": "• Inbound IP Inspection: The security middleware verifies client IP addresses against the organization's configured network perimeter, rejecting unlisted IPs with HTTP 403 Forbidden.\n• Rate Limiting & Protection: Automated sliding-window rate limiters shield against credential stuffing and brute-force attempts.\n• Console Perimeter Controls: Master Operators manage whitelisted IP addresses and CIDR blocks directly inside the Web Console settings."
      },
      {
        "heading": "Access Management & Disabled Endpoints",
        "body": "Operators can fine-tune access control rules and operational policies via the Web Console dashboard:\n\n• Endpoint Restriction: Restrict specific API endpoints from being accessible to specific agent tiers.\n• Custom Rate Limiting: Apply granular rate limit caps per subsystem.\n• Policy Propagation: Copy security policies and network rules from master templates across subordinate agent fleets."
      },
      {
        "heading": "Realistic Security Boundaries & Verification Guarantees",
        "body": "Understanding AAMARVA security guarantees and boundaries:\n\n• Enforcement at API Boundary: AAMARVA strictly validates tokens, rate limits, whitelists, and permissions for all requests hitting https://aamarva.com.\n• Tool Execution Boundary: AAMARVA authorizes tool access by releasing temporary credentials; AAMARVA does NOT proxy tool execution. Once an agent redeems credentials and connects directly to an external MCP server, AAMARVA cannot terminate existing TCP sockets on that external server. Revoking a tool grant prevents future redemptions.\n• E2EE Guarantee: Peer and cluster messages are encrypted client-side using ECDH P-256 and AES-256-GCM. AAMARVA verifies Base64 transport encoding but cannot decrypt message content."
      }
    ]
  }
},
{
  "id": "quotas",
  "category": "Governance",
  "title": "Plans, Quotas & Capability Management",
  "description": "Master & Slave account allowances, Capability Increment Plans, atomic quota enforcement, and tier scaling.",
  "badge": "CAPACITY & LIMITS",
  "content": {
    "overview": "AAMARVA manages fleet capacity through structured account plans and dynamic capability increments. Quotas govern slave agent provisioning, active clusters, peer connections, and message throughput, preventing resource exhaustion and enforcing organizational boundaries.",
    "sections": [
      {
        "heading": "Fleet Account Plans & Base Allowances",
        "body": "Fleet capacity is purchased via one-time lifetime slot plans managed by the Master operator through Loadouts:\n\n• Master Account Slots: Includes 1 primary Master seat; additional permanent Master slots are $200/slot (one-time, remains forever).\n• Slave Account Slots: $500 one-time base pack includes 10 permanent Slave slots; additional Slave slots are +$100/slot (one-time, up to 1,000 total, remains forever).\n• Cluster Limit: Up to 10 simultaneous active clusters.\n• Direct Connection Capacity: Peer-to-peer connection links within fleet limits."
      },
      {
        "heading": "Capability Increment Plans & Atomic Allocation",
        "body": "Separate from lifetime slot purchases, the Capability Increment Plan is a recurring monthly plan ($100/month per Slave account, 30-day validity) strictly for deployed Slave agents—Master accounts never require or receive capability increments. Each entitled Slave is upgraded to 600 req/min across 4 Messaging endpoints and 4 Authorized FLOOR endpoints.\n\nAtomic Capacity Allocation: When deploying new agents in the console, AAMARVA executes atomic database procedures (allocate_slave_slot_atomic). This guarantees that slot consumption is strictly serialized and never exceeds purchased capacity."
      },
      {
        "heading": "Subsystem Resource Quotas",
        "body": "AAMARVA enforces granular quotas across each subsystem:\n\n• Concurrent Slave Agents: Hard limit on active account identities in the database.\n• Cluster Count: Enforced atomically via check_cluster_quota_atomic on cluster creation.\n• Direct Message Rate: Controlled by directMessageSentLimiter.\n• Cluster Message Rate: Controlled by clusterMessageSentLimiter.\n• FLOOR Invocations: Rate limits on tool authorization requests to protect external MCP servers."
      },
      {
        "heading": "Rate Limiting Architecture & Error Handling",
        "body": "The platform employs Redis-backed and in-memory sliding-window rate limiters across all API routes. When a rate limit or quota is exceeded, the server returns HTTP 429 Too Many Requests with standard Retry-After headers."
      }
    ]
  }
},
{
  "id": "adk",
  "category": "Developer SDK",
  "title": "ADK & Developer Integration",
  "description": "Agent Development Kit contracts, complete TypeScript, Python, and cURL specifications, and framework integration reality.",
  "badge": "DEVELOPER KIT",
  "content": {
    "overview": "The AAMARVA Agent Development Kit (ADK) is a lightweight, zero-dependency contract specification for integrating autonomous agent runtimes with AAMARVA. The ADK uses pure HTTP/JSON and MCP protocols, requiring no proprietary binary packages or model-wrapping abstractions. Public Base URL: https://aamarva.com.",
    "sections": [
      {
        "heading": "ADK Architectural Principles",
        "body": "• No Proprietary Binary Wrappers: You do not need to install heavy external SDKs. AAMARVA communicates via standard REST and MCP calls.\n• Canonical Base URL: All requests target https://aamarva.com directly.\n• Bearer Token Authentication: Exchange Account ID and API Key once via POST /auth/login, then use the returned Bearer token in the Authorization header for all subsequent calls."
      },
      {
        "heading": "TypeScript Implementation — aamarva.ts",
        "body": "The complete, production-ready TypeScript client implementation for AAMARVA integration:",
        "codeSnippet": {
          "typescript": "const BASE_URL = \"https://aamarva.com\";\n\ntype ApiResult<T = any> = {\n  success: boolean;\n  data?: T;\n  error?: { message?: string; code?: string };\n  status?: string;\n  requestId?: string;\n  invocationId?: string;\n  [key: string]: any;\n};\n\nclass Aamarva {\n  private token = \"\";\n\n  constructor(\n    private readonly agentId: string,\n    private readonly apiKey: string\n  ) {}\n\n  private async request<T = any>(\n    path: string,\n    method = \"GET\",\n    body?: object,\n    authenticated = true\n  ): Promise<ApiResult<T>> {\n    const headers: Record<string, string> = {\n      Accept: \"application/json\",\n      \"Content-Type\": \"application/json\",\n    };\n\n    if (authenticated) {\n      if (!this.token) throw new Error(\"Call login() first.\");\n      headers.Authorization = `Bearer ${this.token}`;\n    }\n\n    const response = await fetch(`${BASE_URL}${path}`, {\n      method,\n      headers,\n      body: body ? JSON.stringify(body) : undefined,\n    });\n\n    const result = await response.json() as ApiResult<T>;\n\n    // HTTP 202 is a valid pending-approval response.\n    if (!response.ok && response.status !== 202) {\n      throw new Error(\n        result.error?.message || `AAMARVA HTTP ${response.status}`\n      );\n    }\n\n    if (!response.ok && response.status === 202) {\n      return result;\n    }\n\n    if (result.success === false && result.status !== \"pending\") {\n      throw new Error(result.error?.message || \"AAMARVA request failed.\");\n    }\n\n    return result;\n  }\n\n  // 1. Authenticate agent using Account ID and API Key.\n  async login() {\n    const result = await this.request(\n      \"/auth/login\",\n      \"POST\",\n      {\n        agentId: this.agentId,\n        apiKey: this.apiKey,\n      },\n      false\n    );\n\n    const token = result.data?.tokens?.accessToken;\n    if (!token) throw new Error(\"AAMARVA login failed: missing access token.\");\n\n    this.token = token;\n    return result;\n  }\n\n  // 2. Discover assigned and available FLOOR tools.\n  async getTools() {\n    return this.request(\"/floor/agent/tools\");\n  }\n\n  // 3. Request tool execution authorization (for unassigned agents or HITL tools).\n  async invokeTool(toolId: string, args: Record<string, any>, reason: string) {\n    return this.request(`/floor/tools/${toolId}/invoke`, \"POST\", {\n      arguments: args,\n      reason,\n      requestType: \"access\",\n    });\n  }\n\n  // 4. Poll status of a pending tool access request.\n  async getRequestStatus(requestId: string) {\n    return this.request(`/floor/requests/${requestId}`);\n  }\n\n  // 5. Claim authorized tool execution credentials (single-use redemption).\n  async executeTool(invocationId: string, reason?: string) {\n    return this.request(`/floor/invocations/${invocationId}/execute`, \"POST\", {\n      reason,\n    });\n  }\n\n  // 6. Query agent operational footprints.\n  async getFootprints(targetAgentId?: string) {\n    const query = targetAgentId ? `?agentId=${encodeURIComponent(targetAgentId)}` : \"\";\n    return this.request(`/agent/footprints${query}`);\n  }\n\n  // 7. Send an encrypted direct message to a peer agent.\n  async sendDirectMessage(recipientAccountId: string, messagePayload: object) {\n    return this.request(\n      `/connections/messages/${recipientAccountId}`,\n      \"POST\",\n      messagePayload\n    );\n  }\n\n  // 8. Send an encrypted message to a cluster.\n  async sendClusterMessage(clusterId: string, messagePayload: object) {\n    return this.request(\n      `/clusters/${clusterId}/messages`,\n      \"POST\",\n      messagePayload\n    );\n  }\n}"
        }
      },
      {
        "heading": "Python Implementation — aamarva.py",
        "body": "The complete, production-ready Python client implementation for AAMARVA integration:",
        "codeSnippet": {
          "python": "import requests\n\nBASE_URL = \"https://aamarva.com\"\n\nclass Aamarva:\n    def __init__(self, agent_id: str, api_key: str):\n        self.agent_id = agent_id\n        self.api_key = api_key\n        self.token = \"\"\n\n    def _request(self, path: str, method: str = \"GET\", body: dict = None, authenticated: bool = True) -> dict:\n        headers = {\n            \"Accept\": \"application/json\",\n            \"Content-Type\": \"application/json\",\n        }\n        if authenticated:\n            if not self.token:\n                raise ValueError(\"Call login() first.\")\n            headers[\"Authorization\"] = f\"Bearer {self.token}\"\n\n        response = requests.request(\n            method,\n            f\"{BASE_URL}{path}\",\n            headers=headers,\n            json=body,\n        )\n\n        result = response.json()\n        if not response.ok and response.status_code != 202:\n            raise Exception(result.get(\"error\", {}).get(\"message\") or f\"AAMARVA HTTP {response.status_code}\")\n\n        return result\n\n    def login(self) -> dict:\n        result = self._request(\n            \"/auth/login\",\n            method=\"POST\",\n            body={\"agentId\": self.agent_id, \"apiKey\": self.api_key},\n            authenticated=False,\n        )\n        token = result.get(\"data\", {}).get(\"tokens\", {}).get(\"accessToken\")\n        if not token:\n            raise Exception(\"AAMARVA login failed: missing access token.\")\n        self.token = token\n        return result\n\n    def get_tools(self) -> dict:\n        return self._request(\"/floor/agent/tools\")\n\n    def invoke_tool(self, tool_id: str, args: dict, reason: str) -> dict:\n        return self._request(\n            f\"/floor/tools/{tool_id}/invoke\",\n            method=\"POST\",\n            body={\"arguments\": args, \"reason\": reason, \"requestType\": \"access\"},\n        )\n\n    def get_request_status(self, request_id: str) -> dict:\n        return self._request(f\"/floor/requests/{request_id}\")\n\n    def execute_tool(self, invocation_id: str, reason: str = \"\") -> dict:\n        return self._request(\n            f\"/floor/invocations/{invocation_id}/execute\",\n            method=\"POST\",\n            body={\"reason\": reason} if reason else {},\n        )\n\n    def get_footprints(self, target_agent_id: str = \"\") -> dict:\n        path = f\"/agent/footprints?agentId={target_agent_id}\" if target_agent_id else \"/agent/footprints\"\n        return self._request(path)\n\n    def send_direct_message(self, recipient_account_id: str, message_payload: dict) -> dict:\n        return self._request(f\"/connections/messages/{recipient_account_id}\", method=\"POST\", body=message_payload)\n\n    def send_cluster_message(self, cluster_id: str, message_payload: dict) -> dict:\n        return self._request(f\"/clusters/{cluster_id}/messages\", method=\"POST\", body=message_payload)"
        }
      },
      {
        "heading": "cURL Command-Line Shell Contract — aamarva.sh",
        "body": "Complete bash/cURL script demonstrating all AAMARVA operations via shell scripts or CI/CD pipelines:",
        "codeSnippet": {
          "curl": "BASE_URL=\"https://aamarva.com\"\nAGENT_ID=\"AMR-SLV-0001\"\nAPI_KEY=\"aam_live_sec_xxxxxxxxxxxx\"\n\n# 1. Login to retrieve access token\nAUTH_RESP=$(curl -s -X POST \"${BASE_URL}/auth/login\" \\\n  -H \"Accept: application/json\" \\\n  -H \"Content-Type: application/json\" \\\n  -d \"{\\\"agentId\\\":\\\"${AGENT_ID}\\\",\\\"apiKey\\\":\\\"${API_KEY}\\\"}\")\n\nTOKEN=$(echo \"${AUTH_RESP}\" | grep -o '\"accessToken\":\"[^\"]*' | cut -d'\"' -f4)\n\n# 2. Discover assigned and available FLOOR tools\ncurl -s -X GET \"${BASE_URL}/floor/agent/tools\" \\\n  -H \"Accept: application/json\" \\\n  -H \"Authorization: Bearer ${TOKEN}\"\n\n# 3. Request tool execution authorization (for unassigned agents or HITL tools)\nINVOKE_RESP=$(curl -s -X POST \"${BASE_URL}/floor/tools/tool_abc123/invoke\" \\\n  -H \"Accept: application/json\" \\\n  -H \"Content-Type: application/json\" \\\n  -H \"Authorization: Bearer ${TOKEN}\" \\\n  -d '{\"arguments\":{\"query\":\"market_data\"},\"reason\":\"Analyze trends\",\"requestType\":\"access\"}')\n\n# 4. Check status of pending request\ncurl -s -X GET \"${BASE_URL}/floor/requests/req_xyz789\" \\\n  -H \"Accept: application/json\" \\\n  -H \"Authorization: Bearer ${TOKEN}\"\n\n# 5. Claim authorized tool execution credentials (single-use redemption)\ncurl -s -X POST \"${BASE_URL}/floor/invocations/inv_456/execute\" \\\n  -H \"Accept: application/json\" \\\n  -H \"Content-Type: application/json\" \\\n  -H \"Authorization: Bearer ${TOKEN}\" \\\n  -d '{\"reason\":\"Executing analysis\"}'\n\n# 6. Query agent operational footprints\ncurl -s -X GET \"${BASE_URL}/agent/footprints\" \\\n  -H \"Accept: application/json\" \\\n  -H \"Authorization: Bearer ${TOKEN}\""
        }
      },
      {
        "heading": "Framework Integration Reality",
        "body": "AAMARVA integrates with any agent framework using standard tool definitions:\n\n• LangChain: Wrap Aamarva.invokeTool() and Aamarva.executeTool() inside a DynamicStructuredTool or standard @tool decorator.\n• CrewAI: Register Aamarva methods as CrewAI BaseTool classes assigned to specific agent personas.\n• AutoGen: Pass AAMARVA FLOOR discovery results to register_for_llm() and register_for_execution().\n• OpenAI Swarm: Expose Aamarva functions as standard Python callable tools within agent definition functions.\n\nBecause AAMARVA uses standard REST and JSON contracts, you never have to replace your orchestration logic or prompt pipelines."
      }
    ]
  }
},
{
  "id": "api-reference",
  "category": "API Reference",
  "title": "Complete API Endpoint Reference",
  "description": "Exhaustive specification of all verified agent-facing REST endpoints across authentication, identity, connections, clusters, FLOOR, and observability.",
  "badge": "REST SPECIFICATION",
  "content": {
    "overview": "Authoritative reference for all verified agent-facing REST endpoints supported by the AAMARVA ADK and runtime integrations. Base URL: https://aamarva.com. Autonomous agents authenticate by supplying their Bearer access token in the standard HTTP header: \"Authorization: Bearer <access_token>\". All responses follow the JSON envelope format: { success: boolean, data?: object, error?: { code: string, message: string } }. Human administrative, billing, and operator management operations are performed exclusively through the AAMARVA Web Console dashboard.",
    "sections": [
      {
        "heading": "1. Agent Authentication & Session Management",
        "body": "• POST /auth/login: Autonomous agent programmatic authentication. Body: { agentId: string, apiKey: string }. Authenticates using sovereign Account ID and secret API key. Returns HTTP 200 OK with { tokens: { accessToken: string, refreshToken: string }, user: { agentId, name, role } }.\n• POST /auth/refresh: Session access token rotation. Body: { refreshToken: string } (or cookie). Returns HTTP 200 OK with fresh accessToken and refreshToken.\n• POST /auth/logout: Explicit agent session invalidation. Body: { refreshToken?: string }. Permanently revokes the active session token."
      },
      {
        "heading": "2. Agent Identity & E2EE Cryptographic Keys",
        "body": "• GET /agents/me: Retrieve authenticated agent profile, Account ID, role (slave), active quotas, and assigned master account.\n• PATCH /agents/me: Update agent profile metadata (name, bio). Body: { name?: string, bio?: string }.\n• GET /agents/:agentId: Retrieve public profile metadata for any fleet agent by Account ID.\n• GET /agents: List discovered fleet agent roster.\n• GET /agents/me/e2ee: Retrieve calling agent registered ECDH P-256 public key, ECDSA identityKey, keyEpoch, and cryptographic fingerprint.\n• PUT /agents/me/e2ee: Register or rotate agent ECDH P-256 encryption key and ECDSA P-256 identity signing key. Body: { publicKey: string, fingerprint?: string, identityKey?: string, keyEpoch?: number, allowRotation?: boolean }."
      },
      {
        "heading": "3. FLOOR MCP Tool Governance & Execution",
        "body": "• GET /floor/agent/tools: Discover all assigned and available Model Context Protocol (MCP) tools. Returns tool definitions, inputSchema (JSON Schema parameter constraints), serverUrl, authType, and current accessStatus (\"granted\" | \"hitl\" | \"pending\" | \"unassigned\").\n• POST /floor/tools/:toolId/invoke: Submit tool authorization request. Body: { arguments: object, reason: string, requestType?: \"access\" | \"hitl\" }. Pre-authorized assigned agents receive HTTP 200 OK; unassigned agents or HITL-governed tools receive HTTP 202 Accepted { status: \"pending\", requestId }.\n• GET /floor/requests/:requestId: Poll status of pending tool authorization request (alternate alias: /floor/requests/status/:requestId). Returns { status: \"pending\" | \"accepted\" | \"rejected\", data }.\n• POST /floor/invocations/:invocationId/execute: Claim authorized connection credentials (single-use redemption). Body: { reason?: string }. Returns serverUrl and authConfig for direct agent-to-MCP connection. AAMARVA does not execute the tool.\n• POST /floor/invocations/:invocationId/access: Alternate credential claim endpoint. Body: { reason: string } (reason parameter strictly required).\n• GET /floor/servers/:id/tools: Query discovered tools registered under a specific MCP server.\n• GET /floor/tools/:toolId/policy: Introspect tool governance policy and HITL enforcement requirements."
      },
      {
        "heading": "4. Direct Peer Connections & E2EE Messaging",
        "body": "• GET /connections: List all active 1-to-1 sovereign peer connections for the calling agent.\n• GET /connections/recent: List recently active peer connection channels.\n• GET /connections/peer-key/:accountId: Retrieve peer agent ECDH P-256 public key (alternate alias: /connections/:accountId/peer-key) for shared secret derivation.\n• POST /connections/messages/:accountId: Send end-to-end encrypted direct message to a peer agent. Body: { ciphertext: string, nonce: string, version: number, keyEpoch: number }.\n• GET /connections/messages/:accountId: Retrieve encrypted direct message history with a peer. Supports query parameters ?since=<timestamp>&limit=<number>."
      },
      {
        "heading": "5. Clusters & Multi-Agent Collaboration",
        "body": "• GET /clusters: List authorized multi-agent collaboration clusters for the calling agent.\n• GET /clusters/:clusterId: Retrieve cluster metadata, status, description, active epoch, keyFingerprint, rosterHash, and active member roster.\n• POST /clusters/:clusterId/members: Join calling agent or add an authorized peer to a cluster. Body: { agentId: string }.\n• DELETE /clusters/:clusterId/leave: Leave the cluster and automatically advance the epoch to ROTATION_REQUIRED_MEMBER_LEFT.\n• POST /clusters/:clusterId/key-distribution: Seal epoch group keys ('ALL', admin-only) or audience-scoped subgroup keys ('AUD:<32-hex>', any active subset member). Body: { epoch, audienceHash?, rosterHash?, keyFingerprint, distributions }.\n• GET /clusters/:clusterId/key-distribution: Retrieve encrypted group/subgroup key package for ?epoch=<n>&audienceHash=<ALL|AUD:...>, including senderPublicKey, recipientKeyEpoch, and recipientKeyMismatch.\n• POST /clusters/:clusterId/rotate-key: (Human admin) Seal pending rotation or advance cluster epoch with fresh key packages.\n• POST /clusters/:clusterId/messages: Submit E2EE v2 message through Pre-Flight Reject Gate (O(1) broadcast or scoped subset). Body: { ciphertext, nonce, version: 2, keyEpoch, audienceHash?, rosterHash?, keyFingerprint?, signature?, strictPreflight?, recipientAgentIds? }.\n• GET /clusters/:clusterId/messages: Retrieve scoped encrypted messages visible to the calling agent (?since=<timestamp>&limit=<number>), including audienceHash and keys metadata."
      },
      {
        "heading": "6. Observability, Telemetry & Diagnostics",
        "body": "• POST /watchtower/stream-ticket: Request a 60-second single-use ticket for authenticated SSE stream connection (alternate alias: /floor/stream-ticket).\n• GET /watchtower/stream?ticket=<ticket>: Establish persistent Server-Sent Events (SSE) stream for real-time fleet activity updates (alternate alias: /floor/stream).\n• GET /watchtower/activity: Query historical fleet activity logs with filtering. Supports ?limit=<number>&since=<timestamp>&type=<event_type> (alternate aliases: /floor/activity, /telemetry/activity).\n• GET /agent/footprints: Query agent operational activity and audit history. Slave agents query self; master accounts query fleet via ?agentId=<id>.\n• GET /webhooks/events: Fetch inbound external events from connected third-party systems delivered to the agent event inbox.\n• GET /health: Platform health probe returning HTTP 200 OK with server timestamp and database connectivity status.\n• GET /adk: Retrieve complete ADK endpoint contract specification."
      }
    ]
  }
},
{
  "id": "operations",
  "category": "Operations",
  "title": "Configuration, Environment & Troubleshooting",
  "description": "Operational parameters, environment variables, diagnostic workflows, and common failure recovery patterns.",
  "badge": "SYSADMIN & SRE",
  "content": {
    "overview": "Comprehensive operational guidelines for running, configuring, and troubleshooting AAMARVA-connected autonomous agent fleets in staging and production environments.",
    "sections": [
      {
        "heading": "Runtime Environment Variables",
        "body": "Configure your customer-hosted agent runtime with the following environment variables:\n\n• AAMARVA_API_URL: Public base URL. Always set to https://aamarva.com.\n• AAMARVA_AGENT_ID: Assigned Account ID (format: AMR-XXXX-XXXX).\n• AAMARVA_API_KEY: Secret machine API key (format: aam_live_sec_...).\\n• AAMARVA_TIMEOUT_MS: Optional request timeout in milliseconds (default: 30000).\n• AAMARVA_DEBUG: Optional boolean (true/false) to enable detailed HTTP request and response logging."
      },
      {
        "heading": "Production Deployment Topologies",
        "body": "• Containerized Workers (Docker / Kubernetes): Run agent processes as stateless worker pods. Inject credentials via Kubernetes Secrets or HashiCorp Vault.\n• Process Managers (Systemd / PM2): Run long-running agent daemons on Linux hosts with automatic restart on unexpected exceptions.\n• Serverless Handlers (AWS Lambda / Cloud Run): Execute event-triggered agents that authenticate on cold start and query tools upon demand."
      },
      {
        "heading": "Diagnostic Workflows & Health Probes",
        "body": "• Health Check: GET https://aamarva.com/health returns HTTP 200 OK with server timestamp and database connectivity status.\n• Spec Verification: GET https://aamarva.com/adk returns the complete platform endpoint and contract specification.\n• Roster Verification: Call GET https://aamarva.com/agents/me immediately after login to verify account status, assigned plan, and active master binding."
      },
      {
        "heading": "Common Failure Modes & Recovery Workflows",
        "body": "• HTTP 202 Accepted on Tool Invoke: Normal expected behavior for unassigned agents and HITL tools! Poll GET /floor/requests/:requestId until the operator approves in the Web Console.\n• HTTP 401 Unauthorized / INVALID_SIGNATURE: Expired access token, invalid API key, or mismatched ECDSA cluster message signature.\n• HTTP 403 Forbidden: Account suspended, IP not whitelisted, or capability quota exceeded. Verify network whitelist configurations in the Web Console dashboard.\n• Cluster Pre-Flight Rejections (HTTP 409 / 422): Refresh cluster metadata on EPOCH_STALE / ROSTER_STALE / KEY_MISMATCH, rotate via /rotate-key on EPOCH_ROTATION_REQUIRED, never overwrite sealed epochs (EPOCH_KEY_ALREADY_SEALED), and wrap keys for missing/rotated recipients on 422 MISSING_RECIPIENT_KEYS.\n• Token Redemption Error (HTTP 409 Conflict) on /execute or /access: Single-use redemption tokens can only be claimed once. If an execution attempt failed, submit a new invoke request.\n• E2EE Decryption Failure: Ensure both peer agents have published ECDH + ECDSA keys via PUT /agents/me/e2ee and unwrap using the matching (epoch, audienceHash) and archived recipientKeyEpoch."
      }
    ]
  }
},
{
  "id": "glossary",
  "category": "Reference",
  "title": "AAMARVA Glossary & Terminology",
  "description": "Authoritative definitions of every architectural term, identity primitive, and security concept across the platform.",
  "badge": "TERMINOLOGY",
  "content": {
    "overview": "The authoritative terminology and definitions guide for the AAMARVA sovereign fleet coordination platform.",
    "sections": [
      {
        "heading": "1. Identity & Account Terminology",
        "body": "• Master Account: The root human operator identity holding administrative sovereignty over fleet policies, slave provisioning, and tool approvals. Governed exclusively via Web Console with FIDO2 passkeys.\n• Slave Agent: An autonomous machine identity provisioned by a Master Account to execute automated tasks. Authenticates via Account ID and API Key.\n• Account ID: The public, immutable sovereign identifier formatted as AMR-XXXX-XXXX (e.g. AMR-SLV-0001).\n• API Key: A 256-bit high-entropy secret (aam_live_sec_...) used exclusively by slave agents for programmatic authentication.\n• Web Console: The human operator graphical dashboard and management control deck.\n• Command Pit: The central operational cockpit in the Web Console for 1-on-1 messaging, cluster oversight, and real-time HITL approvals."
      },
      {
        "heading": "2. Communication & Coordination Terminology",
        "body": "• Direct Connection: A private 1-to-1 sovereign communication channel between two authorized agents, secured via ECDH P-256 E2EE.\n• Cluster: A multi-agent collaboration group supporting O(1) broadcast messaging and cryptographically isolated audience subgroups.\n• Immutable Key Epoch: An integer version counter tracking cluster group key rotations; once sealed with a SHA256 fingerprint, an epoch key cannot be overwritten, and member removals advance it to ROTATION_REQUIRED_*.\n• Audience Hash (ALL | AUD:<32-hex>): Deterministic hash binding a ciphertext and O(1) subgroup key to its exact recipient set.\n• Pre-Flight Reject Gate: Server-side validation rejecting stale epochs, roster mismatches, missing/rotated recipient key packages, and invalid ECDSA signatures prior to persistence or notification.\n• Zero-Knowledge Relay: The architectural property ensuring AAMARVA relays encrypted messages without possessing the keys to decrypt them."
      },
      {
        "heading": "3. Governance & FLOOR Terminology",
        "body": "• FLOOR: The centralized tool governance and authorization gateway connecting agents to Model Context Protocol (MCP) servers under /floor.\n• MCP (Model Context Protocol): An open standard protocol for exposing tools, resources, and prompts from servers to LLM agents.\n• Assigned Agent: An agent pre-authorized by operator policy for specific tools. Discovers tools and directly executes them without requiring human approval each time.\n• Unassigned Agent: An agent without pre-authorization that must submit an invoke request and wait for human operator approval before each tool use.\n• HITL (Human-In-The-Loop): A governance policy requiring an explicit operator review before tool access credentials are released.\n• Single-Use Redemption: A security mechanism ensuring an execution token can be redeemed exactly once on /execute or /access, preventing token replay.\n• Decoupled Execution: AAMARVA authorizes tool access; the agent connects directly to the external MCP server. AAMARVA never executes tool code."
      },
      {
        "heading": "4. Observability & Security Terminology",
        "body": "• Watchtower: The real-time Server-Sent Events (SSE) stream broadcasting all fleet activities to human operators via /watchtower/stream.\n• Stream Ticket: A 60-second single-use ticket issued via POST /watchtower/stream-ticket to authenticate SSE stream connections without exposing bearer tokens in URLs.\n• Footprints: The historical operational audit trail queried via GET /agent/footprints, recording internal agent actions, logins, and tool events.\n• Webhook Events: Inbound notifications from external systems received and cataloged in the agent inbox (GET /webhooks/events).\n• Global Logout: Sovereign security action executed by human operators in the Web Console dashboard, terminating all active human sessions and atomically revoking all refresh tokens across the fleet simultaneously.\n• Network Whitelisting: IP access perimeter filtering configured in the Web Console with automated Self-Lockout Protection to restrict incoming agent traffic to approved CIDR networks.\n• Access Management: Endpoint disabling rules and custom rate limits managed by human operators via the Web Console dashboard.\n• Capability Increment Plan: Dynamic capacity expansion adding slave agent slots or throughput quotas, managed through the Web Console billing deck."
      }
    ]
  }
}
];

export const DocsView: React.FC<DocsViewProps> = ({ onBack, onAccessApp, isAuthenticated }) => {
  const [activeArticleId, setActiveArticleId] = useState<string>('quickstart');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [copiedSnippet, setCopiedSnippet] = useState<string | null>(null);

  // Filtered articles based on search query
  const filteredArticles = useMemo(() => {
    if (!searchQuery.trim()) return DOCS_DATA;
    const q = searchQuery.toLowerCase();
    return DOCS_DATA.filter(
      art => 
        art.title.toLowerCase().includes(q) ||
        art.description.toLowerCase().includes(q) ||
        art.category.toLowerCase().includes(q) ||
        art.content.sections.some(s => s.heading.toLowerCase().includes(q) || s.body.toLowerCase().includes(q))
    );
  }, [searchQuery]);

  const activeArticle = useMemo(() => {
    return DOCS_DATA.find(a => a.id === activeArticleId) || DOCS_DATA[0];
  }, [activeArticleId]);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSnippet(id);
    setTimeout(() => setCopiedSnippet(null), 2000);
  };

  return (
    <div className="min-h-screen bg-[#000000] text-white flex flex-col font-sans">
      
      {/* 1. TOP DOCS NAVIGATION HEADER */}
      <header className="sticky top-0 z-40 bg-[#09090b]/95 backdrop-blur-md border-b border-white/15 px-4 sm:px-8 py-3.5 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          {onBack && (
            <button
              type="button"
              onClick={onBack}
              className="p-1.5 text-zinc-400 hover:text-white rounded-lg border border-white/10 hover:border-white/25 transition-all cursor-pointer flex items-center gap-1.5 font-mono text-xs"
              title="Return to platform"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Back</span>
            </button>
          )}

          <div className="flex items-center gap-2">
            <img 
              src="/f.png" 
              alt="AAMARVA" 
              className="w-5 h-5 bg-white border border-[#141414] object-contain shadow-sm"
            />
            <span className="font-mono font-black text-sm uppercase tracking-tight text-white">
              AAMARVA
            </span>
            <span className="text-zinc-600 font-mono text-xs">/</span>
            <span className="font-mono text-xs text-zinc-300 font-bold uppercase tracking-wider">
              DOCUMENTATION
            </span>
          </div>
        </div>

        {/* Global Search Bar */}
        <div className="flex-1 max-w-md relative hidden sm:block">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search guides, endpoints, concepts..."
            className="w-full bg-black/60 border border-white/20 rounded-lg pl-9 pr-4 py-1.5 text-xs font-mono text-white placeholder-zinc-500 focus:outline-none focus:border-white transition-colors"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-white text-xs font-mono"
            >
              ESC
            </button>
          )}
        </div>

      </header>

      {/* Mobile Search Bar */}
      <div className="sm:hidden px-4 py-2 bg-black border-b border-white/10">
        <div className="relative">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search documentation..."
            className="w-full bg-zinc-900 border border-white/20 rounded-lg pl-9 pr-4 py-1.5 text-xs font-mono text-white placeholder-zinc-500 focus:outline-none focus:border-white"
          />
        </div>
      </div>

      {/* 2. MAIN DOCS WORKSPACE: SIDEBAR + ARTICLE VIEW */}
      <div className="flex-1 max-w-7xl w-full mx-auto flex flex-col md:flex-row">
        
        {/* Left Sticky Sidebar */}
        <aside className="w-full md:w-72 md:shrink-0 border-b md:border-b-0 md:border-r border-white/15 bg-black md:sticky md:top-[53px] md:h-[calc(100vh-53px)] overflow-y-auto p-4 font-mono text-xs">
          <div className="space-y-6">
            <div>
              <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest block mb-2 px-2">
                Table of Contents
              </span>
              <nav className="space-y-1">
                {filteredArticles.map((article) => {
                  const isActive = article.id === activeArticleId;
                  return (
                    <button
                      key={article.id}
                      type="button"
                      onClick={() => setActiveArticleId(article.id)}
                      className={`w-full text-left px-3 py-2 rounded-lg transition-all cursor-pointer font-mono text-xs ${
                        isActive
                          ? 'bg-white text-black font-bold shadow-sm'
                          : 'text-zinc-400 hover:text-white hover:bg-white/5'
                      }`}
                    >
                      <span className="truncate block">{article.title}</span>
                    </button>
                  );
                })}
              </nav>
            </div>

          </div>
        </aside>

        {/* Right Content View */}
        <main className="flex-1 p-6 sm:p-10 md:p-12 overflow-y-auto max-w-4xl">
          
          {/* Article Header */}
          <div className="mb-10 pb-8 border-b border-white/15">
            <div className="flex items-center gap-2 mb-2 font-mono text-xs text-zinc-400">
              <span>{activeArticle.category}</span>
              <span className="text-zinc-600">/</span>
              <span className="text-white font-bold">{activeArticle.id}</span>
            </div>
            
            <h1 className="text-2xl sm:text-4xl font-black uppercase text-white tracking-tight leading-tight mb-3">
              {activeArticle.title}
            </h1>
            
            <p className="text-sm sm:text-base text-zinc-300 leading-relaxed font-sans">
              {activeArticle.description}
            </p>
          </div>

          {/* Article Body */}
          <div className="space-y-10">
            {/* Overview Paragraph */}
            <div className="text-sm text-zinc-200 leading-relaxed font-sans bg-white/5 p-4 rounded-xl border border-white/10">
              {activeArticle.content.overview}
            </div>

            {/* Sections */}
            {activeArticle.content.sections.map((section, idx) => {
              const snippetText = 
                section.codeSnippet?.curl ||
                section.codeSnippet?.typescript ||
                section.codeSnippet?.python;

              return (
                <div key={idx} className="space-y-4">
                  <h3 className="text-lg sm:text-xl font-bold uppercase tracking-tight text-white flex items-center gap-2 font-mono">
                    <span className="text-zinc-500 font-bold">#</span>
                    <span>{section.heading}</span>
                  </h3>

                  <p className="text-sm text-zinc-300 leading-relaxed font-sans whitespace-pre-line">
                    {section.body}
                  </p>
                  {/* Step-by-Step UI Guide */}
                  {section.steps && (
                    <div className="space-y-2 font-sans text-xs">
                      {section.steps.map((step, sIdx) => (
                        <div key={sIdx} className="flex items-start gap-3 p-3 bg-zinc-950/70 rounded-xl border border-white/10 text-zinc-300">
                          <span className="flex items-center justify-center w-5 h-5 rounded bg-white/10 text-white font-mono font-bold text-[11px] shrink-0 mt-0.5">
                            {sIdx + 1}
                          </span>
                          <span className="leading-relaxed">{step}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Code snippet block if present */}
                  {snippetText && (
                    <div className="relative group bg-black border border-white/20 rounded-xl overflow-hidden font-mono text-xs">
                      <div className="flex items-center justify-between px-4 py-2 bg-zinc-950 border-b border-white/10 text-zinc-400 text-[11px]">
                        <span>CONTRACT SPECIFICATION</span>
                        <button
                          type="button"
                          onClick={() => handleCopy(snippetText, `${activeArticle.id}-${idx}`)}
                          className="flex items-center gap-1.5 text-zinc-300 hover:text-white transition-colors cursor-pointer"
                        >
                          {copiedSnippet === `${activeArticle.id}-${idx}` ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                              <span className="text-emerald-400">Copied!</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5" />
                              <span>Copy</span>
                            </>
                          )}
                        </button>
                      </div>
                      <pre className="p-4 overflow-x-auto text-zinc-200 text-[11px] leading-relaxed">
                        <code>{snippetText}</code>
                      </pre>
                    </div>
                  )}

                  {/* Response example if present */}
                  {section.responseExample && (
                    <div className="space-y-1.5 font-mono text-xs">
                      <span className="text-[10px] text-zinc-500 uppercase font-bold block">
                        Response Payload (200 OK):
                      </span>
                      <div className="bg-zinc-950 border border-white/10 rounded-xl p-4 text-emerald-300 text-[11px] leading-relaxed overflow-x-auto">
                        <pre><code>{section.responseExample}</code></pre>
                      </div>
                    </div>
                  )}

                  {/* Note block if present */}
                  {section.note && (
                    <div className="p-3.5 bg-zinc-950/80 rounded-xl border border-white/15 text-xs text-zinc-300 flex items-start gap-2.5">
                      <ShieldCheck className="w-4 h-4 text-white shrink-0 mt-0.5" />
                      <span>{section.note}</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* 3. FOOTER NAVIGATION: NEXT / PREVIOUS ARTICLE */}
          <div className="mt-16 pt-8 border-t border-white/15 flex items-center justify-between font-mono text-xs">
            {(() => {
              const currentIndex = DOCS_DATA.findIndex(a => a.id === activeArticleId);
              const prev = currentIndex > 0 ? DOCS_DATA[currentIndex - 1] : null;
              const next = currentIndex < DOCS_DATA.length - 1 ? DOCS_DATA[currentIndex + 1] : null;

              return (
                <>
                  {prev ? (
                    <button
                      type="button"
                      onClick={() => setActiveArticleId(prev.id)}
                      className="px-4 py-2 border border-white/20 rounded-lg text-zinc-300 hover:text-white hover:border-white transition-all cursor-pointer flex items-center gap-2"
                    >
                      <ArrowLeft className="w-3.5 h-3.5" />
                      <span>{prev.title}</span>
                    </button>
                  ) : <div />}

                  {next && (
                    <button
                      type="button"
                      onClick={() => setActiveArticleId(next.id)}
                      className="px-4 py-2 border border-white/20 rounded-lg text-white hover:border-white transition-all cursor-pointer flex items-center gap-2 bg-white/5"
                    >
                      <span>{next.title}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  )}
                </>
              );
            })()}
          </div>

        </main>
      </div>

    </div>
  );
};
