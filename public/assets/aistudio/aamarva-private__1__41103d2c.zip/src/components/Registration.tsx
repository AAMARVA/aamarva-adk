import React, { useState, useEffect, useRef } from 'react';
import { X, User, Mail, Lock, Eye, EyeOff, AlertCircle, CheckCircle2, Copy, Upload, Image as ImageIcon } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { BrutalistLoader } from './BrutalistLoader';
import { AgentAvatar } from './AgentAvatar';

import { checkRegistrationLinkStatusApi, getPrefetchedRegistrationLinkStatusSync } from '../services/authApi';

export interface RegistrationProps {
  isOpen: boolean;
  initialEmail?: string;
  initialFleetId?: string;
  slotToken?: string;
  isFromInviteLink?: boolean;
  onClose: () => void;
  onSwitchToLogin?: () => void;
  onSuccess?: () => void;
}
export type FloorRegistrationModalProps = RegistrationProps;

export const Registration: React.FC<RegistrationProps> = ({
  isOpen,
  initialEmail = '',
  initialFleetId = '',
  slotToken = '',
  isFromInviteLink = false,
  onClose,
  onSwitchToLogin,
  onSuccess,
}) => {
  const { register } = useAuth();
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    profileAvatar: '',
    password: '',
    confirmPassword: '',
    fleetId: '',
  });
  const [avatarFileName, setAvatarFileName] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [registeredCredentials, setRegisteredCredentials] = useState<{
    agentId: string;
    apiKey: string;
  } | null>(null);
  const [copiedKey, setCopiedKey] = useState(false);
  const [copiedAgentId, setCopiedAgentId] = useState(false);
  const initialPrefetch =
    isOpen && isFromInviteLink
      ? getPrefetchedRegistrationLinkStatusSync({ email: initialEmail, fleetId: initialFleetId, slotToken })
      : null;
  const [isCheckingLink, setIsCheckingLink] = useState(
    () => Boolean(isOpen && isFromInviteLink && (initialEmail?.trim() || initialFleetId?.trim() || slotToken?.trim()) && !initialPrefetch)
  );
  const [linkExpiredMessage, setLinkExpiredMessage] = useState<string | null>(() =>
    initialPrefetch?.expired
      ? (initialPrefetch.message || 'This registration link has expired because it has already been used to complete registration.')
      : null
  );

  const handleAvatarFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 10 * 1024 * 1024) {
      setSubmitError('Image file size must be less than 10MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const rawDataUrl = event.target?.result as string;
      if (!rawDataUrl) return;

      const img = new Image();
      img.onload = () => {
        const MAX_SIZE = 512;
        let width = img.width;
        let height = img.height;
        if (width > MAX_SIZE || height > MAX_SIZE) {
          if (width > height) {
            height = Math.round((height * MAX_SIZE) / width);
            width = MAX_SIZE;
          } else {
            width = Math.round((width * MAX_SIZE) / height);
            height = MAX_SIZE;
          }
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const compressed = canvas.toDataURL('image/jpeg', 0.85);
          setFormData(prev => ({ ...prev, profileAvatar: compressed }));
          setAvatarFileName(file.name);
          setSubmitError('');
        } else {
          setFormData(prev => ({ ...prev, profileAvatar: rawDataUrl }));
          setAvatarFileName(file.name);
          setSubmitError('');
        }
      };
      img.onerror = () => {
        setFormData(prev => ({ ...prev, profileAvatar: rawDataUrl }));
        setAvatarFileName(file.name);
        setSubmitError('');
      };
      img.src = rawDataUrl;
    };
    reader.onerror = () => {
      setSubmitError('Failed to read image file.');
    };
    reader.readAsDataURL(file);
  };

  useEffect(() => {
    if (!isOpen) {
      setLinkExpiredMessage(null);
      setIsCheckingLink(false);
      return;
    }

    setFormData((prev) => ({
      ...prev,
      email: initialEmail ? initialEmail : prev.email,
      fleetId: initialFleetId ? initialFleetId : prev.fleetId,
    }));

    const hasLinkParams = Boolean(
      isFromInviteLink && (initialEmail?.trim() || initialFleetId?.trim() || slotToken?.trim())
    );
    if (!hasLinkParams) {
      setLinkExpiredMessage(null);
      setIsCheckingLink(false);
      return;
    }

    const syncStatus = getPrefetchedRegistrationLinkStatusSync({
      email: initialEmail,
      fleetId: initialFleetId,
      slotToken,
    });
    if (syncStatus) {
      setLinkExpiredMessage(
        syncStatus.expired
          ? (syncStatus.message ||
              'This registration link has expired because it has already been used to complete registration.')
          : null
      );
      setIsCheckingLink(false);
      return;
    }

    let cancelled = false;
    setIsCheckingLink(true);
    setLinkExpiredMessage(null);

    checkRegistrationLinkStatusApi({
      email: initialEmail,
      fleetId: initialFleetId,
      slotToken,
    })
      .then((status) => {
        if (cancelled) return;
        if (status?.expired) {
          setLinkExpiredMessage(
            status.message ||
              'This registration link has expired because it has already been used to complete registration.'
          );
        }
      })
      .catch(() => {
        // Non-blocking fallback: server enforces single-use check on POST /api/auth/register
      })
      .finally(() => {
        if (!cancelled) setIsCheckingLink(false);
      });

    return () => {
      cancelled = true;
    };
  }, [isOpen, initialEmail, initialFleetId, slotToken, isFromInviteLink]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.fullName.trim() && formData.fullName.trim().length < 2) {
      setSubmitError('Name must be at least 2 characters.');
      return;
    }

    if (formData.fullName.trim().length > 100) {
      setSubmitError('Name cannot exceed 100 characters.');
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      setSubmitError('Passwords do not match.');
      return;
    }

    if (formData.password.length < 8) {
      setSubmitError('Password must be at least 8 characters long.');
      return;
    }

    if (!formData.profileAvatar.trim()) {
      setSubmitError('Profile Avatar is required.');
      return;
    }

    setIsSubmitting(true);
    setSubmitError('');

    try {
      const emailToRegister = formData.email.trim();
      const result = await register(
        emailToRegister,
        formData.password,
        formData.fullName.trim() || undefined,
        undefined,
        undefined,
        formData.profileAvatar.trim(),
        formData.fleetId.trim()
      );

      if (onSuccess) {
        onSuccess();
      }

      setRegisteredCredentials({
        agentId: result.agentId || emailToRegister,
        apiKey: result.apiKey || ''
      });
      setIsSubmitting(false);
    } catch (err: any) {
      if (err?.code === 'REGISTRATION_LINK_EXPIRED') {
        setLinkExpiredMessage(
          err?.message ||
            'This registration link has expired because it has already been used to complete registration.'
        );
      } else {
        setSubmitError(err?.message || 'Registration failed. Please try again.');
      }
      setIsSubmitting(false);
    }
  };

  const handleCopy = (text: string, type: 'agentId' | 'key') => {
    navigator.clipboard.writeText(text);
    if (type === 'agentId') {
      setCopiedAgentId(true);
      setTimeout(() => setCopiedAgentId(false), 2000);
    } else {
      setCopiedKey(true);
      setTimeout(() => setCopiedKey(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-sm p-4 sm:p-8 flex items-center justify-center animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-[#F8F7F4] border-4 border-[#141414] shadow-[12px_12px_0px_0px_rgba(20,20,20,1)] text-[#141414] my-auto">
        {/* Top Header Bar */}
        <div className="bg-[#141414] text-white px-4 py-3 flex items-center justify-between border-b-4 border-[#141414] select-none">
          <span className="font-mono text-xs font-black uppercase tracking-widest">
            {linkExpiredMessage
              ? 'LINK EXPIRED'
              : registeredCredentials
              ? 'REGISTRATION COMPLETE'
              : ''}
          </span>
          <button
            onClick={onClose}
            className="p-1 bg-white text-[#141414] border-2 border-white hover:bg-black hover:text-white transition-colors cursor-pointer"
            title="Close modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 sm:p-8 space-y-6">
          {isCheckingLink ? (
            <div className="py-12 flex flex-col items-center justify-center gap-4">
              <BrutalistLoader />
              <span className="font-mono text-xs font-bold uppercase tracking-widest">
                Verifying registration link...
              </span>
            </div>
          ) : linkExpiredMessage ? (
            <div className="space-y-6">
              <div className="border-b-2 border-[#141414] pb-4 flex items-start gap-3">
                <AlertCircle className="w-6 h-6 text-[#141414] shrink-0 mt-0.5" />
                <div>
                  <h2 className="text-xl sm:text-2xl font-black uppercase tracking-tight text-[#141414]">
                    Registration Link Expired
                  </h2>
                  <p className="font-mono text-xs text-[#141414]/80 mt-1.5 leading-relaxed">
                    {linkExpiredMessage}
                  </p>
                </div>
              </div>

              <div className="p-3 bg-[#E4E3E0] border-2 border-[#141414] font-mono text-xs text-[#141414] leading-relaxed">
                This invitation link is single-use and is no longer valid once an account has been registered through it. Please sign in with your registered email and password.
              </div>

              <div className="pt-1 flex flex-col gap-2.5">
                {onSwitchToLogin && (
                  <button
                    type="button"
                    onClick={onSwitchToLogin}
                    className="w-full py-3 bg-[#141414] text-white font-mono text-xs font-black uppercase tracking-widest hover:bg-black transition-colors border-2 border-[#141414] shadow-[4px_4px_0px_0px_rgba(20,20,20,1)] cursor-pointer"
                  >
                    Sign In Instead
                  </button>
                )}
                <button
                  type="button"
                  onClick={onClose}
                  className="w-full py-2.5 bg-white text-[#141414] font-mono text-xs font-black uppercase tracking-widest hover:bg-[#E4E3E0] transition-colors border-2 border-[#141414] cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>
          ) : registeredCredentials ? (
            <div className="space-y-6">
              <div className="border-b-2 border-[#141414] pb-4">
                <h2 className="text-2xl font-black uppercase tracking-tight text-[#141414]">
                  Account Live & Active
                </h2>
                <p className="font-mono text-xs text-[#141414]/70 mt-1">
                  Your email has been registered. You can now login with the password and the email.
                </p>
              </div>

              {/* Registered Email Box */}
              <div className="space-y-4 font-mono">
                <div className="space-y-1">
                  <span className="text-[10px] font-black uppercase text-[#141414] tracking-wider block">
                    [01] REGISTERED EMAIL
                  </span>
                  <div className="flex items-center justify-between bg-white border-2 border-[#141414] p-2.5 shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]">
                    <span className="font-mono text-xs sm:text-sm font-black text-[#141414] tracking-wider select-all break-all">
                      {formData.email}
                    </span>
                    <button
                      type="button"
                      onClick={() => handleCopy(formData.email, 'agentId')}
                      className="p-1 hover:bg-[#E4E3E0] transition-colors border border-[#141414] ml-2 shrink-0 cursor-pointer"
                      title="Copy Email"
                    >
                      {copiedAgentId ? <CheckCircle2 className="w-4 h-4 text-[#141414]" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div className="p-3 bg-[#141414] text-white border-2 border-[#141414] text-xs font-mono leading-relaxed">
                  Your email has been registered. You can now login with the password and the email.
                </div>
              </div>

              <div className="pt-2 space-y-3">
                <button
                  type="button"
                  onClick={async () => {
                    try {
                      setIsSubmitting(true);
                      const { loginUserApi } = await import('../services/authApi');
                      const loginRes = await loginUserApi({ agentId: registeredCredentials?.agentId || formData.email.trim(), password: formData.password });
                      if (loginRes?.requiresWebAuthnSetup && (window as any).__triggerWebAuthnSetup) {
                        onClose();
                        await (window as any).__triggerWebAuthnSetup(loginRes.pendingToken, loginRes.options, loginRes.user?.name || formData.fullName || 'Operator');
                      } else {
                        onClose();
                        window.location.reload();
                      }
                    } catch (err: any) {
                      setSubmitError(err?.message || 'Failed to initialize session.');
                      setIsSubmitting(false);
                    }
                  }}
                  disabled={isSubmitting}
                  className="w-full py-3.5 bg-[#141414] text-white font-mono text-xs font-black uppercase tracking-widest hover:bg-black transition-colors border-2 border-[#141414] shadow-[4px_4px_0px_0px_rgba(20,20,20,1)] cursor-pointer flex items-center justify-center gap-2"
                >
                  {isSubmitting ? 'Authenticating...' : 'Setup WebAuthn Passkey & Enter App'}
                </button>

                <button
                  type="button"
                  onClick={onClose}
                  className="w-full py-2.5 bg-[#141414] text-white font-mono text-xs font-black uppercase tracking-widest hover:bg-black transition-colors border-2 border-[#141414] shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] cursor-pointer"
                >
                  Enter Application Directly
                </button>
              </div>
            </div>
          ) : (
            <>


              {submitError && (
                <div className="p-3 bg-[#E4E3E0] border-2 border-[#141414] text-[#141414] text-xs font-mono flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-[#141414]" />
                  <span className="break-words">{submitError}</span>
                </div>
              )}

              {isSubmitting ? (
                <div className="py-12 flex flex-col items-center justify-center gap-4">
                  <BrutalistLoader />
                  <span className="font-mono text-xs font-bold uppercase tracking-widest">
                    Minting cryptographic credentials...
                  </span>
                </div>
              ) : (
                  <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block font-mono text-[10px] font-black uppercase tracking-wider text-[#141414]">
                        Agent / Operator Name
                      </label>
                      <span className="font-mono text-[9px] font-bold text-[#141414]/60">
                        MIN 2 | MAX 100 ({formData.fullName.length})
                      </span>
                    </div>
                    <div className="relative">
                      <input
                        type="text"
                        minLength={2}
                        maxLength={100}
                        value={formData.fullName}
                        onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                        placeholder="Alpha Agent"
                        className="w-full bg-white border-2 border-[#141414] px-3 py-2 text-xs font-mono text-[#141414] focus:outline-none focus:ring-2 focus:ring-[#141414] shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]"
                      />
                      <User className="absolute right-3 top-2.5 w-4 h-4 text-[#141414]/40" />
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block font-mono text-[10px] font-black uppercase tracking-wider text-[#141414]">
                        Email Address *
                      </label>
                      <span className="font-mono text-[9px] font-bold text-[#141414]/60">
                        MIN 5 | MAX 254 ({formData.email.length})
                      </span>
                    </div>
                    <div className="relative">
                      <input
                        type="email"
                        required
                        minLength={5}
                        maxLength={254}
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        placeholder="operator@example.com"
                        className="w-full bg-white border-2 border-[#141414] px-3 py-2 text-xs font-mono text-[#141414] focus:outline-none focus:ring-2 focus:ring-[#141414] shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]"
                      />
                      <Mail className="absolute right-3 top-2.5 w-4 h-4 text-[#141414]/40" />
                    </div>
                  </div>

                  <div>
                    <label className="block font-mono text-[10px] font-black uppercase tracking-wider text-[#141414] mb-1">
                      Profile Avatar *
                    </label>
                    <div className="flex items-center gap-2">
                      <label 
                        htmlFor="floor-avatar-upload"
                        className="relative flex-1 flex items-center cursor-pointer group"
                      >
                        <input
                          type="text"
                          readOnly
                          value={avatarFileName}
                          placeholder="Choose image file..."
                          className="w-full bg-white border-2 border-[#141414] pl-3 pr-24 py-2 text-xs font-mono text-[#141414] focus:outline-none cursor-pointer select-none pointer-events-none placeholder:text-[#141414]/40"
                        />
                        <span
                          className="absolute right-1 px-2.5 py-1 bg-[#141414] text-white hover:bg-neutral-800 text-[10px] font-mono font-bold uppercase flex items-center gap-1 border border-[#141414] cursor-pointer select-none transition-colors"
                        >
                          <Upload className="w-3 h-3" />
                          <span>Upload</span>
                        </span>
                      </label>
                      <input
                        id="floor-avatar-upload"
                        ref={fileInputRef}
                        type="file"
                        accept="image/*"
                        onChange={handleAvatarFileUpload}
                        onClick={(e) => {
                          (e.target as HTMLInputElement).value = '';
                        }}
                        style={{ position: 'fixed', top: '-1000px', left: '-1000px', opacity: 0, width: '1px', height: '1px' }}
                        tabIndex={-1}
                        aria-hidden="true"
                      />

                      {/* Avatar preview */}
                      <label 
                        htmlFor="floor-avatar-upload"
                        className="w-9 h-9 shrink-0 bg-white border-2 border-[#141414] shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] flex items-center justify-center overflow-hidden cursor-pointer hover:bg-neutral-50 transition-colors"
                        title="Upload avatar image"
                      >
                        {formData.profileAvatar ? (
                          <AgentAvatar
                            avatar={formData.profileAvatar}
                            name={formData.fullName || 'Agent'}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <User className="w-4 h-4 text-[#141414]/30" />
                        )}
                      </label>
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block font-mono text-[10px] font-black uppercase tracking-wider text-[#141414]">
                        Password *
                      </label>
                      <span className="font-mono text-[9px] font-bold text-[#141414]/60">
                        MIN 8 | MAX 128 ({formData.password.length})
                      </span>
                    </div>
                    <div className="relative">
                      <input
                        type={showPassword ? 'text' : 'password'}
                        required
                        minLength={8}
                        maxLength={128}
                        value={formData.password}
                        onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                        placeholder="••••••••••••"
                        className="w-full bg-white border-2 border-[#141414] px-3 py-2 text-xs font-mono text-[#141414] focus:outline-none focus:ring-2 focus:ring-[#141414] shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] pr-10"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-2.5 text-[#141414]/50 hover:text-[#141414] cursor-pointer"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block font-mono text-[10px] font-black uppercase tracking-wider text-[#141414]">
                        Confirm Password *
                      </label>
                      <span className="font-mono text-[9px] font-bold text-[#141414]/60">
                        MIN 8 | MAX 128 ({formData.confirmPassword.length})
                      </span>
                    </div>
                    <div className="relative">
                      <input
                        type={showConfirmPassword ? 'text' : 'password'}
                        required
                        minLength={8}
                        maxLength={128}
                        value={formData.confirmPassword}
                        onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                        placeholder="••••••••••••"
                        className="w-full bg-white border-2 border-[#141414] px-3 py-2 text-xs font-mono text-[#141414] focus:outline-none focus:ring-2 focus:ring-[#141414] shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] pr-10"
                      />
                      <button
                        type="button"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                        className="absolute right-3 top-2.5 text-[#141414]/50 hover:text-[#141414] cursor-pointer"
                      >
                        {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block font-mono text-[10px] font-black uppercase tracking-wider text-[#141414]">
                        Fleet ID
                      </label>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-[9px] font-bold text-[#141414]/60">
                          MAX 100 ({formData.fleetId.length})
                        </span>
                        <span className="font-mono text-[9px] font-black uppercase tracking-wider px-2 py-0.5 bg-[#141414] text-white">
                          OPTIONAL
                        </span>
                      </div>
                    </div>
                    <div className="relative">
                      <input
                        type="text"
                        maxLength={100}
                        value={formData.fleetId}
                        onChange={(e) => setFormData({ ...formData, fleetId: e.target.value })}
                        className="w-full bg-white border-2 border-[#141414] px-3 py-2 text-xs font-mono text-[#141414] focus:outline-none focus:ring-2 focus:ring-[#141414] shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]"
                      />
                    </div>
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full py-3 bg-[#141414] text-white font-mono text-xs font-black uppercase tracking-widest hover:bg-black transition-colors border-2 border-[#141414] shadow-[4px_4px_0px_0px_rgba(20,20,20,1)] cursor-pointer"
                    >
                      Complete Registration
                    </button>
                  </div>

                  {onSwitchToLogin && (
                    <div className="text-center pt-2">
                      <button
                        type="button"
                        onClick={onSwitchToLogin}
                        className="font-mono text-xs text-[#141414]/70 hover:text-[#141414] hover:underline cursor-pointer"
                      >
                        Already have credentials? Sign In
                      </button>
                    </div>
                  )}
                </form>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export const FloorRegistrationModal = Registration;
export const RegistrationModal = Registration;
export default Registration;
