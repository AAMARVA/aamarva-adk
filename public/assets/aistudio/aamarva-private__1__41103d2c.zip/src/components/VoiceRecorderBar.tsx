import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Play, Pause, Square, Trash2, ChevronUp } from 'lucide-react';
import { VoiceRecordingState } from '../hooks/useVoiceRecorder';

interface VoiceRecorderBarProps {
  state: VoiceRecordingState;
  duration: number;
  audioUrl: string | null;
  audioBlob?: Blob | null;
  isSending: boolean;
  onStop: () => void;
  onCancel: () => void;
  onSend: () => void;
  accompanyingText?: string;
  onTextChange?: (text: string) => void;
}

function formatDuration(seconds: number): string {
  if (isNaN(seconds) || seconds < 0) return '0:00';
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

export const VoiceRecorderBar: React.FC<VoiceRecorderBarProps> = ({
  state,
  duration,
  audioUrl,
  audioBlob,
  isSending,
  onStop,
  onCancel,
  onSend,
  accompanyingText = '',
  onTextChange,
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [playbackDuration, setPlaybackDuration] = useState(duration);
  const [waveSeed, setWaveSeed] = useState(0);
  const [playbackError, setPlaybackError] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Web Audio API Fallback state and refs
  const audioContextRef = useRef<AudioContext | null>(null);
  const audioBufferRef = useRef<AudioBuffer | null>(null);
  const bufferSourceRef = useRef<AudioBufferSourceNode | null>(null);
  const webAudioStartTimeRef = useRef<number>(0);
  const webAudioPauseOffsetRef = useRef<number>(0);
  const webAudioRafRef = useRef<number | null>(null);
  const isWebAudioRef = useRef<boolean>(false);

  const stopWebAudio = () => {
    if (webAudioRafRef.current) {
      cancelAnimationFrame(webAudioRafRef.current);
      webAudioRafRef.current = null;
    }
    if (bufferSourceRef.current) {
      try {
        bufferSourceRef.current.onended = null;
        bufferSourceRef.current.stop();
        bufferSourceRef.current.disconnect();
      } catch {}
      bufferSourceRef.current = null;
    }
    isWebAudioRef.current = false;
  };

  useEffect(() => {
    setPlaybackDuration(duration);
  }, [duration]);

  useEffect(() => {
    setIsPlaying(false);
    setCurrentTime(0);
    setPlaybackError(null);
    stopWebAudio();
    audioBufferRef.current = null;
    webAudioPauseOffsetRef.current = 0;

    const audio = audioRef.current;
    if (audio) {
      if (audioUrl) {
        if (audio.src !== audioUrl) {
          audio.src = audioUrl;
        }
        if (audio.readyState === 0) {
          audio.load();
        }
      } else {
        if (audio.src) {
          audio.removeAttribute('src');
        }
      }
    }

    if (dynamicAudioRef.current) {
      try {
        dynamicAudioRef.current.pause();
        dynamicAudioRef.current.src = '';
      } catch {}
      dynamicAudioRef.current = null;
    }

    return () => {
      stopWebAudio();
      if (dynamicAudioRef.current) {
        try {
          dynamicAudioRef.current.pause();
          dynamicAudioRef.current.src = '';
        } catch {}
        dynamicAudioRef.current = null;
      }
      if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
        try {
          audioContextRef.current.close();
        } catch {}
        audioContextRef.current = null;
      }
    };
  }, [state, audioUrl]);

  // Subtle live waveform pulse during active recording
  useEffect(() => {
    if (state !== 'recording') return;
    const interval = setInterval(() => {
      setWaveSeed((prev) => (prev + 1) % 100);
    }, 120);
    return () => clearInterval(interval);
  }, [state]);

  const handleLoadedMetadata = () => {
    if (audioRef.current && audioRef.current.duration && isFinite(audioRef.current.duration)) {
      setPlaybackDuration(audioRef.current.duration);
    }
  };

  const handleTimeUpdate = () => {
    if (!isWebAudioRef.current && audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
    }
  };

  const handleEnded = () => {
    setIsPlaying(false);
    setCurrentTime(0);
  };

  const playViaWebAudio = async (startOffset: number = 0) => {
    if (!audioBlob) throw new Error('No audio blob available for fallback playback.');

    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioCtx) throw new Error('Web Audio playback is not supported on this device.');

    if (!audioContextRef.current || audioContextRef.current.state === 'closed') {
      audioContextRef.current = new AudioCtx();
    }
    const ctx = audioContextRef.current;
    if (ctx.state === 'suspended') {
      await ctx.resume();
    }

    if (!audioBufferRef.current) {
      const arrayBuffer = await audioBlob.arrayBuffer();
      audioBufferRef.current = await ctx.decodeAudioData(arrayBuffer);
    }
    const buffer = audioBufferRef.current;
    if (!buffer) throw new Error('Could not decode audio data buffer.');

    stopWebAudio();

    if (buffer.duration && isFinite(buffer.duration)) {
      setPlaybackDuration(buffer.duration);
    }

    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.connect(ctx.destination);

    const safeOffset = Math.max(0, Math.min(startOffset, buffer.duration));
    webAudioPauseOffsetRef.current = safeOffset;
    webAudioStartTimeRef.current = ctx.currentTime - safeOffset;
    isWebAudioRef.current = true;

    source.onended = () => {
      if (isWebAudioRef.current) {
        setIsPlaying(false);
        setCurrentTime(0);
        webAudioPauseOffsetRef.current = 0;
        isWebAudioRef.current = false;
        if (webAudioRafRef.current) {
          cancelAnimationFrame(webAudioRafRef.current);
          webAudioRafRef.current = null;
        }
      }
    };

    source.start(0, safeOffset);
    bufferSourceRef.current = source;
    setIsPlaying(true);
    setPlaybackError(null);

    const tick = () => {
      if (!isWebAudioRef.current || !audioContextRef.current) return;
      const elapsed = audioContextRef.current.currentTime - webAudioStartTimeRef.current;
      if (elapsed >= buffer.duration) {
        setCurrentTime(buffer.duration);
        setIsPlaying(false);
        isWebAudioRef.current = false;
        return;
      }
      setCurrentTime(elapsed);
      webAudioRafRef.current = requestAnimationFrame(tick);
    };
    webAudioRafRef.current = requestAnimationFrame(tick);
  };

  const dataUrlRef = useRef<string | null>(null);
  const dynamicAudioRef = useRef<HTMLAudioElement | null>(null);

  const getAudioDataUrl = useCallback(async (blob: Blob): Promise<string> => {
    if (dataUrlRef.current) return dataUrlRef.current;
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        dataUrlRef.current = result;
        resolve(result);
      };
      reader.onerror = () => reject(new Error('Failed to convert audio blob to data URL'));
      reader.readAsDataURL(blob);
    });
  }, []);

  const handleError = (e: React.SyntheticEvent<HTMLAudioElement, Event>) => {
    const audio = audioRef.current;
    if (
      !audioUrl ||
      !audio ||
      !audio.src ||
      !audio.currentSrc ||
      audio.readyState === 0 ||
      audio.networkState === HTMLMediaElement.NETWORK_EMPTY
    ) {
      return;
    }
    const diag = {
      blobSize: audioBlob?.size ?? (audioUrl ? 'url-provided' : 0),
      blobType: audioBlob?.type ?? 'unknown',
      canPlayType: audio.canPlayType(audioBlob?.type || 'audio/webm'),
      audioSrc: audio.src,
      audioCurrentSrc: audio.currentSrc,
      audioReadyState: audio.readyState,
      audioNetworkState: audio.networkState,
      audioDuration: audio.duration,
      audioErrorCode: audio.error?.code ?? null,
      audioErrorMessage: audio.error?.message ?? null,
    };
    console.warn('[VoiceRecorderBar] Preview audio error event:', diag, e);

    // If audio is actively playing and audioBlob is present, try data URL or Web Audio fallback seamlessly
    if (audioBlob && isPlaying) {
      getAudioDataUrl(audioBlob)
        .then((dUrl) => {
          if (audio) {
            audio.src = dUrl;
            return audio.play();
          }
        })
        .catch(() => {
          if (!isWebAudioRef.current) {
            return playViaWebAudio(currentTime);
          }
        })
        .catch((fallbackErr) => {
          setIsPlaying(false);
          setPlaybackError(`Audio playback error: ${fallbackErr?.message || audio.error?.message || 'Unsupported format'}`);
        });
      return;
    }

    setIsPlaying(false);
    if (isPlaying && audio.error && audio.error.code !== 0) {
      setPlaybackError(`Audio playback error (${audio.error.code}): ${audio.error.message || 'The audio format could not be played'}`);
    }
  };

  const togglePreviewPlay = async () => {
    const audio = audioRef.current;
    if (!audioUrl && !audioBlob) return;

    setPlaybackError(null);

    if (isPlaying) {
      if (isWebAudioRef.current) {
        if (audioContextRef.current) {
          webAudioPauseOffsetRef.current = audioContextRef.current.currentTime - webAudioStartTimeRef.current;
        }
        stopWebAudio();
        setIsPlaying(false);
      } else if (dynamicAudioRef.current) {
        dynamicAudioRef.current.pause();
        setIsPlaying(false);
      } else if (audio) {
        audio.pause();
        setIsPlaying(false);
      }
      return;
    }

    // Tier 1: Native HTMLAudioElement with blob URL
    try {
      if (audio && audioUrl) {
        if (audio.src !== audioUrl) {
          audio.src = audioUrl;
        }
        if (audio.readyState === 0) {
          audio.load();
        }

        if (audio.ended || (isFinite(audio.duration) && audio.duration > 0 && audio.currentTime >= audio.duration - 0.1)) {
          audio.currentTime = 0;
        }

        await audio.play();
        setIsPlaying(true);
        isWebAudioRef.current = false;
        return;
      }
    } catch (nativeErr: any) {
      console.warn('[VoiceRecorderBar] Tier 1 HTMLAudioElement play rejected, trying Tier 2 data URL:', nativeErr);
    }

    // Tier 2: HTMLAudioElement with Base64 data URL (immune to blob URL safety checks)
    if (audioBlob) {
      try {
        const dUrl = await getAudioDataUrl(audioBlob);
        if (audio) {
          audio.src = dUrl;
          if (audio.readyState === 0) {
            audio.load();
          }
          if (audio.ended || (isFinite(audio.duration) && audio.duration > 0 && audio.currentTime >= audio.duration - 0.1)) {
            audio.currentTime = 0;
          }
          await audio.play();
          setIsPlaying(true);
          isWebAudioRef.current = false;
          return;
        }
      } catch (tier2Err: any) {
        console.warn('[VoiceRecorderBar] Tier 2 data URL play rejected, trying Tier 3 in-memory audio:', tier2Err);
      }
    }

    // Tier 3: In-memory Audio instance
    if (audioBlob || audioUrl) {
      try {
        const sourceUrl = audioBlob ? await getAudioDataUrl(audioBlob) : audioUrl!;
        const dynAudio = new Audio(sourceUrl);
        dynamicAudioRef.current = dynAudio;
        dynAudio.onended = () => {
          setIsPlaying(false);
          setCurrentTime(0);
        };
        dynAudio.ontimeupdate = () => {
          setCurrentTime(dynAudio.currentTime);
        };
        if (dynAudio.duration && isFinite(dynAudio.duration)) {
          setPlaybackDuration(dynAudio.duration);
        }
        await dynAudio.play();
        setIsPlaying(true);
        isWebAudioRef.current = false;
        return;
      } catch (tier3Err: any) {
        console.warn('[VoiceRecorderBar] Tier 3 in-memory audio rejected, trying Tier 4 Web Audio API:', tier3Err);
      }
    }

    // Tier 4: Resilient Web Audio API playback
    if (audioBlob) {
      try {
        const resumePos = currentTime > 0 ? currentTime : webAudioPauseOffsetRef.current;
        await playViaWebAudio(resumePos);
        return;
      } catch (fallbackErr: any) {
        console.error('[VoiceRecorderBar] All playback tiers failed:', fallbackErr);
        setIsPlaying(false);
        setPlaybackError(fallbackErr?.message || 'Failed to play preview audio');
      }
    } else {
      setIsPlaying(false);
      setPlaybackError('Failed to play preview audio: Media format or security rejection');
    }
  };

  const handleWaveformClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const audio = audioRef.current;
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const ratio = Math.max(0, Math.min(1, clickX / rect.width));
    const effectiveDur = (audio && audio.duration && isFinite(audio.duration))
      ? audio.duration
      : (playbackDuration > 0 ? playbackDuration : duration);
    const targetTime = ratio * effectiveDur;
    setCurrentTime(targetTime);

    if (isWebAudioRef.current) {
      playViaWebAudio(targetTime).catch(console.warn);
    } else if (dynamicAudioRef.current) {
      dynamicAudioRef.current.currentTime = targetTime;
    } else if (audio) {
      audio.currentTime = targetTime;
    }
  };

  return (
    <div className="w-full">
      {/* Hidden DOM-bound HTML5 audio element */}
      <audio
        ref={audioRef}
        src={audioUrl || undefined}
        preload="auto"
        onLoadedMetadata={handleLoadedMetadata}
        onTimeUpdate={handleTimeUpdate}
        onEnded={handleEnded}
        onError={handleError}
        className="hidden"
      />

      {state === 'recording' && (
        <div className="flex items-center justify-between gap-2 sm:gap-3 px-3 py-2 w-full bg-white border-2 border-[#141414] shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] font-mono text-xs select-none">
          {/* Left: WhatsApp pulsing red recording dot + elapsed timer */}
          <div className="flex items-center gap-2 shrink-0">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-600" />
            </span>
            <span className="font-bold text-xs tracking-tight tabular-nums text-neutral-900">
              {formatDuration(duration)}
            </span>
          </div>

          {/* Center: Sleek, minimal WhatsApp soundwave animation */}
          <div className="flex items-center justify-center gap-[3px] flex-1 min-w-0 max-w-[240px] h-5 overflow-hidden mx-1">
            {Array.from({ length: 22 }).map((_, i) => {
              const wave = Math.abs(Math.sin((i * 0.45) + (waveSeed * 0.35)));
              const barH = Math.round(4 + wave * 14);
              return (
                <div
                  key={i}
                  className="w-[2.5px] rounded-full bg-neutral-800 transition-all duration-100 ease-out"
                  style={{ height: `${barH}px` }}
                />
              );
            })}
          </div>

          {/* Right: Actions: Trash & Stop/Review */}
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={onCancel}
              className="p-1.5 text-neutral-500 hover:text-red-600 hover:bg-neutral-100 rounded-sm transition-colors cursor-pointer"
              title="Discard recording"
            >
              <Trash2 className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={onStop}
              className="px-2.5 py-1 bg-[#141414] text-white hover:bg-black rounded-sm text-[11px] font-bold flex items-center gap-1.5 cursor-pointer shadow-[1px_1px_0px_0px_rgba(20,20,20,1)] active:translate-y-0.5 transition-transform"
              title="Stop recording and review"
            >
              <Square className="w-3 h-3 fill-current text-red-500" />
              <span className="tracking-wide">STOP</span>
            </button>
          </div>
        </div>
      )}

      {state === 'preview' && (
        <div className="flex items-center justify-between gap-2 sm:gap-3 px-3 py-2 w-full bg-white border-2 border-[#141414] shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] font-mono text-xs select-none">
          {/* Left: Play/Pause button */}
          <button
            type="button"
            onClick={togglePreviewPlay}
            disabled={isSending}
            className="w-7 h-7 rounded-full bg-[#141414] text-white flex items-center justify-center hover:bg-neutral-800 active:scale-95 transition-all cursor-pointer shrink-0 disabled:opacity-50"
            title={isPlaying ? 'Pause' : 'Play preview'}
          >
            {isPlaying ? (
              <Pause className="w-3.5 h-3.5 fill-current" />
            ) : (
              <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
            )}
          </button>

          {/* Center: Waveform scrubber */}
          <div
            onClick={handleWaveformClick}
            className="flex items-center gap-[3px] flex-1 min-w-0 max-w-[280px] h-6 cursor-pointer group py-1"
            title="Click to seek"
          >
            {Array.from({ length: 26 }).map((_, i) => {
              const effectiveDur = (audioRef.current && audioRef.current.duration && isFinite(audioRef.current.duration))
                ? audioRef.current.duration
                : (playbackDuration > 0 ? playbackDuration : duration);
              const progressRatio = effectiveDur > 0 ? Math.min(1, Math.max(0, currentTime / effectiveDur)) : 0;
              const barRatio = i / 25;
              const isPlayed = barRatio <= progressRatio;
              const profile = Math.sin(i * 0.4) * 0.5 + Math.cos(i * 0.9) * 0.3;
              const barH = Math.round(5 + Math.abs(profile) * 13);

              return (
                <div
                  key={i}
                  className={`w-[2.5px] rounded-full transition-colors duration-100 ${
                    isPlayed ? 'bg-[#141414]' : 'bg-neutral-300 group-hover:bg-neutral-400'
                  }`}
                  style={{ height: `${barH}px` }}
                />
              );
            })}
          </div>

          {/* Time display */}
          <div className="text-[10px] font-bold text-neutral-600 tabular-nums shrink-0">
            <span>{formatDuration(currentTime)}</span>
            <span className="mx-0.5 opacity-50">/</span>
            <span>{formatDuration(playbackDuration > 0 ? playbackDuration : duration)}</span>
          </div>

          {/* Optional note caption input */}
          {onTextChange && (
            <input
              type="text"
              value={accompanyingText}
              onChange={(e) => onTextChange(e.target.value)}
              placeholder="Note..."
              disabled={isSending}
              className="hidden sm:block w-24 border border-neutral-300 px-1.5 py-0.5 text-[10px] bg-neutral-50 focus:bg-white focus:outline-none"
            />
          )}

          {/* Discard & Send button */}
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={onCancel}
              disabled={isSending}
              className="p-1.5 text-neutral-500 hover:text-red-600 hover:bg-neutral-100 rounded-sm transition-colors cursor-pointer shrink-0"
              title="Discard recording"
            >
              <Trash2 className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={onSend}
              disabled={isSending}
              className="w-7 h-7 rounded-full bg-[#141414] text-white flex items-center justify-center hover:bg-black active:scale-95 transition-all shadow-[1px_1px_0px_0px_rgba(20,20,20,1)] cursor-pointer disabled:opacity-50 shrink-0"
              title="Send voice message"
            >
              {isSending ? (
                <span className="inline-block w-3.5 h-3.5 border-2 border-white border-t-transparent animate-spin rounded-full" />
              ) : (
                <ChevronUp className="w-4 h-4" />
              )}
            </button>
          </div>
        </div>
      )}

      {state === 'preview' && playbackError && (
        <div className="mt-1 px-2.5 py-1 bg-red-50 text-red-700 text-[10px] font-mono border border-red-300 flex items-center justify-between">
          <span className="truncate">⚠️ {playbackError}</span>
          <button
            type="button"
            onClick={() => setPlaybackError(null)}
            className="text-red-800 hover:text-red-950 font-bold ml-1 cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}
    </div>
  );
};
