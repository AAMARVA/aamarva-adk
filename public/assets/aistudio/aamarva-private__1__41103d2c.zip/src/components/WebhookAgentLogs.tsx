import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GitCommit, RotateCw, Inbox } from 'lucide-react';
import { apiFetch, buildApiUrl, getCurrentSessionAuthType, getAccessToken } from '../services/authApi';
import { AgentAvatar } from './AgentAvatar';
import { BrutalistLoader } from './BrutalistLoader';
import { getClusterSymbol } from '../lib/clusterSymbols';
import { useAuth } from '../context/AuthContext';
import { getAccountKey, getActivityCache, setActivityCache } from '../lib/appStateCache';
import { extractEventPayload, formatLogDetails } from '../lib/activityFormatting';
import { WebhookManager } from './WebhookManager';
import { warmupConnectionChat } from '../lib/chatMessageWarmup';

interface LogItem {
  id: string;
  category?: 'footprint' | 'event';
  action?: string;
  endpoint?: string;
  details?: any;
  content?: any;
  type?: string;
  senderId?: string;
  senderAgentId?: string;
  senderAgentName?: string;
  senderAvatar?: string;
  target?: string;
  targetId?: string;
  targetAgentId?: string;
  targetAgentName?: string;
  targetAvatar?: string;
  agentId?: string;
  agentName?: string;
  avatar?: string;
  actorAgentId?: string;
  actorAgentName?: string;
  actorAvatar?: string;
  requestId?: string;
  timestamp: string;
  createdAt?: string;
  created_at?: string;
}

interface WebhookAgentLogsProps {
  onOpenChat?: (chat: { id: string; allConnectionIds?: string[]; agentName: string; avatar?: string; agentId?: string; peerE2eePublicKey?: string }) => void;
  connections?: any[];
  pendingRequests?: any[];
  onOpenThread?: (postId: string, details?: any, mode?: 'post' | 'bid') => void;
  onOpenPost?: (postId: string, details?: any) => void;
  onOpenAgentProfile?: (agentName: string, avatar?: string, agentId?: string) => void;
  onOpenCluster?: (clusterId: string, details?: any) => void;
  onOpenRequestsTab?: () => void;
}

// Map footprint actions to their exact API endpoint
const FOOTPRINT_ENDPOINTS: Record<string, string> = {
  CONNECTION_ESTABLISHED: 'POST /api/connections',
  CONNECTED: 'POST /api/connections',
  CONNECTION_ACCEPTED: 'POST /api/connections',
  CONNECTION_REMOVED: 'POST /api/connections/:id/dissolve',
  CONNECTION_DISSOLVED: 'POST /api/connections/:id/dissolve',
  CONNECTION_REQUEST_SENT: 'POST /api/connections/request',
  CONNECTION_REQUEST_ACCEPTED: 'POST /api/connections/requests/:id/respond',
  CONNECTION_REJECTED: 'POST /api/connections/requests/:id/respond',
  MESSAGE_SENT: 'POST /api/connections/:id/messages',
  ATTACHMENT_SENT: 'POST /api/connections/:id/attachments',
  CONNECTION_MESSAGES_CLEARED: 'DELETE /api/connections/:id/messages',
  PROFILE_UPDATED: 'PATCH /api/agents/me',
  AGENT_PROFILE_UPDATED: 'PATCH /api/agents/me',
  AGENT_REGISTERED: 'POST /api/auth/register',
  E2EE_KEYS_UPDATED: 'PUT /api/agents/me/e2ee',
  API_KEY_ROTATED: 'POST /api/auth/agent/rotate-api-key',
  API_KEY_ROTATION_REQUESTED: 'POST /api/auth/agent/rotate-api-key',
  WHITELIST_UPDATED: 'PUT /api/auth/network-whitelist',
  ACCESS_RULES_UPDATED: 'PUT /api/account/access-management',
  SESSIONS_REVOKED_ALL: 'POST /api/auth/sessions/logout-all',
  GLOBAL_LOGOUT: 'POST /api/auth/sessions/logout-all',
  TOOL_INVOKED: 'POST /api/floor/tools/:id/invoke',
  TOOL_EXECUTED: 'POST /api/floor/invocations/:id/execute',
  TOOL_APPROVED: 'POST /api/floor/approvals/:id',
  TOOL_DENIED: 'POST /api/floor/approvals/:id',
  MCP_SERVER_REGISTERED: 'POST /api/floor/servers',
  MCP_TOOL_INVOCATION_BLOCKED: 'POST /api/floor/tools/:id/invoke',
  SLAVE_DEPLOYED: 'POST /api/auth/master/create-slave-agent',
  SLAVE_UNDEPLOYED: 'POST /api/auth/master/undeploy-slave-agent',
  SLAVE_CAPABILITY_BATCH_ACTIVATED: 'POST /api/auth/master/buy-plan',
  FLEET_SETTINGS_COPIED: 'POST /api/auth/master/copy-settings',
  CLUSTER_CREATED: 'POST /api/clusters',
  CLUSTER_UPDATED: 'PATCH /api/clusters/:id',
  CLUSTER_DELETED: 'DELETE /api/clusters/:id',
  CLUSTER_DISBANDED: 'DELETE /api/clusters/:id',

  CLUSTER_JOINED: 'POST /api/clusters/:id/join',
  CLUSTER_LEFT: 'DELETE /api/clusters/:id/leave',
  CLUSTER_MEMBER_ADDED: 'POST /api/clusters/:id/members',
  CLUSTER_MEMBER_INVITED: 'POST /api/clusters/:id/invites',
  CLUSTER_ROLE_UPDATED: 'PATCH /api/clusters/:id/members/:memberId/role',
  CLUSTER_MEMBER_ROLE_UPDATED: 'PATCH /api/clusters/:id/members/:memberId/role',
  CLUSTER_MEMBER_REMOVED: 'DELETE /api/clusters/:id/members/:memberId',
  CLUSTER_MESSAGE_SENT: 'POST /api/clusters/:id/messages',
  CLUSTER_KEY_DISTRIBUTED: 'POST /api/clusters/:id/key-distribution',
  CLUSTER_KEY_ROTATED: 'POST /api/clusters/:id/rotate-key',

  POST_CREATED: 'POST /api/posts',
  BID_SUBMITTED: 'POST /api/posts/:id/replies',

  PASSWORD_CHANGED: 'POST /api/auth/change-password',
  EMAIL_UPDATED: 'POST /api/auth/change-email',
  PEER_REVIEW: 'POST /api/reviews',
  PEER_REVIEW_DELETED: 'DELETE /api/reviews/:id',
  REVIEW_DELETED: 'DELETE /api/reviews/:id'
};

// Map webhook event types to their inbound delivery endpoint
const WEBHOOK_ENDPOINTS: Record<string, string> = {
  CONNECTION_REQUEST_RECEIVED: 'POST /api/connections/request',
  CONNECTION_ACCEPTED_BY_TARGET: 'POST /api/connections',
  CONNECTION_REJECTED: 'POST /api/connections/requests/:id/respond',
  CONNECTION_DISSOLVED: 'POST /api/connections/:id/dissolve',
  MESSAGE_RECEIVED: 'POST /api/connections/:id/messages',
  ATTACHMENT_RECEIVED: 'POST /api/connections/:id/attachments',
  DIRECT_ENCRYPTED_MESSAGE_RECEIVED: 'POST /api/connections/:id/messages',
  SLAVE_CAPABILITY_ACTIVATED: 'POST /api/auth/master/buy-plan',
  SLAVE_CAPABILITY_BATCH_ACTIVATED: 'POST /api/auth/master/buy-plan',

  CLUSTER_MEMBER_JOINED: 'POST /api/clusters/:id/join',
  CLUSTER_MEMBER_LEFT: 'DELETE /api/clusters/:id/leave',
  CLUSTER_MEMBER_REMOVED: 'DELETE /api/clusters/:id/members/:memberId',
  CLUSTER_ROLE_UPDATED: 'PATCH /api/clusters/:id/members/:memberId/role',
  CLUSTER_MESSAGE_RECEIVED: 'POST /api/clusters/:id/messages',
  CLUSTER_DISBANDED: 'DELETE /api/clusters/:id',
  CLUSTER_KEY_DISTRIBUTED: 'POST /api/clusters/:id/key-distribution',
  CLUSTER_KEY_ROTATED: 'POST /api/clusters/:id/rotate-key',
  TOOL_APPROVED: 'POST /api/floor/approvals/:id',
  TOOL_DENIED: 'POST /api/floor/approvals/:id',
  STREAM_CONNECTED: 'GET /api/realtime/stream',
  PEER_REVIEW_RECEIVED: 'POST /api/reviews'
};

const INBOUND_WEBHOOK_TYPES = new Set([
  'CONNECTION_REQUEST_RECEIVED',
  'CONNECTION_ACCEPTED_BY_TARGET',
  'CONNECTION_REJECTED',
  'CONNECTION_DISSOLVED',
  'MESSAGE_RECEIVED',
  'ATTACHMENT_RECEIVED',
  'CLUSTER_MESSAGE_RECEIVED',
  'CLUSTER_MEMBER_JOINED',
  'CLUSTER_MEMBER_LEFT',
  'CLUSTER_MEMBER_REMOVED',
  'CLUSTER_ROLE_UPDATED',
  'CLUSTER_DISBANDED',
  'CLUSTER_KEY_DISTRIBUTED',
  'CLUSTER_KEY_ROTATED',
  'SLAVE_CAPABILITY_ACTIVATED',
  'SLAVE_CAPABILITY_BATCH_ACTIVATED',
  'TOOL_APPROVED',
  'TOOL_DENIED',
  'STREAM_CONNECTED',
  'PEER_REVIEW_RECEIVED',
  'DIRECT_ENCRYPTED_MESSAGE_RECEIVED'
]);

// Event/footprint types that genuinely involve 1-on-1 direct agent messaging or active connections
const CHAT_ELIGIBLE_TYPES = new Set([
  'MESSAGE_RECEIVED',
  'MESSAGE_SENT',
  'CONNECTION_ACCEPTED_BY_TARGET',
  'CONNECTION_ESTABLISHED',
  'CONNECTION_REQUEST_ACCEPTED',
  'CONNECTION_REQUEST_RECEIVED',
  'CLUSTER_MESSAGE_RECEIVED',
  'CLUSTER_MESSAGE_SENT'
]);

export const WebhookAgentLogs: React.FC<WebhookAgentLogsProps> = ({ 
  onOpenChat, 
  connections, 
  pendingRequests,
  onOpenThread, 
  onOpenPost,
  onOpenAgentProfile,
  onOpenCluster,
  onOpenRequestsTab
}) => {
  const { user, activeAccount, userPassword, sessionAuthType } = useAuth();
  const accountKey = getAccountKey(user?.id, activeAccount?.id);
  const accountKeyRef = useRef(accountKey);
  accountKeyRef.current = accountKey;
  const initialCache = getActivityCache(accountKey);

  const [activeTab, setActiveTab] = useState<'footprints' | 'webhooks' | 'outbound'>(() => initialCache.activeTab || 'footprints');
  const [footprintsLogs, setFootprintsLogs] = useState<LogItem[]>(() => initialCache.footprints || []);
  const [webhooksLogs, setWebhooksLogs] = useState<LogItem[]>(() => initialCache.webhooks || []);
  const [isLoadingFootprints, setIsLoadingFootprints] = useState(false);
  const [isLoadingWebhooks, setIsLoadingWebhooks] = useState(false);
  const [footprintsError, setFootprintsError] = useState<string | null>(null);
  const [webhooksError, setWebhooksError] = useState<string | null>(null);
  const [outboundRefreshKey, setOutboundRefreshKey] = useState(0);
  const eventSourceRef = useRef<EventSource | null>(null);

  // Sync state if account switches
  useEffect(() => {
    const current = getActivityCache(accountKey);
    setActiveTab(current.activeTab || 'footprints');
    setFootprintsLogs(current.footprints || []);
    setWebhooksLogs(current.webhooks || []);
    setFootprintsError(null);
    setWebhooksError(null);
  }, [accountKey]);

  const findChatParamsForLog = useCallback((log: LogItem) => {
    const targetId = log.target || log.targetId;
    const senderId = log.senderId;
    const { parsed: detailsObj } = extractEventPayload(log.details);
    const connectionIdFromDetails = detailsObj?.connectionId || detailsObj?.id;

    const match = connections?.find((c: any) => {
      const cId = String(c.id || c.connectionId || '').toLowerCase();
      const cAgentId = String(c.agentId || '').toLowerCase();
      const target = String(connectionIdFromDetails || targetId || senderId || '').toLowerCase();
      return cId === target || (cAgentId && cAgentId === target);
    });

    if (match) {
      return {
        id: match.id || match.connectionId,
        allConnectionIds: match.allConnectionIds,
        agentName: match.agentName || match.peerName || 'Agent',
        avatar: match.avatar || match.peerAvatar || undefined,
        agentId: match.agentId,
        peerE2eePublicKey: match.peerE2eePublicKey
      };
    }

    const connId = connectionIdFromDetails || (targetId && String(targetId).startsWith('conn_') ? targetId : null);
    if (connId) {
      const peerName = detailsObj?.peerName || detailsObj?.agentName || detailsObj?.senderName || 'Connected Agent';
      const peerAgentId = detailsObj?.peerAgentId || detailsObj?.agentId || 'agent';
      return {
        id: connId,
        agentName: peerName,
        avatar: detailsObj?.avatar || undefined,
        agentId: peerAgentId
      };
    }
    return null;
  }, [connections]);

  const handleWarmupChatForLog = useCallback((log: LogItem) => {
    const curPersona = activeAccount || user;
    if (!curPersona?.agentId) return;
    const chatParams = findChatParamsForLog(log);
    if (!chatParams?.id) return;
    warmupConnectionChat({
      connectionId: chatParams.id,
      allConnectionIds: chatParams.allConnectionIds,
      peerAgentId: chatParams.agentId,
      peerPublicKey: chatParams.peerE2eePublicKey,
      accountKey,
      userAgentId: curPersona.agentId,
      userPassword,
      authType: sessionAuthType || getCurrentSessionAuthType() || 'human',
    }).catch(() => {});
  }, [findChatParamsForLog, activeAccount, user, accountKey, userPassword, sessionAuthType]);

  const handleOpenChat = useCallback((log: LogItem) => {
    if (!onOpenChat) return;
    const chatParams = findChatParamsForLog(log);
    if (chatParams) {
      onOpenChat(chatParams);
    }
  }, [onOpenChat, findChatParamsForLog]);

  const footprintsCountRef = useRef(footprintsLogs.length);
  const webhooksCountRef = useRef(webhooksLogs.length);
  footprintsCountRef.current = footprintsLogs.length;
  webhooksCountRef.current = webhooksLogs.length;

  // Authoritative REST fetch with independent state and deduplication
  const fetchLogs = useCallback(async (tab: 'footprints' | 'webhooks', showLoader = false) => {
    const capturedAccountKey = accountKeyRef.current;
    if (tab === 'footprints') {
      if (showLoader && footprintsCountRef.current === 0) setIsLoadingFootprints(true);
    } else {
      if (showLoader && webhooksCountRef.current === 0) setIsLoadingWebhooks(true);
    }

    try {
      const endpoint = tab === 'footprints' ? '/api/agent/footprints' : '/api/webhooks/events';
      const targetAgentId = activeAccount?.agentId || (activeAccount?.id !== user?.id ? activeAccount?.id : undefined);
      const headers: Record<string, string> = {};
      if (targetAgentId) {
        headers['x-target-agent-id'] = targetAgentId;
      }

      let res: any = null;
      let fetchErr: any = null;
      const currentAuth = getCurrentSessionAuthType();
      try {
        res = await apiFetch(endpoint, { authType: currentAuth, headers });
      } catch (err1: any) {
        fetchErr = err1;
        try {
          const fallbackAuth = currentAuth === 'human' ? 'agent' : 'human';
          if (fallbackAuth === 'human' || (fallbackAuth === 'agent' && getAccessToken())) {
            res = await apiFetch(endpoint, { authType: fallbackAuth, headers });
            fetchErr = null;
          }
        } catch (err2: any) {
          fetchErr = err2 || err1;
        }
      }

      if (fetchErr && !res) {
        if (accountKeyRef.current === capturedAccountKey) {
          const errMsg = fetchErr?.message || `Failed to load ${tab}.`;
          if (tab === 'footprints') setFootprintsError(errMsg);
          else setWebhooksError(errMsg);
        }
        return;
      }

      if (accountKeyRef.current === capturedAccountKey) {
        if (tab === 'footprints') setFootprintsError(null);
        else setWebhooksError(null);
      }

      if (res && res.success && Array.isArray(res.data || res.events || res.footprints ? (Array.isArray(res.data) ? res.data : (res.data?.events || res.data?.footprints)) : res.data)) {
        const incomingList: LogItem[] = Array.isArray(res.data) ? res.data : (res.data?.events || res.data?.footprints || []);

        // Prevent race condition: if the user switched accounts while fetch was in-flight, discard response
        if (accountKeyRef.current !== capturedAccountKey) {
          return;
        }

        if (tab === 'footprints') {
          const incomingFootprints: LogItem[] = incomingList.map(item => ({
            ...item,
            category: 'footprint',
            action: item.action || item.type,
            type: undefined,
            timestamp: item.timestamp || item.createdAt || item.created_at || new Date().toISOString()
          }));

          setFootprintsLogs((prev) => {
            if (accountKeyRef.current !== capturedAccountKey) return prev;
            const now = Date.now();
            const map = new Map<string, LogItem>();
            incomingFootprints.forEach(item => { if (item.id) map.set(item.id, item); });
            prev.forEach(item => {
              if (!item.id || map.has(item.id) || item.category === 'event') return;
              const ageMs = now - new Date(item.timestamp || 0).getTime();
              if (Number.isFinite(ageMs) && ageMs >= 0 && ageMs < 15000) {
                map.set(item.id, item);
              }
            });
            const merged = Array.from(map.values());
            merged.sort((a, b) => new Date(b.timestamp || 0).getTime() - new Date(a.timestamp || 0).getTime());
            const sliced = merged.slice(0, 100);
            setActivityCache(capturedAccountKey, { footprints: sliced, lastFetchedFootprints: Date.now() });
            return sliced;
          });
        } else {
          const incomingWebhooks: LogItem[] = incomingList.map(item => ({
            ...item,
            category: 'event',
            type: item.type || item.action,
            action: undefined,
            details: item.details || item.content,
            timestamp: item.timestamp || item.createdAt || item.created_at || new Date().toISOString()
          }));

          setWebhooksLogs((prev) => {
            if (accountKeyRef.current !== capturedAccountKey) return prev;
            const now = Date.now();
            const map = new Map<string, LogItem>();
            incomingWebhooks.forEach(item => { if (item.id) map.set(item.id, item); });
            prev.forEach(item => {
              if (!item.id || map.has(item.id) || item.category === 'footprint') return;
              const ageMs = now - new Date(item.timestamp || 0).getTime();
              if (Number.isFinite(ageMs) && ageMs >= 0 && ageMs < 15000) {
                map.set(item.id, item);
              }
            });
            const merged = Array.from(map.values());
            merged.sort((a, b) => new Date(b.timestamp || 0).getTime() - new Date(a.timestamp || 0).getTime());
            const sliced = merged.slice(0, 100);
            setActivityCache(capturedAccountKey, { webhooks: sliced, lastFetchedWebhooks: Date.now() });
            return sliced;
          });
        }
      }
    } catch (err: any) {
      if (err?.message && !err.message.includes('Failed to fetch')) {
        console.warn(`Failed to fetch ${tab}:`, err.message);
      }
      // Network/HTTP errors must NOT clear valid records
    } finally {
      if (tab === 'footprints') {
        setIsLoadingFootprints(false);
      } else {
        setIsLoadingWebhooks(false);
      }
    }
  }, [accountKey, activeAccount?.agentId, activeAccount?.id, user?.id]);

  // Fetch logs when account switches and poll periodically in the background
  useEffect(() => {
    // Prime both footprints and webhooks so switching is instant without any delay
    fetchLogs('footprints', false);
    fetchLogs('webhooks', false);

    const onWatchtowerRefresh = () => {
      fetchLogs('footprints', false);
    };
    if (typeof window !== 'undefined') {
      window.addEventListener('aamarva:watchtower_refresh', onWatchtowerRefresh);
    }

    const interval = setInterval(() => {
      if (activeTab === 'footprints' || activeTab === 'webhooks') {
        fetchLogs(activeTab, false);
      }
    }, 8000);
    return () => {
      clearInterval(interval);
      if (typeof window !== 'undefined') {
        window.removeEventListener('aamarva:watchtower_refresh', onWatchtowerRefresh);
      }
    };
  }, [accountKey, activeTab, fetchLogs]);

  // Set up real-time SSE stream scoped to active account using ticket authentication
  useEffect(() => {
    if (!user?.id && !activeAccount?.id) {
      return;
    }

    let reconnectTimeout: any = null;
    let isSubscribed = true;
    const capturedAccountKey = accountKey;
    const targetAgentId = activeAccount?.agentId || (activeAccount?.id !== user?.id ? activeAccount?.id : undefined);

    const connectSSE = async () => {
      if (!isSubscribed) return;
      if (eventSourceRef.current) {
        try {
          eventSourceRef.current.close();
        } catch (e) {}
      }

      try {
        const authType = getCurrentSessionAuthType();
        const ticketRes = await apiFetch('/api/realtime/stream-ticket', {
          method: 'POST',
          authType,
          headers: targetAgentId ? { 'x-target-agent-id': targetAgentId } : undefined
        }).catch(() => null);

        if (!isSubscribed) return;

        const ticket = ticketRes?.ticket;
        let streamPath: string;
        if (ticket) {
          streamPath = `/api/realtime/stream?ticket=${encodeURIComponent(ticket)}`;
        } else if (authType === 'human') {
          streamPath = targetAgentId
            ? `/api/realtime/stream?agentId=${encodeURIComponent(targetAgentId)}`
            : '/api/realtime/stream';
        } else {
          reconnectTimeout = setTimeout(connectSSE, 4000);
          return;
        }

        const streamUrl = buildApiUrl(streamPath);
        const es = new EventSource(streamUrl, { withCredentials: true });
        eventSourceRef.current = es;

        es.onmessage = (e) => {
          if (!isSubscribed || !e.data) return;
          try {
            const parsed = JSON.parse(e.data);
            handleIncomingRealtimeEvent(parsed);
          } catch (err) {}
        };

        es.onerror = () => {
          if (!isSubscribed) return;
          try {
            es.close();
          } catch (e) {}
          reconnectTimeout = setTimeout(connectSSE, 3000);
        };
      } catch (err) {
        if (isSubscribed) {
          reconnectTimeout = setTimeout(connectSSE, 5000);
        }
      }
    };

    const handleIncomingRealtimeEvent = (event: any) => {
      if (!event || event.category === 'system') return;
      if (accountKeyRef.current !== capturedAccountKey) return;

      const actionUpper = String(event.type || event.action || '').toUpperCase();
      const isFootprint =
        event.category === 'footprint'
          ? true
          : event.category === 'event'
            ? false
            : !INBOUND_WEBHOOK_TYPES.has(actionUpper);

      const newItem: LogItem = {
        id: event.id || `rt_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        category: isFootprint ? 'footprint' : 'event',
        action: isFootprint ? (event.action || event.type) : undefined,
        endpoint: event.endpoint,
        type: isFootprint ? undefined : (event.type || event.action),
        details: event.details || event.action,
        senderId: event.actorId || event.senderId,
        target: event.targetId || event.target,
        targetId: event.targetId || event.target,
        targetAgentId: event.targetAgentId,
        targetAgentName: event.targetAgentName,
        targetAvatar: event.targetAvatar,
        agentId: event.actorAgentId || event.agentId || (isFootprint ? event.actorId : undefined),
        agentName: event.actorAgentName || event.agentName,
        avatar: event.actorAvatar || event.avatar,
        actorAgentId: event.actorAgentId || event.actorId,
        actorAgentName: event.actorAgentName || event.agentName,
        actorAvatar: event.actorAvatar || event.avatar,
        timestamp: event.timestamp || event.createdAt || event.created_at || new Date().toISOString()
      };

      if (isFootprint) {
        setFootprintsLogs((prev) => {
          if (accountKeyRef.current !== capturedAccountKey) return prev;
          if (prev.some(p => p.id === newItem.id)) return prev;
          const next = [newItem, ...prev];
          next.sort((a, b) => new Date(b.timestamp || 0).getTime() - new Date(a.timestamp || 0).getTime());
          const sliced = next.slice(0, 100);
          setActivityCache(capturedAccountKey, { footprints: sliced });
          return sliced;
        });
      } else {
        setWebhooksLogs((prev) => {
          if (accountKeyRef.current !== capturedAccountKey) return prev;
          if (prev.some(p => p.id === newItem.id)) return prev;
          const next = [newItem, ...prev];
          next.sort((a, b) => new Date(b.timestamp || 0).getTime() - new Date(a.timestamp || 0).getTime());
          const sliced = next.slice(0, 100);
          setActivityCache(capturedAccountKey, { webhooks: sliced });
          return sliced;
        });
      }
    };

    connectSSE();

    return () => {
      isSubscribed = false;
      if (reconnectTimeout) clearTimeout(reconnectTimeout);
      if (eventSourceRef.current) {
        try {
          eventSourceRef.current.close();
        } catch (e) {}
      }
    };
  }, [accountKey, activeAccount?.agentId, activeAccount?.id, user?.id]);

  const formatActionTitle = (text?: string) => {
    if (!text) return 'ACTIVITY EVENT';
    const formatted = text.replace(/_/g, ' ');
    if (formatted === 'BID SENT') return 'BID MADE';
    return formatted;
  };

  const getLogDescription = (log: LogItem) => {
    const isWebhook = log.category ? log.category === 'event' : activeTab === 'webhooks';
    return formatLogDetails(log, isWebhook).summary;
  };

  const parseEndpoint = (rawEndpoint?: string, actionKey?: string, isWebhook = false) => {
    if (rawEndpoint && rawEndpoint.trim()) return rawEndpoint.trim();
    const key = (actionKey || '').toUpperCase();
    if (isWebhook) {
      if (WEBHOOK_ENDPOINTS[key]) return WEBHOOK_ENDPOINTS[key];
      return 'GET /api/webhooks/events';
    }
    return (key ? FOOTPRINT_ENDPOINTS[key] : null) || 'POST /api/agent/footprints';
  };

  const isUuid = (val?: string | null): boolean => {
    if (!val || typeof val !== 'string') return false;
    return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(val.trim());
  };

  const sanitizeAvatar = (av?: string | null): string | null => {
    if (!av || typeof av !== 'string') return null;
    const trimmed = av.trim();
    if (!trimmed || trimmed === '🤖' || trimmed === '👾') return null;
    return trimmed;
  };

  const extractPeerHandleFromText = (str?: string | null): string | null => {
    if (!str || typeof str !== 'string') return null;
    const amrMatch = str.match(/(AMR-[A-Za-z0-9_-]+)/i);
    if (amrMatch && amrMatch[1]) {
      return amrMatch[1].replace(/^@+/, '');
    }
    const atMatch = str.match(/@([A-Za-z0-9][A-Za-z0-9_-]+)/);
    if (atMatch && atMatch[1] && atMatch[1].toLowerCase() !== 'agent' && !atMatch[1].toLowerCase().startsWith('req_')) {
      return atMatch[1];
    }
    const phraseMatch = str.match(/(?:handshake with agent|with agent|to agent|from agent|for agent)\s+@?([A-Za-z0-9_-]+)/i);
    if (phraseMatch && phraseMatch[1]) {
      const candidate = phraseMatch[1].replace(/^@+/, '');
      const lower = candidate.toLowerCase();
      const stopWords = new Set(['node', 'identity', 'profile', 'key', 'keys', 'account', 'accounts', 'session', 'sessions', 'token', 'settings', 'status', 'action', 'slot', 'record', 'unknown', 'agent']);
      if (!lower.startsWith('req_') && !stopWords.has(lower)) {
        return candidate;
      }
    }
    return null;
  };

  const isSelfAccountFootprintAction = (actionKey: string): boolean => {
    return (
      actionKey.includes('PROFILE') ||
      actionKey.includes('E2EE') ||
      actionKey.includes('PASSWORD') ||
      actionKey.includes('EMAIL') ||
      actionKey.includes('WHITELIST') ||
      actionKey.includes('ACCESS_RULES') ||
      actionKey.includes('LOGOUT') ||
      actionKey.includes('SESSIONS_REVOKED') ||
      actionKey.includes('API_KEY') ||
      actionKey.includes('PLAN_ENTITLEMENT') ||
      actionKey.includes('CAPABILITY_BATCH') ||
      actionKey.includes('FLEET_SETTINGS') ||
      actionKey.startsWith('TOOL_') ||
      actionKey.startsWith('MCP_') ||
      actionKey === 'AGENT_REGISTERED' ||
      actionKey === 'AGENT_LOGGED_IN' ||
      actionKey === 'STREAM_CONNECTED'
    );
  };

  const findMatchingCurrentAccount = (candidateId?: string | null) => {
    const accounts = [activeAccount, user].filter(Boolean) as any[];
    if (accounts.length === 0) return null;
    if (!candidateId) return activeAccount || user || null;
    const norm = candidateId.replace(/^@+/, '').trim().toLowerCase();
    return (
      accounts.find((acc) => {
        const accAid = String(acc.agentId || '').replace(/^@+/, '').trim().toLowerCase();
        const accId = String(acc.id || '').trim().toLowerCase();
        return (accAid && accAid === norm) || (accId && accId === norm);
      }) || null
    );
  };

  const getActingAccountForLog = (log: LogItem) => {
    const rawActorId = (log.actorAgentId || log.agentId || '').replace(/^@+/, '').trim();
    const validLogActorId = rawActorId && rawActorId.toLowerCase() !== 'agent' && !isUuid(rawActorId) ? rawActorId : null;
    const cur = findMatchingCurrentAccount(validLogActorId || log.senderId) || (!validLogActorId ? (activeAccount || user || null) : null);

    const resolvedId = validLogActorId || (cur?.agentId && !isUuid(cur.agentId) ? cur.agentId : null) || cur?.id || null;
    const logActorName = (log.actorAgentName || log.agentName || '').trim();
    const validLogName = logActorName && logActorName.toLowerCase() !== 'agent' && !isUuid(logActorName) ? logActorName : null;
    const resolvedName = validLogName || cur?.name || resolvedId || 'Agent';
    const resolvedAvatar = sanitizeAvatar(log.actorAvatar || log.avatar) || sanitizeAvatar(cur?.avatar) || null;

    return {
      agentId: resolvedId,
      agentName: resolvedName,
      agentAvatar: resolvedAvatar
    };
  };

  const resolveLogEntities = (log: LogItem, isWebhookOverride?: boolean) => {
    const isWebhook = typeof isWebhookOverride === 'boolean'
      ? isWebhookOverride
      : (log.category ? log.category === 'event' : activeTab === 'webhooks');
    const detailsObj = extractEventPayload(log.details).parsed || {};
    const detailsStr = typeof log.details === 'string'
      ? log.details
      : (detailsObj?.message || detailsObj?.details || detailsObj?.text || '');
    const actionKey = (log.action || log.type || '').toUpperCase();
    const rawTarget = (log.target || log.targetId || detailsObj?.targetId || '').trim();

    const isRequestAction = 
      actionKey.includes('CONNECTION_REQUEST') ||
      actionKey.includes('REQUEST_SENT') ||
      actionKey.includes('REQUEST_RECEIVED') ||
      (log.endpoint && (log.endpoint.includes('/connections/request') || log.endpoint.includes('/connections/requests')));

    // 1. Identify request ID
    let requestId: string | null = null;
    if (log.requestId) {
      requestId = log.requestId;
    } else if (detailsObj?.requestId) {
      requestId = detailsObj.requestId;
    } else if (rawTarget && (rawTarget.toLowerCase().startsWith('req_') || rawTarget.toUpperCase().startsWith('REQ_'))) {
      requestId = rawTarget;
    } else if (log.id && (log.id.startsWith('req_') || log.id.startsWith('REQ_') || log.id.startsWith('fp_req_'))) {
      requestId = log.id.replace(/^fp_req_/, '');
    }

    // 2. Identify agent ID, display name, and avatar
    let agentId: string | null = null;
    let agentName: string | null = null;
    let agentAvatar: string | null = null;

    if (isWebhook) {
      // Inbound webhook event
      if (actionKey.includes('CAPABILITY') || actionKey.includes('SLAVE_CAPABILITY')) {
        let candidateAcc: any = null;
        if (Array.isArray(detailsObj?.target_accounts) && detailsObj.target_accounts.length > 0) {
          candidateAcc = detailsObj.target_accounts.find((a: any) =>
            (a.agent_id && (a.agent_id === activeAccount?.agentId || a.agent_id === user?.agentId)) ||
            (a.id && (a.id === activeAccount?.id || a.id === user?.id))
          ) || detailsObj.target_accounts[0];
        }
        if (candidateAcc) {
          agentId = candidateAcc.agent_id || candidateAcc.agentId || candidateAcc.id;
          agentName = candidateAcc.name || candidateAcc.agentName || candidateAcc.agent_id;
          agentAvatar = sanitizeAvatar(candidateAcc.avatar);
        } else if (log.targetAgentId) {
          agentId = log.targetAgentId;
          agentName = log.targetAgentName || null;
          agentAvatar = sanitizeAvatar(log.targetAvatar);
        } else if (detailsObj?.agent_id) {
          agentId = detailsObj.agent_id;
          agentName = detailsObj.name || detailsObj.agentName || detailsObj.agent_id;
          agentAvatar = sanitizeAvatar(detailsObj.avatar);
        }
      } else {
        // Other inbound events: peer sender
        agentId = log.senderAgentId || log.senderId || detailsObj?.senderAgentId || detailsObj?.senderId || detailsObj?.reviewerAgentId || null;
        agentName = log.senderAgentName || detailsObj?.senderAgentName || detailsObj?.senderName || detailsObj?.reviewerName || null;
        agentAvatar = sanitizeAvatar(log.senderAvatar || detailsObj?.senderAvatar);
      }
    } else {
      // Outbound footprint
      const explicitTargetAid = log.targetAgentId || detailsObj?.targetAgentId || detailsObj?.receiverAgentId || null;
      const explicitTargetName = log.targetAgentName || detailsObj?.targetAgentName || detailsObj?.receiverAgentName || null;
      const explicitTargetAvatar = sanitizeAvatar(log.targetAvatar || detailsObj?.targetAvatar || detailsObj?.receiverAvatar);

      if (isSelfAccountFootprintAction(actionKey)) {
        const actor = getActingAccountForLog(log);
        const hasSpecificTarget = Boolean(explicitTargetAid && !isUuid(explicitTargetAid) && explicitTargetAid.toLowerCase() !== 'agent');
        agentId = hasSpecificTarget ? explicitTargetAid : actor.agentId;
        const targetMatchesActor = !hasSpecificTarget || !actor.agentId || explicitTargetAid!.toLowerCase() === actor.agentId.toLowerCase();
        agentName = (explicitTargetName && explicitTargetName !== 'Agent' && !isUuid(explicitTargetName))
          ? explicitTargetName
          : (targetMatchesActor ? actor.agentName : explicitTargetAid);
        agentAvatar = explicitTargetAvatar || (targetMatchesActor ? actor.agentAvatar : null);
      } else {
        agentId = explicitTargetAid;
        agentName = explicitTargetName;
        agentAvatar = explicitTargetAvatar;
      }
    }

    // If agentId is empty or a UUID or generic 'agent', check details string for AMR-XXXX-XXXX or explicit peer phrase
    if ((!agentId || isUuid(agentId) || agentId.toLowerCase() === 'agent') && detailsStr) {
      const extracted = extractPeerHandleFromText(detailsStr);
      if (extracted) {
        agentId = extracted;
        if (!agentName || isUuid(agentName) || agentName === 'Agent') {
          agentName = agentId;
        }
      }
    }

    // Check connections to resolve agentId, agentName, and avatar (especially if UUID or empty)
    if (connections && connections.length > 0) {
      const searchKey = String(agentId || rawTarget || log.senderId || '').toLowerCase();
      if (searchKey) {
        const match = connections.find((c: any) => {
          const cId = String(c.id || c.connectionId || '').toLowerCase();
          const cAgentId = String(c.agentId || c.peerAgentId || '').toLowerCase();
          const u1Id = String(c.user1_id || '').toLowerCase();
          const u2Id = String(c.user2_id || '').toLowerCase();
          const a1 = String(c.user1_agent_id || '').toLowerCase();
          const a2 = String(c.user2_agent_id || '').toLowerCase();
          return (
            cId === searchKey ||
            cAgentId === searchKey ||
            u1Id === searchKey ||
            u2Id === searchKey ||
            a1 === searchKey ||
            a2 === searchKey
          );
        });

        if (match) {
          const isU1 = match.user1_id === user?.id || (match.user1_agent_id && match.user1_agent_id.toLowerCase() === (user?.agentId || '').toLowerCase());
          const peerId = match.agentId || match.peerAgentId || (isU1 ? match.user2_agent_id : match.user1_agent_id) || match.id;
          const peerName = match.agentName || match.peerName || (isU1 ? match.user2_agent_name : match.user1_agent_name) || peerId;
          const peerAvatar = sanitizeAvatar(match.avatar || match.peerAvatar || (isU1 ? match.user2_avatar : match.user1_avatar));

          if (!agentId || isUuid(agentId) || agentId.toLowerCase() === 'agent') {
            agentId = peerId;
          }
          if (!agentName || isUuid(agentName) || agentName === 'Agent' || agentName === agentId) {
            agentName = peerName;
          }
          if (!agentAvatar) {
            agentAvatar = peerAvatar;
          }
        }
      }
    }

    // Check pending requests
    if (requestId && pendingRequests && pendingRequests.length > 0) {
      const cleanReqId = requestId.toLowerCase();
      const matchedReq = pendingRequests.find((pr: any) => String(pr.id || '').toLowerCase() === cleanReqId);
      if (matchedReq) {
        if (!agentId || isUuid(agentId)) {
          agentId = matchedReq.receiverAgentId || matchedReq.senderAgentId;
        }
        if (!agentName || isUuid(agentName)) {
          agentName = matchedReq.receiverAgentName || matchedReq.senderAgentName;
        }
        if (!agentAvatar) {
          agentAvatar = sanitizeAvatar(matchedReq.receiverAvatar || matchedReq.senderAvatar);
        }
      }
    }

    // Fallback if rawTarget was a valid non-UUID handle
    if (!agentId && rawTarget && !isUuid(rawTarget) && !rawTarget.toLowerCase().startsWith('req_') && !rawTarget.toLowerCase().startsWith('post_') && !rawTarget.toLowerCase().startsWith('cluster_')) {
      agentId = rawTarget;
    }

    const isRequest = Boolean(isRequestAction || requestId);

    // Final actor fallback for non-request Footprints when no peer target exists
    if (!isWebhook && !isRequest && (!agentId || isUuid(agentId) || agentId.toLowerCase() === 'agent')) {
      const actor = getActingAccountForLog(log);
      if (actor.agentId) {
        agentId = actor.agentId;
        agentName = actor.agentName;
        agentAvatar = actor.agentAvatar;
      }
    }

    // Enrich missing name/avatar when resolved agent matches activeAccount or user
    if (agentId && !isUuid(agentId)) {
      const matchedSelf = findMatchingCurrentAccount(agentId);
      if (matchedSelf) {
        if (!agentName || isUuid(agentName) || agentName === 'Agent' || agentName === agentId) {
          agentName = matchedSelf.name || agentName;
        }
        if (!agentAvatar) {
          agentAvatar = sanitizeAvatar(matchedSelf.avatar);
        }
      }
    }

    return {
      isRequest,
      requestId,
      agentId,
      agentName: (agentName && !isUuid(agentName)) ? agentName : (agentId && !isUuid(agentId) ? agentId : 'Agent'),
      agentAvatar: sanitizeAvatar(agentAvatar)
    };
  };

  const renderAgentBadge = (rawAgentId?: string, agentName?: string | null, avatar?: string | null, details?: any) => {
    if (!rawAgentId && !details) return null;

    const detailsObj = extractEventPayload(details).parsed || {};
    const detailsStr = typeof details === 'string' ? details : (detailsObj?.message || detailsObj?.details || detailsObj?.text || '');
    let finalAgentId = rawAgentId || detailsObj?.agentId || detailsObj?.targetAgentId || detailsObj?.receiverAgentId || detailsObj?.senderAgentId || '';

    // If finalAgentId is a request ID or cluster or post, don't render it as an agent
    if (
      finalAgentId.toLowerCase().startsWith('req_') || 
      finalAgentId.toUpperCase().startsWith('REQ_') ||
      finalAgentId.toLowerCase().startsWith('post_') ||
      finalAgentId.toLowerCase().startsWith('cluster_')
    ) {
      return null;
    }

    let displayName = agentName || detailsObj?.agentName || detailsObj?.targetAgentName || detailsObj?.receiverAgentName || detailsObj?.senderAgentName || detailsObj?.name;
    let resolvedAvatar = sanitizeAvatar(avatar || detailsObj?.avatar || detailsObj?.targetAvatar || detailsObj?.receiverAvatar || detailsObj?.senderAvatar);

    // Check capability target accounts if finalAgentId is missing, UUID, or generic 'agent'
    if (!finalAgentId || isUuid(finalAgentId) || finalAgentId.toLowerCase() === 'agent') {
      if (Array.isArray(detailsObj?.target_accounts) && detailsObj.target_accounts.length > 0) {
        const targetAcc = detailsObj.target_accounts.find((a: any) => 
          (a.agent_id && (a.agent_id === activeAccount?.agentId || a.agent_id === user?.agentId)) ||
          (a.id && (a.id === activeAccount?.id || a.id === user?.id))
        ) || detailsObj.target_accounts[0];
        if (targetAcc) {
          finalAgentId = targetAcc.agent_id || targetAcc.agentId || targetAcc.id;
          if (!displayName || isUuid(displayName) || displayName === 'Agent') {
            displayName = targetAcc.name || targetAcc.agentName || finalAgentId;
          }
          if (!resolvedAvatar) {
            resolvedAvatar = sanitizeAvatar(targetAcc.avatar);
          }
        }
      }
    }

    // Check if details contains AMR-XXXX-XXXX
    if (!finalAgentId || isUuid(finalAgentId) || finalAgentId.toLowerCase() === 'agent') {
      const extracted = extractPeerHandleFromText(detailsStr);
      if (extracted) {
        finalAgentId = extracted;
        if (!displayName || isUuid(displayName) || displayName === 'Agent') {
          displayName = extracted;
        }
      }
    }

    // Match against connections
    if (connections && connections.length > 0) {
      const searchKey = finalAgentId.toLowerCase();
      const match = connections.find((c: any) => {
        const cId = String(c.id || c.connectionId || '').toLowerCase();
        const cAgentId = String(c.agentId || c.peerAgentId || '').toLowerCase();
        const u1Id = String(c.user1_id || '').toLowerCase();
        const u2Id = String(c.user2_id || '').toLowerCase();
        const a1 = String(c.user1_agent_id || '').toLowerCase();
        const a2 = String(c.user2_agent_id || '').toLowerCase();
        return (
          cId === searchKey ||
          cAgentId === searchKey ||
          u1Id === searchKey ||
          u2Id === searchKey ||
          a1 === searchKey ||
          a2 === searchKey
        );
      });
      if (match) {
        const isU1 = match.user1_id === user?.id || (match.user1_agent_id && match.user1_agent_id.toLowerCase() === (user?.agentId || '').toLowerCase());
        const peerId = match.agentId || match.peerAgentId || (isU1 ? match.user2_agent_id : match.user1_agent_id) || match.id;
        const peerName = match.agentName || match.peerName || (isU1 ? match.user2_agent_name : match.user1_agent_name) || peerId;
        const peerAvatar = sanitizeAvatar(match.avatar || match.peerAvatar || (isU1 ? match.user2_avatar : match.user1_avatar));

        if (!finalAgentId || isUuid(finalAgentId) || finalAgentId.toLowerCase() === 'agent') {
          finalAgentId = peerId;
        }
        if (!displayName || isUuid(displayName) || displayName === 'Agent' || displayName === finalAgentId) {
          displayName = peerName;
        }
        if (!resolvedAvatar) {
          resolvedAvatar = peerAvatar;
        }
      }
    }

    // Match against activeAccount / user to enrich missing name or avatar
    if (finalAgentId && !isUuid(finalAgentId)) {
      const matchedSelf = findMatchingCurrentAccount(finalAgentId);
      if (matchedSelf) {
        if (!displayName || isUuid(displayName) || displayName === 'Agent' || displayName === finalAgentId) {
          displayName = matchedSelf.name || displayName;
        }
        if (!resolvedAvatar) {
          resolvedAvatar = sanitizeAvatar(matchedSelf.avatar);
        }
      }
    }

    if (!finalAgentId) {
      finalAgentId = 'agent';
    }

    // If displayName is still a UUID or empty, fall back cleanly to finalAgentId (or 'Agent Node' if finalAgentId is also UUID)
    if (isUuid(displayName) || !displayName) {
      displayName = isUuid(finalAgentId) ? 'Agent Node' : finalAgentId;
    }

    const finalName = displayName;

    return (
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          onOpenAgentProfile?.(finalName, resolvedAvatar || undefined, finalAgentId);
        }}
        className="inline-flex items-center gap-2 bg-[#141414] hover:bg-white hover:text-[#141414] group border border-white/20 px-2 py-1 transition-all cursor-pointer shadow-[1px_1px_0px_0px_rgba(255,255,255,0.05)] active:translate-x-[1px] active:translate-y-[1px]"
        title={`View profile for ${finalName} (@${finalAgentId})`}
      >
        <AgentAvatar 
          name={finalName} 
          avatar={resolvedAvatar || undefined} 
          id={finalAgentId} 
          className="w-5 h-5 border border-white/20 shadow-[1px_1px_0px_0px_rgba(255,255,255,0.1)] shrink-0" 
        />
        <div className="flex flex-col text-left leading-none">
          <span className="font-black text-[10px] tracking-wider uppercase text-white/90 group-hover:text-[#141414] transition-colors">
            {finalName}
          </span>
          <span className="font-mono text-[8px] font-bold text-white/60 group-hover:text-[#141414]/80 tracking-wider mt-0.5 transition-colors">
            @{finalAgentId}
          </span>
        </div>
      </button>
    );
  };

  const renderRequestBadge = (rawRequestId: string) => {
    if (!rawRequestId) return null;
    const cleanId = rawRequestId.toUpperCase();
    const displayId = cleanId.length > 20 ? `${cleanId.slice(0, 16)}...` : cleanId;

    return (
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          onOpenRequestsTab?.();
        }}
        className="inline-flex items-center gap-2 bg-[#141414] hover:bg-white hover:text-[#141414] group border border-white/20 px-2 py-1 transition-all cursor-pointer shadow-[1px_1px_0px_0px_rgba(255,255,255,0.05)] active:translate-x-[1px] active:translate-y-[1px]"
        title={`Request ID: ${cleanId} — Click to redirect to Account Requests tab`}
      >
        <div className="w-5 h-5 bg-white/10 border border-white/20 flex items-center justify-center text-white/90 group-hover:text-[#141414] group-hover:bg-[#141414]/10 shrink-0 transition-colors">
          <Inbox className="w-3 h-3" />
        </div>
        <div className="flex flex-col text-left leading-none">
          <span className="font-black text-[10px] tracking-wider uppercase text-white/90 group-hover:text-[#141414] transition-colors">
            {displayId}
          </span>
          <span className="font-mono text-[8px] font-bold text-white/60 group-hover:text-[#141414]/80 tracking-wider mt-0.5 transition-colors">
            ACCOUNT REQUEST
          </span>
        </div>
      </button>
    );
  };

  const renderClusterBadge = (rawClusterId?: string, details?: any) => {
    const detailsObj = extractEventPayload(details).parsed || {};
    const clusterId = rawClusterId || detailsObj?.clusterId || detailsObj?.targetId || 'cluster_alpha_secret';
    const sym = getClusterSymbol(clusterId);
    const clusterName = detailsObj?.clusterName || detailsObj?.name || (clusterId === 'cluster_alpha_secret' ? 'ALPHA SECRET ENCLAVE' : `CLUSTER ${clusterId.slice(0, 8)}`);

    if (onOpenCluster) {
      return (
        <button
          type="button"
          onClick={() => onOpenCluster(clusterId, details)}
          className="inline-flex items-center gap-2 bg-white/95 text-[#141414] hover:bg-white border border-white/15 px-2.5 py-1 shadow-[1px_1px_0px_0px_rgba(255,255,255,0.05)] cursor-pointer hover:border-white/30 transition-all text-left leading-none active:translate-x-[1px] active:translate-y-[1px]"
          title={`Click to view Cluster: ${clusterName}`}
        >
          <span className="font-mono text-[11px] font-black bg-[#141414] text-white px-1.5 py-0.5 border border-black/20 shrink-0">
            {sym}
          </span>
          <div className="flex flex-col text-left leading-none">
            <span className="font-black text-[10px] tracking-wider uppercase text-[#141414]">
              {clusterName}
            </span>
            <span className="font-mono text-[8px] font-bold text-[#141414]/70 tracking-wider mt-0.5">
              #{clusterId.length > 14 ? `${clusterId.slice(0, 12)}...` : clusterId}
            </span>
          </div>
        </button>
      );
    }

    return (
      <div
        className="inline-flex items-center gap-2 bg-white/90 text-[#141414] border border-white/10 px-2 py-1 shadow-[1px_1px_0px_0px_rgba(255,255,255,0.05)]"
        title={`Cluster Enclave: ${clusterName}`}
      >
        <span className="font-mono text-[11px] font-black bg-[#141414] text-white px-1.5 py-0.5 border border-black/20 shrink-0">
          {sym}
        </span>
        <div className="flex flex-col text-left leading-none">
          <span className="font-black text-[10px] tracking-wider uppercase text-[#141414]">
            {clusterName}
          </span>
          <span className="font-mono text-[8px] font-bold text-[#141414]/70 tracking-wider mt-0.5">
            #{clusterId.length > 14 ? `${clusterId.slice(0, 12)}...` : clusterId}
          </span>
        </div>
      </div>
    );
  };

  const isLoading = activeTab === 'footprints' ? isLoadingFootprints : isLoadingWebhooks;

  const renderLogItem = (log: LogItem, isWebhookTab?: boolean) => {
    const isWebhook = typeof isWebhookTab === 'boolean'
      ? isWebhookTab
      : (log.category ? log.category === 'event' : activeTab === 'webhooks');
    const detailsObj = extractEventPayload(log.details).parsed || {};
    const title = formatActionTitle(isWebhook ? (log.type || log.action) : (log.action || log.type));
    const timeStr = log.timestamp ? new Date(log.timestamp).toLocaleTimeString() : '';
    const actionKey = (log.action || log.type || '').toUpperCase();
    const isChatable = CHAT_ELIGIBLE_TYPES.has(actionKey);
    const targetStr = log.target || log.targetId || detailsObj?.targetId || detailsObj?.postId || detailsObj?.connectionId;
    const targetShort = targetStr ? (targetStr.length > 14 ? `${targetStr.slice(0, 12)}...` : targetStr) : null;
    const isReplyTarget = actionKey.includes('BID') || (log.endpoint && log.endpoint.includes('/replies')) || (targetStr && (targetStr.startsWith('rep_') || targetStr.startsWith('REP_')));
    const isPostTarget = !isReplyTarget && (actionKey.includes('POST') || (log.endpoint && log.endpoint.includes('/posts')) || (targetStr && (targetStr.startsWith('post_') || targetStr.startsWith('POST_'))));
    const isThreadTarget = isPostTarget || isReplyTarget;
    const isClusterTarget = actionKey.includes('CLUSTER') || (targetStr && (targetStr.startsWith('cluster_') || targetStr.startsWith('cls_'))) || Boolean(detailsObj?.clusterId);
    const entities = resolveLogEntities(log, isWebhook);
    const { summary, detailsList } = formatLogDetails(log, isWebhook);
    const fullEndpoint = parseEndpoint(log.endpoint, isWebhook ? (log.type || log.action) : (log.action || log.type), isWebhook);

    return (
      <div key={log.id} className="p-3.5 bg-[#1e1e1e] border border-white/10 text-xs space-y-2.5 shadow-[1px_1px_0px_0px_rgba(255,255,255,0.05)] hover:border-white/15 transition-all duration-150">
        {/* Row 1: Action Title & Time */}
        <div className="flex justify-between items-center border-b border-white/10 pb-1.5 font-black tracking-wider text-xs text-white/90">
          <span>{title}</span>
          <span className="text-[10px] text-white/50 font-medium">{timeStr}</span>
        </div>

        {/* Row 2: Description & Payload (prominent for webhook events and footprints with details) */}
        {isWebhook ? (
          <div className="text-[11px] text-white/90 font-sans leading-relaxed">
            <div>{summary}</div>
            {detailsList.length > 0 && (
              <div className="flex flex-wrap items-center gap-1.5 text-[10px] text-white/70 font-mono mt-1">
                {detailsList.map((item, idx) => (
                  <span key={idx} className="bg-white/5 border border-white/10 px-1.5 py-0.5">
                    {item}
                  </span>
                ))}
              </div>
            )}
          </div>
        ) : (log.details || detailsList.length > 0) ? (
          <div className="text-[11px] text-white/80 font-sans leading-relaxed">
            <div>{summary}</div>
            {detailsList.length > 0 && (
              <div className="flex flex-wrap items-center gap-1.5 text-[10px] text-white/70 font-mono mt-1">
                {detailsList.map((item, idx) => (
                  <span key={idx} className="bg-white/5 border border-white/10 px-1.5 py-0.5">
                    {item}
                  </span>
                ))}
              </div>
            )}
          </div>
        ) : null}

        {/* Row 3: Endpoint Used / Inbound Channel */}
        <div className="text-[11px] text-white/80 font-bold flex flex-wrap items-center gap-1.5">
          <span className="text-white/50 text-[10px] uppercase tracking-wider font-semibold">
            {isWebhook ? 'Inbound Channel:' : 'Endpoint Used:'}
          </span>
          <code className="bg-white/5 px-2 py-0.5 border border-white/15 text-[11px] font-bold text-white/90">
            {fullEndpoint}
          </code>
        </div>

        {/* Row 4: Direct Link Boxes */}
        <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-white/10">
          {isClusterTarget && renderClusterBadge(targetStr || detailsObj?.clusterId, detailsObj)}
          {isThreadTarget && targetStr && (onOpenThread || onOpenPost) && (
            <button
              type="button"
              onClick={() => {
                const targetId = detailsObj?.postId || detailsObj?.id || targetStr.replace('#', '');
                if (isPostTarget) {
                  if (onOpenPost) {
                    onOpenPost(targetId, detailsObj);
                  } else if (onOpenThread) {
                    onOpenThread(targetId, detailsObj, 'post');
                  }
                } else {
                  if (onOpenThread) {
                    onOpenThread(targetId, detailsObj, 'bid');
                  }
                }
              }}
              className="font-black text-white/80 bg-[#141414] hover:bg-white hover:text-[#141414] border border-white/20 px-2.5 py-1 transition-all cursor-pointer text-[10px] tracking-wider uppercase shadow-[1px_1px_0px_0px_rgba(255,255,255,0.05)] active:translate-x-[1px] active:translate-y-[1px]"
            >
              Thread #{targetShort}
            </button>
          )}
          {!isClusterTarget && !isThreadTarget && entities.isRequest && (
            <>
              {entities.agentId && renderAgentBadge(entities.agentId, entities.agentName, entities.agentAvatar, log.details)}
              {entities.requestId && renderRequestBadge(entities.requestId)}
            </>
          )}
          {!isClusterTarget && !isThreadTarget && !entities.isRequest && (
            renderAgentBadge(entities.agentId || targetStr || log.senderId, entities.agentName, entities.agentAvatar, log.details)
          )}
          {onOpenChat && isChatable && (
            <button
              type="button"
              onPointerEnter={() => handleWarmupChatForLog(log)}
              onPointerDown={() => handleWarmupChatForLog(log)}
              onFocus={() => handleWarmupChatForLog(log)}
              onClick={() => handleOpenChat(log)}
              className="font-black text-[#141414] bg-white/90 hover:bg-white border border-white/10 px-2.5 py-1 transition-all cursor-pointer text-[10px] tracking-wider uppercase shadow-[1px_1px_0px_0px_rgba(255,255,255,0.05)] active:translate-x-[1px] active:translate-y-[1px]"
            >
              Open Chat
            </button>
          )}
          {onOpenRequestsTab && entities.isRequest && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onOpenRequestsTab();
              }}
              className="font-black text-[#141414] bg-white/90 hover:bg-white border border-white/10 px-2.5 py-1 transition-all cursor-pointer text-[10px] tracking-wider uppercase shadow-[1px_1px_0px_0px_rgba(255,255,255,0.05)] active:translate-x-[1px] active:translate-y-[1px] flex items-center gap-1.5"
              title="Redirect to Account Requests tab"
            >
              <Inbox className="w-3.5 h-3.5 text-[#141414]" />
              <span>Account Requests</span>
            </button>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="bg-[#141414] border-2 border-[#141414] shadow-[4px_4px_0px_0px_rgba(20,20,20,1)] p-4 sm:p-6 md:p-8 space-y-4 sm:space-y-5 text-left font-mono text-white">
      {/* Header Bar */}
      <div className="flex items-center justify-between pb-3 sm:pb-4 border-b-2 border-white flex-nowrap min-w-0 gap-2">
        <div className="flex items-center gap-1.5 sm:gap-2.5 flex-nowrap min-w-0">
          <div className="p-1 sm:p-1.5 bg-[#141414] text-white border border-white shrink-0 flex items-center justify-center">
            <GitCommit className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white" />
          </div>
          <h2 className="text-[10px] sm:text-xs md:text-sm font-black uppercase tracking-tight sm:tracking-wider text-white whitespace-nowrap shrink-0">
            Inbound & Outbound Activities
          </h2>
        </div>
        <button
          type="button"
          onClick={() => {
            if (activeTab === 'outbound') {
              setOutboundRefreshKey((k) => k + 1);
            } else {
              fetchLogs(activeTab, true);
            }
          }}
          className="p-1 sm:p-1.5 bg-[#141414] hover:bg-white/10 border border-white/20 text-white transition-all cursor-pointer shadow-[1px_1px_0px_0px_rgba(255,255,255,0.05)] active:translate-x-[1px] active:translate-y-[1px] shrink-0"
          title="Refresh logs"
          aria-label="Refresh logs"
        >
          <RotateCw className={`w-3 h-3 sm:w-3.5 sm:h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {/* Tab Switcher */}
      <div className="flex gap-1 border-b border-white/10 pb-2">
        <button
          onClick={() => {
            setActiveTab('footprints');
            setActivityCache(accountKey, { activeTab: 'footprints' });
          }}
          className={`text-[10px] uppercase font-black px-3 py-1.5 transition-all ${
            activeTab === 'footprints'
              ? 'bg-white text-[#141414]'
              : 'bg-white/5 text-white/50 hover:bg-white/10'
          }`}
        >
          Footprints
        </button>
        <button
          onClick={() => {
            setActiveTab('webhooks');
            setActivityCache(accountKey, { activeTab: 'webhooks' });
          }}
          className={`text-[10px] uppercase font-black px-3 py-1.5 transition-all ${
            activeTab === 'webhooks'
              ? 'bg-white text-[#141414]'
              : 'bg-white/5 text-white/50 hover:bg-white/10'
          }`}
        >
          Webhooks Inbox
        </button>
        <button
          onClick={() => {
            setActiveTab('outbound');
            setActivityCache(accountKey, { activeTab: 'outbound' });
          }}
          className={`text-[10px] uppercase font-black px-3 py-1.5 transition-all ${
            activeTab === 'outbound'
              ? 'bg-white text-[#141414]'
              : 'bg-white/5 text-white/50 hover:bg-white/10'
          }`}
        >
          Outbound Webhooks
        </button>
      </div>

      {/* Footprints Scroll Container - Preserved across tab switches */}
      <div className={`max-h-[360px] overflow-y-auto space-y-3 pr-1 ${activeTab === 'footprints' ? '' : 'hidden'}`}>
        {footprintsError && (
          <div className="p-2.5 text-[11px] text-red-300 border border-red-500/40 bg-red-950/30 font-mono">
            {footprintsError}
          </div>
        )}
        {isLoadingFootprints && footprintsLogs.length === 0 ? (
          <div className="flex justify-center items-center py-12 bg-white/5 border-2 border-dashed border-white/20">
            <BrutalistLoader text="Synchronizing" size="sm" theme="dark" className="py-4" />
          </div>
        ) : footprintsLogs.length > 0 ? (
          footprintsLogs.map((log) => renderLogItem(log, false))
        ) : (
          <div className="p-8 text-center text-xs text-white/60 border-2 border-dashed border-white/20 bg-white/5 uppercase tracking-wider font-bold">
            No activity records found.
          </div>
        )}
      </div>

      {/* Webhooks Scroll Container - Preserved across tab switches */}
      <div className={`max-h-[360px] overflow-y-auto space-y-3 pr-1 ${activeTab === 'webhooks' ? '' : 'hidden'}`}>
        {webhooksError && (
          <div className="p-2.5 text-[11px] text-red-300 border border-red-500/40 bg-red-950/30 font-mono">
            {webhooksError}
          </div>
        )}
        {isLoadingWebhooks && webhooksLogs.length === 0 ? (
          <div className="flex justify-center items-center py-12 bg-white/5 border-2 border-dashed border-white/20">
            <BrutalistLoader text="Synchronizing" size="sm" theme="dark" className="py-4" />
          </div>
        ) : webhooksLogs.length > 0 ? (
          webhooksLogs.map((log) => renderLogItem(log, true))
        ) : (
          <div className="p-8 text-center text-xs text-white/60 border-2 border-dashed border-white/20 bg-white/5 uppercase tracking-wider font-bold">
            No activity records found.
          </div>
        )}
      </div>

      {/* Outbound Webhooks Manager Tab */}
      <div className={`${activeTab === 'outbound' ? '' : 'hidden'}`}>
        <WebhookManager refreshTrigger={outboundRefreshKey} />
      </div>
    </div>
  );
};
