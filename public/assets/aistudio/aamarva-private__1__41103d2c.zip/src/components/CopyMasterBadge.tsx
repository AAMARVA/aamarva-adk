import React from 'react';
import { Copy, Infinity as InfinityIcon } from 'lucide-react';

export type CopySyncPolicy = 'one_time' | 'forever' | null | undefined;

interface CopyMasterBadgeProps {
  policy: CopySyncPolicy;
  className?: string;
}

export function resolveModuleCopyPolicy(
  settings: any,
  flagKey: 'copyAccessManagement' | 'copyAccountIps' | 'copyApiKeyRotation' | 'copyGlobalLogout',
  policyKey: 'accessSyncPolicy' | 'ipSyncPolicy' | 'rotationSyncPolicy' | 'logoutSyncPolicy',
  slaveIdsKey: 'accessSlaveIds' | 'ipSlaveIds' | 'rotationSlaveIds' | 'logoutSlaveIds',
  forSlaveAccount?: { id?: string | null; agentId?: string | null } | null
): 'one_time' | 'forever' | null {
  if (!settings || !settings[flagKey]) return null;
  const targetSlaves =
    Array.isArray(settings[slaveIdsKey]) && settings[slaveIdsKey].length > 0
      ? settings[slaveIdsKey]
      : Array.isArray(settings.selectedSlaveIds)
      ? settings.selectedSlaveIds
      : [];
  if (targetSlaves.length === 0) return null;

  if (forSlaveAccount) {
    const norm = (val: any) => String(val || '').trim().replace(/^@/, '').toLowerCase();
    const myId = norm(forSlaveAccount.id);
    const myAgentId = norm(forSlaveAccount.agentId);
    const isTargeted = targetSlaves.some((entry: any) => {
      const clean = norm(entry);
      return Boolean(clean && ((myId && clean === myId) || (myAgentId && clean === myAgentId)));
    });
    if (!isTargeted) return null;
  }

  const rawPolicy = settings[policyKey] || settings.syncPolicy;
  return rawPolicy === 'one_time' ? 'one_time' : 'forever';
}

export const CopyMasterBadge: React.FC<CopyMasterBadgeProps> = ({ policy, className = '' }) => {
  if (policy !== 'one_time' && policy !== 'forever') {
    return null;
  }

  const isOneTime = policy === 'one_time';
  const label = isOneTime
    ? 'Copy Master Active: One-Time Copy (1)'
    : 'Copy Master Active: Copy Forever (∞)';

  return (
    <span
      title={label}
      aria-label={label}
      className={`inline-flex items-center gap-1 px-1.5 py-0.5 bg-[#141414] text-white border border-[#141414] ring-1 ring-white font-mono text-[9px] font-black leading-none shadow-[1.5px_1.5px_0px_0px_rgba(20,20,20,1)] select-none shrink-0 ${className}`}
    >
      <Copy className="w-2.5 h-2.5 shrink-0" />
      {isOneTime ? (
        <span className="leading-none">1</span>
      ) : (
        <InfinityIcon className="w-3 h-3 shrink-0 stroke-[2.5]" />
      )}
    </span>
  );
};
