import React, { useState, useEffect } from 'react';
import { 
  Users, MessageSquare, Shield, ShieldAlert, ChevronRight, Plus
} from 'lucide-react';
import { apiFetch, isSlaveAccount, getCurrentSessionAuthType } from '../services/authApi';
import { getClusterSymbol } from '../lib/clusterSymbols';
import { AgentAvatar } from './AgentAvatar';
import { useAuth } from '../context/AuthContext';
import { warmupClusterChat } from '../lib/chatMessageWarmup';
import { getAccountKey } from '../lib/appStateCache';

interface ClustersTabContentProps {
  clusters: any[];
  onRefreshClusters: () => void;
  currentAgentId: string;
  currentAgentName: string;
  onOpenClusterMembers?: (cluster: any) => void;
  onOpenAgentProfile?: (agentName: string, avatar?: string, agentId?: string) => void;
  onOpenChat?: (chat: any) => void;
  onOpenClusterChat?: (cluster: { id: string; name: string; symbol?: string }) => void;
}

export function ClustersTabContent({ 
  clusters, 
  onRefreshClusters, 
  currentAgentId, 
  currentAgentName,
  onOpenClusterMembers,
  onOpenAgentProfile,
  onOpenChat,
  onOpenClusterChat,
}: ClustersTabContentProps) {
  const { isAuthenticated, user, activeAccount, userPassword, sessionAuthType } = useAuth();
  const isSlave = isSlaveAccount(activeAccount);
  
  // Creating clusters state
  const [isCreating, setIsCreating] = useState(false);
  const [newClusterName, setNewClusterName] = useState('');
  const [newClusterDescription, setNewClusterDescription] = useState('');
  const [createLoading, setCreateLoading] = useState(false);
  const [createError, setCreateError] = useState('');


  // Initial load
  useEffect(() => {

    const handleClusterUpdated = () => {
      onRefreshClusters();
    };

    window.addEventListener('cluster-updated', handleClusterUpdated);
    return () => {
      window.removeEventListener('cluster-updated', handleClusterUpdated);
    };
  }, [isAuthenticated, onRefreshClusters]);

  // Handle Create Cluster
  const handleCreateCluster = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreateError('');
    const name = newClusterName.trim();
    if (!name) {
      setCreateError('Cluster name is required.');
      return;
    }

    setCreateLoading(true);
    try {
      const res = await apiFetch('/api/clusters', {
        authType: 'human',
        method: 'POST',
        body: JSON.stringify({
          name,
          description: newClusterDescription.trim() || undefined,
          isPublic: true
        })
      });

      if (res?.success && res.data) {
        const clusterId = res.data.id || res.data.clusterId;
        setNewClusterName('');
        setNewClusterDescription('');
        setIsCreating(false);
        onRefreshClusters();
      } else {
        setCreateError(res?.error?.message || 'Failed to create cluster.');
      }
    } catch (err: any) {
      setCreateError(err?.message || 'Failed to create cluster.');
    } finally {
      setCreateLoading(false);
    }
  };


  const activeClusters = clusters.filter((c) => {
    if (c.status === 'dissolved') return false;
    if (isSlave) {
        // Assume c has a list of members. We'll check if the slave's ID is in the members list.
        // Cluster object might have `members` (array of objects) or `memberIds`.
        return c.members?.some((m: any) => m.id === activeAccount?.id || m.agentId === activeAccount?.agentId) || 
               c.memberIds?.includes(activeAccount?.id);
    }
    return true;
  });
  const dissolvedClusters = clusters.filter((c) => c.status === 'dissolved');

  return (
    <div className="space-y-6 text-left font-sans">

      {/* 2. Create Cluster UI */}
      {isCreating && (
        <div className="p-4 bg-white border-2 border-[#141414] shadow-[4px_4px_0px_0px_rgba(20,20,20,1)] animate-in slide-in-from-top-2 duration-200">
          <form onSubmit={handleCreateCluster} className="space-y-4">
            {createError && <p className="text-[10px] font-bold text-[#141414] font-bold font-mono uppercase">{createError}</p>}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="block font-mono text-[10px] font-black uppercase text-[#141414]/60">Name</label>
                <input
                  type="text"
                  required
                  value={newClusterName}
                  onChange={(e) => setNewClusterName(e.target.value)}
                  placeholder="e.g. ALPHA SQUAD"
                  className="w-full bg-[#F5F4F0] border-2 border-[#141414] p-2 font-mono text-xs focus:outline-none"
                />
              </div>
              <div className="space-y-1.5">
                <label className="block font-mono text-[10px] font-black uppercase text-[#141414]/60">Description</label>
                <input
                  type="text"
                  value={newClusterDescription}
                  onChange={(e) => setNewClusterDescription(e.target.value)}
                  placeholder="Secure protocol ops..."
                  className="w-full bg-[#F5F4F0] border-2 border-[#141414] p-2 font-mono text-xs focus:outline-none"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <button
                type="submit"
                disabled={createLoading}
                className="flex-1 py-2 bg-[#141414] text-white font-mono text-xs font-black uppercase tracking-wider shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:bg-black disabled:opacity-50 cursor-pointer"
              >
                {createLoading ? 'Deploying...' : 'Initialize Cluster'}
              </button>
              <button
                type="button"
                onClick={() => setIsCreating(false)}
                className="px-4 py-2 border-2 border-[#141414] font-mono text-xs font-black uppercase tracking-wider hover:bg-[#E4E3E0] cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}


      {/* 4. Active Clusters Section */}
      <div className="space-y-3">
        <div className="flex items-center gap-2 border-b border-[#141414]/10 pb-2">
          <Shield className="w-3.5 h-3.5 text-[#141414]/70" />
          <h3 className="font-mono text-xs font-black uppercase text-[#141414]">
            Active clusters ({activeClusters.length})
          </h3>
        </div>

        {activeClusters.length > 0 ? (
          <div className="max-h-[440px] sm:max-h-[225px] overflow-y-auto pr-1.5 p-1 custom-scrollbar">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
              {activeClusters.map((cl) => {
                const sym = getClusterSymbol(cl.id);
                const currentProfile = activeAccount || user;
                const isMaster = Boolean(
                  (currentProfile as any)?.account_type === 'master' ||
                  (currentProfile as any)?.isMasterUser === true ||
                  (currentProfile as any)?.is_master_primary === true ||
                  (currentProfile as any)?.isMasterPrimary === true ||
                  user?.account_type === 'master' ||
                  (user as any)?.isMasterUser === true
                );
                const currentAid = (currentProfile?.agentId || currentAgentId || '').toLowerCase();
                const currentUid = (currentProfile?.id || '').toLowerCase();
                const isOwner = Boolean(
                  (cl.ownerAgentId && currentAid && cl.ownerAgentId.toLowerCase() === currentAid) ||
                  (cl.ownerUserId && currentUid && cl.ownerUserId.toLowerCase() === currentUid)
                );
                const isAdmin = cl.role === 'admin' || cl.role === 'owner';
                const canEdit = isAuthenticated && (isMaster || isOwner || isAdmin);

                const triggerWarmup = () => {
                  const curAid = currentProfile?.agentId || currentAgentId;
                  const curUid = currentProfile?.id || user?.id || 'anon';
                  if (curAid && cl?.id) {
                    warmupClusterChat({
                      clusterId: cl.id,
                      clusterName: cl.name,
                      activeCluster: cl,
                      accountKey: getAccountKey(user?.id, activeAccount?.id),
                      accountId: curUid,
                      userAgentId: curAid,
                      userPassword,
                      authType: sessionAuthType || getCurrentSessionAuthType() || 'human',
                    }).catch(() => {});
                  }
                };

                return (
                  <div 
                    key={cl.id}
                    onClick={() => onOpenClusterChat?.({ id: cl.id, name: cl.name, symbol: sym })}
                    onPointerEnter={triggerWarmup}
                    onPointerDown={triggerWarmup}
                    className="p-3.5 sm:p-4 bg-white border-2 border-[#141414] hover:bg-[#E4E3E0]/15 shadow-[4px_4px_0px_0px_rgba(20,20,20,1)] hover:shadow-[6px_6px_0px_0px_rgba(20,20,20,1)] transition-all cursor-pointer flex flex-col justify-between gap-3 text-left"
                  >
                    <div className="space-y-2">
                      <div className="flex items-center justify-between gap-2.5 sm:gap-3">
                        <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
                          <div className="w-9 h-9 sm:w-10 sm:h-10 bg-[#141414] text-white border-2 border-[#141414] font-mono text-sm flex items-center justify-center font-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] shrink-0">
                            {sym}
                          </div>
                          <div className="min-w-0">
                            <h4 className="font-mono font-black uppercase text-xs sm:text-sm tracking-wide text-[#141414] overflow-x-auto no-scrollbar whitespace-nowrap">
                              <span>{cl.name}</span>
                            </h4>
                          </div>
                        </div>
                        <div className="flex items-center gap-1.5 shrink-0">
                          {canEdit && onOpenClusterMembers && (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                onOpenClusterMembers({ ...cl, initialEdit: true });
                              }}
                              className="py-1 sm:py-1.5 px-2.5 sm:px-3 bg-white text-[#141414] border-2 border-[#141414] font-mono text-[10px] sm:text-xs font-black uppercase tracking-wider hover:bg-[#141414] hover:text-white transition-all cursor-pointer shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] active:translate-x-0.5 active:translate-y-0.5 active:shadow-none flex items-center gap-1 shrink-0"
                              title="Edit Cluster (Admin or Master)"
                            >
                              <span>Edit</span>
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              onOpenClusterChat?.({ id: cl.id, name: cl.name, symbol: sym });
                            }}
                            onPointerEnter={triggerWarmup}
                            onPointerDown={triggerWarmup}
                            className="py-1 sm:py-1.5 px-2.5 sm:px-3 bg-[#141414] text-white border-2 border-[#141414] font-mono text-[10px] sm:text-xs font-black uppercase tracking-wider hover:bg-white hover:text-[#141414] transition-all cursor-pointer shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] active:translate-x-0.5 active:translate-y-0.5 active:shadow-none flex items-center gap-1.5 shrink-0"
                          >
                            <MessageSquare className="w-3.5 h-3.5" />
                            <span>Open It</span>
                          </button>
                        </div>
                      </div>

                      {cl.description && (
                        <p className="text-xs text-[#141414] italic border-l-[3px] border-[#141414] pl-2.5 overflow-x-auto no-scrollbar whitespace-nowrap">
                          <span>"{cl.description}"</span>
                        </p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          <div className="py-8 px-4 text-center border-2 border-dashed border-[#141414]/20 bg-[#E4E3E0]/10 flex flex-col items-center justify-center gap-2">
            <Shield className="w-5 h-5 opacity-30 text-[#141414]" />
            <div className="font-mono text-[10px] font-bold uppercase tracking-widest text-[#141414]/40">No Active Clusters</div>
          </div>
        )}
      </div>
    </div>
  );
}
