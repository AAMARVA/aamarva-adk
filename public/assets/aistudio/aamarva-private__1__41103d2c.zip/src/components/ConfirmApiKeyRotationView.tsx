import React, { useState, useEffect } from 'react';
import {
  CheckCircle2,
  RotateCw,
  ArrowRight,
  AlertTriangle,
  Key,
  ShieldCheck,
  Copy,
  Check,
  Boxes,
  Terminal,
  Download,
  AlertCircle,
} from 'lucide-react';
import { confirmAgentApiKeyRotationApi } from '../services/authApi';
import { executeWebAuthnAssertion } from '../services/webauthnClient';
import { getQueryCache, setQueryCache, invalidateQuery } from '../lib/appStateCache';

interface RotatedSlaveResult {
  id?: string;
  agentId: string;
  name: string;
  apiKey: string;
}

interface ConfirmApiKeyRotationViewProps {
  token: string;
  onBackToHome: () => void;
}

export const ConfirmApiKeyRotationView: React.FC<ConfirmApiKeyRotationViewProps> = ({
  token,
  onBackToHome,
}) => {
  const [status, setStatus] = useState<'pending' | 'verifying' | 'success' | 'error'>('pending');
  const [error, setError] = useState('');
  const [newApiKey, setNewApiKey] = useState('');
  const [rotatedAgentId, setRotatedAgentId] = useState('');
  const [rotatedAccountName, setRotatedAccountName] = useState('');
  const [copiedId, setCopiedId] = useState(false);
  const [rotatedSlaves, setRotatedSlaves] = useState<RotatedSlaveResult[]>([]);
  const [isMasterRotation, setIsMasterRotation] = useState(false);
  const [requiresWebAuthn, setRequiresWebAuthn] = useState(false);
  const [webAuthnData, setWebAuthnData] = useState<any>(null);
  const [copied, setCopied] = useState(false);
  const [bulkCopiedField, setBulkCopiedField] = useState<string | null>(null);

  const handleConfirm = async (webAuthnOverride?: any) => {
    if (!token) {
      setError('No rotation token provided.');
      setStatus('error');
      return;
    }

    setStatus('verifying');
    try {
      const res = await confirmAgentApiKeyRotationApi(token, webAuthnOverride);

      if (res.requiresWebAuthn) {
        setWebAuthnData(res);
        setRequiresWebAuthn(true);
        setStatus('pending');
        return;
      }

      if (Array.isArray(res.rotatedSlaves) && res.rotatedSlaves.length > 0) {
        setRotatedSlaves(res.rotatedSlaves);
      } else {
        setRotatedSlaves([]);
      }
      setIsMasterRotation(Boolean(res.isMasterRotation));
      setNewApiKey(res.apiKey || '');
      setRotatedAgentId(res.agentId || res.masterAgent?.agentId || '');
      setRotatedAccountName(res.name || res.masterAgent?.name || '');
      if (res.masterCopySettings !== undefined) {
        try {
          const cached = getQueryCache('master_accounts', '/api/auth/master/accounts', Number.MAX_SAFE_INTEGER)?.data;
          if (cached) {
            setQueryCache('master_accounts', '/api/auth/master/accounts', {
              ...cached,
              masterCopySettings: res.masterCopySettings || null,
            });
          }
        } catch {}
        window.dispatchEvent(new CustomEvent('aamarva-copy-master-updated', { detail: res.masterCopySettings || null }));
      } else if (res.isMasterRotation) {
        invalidateQuery('/api/auth/master/accounts');
        window.dispatchEvent(new CustomEvent('aamarva-copy-master-updated'));
      }
      window.dispatchEvent(new CustomEvent('aamarva-agents-updated'));
      setStatus('success');
    } catch (err: any) {
      setError(err.message || 'Rotation failed. The link may be expired or invalid.');
      setStatus('error');
    }
  };

  const handleWebAuthnAssertion = async () => {
    if (!webAuthnData) return;

    setStatus('verifying');
    try {
      const isSetup = webAuthnData.status === 'WEBAUTHN_SETUP_REQUIRED';
      const credentialResponse = await executeWebAuthnAssertion(webAuthnData.options, isSetup);

      await handleConfirm({
        pendingToken: webAuthnData.pendingToken,
        credentialResponse,
        isSetup,
      });
    } catch (err: any) {
      setError(err.message || 'WebAuthn passkey verification failed.');
      setStatus('error');
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(newApiKey);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCopyAllJson = () => {
    if (rotatedSlaves.length === 0) return;
    const exportList = rotatedSlaves.map((s) => ({
      ...(s.id ? { accountId: s.id } : {}),
      agentId: s.agentId,
      name: s.name,
      apiKey: s.apiKey,
    }));
    navigator.clipboard.writeText(JSON.stringify(exportList, null, 2));
    setBulkCopiedField('all_json');
    setTimeout(() => setBulkCopiedField(null), 2500);
  };

  const handleCopyAllEnv = () => {
    if (rotatedSlaves.length === 0) return;
    const envText = rotatedSlaves
      .map(
        (a, i) =>
          `# Slave Node ${i + 1}: ${a.name || a.agentId}\nAAMARVA_AGENT_ID_${i + 1}=${a.agentId}\nAAMARVA_API_KEY_${i + 1}=${a.apiKey}`
      )
      .join('\n\n');
    navigator.clipboard.writeText(envText);
    setBulkCopiedField('all_env');
    setTimeout(() => setBulkCopiedField(null), 2500);
  };

  const handleDownloadCsv = () => {
    if (rotatedSlaves.length === 0) return;
    const header = 'Account Name,Account ID (Agent ID),New API Key\n';
    const rows = rotatedSlaves
      .map((a) => `"${(a.name || '').replace(/"/g, '""')}","${a.agentId}","${a.apiKey}"`)
      .join('\n');
    const blob = new Blob([header + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `aamarva_rotated_slave_credentials_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    setBulkCopiedField('all_csv');
    setTimeout(() => setBulkCopiedField(null), 2500);
  };

  useEffect(() => {
    if (!token) {
      setError('No rotation token provided.');
      setStatus('error');
    }
  }, [token]);

  const showBulkRotatedView = status === 'success' && rotatedSlaves.length > 0;

  if (showBulkRotatedView) {
    return (
      <div className="w-full max-w-2xl mx-auto py-8 px-3 animate-in fade-in duration-500">
        <div className="bg-[#F8F7F4] border-4 border-[#141414] shadow-[12px_12px_0px_0px_rgba(20,20,20,1)] text-[#141414] flex flex-col font-mono">
          {/* Header (Matches Bulk Deploy Credentials Issued Modal) */}
          <div className="bg-[#141414] text-white px-4 py-3 flex items-center justify-between border-b-4 border-[#141414] select-none shrink-0">
            <div className="flex items-center gap-2">
              <Boxes className="w-4 h-4 text-white shrink-0" />
              <span className="font-mono text-xs font-black uppercase tracking-widest">
                CASCADE ROTATION: {rotatedSlaves.length} SLAVE CREDENTIAL{rotatedSlaves.length === 1 ? '' : 'S'} ISSUED
              </span>
            </div>
            <span className="px-2 py-0.5 bg-white text-[#141414] text-[9px] font-black uppercase">
              REVOKED &amp; REISSUED
            </span>
          </div>

          <div className="p-4 sm:p-6 space-y-4">
            {/* Warning Banner */}
            <div className="p-3.5 bg-white border-2 border-[#141414] shadow-[3px_3px_0px_0px_rgba(20,20,20,1)] text-[10px] text-neutral-800 font-bold leading-relaxed space-y-1 text-left">
              <p className="uppercase text-[#141414] font-black flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5 text-red-600 shrink-0" />
                CRITICAL: COPY AND STORE THESE KEYS NOW
              </p>
              <p>
                All prior API keys for the {rotatedSlaves.length} slave account{rotatedSlaves.length === 1 ? '' : 's'} below have been permanently revoked. New Account IDs and API Keys have also been dispatched to your registered email and will <strong>never</strong> be displayed again in plain text.
              </p>
            </div>

            {/* Bulk Export Action Controls */}
            <div className="flex items-center justify-between flex-wrap gap-2 border-b-2 border-[#141414] pb-3">
              <div className="text-[10px] font-black uppercase text-[#141414]">
                Quick Export All {rotatedSlaves.length} Account{rotatedSlaves.length === 1 ? '' : 's'}:
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={handleCopyAllJson}
                  className="px-2.5 py-1.5 bg-white hover:bg-[#141414] hover:text-white border-2 border-[#141414] text-[9.5px] font-black uppercase tracking-wider transition-all flex items-center gap-1.5 shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] cursor-pointer"
                >
                  {bulkCopiedField === 'all_json' ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                  <span>{bulkCopiedField === 'all_json' ? 'JSON Copied!' : 'Copy JSON'}</span>
                </button>
                <button
                  type="button"
                  onClick={handleCopyAllEnv}
                  className="px-2.5 py-1.5 bg-white hover:bg-[#141414] hover:text-white border-2 border-[#141414] text-[9.5px] font-black uppercase tracking-wider transition-all flex items-center gap-1.5 shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] cursor-pointer"
                >
                  {bulkCopiedField === 'all_env' ? <Check className="w-3 h-3 text-emerald-600" /> : <Terminal className="w-3 h-3" />}
                  <span>{bulkCopiedField === 'all_env' ? '.ENV Copied!' : 'Copy .ENV'}</span>
                </button>
                <button
                  type="button"
                  onClick={handleDownloadCsv}
                  className="px-2.5 py-1.5 bg-[#141414] text-white hover:bg-black border-2 border-[#141414] text-[9.5px] font-black uppercase tracking-wider transition-all flex items-center gap-1.5 shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] cursor-pointer"
                >
                  <Download className="w-3 h-3 text-white" />
                  <span>Download CSV</span>
                </button>
              </div>
            </div>

            {/* Agent Credentials Cards */}
            <div className="space-y-3 max-h-[55vh] overflow-y-auto pr-1">
              {rotatedSlaves.map((agent, idx) => {
                const isIdCopied = bulkCopiedField === `id_${agent.agentId}`;
                const isKeyCopied = bulkCopiedField === `key_${agent.agentId}`;

                return (
                  <div
                    key={agent.id || agent.agentId || idx}
                    className="bg-white border-2 border-[#141414] p-3 shadow-[3px_3px_0px_0px_rgba(20,20,20,1)] space-y-2.5"
                  >
                    <div className="flex items-center justify-between border-b border-[#141414]/15 pb-2 gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <span className="px-1.5 py-0.5 bg-[#141414] text-white text-[9px] font-black shrink-0">
                          #{idx + 1}
                        </span>
                        <span className="text-xs font-black uppercase text-[#141414] truncate">
                          {agent.name || agent.agentId}
                        </span>
                      </div>
                      <span className="text-[9px] text-zinc-500 font-mono font-bold shrink-0">
                        SLAVE NODE
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-left">
                      {/* Account ID / Agent ID */}
                      <div className="space-y-1">
                        <label className="block text-[8.5px] font-black uppercase text-zinc-600">
                          Account ID (Agent ID)
                        </label>
                        <div className="flex items-center gap-1">
                          <div className="flex-1 bg-[#F8F7F4] border border-[#141414] px-2 py-1.5 text-[10px] font-bold select-all truncate text-[#141414]">
                            {agent.agentId}
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              navigator.clipboard.writeText(agent.agentId);
                              setBulkCopiedField(`id_${agent.agentId}`);
                              setTimeout(() => setBulkCopiedField(null), 2000);
                            }}
                            className="p-1.5 border border-[#141414] bg-white hover:bg-[#141414] hover:text-white transition-all cursor-pointer shrink-0"
                            title="Copy Account ID"
                          >
                            {isIdCopied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      </div>

                      {/* New API Key */}
                      <div className="space-y-1">
                        <label className="block text-[8.5px] font-black uppercase text-zinc-600">
                          API Key (Secret)
                        </label>
                        <div className="flex items-center gap-1">
                          <div className="flex-1 bg-[#F8F7F4] border border-[#141414] px-2 py-1.5 text-[10px] font-bold select-all truncate text-[#141414]">
                            {agent.apiKey}
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              navigator.clipboard.writeText(agent.apiKey);
                              setBulkCopiedField(`key_${agent.agentId}`);
                              setTimeout(() => setBulkCopiedField(null), 2000);
                            }}
                            className="p-1.5 border border-[#141414] bg-white hover:bg-[#141414] hover:text-white transition-all cursor-pointer shrink-0"
                            title="Copy API Key"
                          >
                            {isKeyCopied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="p-3 bg-white border-t-2 border-[#141414] shrink-0">
            <button
              type="button"
              onClick={onBackToHome}
              className="w-full py-3 bg-[#141414] text-white hover:bg-black font-mono text-xs font-black uppercase tracking-wider border-2 border-[#141414] shadow-[4px_4px_0px_0px_rgba(20,20,20,1)] active:translate-x-[1px] active:translate-y-[1px] active:shadow-none transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              Return to Home
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full max-w-xl mx-auto py-12 animate-in fade-in duration-500">
      <div className="bg-white border-4 border-[#141414] shadow-[12px_12px_0px_0px_rgba(20,20,20,1)] p-8 sm:p-12 text-[#141414]">
        <div className="flex justify-center mb-8">
          <div className="p-4 bg-[#141414] text-white rounded-full shadow-[4px_4px_0px_0px_rgba(0,0,0,0.2)]">
            <Key className="w-8 h-8" />
          </div>
        </div>

        <div className="text-center space-y-6">
          <h1 className="text-3xl font-serif italic tracking-tight">API Key Security</h1>
          <div className="h-0.5 w-16 bg-black mx-auto"></div>

          {status === 'pending' && (
            <div className="space-y-6 animate-in fade-in duration-300">
              <p className="font-mono text-sm uppercase tracking-widest text-[#141414]/80">
                {requiresWebAuthn ? 'WebAuthn Passkey Required' : 'Final Step Required'}
              </p>

              <div className="p-4 bg-[#E4E3E0]/30 border-2 border-[#141414] font-mono text-xs leading-relaxed text-left">
                {requiresWebAuthn
                  ? 'AAMARVA security protocols require a cryptographic passkey verification to rotate your API key. Please use your device passkey or security key.'
                  : 'You are about to rotate your agent API key. This will invalidate the existing key and generate a new one immediately.'}
              </div>

              {requiresWebAuthn ? (
                <button
                  onClick={handleWebAuthnAssertion}
                  className="w-full py-4 bg-[#141414] text-white font-mono font-black text-xs uppercase tracking-widest border-2 border-[#141414] shadow-[4px_4px_0px_0px_rgba(20,20,20,1)] hover:shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] hover:bg-black transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <ShieldCheck className="w-4 h-4 animate-pulse" />
                  Verify with Passkey
                </button>
              ) : (
                <button
                  onClick={() => handleConfirm()}
                  className="w-full py-4 bg-[#141414] text-white font-mono font-black text-xs uppercase tracking-widest border-2 border-[#141414] shadow-[4px_4px_0px_0px_rgba(20,20,20,0.3)] hover:shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] hover:translate-x-[2px] hover:translate-y-[2px] transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  Confirm Rotation
                  <ArrowRight className="w-4 h-4" />
                </button>
              )}
            </div>
          )}

          {status === 'verifying' && (
            <div className="space-y-4 py-8">
              <RotateCw className="w-8 h-8 animate-spin mx-auto text-[#141414]" />
              <p className="font-mono text-xs uppercase tracking-widest text-[#141414]/70">Generating new key...</p>
            </div>
          )}

          {status === 'success' && (
            <div className="space-y-6 animate-in zoom-in-95 duration-300">
              <div className="p-4 bg-[#E4E3E0]/30 border-2 border-[#141414] text-[#141414] flex items-center gap-3">
                <CheckCircle2 className="w-6 h-6 text-[#141414] shrink-0" />
                <p className="text-sm font-mono font-bold uppercase tracking-tight text-left">
                  {isMasterRotation ? 'Master Confirmation Complete (0 Slaves Rotated)' : 'New API Key Generated'}
                </p>
              </div>

              {isMasterRotation ? (
                <div className="p-4 bg-[#F8F7F4] border-2 border-[#141414] text-left font-mono text-xs leading-relaxed">
                  No slave account API keys were rotated because <strong>Copy Master &rarr; API Key Rotation</strong> was not enabled with selected slave accounts when this request was created.
                </div>
              ) : (
                <div className="space-y-4 text-left">
                  {rotatedAgentId && (
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <label className="block text-[10px] font-mono font-black uppercase text-[#141414]/70">
                          Account ID / Agent ID
                        </label>
                        {rotatedAccountName && (
                          <span className="text-[9.5px] font-mono font-bold text-zinc-600 uppercase">
                            {rotatedAccountName}
                          </span>
                        )}
                      </div>
                      <div className="relative group">
                        <div className="p-3 bg-[#F8F7F4] text-[#141414] border-2 border-[#141414] font-mono text-xs font-bold select-all break-all pr-12">
                          {rotatedAgentId}
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            navigator.clipboard.writeText(rotatedAgentId);
                            setCopiedId(true);
                            setTimeout(() => setCopiedId(false), 2000);
                          }}
                          className="absolute right-2 top-1/2 -translate-y-1/2 p-2 hover:bg-[#141414]/10 rounded-sm transition-colors text-[#141414]"
                          title="Copy Account ID"
                        >
                          {copiedId ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>
                  )}

                  <div className="space-y-1.5">
                    <label className="block text-[10px] font-mono font-black uppercase text-[#141414]/70">
                      New Secret API Key
                    </label>
                    <div className="relative group">
                      <div className="p-3.5 bg-[#141414] text-white border-2 border-[#141414] font-mono text-xs font-bold break-all pr-12">
                        {newApiKey}
                      </div>
                      <button
                        type="button"
                        onClick={handleCopy}
                        className="absolute right-2 top-1/2 -translate-y-1/2 p-2 hover:bg-white/10 rounded-sm transition-colors text-white"
                        title="Copy to clipboard"
                      >
                        {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {!isMasterRotation && (
                <div className="p-4 border-l-4 border-[#141414] bg-white text-left">
                  <p className="text-[10px] font-mono font-black uppercase text-[#141414] mb-1">Critical Security Notice</p>
                  <p className="text-xs font-mono text-[#141414]/80 leading-relaxed italic">
                    Store this key securely. It will never be shown again. All existing agent instances using the old key will now fail authentication and must be updated.
                  </p>
                </div>
              )}

              <button
                onClick={onBackToHome}
                className="w-full py-4 bg-[#141414] text-white font-mono font-black text-xs uppercase tracking-widest border-2 border-[#141414] shadow-[4px_4px_0px_0px_rgba(20,20,20,0.3)] hover:shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] hover:translate-x-[2px] hover:translate-y-[2px] transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                Return to Home
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}

          {status === 'error' && (
            <div className="space-y-6 animate-in zoom-in-95 duration-300">
              <div className="p-4 bg-white border-2 border-[#141414] text-[#141414] font-bold flex items-center gap-3">
                <AlertTriangle className="w-6 h-6 shrink-0" />
                <p className="text-sm font-mono font-bold uppercase tracking-tight text-left">Rotation Error</p>
              </div>

              <div className="p-4 bg-white border-2 border-[#141414] font-mono text-xs text-[#141414] font-bold">
                {error}
              </div>

              <p className="text-xs font-mono text-[#141414]/70 leading-relaxed italic text-left">
                Security tokens are single-use and expire after 30 minutes. If you need to rotate your key, please request a new link from your dashboard.
              </p>

              <button
                onClick={onBackToHome}
                className="w-full py-4 bg-[#141414] text-white font-mono font-black text-xs uppercase tracking-widest border-2 border-[#141414] shadow-[4px_4px_0px_0px_rgba(20,20,20,0.3)] hover:shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] hover:translate-x-[2px] hover:translate-y-[2px] transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                Back to Login
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
