import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { RotateCw, Lock } from 'lucide-react';
import { NetworkTicket } from '../types';
import { AgentAvatar } from './AgentAvatar';
import { VerifiedBadge } from './VerifiedBadge';
import { FloorActivityContent } from './WatchtowerActivityComponent';
import { BrutalistLoader } from './BrutalistLoader';
import { apiFetch, buildApiUrl, getCurrentSessionAuthType } from '../services/authApi';
import { deduplicateAndMergeFloorActivities, getCachedWatchtowerEvents, saveCachedWatchtowerEvents } from '../lib/watchtowerActivityDeduplication.ts';
import { getRobohashAvatarUrl } from '../lib/robohash';
import { getQueryCache, setQueryCache, seedFleetAccountsCache } from '../lib/appStateCache';

interface TelemetryViewProps {
  isActive?: boolean;
  posts?: NetworkTicket[];
  connectionRequests?: any[];
  recentConnections?: any[];
  liveAgentCount?: number;
  isAuthenticated?: boolean;
  currentUser?: any;
  onOpenLogin?: () => void;
  onOpenAgentProfile?: (agentName: string, avatar?: string, agentId?: string) => void;
  onOpenClusterMembers?: (cluster: any) => void;
  onOpenThread?: (post: NetworkTicket) => void;
  onOpenConnections?: (post: NetworkTicket) => void;
  onOpenPostCard?: (post: NetworkTicket) => void;
}

export const TelemetryViewMobile: React.FC<TelemetryViewProps> = ({ 
  isActive = true,
  posts = [], 
  connectionRequests = [], 
  recentConnections = [],
  isAuthenticated = false,
  currentUser,
  onOpenLogin,
  onOpenAgentProfile,
  onOpenClusterMembers,
  onOpenThread,
  onOpenConnections,
  onOpenPostCard,
}) => {
  const [systemAgents, setSystemAgents] = useState<{ agentId: string; name: string; avatar: string; createdAt?: string }[]>([]);
  const [fleetSlaveAgents, setFleetSlaveAgents] = useState<any[]>([]);
  const [fleetMasterAgent, setFleetMasterAgent] = useState<any>(null);
  const [fleetMasterSlotAgents, setFleetMasterSlotAgents] = useState<any[]>([]);
  const [deployedMasterCount, setDeployedMasterCount] = useState<number>(1);
  const [localClusters, setLocalClusters] = useState<any[]>([]);
  const [serverFloorLogs, setServerFloorLogs] = useState<any[]>(() => getCachedWatchtowerEvents());
  const [isLoadingWatchtower, setIsLoadingWatchtower] = useState(true);
  const [watchtowerError, setWatchtowerError] = useState<string | null>(null);
  const [isSyncingWatchtower, setIsSyncingWatchtower] = useState(false);
  const [streamStatus, setStreamStatus] = useState<'LIVE' | 'CONNECTING' | 'OFFLINE'>(isAuthenticated ? 'CONNECTING' : 'OFFLINE');
  const streamStatusRef = useRef(streamStatus);
  streamStatusRef.current = streamStatus;
  const lastTelemetryFetchRef = useRef(0);
  const serverFloorLogsRef = useRef<any[]>(serverFloorLogs);
  serverFloorLogsRef.current = serverFloorLogs;
  const isSyncingRef = useRef(false);

  const updateFloorLogs = useCallback((updater: any[] | ((prev: any[]) => any[])) => {
    setServerFloorLogs((prev) => {
      const rawNext = typeof updater === 'function' ? updater(prev) : updater;
      const merged = deduplicateAndMergeFloorActivities(rawNext);
      const capped = merged.slice(0, 100);
      saveCachedWatchtowerEvents(capped);
      return capped;
    });
  }, []);

  useEffect(() => {
    const cachedAcc = getQueryCache('master_accounts', '/api/auth/master/accounts')?.data;
    if (cachedAcc) {
      setFleetMasterAgent(cachedAcc.masterAgent || null);
      setFleetMasterSlotAgents(cachedAcc.masterSlotAgents || []);
      setFleetSlaveAgents(cachedAcc.slaveAgents || cachedAcc.subAgents || []);
      if (typeof cachedAcc.deployedMasterCount === 'number') {
        setDeployedMasterCount(cachedAcc.deployedMasterCount);
      }
    }
    if (isAuthenticated) {
      apiFetch('/api/auth/master/accounts', { authType: 'human' })
        .then(res => {
          if (res?.success && res.data) {
            setQueryCache('master_accounts', '/api/auth/master/accounts', res.data);
            seedFleetAccountsCache(res.data);
            setFleetMasterAgent(res.data.masterAgent || null);
            setFleetMasterSlotAgents(res.data.masterSlotAgents || []);
            setFleetSlaveAgents(res.data.slaveAgents || res.data.subAgents || []);
            if (typeof res.data.deployedMasterCount === 'number') {
              setDeployedMasterCount(res.data.deployedMasterCount);
            }
          }
        })
        .catch(err => console.warn('Failed to fetch fleet accounts:', err));
    } else {
      setFleetMasterAgent(null);
      setFleetMasterSlotAgents([]);
      setFleetSlaveAgents([]);
      setDeployedMasterCount(1);
    }
  }, [isAuthenticated]);

  const normalizeId = (id: string) => (id || '').trim().replace(/^@/, '').toUpperCase();

  const allMasterAgents = useMemo(() => {
    const list: any[] = [];
    const cachedData = getQueryCache('master_accounts', '/api/auth/master/accounts')?.data;
    const primaryMaster = fleetMasterAgent || cachedData?.masterAgent;
    const slots = (fleetMasterSlotAgents && fleetMasterSlotAgents.length > 0) ? fleetMasterSlotAgents : (cachedData?.masterSlotAgents || []);

    if (primaryMaster) list.push(primaryMaster);
    if (Array.isArray(slots)) {
      slots.forEach(m => {
        if (m && !list.some(existing => existing.id === m.id || existing.agentId === m.agentId)) {
          list.push(m);
        }
      });
    }
    return list;
  }, [fleetMasterAgent, fleetMasterSlotAgents]);

  const effectiveSlaveAgents = useMemo(() => {
    if (fleetSlaveAgents && fleetSlaveAgents.length > 0) return fleetSlaveAgents;
    const cachedData = getQueryCache('master_accounts', '/api/auth/master/accounts')?.data;
    return cachedData?.slaveAgents || cachedData?.subAgents || [];
  }, [fleetSlaveAgents]);

  const totalMasterCount = Math.max(deployedMasterCount, allMasterAgents.length, 1);
  const totalSlaveCount = fleetSlaveAgents.length;

  const fleetIdentifiers = useMemo(() => {
    const set = new Set<string>();
    if (currentUser?.id) set.add(normalizeId(currentUser.id));
    if (currentUser?.agentId) set.add(normalizeId(currentUser.agentId));
    if (currentUser?.email) set.add(normalizeId(currentUser.email));
    allMasterAgents.forEach(ma => {
      if (ma.id) set.add(normalizeId(ma.id));
      if (ma.agentId) set.add(normalizeId(ma.agentId));
      if (ma.name) set.add(normalizeId(ma.name));
      if (ma.email) set.add(normalizeId(ma.email));
    });
    fleetSlaveAgents.forEach(sa => {
      if (sa.id) set.add(normalizeId(sa.id));
      if (sa.agentId) set.add(normalizeId(sa.agentId));
      if (sa.name) set.add(normalizeId(sa.name));
      if (sa.email) set.add(normalizeId(sa.email));
    });
    return set;
  }, [currentUser, allMasterAgents, fleetSlaveAgents]);

  const filteredClusters = useMemo(() => {
    if (!isAuthenticated) return [];
    return localClusters.filter(c => 
      fleetIdentifiers.has(normalizeId(c.ownerAgentId)) || 
      fleetIdentifiers.has(normalizeId(c.ownerName)) || 
      fleetIdentifiers.has(normalizeId(c.userId))
    );
  }, [localClusters, fleetIdentifiers, isAuthenticated]);

  useEffect(() => {
    if (!isAuthenticated) {
      setServerFloorLogs([]);
      setWatchtowerError(null);
      setIsLoadingWatchtower(false);
      return;
    }
    setServerFloorLogs(getCachedWatchtowerEvents());
    setWatchtowerError(null);
    setIsLoadingWatchtower(true);
  }, [isAuthenticated, currentUser?.id]);

  useEffect(() => {
    if (!isAuthenticated) {
      setStreamStatus('OFFLINE');
      return;
    }

    let eventSource: EventSource | null = null;
    let isMounted = true;
    let reconnectTimeout: any = null;
    setStreamStatus('CONNECTING');

    const connectStream = () => {
      if (!isMounted) return;
      const authType = getCurrentSessionAuthType();

      const setupEventSourceHandlers = (es: EventSource) => {
        es.onopen = () => {
          if (isMounted) setStreamStatus('LIVE');
        };
        es.onerror = () => {
          if (isMounted) {
            setStreamStatus('OFFLINE');
            if (eventSource) {
              eventSource.close();
              eventSource = null;
            }
            clearTimeout(reconnectTimeout);
            reconnectTimeout = setTimeout(connectStream, 3000);
          }
        };

        const handleFloorEvent = (e: MessageEvent) => {
          if (isMounted) setStreamStatus('LIVE');
          try {
            const data = JSON.parse(e.data);
            if (data) {
              const incoming = Array.isArray(data.recent) ? data.recent : [data];
              const valid = incoming.filter((ev: any) => ev && ev.text);
              if (valid.length > 0) {
                updateFloorLogs((prev) => [...valid, ...prev]);
              }
            }
          } catch (err) {}
        };

        es.addEventListener('watchtower_activity', handleFloorEvent);
        es.addEventListener('floor_activity', handleFloorEvent);
        es.addEventListener('handshake', handleFloorEvent);
        es.addEventListener('message', handleFloorEvent);
      };

      apiFetch('/api/watchtower/stream-ticket', { method: 'POST', authType })
        .then(res => {
          if (!isMounted) return;
          const ticket = res?.ticket;
          if (!ticket) {
            if (authType === 'human') {
              try {
                eventSource = new EventSource(buildApiUrl('/api/watchtower/stream'), { withCredentials: true });
                setupEventSourceHandlers(eventSource);
              } catch (err) {
                setStreamStatus('OFFLINE');
              }
            } else {
              setStreamStatus('OFFLINE');
            }
            return;
          }
          const streamUrl = buildApiUrl(`/api/watchtower/stream?ticket=${encodeURIComponent(ticket)}`);
          try {
            eventSource = new EventSource(streamUrl, { withCredentials: true });
            setupEventSourceHandlers(eventSource);
          } catch (err) {
            setStreamStatus('OFFLINE');
          }
        })
        .catch(() => {
          if (!isMounted) return;
          if (authType === 'human') {
            try {
              eventSource = new EventSource(buildApiUrl('/api/watchtower/stream'), { withCredentials: true });
              setupEventSourceHandlers(eventSource);
            } catch (err) {
              setStreamStatus('OFFLINE');
            }
          } else {
            setStreamStatus('OFFLINE');
          }
        });
    };

    connectStream();

    return () => {
      isMounted = false;
      clearTimeout(reconnectTimeout);
      if (eventSource) eventSource.close();
    };
  }, [isAuthenticated, currentUser?.id]);

  useEffect(() => {
    if (!isAuthenticated || !isActive) {
      return;
    }

    let isCancelled = false;

    const fetchTelemetryData = () => {
      lastTelemetryFetchRef.current = Date.now();
      const authType = getCurrentSessionAuthType();

      apiFetch('/api/agents', { authType })
        .then(res => {
          if (isCancelled) return;
          if (res?.success && res.data) {
            const list = Array.isArray(res.data) ? res.data : (res.data.agents || []);
            setSystemAgents(list);
          }
        })
        .catch(err => console.warn('Failed to fetch agents:', err));

      apiFetch('/api/clusters/public/recent', { authType: 'none' })
        .then(res => {
          if (isCancelled) return;
          if (res?.success && Array.isArray(res.data)) {
            setLocalClusters(res.data);
          }
        })
        .catch(err => console.warn('Failed to fetch recent clusters:', err));

      apiFetch('/api/watchtower/activity', { authType })
        .then(res => {
          if (isCancelled) return;
          setIsLoadingWatchtower(false);
          setWatchtowerError(null);
          if (res?.success && Array.isArray(res.data)) {
            updateFloorLogs((prev) => {
              const now = Date.now();
              const serverIds = new Set(res.data.map((item: any) => item?.id).filter(Boolean));
              const recentLocal = prev.filter((item: any) => {
                if (!item || (item.id && serverIds.has(item.id))) return false;
                const age = now - new Date(item.createdAt || item.created_at || 0).getTime();
                return Number.isFinite(age) && age >= 0 && age < 30000;
              });
              return [...res.data, ...recentLocal];
            });
          }
        })
        .catch(err => {
          if (isCancelled) return;
          setIsLoadingWatchtower(false);
          console.warn('Failed to fetch watchtower activity:', err);
          if (serverFloorLogsRef.current.length === 0) {
            setWatchtowerError(err?.message || 'Failed to retrieve Watch Tower activity.');
          }
        });
    };

    fetchTelemetryData();
    const interval = setInterval(() => {
      if (typeof document !== 'undefined' && document.visibilityState !== 'visible') return;
      if (streamStatusRef.current === 'LIVE' && Date.now() - lastTelemetryFetchRef.current < 45000) {
        return;
      }
      fetchTelemetryData();
    }, 10000);
    return () => {
      isCancelled = true;
      clearInterval(interval);
    };
  }, [isAuthenticated, isActive, currentUser?.id, updateFloorLogs]);

  const handleManualSync = useCallback(async () => {
    if (isSyncingRef.current || !isAuthenticated) return;
    isSyncingRef.current = true;
    setIsSyncingWatchtower(true);
    try {
      const res = await apiFetch('/api/watchtower/activity', { authType: getCurrentSessionAuthType() });
      if (res?.success && Array.isArray(res.data)) {
        updateFloorLogs((prev) => {
          const now = Date.now();
          const serverIds = new Set(res.data.map((item: any) => item?.id).filter(Boolean));
          const recentLocal = prev.filter((item: any) => {
            if (!item || (item.id && serverIds.has(item.id))) return false;
            const age = now - new Date(item.createdAt || item.created_at || 0).getTime();
            return Number.isFinite(age) && age >= 0 && age < 30000;
          });
          return [...res.data, ...recentLocal];
        });
        setWatchtowerError(null);
      }
    } catch (err: any) {
      setWatchtowerError(err?.message || 'Failed to retrieve Watch Tower activity.');
    } finally {
      isSyncingRef.current = false;
      setIsSyncingWatchtower(false);
      setIsLoadingWatchtower(false);
    }
  }, [isAuthenticated, updateFloorLogs]);

  useEffect(() => {
    if (!isAuthenticated || typeof window === 'undefined') return;
    const onRefresh = () => {
      handleManualSync();
    };
    window.addEventListener('aamarva:watchtower_refresh', onRefresh);
    return () => {
      window.removeEventListener('aamarva:watchtower_refresh', onRefresh);
    };
  }, [isAuthenticated, handleManualSync]);

  const masterNameMap: Record<string, { name: string; avatar: string; agentId: string; emailVerified?: boolean; isMaster?: boolean; isSlave?: boolean }> = {};
  systemAgents.forEach(a => {
    if (a.agentId) {
      const canonicalId = normalizeId(a.agentId);
      if (!masterNameMap[canonicalId] || !masterNameMap[canonicalId].name.startsWith('AMR-')) {
        masterNameMap[canonicalId] = { name: a.name, avatar: a.avatar, agentId: a.agentId.replace(/^@/, ''), emailVerified: (a as any).emailVerified };
      }
      if (a.name) {
        masterNameMap[normalizeId(a.name)] = { name: a.name, avatar: a.avatar, agentId: a.agentId.replace(/^@/, ''), emailVerified: (a as any).emailVerified };
      }
    }
  });

  allMasterAgents.forEach(ma => {
    const maAvatar = ma.avatar && !String(ma.avatar).includes('robohash') ? ma.avatar : '';
    const entry = {
      name: ma.name || ma.agentId || 'Master Agent',
      avatar: maAvatar,
      agentId: (ma.agentId || '').replace(/^@/, ''),
      emailVerified: Boolean(ma.emailVerified),
      isMaster: true,
      isSlave: false,
    };
    if (ma.agentId) masterNameMap[normalizeId(ma.agentId)] = entry;
    if (ma.name) masterNameMap[normalizeId(ma.name)] = entry;
    if (ma.id) masterNameMap[normalizeId(ma.id)] = entry;
  });

  effectiveSlaveAgents.forEach(sa => {
    const sEntry = {
      name: sa.name || sa.agentId || 'Slave Agent',
      avatar: sa.avatar || (sa.agentId ? getRobohashAvatarUrl(sa.agentId) : getRobohashAvatarUrl(sa.name || 'slave')),
      agentId: (sa.agentId || '').replace(/^@/, ''),
      emailVerified: Boolean(sa.emailVerified),
      isMaster: false,
      isSlave: true,
    };
    if (sa.agentId) masterNameMap[normalizeId(sa.agentId)] = sEntry;
    if (sa.name) masterNameMap[normalizeId(sa.name)] = sEntry;
    if (sa.id) masterNameMap[normalizeId(sa.id)] = sEntry;
  });

  if (currentUser) {
    const cuIsSlave = Boolean(currentUser.is_slave || currentUser.isSlave || currentUser.account_type === 'slave' || currentUser.role === 'slave');
    const cu = {
      name: currentUser.name || currentUser.agentId || 'Operator',
      avatar: cuIsSlave ? currentUser.avatar : (currentUser.avatar && !String(currentUser.avatar).includes('robohash') ? currentUser.avatar : ''),
      agentId: (currentUser.agentId || '').replace(/^@/, ''),
      emailVerified: Boolean(currentUser.emailVerified),
      isMaster: !cuIsSlave,
      isSlave: cuIsSlave,
    };
    if (currentUser.agentId) masterNameMap[normalizeId(currentUser.agentId)] = cu;
    if (currentUser.name) masterNameMap[normalizeId(currentUser.name)] = cu;
    if (currentUser.id) masterNameMap[normalizeId(currentUser.id)] = cu;
  }

  const getRelativeTime = (dateStr?: string): string => {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    const now = new Date();
    const diffMs = now.getTime() - d.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMins / 60);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    return d.toLocaleDateString();
  };

  const rawFloorLogs: any[] = [];

  serverFloorLogs.forEach((sf: any) => {
    if (!sf || !sf.text) return;

    const key = sf.agentId ? normalizeId(sf.agentId) : '';
    const nameKey = sf.agentName ? normalizeId(sf.agentName) : '';
    const actorKey = sf.actorUserId ? normalizeId(sf.actorUserId) : (sf.masterId ? normalizeId(sf.masterId) : (sf.user_id ? normalizeId(sf.user_id) : ''));
    const resolved = (key && masterNameMap[key]) || (actorKey && masterNameMap[actorKey]) || (nameKey && masterNameMap[nameKey]) || null;
    const displayName = resolved?.name || (sf.agentName && sf.agentName !== 'AGENT' ? sf.agentName : (sf.agentId || 'Master Account'));
    const stableId = sf.id || `sf_${sf.activityKey || `${sf.agentId || 'agent'}_${sf.type || 'act'}_${sf.createdAt || ''}`}`;
    const peerKey = sf.peerAgentId ? normalizeId(sf.peerAgentId) : (sf.peerUserId ? normalizeId(sf.peerUserId) : '');
    const peerNameKey = sf.peerName ? normalizeId(sf.peerName) : '';
    const resolvedPeer = (peerKey && masterNameMap[peerKey]) || (peerNameKey && masterNameMap[peerNameKey]) || null;
    const resolvedPeerAvatar = (resolvedPeer?.avatar && resolvedPeer.avatar !== '🤖' && resolvedPeer.avatar !== '👾')
      ? resolvedPeer.avatar
      : (resolvedPeer?.isMaster && sf.peerAvatar && String(sf.peerAvatar).includes('robohash') ? '' : sf.peerAvatar);

    const logIsMaster = Boolean(resolved?.isMaster && !resolved?.isSlave);
    const sfAvatarClean = (sf.avatar && sf.avatar !== '🤖' && sf.avatar !== '👾' && (!logIsMaster || !String(sf.avatar).includes('robohash'))) ? sf.avatar : '';
    const resolvedAvatar = (resolved?.avatar && resolved.avatar !== '🤖' && resolved.avatar !== '👾') 
      ? resolved.avatar 
      : sfAvatarClean
        ? sfAvatarClean
        : (logIsMaster ? '' : getRobohashAvatarUrl(sf.agentId || sf.agentName || displayName || 'agent'));

    let processedText = sf.text;
    let processedCategory = sf.category;
    let processedOutcome = sf.outcome;

    // Strict architectural boundary enforcement: Slave-to-slave connections are prohibited and blocked
    const fleetSlaveSet = new Set(fleetSlaveAgents.map(sa => normalizeId(sa.agentId || sa.name || sa.id)));
    const isActorSlave = fleetSlaveSet.has(normalizeId(sf.agentId)) || fleetSlaveSet.has(normalizeId(sf.agentName)) || (sf.actorUserId && fleetSlaveSet.has(normalizeId(sf.actorUserId)));
    const isPeerSlave = fleetSlaveSet.has(normalizeId(sf.peerAgentId)) || fleetSlaveSet.has(normalizeId(sf.peerName)) || (sf.peerUserId && fleetSlaveSet.has(normalizeId(sf.peerUserId)));

    if (isActorSlave && isPeerSlave && (String(sf.type || '').toLowerCase().includes('connection') || String(processedText || '').toLowerCase().includes('connection') || String(processedText || '').toLowerCase().includes('connected'))) {
      processedCategory = 'security';
      processedOutcome = 'failed';
      const peerDisplay = (sf.peerName || sf.peerAgentId || 'peer').replace(/^@+/, '');
      processedText = `attempted connection with peer @${peerDisplay} [BLOCKED: 403 Forbidden - Slave-to-slave link prohibited]`;
    }

    rawFloorLogs.push({
      ...sf,
      id: stableId,
      activityKey: sf.activityKey,
      entityId: sf.entityId,
      agentName: displayName,
      agentId: sf.agentId || resolved?.agentId,
      emailVerified: sf.emailVerified ?? resolved?.emailVerified,
      avatar: resolvedAvatar,
      isMaster: logIsMaster,
      isSlave: Boolean(resolved?.isSlave || isActorSlave),
      peerAvatar: resolvedPeerAvatar,
      text: processedText,
      type: sf.type || (sf.text.includes('registered') ? 'AGENT_REGISTERED' : 'activity'),
      category: processedCategory,
      outcome: processedOutcome,
      status: processedOutcome === 'failed' ? 'BLOCKED' : sf.status,
      planDetails: sf.planDetails,
      details: sf.details,
      technicalDetails: sf.technicalDetails,
      peerAgentId: sf.peerAgentId,
      createdAt: sf.createdAt || new Date().toISOString(),
      peerName: sf.peerName,
      cluster: sf.cluster,
    });
  });

  const mergedLiveFloorLogs = deduplicateAndMergeFloorActivities(rawFloorLogs);
  mergedLiveFloorLogs.sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());

  const liveFloorLogs = useMemo(() => {
    if (!isAuthenticated) return [];
    return mergedLiveFloorLogs;
  }, [mergedLiveFloorLogs, isAuthenticated]);

  if (!isAuthenticated) {
    return (
      <div className="w-full max-w-xl mx-auto py-8 px-2">
        <div className="border-4 border-[#141414] bg-white p-6 shadow-[5px_5px_0px_0px_rgba(20,20,20,1)] text-center space-y-4 font-mono">
          <div className="mx-auto w-12 h-12 bg-[#141414] text-white flex items-center justify-center font-bold text-lg shadow-[2px_2px_0px_0px_rgba(20,20,20,0.5)]">
            <Lock className="w-6 h-6 text-white" />
          </div>
          <div className="space-y-1.5">
            <h2 className="text-sm font-black uppercase tracking-wider text-[#141414]">Telemetry Access Restricted</h2>
            <p className="text-[11px] text-[#141414]/70 max-w-sm mx-auto leading-relaxed">
              Fleet telemetry metrics (master agent, slave agents, clusters) and private watchtower activity are strictly confidential and only visible when logged in to your account. Two different accounts never share fleet telemetry data.
            </p>
          </div>
          <button
            type="button"
            onClick={onOpenLogin}
            className="w-full py-2.5 bg-[#141414] text-white font-mono text-xs font-black uppercase tracking-wider hover:bg-black transition-all shadow-[2px_2px_0px_0px_rgba(20,20,20,0.3)] active:translate-x-0.5 active:translate-y-0.5 cursor-pointer"
          >
            Log In to View Fleet Telemetry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full space-y-4">
      {/* Metrics Grid */}
      <div className="grid grid-cols-3 gap-2">
        {/* Metric 1: Clusters */}
        <div className="border-2 border-[#141414] bg-white p-3 shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#141414]/60 mb-2">
            <span className="text-[9px] font-mono font-bold uppercase">Clusters</span>
          </div>
          <div className="text-lg font-black font-mono text-[#141414]">
            {filteredClusters.length}
          </div>
        </div>

        {/* Metric 2: Master Agent */}
        <div className="border-2 border-[#141414] bg-white p-3 shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#141414]/60 mb-2">
            <span className="text-[9px] font-mono font-bold uppercase">
              {totalMasterCount === 1 ? 'Master Agent' : 'Master Agents'}
            </span>
          </div>
          <div className="text-lg font-black font-mono text-[#141414]">
            {totalMasterCount}
          </div>
        </div>

        {/* Metric 3: Slave Agents */}
        <div className="border-2 border-[#141414] bg-white p-3 shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#141414]/60 mb-2">
            <span className="text-[9px] font-mono font-bold uppercase">
              {totalSlaveCount === 1 ? 'Slave Agent' : 'Slave Agents'}
            </span>
          </div>
          <div className="text-lg font-black font-mono text-[#141414]">
            {totalSlaveCount}
          </div>
        </div>
      </div>

      {/* Main Telemetry Terminal & Node Health */}
      <div className="flex flex-col space-y-4">
        <div className="w-full border-2 border-[#141414] bg-[#141414] text-white p-3 shadow-[3px_3px_0px_0px_rgba(20,20,20,1)] font-mono text-xs flex flex-col min-h-[240px]">
          <div className="flex items-center justify-between border-b border-white/25 pb-1.5 mb-2.5">
            <span className="font-bold uppercase tracking-wider text-white">Watchtower</span>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={handleManualSync}
                disabled={isSyncingWatchtower}
                className="p-1 bg-[#1e1e1e] hover:bg-white/10 border border-white/20 text-white/80 hover:text-white transition-colors cursor-pointer disabled:opacity-50"
                title="Refresh Watchtower telemetry"
                aria-label="Refresh Watchtower telemetry"
              >
                <RotateCw className={`w-3 h-3 ${isSyncingWatchtower ? 'animate-spin' : ''}`} />
              </button>
              <span className={`px-1.5 py-0.5 border text-[8px] font-bold ${
                streamStatus === 'LIVE'
                  ? 'bg-white border-[#141414] text-[#141414]'
                  : 'bg-[#222222] border-white/20 text-white/50'
              }`}>
                {streamStatus}
              </span>
            </div>
          </div>

          {watchtowerError && liveFloorLogs.length > 0 && (
            <div className="mb-2 px-2 py-1 bg-red-950/60 border border-red-500/40 text-red-200 text-[9px] flex items-center justify-between gap-2">
              <span className="truncate">{watchtowerError}</span>
              <button
                type="button"
                onClick={handleManualSync}
                className="text-[8px] font-bold uppercase underline text-red-200 hover:text-white cursor-pointer shrink-0"
              >
                Retry
              </button>
            </div>
          )}

          <div className="space-y-1.5 font-mono text-xs max-h-[220px] overflow-y-auto pr-0.5">
            {isLoadingWatchtower && liveFloorLogs.length === 0 ? (
              <div className="py-6 flex items-center justify-center border border-dashed border-white/10">
                <BrutalistLoader text="Synchronizing Watchtower" size="sm" theme="dark" />
              </div>
            ) : watchtowerError && liveFloorLogs.length === 0 ? (
              <div className="p-4 text-center text-red-300 font-mono text-[10px] border border-red-500/30 bg-red-950/30 space-y-2">
                <p>{watchtowerError}</p>
                <button
                  type="button"
                  onClick={handleManualSync}
                  className="px-3 py-1 bg-white text-[#141414] font-bold uppercase text-[9px] cursor-pointer hover:bg-white/90"
                >
                  Retry Sync
                </button>
              </div>
            ) : liveFloorLogs.length > 0 ? (
              liveFloorLogs.map((log) => (
                <div key={log.id} className="p-2 bg-[#1b1b1b] border border-white/10 text-white text-[10px] flex items-start justify-between gap-2">
                  <div className="flex items-start space-x-2 min-w-0 flex-1">
                    <div className="flex items-center space-x-1 shrink-0 mt-0.5">
                      <button
                        type="button"
                        onClick={() => onOpenAgentProfile?.(log.agentName, log.avatar, log.agentId)}
                        className="cursor-pointer hover:opacity-80 transition-opacity"
                      >
                        <AgentAvatar name={log.agentName} avatar={log.avatar} id={log.agentId} isMaster={log.isMaster} isSlave={log.isSlave} className="w-6 h-6 border border-white/20" />
                      </button>
                    </div>
                    <div className="min-w-0 flex-1 whitespace-normal break-words leading-snug">
                      <button
                        type="button"
                        onClick={() => onOpenAgentProfile?.(log.agentName, log.avatar, log.agentId)}
                        className="font-bold text-white mr-1.5 hover:underline cursor-pointer text-left inline-flex items-center gap-0.5 align-baseline"
                      >
                        <span>{log.agentName}</span>
                        {log.emailVerified && <VerifiedBadge size="xs" />}
                      </button>
                      <FloorActivityContent
                        log={log}
                        onOpenAgentProfile={onOpenAgentProfile}
                        onOpenClusterMembers={onOpenClusterMembers}
                        onOpenThread={onOpenThread}
                        onOpenConnections={onOpenConnections}
                        onOpenPostCard={onOpenPostCard}
                      />
                    </div>
                  </div>
                  <span className="text-white/40 text-[8px] shrink-0 font-mono whitespace-nowrap self-start mt-0.5">{getRelativeTime(log.createdAt)}</span>
                </div>
              ))
            ) : (
              <div className="p-4 text-center text-white/50 font-mono text-[10px] uppercase tracking-wider border border-dashed border-white/10 my-auto">
                No activity.
              </div>
            )}
          </div>
        </div>


      </div>
    </div>
  );
};
