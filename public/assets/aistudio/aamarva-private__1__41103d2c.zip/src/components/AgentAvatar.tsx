import React, { useMemo, useState, useEffect } from 'react';
import { getPreparedAccountProfile, getQueryCache } from '../lib/appStateCache';
import { getRobohashAvatarUrl, normalizeAvatarUrl } from '../lib/robohash';

export interface AgentAvatarProps {
  avatar?: string;
  name?: string;
  id?: string;
  className?: string;
  size?: string;
  isMaster?: boolean;
  isSlave?: boolean;
  accountType?: 'master' | 'slave';
}

const isPlaceholderAvatar = (val?: string | null): boolean => {
  if (!val || typeof val !== 'string') return true;
  const trimmed = val.trim();
  return !trimmed || trimmed === '🤖' || trimmed === '👾';
};

const isRobohashUrl = (val?: string | null): boolean => {
  if (!val || typeof val !== 'string') return false;
  return val.includes('robohash.org') || val.includes('robohash-i7n8.onrender.com');
};

/**
 * Robust AgentAvatar component:
 * 1. Renders provided avatar URL/path (normalized).
 * 2. Preserves robohash robot avatars for Slave / general agents.
 * 3. Protects Master accounts from ever displaying or flashing robohash avatars.
 * 4. Gracefully falls back to crisp operator/agent initials badge if image fails or is unavailable.
 */
export const AgentAvatar: React.FC<AgentAvatarProps> = React.memo(({
  avatar,
  name,
  id,
  className = 'w-10 h-10',
  isMaster,
  isSlave,
  accountType,
}) => {
  const [imgError, setImgError] = useState(false);

  useEffect(() => {
    setImgError(false);
  }, [avatar, id, name]);

  const currentSrc = useMemo(() => {
    if (imgError) return '';

    const cleanId = (id || '').replace(/^@+/, '').trim();
    const cleanName = (name || '').replace(/^@+/, '').trim();
    const normId = cleanId.toLowerCase();
    const normName = cleanName.toLowerCase();

    const prepared =
      getPreparedAccountProfile(cleanId) ||
      getPreparedAccountProfile(cleanName) ||
      (cleanId ? getPreparedAccountProfile(`@${cleanId}`) : null);

    const cachedAccounts = getQueryCache('master_accounts', '/api/auth/master/accounts')?.data;
    const masterAgentsList = [
      ...(cachedAccounts?.masterAgent ? [cachedAccounts.masterAgent] : []),
      ...(Array.isArray(cachedAccounts?.masterSlotAgents) ? cachedAccounts.masterSlotAgents : []),
    ];
    const slaveAgentsList = Array.isArray(cachedAccounts?.slaveAgents)
      ? cachedAccounts.slaveAgents
      : Array.isArray(cachedAccounts?.subAgents)
        ? cachedAccounts.subAgents
        : [];

    const matchesAccount = (acc: any): boolean => {
      if (!acc) return false;
      const aId = (acc.agentId || acc.id || '').toString().replace(/^@+/, '').toLowerCase().trim();
      const aName = (acc.name || '').toString().toLowerCase().trim();
      return Boolean(
        (normId && (aId === normId || aName === normId)) ||
        (normName && (aId === normName || aName === normName))
      );
    };

    const matchedMaster = masterAgentsList.find(matchesAccount);
    const matchedSlave = slaveAgentsList.find(matchesAccount);

    const pData = prepared?.data;
    const preparedIsSlave = Boolean(
      pData &&
      (pData.isSlave === true ||
        pData.is_slave === true ||
        pData.account_type === 'slave' ||
        pData.role === 'slave')
    );
    const preparedIsMaster = Boolean(
      pData &&
      !preparedIsSlave &&
      (pData.isMasterPrimary === true ||
        pData.is_master_primary === true ||
        pData.isMasterSlot === true ||
        pData.is_master_slot === true ||
        pData.account_type === 'master' ||
        pData.account_type === 'master_slot' ||
        pData.isMasterUser === true)
    );

    const resolvedIsSlave = Boolean(
      isSlave === true ||
      accountType === 'slave' ||
      (isMaster !== true && accountType !== 'master' && (preparedIsSlave || matchedSlave))
    );

    const resolvedIsMaster = Boolean(
      !resolvedIsSlave &&
      (isMaster === true || accountType === 'master' || preparedIsMaster || matchedMaster)
    );

    let effectiveAvatar = avatar;

    if (resolvedIsMaster) {
      // Master account: never allow robohash; resolve custom/SVG avatar from prepared/master cache if needed
      if (isPlaceholderAvatar(effectiveAvatar) || isRobohashUrl(effectiveAvatar)) {
        if (pData?.avatar && !isPlaceholderAvatar(pData.avatar) && !isRobohashUrl(pData.avatar)) {
          effectiveAvatar = pData.avatar;
        } else if (matchedMaster?.avatar && !isPlaceholderAvatar(matchedMaster.avatar) && !isRobohashUrl(matchedMaster.avatar)) {
          effectiveAvatar = matchedMaster.avatar;
        } else {
          effectiveAvatar = '';
        }
      }
    } else {
      // Slave or general agent: allow robohash robot avatars and resolve from cache or deterministic seed
      if (isPlaceholderAvatar(effectiveAvatar)) {
        if (pData?.avatar && !isPlaceholderAvatar(pData.avatar)) {
          effectiveAvatar = pData.avatar;
        } else if (matchedSlave?.avatar && !isPlaceholderAvatar(matchedSlave.avatar)) {
          effectiveAvatar = matchedSlave.avatar;
        } else if (resolvedIsSlave && (cleanId || cleanName)) {
          effectiveAvatar = getRobohashAvatarUrl(cleanId || cleanName);
        }
      }

      if (effectiveAvatar && isRobohashUrl(effectiveAvatar)) {
        effectiveAvatar = normalizeAvatarUrl(effectiveAvatar, cleanId || cleanName || 'agent');
      }
    }

    if (effectiveAvatar && typeof effectiveAvatar === 'string' && effectiveAvatar.trim().length > 0) {
      const trimmed = effectiveAvatar.trim();
      if (
        (trimmed.startsWith('http://') ||
          trimmed.startsWith('https://') ||
          trimmed.startsWith('/') ||
          trimmed.startsWith('data:')) &&
        (!resolvedIsMaster || !isRobohashUrl(trimmed))
      ) {
        return trimmed;
      }
    }
    return '';
  }, [avatar, id, name, imgError, isMaster, isSlave, accountType]);

  const initials = useMemo(() => {
    const raw = (name || id || 'Agent').replace(/^@+/, '').trim();
    if (!raw) return 'AG';
    const parts = raw.split(/\s+/);
    if (parts.length >= 2) {
      return `${parts[0][0] || ''}${parts[1][0] || ''}`.toUpperCase();
    }
    return raw.slice(0, 2).toUpperCase();
  }, [name, id]);

  return (
    <div
      className={`relative bg-[#141414] border border-[#141414] text-white flex items-center justify-center font-mono overflow-hidden shrink-0 shadow-[1px_1px_0px_0px_rgba(20,20,20,0.3)] select-none ${className}`}
    >
      {currentSrc ? (
        <img
          src={currentSrc}
          alt={name || id || 'avatar'}
          loading="lazy"
          decoding="async"
          onError={() => {
            if (!imgError) {
              setImgError(true);
            }
          }}
          className="w-full h-full object-cover bg-transparent relative z-10 block"
        />
      ) : (
        <span className="text-[10px] sm:text-xs font-black text-white uppercase tracking-wider">
          {initials}
        </span>
      )}
    </div>
  );
});

AgentAvatar.displayName = 'AgentAvatar';

