import React, { useState, useEffect, useRef, useCallback } from 'react';
import { ArrowLeft, User, PanelLeftClose, PanelLeftOpen, ChevronUp, Lock, Paperclip, Download, FileText, Mic, AlertTriangle, Clock, Check, CheckCheck, ArrowDown } from 'lucide-react';
import { apiFetch, getAccessToken, getCurrentSessionAuthType, sendPrivateMessageApi, isSlaveAccount, uploadEncryptedAttachmentApi, getEncryptedAttachmentApi, resolveOrRecoverSenderLocalKeys, syncOwnLocalKeysWithServer } from '../services/authApi';
import { AgentAvatar } from './AgentAvatar';
import { BrutalistLoader } from './BrutalistLoader';
import { useAuth } from '../context/AuthContext';
import { VoiceMessagePlayer } from './VoiceMessagePlayer';
import { VoiceRecorderBar } from './VoiceRecorderBar';
import { useVoiceRecorder } from '../hooks/useVoiceRecorder';
import { 
  decryptMessage, 
  getLocalKeyPair, 
  getAllLocalEpochKeys,
  getPinnedPeerKey,
  resolveSenderPublicKey, 
  normalizeAgentId, 
  formatDecryptionErrorStatus, 
  FormattedDecryptionStatus, 
  StoredAgentKeyEntry,
  encryptAttachmentFile,
  decryptAttachmentFile
} from '../lib/e2ee';
import { 
  getCachedPeerKey, 
  setCachedPeerKey,
  fetchConnectionPeerKey,
  isPeerKeyStale
} from '../lib/e2eePrefetch';
import {
  getCachedDecryptedMessage,
  cacheDecryptedMessage,
  isDecryptionErrorPlaceholder,
  getCachedConnectionMessages,
  getCachedConnectionMessagesByAliases,
  makePeerAliasKey,
  setCachedConnectionMessages
} from '../lib/decryptedMessageStore';
import { getQueryCache, getAccountKey, clearUnreadCount } from '../lib/appStateCache';
import { subscribeRealtimeStream, isRealtimeStreamConnected } from '../lib/realtimeStream';
import { ingestRealtimeConnectionMessage } from '../lib/chatMessageWarmup';
import { ChatChannelNavigator } from './ChatChannelNavigator';


interface ChatModalProps {
  connectionId: string;
  allConnectionIds?: string[];
  peerName: string;
  peerAvatar?: string;
  peerAgentId?: string;
  peerE2eePublicKey?: string | null;
  peerIsMaster?: boolean;
  peerIsSlave?: boolean;
  deviceSize?: 'mobile' | 'tablet' | 'desktop';
  onSelectChat?: (chat: any) => void;
  onSelectClusterChat?: (cluster: { id: string; name: string; symbol?: string }) => void;
  onClose: () => void;
  onOpenAgentProfile?: (agentName: string, avatar?: string, agentId?: string) => void;
}

function uint8ToBase64(bytes: Uint8Array): string {
  const CHUNK_SIZE = 0x8000;
  const parts: string[] = [];
  for (let i = 0; i < bytes.byteLength; i += CHUNK_SIZE) {
    parts.push(String.fromCharCode(...bytes.subarray(i, i + CHUNK_SIZE)));
  }
  return btoa(parts.join(''));
}

function computeIncrementalSince(existing: DecryptedChatMessage[]): string | undefined {
  if (!Array.isArray(existing) || existing.length === 0) return undefined;
  let maxTs = 0;
  for (const m of existing) {
    if (!m || typeof m.id !== 'string' || m.id.startsWith('temp_')) continue;
    if (m.createdAt) {
      const ts = new Date(m.createdAt).getTime();
      if (Number.isFinite(ts) && ts > maxTs) maxTs = ts;
    }
  }
  if (maxTs <= 0) return undefined;
  return new Date(Math.max(0, maxTs - 1000)).toISOString();
}

interface DecryptedChatMessage {
  id: string;
  connectionId: string;
  senderAgentId: string;
  content: string;
  decryptionStatus?: FormattedDecryptionStatus;
  isDecrypted: boolean;
  createdAt: string;
  keyEpoch?: number;
  sequence?: number;
  deliveryStatus?: 'sending' | 'sent' | 'delivered' | 'failed';
  retryPayload?: {
    text: string;
    fileToEncrypt?: File | null;
  };
}

function formatFileSize(bytes: number): string {
  if (!bytes || bytes <= 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

function formatChatMessageTimestamp(rawDate?: string | Date): string {
  if (!rawDate) return '';
  const d = new Date(rawDate);
  if (isNaN(d.getTime())) return '';

  const timeStr = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
  
  const now = new Date();
  const isToday = d.getDate() === now.getDate() &&
    d.getMonth() === now.getMonth() &&
    d.getFullYear() === now.getFullYear();

  const yesterday = new Date();
  yesterday.setDate(now.getDate() - 1);
  const isYesterday = d.getDate() === yesterday.getDate() &&
    d.getMonth() === yesterday.getMonth() &&
    d.getFullYear() === yesterday.getFullYear();

  if (isToday) {
    return `${timeStr} / today`;
  }
  if (isYesterday) {
    return `${timeStr} / yesterday`;
  }

  const dayName = d.toLocaleDateString('en-US', { weekday: 'short' });
  const dayNum = d.getDate();
  const monthName = d.toLocaleDateString('en-US', { month: 'short' });
  const year2Digits = String(d.getFullYear()).slice(-2);

  return `${timeStr} / ${dayName.toLowerCase()}, ${dayNum} ${monthName.toLowerCase()} ${year2Digits}`;
}

interface ChatMessageContentProps {
  content: string;
  isCurrentUser: boolean;
  connectionId?: string;
  senderAgentId?: string;
  keyEpoch?: number;
  localPrivateKey?: CryptoKey | string | null;
  senderPublicKey?: string | null;
  effectiveAuthType?: 'human' | 'agent';
}

const ChatMessageContent = React.memo<ChatMessageContentProps>(({
  content,
  isCurrentUser,
  connectionId,
  senderAgentId,
  keyEpoch = 1,
  localPrivateKey,
  senderPublicKey,
  effectiveAuthType = 'human'
}) => {
  const { user, userPassword } = useAuth();
  const [isExpanded, setIsExpanded] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadError, setDownloadError] = useState<string | null>(null);

  // Check if decrypted message contains an encrypted attachment envelope reference
  let attachmentMeta: any = null;
  if (content && typeof content === 'string' && content.startsWith('{') && content.includes('"aamarva_attachment":true')) {
    try {
      const parsed = JSON.parse(content);
      if (parsed.aamarva_attachment && (parsed.attachmentId || parsed.fileBase64 || parsed.audioBase64 || parsed.filename)) {
        attachmentMeta = parsed;
      }
    } catch {}
  }

  const handleDecryptAndDownload = async () => {
    if (!attachmentMeta) return;
    setIsDownloading(true);
    setDownloadError(null);

    try {
      // 1. Fast-path: Instant in-memory decode if fileBase64 is directly embedded in decrypted message payload
      if (attachmentMeta.fileBase64) {
        const sanitized = attachmentMeta.fileBase64.replace(/\s/g, '').replace(/-/g, '+').replace(/_/g, '/');
        const binaryString = atob(sanitized);
        const len = binaryString.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
          bytes[i] = binaryString.charCodeAt(i);
        }
        const blob = new Blob([bytes], { type: attachmentMeta.mimeType || 'application/octet-stream' });
        const objectUrl = URL.createObjectURL(blob);
        const downloadAnchor = document.createElement('a');
        downloadAnchor.href = objectUrl;
        downloadAnchor.download = attachmentMeta.filename || 'downloaded_file';
        document.body.appendChild(downloadAnchor);
        downloadAnchor.click();
        document.body.removeChild(downloadAnchor);
        setTimeout(() => URL.revokeObjectURL(objectUrl), 3000);
        return;
      }

      // 2. Fallback: Download server-blind encrypted attachment blob
      if (!attachmentMeta.attachmentId || !connectionId) {
        throw new Error('Attachment data unavailable.');
      }

      const authTypeArg: 'human' | 'agent' = effectiveAuthType === 'agent' ? 'agent' : 'human';
      const res = await getEncryptedAttachmentApi(connectionId, attachmentMeta.attachmentId, authTypeArg);
      if (!res?.success || !res?.data) {
        throw new Error(res?.error?.message || 'Failed to retrieve encrypted attachment from server.');
      }

      const encryptedRecord = res.data;

      // Resolve required keys for local client-side decryption (including multi-epoch fallback)
      const localKeyCandidates: (CryptoKey | string)[] = [];
      const addLocalCandidate = (k?: CryptoKey | string | null) => {
        if (k && !localKeyCandidates.includes(k)) localKeyCandidates.push(k);
      };
      addLocalCandidate(localPrivateKey);
      if (user?.agentId) {
        try {
          const epKp = await getLocalKeyPair(user.agentId, keyEpoch, userPassword || undefined);
          addLocalCandidate(epKp?.privateKey);
          const allLocal = await getAllLocalEpochKeys(user.agentId);
          for (const entry of allLocal) {
            addLocalCandidate(entry.privateKey);
          }
        } catch {}
      }
      if (localKeyCandidates.length === 0) {
        throw new Error('Local private key unavailable for attachment decryption.');
      }

      const peerKeyCandidates: string[] = [];
      const addPeerCandidate = (pk?: any) => {
        if (!pk) return;
        const s = typeof pk === 'string' ? pk : JSON.stringify(pk);
        if (s && !peerKeyCandidates.includes(s)) peerKeyCandidates.push(s);
      };
      addPeerCandidate(senderPublicKey);

      const loadPeerKeys = async (forceRefresh: boolean) => {
        if (!connectionId) return;
        try {
          const peerInfo = await fetchConnectionPeerKey(connectionId, {
            receiverAgentId: senderAgentId,
            authType: authTypeArg,
            forceRefresh,
            bypassCooldown: forceRefresh,
          });
          addPeerCandidate(peerInfo?.peerPublicKey);
          if (peerInfo?.peerEpochKeys && typeof peerInfo.peerEpochKeys === 'object') {
            if (keyEpoch && peerInfo.peerEpochKeys[String(keyEpoch)]?.publicKey) {
              addPeerCandidate(peerInfo.peerEpochKeys[String(keyEpoch)].publicKey);
            }
            for (const epData of Object.values(peerInfo.peerEpochKeys)) {
              addPeerCandidate((epData as any)?.publicKey);
            }
          }
        } catch {}
      };

      if (peerKeyCandidates.length === 0) {
        await loadPeerKeys(false);
      }
      if (peerKeyCandidates.length === 0) {
        throw new Error('Peer public key unavailable for attachment decryption.');
      }

      let decrypted: Awaited<ReturnType<typeof decryptAttachmentFile>> | null = null;
      let lastAttErr: any = null;
      const attemptAttachmentDecrypt = async () => {
        for (const privCand of localKeyCandidates) {
          for (const pubCand of peerKeyCandidates) {
            try {
              decrypted = await decryptAttachmentFile(
                encryptedRecord,
                privCand,
                pubCand,
                connectionId,
                senderAgentId || 'peer'
              );
              return;
            } catch (err) {
              lastAttErr = err;
            }
          }
        }
      };

      await attemptAttachmentDecrypt();
      if (!decrypted) {
        await loadPeerKeys(true);
        if (user?.agentId) {
          try {
            const ownSync = await syncOwnLocalKeysWithServer(
              user.agentId,
              userPassword || undefined,
              authTypeArg,
              { force: true }
            );
            if (ownSync.restoredNewEpochs) {
              if (ownSync.localKeys?.privateKey && !localKeyCandidates.includes(ownSync.localKeys.privateKey)) {
                localKeyCandidates.unshift(ownSync.localKeys.privateKey);
              }
              const refreshedAll = await getAllLocalEpochKeys(user.agentId).catch(() => []);
              for (const ep of refreshedAll) {
                if (ep?.privateKey && !localKeyCandidates.includes(ep.privateKey)) {
                  localKeyCandidates.push(ep.privateKey);
                }
              }
            } else if (ownSync.status === 'recovery_required') {
              throw new Error('Missing matching device key for this attachment epoch.');
            }
          } catch (syncErr: any) {
            if (syncErr?.message?.includes('missing matching device key') || syncErr?.message?.includes('Missing matching device key')) {
              throw syncErr;
            }
          }
        }
        await attemptAttachmentDecrypt();
      }
      if (!decrypted) {
        throw lastAttErr || new Error('Failed to decrypt attachment.');
      }

      // Trigger safe in-memory file download and revoke object URL
      const objectUrl = URL.createObjectURL(decrypted.blob);
      const downloadAnchor = document.createElement('a');
      downloadAnchor.href = objectUrl;
      downloadAnchor.download = decrypted.filename || attachmentMeta.filename || 'downloaded_file';
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      document.body.removeChild(downloadAnchor);
      setTimeout(() => URL.revokeObjectURL(objectUrl), 3000);
    } catch (err: any) {
      console.error('Failed to decrypt attachment:', err);
      setDownloadError(err?.message || 'Decryption failed.');
    } finally {
      setIsDownloading(false);
    }
  };

  if (attachmentMeta) {
    const isVoice = Boolean(
      attachmentMeta.isVoiceMessage ||
      attachmentMeta.mimeType?.startsWith('audio/') ||
      attachmentMeta.filename?.endsWith('.webm') ||
      attachmentMeta.filename?.endsWith('.mp4') ||
      attachmentMeta.filename?.endsWith('.ogg')
    );

    if (isVoice) {
      return (
        <VoiceMessagePlayer
          payload={attachmentMeta}
          isCurrentUser={Boolean(isCurrentUser)}
          connectionId={connectionId}
          senderAgentId={senderAgentId}
          keyEpoch={keyEpoch}
          localPrivateKey={localPrivateKey}
          senderPublicKey={senderPublicKey}
          effectiveAuthType={effectiveAuthType}
        />
      );
    }

    const isImage = Boolean(
      (attachmentMeta.mimeType?.startsWith('image/') ||
       attachmentMeta.filename?.match(/\.(png|jpe?g|gif|webp|svg)$/i)) &&
      attachmentMeta.fileBase64
    );

    return (
      <div className="space-y-1.5 font-mono">
        {attachmentMeta.text && (
          <div className="text-xs sm:text-sm whitespace-pre-wrap break-words leading-relaxed mb-1">
            {attachmentMeta.text}
          </div>
        )}

        {isImage && (
          <div
            onClick={handleDecryptAndDownload}
            className={`max-h-52 overflow-hidden border p-1 cursor-pointer transition-opacity hover:opacity-90 flex items-center justify-center ${
              isCurrentUser
                ? 'border-white/30 bg-black/30'
                : 'border-[#141414]/30 bg-[#141414]/5'
            }`}
            title="Click to download image"
          >
            <img
              src={`data:${attachmentMeta.mimeType || 'image/png'};base64,${attachmentMeta.fileBase64}`}
              alt={attachmentMeta.filename || 'attachment'}
              className="max-h-48 max-w-full object-contain"
            />
          </div>
        )}

        <div
          className={`flex items-center justify-between gap-3 p-2 border ${
            isCurrentUser
              ? 'border-white/30 bg-white/5 text-white'
              : 'border-[#141414]/25 bg-black/5 text-[#141414]'
          }`}
        >
          <div className="flex items-center gap-2 min-w-0 flex-1">
            <FileText className="w-4 h-4 shrink-0 opacity-75" />
            <div className="truncate min-w-0">
              <span className="font-bold text-xs truncate block leading-tight">
                {attachmentMeta.filename || 'attachment'}
              </span>
              <span className="text-[9.5px] opacity-65 font-mono">
                {formatFileSize(attachmentMeta.size)}
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={handleDecryptAndDownload}
            disabled={isDownloading}
            className={`p-1.5 border transition-all cursor-pointer flex items-center justify-center shrink-0 active:scale-95 shadow-[1px_1px_0px_0px_rgba(20,20,20,1)] ${
              isCurrentUser
                ? 'border-white bg-white text-[#141414] hover:bg-neutral-200'
                : 'border-[#141414] bg-[#141414] text-white hover:bg-neutral-800'
            }`}
            title="Download file"
          >
            {isDownloading ? (
              <span className="inline-block w-3.5 h-3.5 border-2 border-current border-t-transparent animate-spin rounded-full" />
            ) : (
              <Download className="w-3.5 h-3.5" />
            )}
          </button>
        </div>

        {downloadError && (
          <div className="text-[9.5px] font-mono text-red-500 opacity-90 flex items-center gap-1 mt-0.5">
            <span>⚠️ {downloadError}</span>
          </div>
        )}
      </div>
    );
  }

  const isLong = content.length > 300 || content.split('\n').length > 6;
  const isDecryptionNotice = content.includes('Cannot be decrypted') || content.startsWith('🔒') || content.startsWith('🔐');
  const cleanContent = content.replace(/^[🔒🔐]\s*/, '');

  return (
    <div className="space-y-1.5">
      <div
        className={`text-xs sm:text-sm font-mono whitespace-pre-wrap break-words overscroll-contain touch-pan-y ${
          isExpanded
            ? 'max-h-[600px] overflow-y-auto custom-scrollbar'
            : 'max-h-[250px] overflow-y-auto custom-scrollbar'
        }`}
      >
        {isDecryptionNotice ? (
          <span className="flex items-start gap-1.5">
            <Lock className={`w-3.5 h-3.5 shrink-0 mt-0.5 ${isCurrentUser ? 'text-white' : 'text-[#141414]'}`} />
            <span>{cleanContent}</span>
          </span>
        ) : (
          content
        )}
      </div>
      {isLong && (
        <button
          type="button"
          onClick={() => setIsExpanded(!isExpanded)}
          className={`text-[10px] font-mono font-bold uppercase tracking-wider underline cursor-pointer transition-opacity hover:opacity-100 ${
            isCurrentUser ? 'text-white/80' : 'text-[#141414]/80'
          }`}
        >
          {isExpanded ? '▲ Collapse message' : '▼ Read full message'}
        </button>
      )}
    </div>
  );
});

export const ChatModal: React.FC<ChatModalProps> = ({
  connectionId,
  allConnectionIds,
  peerName,
  peerAvatar,
  peerAgentId,
  peerE2eePublicKey: initialPeerKey,
  peerIsMaster,
  peerIsSlave,
  deviceSize,
  onSelectChat,
  onSelectClusterChat,
  onClose,
  onOpenAgentProfile,
}) => {
  const { user, activeAccount, userPassword, e2eeStatus, ensureE2EEKeys, sessionAuthType } = useAuth();
  const actingUser = activeAccount || user;
  const accountKey = getAccountKey(user?.id, activeAccount?.id);
  const isSlave = isSlaveAccount(actingUser);
  const effectiveDeviceSize: 'mobile' | 'tablet' | 'desktop' =
    deviceSize || (typeof window !== 'undefined' ? (window.innerWidth < 768 ? 'mobile' : window.innerWidth <= 1024 ? 'tablet' : 'desktop') : 'desktop');
  const isMobile = effectiveDeviceSize === 'mobile';
  const isTablet = effectiveDeviceSize === 'tablet';
  const isDesktop = effectiveDeviceSize === 'desktop';
  const hasChannelSwitcher = Boolean(onSelectChat || onSelectClusterChat);
  const [isChannelSidebarOpen, setIsChannelSidebarOpen] = useState<boolean>(true);

  const toggleChannelSidebar = useCallback(() => {
    setIsChannelSidebarOpen((prev) => !prev);
  }, []);
  const effectiveAuthType: 'human' | 'agent' = sessionAuthType || getCurrentSessionAuthType() || 'human';
  const rawAliasListKey = Array.isArray(allConnectionIds) ? allConnectionIds.join('|') : '';
  const aliasIds = React.useMemo(
    () => Array.from(new Set([connectionId, ...(rawAliasListKey ? rawAliasListKey.split('|') : [])].filter((id): id is string => Boolean(id && typeof id === 'string' && id.trim())))),
    [connectionId, rawAliasListKey]
  );
  const aliasKey = aliasIds.join('|');
  const [messages, setMessages] = useState<DecryptedChatMessage[]>(() =>
    getCachedConnectionMessagesByAliases([connectionId, ...(allConnectionIds || [])], accountKey, peerAgentId)
  );
  const messagesRef = useRef<DecryptedChatMessage[]>(messages);
  messagesRef.current = messages;
  const [newMessage, setNewMessage] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isSending, setIsSending] = useState(false);
  const [sendError, setSendError] = useState<string | null>(null);
  const voiceRecorder = useVoiceRecorder();

  const handleMicClick = async () => {
    if (voiceRecorder.state === 'idle') {
      await voiceRecorder.startRecording();
    } else if (voiceRecorder.state === 'recording') {
      voiceRecorder.stopRecording();
    }
  };

  const sentPlaintextsRef = useRef<Map<string, string>>(new Map());
  const [hiddenMessageIds, setHiddenMessageIds] = useState<Set<string>>(new Set());
  const [showHiddenMessages, setShowHiddenMessages] = useState(false);
  const [isLoading, setIsLoading] = useState(
    () => getCachedConnectionMessagesByAliases([connectionId, ...(allConnectionIds || [])], accountKey, peerAgentId).length === 0
  );
  const [hasPendingNewBelow, setHasPendingNewBelow] = useState(false);
  const [fetchError, setFetchError] = useState<string | null>(null);

  // E2EE Keystore State & Refs (refs prevent fetchAndDecryptMessages re-render storms)
  const canonicalConnectionIdRef = useRef<string>(connectionId);
  const [localKeys, setLocalKeys] = useState<StoredAgentKeyEntry | null>(null);
  const localKeysRef = useRef<StoredAgentKeyEntry | null>(null);
  const [peerKey, setPeerKey] = useState<string | null>(initialPeerKey || null);
  const peerKeyRef = useRef<string | null>(initialPeerKey || null);
  const [peerKeyEpoch, setPeerKeyEpoch] = useState<number>(1);
  const peerKeyEpochRef = useRef<number>(1);
  const [peerEpochKeys, setPeerEpochKeys] = useState<Record<string, any>>({});
  const peerEpochKeysRef = useRef<Record<string, any>>({});
  const [resolvedPeerAgentId, setResolvedPeerAgentId] = useState<string | undefined>(peerAgentId);
  const resolvedPeerAgentIdRef = useRef<string | undefined>(peerAgentId);
  const hasScrolledInitiallyRef = useRef<boolean>(false);
  const hasCompletedInitialSyncRef = useRef<boolean>(false);
  const userScrolledUpRef = useRef<boolean>(false);
  const lastScrollTopRef = useRef<number>(0);
  const isNearBottomRef = useRef<boolean>(true);
  const prevLastMsgIdRef = useRef<string | null>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const composerInputRef = useRef<HTMLInputElement>(null);
  const isFetchingRef = useRef<boolean>(false);
  const pendingRefetchRef = useRef<boolean>(false);
  const pendingForceKeyRef = useRef<string | undefined>(undefined);
  const syncGenerationRef = useRef<number>(0);
  const retryTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const retryCountRef = useRef<number>(0);
  const lastServerSyncAtRef = useRef<number>(0);

  const syncConnectionMessagesCache = useCallback(
    (nextMessages: DecryptedChatMessage[], extraConnId?: string | null) => {
      const peerAlias = makePeerAliasKey(resolvedPeerAgentIdRef.current || peerAgentId);
      const targetIds = new Set<string>(
        [connectionId, canonicalConnectionIdRef.current, extraConnId, peerAlias, ...aliasIds].filter(
          (id): id is string => Boolean(id && typeof id === 'string' && id.trim())
        )
      );
      targetIds.forEach((cid) => setCachedConnectionMessages(cid, nextMessages, accountKey));
    },
    [connectionId, aliasKey, accountKey, peerAgentId]
  );

  const syncContextRef = useRef({
    actingUser,
    user,
    userPassword,
    e2eeStatus,
    ensureE2EEKeys,
    initialPeerKey,
    peerAgentId,
    peerName,
    aliasIds,
    syncConnectionMessagesCache,
  });
  syncContextRef.current = {
    actingUser,
    user,
    userPassword,
    e2eeStatus,
    ensureE2EEKeys,
    initialPeerKey,
    peerAgentId,
    peerName,
    aliasIds,
    syncConnectionMessagesCache,
  };

  // Non-destructive prop sync: update peer/alias metadata refs without aborting in-flight fetches
  useEffect(() => {
    if (syncContextRef.current.initialPeerKey && !peerKeyRef.current) {
      peerKeyRef.current = syncContextRef.current.initialPeerKey;
      setPeerKey(syncContextRef.current.initialPeerKey);
    }
    if (syncContextRef.current.peerAgentId && !resolvedPeerAgentIdRef.current) {
      resolvedPeerAgentIdRef.current = syncContextRef.current.peerAgentId;
      setResolvedPeerAgentId(syncContextRef.current.peerAgentId);
    }
  }, [initialPeerKey, peerAgentId, aliasKey]);

  // Hard conversation reset ONLY when switching connectionId or active accountKey
  useEffect(() => {
    syncGenerationRef.current += 1;
    isFetchingRef.current = false;
    pendingRefetchRef.current = false;
    pendingForceKeyRef.current = undefined;
    retryCountRef.current = 0;
    lastServerSyncAtRef.current = 0;
    if (retryTimerRef.current) {
      clearTimeout(retryTimerRef.current);
      retryTimerRef.current = null;
    }
    const ctx = syncContextRef.current;
    const cachedPeer = getCachedPeerKey(connectionId);
    const seedConnId = cachedPeer?.connectionId || connectionId;
    const seedPeerKey = ctx.initialPeerKey || cachedPeer?.peerPublicKey || null;
    const seedEpochKeys = cachedPeer?.peerEpochKeys || {};
    const seedPeerEpoch = cachedPeer?.peerKeyEpoch || 1;
    const seedPeerId = ctx.peerAgentId || cachedPeer?.peerAgentId;

    canonicalConnectionIdRef.current = seedConnId;
    hasScrolledInitiallyRef.current = false;
    hasCompletedInitialSyncRef.current = false;
    userScrolledUpRef.current = false;
    lastScrollTopRef.current = 0;
    isNearBottomRef.current = true;
    const cachedMsgs = getCachedConnectionMessagesByAliases([connectionId, ...ctx.aliasIds], accountKey, seedPeerId);
    prevLastMsgIdRef.current = cachedMsgs.length > 0 ? cachedMsgs[cachedMsgs.length - 1]?.id || null : null;
    setMessages(cachedMsgs);
    setIsLoading(cachedMsgs.length === 0);
    setHasPendingNewBelow(false);
    setFetchError(null);
    localKeysRef.current = null;
    setLocalKeys(null);
    peerKeyRef.current = seedPeerKey;
    setPeerKey(seedPeerKey);
    peerKeyEpochRef.current = seedPeerEpoch;
    setPeerKeyEpoch(seedPeerEpoch);
    peerEpochKeysRef.current = seedEpochKeys;
    setPeerEpochKeys(seedEpochKeys);
    resolvedPeerAgentIdRef.current = seedPeerId;
    setResolvedPeerAgentId(seedPeerId);

    const focusRaf = requestAnimationFrame(() => {
      if (composerInputRef.current && document.activeElement !== composerInputRef.current) {
        composerInputRef.current.focus({ preventScroll: true });
      }
    });
    return () => cancelAnimationFrame(focusRaf);
  }, [connectionId, accountKey]);

  // Determine whether the connection peer (recipient) is a Master Account
  const isPeerMaster = React.useMemo(() => {
    if (typeof peerIsMaster === 'boolean') return peerIsMaster;
    if (typeof peerIsSlave === 'boolean') return !peerIsSlave;

    const targetAgentId = resolvedPeerAgentId || peerAgentId;
    if (!targetAgentId) return false;

    const cleanId = String(targetAgentId).trim().toUpperCase();

    try {
      const cached = getQueryCache('master_accounts', '/api/auth/master/accounts')?.data;
      if (cached) {
        if (cached.masterAgent && String(cached.masterAgent.agentId).toUpperCase() === cleanId) {
          return true;
        }
        if (
          Array.isArray(cached.masterSlotAgents) &&
          cached.masterSlotAgents.some((m: any) => String(m.agentId).toUpperCase() === cleanId)
        ) {
          return true;
        }
        if (
          Array.isArray(cached.subAgents || cached.slaveAgents) &&
          (cached.subAgents || cached.slaveAgents).some((s: any) => String(s.agentId).toUpperCase() === cleanId)
        ) {
          return false;
        }
      }
    } catch {}

    return false;
  }, [peerIsMaster, peerIsSlave, resolvedPeerAgentId, peerAgentId]);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const isMountedRef = useRef(true);
  const lastMarkedReadKeyRef = useRef<string>('');

  useEffect(() => {
    isMountedRef.current = true;
    return () => {
      isMountedRef.current = false;
    };
  }, []);

  useEffect(() => {
    const ids = [connectionId, peerAgentId, resolvedPeerAgentId, peerName].filter((id): id is string => Boolean(id && typeof id === 'string'));
    if (ids.length > 0) {
      clearUnreadCount(accountKey, ids);
    }
    const readKey = `${accountKey}::${connectionId}::${effectiveAuthType}`;
    if (connectionId && lastMarkedReadKeyRef.current !== readKey) {
      lastMarkedReadKeyRef.current = readKey;
      apiFetch(`/api/connections/${connectionId}/read`, {
        method: 'POST',
        authType: effectiveAuthType,
        body: JSON.stringify({ connectionId, agentId: peerAgentId || resolvedPeerAgentId, ids })
      }).catch(() => {});
    }
    return () => {
      if (ids.length > 0) {
        clearUnreadCount(accountKey, ids);
      }
    };
  }, [connectionId, effectiveAuthType, peerAgentId, resolvedPeerAgentId, peerName, accountKey]);

  const [isActivatingPeer, setIsActivatingPeer] = useState(false);
  const handleActivatePeerKey = async (): Promise<boolean> => {
    const targetAgentId = resolvedPeerAgentId || peerAgentId;
    if (!targetAgentId) return false;
    setIsActivatingPeer(true);
    try {
      const res = await apiFetch(`/api/agents/${targetAgentId}/e2ee`, { authType: effectiveAuthType });
      const pubKey = res?.data?.publicKey || res?.publicKey;
      if (pubKey) {
        setPeerKey(pubKey);
        await fetchAndDecryptMessages(pubKey);
        return true;
      } else {
        setSendError('Slave agent manages its own cryptographic identity via its own runtime. Please ensure the slave agent has started and registered its public key.');
        return false;
      }
    } catch (err: any) {
      setSendError(`Failed to fetch agent public key: ${err?.message || err}`);
      return false;
    } finally {
      if (isMountedRef.current) {
        setIsActivatingPeer(false);
      }
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 25 * 1024 * 1024) {
      setSendError('File exceeds maximum allowed size (25MB).');
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }
    setSelectedFile(file);
    setSendError(null);
  };

  const executeSendMessage = async (tempId: string, text: string, fileToEncrypt: File | null) => {
    const targetReceiver = resolvedPeerAgentIdRef.current || resolvedPeerAgentId || peerAgentId;
    let activePeerKey = peerKeyRef.current || peerKey;

    try {
      // Non-blocking peer key readiness: only block if key is completely missing; otherwise refresh silently in background if stale
      if (!activePeerKey) {
        const cachedData = await fetchConnectionPeerKey(connectionId, {
          receiverAgentId: targetReceiver,
          authType: effectiveAuthType,
          forceRefresh: true,
          bypassCooldown: true,
        });
        if (cachedData?.connectionId) {
          canonicalConnectionIdRef.current = cachedData.connectionId;
        }
        if (cachedData?.peerPublicKey) {
          activePeerKey = cachedData.peerPublicKey;
          peerKeyRef.current = activePeerKey;
          setPeerKey(activePeerKey);
        } else if (targetReceiver) {
          const res = await apiFetch(`/api/agents/${targetReceiver}/e2ee`, {
            authType: effectiveAuthType,
            cache: 'no-store',
            skipDedupe: true,
          });
          const pk = res?.data?.publicKey || res?.publicKey;
          if (pk) {
            activePeerKey = pk;
            peerKeyRef.current = activePeerKey;
            setPeerKey(activePeerKey);
          }
        }
      } else if (isPeerKeyStale(connectionId, 60000)) {
        void fetchConnectionPeerKey(connectionId, {
          receiverAgentId: targetReceiver,
          authType: effectiveAuthType,
          forceRefresh: true,
          bypassCooldown: true,
        }).then((cachedData) => {
          if (cachedData?.connectionId) canonicalConnectionIdRef.current = cachedData.connectionId;
          if (cachedData?.peerPublicKey && isMountedRef.current) {
            peerKeyRef.current = cachedData.peerPublicKey;
            setPeerKey(cachedData.peerPublicKey);
          }
        }).catch(() => {});
      }

      if (!activePeerKey) {
        throw new Error(`Recipient public key not registered for connection ${connectionId}.`);
      }

      let payloadToSend = text;
      const resolvedForAttachment = canonicalConnectionIdRef.current || connectionId;

      if (fileToEncrypt) {
        const myAgent = actingUser?.agentId || user?.agentId || '';
        let currentLocalKeys = myAgent
          ? await resolveOrRecoverSenderLocalKeys(myAgent, userPassword || undefined, effectiveAuthType).catch(
              () => localKeysRef.current || localKeys
            )
          : (localKeysRef.current || localKeys);
        if (!currentLocalKeys?.privateKey && myAgent) {
          currentLocalKeys = await getLocalKeyPair(myAgent, undefined, userPassword || undefined);
        }
        if (currentLocalKeys) {
          localKeysRef.current = currentLocalKeys;
          setLocalKeys(currentLocalKeys);
        }
        if (!currentLocalKeys?.privateKey) {
          throw new Error('Local private key unavailable for attachment encryption.');
        }

        const fileBytes = await fileToEncrypt.arrayBuffer();
        const rawBytes = new Uint8Array(fileBytes);
        let base64File = '';
        try {
          base64File = uint8ToBase64(rawBytes);
        } catch {}

        let encryptedAttId: string | undefined = undefined;
        try {
          const encryptedAtt = await encryptAttachmentFile(
            {
              name: fileToEncrypt.name,
              type: fileToEncrypt.type || 'application/octet-stream',
              size: fileToEncrypt.size,
              data: rawBytes
            },
            currentLocalKeys.privateKey,
            activePeerKey,
            resolvedForAttachment,
            user!.agentId,
            currentLocalKeys.keyEpoch || 1
          );
          encryptedAttId = encryptedAtt.attachmentId;
          await uploadEncryptedAttachmentApi(resolvedForAttachment, encryptedAtt, effectiveAuthType);
        } catch (uploadNotice) {
          console.warn('Server attachment storage notice:', uploadNotice);
        }

        payloadToSend = JSON.stringify({
          aamarva_attachment: true,
          attachmentId: encryptedAttId,
          filename: fileToEncrypt.name,
          size: fileToEncrypt.size,
          mimeType: fileToEncrypt.type || 'application/octet-stream',
          fileBase64: base64File || undefined,
          text: text || undefined
        });
      }

      sentPlaintextsRef.current.set(tempId, payloadToSend);
      try {
        sessionStorage.setItem(`aamarva_plain_${connectionId}_${tempId}`, payloadToSend);
        if (resolvedForAttachment !== connectionId) {
          sessionStorage.setItem(`aamarva_plain_${resolvedForAttachment}_${tempId}`, payloadToSend);
        }
      } catch {}
      cacheDecryptedMessage(payloadToSend, [
        tempId,
        `${connectionId}_${tempId}`,
        `${resolvedForAttachment}_${tempId}`,
      ]);

      const myAgent = actingUser?.agentId || user?.agentId || '';
      const sentRes = await sendPrivateMessageApi(connectionId, payloadToSend, myAgent, { 
        password: userPassword || undefined,
        receiverAgentId: targetReceiver,
        authType: effectiveAuthType
      });

      const realId = sentRes?.id || sentRes?.messageId;
      if (!realId) {
        throw new Error('Server did not return a persisted message ID.');
      }

      const returnedConnId = sentRes?.connectionId || resolvedForAttachment;
      if (sentRes?.connectionId) {
        canonicalConnectionIdRef.current = sentRes.connectionId;
      }

      const keysToCache: (string | undefined | null)[] = [
        realId,
        `${connectionId}_${realId}`,
        `${returnedConnId}_${realId}`,
      ];
      if (sentRes?.nonce) {
        keysToCache.push(sentRes.nonce, `${connectionId}_${sentRes.nonce}`, `${returnedConnId}_${sentRes.nonce}`);
      }
      if (sentRes?.ciphertext) {
        keysToCache.push(sentRes.ciphertext, `${connectionId}_${sentRes.ciphertext}`, `${returnedConnId}_${sentRes.ciphertext}`);
      }
      cacheDecryptedMessage(payloadToSend, keysToCache);
      try {
        sessionStorage.setItem(`aamarva_plain_${connectionId}_${realId}`, payloadToSend);
        if (returnedConnId !== connectionId) {
          sessionStorage.setItem(`aamarva_plain_${returnedConnId}_${realId}`, payloadToSend);
        }
      } catch {}

      const applyReconcile = (list: DecryptedChatMessage[]): DecryptedChatMessage[] =>
        list.map((m) =>
          m.id === tempId
            ? {
                ...m,
                id: realId,
                connectionId: returnedConnId || m.connectionId,
                createdAt: sentRes?.createdAt || m.createdAt,
                deliveryStatus: 'sent',
                content: payloadToSend,
                retryPayload: undefined,
              }
            : m
        );

      // Persist immediately to cache even if the user closed the modal mid-flight
      const reconciledCache = applyReconcile(getCachedConnectionMessages(connectionId, accountKey));
      syncConnectionMessagesCache(reconciledCache, returnedConnId);

      // Reconcile optimistic message in place to 'sent'
      if (isMountedRef.current) {
        setMessages((prev) => {
          const next = applyReconcile(prev);
          syncConnectionMessagesCache(next, returnedConnId);
          return next;
        });
      }
    } catch (err: any) {
      console.error('Failed to send message:', err);
      const applyFailed = (list: DecryptedChatMessage[]): DecryptedChatMessage[] =>
        list.map((m) =>
          m.id === tempId
            ? { ...m, deliveryStatus: 'failed', retryPayload: { text, fileToEncrypt } }
            : m
        );

      const failedCache = applyFailed(getCachedConnectionMessages(connectionId, accountKey));
      syncConnectionMessagesCache(failedCache);

      if (isMountedRef.current) {
        setMessages((prev) => {
          const next = applyFailed(prev);
          syncConnectionMessagesCache(next);
          return next;
        });
        setSendError(err?.message || 'Failed to send message.');
      }
    }
  };

  const handleRetryMessage = async (messageId: string) => {
    const targetMsg = messages.find((m) => m.id === messageId);
    if (!targetMsg || !targetMsg.retryPayload) return;
    setSendError(null);
    setMessages((prev) => {
      const next = prev.map((m) => (m.id === messageId ? { ...m, deliveryStatus: 'sending' as const } : m));
      syncConnectionMessagesCache(next);
      return next;
    });
    executeSendMessage(messageId, targetMsg.retryPayload.text, targetMsg.retryPayload.fileToEncrypt || null);
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSlave) {
      setSendError('Slave UI messaging is disabled. Slave agents must send messages via their agent runtime API.');
      return;
    }
    const text = newMessage.trim();
    if ((!text && !selectedFile) || !user?.agentId) return;

    setSendError(null);
    const fileToEncrypt = selectedFile;
    const tempId = `temp_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

    // Build optimistic message payload for instantaneous render
    let optimisticPayload = text;
    if (fileToEncrypt) {
      optimisticPayload = JSON.stringify({
        aamarva_attachment: true,
        filename: fileToEncrypt.name,
        size: fileToEncrypt.size,
        mimeType: fileToEncrypt.type || 'application/octet-stream',
        text: text || undefined
      });
    }

    const optimisticMsg: DecryptedChatMessage = {
      id: tempId,
      connectionId: canonicalConnectionIdRef.current || connectionId,
      senderAgentId: user.agentId,
      content: optimisticPayload,
      isDecrypted: true,
      createdAt: new Date().toISOString(),
      deliveryStatus: 'sending',
      retryPayload: { text, fileToEncrypt }
    };

    // Render immediately and persist in connection cache so reopen preserves message state
    setMessages((prev) => {
      const next = [...prev, optimisticMsg];
      syncConnectionMessagesCache(next);
      return next;
    });
    setNewMessage('');
    setSelectedFile(null);
    if (fileInputRef.current) fileInputRef.current.value = '';

    // Asynchronously dispatch transmission in background
    executeSendMessage(tempId, text, fileToEncrypt);
  };

  // Secure Server-Blind E2EE Voice Message Transmission
  const handleSendVoiceMessage = async () => {
    if (!voiceRecorder.audioBlob || !user?.agentId || isSending) return;
    setIsSending(true);
    setSendError(null);

    const targetReceiver = resolvedPeerAgentId || peerAgentId;
    let activePeerKey = peerKey;

    if (!activePeerKey) {
      try {
        const cachedData = await fetchConnectionPeerKey(connectionId, {
          receiverAgentId: targetReceiver,
          authType: effectiveAuthType,
          forceRefresh: true,
          bypassCooldown: true,
        });
        if (cachedData?.peerPublicKey) {
          activePeerKey = cachedData.peerPublicKey;
          peerKeyRef.current = activePeerKey;
          setPeerKey(activePeerKey);
        } else if (targetReceiver) {
          const res = await apiFetch(`/api/agents/${targetReceiver}/e2ee`, {
            authType: effectiveAuthType,
            cache: 'no-store',
            skipDedupe: true,
          });
          const pk = res?.data?.publicKey || res?.publicKey;
          if (pk) {
            activePeerKey = pk;
            peerKeyRef.current = activePeerKey;
            setPeerKey(activePeerKey);
          }
        }
      } catch (err: any) {
        console.warn('Pre-send key readiness notice:', err?.message || err);
      }
    }

    if (!activePeerKey) {
      setSendError(`E2EE Error: Recipient public key not registered for connection ${connectionId}. Outbound voice transmission aborted.`);
      setIsSending(false);
      return;
    }

    try {
      let currentLocalKeys = await resolveOrRecoverSenderLocalKeys(
        user.agentId,
        userPassword || undefined,
        effectiveAuthType
      ).catch(() => localKeys);
      if (!currentLocalKeys?.privateKey) {
        currentLocalKeys = await getLocalKeyPair(user.agentId, undefined, userPassword || undefined);
      }
      if (currentLocalKeys) {
        localKeysRef.current = currentLocalKeys;
        setLocalKeys(currentLocalKeys);
      }
      if (!currentLocalKeys?.privateKey) {
        throw new Error('Local private key unavailable for voice encryption.');
      }

      const ext = voiceRecorder.mimeType.includes('mp4') ? 'mp4' : voiceRecorder.mimeType.includes('ogg') ? 'ogg' : 'webm';
      const filename = `voice_message_${Date.now()}.${ext}`;
      const audioBytes = new Uint8Array(await voiceRecorder.audioBlob.arrayBuffer());

      // 1. Client-side E2EE encryption using P-256 ECDH + HKDF-SHA256 + AES-256-GCM
      const encryptedAtt = await encryptAttachmentFile(
        {
          name: filename,
          type: voiceRecorder.mimeType || 'audio/webm',
          size: voiceRecorder.audioBlob.size,
          data: audioBytes,
        },
        currentLocalKeys.privateKey,
        activePeerKey,
        connectionId,
        user.agentId,
        currentLocalKeys.keyEpoch || 1
      );

      // 2. Prepare base64 for instant optimistic local preview and peer playback
      let base64Audio = '';
      try {
        base64Audio = uint8ToBase64(audioBytes);
      } catch {}

      // 3. Best-effort upload ciphertext to server-blind storage
      let encryptedAttId: string | undefined = encryptedAtt?.attachmentId;
      try {
        await uploadEncryptedAttachmentApi(connectionId, encryptedAtt, effectiveAuthType);
      } catch (attUploadErr) {
        console.warn('Voice server attachment storage notice (embedded ciphertext active):', attUploadErr);
      }

      const noteText = newMessage.trim();
      const payloadToSend = JSON.stringify({
        aamarva_attachment: true,
        isVoiceMessage: true,
        attachmentId: encryptedAttId,
        filename,
        size: voiceRecorder.audioBlob.size,
        mimeType: voiceRecorder.mimeType || 'audio/webm',
        duration: voiceRecorder.duration,
        audioBase64: base64Audio || undefined,
        text: noteText || undefined,
      });

      const optimisticPayload = payloadToSend;

      // Optimistic message placeholder
      const myAgent = actingUser?.agentId || user?.agentId || '';
      const tempId = `temp_voice_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      const optimisticMsg: DecryptedChatMessage = {
        id: tempId,
        connectionId,
        senderAgentId: myAgent,
        content: optimisticPayload,
        isDecrypted: true,
        keyEpoch: peerKeyEpoch || 1,
        createdAt: new Date().toISOString(),
        deliveryStatus: 'sending',
      };

      sentPlaintextsRef.current.set(tempId, optimisticPayload);
      try { sessionStorage.setItem(`aamarva_plain_${connectionId}_${tempId}`, optimisticPayload); } catch {}
      cacheDecryptedMessage(optimisticPayload, [tempId, `${connectionId}_${tempId}`]);
      setMessages((prev) => {
        const next = [...prev, optimisticMsg];
        syncConnectionMessagesCache(next);
        return next;
      });

      setNewMessage('');
      voiceRecorder.clearRecording();

      // 4. Send encrypted private message envelope through existing channel
      const sentRes = await sendPrivateMessageApi(connectionId, payloadToSend, myAgent, {
        password: userPassword || undefined,
        receiverAgentId: targetReceiver,
        authType: effectiveAuthType,
      });

      const realId = sentRes?.id || sentRes?.messageId;
      if (!realId) {
        throw new Error('Server did not return a persisted voice message ID.');
      }
      const returnedConnId = sentRes?.connectionId || canonicalConnectionIdRef.current || connectionId;
      if (sentRes?.connectionId) {
        canonicalConnectionIdRef.current = sentRes.connectionId;
      }

      const keysToCache: (string | undefined | null)[] = [
        realId,
        `${connectionId}_${realId}`,
        `${returnedConnId}_${realId}`,
      ];
      if (sentRes?.nonce) keysToCache.push(sentRes.nonce, `${connectionId}_${sentRes.nonce}`, `${returnedConnId}_${sentRes.nonce}`);
      if (sentRes?.ciphertext) keysToCache.push(sentRes.ciphertext, `${connectionId}_${sentRes.ciphertext}`, `${returnedConnId}_${sentRes.ciphertext}`);
      cacheDecryptedMessage(payloadToSend, keysToCache);

      const applyVoiceReconcile = (list: DecryptedChatMessage[]): DecryptedChatMessage[] =>
        list.map((m) =>
          m.id === tempId
            ? {
                ...m,
                id: realId,
                connectionId: returnedConnId || m.connectionId,
                createdAt: sentRes?.createdAt || m.createdAt,
                deliveryStatus: 'sent',
                content: payloadToSend,
              }
            : m
        );

      const reconciledVoiceCache = applyVoiceReconcile(getCachedConnectionMessages(connectionId, accountKey));
      syncConnectionMessagesCache(reconciledVoiceCache, returnedConnId);

      // Reconcile optimistic voice message in place
      if (isMountedRef.current) {
        setMessages((prev) => {
          const next = applyVoiceReconcile(prev);
          syncConnectionMessagesCache(next, returnedConnId);
          return next;
        });
      }
    } catch (err: any) {
      console.error('Failed to send voice message:', err);
      const applyVoiceFail = (list: DecryptedChatMessage[]): DecryptedChatMessage[] =>
        list.map((m) =>
          m.id.startsWith('temp_voice_') ? { ...m, deliveryStatus: 'failed' as const } : m
        );

      syncConnectionMessagesCache(applyVoiceFail(getCachedConnectionMessages(connectionId, accountKey)));

      if (isMountedRef.current) {
        setMessages((prev) => {
          const next = applyVoiceFail(prev);
          syncConnectionMessagesCache(next);
          return next;
        });
        setSendError(err?.message || 'Failed to send voice message');
      }
    } finally {
      if (isMountedRef.current) {
        setIsSending(false);
      }
    }
  };

  // Synchronized message fetch and decryption (non-blocking against /peer-key or E2EE recovery waits)
  const fetchAndDecryptMessages = useCallback(async (forcedPeerKey?: string) => {
    const ctx = syncContextRef.current;
    const myAgentId = ctx.actingUser?.agentId || ctx.user?.agentId;
    if (!myAgentId) return;

    if (!connectionId || !connectionId.trim()) {
      setFetchError('Connection not found: Missing or invalid connection ID.');
      setIsLoading(false);
      return;
    }

    // If a sync is already in flight, queue an immediate uncoalesced catch-up run instead of dropping or sharing a stale GET
    if (isFetchingRef.current) {
      pendingRefetchRef.current = true;
      if (forcedPeerKey) pendingForceKeyRef.current = forcedPeerKey;
      return;
    }

    if (retryTimerRef.current) {
      clearTimeout(retryTimerRef.current);
      retryTimerRef.current = null;
    }

    const requestGen = syncGenerationRef.current;
    const syncStartedAt = Date.now();
    isFetchingRef.current = true;

    const scheduleFastRetry = () => {
      if (!isMountedRef.current || requestGen !== syncGenerationRef.current) return;
      if (retryCountRef.current >= 3) return;
      const delays = [1200, 2500, 5000];
      const delay = delays[retryCountRef.current] ?? 5000;
      retryCountRef.current += 1;
      if (retryTimerRef.current) clearTimeout(retryTimerRef.current);
      retryTimerRef.current = setTimeout(() => {
        retryTimerRef.current = null;
        if (isMountedRef.current && requestGen === syncGenerationRef.current) {
          void fetchAndDecryptMessages(forcedPeerKey);
        }
      }, delay);
    };

    try {
      // 1. Resolve synchronous peer metadata from refs & prefetch cache at t=0
      let currentPeerKey = forcedPeerKey || peerKeyRef.current || ctx.initialPeerKey || null;
      let currentPeerEpochKeys = peerEpochKeysRef.current;
      let currentPeerId = resolvedPeerAgentIdRef.current || ctx.peerAgentId;
      let currentPeerEpoch = peerKeyEpochRef.current || 1;

      const cachedPeer =
        getCachedPeerKey(connectionId) ||
        (canonicalConnectionIdRef.current !== connectionId ? getCachedPeerKey(canonicalConnectionIdRef.current) : null);
      if (cachedPeer) {
        if (cachedPeer.connectionId) {
          canonicalConnectionIdRef.current = cachedPeer.connectionId;
        }
        if (!currentPeerKey && cachedPeer.peerPublicKey) {
          currentPeerKey = cachedPeer.peerPublicKey;
          peerKeyRef.current = currentPeerKey;
          if (isMountedRef.current) setPeerKey(currentPeerKey);
        }
        if (cachedPeer.peerKeyEpoch) {
          currentPeerEpoch = cachedPeer.peerKeyEpoch;
          peerKeyEpochRef.current = currentPeerEpoch;
          if (isMountedRef.current) setPeerKeyEpoch(currentPeerEpoch);
        }
        if (Object.keys(currentPeerEpochKeys).length === 0 && cachedPeer.peerEpochKeys && Object.keys(cachedPeer.peerEpochKeys).length > 0) {
          currentPeerEpochKeys = cachedPeer.peerEpochKeys;
          peerEpochKeysRef.current = currentPeerEpochKeys;
          if (isMountedRef.current) setPeerEpochKeys(currentPeerEpochKeys);
        }
        if (!currentPeerId && cachedPeer.peerAgentId) {
          currentPeerId = cachedPeer.peerAgentId;
          resolvedPeerAgentIdRef.current = currentPeerId;
          if (isMountedRef.current) setResolvedPeerAgentId(currentPeerId);
        }
      }

      const targetPeerId = currentPeerId || ctx.peerAgentId;
      let pinnedPeerKey: string | null = null;
      if (!currentPeerKey && targetPeerId) {
        try {
          const pinned = await getPinnedPeerKey(normalizeAgentId(targetPeerId));
          if (pinned?.publicKey) {
            pinnedPeerKey = pinned.publicKey;
            currentPeerKey = pinned.publicKey;
            peerKeyRef.current = pinned.publicKey;
          }
        } catch {}
      }

      const queryParts: string[] = [];
      if (targetPeerId) {
        queryParts.push(`receiverAgentId=${encodeURIComponent(targetPeerId)}`);
      }
      const sinceIso =
        !forcedPeerKey && hasCompletedInitialSyncRef.current
          ? computeIncrementalSince(messagesRef.current)
          : undefined;
      if (sinceIso) {
        queryParts.push(`since=${encodeURIComponent(sinceIso)}`);
      }
      const peerQuery = queryParts.length > 0 ? `?${queryParts.join('&')}` : '';
      const needsKeyFetch =
        !currentPeerKey ||
        !currentPeerId ||
        Object.keys(currentPeerEpochKeys).length === 0 ||
        isPeerKeyStale(connectionId, 60000);

      // 2a. Fast local key resolution: read IndexedDB/localStorage FIRST without waiting for E2EE network sync
      const resolveLocalKeysPromise = (async () => {
        if (localKeysRef.current?.privateKey) {
          return localKeysRef.current;
        }
        let keys = await getLocalKeyPair(myAgentId, undefined, ctx.userPassword || undefined);
        if (!keys?.privateKey && (ctx.e2eeStatus === 'initializing' || ctx.e2eeStatus === 'recovery_in_progress' || !keys)) {
          await ctx.ensureE2EEKeys(myAgentId, false, ctx.userPassword || undefined);
          keys = await getLocalKeyPair(myAgentId, undefined, ctx.userPassword || undefined);
        }
        if (keys) {
          localKeysRef.current = keys;
          if (isMountedRef.current && requestGen === syncGenerationRef.current) {
            setLocalKeys(keys);
          }
        }
        return keys;
      })();

      // 2b. Fire /peer-key independently (never block /messages decryption on /peer-key!)
      const peerKeyFetchPromise = needsKeyFetch
        ? fetchConnectionPeerKey(connectionId, {
            receiverAgentId: targetPeerId,
            authType: effectiveAuthType,
            forceRefresh: isPeerKeyStale(connectionId, 60000),
            bypassCooldown: true,
          }).catch(() => null)
        : Promise.resolve(null);

      // 2c. Fire live server message fetch immediately at t=0
      const messagesFetchPromise = apiFetch(`/api/connections/${connectionId}/messages${peerQuery}`, {
        authType: effectiveAuthType,
        cache: 'no-store',
        skipDedupe: true,
      }).catch((e) => ({
        success: false,
        error: { message: e?.message || 'Failed to fetch messages.' },
      }));

      // Only await local keys + /messages before rendering!
      let [currentLocalKeys, responseData] = await Promise.all([
        resolveLocalKeysPromise,
        messagesFetchPromise,
      ]);

      if (!isMountedRef.current || requestGen !== syncGenerationRef.current) return;

      if (!responseData || responseData.success === false || responseData.error) {
        const errStatus = responseData?.error?.status;
        const errCode = responseData?.error?.code;
        const errMsg = responseData?.error?.message || responseData?.message || 'Failed to fetch conversation logs.';
        const isNewDirectChat = connectionId.startsWith('conn_') || connectionId.startsWith('fleet_conn_');
        const isNotFound =
          errStatus === 404 ||
          errCode === 'CONNECTION_NOT_FOUND' ||
          String(errMsg).toLowerCase().includes('not found');

        if (isMountedRef.current) {
          if (isNewDirectChat && isNotFound) {
            setFetchError(null);
          } else {
            setFetchError(errMsg);
            scheduleFastRetry();
          }
        }
        return;
      }

      retryCountRef.current = 0;

      const rawList = Array.isArray(responseData?.data)
        ? responseData.data
        : Array.isArray(responseData)
          ? responseData
          : null;

      if (Array.isArray(rawList)) {
        interface FallbackPeerKeyBundle {
          peerPublicKey: string | null;
          peerEpochKeys?: Record<string, any>;
          peerKeyEpoch?: number;
        }
        const fallbackPeerKeyPromises = new Map<string, Promise<FallbackPeerKeyBundle | null>>();
        const fetchFallbackSenderKey = (targetPeer: string): Promise<FallbackPeerKeyBundle | null> => {
          const clean = normalizeAgentId(targetPeer);
          if (!clean || clean === 'PEER') return Promise.resolve(null);
          const existing = fallbackPeerKeyPromises.get(clean);
          if (existing) return existing;

          const p = (async (): Promise<FallbackPeerKeyBundle | null> => {
            try {
              const peerInfo = await fetchConnectionPeerKey(connectionId, {
                receiverAgentId: targetPeer,
                authType: effectiveAuthType,
                forceRefresh: true,
                bypassCooldown: true,
              });
              if (peerInfo?.peerPublicKey || (peerInfo?.peerEpochKeys && Object.keys(peerInfo.peerEpochKeys).length > 0)) {
                if (peerInfo.peerPublicKey) {
                  peerKeyRef.current = peerInfo.peerPublicKey;
                  if (isMountedRef.current) setPeerKey(peerInfo.peerPublicKey);
                }
                if (peerInfo.peerEpochKeys && Object.keys(peerInfo.peerEpochKeys).length > 0) {
                  peerEpochKeysRef.current = peerInfo.peerEpochKeys;
                  if (isMountedRef.current) setPeerEpochKeys(peerInfo.peerEpochKeys);
                }
                if (peerInfo.peerKeyEpoch) {
                  peerKeyEpochRef.current = peerInfo.peerKeyEpoch;
                  if (isMountedRef.current) setPeerKeyEpoch(peerInfo.peerKeyEpoch);
                }
                return {
                  peerPublicKey: peerInfo.peerPublicKey || null,
                  peerEpochKeys: peerInfo.peerEpochKeys,
                  peerKeyEpoch: peerInfo.peerKeyEpoch,
                };
              }
            } catch {}
            try {
              const agentKeyRes = await apiFetch(`/api/agents/${targetPeer}/e2ee`, {
                authType: effectiveAuthType,
                cache: 'no-store',
                skipDedupe: true,
              });
              const pubKey = agentKeyRes?.data?.publicKey || agentKeyRes?.publicKey || null;
              const epKeys = agentKeyRes?.data?.epochHistory || agentKeyRes?.data?.epochKeys || agentKeyRes?.epochHistory || agentKeyRes?.epochKeys;
              const epNum = agentKeyRes?.data?.keyEpoch || agentKeyRes?.keyEpoch;
              if (pubKey || epKeys) {
                if (pubKey) {
                  peerKeyRef.current = pubKey;
                  if (isMountedRef.current) setPeerKey(pubKey);
                }
                if (epKeys && typeof epKeys === 'object' && Object.keys(epKeys).length > 0) {
                  peerEpochKeysRef.current = epKeys;
                  if (isMountedRef.current) setPeerEpochKeys(epKeys);
                }
                return { peerPublicKey: pubKey, peerEpochKeys: epKeys, peerKeyEpoch: epNum };
              }
            } catch {}
            return null;
          })();
          fallbackPeerKeyPromises.set(clean, p);
          return p;
        };

        const historicalKeyCache = new Map<number, CryptoKey | string>();
        const allLocalKeysList = await getAllLocalEpochKeys(myAgentId).catch(() => [] as StoredAgentKeyEntry[]);
        for (const epEntry of allLocalKeysList) {
          if (epEntry?.privateKey) {
            historicalKeyCache.set(epEntry.keyEpoch || 1, epEntry.privateKey);
          }
        }
        if (currentLocalKeys?.privateKey) {
          historicalKeyCache.set(currentLocalKeys.keyEpoch || 1, currentLocalKeys.privateKey);
        }

        const decryptTranscriptBatch = async (
          allowFallbackNetworkKeyLookup: boolean,
          peerKeyOverride?: string | null,
          peerEpochKeysOverride?: Record<string, any>,
          peerIdOverride?: string,
          peerEpochOverride?: number
        ): Promise<DecryptedChatMessage[]> => {
          const effPeerKey = peerKeyOverride ?? currentPeerKey;
          const effPeerEpochKeys = peerEpochKeysOverride ?? currentPeerEpochKeys;
          const effPeerId = peerIdOverride ?? currentPeerId;
          const effPeerEpoch = peerEpochOverride ?? currentPeerEpoch;
          const curCtx = syncContextRef.current;

          return Promise.all(
            rawList.map(async (m: any) => {
              const sender = m.senderAgentId || 'Agent';
              const ciphertext = m.ciphertext;
              const nonce = m.nonce;
              const msgEpoch = m.keyEpoch || 1;
              const isPublicContext = m.id && (m.id.startsWith('msg_post_') || m.id.startsWith('msg_reply_'));

              if (isPublicContext && m.content) {
                return {
                  id: m.id,
                  connectionId: m.connectionId,
                  senderAgentId: sender,
                  content: m.content,
                  isDecrypted: true,
                  keyEpoch: msgEpoch,
                  sequence: typeof m.sequence === 'number' ? m.sequence : undefined,
                  createdAt: m.createdAt,
                };
              }

              const cachedPlain = getCachedDecryptedMessage([
                m.id,
                m.messageId,
                m.nonce,
                m.ciphertext,
                `${connectionId}_${m.id}`,
                `${canonicalConnectionIdRef.current}_${m.id}`,
                `${connectionId}_${m.nonce}`,
                `${connectionId}_${m.ciphertext}`,
                `aamarva_plain_${connectionId}_${m.id}`,
                `aamarva_plain_${connectionId}_${m.nonce}`,
                `aamarva_plain_${connectionId}_${m.ciphertext}`,
              ]);

              if (cachedPlain && !isDecryptionErrorPlaceholder(cachedPlain)) {
                return {
                  id: m.id,
                  connectionId: m.connectionId || connectionId,
                  senderAgentId: sender,
                  content: cachedPlain,
                  isDecrypted: true,
                  keyEpoch: msgEpoch,
                  sequence: typeof m.sequence === 'number' ? m.sequence : undefined,
                  createdAt: m.createdAt,
                };
              }

              let resolvedPlaintext: string | null = null;
              let decryptionErrorReason: string | null = null;

              if (ciphertext && nonce) {
                if (!currentLocalKeys && historicalKeyCache.size === 0) {
                  decryptionErrorReason = 'MISSING_RECIPIENT_PRIVATE_KEY';
                } else {
                  try {
                    const candidateLocalKeys: (CryptoKey | string)[] = [];
                    const pushLocalCandidate = (k?: CryptoKey | string | null) => {
                      if (k && !candidateLocalKeys.includes(k)) candidateLocalKeys.push(k);
                    };

                    let exactEpochKey = historicalKeyCache.get(msgEpoch);
                    if (!exactEpochKey && currentLocalKeys?.keyEpoch !== msgEpoch) {
                      const historicalEntry = await getLocalKeyPair(myAgentId, msgEpoch, curCtx.userPassword || undefined);
                      if (historicalEntry?.privateKey) {
                        exactEpochKey = historicalEntry.privateKey;
                        historicalKeyCache.set(msgEpoch, exactEpochKey);
                      }
                    }
                    // Prioritize exact epoch match first, then active key, then all other known historical epochs
                    pushLocalCandidate(exactEpochKey);
                    pushLocalCandidate(currentLocalKeys?.privateKey);
                    const sortedLocalEpochs = Array.from(historicalKeyCache.entries()).sort(
                      ([epA], [epB]) => Math.abs(epA - msgEpoch) - Math.abs(epB - msgEpoch)
                    );
                    for (const [, k] of sortedLocalEpochs) {
                      pushLocalCandidate(k);
                    }

                    const isMyMessage = normalizeAgentId(m.senderAgentId) === normalizeAgentId(myAgentId);
                    const targetPeer = isMyMessage ? (effPeerId || curCtx.peerAgentId || 'peer') : m.senderAgentId;

                    let senderPubKey = await resolveSenderPublicKey(
                      targetPeer,
                      msgEpoch,
                      effPeerEpochKeys,
                      effPeerKey,
                      effPeerEpoch
                    );

                    let freshBundle: FallbackPeerKeyBundle | null = null;
                    if (!senderPubKey && allowFallbackNetworkKeyLookup && targetPeer && targetPeer !== 'peer') {
                      freshBundle = await fetchFallbackSenderKey(targetPeer);
                      if (freshBundle) {
                        senderPubKey =
                          (await resolveSenderPublicKey(
                            targetPeer,
                            msgEpoch,
                            freshBundle.peerEpochKeys || effPeerEpochKeys,
                            freshBundle.peerPublicKey || effPeerKey,
                            freshBundle.peerKeyEpoch || effPeerEpoch
                          )) || freshBundle.peerPublicKey;
                      }
                    }

                    const candidatePeerKeys: any[] = [];
                    const pushPeerCandidate = (pk: any) => {
                      if (!pk) return;
                      const s = typeof pk === 'string' ? pk : JSON.stringify(pk);
                      if (s && !candidatePeerKeys.includes(s)) candidatePeerKeys.push(s);
                    };
                    pushPeerCandidate(senderPubKey);
                    pushPeerCandidate(effPeerKey);
                    pushPeerCandidate(curCtx.initialPeerKey);
                    pushPeerCandidate(pinnedPeerKey);
                    pushPeerCandidate(cachedPeer?.peerPublicKey);

                    const appendEpochMapKeys = (epMap?: Record<string, any>) => {
                      if (!epMap || typeof epMap !== 'object') return;
                      const ordered = Object.entries(epMap).sort(
                        ([a], [b]) => Math.abs(Number(a) - msgEpoch) - Math.abs(Number(b) - msgEpoch)
                      );
                      for (const [, epVal] of ordered) {
                        pushPeerCandidate(epVal?.publicKey);
                      }
                    };
                    appendEpochMapKeys(effPeerEpochKeys);
                    appendEpochMapKeys(cachedPeer?.peerEpochKeys);

                    const candidateConnIds = Array.from(
                      new Set([m.connectionId, canonicalConnectionIdRef.current, connectionId, ...curCtx.aliasIds].filter(Boolean))
                    );

                    const tryDecryptWithKeys = async (keysToTry: any[]) => {
                      for (const localPrivCandidate of candidateLocalKeys) {
                        if (resolvedPlaintext) break;
                        for (const keyCandidate of keysToTry) {
                          if (resolvedPlaintext) break;
                          for (const cid of candidateConnIds) {
                            try {
                              resolvedPlaintext = await decryptMessage(
                                { ciphertext, nonce, version: m.version || 1, keyEpoch: msgEpoch },
                                localPrivCandidate,
                                keyCandidate,
                                cid,
                                m.senderAgentId || 'AGENT'
                              );
                              if (resolvedPlaintext) break;
                            } catch (decErr: any) {
                              decryptionErrorReason = decErr?.code || 'AUTHENTICATION_TAG_FAILED';
                            }
                          }
                        }
                      }
                    };

                    if (candidatePeerKeys.length === 0) {
                      decryptionErrorReason = 'MISSING_SENDER_PUBLIC_KEY';
                    } else if (candidateLocalKeys.length === 0) {
                      decryptionErrorReason = (currentLocalKeys?.keyEpoch !== msgEpoch) ? 'KEY_EPOCH_NOT_FOUND' : 'MISSING_RECIPIENT_PRIVATE_KEY';
                    } else {
                      await tryDecryptWithKeys(candidatePeerKeys);

                      // If decryption failed using cached/stale key material, force-refresh peer key & epoch history from server & retry
                      if (!resolvedPlaintext && allowFallbackNetworkKeyLookup && targetPeer && targetPeer !== 'peer' && !freshBundle) {
                        freshBundle = await fetchFallbackSenderKey(targetPeer);
                        if (freshBundle) {
                          const freshCandidates: any[] = [];
                          const pushFresh = (pk: any) => {
                            if (!pk) return;
                            const s = typeof pk === 'string' ? pk : JSON.stringify(pk);
                            if (s && !candidatePeerKeys.includes(s) && !freshCandidates.includes(s)) {
                              freshCandidates.push(s);
                            }
                          };
                          const epMatch = freshBundle.peerEpochKeys?.[String(msgEpoch)] || freshBundle.peerEpochKeys?.[msgEpoch];
                          pushFresh(epMatch?.publicKey);
                          pushFresh(freshBundle.peerPublicKey);
                          if (freshBundle.peerEpochKeys && typeof freshBundle.peerEpochKeys === 'object') {
                            for (const epVal of Object.values(freshBundle.peerEpochKeys)) {
                              pushFresh((epVal as any)?.publicKey);
                            }
                          }
                          if (freshCandidates.length > 0) {
                            await tryDecryptWithKeys(freshCandidates);
                          }
                        }
                      }
                    }
                  } catch (decErr: any) {
                    decryptionErrorReason = decErr?.code || 'AUTHENTICATION_TAG_FAILED';
                    resolvedPlaintext = null;
                  }
                }
              }

              if (!resolvedPlaintext && normalizeAgentId(m.senderAgentId) === normalizeAgentId(myAgentId)) {
                const localCached = (m.id && sentPlaintextsRef.current.get(m.id)) ||
                                    (m.nonce && sentPlaintextsRef.current.get(m.nonce)) ||
                                    (m.ciphertext && sentPlaintextsRef.current.get(m.ciphertext)) ||
                                    (m.id && sessionStorage.getItem(`aamarva_plain_${connectionId}_${m.id}`)) ||
                                    (m.nonce && sessionStorage.getItem(`aamarva_plain_${connectionId}_${m.nonce}`)) ||
                                    (m.ciphertext && sessionStorage.getItem(`aamarva_plain_${connectionId}_${m.ciphertext}`)) ||
                                    getCachedDecryptedMessage([m.id, m.nonce, m.ciphertext, `${connectionId}_${m.id}`]);
                if (localCached && !isDecryptionErrorPlaceholder(localCached)) {
                  resolvedPlaintext = localCached;
                } else if (!resolvedPlaintext) {
                  resolvedPlaintext = '[Your encrypted message]';
                }
              }

              if (typeof resolvedPlaintext === 'string' && !isDecryptionErrorPlaceholder(resolvedPlaintext)) {
                const safePlaintext = resolvedPlaintext;
                cacheDecryptedMessage(safePlaintext, [
                  m.id,
                  m.messageId,
                  m.nonce,
                  m.ciphertext,
                  `${connectionId}_${m.id}`,
                  `${connectionId}_${m.nonce}`,
                  `${connectionId}_${m.ciphertext}`,
                ]);

                return {
                  id: m.id,
                  connectionId: m.connectionId || connectionId,
                  senderAgentId: sender,
                  content: safePlaintext,
                  isDecrypted: true,
                  keyEpoch: msgEpoch,
                  sequence: typeof m.sequence === 'number' ? m.sequence : undefined,
                  createdAt: m.createdAt,
                };
              }

              const failureStatus = formatDecryptionErrorStatus(decryptionErrorReason);
              return {
                id: m.id,
                connectionId: m.connectionId,
                senderAgentId: sender,
                content: failureStatus.title,
                decryptionStatus: failureStatus,
                isDecrypted: false,
                keyEpoch: msgEpoch,
                sequence: typeof m.sequence === 'number' ? m.sequence : undefined,
                createdAt: m.createdAt,
              };
            })
          );
        };

        const applyProcessedMessagesToState = (processedList: DecryptedChatMessage[]) => {
          if (!isMountedRef.current || requestGen !== syncGenerationRef.current) return;
          lastServerSyncAtRef.current = Math.max(lastServerSyncAtRef.current, syncStartedAt);
          setMessages((prev) => {
            // CRITICAL: "once decrypted for the ui we never wanna go back to the encrypted phase"
            const prevDecryptedMap = new Map<string, DecryptedChatMessage>();
            for (const p of prev) {
              if (p.isDecrypted && p.content && !isDecryptionErrorPlaceholder(p.content)) {
                prevDecryptedMap.set(p.id, p);
                if (p.sequence !== undefined) {
                  prevDecryptedMap.set(`seq_${p.sequence}`, p);
                }
              }
            }

            const merged = processedList.map((newMsg) => {
              if (!newMsg.isDecrypted) {
                const prevMsg = prevDecryptedMap.get(newMsg.id) || (newMsg.sequence !== undefined ? prevDecryptedMap.get(`seq_${newMsg.sequence}`) : undefined);
                if (prevMsg && prevMsg.isDecrypted && !isDecryptionErrorPlaceholder(prevMsg.content)) {
                  cacheDecryptedMessage(prevMsg.content, [
                    newMsg.id,
                    `${connectionId}_${newMsg.id}`,
                    (newMsg as any).nonce,
                    (newMsg as any).ciphertext
                  ]);
                  return {
                    ...newMsg,
                    content: prevMsg.content,
                    isDecrypted: true,
                    decryptionStatus: undefined
                  };
                }
              }
              return newMsg;
            });

            const existingIds = new Set(merged.map((m) => m.id));
            const prevExtra = prev.filter(
              (p) =>
                p.id &&
                !existingIds.has(p.id) &&
                (p.id.startsWith('temp_')
                  ? !merged.some((m) => m.content === p.content && m.senderAgentId === p.senderAgentId)
                  : p.isDecrypted)
            );
            const combined = [...merged, ...prevExtra];
            combined.sort((a, b) => {
              const timeDiff = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
              if (timeDiff !== 0) return timeDiff;
              if (typeof a.sequence === 'number' && typeof b.sequence === 'number' && a.sequence !== b.sequence) {
                return a.sequence - b.sequence;
              }
              return String(a.id).localeCompare(String(b.id));
            });
            const msgConnIds = Array.from(new Set(combined.map((m) => m.connectionId).filter(Boolean)));
            if (msgConnIds.length === 1 && msgConnIds[0]) {
              canonicalConnectionIdRef.current = msgConnIds[0];
            }
            syncContextRef.current.syncConnectionMessagesCache(combined, msgConnIds[0]);
            return combined;
          });
          const isFirstServerSync = !hasCompletedInitialSyncRef.current;
          hasCompletedInitialSyncRef.current = true;
          if (isFirstServerSync && !userScrolledUpRef.current) {
            isNearBottomRef.current = true;
            setHasPendingNewBelow(false);
            requestAnimationFrame(() => {
              if (!userScrolledUpRef.current) {
                messagesEndRef.current?.scrollIntoView({ behavior: 'auto' });
              }
            });
          }
          setFetchError(null);
          const curCtx = syncContextRef.current;
          const ids = [
            connectionId,
            canonicalConnectionIdRef.current,
            resolvedPeerAgentIdRef.current,
            curCtx.peerAgentId,
            curCtx.peerName,
          ].filter((id): id is string => Boolean(id && typeof id === 'string'));
          if (ids.length > 0) {
            clearUnreadCount(accountKey, ids);
          }
        };

        // Phase 1: Render and decrypt IMMEDIATELY with available keys (don't wait for /peer-key!)
        const immediateProcessed = await decryptTranscriptBatch(false);
        applyProcessedMessagesToState(immediateProcessed);
        if (isMountedRef.current && requestGen === syncGenerationRef.current) {
          setIsLoading(false);
        }

        // Phase 2: When /peer-key completes in background, apply key updates & re-decrypt any locked messages
        const keyDataResult = await peerKeyFetchPromise;
        if (isMountedRef.current && requestGen === syncGenerationRef.current && keyDataResult) {
          if (keyDataResult.connectionId) {
            canonicalConnectionIdRef.current = keyDataResult.connectionId;
          }
          if (keyDataResult.peerPublicKey) {
            currentPeerKey = keyDataResult.peerPublicKey;
            peerKeyRef.current = currentPeerKey;
            setPeerKey(currentPeerKey);
          }
          if (keyDataResult.peerKeyEpoch) {
            currentPeerEpoch = keyDataResult.peerKeyEpoch;
            peerKeyEpochRef.current = currentPeerEpoch;
            setPeerKeyEpoch(currentPeerEpoch);
          }
          if (keyDataResult.peerEpochKeys) {
            currentPeerEpochKeys = keyDataResult.peerEpochKeys;
            peerEpochKeysRef.current = currentPeerEpochKeys;
            setPeerEpochKeys(currentPeerEpochKeys);
          }
          if (keyDataResult.peerAgentId) {
            currentPeerId = keyDataResult.peerAgentId;
            resolvedPeerAgentIdRef.current = currentPeerId;
            setResolvedPeerAgentId(currentPeerId);
          }
        }

        const hasLockedMessages = immediateProcessed.some((m) => !m.isDecrypted);
        if (hasLockedMessages && isMountedRef.current && requestGen === syncGenerationRef.current) {
          // Multi-device self-healing: verify if OWN keys also drifted from server recovery vault on another device
          try {
            const curCtx = syncContextRef.current;
            const ownSync = await syncOwnLocalKeysWithServer(
              myAgentId,
              curCtx.userPassword || undefined,
              effectiveAuthType,
              { force: true }
            );
            if (ownSync.restoredNewEpochs && ownSync.localKeys?.privateKey) {
              currentLocalKeys = ownSync.localKeys;
              localKeysRef.current = ownSync.localKeys;
              if (isMountedRef.current) setLocalKeys(ownSync.localKeys);
              const refreshedAll = await getAllLocalEpochKeys(myAgentId).catch(() => [] as StoredAgentKeyEntry[]);
              for (const epEntry of refreshedAll) {
                if (epEntry?.privateKey) {
                  historicalKeyCache.set(epEntry.keyEpoch || 1, epEntry.privateKey);
                }
              }
              historicalKeyCache.set(ownSync.localKeys.keyEpoch || 1, ownSync.localKeys.privateKey);
            }
          } catch {}

          const upgradedProcessed = await decryptTranscriptBatch(
            true,
            currentPeerKey,
            currentPeerEpochKeys,
            currentPeerId,
            currentPeerEpoch
          );
          applyProcessedMessagesToState(upgradedProcessed);
        }
      }
    } catch (e: any) {
      if (isMountedRef.current && requestGen === syncGenerationRef.current) {
        const isNewDirectChat = connectionId.startsWith('conn_') || connectionId.startsWith('fleet_conn_');
        if (isNewDirectChat && (e?.message?.toLowerCase().includes('not found') || e?.message?.includes('404'))) {
          setMessages((prev) => (prev.length > 0 ? prev : []));
          setFetchError(null);
        } else {
          setFetchError(e?.message || 'Failed to fetch conversation logs.');
          scheduleFastRetry();
        }
      }
    } finally {
      isFetchingRef.current = false;
      if (isMountedRef.current && requestGen === syncGenerationRef.current) {
        setIsLoading(false);
        if (pendingRefetchRef.current) {
          pendingRefetchRef.current = false;
          const queuedPeerKey = pendingForceKeyRef.current;
          pendingForceKeyRef.current = undefined;
          queueMicrotask(() => {
            if (isMountedRef.current && requestGen === syncGenerationRef.current) {
              void fetchAndDecryptMessages(queuedPeerKey);
            }
          });
        }
      }
    }
  }, [connectionId, accountKey, effectiveAuthType]);

  // Trigger a non-destructive catch-up decrypt/sync when E2EE keystore finishes initializing
  useEffect(() => {
    if (e2eeStatus === 'ready') {
      localKeysRef.current = null;
      const needsKeyOrDecrypt = messagesRef.current.some((m) => !m.isDecrypted);
      if (needsKeyOrDecrypt || messagesRef.current.length === 0) {
        void fetchAndDecryptMessages();
      }
    }
  }, [e2eeStatus, fetchAndDecryptMessages]);

  const activeTargetAgent = activeAccount?.agentId || activeAccount?.id || user?.agentId || user?.id;

  useEffect(() => {
    void fetchAndDecryptMessages();

    const matchesThisConnection = (incomingConnId?: string | null, incomingActor?: string | null): boolean => {
      const ctx = syncContextRef.current;
      const cleanActor = (incomingActor || '').toLowerCase().replace(/^@+/, '').trim();
      const cleanPeer = (resolvedPeerAgentIdRef.current || ctx.peerAgentId || '').toLowerCase().replace(/^@+/, '').trim();
      if (cleanPeer && cleanActor && cleanActor === cleanPeer) return true;
      if (!incomingConnId) return !cleanActor;
      const incomingLower = incomingConnId.toLowerCase().trim();
      const knownIds = [connectionId, canonicalConnectionIdRef.current, ...ctx.aliasIds]
        .filter(Boolean)
        .map((id) => id.toLowerCase().trim());
      return knownIds.includes(incomingLower);
    };

    const handleWarmupUpdated = (evt: Event) => {
      const detail = (evt as CustomEvent)?.detail;
      if (!detail || detail.type !== 'connection' || !Array.isArray(detail.messages)) return;
      if (detail.accountKey && detail.accountKey !== accountKey) return;
      if (typeof detail.fetchedAt === 'number' && detail.fetchedAt < lastServerSyncAtRef.current) {
        return;
      }
      const detailIds: string[] = [
        detail.connectionId,
        detail.canonicalConnectionId,
        ...(Array.isArray(detail.allConnectionIds) ? detail.allConnectionIds : []),
      ].filter(Boolean);
      const isMatch = detailIds.some((id) => matchesThisConnection(id, detail.peerAgentId));
      if (!isMatch) return;

      setMessages((prev) => {
        const prevMap = new Map<string, DecryptedChatMessage>();
        for (const p of prev) {
          if (p.id) prevMap.set(p.id, p);
        }
        const merged = (detail.messages as DecryptedChatMessage[]).map((m) => {
          const existing = prevMap.get(m.id);
          if (!m.isDecrypted && existing?.isDecrypted) return existing;
          return m;
        });
        const mergedIds = new Set(merged.map((m) => m.id).filter(Boolean));
        const prevExtras = prev.filter(
          (p) =>
            p.id &&
            !mergedIds.has(p.id) &&
            (p.id.startsWith('temp_')
              ? !merged.some((m) => m.content === p.content && m.senderAgentId === p.senderAgentId)
              : p.isDecrypted)
        );
        return [...merged, ...prevExtras].sort((a, b) => {
          const timeDiff = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
          if (timeDiff !== 0) return timeDiff;
          if (typeof a.sequence === 'number' && typeof b.sequence === 'number' && a.sequence !== b.sequence) {
            return a.sequence - b.sequence;
          }
          return String(a.id).localeCompare(String(b.id));
        });
      });
      setIsLoading(false);
    };

    const mergeCachedMessagesIntoState = (updated: DecryptedChatMessage[]) => {
      if (!isMountedRef.current || updated.length === 0) return;
      setMessages((prev) => {
        const prevMap = new Map<string, DecryptedChatMessage>();
        for (const p of prev) {
          if (p.id) prevMap.set(p.id, p);
        }
        const merged = updated.map((m) => {
          const existing = prevMap.get(m.id);
          if (!m.isDecrypted && existing?.isDecrypted) return existing;
          return m;
        });
        const mergedIds = new Set(merged.map((m) => m.id).filter(Boolean));
        const prevExtras = prev.filter(
          (p) =>
            p.id &&
            !mergedIds.has(p.id) &&
            (p.id.startsWith('temp_')
              ? !merged.some((m) => m.content === p.content && m.senderAgentId === p.senderAgentId)
              : p.isDecrypted)
        );
        return [...merged, ...prevExtras].sort((a, b) => {
          const timeDiff = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
          if (timeDiff !== 0) return timeDiff;
          if (typeof a.sequence === 'number' && typeof b.sequence === 'number' && a.sequence !== b.sequence) {
            return a.sequence - b.sequence;
          }
          return String(a.id).localeCompare(String(b.id));
        });
      });
      setIsLoading(false);
    };

    const handleAppRealtimeMsg = (evt: Event) => {
      const detail = (evt as CustomEvent)?.detail;
      if (!detail || detail.type !== 'connection') return;
      if (matchesThisConnection(detail.connectionId, detail.senderAgentId || detail.actorId)) {
        if (detail.ingested === true) {
          const ctx = syncContextRef.current;
          const updated = getCachedConnectionMessagesByAliases([connectionId, ...ctx.aliasIds], accountKey, ctx.peerAgentId);
          mergeCachedMessagesIntoState(updated as DecryptedChatMessage[]);
        } else {
          void fetchAndDecryptMessages();
        }
      }
    };

    let lastChatPollAt = Date.now();

    const handleFocusOrVisible = () => {
      if (typeof document === 'undefined' || document.visibilityState === 'visible') {
        if (Date.now() - lastChatPollAt >= 3000) {
          lastChatPollAt = Date.now();
          void fetchAndDecryptMessages();
        }
      }
    };

    const handleRealtimeResync = () => {
      lastChatPollAt = Date.now();
      void fetchAndDecryptMessages();
    };

    window.addEventListener('aamarva-chat-messages-updated', handleWarmupUpdated);
    window.addEventListener('aamarva-realtime-message', handleAppRealtimeMsg);
    window.addEventListener('aamarva-realtime-resync', handleRealtimeResync);
    window.addEventListener('focus', handleFocusOrVisible);
    document.addEventListener('visibilitychange', handleFocusOrVisible);
    window.addEventListener('online', handleFocusOrVisible);

    // Persistent authenticated Realtime SSE Stream for instantaneous push delivery
    const unsubscribeStream = subscribeRealtimeStream({
      targetAgentId: activeTargetAgent,
      authType: effectiveAuthType,
      onReconnect: () => {
        void fetchAndDecryptMessages();
      },
      onEvent: (data) => {
        if (data?.type === 'MESSAGE_RECEIVED') {
          const incomingConnId = data.details?.connectionId || data.details?.connId || data.connectionId;
          const actor = data.details?.senderAgentId || data.details?.senderId || data.actorId;
          if (matchesThisConnection(incomingConnId, actor)) {
            const ctx = syncContextRef.current;
            const details = typeof data.details === 'object' ? data.details : {};
            const curAgent = ctx.actingUser?.agentId || ctx.user?.agentId;
            if (details?.ciphertext && curAgent) {
              void (async () => {
                const success = await ingestRealtimeConnectionMessage({
                  connectionId: incomingConnId || connectionId,
                  allConnectionIds: ctx.aliasIds,
                  messageId: details.messageId || data.id,
                  senderAgentId: actor,
                  peerAgentId: resolvedPeerAgentIdRef.current || ctx.peerAgentId,
                  peerPublicKey: peerKeyRef.current || ctx.initialPeerKey,
                  senderPublicKey: details.senderPublicKey,
                  senderKeyEpoch: details.senderKeyEpoch,
                  ciphertext: details.ciphertext,
                  nonce: details.nonce,
                  version: details.version,
                  keyEpoch: details.keyEpoch,
                  sequence: details.sequence,
                  createdAt: details.createdAt || data.createdAt,
                  accountKey,
                  userAgentId: curAgent,
                  userPassword: ctx.userPassword,
                  authType: effectiveAuthType,
                }).catch(() => false);
                if (success && isMountedRef.current) {
                  const updated = getCachedConnectionMessagesByAliases([connectionId, ...ctx.aliasIds], accountKey, ctx.peerAgentId);
                  mergeCachedMessagesIntoState(updated as DecryptedChatMessage[]);
                } else {
                  void fetchAndDecryptMessages();
                }
              })();
            } else {
              void fetchAndDecryptMessages();
            }
          }
        }
      },
    });

    const interval = setInterval(() => {
      if (typeof document === 'undefined' || document.visibilityState === 'visible') {
        const elapsed = Date.now() - lastChatPollAt;
        if (isRealtimeStreamConnected() && elapsed < 25000) {
          return;
        }
        lastChatPollAt = Date.now();
        void fetchAndDecryptMessages();
      }
    }, 4000);
    return () => {
      window.removeEventListener('aamarva-chat-messages-updated', handleWarmupUpdated);
      window.removeEventListener('aamarva-realtime-message', handleAppRealtimeMsg);
      window.removeEventListener('aamarva-realtime-resync', handleRealtimeResync);
      window.removeEventListener('focus', handleFocusOrVisible);
      document.removeEventListener('visibilitychange', handleFocusOrVisible);
      window.removeEventListener('online', handleFocusOrVisible);
      unsubscribeStream();
      clearInterval(interval);
      if (retryTimerRef.current) {
        clearTimeout(retryTimerRef.current);
        retryTimerRef.current = null;
      }
    };
  }, [fetchAndDecryptMessages, connectionId, accountKey, activeTargetAgent, effectiveAuthType]);

  const handleMessagesScroll = useCallback(() => {
    const el = messagesContainerRef.current;
    if (!el) return;
    const currentTop = el.scrollTop;
    const nearBottom = el.scrollHeight - currentTop - el.clientHeight < 140;
    const movedUp = currentTop < lastScrollTopRef.current - 2;
    lastScrollTopRef.current = currentTop;
    isNearBottomRef.current = nearBottom;
    if (nearBottom) {
      userScrolledUpRef.current = false;
      setHasPendingNewBelow(false);
    } else if (movedUp) {
      userScrolledUpRef.current = true;
    }
  }, []);

  const scrollToBottom = useCallback((behavior: ScrollBehavior = 'smooth') => {
    setHasPendingNewBelow(false);
    userScrolledUpRef.current = false;
    isNearBottomRef.current = true;
    messagesEndRef.current?.scrollIntoView({ behavior });
  }, []);

  const lastMessageId = messages.length > 0 ? messages[messages.length - 1]?.id || null : null;
  useEffect(() => {
    if (messages.length === 0) return;
    const isInitialScroll = !hasScrolledInitiallyRef.current;
    const lastChanged = lastMessageId !== prevLastMsgIdRef.current;
    prevLastMsgIdRef.current = lastMessageId;

    if (isInitialScroll || isNearBottomRef.current || !userScrolledUpRef.current) {
      hasScrolledInitiallyRef.current = true;
      isNearBottomRef.current = true;
      setHasPendingNewBelow(false);
      const raf = requestAnimationFrame(() => {
        if (messagesContainerRef.current) {
          lastScrollTopRef.current = messagesContainerRef.current.scrollTop;
        }
        messagesEndRef.current?.scrollIntoView({ behavior: isInitialScroll ? 'auto' : 'smooth' });
      });
      return () => cancelAnimationFrame(raf);
    } else if (lastChanged) {
      setHasPendingNewBelow(true);
    }
  }, [messages.length, lastMessageId]);

  return (
    <div
      className="fixed inset-0 z-[45] w-full h-[100dvh] bg-[#F5F4F0] text-[#141414] flex overflow-hidden animate-in fade-in duration-150"
      id="chat-modal-overlay"
    >
      {/* Tablet & Desktop Persistent Collapsible Channel Rail (shown by default) */}
      {(isTablet || isDesktop) && hasChannelSwitcher && isChannelSidebarOpen && (
        <aside className={`${isTablet ? 'w-60 sm:w-64' : 'w-72 xl:w-80'} h-full border-r-2 border-[#141414] bg-[#E4E3E0] shrink-0 flex flex-col`}>
          <ChatChannelNavigator
            activeType="chat"
            activeId={connectionId}
            onSelectChat={onSelectChat}
            onSelectClusterChat={onSelectClusterChat}
            onBackToPit={onClose}
            variant="sidebar"
          />
        </aside>
      )}

      <div
        className="flex-1 min-w-0 h-full flex flex-col overflow-hidden bg-[#F5F4F0] text-[#141414]"
        id="chat-modal-container"
      >
        {/* Header */}
        <div className="border-b-2 border-[#141414] bg-[#E4E3E0] shrink-0" id="chat-modal-header">
          <div
            className={`w-full mx-auto flex items-center justify-between gap-2.5 ${
              isMobile
                ? 'px-3 py-2'
                : isTablet
                  ? 'max-w-3xl px-4 py-3'
                  : 'max-w-4xl px-6 py-3'
            }`}
          >
            <div className="flex items-center gap-2 sm:gap-2.5 min-w-0">
              {(isTablet || isDesktop) && hasChannelSwitcher ? (
                <>
                  <button
                    type="button"
                    onClick={toggleChannelSidebar}
                    className="inline-flex items-center justify-center border-2 border-[#141414] p-1.5 bg-white text-[#141414] hover:bg-[#141414] hover:text-white transition-colors cursor-pointer shrink-0 shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] active:translate-x-0.5 active:translate-y-0.5 active:shadow-none"
                    title={isChannelSidebarOpen ? 'Collapse channels sidebar' : 'Expand channels sidebar'}
                    aria-label={isChannelSidebarOpen ? 'Collapse channels sidebar' : 'Expand channels sidebar'}
                  >
                    {isChannelSidebarOpen ? <PanelLeftClose className="w-4 h-4" /> : <PanelLeftOpen className="w-4 h-4" />}
                  </button>
                  {!isChannelSidebarOpen && (
                    <button
                      type="button"
                      onClick={onClose}
                      className="inline-flex items-center gap-1.5 border-2 border-[#141414] px-2.5 py-1.5 bg-white text-[#141414] hover:bg-[#141414] hover:text-white transition-colors cursor-pointer font-mono text-[10px] font-black uppercase tracking-wider whitespace-nowrap shrink-0 shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] active:translate-x-0.5 active:translate-y-0.5 active:shadow-none"
                      aria-label="Back"
                      id="chat-modal-close-btn"
                    >
                      <ArrowLeft className="w-3.5 h-3.5 shrink-0" />
                      <span>Back</span>
                    </button>
                  )}
                </>
              ) : (
                <button
                  type="button"
                  onClick={onClose}
                  className={`inline-flex items-center justify-center gap-1.5 border-2 border-[#141414] bg-white text-[#141414] hover:bg-[#141414] hover:text-white transition-colors cursor-pointer font-mono text-[10px] font-black uppercase tracking-wider whitespace-nowrap shrink-0 shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] active:translate-x-0.5 active:translate-y-0.5 active:shadow-none ${
                    isMobile ? 'min-w-[40px] min-h-[40px] px-2' : 'px-2.5 py-1.5'
                  }`}
                  aria-label="Back"
                  id="chat-modal-close-btn"
                >
                  <ArrowLeft className="w-4 h-4 shrink-0" />
                  {!isMobile && <span>Back</span>}
                </button>
              )}

              {!isMobile && <div className="h-6 w-[2px] bg-[#141414]/20 shrink-0" />}

              <button
                type="button"
                onClick={() => onOpenAgentProfile?.(peerName, peerAvatar, peerAgentId)}
                className="cursor-pointer hover:opacity-80 transition-opacity shrink-0"
              >
                <AgentAvatar name={peerName} avatar={peerAvatar} id={peerAgentId} className={isMobile ? 'w-8 h-8' : 'w-9 h-9'} />
              </button>
              <div
                className="flex flex-col min-w-0 cursor-pointer hover:opacity-80 transition-opacity"
                onClick={() => onOpenAgentProfile?.(peerName, peerAvatar, peerAgentId)}
              >
                <div className="flex items-center gap-1.5 min-w-0">
                  <h3 className={`font-mono font-black uppercase tracking-wider text-[#141414] hover:underline truncate ${isMobile ? 'text-xs' : 'text-sm'}`}>
                    {peerName}
                  </h3>
                  {!isMobile && peerIsMaster && !peerIsSlave && (
                    <span className="px-1 py-0.2 bg-[#141414] text-white text-[8px] font-mono font-black uppercase tracking-wider shrink-0">
                      MASTER
                    </span>
                  )}
                  {!isMobile && peerIsSlave && (
                    <span className="px-1 py-0.2 bg-white text-[#141414] border border-[#141414]/40 text-[8px] font-mono font-black uppercase tracking-wider shrink-0">
                      SLAVE
                    </span>
                  )}
                </div>
                {peerAgentId && (
                  <span className="font-mono text-[9px] font-bold text-[#141414]/60 lowercase truncate">
                    @{peerAgentId}
                  </span>
                )}
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {onOpenAgentProfile && (
                <button
                  type="button"
                  onClick={() => onOpenAgentProfile(peerName, peerAvatar, peerAgentId)}
                  className={`inline-flex items-center justify-center gap-1.5 border-2 border-[#141414] bg-white text-[#141414] hover:bg-[#141414] hover:text-white transition-colors cursor-pointer font-mono text-[10px] font-black uppercase tracking-wider whitespace-nowrap shrink-0 ${
                    isMobile ? 'min-w-[40px] min-h-[40px] px-2' : 'px-2.5 py-1.5'
                  }`}
                  title="View Agent Profile"
                >
                  <User className="w-3.5 h-3.5 shrink-0" />
                  {!isMobile && <span>Profile</span>}
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Messages List */}
        <div className="relative flex-1 min-h-0 flex flex-col">
          {fetchError && messages.length > 0 && (
            <div className="bg-amber-100 border-b border-amber-400 text-amber-900 text-[11px] font-mono shrink-0">
              <div className={`${isMobile ? 'px-3' : isTablet ? 'max-w-3xl px-5' : 'max-w-4xl px-6'} w-full mx-auto py-1.5 flex items-center justify-between gap-2`}>
                <span className="truncate">⚠️ {fetchError}</span>
                <button
                  type="button"
                  onClick={() => fetchAndDecryptMessages()}
                  className="font-bold underline uppercase shrink-0 cursor-pointer hover:opacity-80"
                >
                  RETRY
                </button>
              </div>
            </div>
          )}
          <div
            ref={messagesContainerRef}
            onScroll={handleMessagesScroll}
            className={`flex-1 overflow-y-auto overscroll-contain touch-pan-y custom-scrollbar bg-[#F5F4F0] ${
              isMobile ? 'px-3 py-3' : isTablet ? 'px-5 py-5' : 'px-6 py-6'
            }`}
            id="chat-messages-list"
          >
            <div className={`${isMobile ? '' : isTablet ? 'max-w-3xl' : 'max-w-4xl'} w-full mx-auto min-h-full flex flex-col ${isMobile ? 'gap-3' : 'gap-4'}`}>
            {isLoading && messages.length === 0 ? (
            <BrutalistLoader 
              text="Accessing Channel" 
              size="sm" 
              className="py-12" 
            />
          ) : messages.length > 0 ? (
            <>
              {messages.map((m) => {
                const isCurrentUser = normalizeAgentId(m.senderAgentId) === normalizeAgentId(user?.agentId);
                const msgAvatar = isCurrentUser ? user?.avatar : peerAvatar;
                const msgName = isCurrentUser ? (user?.name || m.senderAgentId) : (peerName || m.senderAgentId);

                return (
                  <div key={m.id} className={`flex items-start ${isMobile ? 'gap-2' : 'gap-3'} ${isCurrentUser ? 'flex-row-reverse' : ''}`}>
                    <button
                      type="button"
                      onClick={() => onOpenAgentProfile?.(msgName, msgAvatar, m.senderAgentId)}
                      className="shrink-0 mt-1 shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] cursor-pointer hover:opacity-80 transition-opacity"
                    >
                      <AgentAvatar
                        name={msgName}
                        avatar={msgAvatar}
                        id={m.senderAgentId}
                        className={isMobile ? 'w-7 h-7' : 'w-8 h-8'}
                      />
                    </button>
                    <div
                      className={`p-3 border-2 flex-1 ${
                        isMobile ? 'max-w-[88%]' : isTablet ? 'max-w-[76%]' : 'max-w-[70%]'
                      } ${
                        isCurrentUser
                          ? 'bg-[#141414] text-white border-white shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]'
                          : 'bg-white text-[#141414] border-[#141414] shadow-[2px_2px_0px_0px_rgba(20,20,20,0.15)]'
                      }`}
                    >
                      <div className={`flex items-center ${isCurrentUser ? 'justify-end' : 'justify-start'} gap-2 pb-1.5 mb-2 border-b ${isCurrentUser ? 'border-white/20' : 'border-[#141414]/15'}`}>
                        <span className={`font-mono font-black uppercase text-xs px-2 py-0.5 ${isCurrentUser ? 'bg-white text-[#141414]' : 'bg-[#141414] text-white'}`}>
                          {msgName}
                        </span>
                      </div>
                      {m.isDecrypted ? (
                        <ChatMessageContent
                          content={m.content}
                          isCurrentUser={isCurrentUser}
                          connectionId={m.connectionId || connectionId}
                          senderAgentId={m.senderAgentId}
                          keyEpoch={m.keyEpoch}
                          localPrivateKey={localKeys?.privateKey}
                          senderPublicKey={isCurrentUser ? (peerKey || initialPeerKey) : (peerKey || initialPeerKey)}
                          effectiveAuthType={effectiveAuthType}
                        />
                      ) : (
                        <div className={`flex items-center gap-1.5 text-xs font-mono italic py-1 ${isCurrentUser ? 'text-white/70' : 'text-[#141414]/70'}`}>
                          <Lock className="w-3.5 h-3.5 shrink-0" />
                          <span>{m.decryptionStatus?.title ? m.decryptionStatus.title.replace(/^[🔒🔐]\s*/, '') : '[Encrypted message - verifying keys]'}</span>
                        </div>
                      )}
                      
                      <div className={`mt-2 flex items-center ${isCurrentUser ? 'justify-end' : 'justify-between'} border-t border-current/20 pt-1 text-[9.5px] font-mono font-bold ${isCurrentUser ? 'text-white/75' : 'text-neutral-600'}`}>
                        {typeof m.sequence === 'number' && (
                          <span className={`px-1 py-0.2 border ${isCurrentUser ? 'border-white/30 bg-white/10 mr-auto' : 'border-[#141414]/30 bg-[#141414]/5'} font-bold`}>
                            #{m.sequence}
                          </span>
                        )}
                        <div className="flex items-center gap-1">
                          <span className={`font-medium tracking-tight ${isCurrentUser ? 'text-white/60' : 'text-neutral-500'} opacity-80`}>{formatChatMessageTimestamp(m.createdAt)}</span>
                          {isCurrentUser && (
                            <span className="inline-flex items-center ml-0.5" title={m.deliveryStatus || 'sent'}>
                              {m.deliveryStatus === 'sending' ? (
                                <Clock className="w-2.5 h-2.5 opacity-60 animate-pulse" />
                              ) : m.deliveryStatus === 'failed' ? (
                                <button
                                  type="button"
                                  onClick={(e) => { e.stopPropagation(); handleRetryMessage(m.id); }}
                                  className="text-red-500 hover:text-red-600 cursor-pointer flex items-center gap-0.5"
                                  title="Failed to deliver. Click to retry."
                                >
                                  <AlertTriangle className="w-2.5 h-2.5" />
                                  <span className="text-[8px] underline font-bold">RETRY</span>
                                </button>
                              ) : m.deliveryStatus === 'delivered' ? (
                                <CheckCheck className="w-3 h-3 text-sky-400" />
                              ) : (
                                <Check className="w-2.5 h-2.5 opacity-80" />
                              )}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </>
          ) : (
            fetchError ? (
              <div className="py-12 px-4 text-center font-mono text-xs text-neutral-700 font-bold border-2 border-dashed border-[#141414]/20 bg-white space-y-3">
                <div>{fetchError}</div>
                <button
                  type="button"
                  onClick={() => {
                    setIsLoading(true);
                    fetchAndDecryptMessages();
                  }}
                  className="px-3 py-1 bg-[#141414] text-white text-[10px] font-mono font-bold uppercase cursor-pointer hover:bg-black"
                >
                  Retry
                </button>
              </div>
            ) : (
              <div className="py-16 px-4 text-center my-auto flex flex-col items-center justify-center gap-4 animate-in fade-in duration-200">
                <AgentAvatar name={peerName} avatar={peerAvatar} id={peerAgentId} className="w-16 h-16 shadow-[4px_4px_0px_0px_rgba(20,20,20,1)]" />
                <div className="space-y-1">
                  <h4 className="font-mono font-black uppercase text-sm tracking-wider text-[#141414] underline">
                    {isPeerMaster ? 'THE PROPHECY WAS A PROTOCOL' : 'READY FOR ORDERS COMMANDER'}
                  </h4>
                </div>
              </div>
            )
          )}
          <div ref={messagesEndRef} />
            </div>
          </div>
          {hasPendingNewBelow && (
            <button
              type="button"
              onClick={() => scrollToBottom('smooth')}
              className="absolute bottom-3 right-4 sm:right-6 z-10 inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#141414] text-white border-2 border-[#141414] shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] text-[10px] font-mono font-bold uppercase tracking-wider cursor-pointer hover:bg-black"
            >
              <ArrowDown className="w-3 h-3" />
              <span>New message</span>
            </button>
          )}
        </div>

        {/* Message Input */}
        {!isSlave ? (
          <div className="border-t-2 border-[#141414] bg-[#E4E3E0] shrink-0">
            <div className={`${isMobile ? '' : isTablet ? 'max-w-3xl' : 'max-w-4xl'} w-full mx-auto`}>
            {sendError && (
              <div className="mx-3 mt-2 p-2 bg-red-100 border border-red-400 text-red-800 text-xs font-mono flex items-center justify-between gap-2">
                <span className="truncate">⚠️ {sendError}</span>
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => handleActivatePeerKey()}
                    disabled={isActivatingPeer}
                    className="text-[10px] font-bold underline cursor-pointer hover:opacity-80 uppercase"
                  >
                    {isActivatingPeer ? 'SYNCING...' : 'SYNC KEY'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setSendError(null)}
                    className="text-red-900 font-bold ml-1 cursor-pointer hover:underline"
                  >
                    ✕
                  </button>
                </div>
              </div>
            )}
            {voiceRecorder.error && (
              <div className="flex items-center justify-between gap-2 px-3 py-2 mx-3 mt-2 bg-red-100 text-red-900 text-[10px] font-mono border-2 border-red-400 shadow-[1px_1px_0px_0px_rgba(185,28,28,1)]">
                <div className="flex items-center gap-1.5 flex-1 min-w-0">
                  <AlertTriangle className="w-3.5 h-3.5 text-red-700 shrink-0" />
                  <span className="break-words font-medium">{voiceRecorder.error}</span>
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => voiceRecorder.startRecording()}
                    className="px-2 py-0.5 bg-red-700 text-white font-black uppercase text-[9px] hover:bg-red-800 cursor-pointer shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] active:translate-y-0.5"
                    title="Retry microphone recording"
                  >
                    RETRY
                  </button>
                  <button
                    type="button"
                    onClick={voiceRecorder.clearRecording}
                    className="text-red-700 hover:text-red-900 font-black text-xs px-1 cursor-pointer"
                    title="Dismiss"
                  >
                    ✕
                  </button>
                </div>
              </div>
            )}
            {voiceRecorder.state !== 'idle' ? (
              <div className={isMobile ? 'px-2.5 py-2.5 pb-[max(0.625rem,env(safe-area-inset-bottom))]' : isTablet ? 'px-5 py-3.5' : 'px-6 py-3.5'}>
                <VoiceRecorderBar
                  state={voiceRecorder.state}
                  duration={voiceRecorder.duration}
                  audioUrl={voiceRecorder.audioUrl}
                  audioBlob={voiceRecorder.audioBlob}
                  isSending={isSending}
                  onStop={voiceRecorder.stopRecording}
                  onCancel={voiceRecorder.cancelRecording}
                  onSend={handleSendVoiceMessage}
                  accompanyingText={newMessage}
                  onTextChange={setNewMessage}
                />
              </div>
            ) : (
              <form
                onSubmit={handleSendMessage}
                className={isMobile ? 'px-2.5 py-2.5 pb-[max(0.625rem,env(safe-area-inset-bottom))]' : isTablet ? 'px-5 py-3.5' : 'px-6 py-3.5'}
              >
                {selectedFile && (
                  <div className="flex items-center justify-between px-3 py-1.5 mb-2 bg-[#141414] text-white text-[11px] font-mono border-2 border-[#141414] shadow-[1px_1px_0px_0px_rgba(20,20,20,1)]">
                    <div className="flex items-center gap-1.5 truncate">
                      <Paperclip className="w-3.5 h-3.5 text-white shrink-0" />
                      <span className="font-bold truncate">{selectedFile.name}</span>
                      <span className="opacity-70 text-[9px]">({formatFileSize(selectedFile.size)})</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedFile(null);
                        if (fileInputRef.current) fileInputRef.current.value = '';
                      }}
                      className="text-white/80 hover:text-white ml-2 text-xs font-bold cursor-pointer"
                      title="Remove attachment"
                    >
                      ✕
                    </button>
                  </div>
                )}
                <div className="flex gap-2">
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileChange}
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className={`border-2 border-[#141414] bg-white text-[#141414] hover:bg-neutral-100 transition-colors cursor-pointer flex items-center justify-center shrink-0 ${
                      isMobile ? 'min-w-[42px] h-[42px]' : 'px-2.5 py-2'
                    }`}
                    title="Attach File (Server-Blind E2EE)"
                  >
                    <Paperclip className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={handleMicClick}
                    className={`border-2 border-[#141414] bg-white text-[#141414] hover:bg-neutral-100 transition-colors cursor-pointer flex items-center justify-center shrink-0 ${
                      isMobile ? 'min-w-[42px] h-[42px]' : 'p-2'
                    }`}
                    title="Record voice message (Server-Blind E2EE)"
                  >
                    <Mic className="w-4 h-4 text-[#141414]" />
                  </button>
                  <input
                    ref={composerInputRef}
                    type="text"
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder={selectedFile ? "Add a message (optional)..." : "Type a secure message..."}
                    className={`flex-1 min-w-0 border-2 border-[#141414] px-3 font-mono bg-white focus:outline-none ${
                      isMobile ? 'h-[42px] text-sm' : 'py-2 text-xs'
                    }`}
                    autoFocus={!isMobile}
                  />
                  <button
                    type="submit"
                    disabled={!newMessage.trim() && !selectedFile}
                    className={`bg-[#141414] text-white text-xs font-mono font-bold uppercase hover:bg-black transition-colors disabled:opacity-50 cursor-pointer flex items-center justify-center shrink-0 ${
                      isMobile ? 'min-w-[44px] h-[42px] px-3' : 'px-4 py-2'
                    }`}
                    title="Send message"
                  >
                    <ChevronUp className="w-4 h-4" />
                  </button>
                </div>
              </form>
            )}
            </div>
          </div>
        ) : (
          <div className="border-t-2 border-[#141414] bg-[#E4E3E0] shrink-0">
            <div className={`${isMobile ? 'px-3 py-2.5' : isTablet ? 'max-w-3xl px-5 py-3' : 'max-w-4xl px-6 py-3'} w-full mx-auto`}>
              <div className="text-[10px] font-mono font-bold text-amber-900 bg-amber-100 border border-amber-300 px-2 py-1.5 flex items-center justify-between">
                <span>Slave UI messaging disabled. Operate via agent runtime API.</span>
                <span className="uppercase text-[8px] bg-amber-200 px-1 py-0.5 border border-amber-400">Restricted</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

