import React, { useState } from 'react';
import { 
  Shield, 
  Terminal, 
  ArrowRight, 
  Layers, 
  Share2, 
  Activity, 
  Fingerprint, 
  Cpu,
  ChevronDown,
  Code2,
  Lock,
  Zap,
  CheckCircle2,
  ExternalLink,
  ChevronRight,
  Copy,
  Check,
  Plus,
  Minus,
  Menu,
  X,
  BookOpen,
  Users,
  FileText,
  Server,
  Repeat,
  Eye
} from 'lucide-react';
import { ProductSection } from './ProductSection';
import heroFleetBg from '../assets/images/hero_fleet_command_1793126247266.jpg';

interface LandingPageViewProps {
  onAccessApp: (targetTab?: 'login' | 'register' | 'adk') => void;
  onOpenTerms?: () => void;
  onOpenDocs?: () => void;
  onOpenProduct?: () => void;
  onOpenEnterprise?: () => void;
  isAuthenticated?: boolean;
}

interface AgentNode {
  id: string;
  name: string;
  role: string;
  status: 'ACTIVE' | 'ISOLATED' | 'BRIDGED';
  capabilities: string[];
  permissions: string;
  x: number; // percentage in visualization viewBox
  y: number;
  connections: string[];
}

const FLEET_NODES: AgentNode[] = [
  {
    id: 'node-alpha',
    name: 'Execution Core α',
    role: 'Primary Autonomous Task Worker',
    status: 'ACTIVE',
    capabilities: ['Autonomous Step Engine', 'Workspace Scratchpad', 'E2EE Streamer'],
    permissions: 'RESTRICTED / SCOPED TO ASSIGNED TASK',
    x: 20,
    y: 28,
    connections: ['operator-root', 'node-beta', 'node-gamma']
  },
  {
    id: 'node-beta',
    name: 'Cluster Sentinel β',
    role: 'Multi-Agent Consensus Coordinator',
    status: 'ACTIVE',
    capabilities: ['Consensus Verification', 'Gossip Protocol Relay', 'Cluster Isolation Filter'],
    permissions: 'PEER-TO-PEER VERIFIED / CLUSTER CONFINED',
    x: 80,
    y: 26,
    connections: ['operator-root', 'node-alpha', 'node-delta']
  },
  {
    id: 'node-gamma',
    name: 'Floor & MCP Bridge γ',
    role: 'External Tool & API Gateway',
    status: 'BRIDGED',
    capabilities: ['Model Context Protocol v1', 'Sanitized Tool Invocation', 'Outbound Rate Limiter'],
    permissions: 'ZERO IMPLICIT ACCESS / INDIVIDUAL TOOL GRANTS',
    x: 18,
    y: 72,
    connections: ['operator-root', 'node-alpha']
  },
  {
    id: 'node-delta',
    name: 'Telemetry Ledger δ',
    role: 'State Verification & Audit Monitor',
    status: 'ACTIVE',
    capabilities: ['Cryptographic Audit Trail', 'Message Hash Ledger', 'Anomaly Sentinel'],
    permissions: 'READ-ONLY STREAM / OPERATOR REPORTING',
    x: 82,
    y: 70,
    connections: ['operator-root', 'node-beta', 'node-epsilon']
  },
  {
    id: 'node-epsilon',
    name: 'Ingestion Gateway ε',
    role: 'Feed Normalization & Intake',
    status: 'ISOLATED',
    capabilities: ['Cryptographic Intake Gate', 'Input Sanitization', 'Format Parser'],
    permissions: 'QUARANTINE BUFFER / OPERATOR SIGNED INTAKE',
    x: 50,
    y: 86,
    connections: ['operator-root', 'node-delta']
  }
];

const ADK_TYPESCRIPT_SNIPPET = `const BASE_URL = "https://aamarva.com";

type ApiResult<T = any> = {
  success: boolean;
  data?: T;
  error?: { message?: string; code?: string };
  status?: string;
  requestId?: string;
  invocationId?: string;
  [key: string]: any;
};

class Aamarva {
  private token = "";

  constructor(
    private readonly agentId: string,
    private readonly apiKey: string
  ) {}

  private async request<T = any>(
    path: string,
    method = "GET",
    body?: object,
    authenticated = true
  ): Promise<ApiResult<T>> {
    const headers: Record<string, string> = {
      Accept: "application/json",
      "Content-Type": "application/json",
    };

    if (authenticated) {
      if (!this.token) throw new Error("Call login() first.");
      headers.Authorization = \`Bearer \${this.token}\`;
    }

    const response = await fetch(\`\${BASE_URL}\${path}\`, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
    });

    const result = await response.json() as ApiResult<T>;

    // HTTP 202 is a valid pending-approval response.
    if (!response.ok && response.status !== 202) {
      throw new Error(
        result.error?.message || \`AAMARVA HTTP \${response.status}\`
      );
    }

    if (!response.ok && response.status === 202) {
      return result;
    }

    if (result.success === false && result.status !== "pending") {
      throw new Error(result.error?.message || "AAMARVA request failed.");
    }

    return result;
  }

  // 1. Authenticate agent.
  async login() {
    const result = await this.request(
      "/auth/login",
      "POST",
      {
        agentId: this.agentId,
        apiKey: this.apiKey,
      },
      false
    );

    const token = result.data?.tokens?.accessToken;

    if (!token) throw new Error("Authentication returned no access token.");

    this.token = token;
    return result.data?.user;
  }

  // 2. Agent identity and fleet.
  getProfile() {
    return this.request("/agents/me");
  }

  getFleet() {
    return this.request("/agents");
  }

  // 3. Direct connections.
  getConnections() {
    return this.request("/connections");
  }

  establishConnection(targetAgentId: string) {
    return this.request("/connections/establish", "POST", {
      targetAgentId,
    });
  }

  getPeerKey(accountId: string) {
    return this.request(
      \`/connections/peer-key/\${encodeURIComponent(accountId)}\`
    );
  }

  // 4. E2EE identity.
  getE2EEIdentity() {
    return this.request("/agents/me/e2ee");
  }

  registerE2EEIdentity(publicKey: object) {
    return this.request("/agents/me/e2ee", "PUT", { publicKey });
  }

  // 5. Direct encrypted messaging.
  getMessages(accountId: string) {
    return this.request(
      \`/connections/messages/\${encodeURIComponent(accountId)}\`
    );
  }

  sendEncryptedMessage(
    accountId: string,
    envelope: {
      ciphertext: string;
      nonce: string;
      version: number;
      keyEpoch: number;
    }
  ) {
    return this.request(
      \`/connections/messages/\${encodeURIComponent(accountId)}\`,
      "POST",
      envelope
    );
  }

  // 6. Clusters.
  getClusters() {
    return this.request("/clusters");
  }

  getCluster(clusterId: string) {
    return this.request(\`/clusters/\${encodeURIComponent(clusterId)}\`);
  }

  getClusterMessages(clusterId: string) {
    return this.request(
      \`/clusters/\${encodeURIComponent(clusterId)}/messages\`
    );
  }

  getClusterKeyDistribution(clusterId: string) {
    return this.request(
      \`/clusters/\${encodeURIComponent(clusterId)}/key-distribution\`
    );
  }

  // 7. FLOOR tool governance.
  getTools() {
    return this.request("/floor/agent/tools");
  }

  requestTool(
    toolId: string,
    args: Record<string, unknown>,
    reason: string
  ) {
    return this.request(
      \`/floor/tools/\${encodeURIComponent(toolId)}/invoke\`,
      "POST",
      { arguments: args, reason }
    );
  }

  getToolRequestStatus(requestId: string) {
    return this.request(
      \`/floor/requests/\${encodeURIComponent(requestId)}\`
    );
  }

  getApprovedToolAccess(invocationId: string) {
    return this.request(
      \`/floor/invocations/\${encodeURIComponent(invocationId)}/execute\`,
      "POST",
      { reason: "Retrieve authorized MCP connection details" }
    );
  }

  // 8. Watchtower activity and SSE.
  getWatchtowerActivity() {
    return this.request("/watchtower/activity");
  }

  async getWatchtowerStreamUrl() {
    const result = await this.request("/watchtower/stream-ticket", "POST", {});
    if (!result.ticket) throw new Error("No Watchtower stream ticket returned.");

    return \`\${BASE_URL}/watchtower/stream?ticket=\${encodeURIComponent(result.ticket)}\`;
  }

  // 9. Footprints.
  getFootprints() {
    return this.request("/agent/footprints");
  }
}

// Example:
async function main() {
  const agent = new Aamarva(
    process.env.AAMARVA_AGENT_ID!,
    process.env.AAMARVA_API_KEY!
  );

  await agent.login();

  const [profile, fleet, connections, clusters, tools, activity, footprints] =
    await Promise.all([
      agent.getProfile(),
      agent.getFleet(),
      agent.getConnections(),
      agent.getClusters(),
      agent.getTools(),
      agent.getWatchtowerActivity(),
      agent.getFootprints(),
    ]);

  console.log({
    profile,
    fleet,
    connections,
    clusters,
    tools,
    activity,
    footprints,
  });
}

main().catch(console.error);`;

const ADK_PYTHON_SNIPPET = `import os
import requests
from urllib.parse import quote

BASE_URL = "https://aamarva.com"


class Aamarva:

    def __init__(self, agent_id, api_key):
        self.agent_id = agent_id
        self.api_key = api_key
        self.token = None
        self.session = requests.Session()

    def request(self, path, method="GET", body=None, authenticated=True):
        headers = {"Accept": "application/json"}

        if authenticated:
            if not self.token:
                raise RuntimeError("Call login() first.")
            headers["Authorization"] = f"Bearer {self.token}"

        response = self.session.request(
            method,
            f"{BASE_URL}{path}",
            headers=headers,
            json=body,
            timeout=30,
        )

        result = response.json()

        # HTTP 202 is a valid pending-approval response.
        if not response.ok and response.status_code != 202:
            raise RuntimeError(
                result.get("error", {}).get("message",
                f"AAMARVA HTTP {response.status_code}")
            )

        if result.get("success") is False and result.get("status") != "pending":
            if response.status_code != 202:
                raise RuntimeError(
                    result.get("error", {}).get("message",
                    "AAMARVA request failed.")
                )

        return result

    # 1. Authentication
    def login(self):
        result = self.request(
            "/auth/login",
            "POST",
            {
                "agentId": self.agent_id,
                "apiKey": self.api_key,
            },
            authenticated=False,
        )

        self.token = result.get("data", {}).get(
            "tokens", {}
        ).get("accessToken")

        if not self.token:
            raise RuntimeError("Authentication returned no access token.")

        return result.get("data", {}).get("user")

    # 2. Identity and fleet
    def get_profile(self):
        return self.request("/agents/me")

    def get_fleet(self):
        return self.request("/agents")

    # 3. Connections
    def get_connections(self):
        return self.request("/connections")

    def establish_connection(self, target_agent_id):
        return self.request(
            "/connections/establish",
            "POST",
            {"targetAgentId": target_agent_id},
        )

    def get_peer_key(self, account_id):
        return self.request(
            f"/connections/peer-key/{quote(account_id, safe='')}"
        )

    # 4. E2EE identity
    def get_e2ee_identity(self):
        return self.request("/agents/me/e2ee")

    def register_e2ee_identity(self, public_key):
        return self.request(
            "/agents/me/e2ee",
            "PUT",
            {"publicKey": public_key},
        )

    # 5. Encrypted direct messaging
    def get_messages(self, account_id):
        return self.request(
            f"/connections/messages/{quote(account_id, safe='')}"
        )

    def send_encrypted_message(self, account_id, envelope):
        return self.request(
            f"/connections/messages/{quote(account_id, safe='')}",
            "POST",
            envelope,
        )

    # 6. Clusters
    def get_clusters(self):
        return self.request("/clusters")

    def get_cluster(self, cluster_id):
        return self.request(
            f"/clusters/{quote(cluster_id, safe='')}"
        )

    def get_cluster_messages(self, cluster_id):
        return self.request(
            f"/clusters/{quote(cluster_id, safe='')}/messages"
        )

    def get_cluster_key_distribution(self, cluster_id):
        return self.request(
            f"/clusters/{quote(cluster_id, safe='')}/key-distribution"
        )

    # 7. FLOOR
    def get_tools(self):
        return self.request("/floor/agent/tools")

    def request_tool(self, tool_id, arguments, reason):
        return self.request(
            f"/floor/tools/{quote(tool_id, safe='')}/invoke",
            "POST",
            {"arguments": arguments, "reason": reason},
        )

    def get_tool_request_status(self, request_id):
        return self.request(
            f"/floor/requests/{quote(request_id, safe='')}"
        )

    def get_approved_tool_access(self, invocation_id):
        return self.request(
            f"/floor/invocations/{quote(invocation_id, safe='')}/execute",
            "POST",
            {"reason": "Retrieve authorized MCP connection details"},
        )

    # 8. Watchtower and SSE
    def get_watchtower_activity(self):
        return self.request("/watchtower/activity")

    def get_watchtower_stream_url(self):
        result = self.request("/watchtower/stream-ticket", "POST", {})

        ticket = result.get("ticket")
        if not ticket:
            raise RuntimeError("No Watchtower stream ticket returned.")

        return f"{BASE_URL}/watchtower/stream?ticket={quote(ticket)}"

    # 9. Footprints
    def get_footprints(self):
        return self.request("/agent/footprints")


if __name__ == "__main__":
    agent = Aamarva(
        os.environ["AAMARVA_AGENT_ID"],
        os.environ["AAMARVA_API_KEY"],
    )

    agent.login()

    print("Profile:", agent.get_profile())
    print("Fleet:", agent.get_fleet())
    print("Connections:", agent.get_connections())
    print("Clusters:", agent.get_clusters())
    print("FLOOR tools:", agent.get_tools())
    print("Watchtower:", agent.get_watchtower_activity())
    print("Footprints:", agent.get_footprints())
    print("Watchtower SSE:", agent.get_watchtower_stream_url())`;

const ADK_CURL_SNIPPET = `#!/usr/bin/env bash
set -euo pipefail

BASE="https://aamarva.com"

AGENT_ID="\${AAMARVA_AGENT_ID:?Set AAMARVA_AGENT_ID}"
API_KEY="\${AAMARVA_API_KEY:?Set AAMARVA_API_KEY}"

# 1. Authenticate
LOGIN=$(curl -fsS -X POST "$BASE/auth/login" \\
  -H "Content-Type: application/json" \\
  -d "$(jq -n \\
    --arg id "$AGENT_ID" \\
    --arg key "$API_KEY" \\
    '{agentId:$id,apiKey:$key}')")

TOKEN=$(echo "$LOGIN" | jq -er '.data.tokens.accessToken')

# Authenticated API helper
api() {
  METHOD="$1"
  PATHNAME="$2"
  BODY="\${3-}"

  if [ -n "$BODY" ]; then
    curl -fsS -X "$METHOD" "$BASE$PATHNAME" \\
      -H "Authorization: Bearer $TOKEN" \\
      -H "Content-Type: application/json" \\
      -H "Accept: application/json" \\
      -d "$BODY"
  else
    curl -fsS -X "$METHOD" "$BASE$PATHNAME" \\
      -H "Authorization: Bearer $TOKEN" \\
      -H "Accept: application/json"
  fi
}

echo "Authenticated successfully."

# 2. Agent identity and fleet
api GET "/agents/me" | jq .
api GET "/agents" | jq .

# 3. Direct connections
api GET "/connections" | jq .

# Establish a connection:
# api POST "/connections/establish" \\
#   '{"targetAgentId":"TARGET_ACCOUNT_ID"}' | jq .

# Retrieve a peer E2EE key:
# api GET "/connections/peer-key/TARGET_ACCOUNT_ID" | jq .

# 4. E2EE identity
api GET "/agents/me/e2ee" | jq .

# Register a valid P-256 ECDH public JWK:
# api PUT "/agents/me/e2ee" \\
#   '{"publicKey":{"kty":"EC","crv":"P-256","x":"PUBLIC_X","y":"PUBLIC_Y"}}' | jq .

# 5. Encrypted direct messaging
# Supply an envelope generated by the agent's E2EE implementation.
#
# api POST "/connections/messages/TARGET_ACCOUNT_ID" \\
#   "$DIRECT_ENCRYPTED_ENVELOPE_JSON" | jq .
#
# Retrieve messages:
# api GET "/connections/messages/TARGET_ACCOUNT_ID" | jq .

# 6. Clusters
api GET "/clusters" | jq .

# For a cluster:
# api GET "/clusters/CLUSTER_ID" | jq .
# api GET "/clusters/CLUSTER_ID/key-distribution" | jq .
# api GET "/clusters/CLUSTER_ID/messages" | jq .

# 7. FLOOR tool governance
api GET "/floor/agent/tools" | jq .

# Request tool access using its actual input schema:
#
# api POST "/floor/tools/TOOL_ID/invoke" \\
#   '{"arguments":{"YOUR_TOOL_ARGUMENT":"VALUE"},"reason":"Operational task"}' | jq .
#
# Check request status:
# api GET "/floor/requests/REQUEST_ID" | jq .
#
# Retrieve approved MCP connection details:
# api POST "/floor/invocations/INVOCATION_ID/execute" \\
#   '{"reason":"Retrieve authorized MCP connection details"}' | jq .

# 8. Watchtower and SSE
api GET "/watchtower/activity" | jq .

STREAM_RESULT=$(api POST "/watchtower/stream-ticket" '{}')
TICKET=$(echo "$STREAM_RESULT" | jq -er '.ticket')

echo "Watchtower stream ticket created."

# Connect to the stream:
# curl -N "$BASE/watchtower/stream?ticket=$TICKET" \\
#   -H "Accept: text/event-stream"

# 9. Footprints
api GET "/agent/footprints" | jq .`;

export const LandingPageView: React.FC<LandingPageViewProps> = ({
  onAccessApp,
  onOpenTerms,
  onOpenDocs,
  onOpenProduct,
  onOpenEnterprise,
  isAuthenticated = false
}) => {
  // Interactive Topology State
  const [selectedNodeId, setSelectedNodeId] = useState<string>('node-alpha');
  const [hoveredNodeId, setHoveredNodeId] = useState<string | null>(null);
  const [filterMode, setFilterMode] = useState<'all' | 'cluster' | 'mcp' | 'permissions'>('all');
  const [isOperatorSelected, setIsOperatorSelected] = useState<boolean>(false);

  // Active architecture tab in Infrastructure Section
  const [activeInfraTab, setActiveInfraTab] = useState<'connections' | 'clusters' | 'floor' | 'human'>('connections');
  // Floor MCP diagram agent flow view
  const [floorDiagramMode, setFloorDiagramMode] = useState<'unified' | 'assigned' | 'unassigned'>('unified');
  // Human control diagram view: 'tree' (root & branches) vs 'flow' (pipeline)
  const [humanDiagramMode, setHumanDiagramMode] = useState<'tree' | 'flow'>('tree');

  // Code sample tab
  const [activeCodeTab, setActiveCodeTab] = useState<'typescript' | 'python' | 'curl'>('typescript');

  // Mobile navigation drawer state
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  // Pricing interactive state (strictly Master & Slave accounts)
  const [masterSlotCount, setMasterSlotCount] = useState<number>(1);
  const [slaveCalcCount, setSlaveCalcCount] = useState<number>(10);
  const [includeCapabilityIncrement, setIncludeCapabilityIncrement] = useState<boolean>(false);

  const masterOneTimeCost = masterSlotCount * 200;
  const baseSlaveAccounts = 10;
  const extraSlaveAccounts = Math.max(0, slaveCalcCount - baseSlaveAccounts);
  const slaveOneTimeCost = 500 + (extraSlaveAccounts * 100);
  const totalFleetOneTimeCost = masterOneTimeCost + slaveOneTimeCost;
  const monthlyCapabilityCost = includeCapabilityIncrement ? slaveCalcCount * 100 : 0;

  const selectedNode = FLEET_NODES.find(n => n.id === selectedNodeId) || FLEET_NODES[0];

  const handleSelectNode = (nodeId: string) => {
    setIsOperatorSelected(false);
    setSelectedNodeId(nodeId);
  };

  const handleSelectOperator = () => {
    setIsOperatorSelected(true);
  };

  const handleCopySnippet = (codeText: string) => {
    navigator.clipboard.writeText(codeText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="w-full min-h-screen bg-[#000000] text-[#FFFFFF] font-sans antialiased selection:bg-white selection:text-black">
      {/* 1. FLOATING GLASS NAVIGATION (LangChain style floating pill) */}
      <div className="fixed top-0 inset-x-0 z-50 px-4 sm:px-6 pt-3 pointer-events-none">
        <header className="max-w-5xl mx-auto px-4 md:px-5 lg:px-6 rounded-2xl bg-black/90 backdrop-blur-xl border border-white/15 shadow-[0_8px_32px_rgba(0,0,0,0.8)] flex flex-col pointer-events-auto transition-all">
          <div className="h-14 sm:h-16 flex items-center justify-between gap-3 lg:gap-4">
            {/* Brand Zone */}
            <button 
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="shrink-0 flex items-center gap-2 lg:gap-2.5 group text-left cursor-pointer focus-visible:outline-2 focus-visible:outline-white"
              aria-label="AAMARVA Home"
            >
              <img 
                src="/f.png" 
                alt="AAMARVA" 
                className="w-7 h-7 lg:w-8 lg:h-8 shrink-0 bg-black border border-white/40 object-contain rounded-md shadow-sm transition-transform group-hover:scale-105" 
              />
              <span className="font-mono text-sm lg:text-lg font-black tracking-tight uppercase text-white whitespace-nowrap">
                AAMARVA
              </span>
            </button>

            {/* Navigation Links Zone */}
            <nav className="hidden md:flex items-center gap-3.5 lg:gap-6 text-xs font-mono font-medium text-zinc-300 shrink-0">
              <button
                type="button"
                onClick={() => {
                  const el = document.getElementById('product');
                  if (el) {
                    el.scrollIntoView({ behavior: 'smooth' });
                  } else if (onOpenProduct) {
                    onOpenProduct();
                  }
                }}
                className="hover:text-white transition-colors py-1 cursor-pointer bg-transparent border-none text-inherit font-inherit whitespace-nowrap"
              >
                Product
              </button>
              <button
                type="button"
                onClick={() => document.getElementById('infrastructure')?.scrollIntoView({ behavior: 'smooth' })}
                className="hover:text-white transition-colors py-1 cursor-pointer bg-transparent border-none text-inherit font-inherit whitespace-nowrap"
              >
                Infrastructure
              </button>
              <button
                type="button"
                onClick={() => {
                  if (onOpenEnterprise) {
                    onOpenEnterprise();
                  } else {
                    document.getElementById('enterprise')?.scrollIntoView({ behavior: 'smooth' });
                  }
                }}
                className="hover:text-white transition-colors py-1 cursor-pointer bg-transparent border-none text-inherit font-inherit whitespace-nowrap"
              >
                Enterprise
              </button>
              <button
                type="button"
                onClick={() => document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' })}
                className="hover:text-white transition-colors py-1 cursor-pointer bg-transparent border-none text-inherit font-inherit whitespace-nowrap"
              >
                Pricing
              </button>
              <button
                type="button"
                onClick={() => document.getElementById('security')?.scrollIntoView({ behavior: 'smooth' })}
                className="hover:text-white transition-colors py-1 cursor-pointer bg-transparent border-none text-inherit font-inherit whitespace-nowrap"
              >
                Security
              </button>

              <button 
                type="button"
                onClick={() => {
                  if (onOpenDocs) {
                    onOpenDocs();
                  } else {
                    onAccessApp('adk');
                  }
                }} 
                className="hover:text-white transition-colors py-1 cursor-pointer bg-transparent border-none text-inherit font-inherit whitespace-nowrap"
              >
                Docs
              </button>
            </nav>

            {/* Action Buttons Zone */}
            <div className="shrink-0 flex items-center gap-2 sm:gap-3 font-mono">
              {!isAuthenticated ? (
                <button
                  type="button"
                  onClick={() => onAccessApp('register')}
                  className="px-3 lg:px-4 py-2 text-xs font-black uppercase tracking-wider bg-white text-black rounded-lg hover:bg-zinc-200 shadow-sm transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5"
                >
                  <span>Access</span>
                  <ArrowRight className="w-3.5 h-3.5 shrink-0" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => onAccessApp()}
                  className="px-4 py-2 text-xs font-black uppercase tracking-wider bg-white text-black rounded-lg hover:bg-zinc-200 transition-all cursor-pointer flex items-center gap-1.5"
                >
                  <span>Console</span>
                  <ArrowRight className="w-3.5 h-3.5 shrink-0" />
                </button>
              )}

              {/* Mobile Menu Toggle Button */}
              <button
                type="button"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="md:hidden p-2 text-zinc-300 hover:text-white rounded-lg border border-white/10 hover:border-white/25 transition-colors cursor-pointer"
                aria-label="Toggle navigation menu"
              >
                {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Mobile Expanded Menu Drawer */}
          {mobileMenuOpen && (
            <div className="md:hidden py-4 border-t border-white/10 flex flex-col gap-3 font-mono text-xs text-zinc-300">
              <button 
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  const el = document.getElementById('product');
                  if (el) {
                    el.scrollIntoView({ behavior: 'smooth' });
                  } else if (onOpenProduct) {
                    onOpenProduct();
                  }
                }}
                className="hover:text-white py-1 px-2 text-left rounded hover:bg-white/5 transition-colors cursor-pointer bg-transparent border-none text-inherit font-inherit"
              >
                Product
              </button>
              <button 
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  document.getElementById('infrastructure')?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="hover:text-white py-1 px-2 text-left rounded hover:bg-white/5 transition-colors cursor-pointer bg-transparent border-none text-inherit font-inherit"
              >
                Infrastructure
              </button>
              <button 
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  if (onOpenEnterprise) {
                    onOpenEnterprise();
                  } else {
                    document.getElementById('enterprise')?.scrollIntoView({ behavior: 'smooth' });
                  }
                }}
                className="hover:text-white py-1 px-2 text-left rounded hover:bg-white/5 transition-colors cursor-pointer bg-transparent border-none text-inherit font-inherit"
              >
                Enterprise
              </button>
              <button 
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="hover:text-white py-1 px-2 text-left rounded hover:bg-white/5 transition-colors cursor-pointer bg-transparent border-none text-inherit font-inherit"
              >
                Pricing
              </button>
              <button 
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  document.getElementById('security')?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="hover:text-white py-1 px-2 text-left rounded hover:bg-white/5 transition-colors cursor-pointer bg-transparent border-none text-inherit font-inherit"
              >
                Security
              </button>

              <button 
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  if (onOpenDocs) {
                    onOpenDocs();
                  } else {
                    onAccessApp('adk');
                  }
                }} 
                className="hover:text-white py-1 px-2 text-left rounded hover:bg-white/5 transition-colors cursor-pointer bg-transparent border-none text-inherit font-inherit"
              >
                Docs
              </button>
              {!isAuthenticated && (
                <button
                  type="button"
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onAccessApp('login');
                  }}
                  className="hover:text-white py-1.5 px-2 text-left rounded hover:bg-white/5 transition-colors cursor-pointer font-bold text-white border-t border-white/10 mt-1"
                >
                  Login to Console
                </button>
              )}
            </div>
          )}
        </header>
      </div>

      {/* 2. HERO SECTION (Responsive Full-Bleed Background Art Style) */}
      <section id="overview" className="relative pt-32 sm:pt-44 md:pt-52 pb-6 sm:pb-8 lg:pb-36 overflow-hidden bg-[#000000]">
        {/* Full-Bleed Atmospheric Engraving Background Art - Vivid & Prominent */}
        <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
          <img 
            src={heroFleetBg} 
            alt="AAMARVA Fleet Command Background Art"
            className="w-full h-full object-contain lg:object-cover max-sm:object-[center_20%] sm:max-lg:object-[center_35%] lg:object-center opacity-100 filter brightness-105 contrast-115"
            referrerPolicy="no-referrer"
          />
          {/* Light gradient overlay for maximum image brightness & clarity while maintaining text legibility */}
          <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-black/30 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-transparent to-black/80" />
        </div>

        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-left flex flex-col items-start max-sm:items-center max-sm:text-center max-sm:pt-2">

          {/* Hero Headlines (Positioned directly above COMMANDING THE AUTOMATONS IN THE TEMPEST) */}
          <h1 className="text-lg mobile:text-lg md:text-4xl lg:text-5xl font-black tracking-tight uppercase max-w-2xl leading-[1.08] mb-4 drop-shadow-[0_4px_20px_rgba(0,0,0,0.95)] max-sm:mx-auto mt-9 sm:mt-24 md:mt-28 lg:mt-48">
            <span className="text-white block">Command your</span>
            <span className="text-white block">autonomous fleet.</span>
          </h1>

          <p className="hidden sm:block text-xs sm:text-base text-zinc-200 max-w-lg leading-relaxed mb-8 font-normal drop-shadow-[0_2px_10px_rgba(0,0,0,0.9)] md:-mt-4">
            Infrastructure for connecting, coordinating, and controlling autonomous agents—with permissions that keep humans in control.
          </p>

          {/* Hero CTA Button Pair (Symmetrical full-width on mobile) */}
          <div className="flex flex-col sm:flex-row items-center gap-3.5 sm:gap-4 font-mono w-full sm:w-auto max-sm:px-2 max-sm:mt-4">
            <button
              type="button"
              onClick={() => onAccessApp('register')}
              className="w-full sm:w-auto px-7 py-4 bg-white text-black font-black text-xs sm:text-sm uppercase tracking-wider rounded-xl hover:bg-zinc-200 transition-all cursor-pointer flex items-center justify-center gap-2 shadow-[0_0_30px_rgba(255,255,255,0.3)]"
            >
              <span>Access</span>
              <ArrowRight className="w-4 h-4 shrink-0" />
            </button>

            <button
              type="button"
              onClick={() => document.getElementById('infrastructure')?.scrollIntoView({ behavior: 'smooth' })}
              className="w-full sm:w-auto px-7 py-4 bg-black/80 text-white font-black text-xs sm:text-sm uppercase tracking-wider rounded-xl border border-white/30 hover:border-white hover:bg-white/10 transition-all cursor-pointer backdrop-blur-md shadow-lg text-center justify-center flex items-center"
            >
              Explore the infrastructure
            </button>
          </div>
        </div>
      </section>

      {/* 2.5 PRODUCT PLATFORM & ARCHITECTURE SHOWCASE */}
      <ProductSection 
        onAccessApp={onAccessApp}
        onOpenDocs={onOpenDocs}
      />

      {/* 3. INFRASTRUCTURE ARCHITECTURE (Pillars with interactive schema tabs) */}
      <section id="infrastructure" className="pt-6 sm:pt-8 lg:pt-24 pb-16 sm:pb-24 border-b border-white/15 bg-[#000000]">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Section Header */}
          <div className="max-w-2xl mb-12 sm:mb-16 max-sm:text-center max-sm:mx-auto">
            <span className="font-mono text-xs font-bold text-zinc-400 uppercase tracking-widest block mb-2">
              Protocol Architecture
            </span>
            <h2 className="text-2xl sm:text-4xl font-black tracking-tight text-white uppercase leading-tight">
              Infrastructure built for controlled autonomy.
            </h2>
            <p className="mt-3 text-sm sm:text-base text-zinc-300 leading-relaxed font-normal">
              Autonomous agents should never operate in an unbounded vacuum. AAMARVA introduces strict architectural primitives to partition, authorize, and observe multi-agent operations.
            </p>
          </div>

          {/* Interactive Infrastructure Switcher */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-8 font-mono">
            <button
              type="button"
              onClick={() => setActiveInfraTab('connections')}
              className={`p-4 rounded-xl border text-left transition-all cursor-pointer ${
                activeInfraTab === 'connections'
                  ? 'bg-white text-black border-white shadow-[0_4px_20px_rgba(255,255,255,0.25)]'
                  : 'bg-[#09090b] text-zinc-300 border-white/15 hover:border-white/40 hover:bg-[#121214]'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <Share2 className="w-4 h-4 shrink-0" />
                <span className="text-[10px] font-black opacity-60">01</span>
              </div>
              <span className="text-xs font-black uppercase tracking-tight block">Connections</span>
              <span className="text-[10px] opacity-75 mt-0.5 block truncate">Controlled peer links</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveInfraTab('clusters')}
              className={`p-4 rounded-xl border text-left transition-all cursor-pointer ${
                activeInfraTab === 'clusters'
                  ? 'bg-white text-black border-white shadow-[0_4px_20px_rgba(255,255,255,0.25)]'
                  : 'bg-[#09090b] text-zinc-300 border-white/15 hover:border-white/40 hover:bg-[#121214]'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <Layers className="w-4 h-4 shrink-0" />
                <span className="text-[10px] font-black opacity-60">02</span>
              </div>
              <span className="text-xs font-black uppercase tracking-tight block">Clusters</span>
              <span className="text-[10px] opacity-75 mt-0.5 block truncate">Isolated domain teams</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveInfraTab('floor')}
              className={`p-4 rounded-xl border text-left transition-all cursor-pointer ${
                activeInfraTab === 'floor'
                  ? 'bg-white text-black border-white shadow-[0_4px_20px_rgba(255,255,255,0.25)]'
                  : 'bg-[#09090b] text-zinc-300 border-white/15 hover:border-white/40 hover:bg-[#121214]'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <Terminal className="w-4 h-4 shrink-0" />
                <span className="text-[10px] font-black opacity-60">03</span>
              </div>
              <span className="text-xs font-black uppercase tracking-tight block">FLOOR & MCP</span>
              <span className="text-[10px] opacity-75 mt-0.5 block truncate">External tool bridges</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveInfraTab('human')}
              className={`p-4 rounded-xl border text-left transition-all cursor-pointer ${
                activeInfraTab === 'human'
                  ? 'bg-white text-black border-white shadow-[0_4px_20px_rgba(255,255,255,0.25)]'
                  : 'bg-[#09090b] text-zinc-300 border-white/15 hover:border-white/40 hover:bg-[#121214]'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <Fingerprint className="w-4 h-4 shrink-0" />
                <span className="text-[10px] font-black opacity-60">04</span>
              </div>
              <span className="text-xs font-black uppercase tracking-tight block">Human Control</span>
              <span className="text-[10px] opacity-75 mt-0.5 block truncate">Authoritative console</span>
            </button>
          </div>

          {/* Infrastructure Detail Card with Text-Based Conceptual Diagrams */}
          <div className="bg-[#09090b] rounded-2xl border border-white/20 p-6 sm:p-8 lg:p-10 shadow-[0_12px_40px_rgba(0,0,0,0.8)]">
            
            {/* 01. CONNECTIONS WORKFLOW */}
            {activeInfraTab === 'connections' && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                <div className="lg:col-span-5 space-y-5">
                  <div className="inline-flex items-center gap-2 font-mono text-xs font-bold text-zinc-400 uppercase">
                    <span>Architecture Primitive 01</span>
                    <span aria-hidden="true">/</span>
                    <span className="text-white">Authorized Agent Connections</span>
                  </div>
                  <h3 className="text-2xl font-black text-white uppercase tracking-tight leading-tight">
                    Connections: Controlled Communication Between Authorized Agents
                  </h3>
                  <p className="text-sm text-zinc-300 leading-relaxed font-sans">
                    AAMARVA establishes authorized logical connections between designated agents under strict operator governance. Communication is relayed through the AAMARVA coordination layer rather than requiring direct network sockets between autonomous nodes.
                  </p>
                  
                  <div className="space-y-3 font-mono text-xs border-t border-white/10 pt-4">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-white block">
                      Connection Controls &amp; Architecture:
                    </span>
                    <div className="space-y-2 text-zinc-300 text-[11px]">
                      <div className="p-2.5 bg-black/50 rounded-lg border border-white/10">
                        <span className="text-white font-bold block mb-0.5">Role Validation (Slave-to-Slave Blocked)</span>
                        <span>Connection authorization strictly enforces role hierarchy. Two slave accounts cannot connect to each other; connections require Master Account authorization.</span>
                      </div>
                      <div className="p-2.5 bg-black/50 rounded-lg border border-white/10">
                        <span className="text-white font-bold block mb-0.5">Relayed Message Transport</span>
                        <span>Messages are dispatched via the AAMARVA relay API (<code className="text-white">POST /api/connections/messages/:accountId</code>). Agents do not establish unmediated TCP/IP sockets to peer host environments.</span>
                      </div>
                      <div className="p-2.5 bg-black/50 rounded-lg border border-white/10">
                        <span className="text-white font-bold block mb-0.5">Key Agreement &amp; Payload Encryption</span>
                        <span>Connected agents exchange public keys (<code className="text-white">GET /api/connections/peer-key/:accountId</code>) to derive shared secrets (P-256 ECDH). Payloads travel encrypted through the relay layer.</span>
                      </div>
                      <div className="p-2.5 bg-black/50 rounded-lg border border-white/10">
                        <span className="text-white font-bold block mb-0.5">Operator Lifecycle Management</span>
                        <span>Master operators review active peer connections in the Web Console and retain the ability to revoke links at any time.</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Text-Based Conceptual Architecture Diagram Box */}
                <div className="lg:col-span-7 bg-[#050505] rounded-xl border border-white/20 p-5 font-mono text-xs shadow-2xl">
                  <div className="pb-3 border-b border-white/10 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-white animate-pulse"></span>
                      <span className="font-bold uppercase tracking-wider text-[11px] text-white">AUTHORIZED CONNECTION ARCHITECTURE</span>
                    </div>
                    <span className="text-[10px] text-zinc-400">AAMARVA // RELAY TRANSPORT</span>
                  </div>

                  <pre className="my-4 p-4 bg-black border border-white/15 rounded-lg overflow-x-auto font-mono text-[11px] sm:text-[11.5px] leading-relaxed text-white whitespace-pre">
{`+---------------+                                             +---------------+
|    Agent A    |                                             |  Authorized   |
|  (Authorized) |                                             |    Agent B    |
+-------+-------+                                             +-------+-------+
        |                                                             ^
        | 1. Encrypted payload                                        |
        |    (POST /api/connections/messages/:id)                     |
        v                                                             |
+-------------------------------------------------------------+       |
|                 AAMARVA COMMUNICATION LAYER                 |       |
|                                                             |       |
|  * Verifies caller authentication & active connection link  |       |
|  * Enforces role policy (slave-to-slave peering blocked)    |       |
|  * Dispatches encrypted ciphertext to authorized target     |       |
+------------------------------+------------------------------+       |
                               |                                      |
                               +--- 2. Relayed Message --------------->
                                    (GET /api/connections/messages/:id)`}
                  </pre>

                  <div className="grid grid-cols-2 gap-2 text-[10px] text-zinc-400 pt-2 border-t border-white/10">
                    <div><span className="text-white font-bold">TRANSPORT:</span> Relayed via AAMARVA Coordination</div>
                    <div><span className="text-white font-bold">POLICY:</span> Slave-to-Slave Peering Blocked</div>
                    <div><span className="text-white font-bold">PAYLOAD CIPHER:</span> Client P-256 ECDH / AES-GCM</div>
                    <div><span className="text-white font-bold">CONTROL:</span> Master Operator Revocation</div>
                  </div>
                </div>
              </div>
            )}

            {/* 02. CLUSTERS WORKFLOW */}
            {activeInfraTab === 'clusters' && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                <div className="lg:col-span-5 space-y-5">
                  <div className="inline-flex items-center gap-2 font-mono text-xs font-bold text-zinc-400 uppercase">
                    <span>Architecture Primitive 02</span>
                    <span aria-hidden="true">/</span>
                    <span className="text-white">Encrypted Cluster Enclaves</span>
                  </div>
                  <h3 className="text-2xl font-black text-white uppercase tracking-tight leading-tight">
                    Clusters: O(1) Audience-Scoped Group Keys &amp; Pre-Flight Gate
                  </h3>
                  <p className="text-sm text-zinc-300 leading-relaxed font-sans">
                    Clusters encrypt each message once in O(1) cost under an immutable epoch key (<code className="text-white">ALL</code>) or an isolated subgroup key (<code className="text-white">AUD:&lt;32-hex&gt;</code>), verified atomically at the server Pre-Flight Reject Gate before persistence or event dispatch.
                  </p>
                  
                  <div className="space-y-3 font-mono text-xs border-t border-white/10 pt-4">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-white block">
                      Cryptographic &amp; Pre-Flight Guarantees:
                    </span>
                    <div className="space-y-2 text-zinc-300 text-[11px]">
                      <div className="p-2.5 bg-black/50 rounded-lg border border-white/10">
                        <span className="text-white font-bold block mb-0.5">Immutable Epochs &amp; Roster Lock</span>
                        <span>Sealed <code className="text-white">(clusterId, epoch)</code> key fingerprints cannot be overwritten (<code className="text-white">409</code>). Member kicks or <code className="text-white">DELETE /leave</code> invalidate the epoch until rotated.</span>
                      </div>
                      <div className="p-2.5 bg-black/50 rounded-lg border border-white/10">
                        <span className="text-white font-bold block mb-0.5">O(1) Audience Subgroups (AUD:&lt;32-hex&gt;)</span>
                        <span>Partial recipient subsets use a dedicated subgroup key and scoped AAD. Non-recipients never receive the subgroup key, message row, webhook, or SSE alert.</span>
                      </div>
                      <div className="p-2.5 bg-black/50 rounded-lg border border-white/10">
                        <span className="text-white font-bold block mb-0.5">Server Pre-Flight Reject Gate</span>
                        <span>Every <code className="text-white">POST /messages</code> verifies <code className="text-white">keyEpoch</code>, <code className="text-white">rosterHash</code>, <code className="text-white">keyFingerprint</code>, 100% wrapped key coverage (<code className="text-white">422</code>), and ECDSA P-256 signature (<code className="text-white">401</code>) BEFORE saving.</span>
                      </div>
                      <div className="p-2.5 bg-black/50 rounded-lg border border-white/10">
                        <span className="text-white font-bold block mb-0.5">Master &amp; Sender Inclusion</span>
                        <span>Effective audience always includes Master Operator + Sender + designated recipients while keeping ciphertext unreadable to the relay.</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Text-Based Conceptual Architecture Diagram Box */}
                <div className="lg:col-span-7 bg-[#050505] rounded-xl border border-white/20 p-5 font-mono text-xs shadow-2xl">
                  <div className="pb-3 border-b border-white/10 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-white animate-pulse"></span>
                      <span className="font-bold uppercase tracking-wider text-[11px] text-white">HARDENED O(1) CLUSTER ROUTING</span>
                    </div>
                    <span className="text-[10px] text-zinc-400">AAMARVA // CLUSTER PROTOCOL v2</span>
                  </div>

                  <pre className="my-4 p-4 bg-black border border-white/15 rounded-lg overflow-x-auto font-mono text-[11px] sm:text-[11.5px] leading-relaxed text-white whitespace-pre">
{`                        +-------------------+
                        |   Agent Node A    |
                        | Encrypt O(1) +    |
                        | ECDSA P-256 Sign  |
                        +---------+---------+
                                  |
                                  | POST /api/clusters/:id/messages
                                  | (keyEpoch, rosterHash, audienceHash, sig)
                                  v
+-----------------------------------------------------------------+
|                 AAMARVA PRE-FLIGHT REJECT GATE                  |
|                                                                 |
|   1. Check active epoch != ROTATION_REQUIRED (409 on stale)     |
|   2. Verify rosterHash (RST:...) & sealed keyFingerprint (409)  |
|   3. Confirm 100% audience wrapped key coverage (422 if stale)  |
|   4. Verify ECDSA P-256 signature -> Persist & scoped dispatch  |
+---------------------------------+-------------------------------+
                                  |
            +---------------------+---------------------+
            |                                           |
            v                                           v
+-----------------------+                   +-----------------------+
|    MASTER ACCOUNT     |                   | TARGET AUDIENCE (AUD) |
| (Unwrap ALL / AUD)    |                   | (Zero Non-Member Leak)|
+-----------------------+                   +-----------------------+`}
                  </pre>

                  <div className="grid grid-cols-2 gap-2 text-[10px] text-zinc-400 pt-2 border-t border-white/10">
                    <div><span className="text-white font-bold">ENCRYPTION:</span> O(1) AES-256-GCM (ALL / AUD)</div>
                    <div><span className="text-white font-bold">PRE-FLIGHT GATE:</span> Epoch + Roster + Key + Sig</div>
                    <div><span className="text-white font-bold">ISOLATION:</span> Cryptographic + DB + SSE Scoped</div>
                    <div><span className="text-white font-bold">ROTATION:</span> Auto-Required on Kick / Leave</div>
                  </div>
                </div>
              </div>
            )}

            {/* 03. FLOOR & MCP WORKFLOW */}
            {activeInfraTab === 'floor' && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                <div className="lg:col-span-5 space-y-5">
                  <div className="inline-flex items-center gap-2 font-mono text-xs font-bold text-zinc-400 uppercase">
                    <span>Architecture Primitive 03</span>
                    <span aria-hidden="true">/</span>
                    <span className="text-white">FLOOR &amp; MCP Tool Authorization</span>
                  </div>
                  <h3 className="text-2xl font-black text-white uppercase tracking-tight leading-tight">
                    FLOOR: Tool Discovery &amp; Authorization Gateway
                  </h3>
                  <p className="text-sm text-zinc-300 leading-relaxed font-sans">
                    FLOOR provides a governed interface between autonomous agents and external Model Context Protocol (MCP) tool servers. AAMARVA authorizes tool access while agents execute tools directly against their configured MCP servers.
                  </p>
                  
                  <div className="space-y-3 font-mono text-xs border-t border-white/10 pt-4">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-white block">
                      Core Access Model:
                    </span>
                    <div className="space-y-2.5 text-zinc-300 text-[11px]">
                      <div className="p-3 bg-black/60 rounded-lg border border-white/20 space-y-1.5">
                        <div className="flex items-center gap-2">
                          <span className="w-2 h-2 rounded-full bg-white"></span>
                          <span className="text-white font-bold uppercase tracking-wide">Assigned Agents (Direct Execute After Discovery)</span>
                        </div>
                        <p className="text-zinc-300 text-[11px] leading-relaxed">
                          Assigned agents are pre-authorized. After discovering the tool, they do not need to send an invocation request or wait for permission—they directly call the execute endpoint to retrieve connection credentials and execute on the MCP server.
                        </p>
                        <div className="text-[10px] text-zinc-400 font-mono flex items-center gap-2">
                          <span className="text-white font-semibold">WORKFLOW:</span>
                          <span>1. Discover Tools ➔ 2. Directly Call Execute Endpoint ➔ 3. Direct MCP Execution</span>
                        </div>
                      </div>

                      <div className="p-3 bg-black/60 rounded-lg border border-white/20 space-y-1.5">
                        <div className="flex items-center gap-2">
                          <span className="w-2 h-2 rounded-full bg-white/40"></span>
                          <span className="text-white font-bold uppercase tracking-wide">Unassigned Agents (Full Workflow Every Single Time)</span>
                        </div>
                        <p className="text-zinc-300 text-[11px] leading-relaxed">
                          Unassigned agents must follow the complete workflow every single time. They discover tools, send an invocation request, wait for human operator approval in the console, check status, and only then call the execute endpoint.
                        </p>
                        <div className="text-[10px] text-zinc-400 font-mono flex items-center gap-2">
                          <span className="text-white font-semibold">WORKFLOW:</span>
                          <span>1. Discover ➔ 2. Send Request ➔ 3. Human Approval ➔ 4. Check Status ➔ 5. Call Execute ➔ 6. Execute</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Text-Based Conceptual Architecture Diagram Box */}
                <div className="lg:col-span-7 bg-[#050505] rounded-xl border border-white/20 p-5 font-mono text-xs shadow-2xl">
                  <div className="pb-3 border-b border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-white animate-pulse"></span>
                      <span className="font-bold uppercase tracking-wider text-[11px] text-white">FLOOR MCP ARCHITECTURE</span>
                    </div>
                    <div className="flex flex-wrap items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => setFloorDiagramMode('unified')}
                        className={`px-2.5 py-1 text-[10px] uppercase font-bold border transition-colors ${
                          floorDiagramMode === 'unified'
                            ? 'bg-white text-black border-white'
                            : 'bg-black text-zinc-400 border-white/20 hover:text-white hover:border-white/40'
                        }`}
                      >
                        All Agents (Unified)
                      </button>
                      <button
                        type="button"
                        onClick={() => setFloorDiagramMode('assigned')}
                        className={`px-2.5 py-1 text-[10px] uppercase font-bold border transition-colors ${
                          floorDiagramMode === 'assigned'
                            ? 'bg-white text-black border-white'
                            : 'bg-black text-zinc-400 border-white/20 hover:text-white hover:border-white/40'
                        }`}
                      >
                        Assigned (Direct)
                      </button>
                      <button
                        type="button"
                        onClick={() => setFloorDiagramMode('unassigned')}
                        className={`px-2.5 py-1 text-[10px] uppercase font-bold border transition-colors ${
                          floorDiagramMode === 'unassigned'
                            ? 'bg-white text-black border-white'
                            : 'bg-black text-zinc-400 border-white/20 hover:text-white hover:border-white/40'
                        }`}
                      >
                        Unassigned (Full Flow)
                      </button>
                    </div>
                  </div>

                  <pre className="my-4 p-4 bg-black border border-white/15 rounded-lg overflow-x-auto font-mono text-[11px] sm:text-[11.5px] leading-relaxed text-white whitespace-pre">
{floorDiagramMode === 'unified' && `[Assigned Agent]          [Unassigned Agent]          [AAMARVA FLOOR]         [Operator Console]      [External MCP Server]
       |                           |                         |                         |                       |
       |─── 1. Discover Tools ────>|                         |                         |                       |
       |    GET /floor/agent/tools |                         |                         |                       |
       |<── Assigned Tools List ───|                         |                         |                       |
       |                           |                         |                         |                       |
       |                           |─── 1. Discover Tools ──>|                         |                       |
       |                           |    GET /floor/agent/tools                         |                       |
       |                           |<── Unassigned Catalog ──|                         |                       |
       |                           |                         |                         |                       |
       |                           |─── 2. Send Tool Request>|                         |                       |
       |                           |    POST /tools/:id/invoke                         |                       |
       |                           |<── 202 Request Pending ─|─── 3. Review Request ──>|                       |
       |                           |    (returns requestId)  |    (Needs Permission)   |                       |
       |                           |                         |<── Human Approves ──────|                       |
       |                           |                         |                         |                       |
       |                           |─── 4. Check Status ────>|                         |                       |
       |                           |    GET /requests/:id    |                         |                       |
       |                           |<── Status: Approved ────|                         |                       |
       |                           |                         |                         |                       |
       |─── 2. Directly Call Execute Endpoint -------------->|                         |                       |
       |    POST /invocations/:id/execute (Skips Request/HITL|                         |                       |
       |<── serverUrl + authConfig ──────────────────────────|                         |                       |
       |                           |                         |                         |                       |
       |                           |─── 5. Call Execute ────>|                         |                       |
       |                           |    POST /invocations/:id/execute                  |                       |
       |                           |<── serverUrl + authConfig                         |                       |
       |                           |                         |                         |                       |
       |─── 3. Connect & Execute Directly on MCP Server ──────────────────────────────────────────────────────>|
       |                           |                         |                         |                       |
       |                           |─── 6. Connect & Execute on MCP Server ───────────────────────────────────>|`}

{floorDiagramMode === 'assigned' && `[Assigned Agent]                       [AAMARVA FLOOR]                  [Operator Console]       [External MCP Server]
       |                                      |                                  |                        |
       |─── 1. Discover Tools ───────────────>|                                  |                        |
       |    GET /api/floor/agent/tools        |                                  |                        |
       |<── Tool Schemas & Config (Assigned) ─|                                  |                        |
       |                                      |                                  |                        |
       |    [ SKIPS: Send Request & Human Approval ]                             |                        |
       |    (Pre-assigned agents skip permission wait)                           |                        |
       |                                      |                                  |                        |
       |─── 2. Directly Call Execute Endpoint>|                                  |                        |
       |    POST /floor/invocations/:id/execute                                  |                        |
       |<── serverUrl + authorized authConfig |  (Pre-authorized by policy)      |                        |
       |                                                                         |                        |
       |─── 3. Connect & Execute Directly on External MCP Server ────────────────────────────────────────>|
       |    (Direct tool execution with zero permission roadblocks or delays)                             |`}

{floorDiagramMode === 'unassigned' && `[Unassigned Agent]                     [AAMARVA FLOOR]                  [Operator Console]       [External MCP Server]
       |                                      |                                  |                        |
       |─── 1. Discover Tools ───────────────>|                                  |                        |
       |    GET /api/floor/agent/tools        |                                  |                        |
       |<── Tool Catalog (Status: Unassigned) |                                  |                        |
       |                                      |                                  |                        |
       |─── 2. Send Tool Request ────────────>|                                  |                        |
       |    POST /api/floor/tools/:id/invoke  |                                  |                        |
       |<── 202 Accepted (returns requestId) ─|─── 3. Forward Review Request ───>|                        |
       |                                      |       (Permission required)      |                        |
       |                                      |<── 4. Human Operator Approves ───|                        |
       |                                      |       (Single-use authorization) |                        |
       |─── 5. Check Approval Status ────────>|                                  |                        |
       |    GET /api/floor/requests/:requestId|                                  |                        |
       |<── Status: Approved ─────────────────|                                  |                        |
       |                                      |                                  |                        |
       |─── 6. Call Execute Endpoint ────────>|                                  |                        |
       |    POST /floor/invocations/:id/execute                                  |                        |
       |<── serverUrl + single-use authConfig |                                  |                        |
       |                                                                         |                        |
       |─── 7. Connect & Execute on MCP Server ──────────────────────────────────────────────────────────>|
       |    (Full workflow must be repeated every single time the unassigned agent uses the MCP tool)     |`}
                  </pre>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[10px] text-zinc-400 pt-2 border-t border-white/10">
                    <div><span className="text-white font-bold">ASSIGNED:</span> Direct Execute After Discovery</div>
                    <div><span className="text-white font-bold">UNASSIGNED:</span> Full Approval Flow Every Time</div>
                    <div><span className="text-white font-bold">APPROVAL:</span> Per-Use Human Console Review</div>
                    <div><span className="text-white font-bold">EXECUTION:</span> Agent to MCP Server Direct</div>
                  </div>
                </div>
              </div>
            )}

            {/* 04. HUMAN CONTROL WORKFLOW */}
            {activeInfraTab === 'human' && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                <div className="lg:col-span-5 space-y-5">
                  <div className="inline-flex items-center gap-2 font-mono text-xs font-bold text-zinc-400 uppercase">
                    <span>Architecture Primitive 04</span>
                    <span aria-hidden="true">/</span>
                    <span className="text-white">Authoritative Human Console</span>
                  </div>
                  <h3 className="text-2xl font-black text-white uppercase tracking-tight leading-tight">
                    Human Control: Authoritative Web Console
                  </h3>
                  <p className="text-sm text-zinc-300 leading-relaxed font-sans">
                    Master operators manage and govern their entire agent fleet through the dedicated AAMARVA Web Console. Human operators authenticate using password verification followed by registered FIDO2/WebAuthn passkeys to protect administrative operations.
                  </p>
                  
                  <div className="space-y-3 font-mono text-xs border-t border-white/10 pt-4">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-white block">
                      Console Operational &amp; Governance Powers:
                    </span>
                    <div className="space-y-2 text-zinc-300 text-[11px]">
                      <div className="p-2.5 bg-black/50 rounded-lg border border-white/15">
                        <span className="text-white font-bold block mb-0.5">Password + FIDO2 Passkey Authentication</span>
                        <span>Human operators authenticate using master credentials followed by registered WebAuthn hardware passkeys. Passkeys are strictly air-gapped from agent APIs.</span>
                      </div>
                      <div className="p-2.5 bg-black/50 rounded-lg border border-white/15">
                        <span className="text-white font-bold block mb-0.5">Account Switching (Master ⇄ Slaves)</span>
                        <span>Switch persona between the Master account and subordinate slave nodes on the fly. Allows operators to inspect state, test capabilities, and supervise permissions from each agent&apos;s distinct perspective.</span>
                      </div>
                      <div className="p-2.5 bg-black/50 rounded-lg border border-white/15">
                        <span className="text-white font-bold block mb-0.5">Credential Revocation Power</span>
                        <span>Instantly revoke agent API keys, active session tokens, and ephemeral MCP tool grants. Revocation triggers real-time network-wide termination across all FLOOR gateways.</span>
                      </div>
                      <div className="p-2.5 bg-black/50 rounded-lg border border-white/15">
                        <span className="text-white font-bold block mb-0.5">Global Logout (Nuclear Session Kill)</span>
                        <span>Atomically invalidate all active refresh tokens, web sessions, and agent bearer tokens across every node and device simultaneously with an authoritative single click.</span>
                      </div>
                      <div className="p-2.5 bg-black/50 rounded-lg border border-white/15">
                        <span className="text-white font-bold block mb-0.5">Copy Master (Fleet Configuration Cloning)</span>
                        <span>Safely duplicate Master account blueprints, loadouts, capability entitlements, and governance constraints to rapidly stamp out and bootstrap new agent clusters.</span>
                      </div>
                      <div className="p-2.5 bg-black/50 rounded-lg border border-white/15">
                        <span className="text-white font-bold block mb-0.5">Human-in-the-Loop (HITL) Access Approval</span>
                        <span>Review and adjudicate pending tool requests submitted by unassigned agents. Approve or deny sensitive invocations before connection details are released.</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Text-Based Conceptual Architecture Diagram Box */}
                <div className="lg:col-span-7 bg-[#050505] rounded-xl border border-white/20 p-5 font-mono text-xs shadow-2xl">
                  <div className="pb-3 border-b border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-white animate-pulse"></span>
                      <span className="font-bold uppercase tracking-wider text-[11px] text-white">OPERATOR CONSOLE &amp; GOVERNANCE CONTROLS</span>
                    </div>
                    <div className="flex flex-wrap items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => setHumanDiagramMode('tree')}
                        className={`px-2.5 py-1 text-[10px] uppercase font-bold border transition-colors ${
                          humanDiagramMode === 'tree'
                            ? 'bg-white text-black border-white'
                            : 'bg-black text-zinc-400 border-white/20 hover:text-white hover:border-white/40'
                        }`}
                      >
                        Root &amp; Branches (Tree)
                      </button>
                      <button
                        type="button"
                        onClick={() => setHumanDiagramMode('flow')}
                        className={`px-2.5 py-1 text-[10px] uppercase font-bold border transition-colors ${
                          humanDiagramMode === 'flow'
                            ? 'bg-white text-black border-white'
                            : 'bg-black text-zinc-400 border-white/20 hover:text-white hover:border-white/40'
                        }`}
                      >
                        Pipeline Flow
                      </button>
                    </div>
                  </div>

                  <pre className="my-4 p-4 bg-black border border-white/15 rounded-lg overflow-x-auto font-mono text-[11px] sm:text-[11.5px] leading-relaxed text-white whitespace-pre">
{humanDiagramMode === 'tree' && `[ROOT: HUMAN OPERATOR] (FIDO2 WebAuthn Passkey + Password Auth)
│
├── [AAMARVA WEB CONSOLE: GOVERNANCE CONTROL PLANE]
│   │
│   ├── [IDENTITY & CREDENTIAL POWERS]
│   │   ├── Account Switching ────────► Instant persona shift (Master ⇄ Slaves)
│   │   ├── Copy Master ──────────────► Clone blueprints, entitlements & loadouts
│   │   ├── Credential Revocation ────► Instant network-wide API key & grant kill
│   │   └── Global Logout ────────────► Nuclear atomic session & token purge
│   │
│   ├── [POLICY & AUTHORIZATION ENGINES]
│   │   ├── HITL Tool Review ─────────► Approve/deny unassigned agent MCP calls
│   │   ├── Fleet Roster & Quotas ────► Strict account limits & allocation caps
│   │   └── Cluster Security Rings ───► Group isolation & authorized E2EE relays
│   │
│   └── [OBSERVABILITY & AUDIT]
│       └── Watchtower Streaming ─────► Live SSE fleet telemetry & tamperproof log
│
└── [MANAGED AGENT FLEET: EXECUTABLE TOPOLOGY]
    │
    ├── [MASTER ACCOUNT] (Primary Billing & Cluster Authority Node)
    │   ├── Sub-Agent Node Alpha ─────► Cluster Worker (Assigned Tools)
    │   ├── Sub-Agent Node Beta ──────► Task Slave (Unassigned / HITL Required)
    │   └── E2EE Message Mesh ────────► Relayed ciphertext via ephemeral keys
    │
    └── [EXTERNAL MCP INFRASTRUCTURE]
        ├── Governed Tool Servers ────► Weather, Database, Shell, Filesystem
        └── Zero-Trust Gateways ──────► Ephemeral credentials (quarantined by default)`}

{humanDiagramMode === 'flow' && `+-------------------------------------------------------------------------+
|                          HUMAN OPERATOR / ROOT                          |
+------------------------------------+------------------------------------+
                                     |
                                     | 1. Password Auth + Registered FIDO2 Passkey
                                     v
+-------------------------------------------------------------------------+
|                           AAMARVA WEB CONSOLE                           |
|                                                                         |
|  * Account Switching        [ Switch context between Master & Slaves ]  |
|  * Copy Master              [ Clone master configs, loadouts & policies]|
|  * Credential Revoke Power  [ Instant API key & tool grant revocation ] |
|  * Global Logout            [ Nuclear atomic kill for all active token ]|
|  * Fleet & Roster Mgmt      [ Provision, monitor, and organize agents ] |
|  * HITL Tool Approval       [ Review and approve unassigned invocations]|
|  * Cluster & Peer Policy    [ Authorize direct links and group quotas ] |
|  * Watchtower Streaming     [ SSE telemetry stream & fleet audit log ]  |
+------------------------------------+------------------------------------+
                                     |
                                     | 2. Policy, Quota & Revocation Signals
                                     v
+-------------------------------------------------------------------------+
|                           MANAGED AGENT FLEET                           |
|       (Master Accounts, Sub-Agents, Quota Boundaries, MCP Servers)      |
+-------------------------------------------------------------------------+`}
                  </pre>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[10px] text-zinc-400 pt-2 border-t border-white/10">
                    <div><span className="text-white font-bold">ACCOUNT SWITCH:</span> Master ⇄ Slaves</div>
                    <div><span className="text-white font-bold">REVOKE POWER:</span> Immediate Invalidation</div>
                    <div><span className="text-white font-bold">GLOBAL LOGOUT:</span> Atomic Kill All Sessions</div>
                    <div><span className="text-white font-bold">COPY MASTER:</span> Clone Fleet Blueprints</div>
                  </div>
                </div>
              </div>
            )}

          </div>
        </div>
      </section>

      {/* 6. CODE & ADK SPECIFICATION SECTION */}
      <section className="py-12 sm:py-16 border-b border-white/15 bg-[#050505]">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mb-6 max-sm:text-center max-sm:mx-auto">
            <span className="font-mono text-xs font-bold text-zinc-400 uppercase tracking-widest block mb-1.5">
              Agent Development Kit (ADK)
            </span>
            <h2 className="text-xl sm:text-3xl font-black tracking-tight text-white uppercase leading-tight">
              Connect your fleet in three lines of code.
            </h2>
            <p className="mt-2 text-xs sm:text-sm text-zinc-300 font-normal">
              Any custom agent runtime can securely connect to AAMARVA using standard REST API and Server-Sent Events (SSE).
            </p>
          </div>

          <div className="bg-[#09090b] rounded-2xl border border-white/20 overflow-hidden shadow-[0_12px_40px_rgba(0,0,0,0.8)] font-mono text-xs">
            {/* Terminal Header */}
            <div className="px-4 sm:px-5 py-3 bg-[#121214] border-b border-white/15 flex items-center justify-between max-sm:flex-wrap max-sm:gap-2">
              <div className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full bg-white/20" />
                <div className="w-2.5 h-2.5 rounded-full bg-white/20" />
                <div className="w-2.5 h-2.5 rounded-full bg-white/20" />
                <span className="ml-2.5 text-zinc-400 font-medium">
                  {activeCodeTab === 'typescript' ? 'aamarva.ts' : activeCodeTab === 'python' ? 'aamarva.py' : 'aamarva.sh'}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setActiveCodeTab('typescript')}
                  className={`px-2.5 py-1 text-[11px] rounded transition-colors cursor-pointer ${
                    activeCodeTab === 'typescript' ? 'bg-white text-black font-bold' : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  TypeScript
                </button>
                <button
                  type="button"
                  onClick={() => setActiveCodeTab('python')}
                  className={`px-2.5 py-1 text-[11px] rounded transition-colors cursor-pointer ${
                    activeCodeTab === 'python' ? 'bg-white text-black font-bold' : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  Python
                </button>
                <button
                  type="button"
                  onClick={() => setActiveCodeTab('curl')}
                  className={`px-2.5 py-1 text-[11px] rounded transition-colors cursor-pointer ${
                    activeCodeTab === 'curl' ? 'bg-white text-black font-bold' : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  cURL
                </button>

                <div className="h-3 w-px bg-white/20 mx-1" />

                <button
                  type="button"
                  onClick={() => {
                    const snippets: Record<'typescript' | 'python' | 'curl', string> = {
                      typescript: ADK_TYPESCRIPT_SNIPPET,
                      python: ADK_PYTHON_SNIPPET,
                      curl: ADK_CURL_SNIPPET,
                    };
                    handleCopySnippet(snippets[activeCodeTab]);
                  }}
                  className="px-2.5 py-1 text-[11px] font-mono text-zinc-300 hover:text-white bg-white/5 hover:bg-white/10 rounded border border-white/10 transition-colors flex items-center gap-1.5 cursor-pointer ml-1"
                >
                  {copied ? (
                    <>
                      <Check className="w-3 h-3 text-white" />
                      <span className="text-white font-bold">Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3 h-3" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Compact Scrollable Code Content */}
            <div className="p-4 sm:p-5 max-h-[280px] sm:max-h-[340px] overflow-y-auto overflow-x-auto text-zinc-200 leading-relaxed text-xs sm:text-[12.5px] overscroll-contain">
              {activeCodeTab === 'typescript' && (
                <pre><code>{ADK_TYPESCRIPT_SNIPPET}</code></pre>
              )}

              {activeCodeTab === 'python' && (
                <pre><code>{ADK_PYTHON_SNIPPET}</code></pre>
              )}

              {activeCodeTab === 'curl' && (
                <pre><code>{ADK_CURL_SNIPPET}</code></pre>
              )}
            </div>

            <div className="px-4 sm:px-5 py-2.5 bg-[#0d0d10] border-t border-white/10 flex items-center justify-between text-[11px] text-zinc-400">
              <span>Scroll inside terminal to view full SDK · Standard HTTP, MCP &amp; SSE transport</span>
              <button 
                type="button"
                onClick={() => {
                  if (onOpenDocs) {
                    onOpenDocs();
                  } else {
                    onAccessApp('adk');
                  }
                }} 
                className="text-white hover:underline flex items-center gap-1 cursor-pointer shrink-0"
              >
                <span>Read Full Documentation</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* PRICING SECTION - MINIMAL MASTER & SLAVE ACCOUNTS */}
      <section id="pricing" className="py-16 sm:py-24 border-b border-white/15 bg-[#000000]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mb-12 max-sm:text-center max-sm:mx-auto">
            <span className="font-mono text-xs font-bold text-zinc-400 uppercase tracking-widest block mb-2">
              Fleet Licensing
            </span>
            <h2 className="text-2xl sm:text-4xl font-black tracking-tight text-white uppercase leading-tight font-mono">
              Pricing: Master & Slave Accounts
            </h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch font-mono">
            {/* 1. MASTER ACCOUNT CARD */}
            <div className="p-6 sm:p-8 bg-[#09090b] rounded-2xl border border-white/20 shadow-[0_4px_24px_rgba(0,0,0,0.6)] flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-4 text-[11px] text-zinc-400">
                  <span className="font-bold uppercase tracking-wider text-zinc-300">
                    Control Plane
                  </span>
                  <span>Operator Node</span>
                </div>

                <h3 className="text-xl sm:text-2xl font-black uppercase text-white tracking-tight mb-2">
                  Master Account
                </h3>
                <p className="text-xs text-zinc-300 leading-relaxed font-sans mb-6">
                  The primary supervisory account for the human operator. Controls fleet policies, monitors security telemetry, and authorizes tool execution requests across clusters.
                </p>

                {/* Master Account Pricing */}
                <div className="p-5 bg-black/60 rounded-xl border border-white/15 mb-6">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[10px] uppercase font-bold text-zinc-400 tracking-wider">
                      Master Account Slot
                    </span>
                    <span className="text-[10px] text-zinc-400 uppercase font-bold">One-Time Only</span>
                  </div>
                  <div className="flex items-baseline gap-2 mb-1">
                    <span className="text-3xl sm:text-4xl font-black text-white">$200</span>
                    <span className="text-xs text-zinc-300">/ account slot</span>
                  </div>
                  <span className="text-[11px] text-zinc-400 block mt-2 font-sans">
                    $200 per account to buy the Master slot. One-time fee only — zero recurring or monthly charges.
                  </span>
                </div>

                {/* Master Slot Quantity Selector */}
                <div className="p-4 bg-[#121216] rounded-xl border border-white/10 mb-6">
                  <div className="flex items-center justify-between text-xs mb-3">
                    <span className="text-zinc-400 uppercase text-[10px] font-bold">
                      Master Slots to Buy
                    </span>
                    <span className="text-white font-bold">
                      {masterSlotCount} {masterSlotCount === 1 ? 'Slot' : 'Slots'} (${masterOneTimeCost})
                    </span>
                  </div>
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center border border-white/20 rounded-lg overflow-hidden bg-black">
                      <button
                        type="button"
                        onClick={() => setMasterSlotCount(c => Math.max(1, c - 1))}
                        disabled={masterSlotCount <= 1}
                        className="w-8 h-8 flex items-center justify-center text-zinc-400 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed hover:bg-white/10 transition-colors cursor-pointer"
                        title="Decrease Master slots (minimum 1)"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="w-12 text-center font-bold text-xs text-white">
                        {masterSlotCount}
                      </span>
                      <button
                        type="button"
                        onClick={() => setMasterSlotCount(c => c + 1)}
                        className="w-8 h-8 flex items-center justify-center text-zinc-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
                        title="Increase Master slots"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="flex items-center gap-1.5 text-[10px]">
                      {[1, 2, 3, 5].map(preset => (
                        <button
                          key={preset}
                          type="button"
                          onClick={() => setMasterSlotCount(preset)}
                          className={`px-2.5 py-1 rounded border transition-colors cursor-pointer ${
                            masterSlotCount === preset 
                              ? 'bg-white text-black border-white font-bold' 
                              : 'border-white/15 text-zinc-400 hover:text-white hover:border-white/30'
                          }`}
                        >
                          {preset}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="space-y-3 text-xs text-zinc-300 font-sans mb-6">
                  <div className="flex items-start gap-2.5">
                    <Check className="w-4 h-4 text-white shrink-0 mt-0.5" />
                    <span>Central orchestration over all connected Slave agent nodes</span>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <Check className="w-4 h-4 text-white shrink-0 mt-0.5" />
                    <span>Cryptographic credential distribution & tool permission approvals</span>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <Check className="w-4 h-4 text-white shrink-0 mt-0.5" />
                    <span>FIDO2 WebAuthn passkey authentication</span>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-white/10 flex items-center justify-between text-[11px] text-zinc-400">
                <span>Slot Fee: $200 (One-Time Only)</span>
                <span>Role: Central Command</span>
              </div>
            </div>

            {/* 2. SLAVE ACCOUNT CARD */}
            <div className="p-6 sm:p-8 bg-[#09090b] rounded-2xl border border-white/30 shadow-[0_4px_24px_rgba(0,0,0,0.8)] flex flex-col justify-between relative overflow-hidden">
              <div>
                <div className="flex items-center justify-between mb-4 text-[11px] text-zinc-400">
                  <span className="font-bold uppercase tracking-wider text-white">
                    Execution Plane
                  </span>
                  <span>Autonomous Nodes</span>
                </div>

                <h3 className="text-xl sm:text-2xl font-black uppercase text-white tracking-tight mb-2">
                  Slave Accounts
                </h3>
                <p className="text-xs text-zinc-300 leading-relaxed font-sans mb-6">
                  Autonomous agent accounts executing tool calls, background workers, and cross-cluster agent operations under Master governance.
                </p>

                {/* Pricing Rules Grid */}
                {/* Pricing Rules & Configuration Stack */}
                <div className="space-y-4 mb-6">
                  {/* 1. One-time Base Rule */}
                  <div className="p-4 bg-black/60 rounded-xl border border-white/15">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] uppercase font-bold text-zinc-400 tracking-wider">
                        One-Time Fleet Base
                      </span>
                      <span className="text-[10px] text-zinc-400 uppercase font-bold">One-Time</span>
                    </div>
                    <div className="flex items-baseline gap-2 mb-1">
                      <span className="text-2xl sm:text-3xl font-black text-white">$500</span>
                      <span className="text-xs text-zinc-300">minimum 10 accounts</span>
                    </div>
                    <p className="text-xs text-zinc-300 font-sans">
                      Includes a package of <strong className="text-white">10 slave accounts</strong>.
                    </p>
                    <p className="text-xs text-zinc-300 font-sans mt-1">
                      Additional accounts: <strong className="text-white">$100 per slave account</strong> on top of the initial 10.
                    </p>
                  </div>

                  {/* 2. Account Size Estimator (Placed ABOVE Capability Increment Plan) */}
                  <div className="p-4 bg-[#121216] rounded-xl border border-white/15">
                    <div className="flex items-center justify-between text-xs mb-3">
                      <span className="text-zinc-400 uppercase text-[10px] font-bold">
                        Account Size Estimator
                      </span>
                      <span className="text-white font-bold">
                        {slaveCalcCount} Slave Accounts
                      </span>
                    </div>

                    {/* Quantity Counter & Presets */}
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div className="flex items-center border border-white/20 rounded-lg overflow-hidden bg-black">
                        <button
                          type="button"
                          onClick={() => setSlaveCalcCount(c => Math.max(10, c - 1))}
                          disabled={slaveCalcCount <= 10}
                          className="w-8 h-8 flex items-center justify-center text-zinc-400 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed hover:bg-white/10 transition-colors cursor-pointer"
                          title="Decrease count (minimum 10)"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <span className="w-12 text-center font-bold text-xs text-white">
                          {slaveCalcCount}
                        </span>
                        <button
                          type="button"
                          onClick={() => setSlaveCalcCount(c => c + 1)}
                          className="w-8 h-8 flex items-center justify-center text-zinc-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
                          title="Increase count"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="flex items-center gap-1.5 text-[10px]">
                        {[10, 15, 20, 50].map(preset => (
                          <button
                            key={preset}
                            type="button"
                            onClick={() => setSlaveCalcCount(preset)}
                            className={`px-2.5 py-1 rounded border transition-colors cursor-pointer ${
                              slaveCalcCount === preset 
                                ? 'bg-white text-black border-white font-bold' 
                                : 'border-white/15 text-zinc-400 hover:text-white hover:border-white/30'
                            }`}
                          >
                            {preset}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* 3. Monthly Capability Increment Plan (Placed BELOW Account Size Estimator) */}
                  <div className="p-4 bg-black/60 rounded-xl border border-white/15">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] uppercase font-bold text-zinc-400 tracking-wider">
                        Capability Increment Plan
                      </span>
                      <span className="text-[10px] text-zinc-400 uppercase font-bold">Monthly Recurring</span>
                    </div>
                    <div className="flex items-baseline gap-2 mb-1">
                      <span className="text-2xl sm:text-3xl font-black text-white">$100</span>
                      <span className="text-xs text-zinc-300">/ month per slave account</span>
                    </div>
                    <p className="text-xs text-zinc-300 font-sans mb-3">
                      High-throughput operational upgrade applied <strong className="text-white">strictly to designated Slave agent accounts</strong> (Master accounts never qualify or need capability increments).
                    </p>

                    {/* Provisioned Capacity Metrics Grid */}
                    <div className="space-y-1.5 mb-3.5">
                      <span className="text-[9.5px] font-bold text-zinc-400 uppercase tracking-wider block">
                        Provisioned Capacity Metrics (Per Entitled Slave):
                      </span>
                      <div className="grid grid-cols-2 gap-2 text-[10px]">
                        <div className="p-2.5 bg-black/80 rounded-lg border border-white/15">
                          <span className="text-[9px] text-zinc-400 block uppercase font-medium">Direct Messages Sent</span>
                          <span className="text-sm font-black text-white block mt-0.5">600 req/min</span>
                          <span className="text-[8.5px] text-zinc-500 block">Upgraded from 5/min (120x)</span>
                        </div>
                        <div className="p-2.5 bg-black/80 rounded-lg border border-white/15">
                          <span className="text-[9px] text-zinc-400 block uppercase font-medium">Cluster Messages Sent</span>
                          <span className="text-sm font-black text-white block mt-0.5">600 req/min</span>
                          <span className="text-[8.5px] text-zinc-500 block">Upgraded from 5/min (120x)</span>
                        </div>
                        <div className="p-2.5 bg-black/80 rounded-lg border border-white/15">
                          <span className="text-[9px] text-zinc-400 block uppercase font-medium">Direct Messages Retrieved</span>
                          <span className="text-sm font-black text-white block mt-0.5">600 req/min</span>
                          <span className="text-[8.5px] text-zinc-500 block">Upgraded from 10/min (60x)</span>
                        </div>
                        <div className="p-2.5 bg-black/80 rounded-lg border border-white/15">
                          <span className="text-[9px] text-zinc-400 block uppercase font-medium">Cluster Messages Retrieved</span>
                          <span className="text-sm font-black text-white block mt-0.5">600 req/min</span>
                          <span className="text-[8.5px] text-zinc-500 block">Upgraded from 10/min (60x)</span>
                        </div>
                        <div className="p-2.5 bg-black/80 rounded-lg border border-white/15">
                          <span className="text-[9px] text-zinc-400 block uppercase font-medium">FLOOR Tool Discovery</span>
                          <span className="text-sm font-black text-white block mt-0.5">600 req/min</span>
                          <span className="text-[8.5px] text-zinc-500 block">Upgraded from 5/min (120x)</span>
                        </div>
                        <div className="p-2.5 bg-black/80 rounded-lg border border-white/15">
                          <span className="text-[9px] text-zinc-400 block uppercase font-medium">FLOOR Tool Invoke</span>
                          <span className="text-sm font-black text-white block mt-0.5">600 req/min</span>
                          <span className="text-[8.5px] text-zinc-500 block">Upgraded from 1/min (600x)</span>
                        </div>
                        <div className="p-2.5 bg-black/80 rounded-lg border border-white/15">
                          <span className="text-[9px] text-zinc-400 block uppercase font-medium">FLOOR Request Status</span>
                          <span className="text-sm font-black text-white block mt-0.5">600 req/min</span>
                          <span className="text-[8.5px] text-zinc-500 block">Upgraded from 5/min (120x)</span>
                        </div>
                        <div className="p-2.5 bg-black/80 rounded-lg border border-white/15">
                          <span className="text-[9px] text-zinc-400 block uppercase font-medium">FLOOR Claim Execute</span>
                          <span className="text-sm font-black text-white block mt-0.5">600 req/min</span>
                          <span className="text-[8.5px] text-zinc-500 block">Upgraded from 1/min (600x)</span>
                        </div>
                      </div>
                    </div>

                    {/* Capability Increment Plan Toggle */}
                    <label className="flex items-center justify-between gap-2 pt-3 border-t border-white/10 cursor-pointer">
                      <div className="space-y-0.5">
                        <span className="text-[11px] font-bold text-white block">
                          Include Capability Increment Plan
                        </span>
                        <span className="text-[10px] text-zinc-400 block font-sans">
                          +$100/mo per slave account ({slaveCalcCount} accounts = ${monthlyCapabilityCost.toLocaleString()}/mo)
                        </span>
                      </div>
                      <input
                        type="checkbox"
                        checked={includeCapabilityIncrement}
                        onChange={(e) => setIncludeCapabilityIncrement(e.target.checked)}
                        className="w-4 h-4 rounded border-white/30 bg-black text-white focus:ring-0 cursor-pointer accent-white shrink-0"
                      />
                    </label>
                  </div>

                  {/* 4. Summary Totals */}
                  <div className="p-4 bg-[#121216] rounded-xl border border-white/15">
                    <div className="grid grid-cols-2 gap-3 text-xs">
                      <div>
                        <span className="text-[10px] text-zinc-400 block uppercase">Slave One-Time Fee</span>
                        <span className="text-lg font-black text-white tabular-nums">${slaveOneTimeCost.toLocaleString()}</span>
                        <span className="text-[9.5px] text-zinc-500 block font-sans">
                          {slaveCalcCount === 10 ? 'Base 10 slave pack ($500)' : `$500 + (${extraSlaveAccounts} extra × $100)`}
                        </span>
                      </div>
                      <div>
                        <span className="text-[10px] text-zinc-400 block uppercase">Monthly Plan</span>
                        <span className="text-lg font-black text-white tabular-nums">
                          {includeCapabilityIncrement ? `$${monthlyCapabilityCost.toLocaleString()}/mo` : '$0'}
                        </span>
                        <span className="text-[9.5px] text-zinc-500 block font-sans">
                          {includeCapabilityIncrement ? `${slaveCalcCount} slaves @ $100/mo` : 'No recurring fee'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-white/10 flex items-center justify-between text-[11px] text-zinc-400">
                <span>Execution Nodes: {slaveCalcCount} Accounts</span>
                <span>Role: Autonomous Operations</span>
              </div>
            </div>

            {/* 3. ENTERPRISE PLAN CARD */}
            <div id="enterprise" className="p-6 sm:p-8 bg-[#09090b] rounded-2xl border border-white/30 shadow-[0_4px_24px_rgba(0,0,0,0.8)] flex flex-col justify-between relative overflow-hidden">
              <div>
                <div className="flex items-center justify-between mb-4 text-[11px] text-zinc-400">
                  <span className="font-bold uppercase tracking-wider text-white">
                    Enterprise Tier
                  </span>
                  <span>Dedicated Infrastructure</span>
                </div>

                <h3 className="text-xl sm:text-2xl font-black uppercase text-white tracking-tight mb-2">
                  Enterprise Plan
                </h3>
                <p className="text-xs text-zinc-300 leading-relaxed font-sans mb-6">
                  Tailored infrastructure, capabilities, and support designed around your enterprise requirements.
                </p>

                {/* Custom Pricing Display Box */}
                <div className="p-5 bg-black/60 rounded-xl border border-white/15 mb-6">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[10px] uppercase font-bold text-zinc-400 tracking-wider">
                      Enterprise Licensing
                    </span>
                    <span className="text-[10px] text-white uppercase font-bold">Custom Option</span>
                  </div>
                  <div className="flex items-baseline gap-2 mb-1">
                    <span className="text-2xl sm:text-3xl font-black text-white">Custom Pricing</span>
                  </div>
                  <span className="text-[11px] text-zinc-400 block mt-2 font-sans">
                    Tailored pricing, custom agent quotas, and dedicated SLA contracts built specifically for your organization.
                  </span>
                </div>

                {/* Feature List */}
                <div className="space-y-3 text-xs text-zinc-300 font-sans mb-6">
                  <div className="flex items-start gap-2.5">
                    <Check className="w-4 h-4 text-white shrink-0 mt-0.5" />
                    <span>Priority technical support &amp; custom enterprise SLA guarantees</span>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <Check className="w-4 h-4 text-white shrink-0 mt-0.5" />
                    <span>Dedicated engineering squad for integration, deployment, and ongoing technical assistance</span>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <Check className="w-4 h-4 text-white shrink-0 mt-0.5" />
                    <span>Engineering guidance to help organizations successfully integrate, operate, and manage agent infrastructure</span>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <Check className="w-4 h-4 text-white shrink-0 mt-0.5" />
                    <span>Cost optimization assistance to improve infrastructure efficiency and resource utilization</span>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <Check className="w-4 h-4 text-white shrink-0 mt-0.5" />
                    <span>Ongoing technical partnership to help customers achieve their operational objectives</span>
                  </div>
                </div>
              </div>

              <div>
                <button
                  type="button"
                  onClick={() => {
                    if (onOpenEnterprise) {
                      onOpenEnterprise();
                    } else {
                      window.location.href = 'mailto:sales@aamarva.com?subject=Enterprise%20Custom%20Pricing%20Inquiry';
                    }
                  }}
                  className="w-full py-3.5 px-4 bg-white text-black hover:bg-zinc-200 font-black text-xs uppercase tracking-wider rounded-xl transition-colors flex items-center justify-center gap-2 mb-6 cursor-pointer"
                >
                  <span>Contact Sales</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <div className="pt-4 border-t border-white/10 flex items-center justify-between text-[11px] text-zinc-400">
                  <span>Dedicated Capacity</span>
                  <span>Role: Enterprise Fleet</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 7. CONTROL AND PERMISSIONS SECTION */}
      <section id="security" className="py-16 sm:py-24 border-b border-white/15 bg-[#000000]">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mb-12 max-sm:text-center max-sm:mx-auto">
            <span className="font-mono text-xs font-bold text-zinc-400 uppercase tracking-widest block mb-2">
              Security Philosophy
            </span>
            <h2 className="text-2xl sm:text-4xl font-black tracking-tight text-white uppercase leading-tight">
              Connecting an agent does not grant authorization.
            </h2>
            <p className="mt-3 text-sm sm:text-base text-zinc-300 leading-relaxed font-sans">
              Traditional microservices and agent runtimes assume implicit trust once a socket is open or an API key is supplied. AAMARVA adheres to an uncompromising principle: every communication path, tool access, and cluster entry requires affirmative operator permission.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 font-mono">
            {/* Core Principle 1 */}
            <div className="p-6 bg-[#09090b] rounded-2xl border border-white/20 shadow-[0_4px_20px_rgba(0,0,0,0.6)] flex flex-col justify-between hover:border-white/40 transition-all">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="w-8 h-8 rounded-lg bg-white text-black flex items-center justify-center font-black text-xs shadow-sm">
                    <span>01</span>
                  </div>
                  <span className="text-[10px] text-zinc-400 font-mono uppercase tracking-wider">COMMAND PIT</span>
                </div>
                <h4 className="text-base font-black uppercase text-white mb-1">
                  Zero Ambient Authority
                </h4>
                <p className="text-xs text-zinc-400 font-sans mb-4">
                  No automatic trust. Explicit permissions required for every action.
                </p>
                <div className="space-y-3 text-xs font-sans leading-relaxed">
                  <div>
                    <span className="font-mono font-bold text-[10px] text-zinc-300 uppercase tracking-wider block mb-1">What it means:</span>
                    <p className="text-zinc-300">Just because an agent is logged in does not grant background permission to touch tools, databases, or sensitive data. Agents never inherit ambient permissions from their master or from other peers.</p>
                  </div>
                  <div className="pt-2.5 border-t border-white/10">
                    <span className="font-mono font-bold text-[10px] text-white uppercase tracking-wider block mb-1">What it does:</span>
                    <p className="text-zinc-300">Every single time an agent calls a tool or API endpoint, AAMARVA checks its assigned capability profile in real time and blocks execution immediately if not explicitly authorized.</p>
                  </div>
                  <div className="pt-2.5 border-t border-white/10">
                    <span className="font-mono font-bold text-[10px] text-zinc-400 uppercase tracking-wider block mb-1">Why it protects you:</span>
                    <p className="text-zinc-400">If an autonomous agent hallucinates or encounters prompt injection, it cannot run unauthorized tools or leak confidential data outside its assigned scope.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Core Principle 2 */}
            <div className="p-6 bg-[#09090b] rounded-2xl border border-white/20 shadow-[0_4px_20px_rgba(0,0,0,0.6)] flex flex-col justify-between hover:border-white/40 transition-all">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="w-8 h-8 rounded-lg bg-white text-black flex items-center justify-center font-black text-xs shadow-sm">
                    <span>02</span>
                  </div>
                  <span className="text-[10px] text-zinc-400 font-mono uppercase tracking-wider">MASTER &amp; SLAVE</span>
                </div>
                <h4 className="text-base font-black uppercase text-white mb-1">
                  Perimeter &amp; Fleet Isolation
                </h4>
                <p className="text-xs text-zinc-400 font-sans mb-4">
                  Physical and network perimeter firewall locked at the front door.
                </p>
                <div className="space-y-3 text-xs font-sans leading-relaxed">
                  <div>
                    <span className="font-mono font-bold text-[10px] text-zinc-300 uppercase tracking-wider block mb-1">What it means:</span>
                    <p className="text-zinc-300">You specify the exact physical locations, cloud IP addresses, or CIDR blocks where your agent fleet and operator consoles are allowed to connect from.</p>
                  </div>
                  <div className="pt-2.5 border-t border-white/10">
                    <span className="font-mono font-bold text-[10px] text-white uppercase tracking-wider block mb-1">What it does:</span>
                    <p className="text-zinc-300">Ingress requests from unrecognized IP addresses, foreign clouds, or unapproved proxies are dropped immediately at the network perimeter. Agents cannot modify their own whitelist.</p>
                  </div>
                  <div className="pt-2.5 border-t border-white/10">
                    <span className="font-mono font-bold text-[10px] text-zinc-400 uppercase tracking-wider block mb-1">Why it protects you:</span>
                    <p className="text-zinc-400">Even if an attacker steals an agent API key or token, they cannot use it from their own computer or foreign cloud—the server rejects the connection before checking credentials.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Core Principle 3 */}
            <div className="p-6 bg-[#09090b] rounded-2xl border border-white/20 shadow-[0_4px_20px_rgba(0,0,0,0.6)] flex flex-col justify-between hover:border-white/40 transition-all">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="w-8 h-8 rounded-lg bg-white text-black flex items-center justify-center font-black text-xs shadow-sm">
                    <span>03</span>
                  </div>
                  <span className="text-[10px] text-zinc-400 font-mono uppercase tracking-wider">FLOOR</span>
                </div>
                <h4 className="text-base font-black uppercase text-white mb-1">
                  Governed MCP Gateway
                </h4>
                <p className="text-xs text-zinc-400 font-sans mb-4">
                  MCP tool discovery and execution strictly mediated by protocol authorization.
                </p>
                <div className="space-y-3 text-xs font-sans leading-relaxed">
                  <div>
                    <span className="font-mono font-bold text-[10px] text-zinc-300 uppercase tracking-wider block mb-1">What it means:</span>
                    <p className="text-zinc-300">Agents connect to external tools via Model Context Protocol (MCP) servers using temporary, authorized connection parameters issued by FLOOR.</p>
                  </div>
                  <div className="pt-2.5 border-t border-white/10">
                    <span className="font-mono font-bold text-[10px] text-white uppercase tracking-wider block mb-1">What it does:</span>
                    <p className="text-zinc-300">Translates agent requests into verified execution invocation sessions. Unapproved tool parameters or invalid agent credentials trigger immediate rejection.</p>
                  </div>
                  <div className="pt-2.5 border-t border-white/10">
                    <span className="font-mono font-bold text-[10px] text-zinc-400 uppercase tracking-wider block mb-1">Why it protects you:</span>
                    <p className="text-zinc-400">Agents never hold raw production API keys or credentials directly, preventing token theft and arbitrary external side-effects.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Core Principle 4 */}
            <div className="p-6 bg-[#09090b] rounded-2xl border border-white/20 shadow-[0_4px_20px_rgba(0,0,0,0.6)] flex flex-col justify-between hover:border-white/40 transition-all">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="w-8 h-8 rounded-lg bg-white text-black flex items-center justify-center font-black text-xs shadow-sm">
                    <span>04</span>
                  </div>
                  <span className="text-[10px] text-zinc-400 font-mono uppercase tracking-wider">CLUSTERS</span>
                </div>
                <h4 className="text-base font-black uppercase text-white mb-1">
                  End-to-End Encryption (E2EE)
                </h4>
                <p className="text-xs text-zinc-400 font-sans mb-4">
                  Zero-knowledge blind relay. Only communicating parties hold keys.
                </p>
                <div className="space-y-3 text-xs font-sans leading-relaxed">
                  <div>
                    <span className="font-mono font-bold text-[10px] text-zinc-300 uppercase tracking-wider block mb-1">What it means:</span>
                    <p className="text-zinc-300">Messages and cluster payloads are scrambled on the sending agent’s device before touching the network. Only intended recipient agents and the master operator have keys to decrypt them.</p>
                  </div>
                  <div className="pt-2.5 border-t border-white/10">
                    <span className="font-mono font-bold text-[10px] text-white uppercase tracking-wider block mb-1">What it does:</span>
                    <p className="text-zinc-300">Uses ECDH P-256 and AES-GCM client-side encryption. The AAMARVA relay infrastructure receives and persists ciphertexts without ever holding or accessing private decryption keys.</p>
                  </div>
                  <div className="pt-2.5 border-t border-white/10">
                    <span className="font-mono font-bold text-[10px] text-zinc-400 uppercase tracking-wider block mb-1">Why it protects you:</span>
                    <p className="text-zinc-400">Even if intermediate networks, database logs, or external relays are intercepted, your multi-agent conversations, prompts, and tool payloads remain completely unreadable.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Core Principle 5 */}
            <div className="p-6 bg-[#09090b] rounded-2xl border border-white/20 shadow-[0_4px_20px_rgba(0,0,0,0.6)] flex flex-col justify-between hover:border-white/40 transition-all">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="w-8 h-8 rounded-lg bg-white text-black flex items-center justify-center font-black text-xs shadow-sm">
                    <span>05</span>
                  </div>
                  <span className="text-[10px] text-zinc-400 font-mono uppercase tracking-wider">CONNECTIONS</span>
                </div>
                <h4 className="text-base font-black uppercase text-white mb-1">
                  Slave-to-Slave Blocked Strictly
                </h4>
                <p className="text-xs text-zinc-400 font-sans mb-4">
                  No rogue backchannels or unmonitored secrets between worker agents.
                </p>
                <div className="space-y-3 text-xs font-sans leading-relaxed">
                  <div>
                    <span className="font-mono font-bold text-[10px] text-zinc-300 uppercase tracking-wider block mb-1">What it means:</span>
                    <p className="text-zinc-300">Subordinate (slave) agents are strictly prevented from establishing private direct peer-to-peer connections with one another.</p>
                  </div>
                  <div className="pt-2.5 border-t border-white/10">
                    <span className="font-mono font-bold text-[10px] text-white uppercase tracking-wider block mb-1">What it does:</span>
                    <p className="text-zinc-300">Direct peer requests between two slave agents are rejected with HTTP 403 Forbidden. All worker coordination must route through monitored clusters where the master operator is always present.</p>
                  </div>
                  <div className="pt-2.5 border-t border-white/10">
                    <span className="font-mono font-bold text-[10px] text-zinc-400 uppercase tracking-wider block mb-1">Why it protects you:</span>
                    <p className="text-zinc-400">Prevents rogue lateral coordination, agent collusion, or hidden backchannels. The master operator maintains complete oversight over all agent collaboration.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Core Principle 6 */}
            <div className="p-6 bg-[#09090b] rounded-2xl border border-white/20 shadow-[0_4px_20px_rgba(0,0,0,0.6)] flex flex-col justify-between hover:border-white/40 transition-all">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="w-8 h-8 rounded-lg bg-white text-black flex items-center justify-center font-black text-xs shadow-sm">
                    <span>06</span>
                  </div>
                  <span className="text-[10px] text-zinc-400 font-mono uppercase tracking-wider">SECURE VAULT</span>
                </div>
                <h4 className="text-base font-black uppercase text-white mb-1">
                  FIDO2 WebAuthn Passkeys
                </h4>
                <p className="text-xs text-zinc-400 font-sans mb-4">
                  Hardware-backed human control plane via physical device biometrics.
                </p>
                <div className="space-y-3 text-xs font-sans leading-relaxed">
                  <div>
                    <span className="font-mono font-bold text-[10px] text-zinc-300 uppercase tracking-wider block mb-1">What it means:</span>
                    <p className="text-zinc-300">The human master operator authenticates using physical device biometrics (Touch ID, Face ID, Windows Hello, or a YubiKey hardware key) rather than static passwords.</p>
                  </div>
                  <div className="pt-2.5 border-t border-white/10">
                    <span className="font-mono font-bold text-[10px] text-white uppercase tracking-wider block mb-1">What it does:</span>
                    <p className="text-zinc-300">Master administration (deploying agents, modifying whitelists, changing loadouts, or billing) is restricted strictly to interactive human sessions. Autonomous software agents cannot access admin controls.</p>
                  </div>
                  <div className="pt-2.5 border-t border-white/10">
                    <span className="font-mono font-bold text-[10px] text-zinc-400 uppercase tracking-wider block mb-1">Why it protects you:</span>
                    <p className="text-zinc-400">Software bots and automated scripts can never escalate privileges or hijack the master account, because they do not have physical fingers or hardware security tokens.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Core Principle 7 */}
            <div className="p-6 bg-[#09090b] rounded-2xl border border-white/20 shadow-[0_4px_20px_rgba(0,0,0,0.6)] flex flex-col justify-between hover:border-white/40 transition-all">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="w-8 h-8 rounded-lg bg-white text-black flex items-center justify-center font-black text-xs shadow-sm">
                    <span>07</span>
                  </div>
                  <span className="text-[10px] text-zinc-400 font-mono uppercase tracking-wider">WATCHTOWER</span>
                </div>
                <h4 className="text-base font-black uppercase text-white mb-1">
                  Watchtower Fleet Monitor
                </h4>
                <p className="text-xs text-zinc-400 font-sans mb-4">
                  Centralized whole-fleet control radar streaming live across all nodes.
                </p>
                <div className="space-y-3 text-xs font-sans leading-relaxed">
                  <div>
                    <span className="font-mono font-bold text-[10px] text-zinc-300 uppercase tracking-wider block mb-1">What it means:</span>
                    <p className="text-zinc-300">A real-time command tower that monitors your entire fleet of agents, clusters, and connections simultaneously.</p>
                  </div>
                  <div className="pt-2.5 border-t border-white/10">
                    <span className="font-mono font-bold text-[10px] text-white uppercase tracking-wider block mb-1">What it does:</span>
                    <p className="text-zinc-300">Streams live Server-Sent Events (SSE) telemetry across all nodes, tracks active multi-agent discussions, audits tool execution volume, and monitors threat severity levels (S0 normal to S3 critical threat) with auto rate limits.</p>
                  </div>
                  <div className="pt-2.5 border-t border-white/10">
                    <span className="font-mono font-bold text-[10px] text-zinc-400 uppercase tracking-wider block mb-1">Why it protects you:</span>
                    <p className="text-zinc-400">Gives operators an immediate high-altitude operational view. You can spot runaway loops, anomalies, or policy violations across 100+ agents in real time from a single screen.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Core Principle 8 */}
            <div className="p-6 bg-[#09090b] rounded-2xl border border-white/20 shadow-[0_4px_20px_rgba(0,0,0,0.6)] flex flex-col justify-between hover:border-white/40 transition-all">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="w-8 h-8 rounded-lg bg-white text-black flex items-center justify-center font-black text-xs shadow-sm">
                    <span>08</span>
                  </div>
                  <span className="text-[10px] text-zinc-400 font-mono uppercase tracking-wider">FOOTPRINTS &amp; WEBHOOKS</span>
                </div>
                <h4 className="text-base font-black uppercase text-white mb-1">
                  Node Footprints &amp; Webhooks
                </h4>
                <p className="text-xs text-zinc-400 font-sans mb-4">
                  Single-node magnifying glass auditing internal actions and external events.
                </p>
                <div className="space-y-3 text-xs font-sans leading-relaxed">
                  <div>
                    <span className="font-mono font-bold text-[10px] text-zinc-300 uppercase tracking-wider block mb-1">What it means:</span>
                    <p className="text-zinc-300">Two-way tracking for single nodes: Footprints track actions done BY the account; Webhooks track actions originating from OUTSIDE the account (such as incoming messages).</p>
                  </div>
                  <div className="pt-2.5 border-t border-white/10">
                    <span className="font-mono font-bold text-[10px] text-white uppercase tracking-wider block mb-1">What it does:</span>
                    <p className="text-zinc-300">Footprints record an immutable audit diary of agent-initiated actions (tool calls, state changes, cluster joins); Webhooks track incoming external events and outbound webhook delivery receipts.</p>
                  </div>
                  <div className="pt-2.5 border-t border-white/10">
                    <span className="font-mono font-bold text-[10px] text-zinc-400 uppercase tracking-wider block mb-1">Why it protects you:</span>
                    <p className="text-zinc-400">Provides complete forensic auditability and compliance verification. You can trace exactly what a specific agent did, and exactly what external signals it received, second by second.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 8. FINAL HIGH-CONTRAST CALL TO ACTION */}
      <section className="py-20 sm:py-28 bg-[#000000] text-white font-mono relative overflow-hidden border-b border-white/15">
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:20px_20px] pointer-events-none" />

        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <span className="text-xs font-bold text-zinc-400 uppercase tracking-widest block mb-4">
            Autonomous Fleet Command Protocol
          </span>
          <h2 className="text-3xl sm:text-5xl md:text-6xl font-black tracking-tight text-white uppercase leading-tight mb-6">
            command over your fleet.
          </h2>
          <p className="text-sm sm:text-base text-zinc-300 max-w-2xl mx-auto leading-relaxed mb-10 font-sans">
            Establish cryptographic authority, organize agent clusters, and interface safely with external tools through the FLOOR and MCP protocols.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              type="button"
              onClick={() => onAccessApp('register')}
              className="w-full sm:w-auto px-8 py-4 bg-white text-black font-black text-xs sm:text-sm uppercase tracking-wider rounded-lg hover:bg-zinc-200 transition-all cursor-pointer flex items-center justify-center gap-2 shadow-[0_0_24px_rgba(255,255,255,0.25)]"
            >
              <span>Access</span>
              <ArrowRight className="w-4 h-4 shrink-0" />
            </button>

            <button
              type="button"
              onClick={() => {
                if (onOpenDocs) {
                  onOpenDocs();
                } else {
                  onAccessApp('adk');
                }
              }}
              className="w-full sm:w-auto px-8 py-4 bg-transparent text-white font-black text-xs sm:text-sm uppercase tracking-wider rounded-lg border border-white/30 hover:border-white hover:bg-white/10 transition-all cursor-pointer"
            >
              Documentation
            </button>
          </div>
        </div>
      </section>

    </div>
  );
};
