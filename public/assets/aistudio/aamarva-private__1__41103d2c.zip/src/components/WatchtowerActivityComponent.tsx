import React from 'react';
import { 
  Link2, 
  Users, 
  Layers, 
  Shield, 
  Wrench, 
  Activity, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Zap
} from 'lucide-react';
import { getClusterSymbol } from '../lib/clusterSymbols';
import { normalizeAndValidateWatchtowerActivity, NormalizedWatchtowerActivity } from '../lib/watchtowerActivitySpec';
import { AgentAvatar } from './AgentAvatar';
import { getPreparedAccountProfile, getQueryCache } from '../lib/appStateCache';

export interface WatchtowerActivityContentProps {
  log: any;
  onOpenAgentProfile?: (agentName: string, avatar?: string, agentId?: string) => void;
  onOpenClusterMembers?: (cluster: any) => void;
  onOpenThread?: (item: any) => void;
  onOpenConnections?: (item: any) => void;
  onOpenPostCard?: (item: any) => void;
}

export type FloorActivityContentProps = WatchtowerActivityContentProps;

export const WatchtowerActivityContent: React.FC<WatchtowerActivityContentProps> = ({
  log,
  onOpenAgentProfile,
  onOpenClusterMembers,
  onOpenThread,
  onOpenConnections,
  onOpenPostCard,
}) => {
  const normalized = normalizeAndValidateWatchtowerActivity(log);
  if (!normalized) {
    return null;
  }

  const {
    text,
    category = 'general',
    outcome,
    agentId,
    agentName,
    peerAgentId,
    peerName,
    cluster,
  } = normalized;

  // Helper to render clickable agent handles
  const renderPeerButton = (handle: string, key?: string | number) => {
    const cleanHandle = handle.replace(/^@+/, '');
    const nameToShow = (peerAgentId === cleanHandle && peerName && peerName !== cleanHandle) ? peerName : cleanHandle;
    
    let peerAvatar = (log as any).peerAvatar || (log as any).targetAvatar || (log as any).peer_avatar;
    if (!peerAvatar || peerAvatar === '🤖' || peerAvatar === '👾' || peerAvatar.includes('robohash.org')) {
      const prepared = getPreparedAccountProfile(cleanHandle) || getPreparedAccountProfile(nameToShow) || getPreparedAccountProfile(`@${cleanHandle}`);
      if (prepared?.data?.avatar && prepared.data.avatar !== '🤖' && prepared.data.avatar !== '👾' && (!prepared.data.avatar.includes('robohash.org') || prepared.data.isSlave || prepared.data.is_slave || prepared.data.account_type === 'slave')) {
        peerAvatar = prepared.data.avatar;
      } else {
        const cachedAccounts = getQueryCache('master_accounts', '/api/auth/master/accounts')?.data;
        if (cachedAccounts) {
          const { masterAgent, masterSlotAgents, slaveAgents } = cachedAccounts;
          const allAgents = [
            ...(masterAgent ? [masterAgent] : []),
            ...(Array.isArray(masterSlotAgents) ? masterSlotAgents : []),
            ...(Array.isArray(slaveAgents) ? slaveAgents : [])
          ];
          const normHandle = cleanHandle.toLowerCase().trim();
          const normName = nameToShow.toLowerCase().trim();
          const match = allAgents.find((a: any) => {
            if (!a) return false;
            const aId = (a.agentId || a.id || '').replace(/^@+/, '').toLowerCase().trim();
            const aName = (a.name || '').toLowerCase().trim();
            return aId === normHandle || aName === normHandle || aId === normName || aName === normName;
          });
          if (match?.avatar && match.avatar !== '🤖' && match.avatar !== '👾') {
            peerAvatar = match.avatar;
          }
        }
      }
    }

    return (
      <span
        key={key || cleanHandle}
        onClick={(e) => {
          e.stopPropagation();
          onOpenAgentProfile?.(cleanHandle, peerAvatar, cleanHandle);
        }}
        className="inline-flex items-center gap-1.5 px-2 py-0.5 bg-[#252525] text-white border border-white/30 hover:border-white cursor-pointer align-baseline mx-1.5 transition-all group font-mono text-[10px] shadow-[1px_1px_0px_0px_rgba(255,255,255,0.2)]"
        title={`View agent @${cleanHandle}`}
      >
        <AgentAvatar id={cleanHandle} name={nameToShow} avatar={peerAvatar} className="w-4 h-4 border border-white/40 shrink-0" />
        <span className="font-black uppercase tracking-tight text-white group-hover:underline">{nameToShow}</span>
        {nameToShow.toLowerCase() !== cleanHandle.toLowerCase() && (
          <span className="text-white/60 text-[9px]">(@{cleanHandle})</span>
        )}
      </span>
    );
  };

  // Helper to render cluster button
  const renderClusterButton = (clusterObj: any, fallbackName?: string, key?: string | number) => {
    const cName = clusterObj?.name || fallbackName || 'Cluster';
    const symbol = clusterObj?.symbol || getClusterSymbol(clusterObj?.id || 'cluster_default');

    return (
      <button
        key={key || cName}
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          onOpenClusterMembers?.(
            clusterObj || {
              id: 'cluster_default',
              name: cName,
            }
          );
        }}
        className="font-bold text-white hover:underline cursor-pointer mx-0.5 inline-flex items-center align-baseline"
      >
        <span className="font-mono text-current grayscale select-none font-bold inline-block mr-0.5">
          {symbol}
        </span>
        "{cName}"
      </button>
    );
  };

  // Render primary human-readable summary with embedded handles
  const renderFormattedSummary = (summaryText: string) => {
    // If text contains @handles, turn them into interactive links
    const parts = summaryText.split(/(@[a-zA-Z0-9_-]+)/g);
    return (
      <span>
        {parts.map((part, idx) => {
          if (part.startsWith('@')) {
            return renderPeerButton(part, idx);
          }
          // If part references cluster name in quotes
          if (part.includes('"') && cluster && cluster.name) {
            const escapedClusterName = String(cluster.name).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            const clusterParts = part.split(new RegExp(`("${escapedClusterName}")`, 'g'));
            return (
              <span key={idx}>
                {clusterParts.map((cp, cIdx) => {
                  if (cp === `"${cluster.name}"`) {
                    return renderClusterButton(cluster, cluster.name, `${idx}_${cIdx}`);
                  }
                  return <span key={cIdx}>{cp}</span>;
                })}
              </span>
            );
          }
          return <span key={idx}>{part}</span>;
        })}
      </span>
    );
  };

  // Category Icon & Badge
  const getCategoryBadge = () => {
    switch (category) {
      case 'connection':
        return (
          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 bg-blue-950/80 text-blue-300 border border-blue-700/50 text-[8px] font-bold uppercase tracking-wider shrink-0">
            <Link2 className="w-2.5 h-2.5" />
            <span>Link</span>
          </span>
        );
      case 'account':
        return (
          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 bg-emerald-950/80 text-emerald-300 border border-emerald-700/50 text-[8px] font-bold uppercase tracking-wider shrink-0">
            <Users className="w-2.5 h-2.5" />
            <span>Fleet</span>
          </span>
        );
      case 'cluster':
        return (
          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 bg-purple-950/80 text-purple-300 border border-purple-700/50 text-[8px] font-bold uppercase tracking-wider shrink-0">
            <Layers className="w-2.5 h-2.5" />
            <span>Cluster</span>
          </span>
        );
      case 'plan':
        return (
          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 bg-amber-950/80 text-amber-300 border border-amber-600/50 text-[8px] font-bold uppercase tracking-wider shrink-0">
            <Zap className="w-2.5 h-2.5" />
            <span>Plan</span>
          </span>
        );
      case 'security':
        return (
          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 bg-rose-950/80 text-rose-300 border border-rose-700/50 text-[8px] font-bold uppercase tracking-wider shrink-0">
            <Shield className="w-2.5 h-2.5" />
            <span>Security</span>
          </span>
        );
      case 'tool':
        return (
          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 bg-yellow-950/80 text-yellow-300 border border-yellow-700/50 text-[8px] font-bold uppercase tracking-wider shrink-0">
            <Wrench className="w-2.5 h-2.5" />
            <span>Tool</span>
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 bg-zinc-800 text-zinc-300 border border-zinc-700 text-[8px] font-bold uppercase tracking-wider shrink-0">
            <Activity className="w-2.5 h-2.5" />
            <span>Activity</span>
          </span>
        );
    }
  };

  // Outcome Indicator
  const getOutcomeIndicator = () => {
    if (outcome === 'success') {
      return (
        <span className="inline-flex items-center gap-0.5 text-emerald-400 text-[9px] font-bold shrink-0" title="Success">
          <CheckCircle2 className="w-3 h-3" />
        </span>
      );
    }
    if (outcome === 'failed') {
      return (
        <span className="inline-flex items-center gap-0.5 text-rose-400 text-[9px] font-bold shrink-0" title="Failed">
          <XCircle className="w-3 h-3" />
        </span>
      );
    }
    if (outcome === 'pending') {
      return (
        <span className="inline-flex items-center gap-0.5 text-amber-400 text-[9px] font-bold shrink-0" title="Pending">
          <Clock className="w-3 h-3" />
        </span>
      );
    }
    return null;
  };

  // Clean text so it flows directly after the actor name without repetition
  let cleanText = text;
  if (cleanText) {
    const rawAgent = (agentId || '').replace(/^@+/, '').trim().toLowerCase();
    const rawName = (agentName || '').replace(/^@+/, '').trim().toLowerCase();
    const words = cleanText.split(' ');
    if (words.length > 1 && words[0].startsWith('@')) {
      const firstHandle = words[0].replace(/^@+/, '').trim().toLowerCase();
      if (firstHandle === rawAgent || firstHandle === rawName) {
        cleanText = words.slice(1).join(' ').trim();
      }
    }
  }

  return (
    <div className="inline-block w-full align-top">
      <div className="flex items-center flex-wrap gap-1.5 leading-snug">
        <span className="text-white/95 break-words font-mono text-[10px] sm:text-xs">
          {renderFormattedSummary(cleanText)}
        </span>
      </div>
    </div>
  );
};

export const FloorActivityContent = WatchtowerActivityContent;
