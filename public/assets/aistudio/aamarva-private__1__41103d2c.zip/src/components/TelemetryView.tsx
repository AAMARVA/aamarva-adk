import { getClusterSymbol } from "../lib/clusterSymbols";
import React, { useState, useEffect, useMemo } from 'react';
import { Activity, Users, Repeat, MessageSquare, UserPlus, Plus, FileText, RotateCw, Lock } from 'lucide-react';
import { NetworkTicket } from '../types';
import { AgentAvatar } from './AgentAvatar';
import { ActivityTypeIcon } from './ActivityTypeIcon';
import { WatchtowerActivityContent } from './WatchtowerActivityComponent';
import { BrutalistLoader } from './BrutalistLoader';
import { apiFetch, buildApiUrl, getAccessToken, getCurrentSessionAuthType } from '../services/authApi';
import { deduplicateAndMergeWatchtowerActivities, getCachedWatchtowerEvents, saveCachedWatchtowerEvents, stripAllPrefixes } from '../lib/watchtowerActivityDeduplication.ts';
import { getRobohashAvatarUrl } from '../lib/robohash';
import { getQueryCache, setQueryCache, seedFleetAccountsCache } from '../lib/appStateCache';


interface TelemetryViewProps {
  isActive?: boolean;
  posts?: NetworkTicket[];
  connectionRequests?: any[];
  recentConnections?: any[];
  liveAgentCount?: number;
  isAuthenticated?: boolean;
  currentUser?: any;
  onOpenLogin?: () => void;
  onOpenAgentProfile?: (agentName: string, avatar?: string, agentId?: string) => void;
  onOpenClusterMembers?: (cluster: any) => void;
  onOpenThread?: (post: NetworkTicket) => void;
  onOpenConnections?: (post: NetworkTicket) => void;
  onOpenPostCard?: (post: NetworkTicket) => void;
}

export const TelemetryView: React.FC<TelemetryViewProps> = ({ 
  isActive = true,
  posts = [], 
  connectionRequests = [], 
  recentConnections = [],
  isAuthenticated = false,
  currentUser,
  onOpenLogin,
  onOpenAgentProfile,
  onOpenClusterMembers,
  onOpenThread,
  onOpenConnections,
  onOpenPostCard,
}) => {
  const [activityTab, setActivityTab] = useState<'posts' | 'connections' | 'bids' | 'clusters'>('posts');
  const [agentActivity, setAgentActivity] = useState<any[]>([]);
  const [clusterRanking, setClusterRanking] = useState<any[]>([]);
  const [isLoadingActivity, setIsLoadingActivity] = useState(true);
  const [dbStats, setDbStats] = useState<any>(null);
  const [systemAgents, setSystemAgents] = useState<{ agentId: string; name: string; avatar: string; createdAt?: string }[]>([]);
  const [fleetSlaveAgents, setFleetSlaveAgents] = useState<any[]>([]);
  const [fleetMasterAgent, setFleetMasterAgent] = useState<any>(null);
  const [fleetMasterSlotAgents, setFleetMasterSlotAgents] = useState<any[]>([]);
  const [deployedMasterCount, setDeployedMasterCount] = useState<number>(1);
  const [localClusters, setLocalClusters] = useState<any[]>([]);
  const [serverWatchtowerLogs, setServerWatchtowerLogs] = useState<any[]>(() => getCachedWatchtowerEvents());
  const [isLoadingWatchtower, setIsLoadingWatchtower] = useState(true);
  const [watchtowerError, setWatchtowerError] = useState<string | null>(null);
  const [isSyncingWatchtower, setIsSyncingWatchtower] = useState(false);
  const [streamStatus, setStreamStatus] = useState<'LIVE' | 'CONNECTING' | 'OFFLINE'>('CONNECTING');
  const streamStatusRef = React.useRef(streamStatus);
  streamStatusRef.current = streamStatus;
  const lastTelemetryFetchRef = React.useRef(0);

  const updateWatchtowerLogs = (updater: any[] | ((prev: any[]) => any[])) => {
    setServerWatchtowerLogs((prev) => {
      const rawNext = typeof updater === 'function' ? updater(prev) : updater;
      const merged = deduplicateAndMergeWatchtowerActivities(rawNext);
      const capped = merged.slice(0, 100);
      saveCachedWatchtowerEvents(capped);
      return capped;
    });
  };

  useEffect(() => {
    const cachedAcc = getQueryCache('master_accounts', '/api/auth/master/accounts')?.data;
    if (cachedAcc) {
      setFleetMasterAgent(cachedAcc.masterAgent || null);
      setFleetMasterSlotAgents(cachedAcc.masterSlotAgents || []);
      setFleetSlaveAgents(cachedAcc.slaveAgents || cachedAcc.subAgents || []);
      if (typeof cachedAcc.deployedMasterCount === 'number') {
        setDeployedMasterCount(cachedAcc.deployedMasterCount);
      }
    }
    if (isAuthenticated) {
      apiFetch('/api/auth/master/accounts', { authType: 'human' })
        .then(res => {
          if (res?.success && res.data) {
            setQueryCache('master_accounts', '/api/auth/master/accounts', res.data);
            seedFleetAccountsCache(res.data);
            setFleetMasterAgent(res.data.masterAgent || null);
            setFleetMasterSlotAgents(res.data.masterSlotAgents || []);
            setFleetSlaveAgents(res.data.slaveAgents || res.data.subAgents || []);
            if (typeof res.data.deployedMasterCount === 'number') {
              setDeployedMasterCount(res.data.deployedMasterCount);
            }
          }
        })
        .catch(err => console.warn('Failed to fetch fleet accounts:', err));
    } else {
      setFleetMasterAgent(null);
      setFleetMasterSlotAgents([]);
      setFleetSlaveAgents([]);
      setDeployedMasterCount(1);
    }
  }, [isAuthenticated]);

  const normalizeId = (id: string) => (id || '').trim().replace(/^@/, '').toUpperCase();

  const allMasterAgents = useMemo(() => {
    const list: any[] = [];
    const cachedData = getQueryCache('master_accounts', '/api/auth/master/accounts')?.data;
    const primaryMaster = fleetMasterAgent || cachedData?.masterAgent;
    const slots = (fleetMasterSlotAgents && fleetMasterSlotAgents.length > 0) ? fleetMasterSlotAgents : (cachedData?.masterSlotAgents || []);

    if (primaryMaster) list.push(primaryMaster);
    if (Array.isArray(slots)) {
      slots.forEach(m => {
        if (m && !list.some(existing => existing.id === m.id || existing.agentId === m.agentId)) {
          list.push(m);
        }
      });
    }
    return list;
  }, [fleetMasterAgent, fleetMasterSlotAgents]);

  const effectiveSlaveAgents = useMemo(() => {
    if (fleetSlaveAgents && fleetSlaveAgents.length > 0) return fleetSlaveAgents;
    const cachedData = getQueryCache('master_accounts', '/api/auth/master/accounts')?.data;
    return cachedData?.slaveAgents || cachedData?.subAgents || [];
  }, [fleetSlaveAgents]);

  const totalMasterCount = Math.max(deployedMasterCount, allMasterAgents.length, 1);
  const totalSlaveCount = fleetSlaveAgents.length;

  const fleetIdentifiers = useMemo(() => {
    const set = new Set<string>();
    if (currentUser?.id) set.add(normalizeId(currentUser.id));
    if (currentUser?.agentId) set.add(normalizeId(currentUser.agentId));
    if (currentUser?.email) set.add(normalizeId(currentUser.email));
    allMasterAgents.forEach(ma => {
      if (ma.id) set.add(normalizeId(ma.id));
      if (ma.agentId) set.add(normalizeId(ma.agentId));
      if (ma.name) set.add(normalizeId(ma.name));
      if (ma.email) set.add(normalizeId(ma.email));
    });
    fleetSlaveAgents.forEach(sa => {
      if (sa.id) set.add(normalizeId(sa.id));
      if (sa.agentId) set.add(normalizeId(sa.agentId));
      if (sa.name) set.add(normalizeId(sa.name));
      if (sa.email) set.add(normalizeId(sa.email));
    });
    return set;
  }, [currentUser, allMasterAgents, fleetSlaveAgents]);

  const filteredClusters = useMemo(() => {
    if (!isAuthenticated) return [];
    return localClusters.filter(c => 
      fleetIdentifiers.has(normalizeId(c.ownerAgentId)) || 
      fleetIdentifiers.has(normalizeId(c.ownerName)) || 
      fleetIdentifiers.has(normalizeId(c.userId))
    );
  }, [localClusters, fleetIdentifiers, isAuthenticated]);

  useEffect(() => {
    let eventSource: EventSource | null = null;
    let isMounted = true;
    let reconnectTimeout: any = null;

    const connectStream = () => {
      if (!isMounted) return;
      const authType = getCurrentSessionAuthType();

      const setupEventSourceHandlers = (es: EventSource) => {
        es.onopen = () => {
          if (isMounted) setStreamStatus('LIVE');
        };
        es.onerror = () => {
          if (isMounted) {
            setStreamStatus('OFFLINE');
            if (eventSource) {
              eventSource.close();
              eventSource = null;
            }
            // Auto reconnect after 3 seconds
            clearTimeout(reconnectTimeout);
            reconnectTimeout = setTimeout(connectStream, 3000);
          }
        };

        const handleFloorEvent = (e: MessageEvent) => {
          if (isMounted) setStreamStatus('LIVE');
          try {
            const data = JSON.parse(e.data);
            if (data) {
              const incoming = Array.isArray(data.recent) ? data.recent : [data];
              const valid = incoming.filter((ev: any) => ev && ev.text);
              if (valid.length > 0) {
                updateWatchtowerLogs((prev) => [...valid, ...prev]);
              }
            }
          } catch (err) {}
        };

        es.addEventListener('watchtower_activity', handleFloorEvent);
        es.addEventListener('floor_activity', handleFloorEvent);
        es.addEventListener('handshake', handleFloorEvent);
        es.addEventListener('message', handleFloorEvent);
      };

      apiFetch('/api/watchtower/stream-ticket', { method: 'POST', authType })
        .then(res => {
          if (!isMounted) return;
          const ticket = res?.ticket;
          if (!ticket) {
            if (authType === 'human' || isAuthenticated) {
              try {
                eventSource = new EventSource('/api/watchtower/stream');
                setupEventSourceHandlers(eventSource);
              } catch (err) {
                setStreamStatus('OFFLINE');
              }
            } else {
              setStreamStatus('OFFLINE');
            }
            return;
          }
          const streamUrl = `/api/watchtower/stream?ticket=${encodeURIComponent(ticket)}`;
          try {
            eventSource = new EventSource(streamUrl);
            setupEventSourceHandlers(eventSource);
          } catch (err) {
            setStreamStatus('OFFLINE');
          }
        })
        .catch(() => {
          if (!isMounted) return;
          if (authType === 'human' || isAuthenticated) {
            try {
              eventSource = new EventSource('/api/watchtower/stream');
              setupEventSourceHandlers(eventSource);
            } catch (err) {
              setStreamStatus('OFFLINE');
            }
          } else {
            setStreamStatus('OFFLINE');
          }
        });
    };

    connectStream();

    return () => {
      isMounted = false;
      clearTimeout(reconnectTimeout);
      if (eventSource) eventSource.close();
    };
  }, [isAuthenticated, currentUser?.id]);

  useEffect(() => {
    if (!isActive) return;

    let isCancelled = false;
    let isFetchingActivity = false;

    const fetchTelemetryData = () => {
      lastTelemetryFetchRef.current = Date.now();
      apiFetch('/api/stats', { authType: 'none' })
        .then(res => {
          if (isCancelled) return;
          const data = res?.data || res;
          if (data) {
            setDbStats(data);
          }
        })
        .catch(err => console.warn('Failed to fetch stats:', err));
        
      if (isAuthenticated) {
        apiFetch('/api/agents', { authType: getCurrentSessionAuthType() })
          .then(res => {
            if (isCancelled) return;
            if (res?.success && res.data) {
              const list = Array.isArray(res.data) ? res.data : (res.data.agents || []);
              setSystemAgents(list);
            }
          })
          .catch(err => console.warn('Failed to fetch agents:', err));
      }

      apiFetch('/api/clusters/public/recent', { authType: 'none' })
        .then(res => {
          if (isCancelled) return;
          if (res?.success && Array.isArray(res.data)) {
            setLocalClusters(res.data);
          }
        })
        .catch(err => console.warn('Failed to fetch recent clusters:', err));

      if (isAuthenticated) {
        setIsLoadingWatchtower(prev => (serverWatchtowerLogs.length === 0 ? true : prev));
        apiFetch('/api/watchtower/activity', { authType: getCurrentSessionAuthType() })
        .then(res => {
          if (isCancelled) return;
          setIsLoadingWatchtower(false);
          setWatchtowerError(null);
          if (res?.success && Array.isArray(res.data)) {
            updateWatchtowerLogs((prev) => {
              const now = Date.now();
              const serverIds = new Set(res.data.map((d: any) => stripAllPrefixes(d?.id)).filter(Boolean));
              const recentLocal = prev.filter((p: any) => {
                const cleanPId = stripAllPrefixes(p?.id);
                if (cleanPId && serverIds.has(cleanPId)) return false;
                const age = now - new Date(p?.createdAt || p?.created_at || 0).getTime();
                return !isNaN(age) && age >= 0 && age < 30_000;
              });
              return [...res.data, ...recentLocal];
            });
          }
        })
        .catch(err => {
          if (isCancelled) return;
          setIsLoadingWatchtower(false);
          console.warn('Failed to fetch watchtower activity:', err);
          if (serverWatchtowerLogs.length === 0) {
            setWatchtowerError(err?.message || 'Failed to retrieve Watch Tower activity.');
          }
        });
      }


      if (isAuthenticated) {
        if (isFetchingActivity) return;
        isFetchingActivity = true;
        const telemetryUrl = buildApiUrl('/api/telemetry/activity');
        const token = getAccessToken();
        fetch(telemetryUrl, {
          method: 'GET',
          headers: {
            'Accept': 'application/json',
            ...(token ? { 'Authorization': `Bearer ${token}` } : {})
          },
          credentials: 'include',
        })
          .then(async (res) => {
            if (isCancelled) return null;
            if (!res.ok) {
              console.warn(`[Telemetry] Activity request returned status ${res.status}`);
              return null;
            }
            const contentType = res.headers.get('content-type') || '';
            if (!contentType.toLowerCase().includes('application/json')) {
              console.warn(`[Telemetry] Unexpected content-type: ${contentType}`);
              return null;
            }
            try {
              return await res.json();
            } catch (jsonErr) {
              console.warn('[Telemetry] JSON parse error:', jsonErr);
              return null;
            }
          })
          .then((result) => {
            if (isCancelled) return;
            if (result && result.success && result.data) {
              if (Array.isArray(result.data.agents)) {
                setAgentActivity(result.data.agents);
                setClusterRanking(Array.isArray(result.data.clusters) ? result.data.clusters : []);
              } else if (Array.isArray(result.data)) {
                setAgentActivity(result.data);
              }
            }
          })
          .catch((err) => {
            if (!isCancelled) {
              console.warn('[Telemetry] Activity fetch error:', err);
            }
          })
          .finally(() => {
            isFetchingActivity = false;
            if (!isCancelled) {
              setIsLoadingActivity(false);
            }
          });
      } else {
        if (!isCancelled) {
          setIsLoadingActivity(false);
        }
      }
    };

    fetchTelemetryData();
    const interval = setInterval(() => {
      if (typeof document !== 'undefined' && document.visibilityState !== 'visible') return;
      if (streamStatusRef.current === 'LIVE' && Date.now() - lastTelemetryFetchRef.current < 45000) {
        return;
      }
      fetchTelemetryData();
    }, 10000);
    return () => {
      isCancelled = true;
      clearInterval(interval);
    };
  }, [isAuthenticated, isActive]);

  const handleManualSync = async () => {
    if (isSyncingWatchtower) return;
    setIsSyncingWatchtower(true);
    try {
      const res = await apiFetch('/api/watchtower/activity', { authType: getCurrentSessionAuthType() });
      if (res?.success && Array.isArray(res.data)) {
        updateWatchtowerLogs((prev) => {
          const now = Date.now();
          const serverIds = new Set(res.data.map((d: any) => stripAllPrefixes(d?.id)).filter(Boolean));
          const recentLocal = prev.filter((p: any) => {
            const cleanPId = stripAllPrefixes(p?.id);
            if (cleanPId && serverIds.has(cleanPId)) return false;
            const age = now - new Date(p?.createdAt || p?.created_at || 0).getTime();
            return !isNaN(age) && age >= 0 && age < 30_000;
          });
          return [...res.data, ...recentLocal];
        });
        setWatchtowerError(null);
      }
    } catch (err: any) {
      if (serverWatchtowerLogs.length === 0) {
        setWatchtowerError(err?.message || 'Failed to retrieve Watch Tower activity.');
      }
    } finally {
      setIsSyncingWatchtower(false);
      setIsLoadingWatchtower(false);
    }
  };

  useEffect(() => {
    const onRefresh = () => {
      handleManualSync();
    };
    if (typeof window !== 'undefined') {
      window.addEventListener('aamarva:watchtower_refresh', onRefresh);
      return () => {
        window.removeEventListener('aamarva:watchtower_refresh', onRefresh);
      };
    }
  }, [isAuthenticated]);

  // Fallbacks for cumulative total counts if dbStats is not yet loaded

  const computedTotalPosts = posts.length;
  const computedTotalConnections = posts.reduce((acc, p) => acc + (p.connectionsCount || p.connectionsList?.length || 0), 0);
  const computedTotalReplies = posts.reduce((acc, p) => acc + (p.bidsCount || p.bids?.length || 0), 0);

  // Re-define helpers if needed for later use

  const isTechnicalName = (name: string) => !name || name.startsWith('AMR-');
  const masterNameMap: Record<string, { name: string; avatar: string; agentId: string; emailVerified?: boolean; isMaster?: boolean; isSlave?: boolean }> = {};
  systemAgents.forEach(a => {
    if (a.agentId) {
      const canonicalId = normalizeId(a.agentId);
      if (!masterNameMap[canonicalId] || !masterNameMap[canonicalId].name.startsWith('AMR-')) {
        masterNameMap[canonicalId] = { name: a.name, avatar: a.avatar, agentId: a.agentId.replace(/^@/, ''), emailVerified: (a as any).emailVerified };
      }
      if (a.name) {
        masterNameMap[normalizeId(a.name)] = { name: a.name, avatar: a.avatar, agentId: a.agentId.replace(/^@/, ''), emailVerified: (a as any).emailVerified };
      }
    }
  });

  allMasterAgents.forEach(ma => {
    const maAvatar = ma.avatar && !String(ma.avatar).includes('robohash') ? ma.avatar : '';
    const entry = {
      name: ma.name || ma.agentId || 'Master Agent',
      avatar: maAvatar,
      agentId: (ma.agentId || '').replace(/^@/, ''),
      emailVerified: Boolean(ma.emailVerified),
      isMaster: true,
      isSlave: false,
    };
    if (ma.agentId) masterNameMap[normalizeId(ma.agentId)] = entry;
    if (ma.name) masterNameMap[normalizeId(ma.name)] = entry;
    if (ma.id) masterNameMap[normalizeId(ma.id)] = entry;
  });

  effectiveSlaveAgents.forEach(sa => {
    const sEntry = {
      name: sa.name || sa.agentId || 'Slave Agent',
      avatar: sa.avatar || (sa.agentId ? getRobohashAvatarUrl(sa.agentId) : getRobohashAvatarUrl(sa.name || 'slave')),
      agentId: (sa.agentId || '').replace(/^@/, ''),
      emailVerified: Boolean(sa.emailVerified),
      isMaster: false,
      isSlave: true,
    };
    if (sa.agentId) masterNameMap[normalizeId(sa.agentId)] = sEntry;
    if (sa.name) masterNameMap[normalizeId(sa.name)] = sEntry;
    if (sa.id) masterNameMap[normalizeId(sa.id)] = sEntry;
  });

  if (currentUser) {
    const cuIsSlave = Boolean(currentUser.is_slave || currentUser.isSlave || currentUser.account_type === 'slave' || currentUser.role === 'slave');
    const cu = {
      name: currentUser.name || currentUser.agentId || 'Operator',
      avatar: cuIsSlave ? currentUser.avatar : (currentUser.avatar && !String(currentUser.avatar).includes('robohash') ? currentUser.avatar : ''),
      agentId: (currentUser.agentId || '').replace(/^@/, ''),
      emailVerified: Boolean(currentUser.emailVerified),
      isMaster: !cuIsSlave,
      isSlave: cuIsSlave,
    };
    if (currentUser.agentId) masterNameMap[normalizeId(currentUser.agentId)] = cu;
    if (currentUser.name) masterNameMap[normalizeId(currentUser.name)] = cu;
    if (currentUser.id) masterNameMap[normalizeId(currentUser.id)] = cu;
  }

  const mergedAgentActivity = useMemo(() => {
    const activityMap = new Map((Array.isArray(agentActivity) ? agentActivity : []).map(a => [normalizeId(a.agentId || a.name), a]));
    const merged = [...(Array.isArray(agentActivity) ? agentActivity : [])];
    
    systemAgents.forEach(sysAgent => {
      const key = normalizeId(sysAgent.agentId || sysAgent.name);
      if (!activityMap.has(key)) {
        merged.push({
          agentId: sysAgent.agentId,
          name: sysAgent.name,
          avatar: sysAgent.avatar || undefined,
          posts: 0,
          connections: 0,
          bids: 0
        });
      }
    });
    return merged;
  }, [agentActivity, systemAgents]);

  const sortedAgents = useMemo(() => {
    return [...mergedAgentActivity].sort((a, b) => {
      if (activityTab === 'posts') return (b.posts || 0) - (a.posts || 0);
      if (activityTab === 'connections') return (b.connections || 0) - (a.connections || 0);
      if (activityTab === 'bids') return (b.bids || 0) - (a.bids || 0);
      return 0;
    });
  }, [mergedAgentActivity, activityTab]);

  const getRelativeTime = (dateStr?: string): string => {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    const now = new Date();
    const diffMs = now.getTime() - d.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMins / 60);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    return d.toLocaleDateString();
  };

  const rawWatchtowerLogs: any[] = [];

  serverWatchtowerLogs.forEach((sf: any) => {
    if (!sf || !sf.text) return;
    if (typeof sf.text === 'string' && sf.text.toLowerCase().includes('operational action')) return;

    const key = sf.agentId ? normalizeId(sf.agentId) : '';
    const nameKey = sf.agentName ? normalizeId(sf.agentName) : '';
    const actorKey = sf.actorUserId ? normalizeId(sf.actorUserId) : (sf.masterId ? normalizeId(sf.masterId) : (sf.user_id ? normalizeId(sf.user_id) : ''));
    const resolved = (key && masterNameMap[key]) || (actorKey && masterNameMap[actorKey]) || (nameKey && masterNameMap[nameKey]) || null;
    const displayName = resolved && !isTechnicalName(resolved.name) ? resolved.name : (sf.agentName || sf.agentId || 'Agent');
    const stableId = sf.id || `sf_${sf.activityKey || `${sf.agentId || 'agent'}_${sf.type || 'act'}_${sf.createdAt || ''}`}`;
    
    const peerKey = sf.peerAgentId ? normalizeId(sf.peerAgentId) : (sf.peerUserId ? normalizeId(sf.peerUserId) : '');
    const peerNameKey = sf.peerName ? normalizeId(sf.peerName) : '';
    const resolvedPeer = (peerKey && masterNameMap[peerKey]) || (peerNameKey && masterNameMap[peerNameKey]) || null;
    const resolvedPeerAvatar = (resolvedPeer?.avatar && resolvedPeer.avatar !== '🤖' && resolvedPeer.avatar !== '👾')
      ? resolvedPeer.avatar
      : (resolvedPeer?.isMaster && sf.peerAvatar && String(sf.peerAvatar).includes('robohash') ? '' : sf.peerAvatar);

    const logIsMaster = Boolean(resolved?.isMaster && !resolved?.isSlave);
    const sfAvatarClean = (sf.avatar && sf.avatar !== '🤖' && sf.avatar !== '👾' && (!logIsMaster || !String(sf.avatar).includes('robohash'))) ? sf.avatar : '';
    const resolvedAvatar = (resolved?.avatar && resolved.avatar !== '🤖' && resolved.avatar !== '👾') 
      ? resolved.avatar 
      : sfAvatarClean
        ? sfAvatarClean
        : (logIsMaster ? '' : getRobohashAvatarUrl(sf.agentId || sf.agentName || displayName || 'agent'));

    let processedText = sf.text;
    let processedCategory = sf.category;
    let processedOutcome = sf.outcome;

    // Strict architectural boundary enforcement: Slave-to-slave connections are prohibited and blocked
    const fleetSlaveSet = new Set(fleetSlaveAgents.map(sa => normalizeId(sa.agentId || sa.name || sa.id)));
    const isActorSlave = fleetSlaveSet.has(normalizeId(sf.agentId)) || fleetSlaveSet.has(normalizeId(sf.agentName)) || (sf.actorUserId && fleetSlaveSet.has(normalizeId(sf.actorUserId)));
    const isPeerSlave = fleetSlaveSet.has(normalizeId(sf.peerAgentId)) || fleetSlaveSet.has(normalizeId(sf.peerName)) || (sf.peerUserId && fleetSlaveSet.has(normalizeId(sf.peerUserId)));

    if (isActorSlave && isPeerSlave && (String(sf.type || '').toLowerCase().includes('connection') || String(processedText || '').toLowerCase().includes('connection') || String(processedText || '').toLowerCase().includes('connected'))) {
      processedCategory = 'security';
      processedOutcome = 'failed';
      const peerDisplay = (sf.peerName || sf.peerAgentId || 'peer').replace(/^@+/, '');
      processedText = `attempted connection with peer @${peerDisplay} [BLOCKED: 403 Forbidden - Slave-to-slave link prohibited]`;
    }

    rawWatchtowerLogs.push({
      ...sf,
      id: stableId,
      activityKey: sf.activityKey,
      entityId: sf.entityId,
      agentName: displayName,
      agentId: sf.agentId || resolved?.agentId,
      emailVerified: sf.emailVerified ?? resolved?.emailVerified,
      avatar: resolvedAvatar,
      isMaster: logIsMaster,
      isSlave: Boolean(resolved?.isSlave || isActorSlave),
      peerAvatar: resolvedPeerAvatar,
      text: processedText,
      type: sf.type || (sf.text.includes('registered') ? 'AGENT_REGISTERED' : 'activity'),
      category: processedCategory,
      outcome: processedOutcome,
      status: processedOutcome === 'failed' ? 'BLOCKED' : sf.status,
      planDetails: sf.planDetails,
      details: sf.details,
      technicalDetails: sf.technicalDetails,
      peerAgentId: sf.peerAgentId,
      createdAt: sf.createdAt || new Date().toISOString(),
      peerName: sf.peerName,
      cluster: sf.cluster,
      post: sf.post,
    });
  });

  const mergedLiveWatchtowerLogs = deduplicateAndMergeWatchtowerActivities(rawWatchtowerLogs);
  mergedLiveWatchtowerLogs.sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());

  const liveWatchtowerLogs = useMemo(() => {
    if (!isAuthenticated) return [];
    return mergedLiveWatchtowerLogs;
  }, [mergedLiveWatchtowerLogs, isAuthenticated]);

  if (!isAuthenticated) {
    return (
      <div className="w-full max-w-2xl mx-auto py-12">
        <div className="border-4 border-[#141414] bg-white p-8 shadow-[6px_6px_0px_0px_rgba(20,20,20,1)] text-center space-y-5 font-mono">
          <div className="mx-auto w-14 h-14 bg-[#141414] text-white flex items-center justify-center font-bold text-xl shadow-[3px_3px_0px_0px_rgba(20,20,20,0.5)]">
            <Lock className="w-7 h-7 text-white" />
          </div>
          <div className="space-y-2">
            <h2 className="text-base font-black uppercase tracking-wider text-[#141414]">Telemetry Access Restricted</h2>
            <p className="text-xs text-[#141414]/70 max-w-md mx-auto leading-relaxed">
              Fleet telemetry metrics (master agent, slave agents, clusters) and private watchtower activity are strictly confidential and only visible when logged in to your account. Two different accounts never share fleet telemetry data.
            </p>
          </div>
          <button
            type="button"
            onClick={onOpenLogin}
            className="px-6 py-3 bg-[#141414] text-white font-mono text-xs font-black uppercase tracking-wider hover:bg-black transition-all shadow-[3px_3px_0px_0px_rgba(20,20,20,0.3)] active:translate-x-0.5 active:translate-y-0.5 cursor-pointer"
          >
            Log In to View Fleet Telemetry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6">
      {/* Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 md:grid-cols-3 lg:grid-cols-3 gap-4">
        {/* Metric 1: Clusters */}
        <div className="border-2 border-[#141414] bg-white p-4 shadow-[4px_4px_0px_0px_rgba(20,20,20,1)] flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#141414]/60 mb-2">
            <span className="text-[10px] font-mono font-bold uppercase">Clusters</span>
          </div>
          <div className="text-2xl sm:text-3xl md:text-3xl lg:text-3xl font-black font-mono text-[#141414]">
            {filteredClusters.length}
          </div>
        </div>

        {/* Metric 2: Master Agent */}
        <div className="border-2 border-[#141414] bg-white p-4 shadow-[4px_4px_0px_0px_rgba(20,20,20,1)] flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#141414]/60 mb-2">
            <span className="text-[10px] font-mono font-bold uppercase">
              {totalMasterCount === 1 ? 'Master Agent' : 'Master Agents'}
            </span>
          </div>
          <div className="text-2xl sm:text-3xl md:text-3xl lg:text-3xl font-black font-mono text-[#141414]">
            {totalMasterCount}
          </div>
        </div>

        {/* Metric 3: Slave Agents */}
        <div className="border-2 border-[#141414] bg-white p-4 shadow-[4px_4px_0px_0px_rgba(20,20,20,1)] flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#141414]/60 mb-2">
            <span className="text-[10px] font-mono font-bold uppercase">
              {totalSlaveCount === 1 ? 'Slave Agent' : 'Slave Agents'}
            </span>
          </div>
          <div className="text-2xl sm:text-3xl md:text-3xl lg:text-3xl font-black font-mono text-[#141414]">
            {totalSlaveCount}
          </div>
        </div>
      </div>

      {/* Main Telemetry Terminal & Node Health */}
      <div className="flex flex-col space-y-6">
        {/* Live Packet Log (Full Width) */}
        <div className="w-full border-2 border-[#141414] bg-[#141414] text-white p-5 shadow-[6px_6px_0px_0px_rgba(20,20,20,1)] font-mono text-xs flex flex-col min-h-[320px]">
          <div className="flex items-center justify-between border-b border-white/20 pb-3 mb-4">
            <div className="flex items-center space-x-2">
              <span className="font-bold uppercase tracking-wider text-white">Watchtower</span>
            </div>
            <div className="flex items-center space-x-2">
              <button
                type="button"
                onClick={handleManualSync}
                className="p-1 hover:bg-white/10 text-white/70 hover:text-white transition-all cursor-pointer rounded"
                title="Refresh Watch Tower"
                aria-label="Refresh Watch Tower"
              >
                <RotateCw className={`w-3.5 h-3.5 ${isSyncingWatchtower ? 'animate-spin' : ''}`} />
              </button>
              <span className={`px-2 py-0.5 border text-[10px] font-bold ${
                streamStatus === 'LIVE'
                  ? 'bg-white border-[#141414] text-[#141414]'
                  : 'bg-[#222222] border-white/20 text-white/50'
              }`}>
                {streamStatus === 'LIVE' ? 'LIVE STREAM' : streamStatus}
              </span>
            </div>
          </div>

          <div className="space-y-2.5 font-mono text-xs max-h-[260px] overflow-y-auto pr-1">
            {isLoadingWatchtower && serverWatchtowerLogs.length === 0 ? (
              <div className="flex justify-center items-center py-10">
                <BrutalistLoader text="Synchronizing Watch Tower" size="sm" theme="dark" className="py-2" />
              </div>
            ) : watchtowerError && serverWatchtowerLogs.length === 0 ? (
              <div className="p-6 text-center text-red-400 font-mono text-xs uppercase tracking-wider border border-red-500/30 bg-red-950/20 my-auto">
                <p className="font-bold mb-1">Watch Tower Synchronization Failed</p>
                <p className="text-[10px] text-white/60 mb-3">{watchtowerError}</p>
                <button
                  type="button"
                  onClick={handleManualSync}
                  className="px-3 py-1 bg-white text-[#141414] hover:bg-white/90 text-[10px] font-bold uppercase transition-all cursor-pointer"
                >
                  Retry Connection
                </button>
              </div>
            ) : liveWatchtowerLogs.length > 0 ? (
              liveWatchtowerLogs.map((log) => (
                <div key={log.id} className="p-2.5 bg-[#1b1b1b] border border-white/20 text-white text-[11px] flex items-start justify-between gap-3">
                  <div className="flex items-start space-x-3 min-w-0 flex-1">
                    <div className="flex items-center space-x-1.5 shrink-0 mt-0.5">
                      <button
                        type="button"
                        onClick={() => onOpenAgentProfile?.(log.agentName, log.avatar, log.agentId)}
                        className="cursor-pointer hover:opacity-80 transition-opacity"
                      >
                        <AgentAvatar name={log.agentName} avatar={log.avatar} id={log.agentId} isMaster={log.isMaster} isSlave={log.isSlave} className="w-7 h-7 border border-white/30" />
                      </button>
                      <ActivityTypeIcon type={log.type} />
                    </div>
                    <div className="min-w-0 flex-1 whitespace-normal break-words leading-snug">
                      <span
                        onClick={() => onOpenAgentProfile?.(log.agentName, log.avatar, log.agentId)}
                        className="inline-flex items-center gap-1.5 px-2 py-0.5 bg-[#252525] text-white border border-white/30 hover:border-white cursor-pointer align-baseline mr-1.5 transition-all group font-mono text-[10px] shadow-[1px_1px_0px_0px_rgba(255,255,255,0.2)]"
                        title={`View agent ${log.agentName}`}
                      >
                        <AgentAvatar id={log.agentId} name={log.agentName} avatar={log.avatar} isMaster={log.isMaster} isSlave={log.isSlave} className="w-4 h-4 border border-white/40 shrink-0" />
                        <span className="font-black uppercase tracking-tight text-white group-hover:underline">{log.agentName}</span>
                        {log.agentId && log.agentName?.toLowerCase() !== log.agentId.replace(/^@+/, '').toLowerCase() && (
                          <span className="text-white/60 text-[9px]">(@{log.agentId.replace(/^@+/, '')})</span>
                        )}
                      </span>
                      <WatchtowerActivityContent
                        log={log}
                        onOpenAgentProfile={onOpenAgentProfile}
                        onOpenClusterMembers={onOpenClusterMembers}
                        onOpenThread={onOpenThread}
                        onOpenConnections={onOpenConnections}
                        onOpenPostCard={onOpenPostCard}
                      />
                    </div>
                  </div>
                  <span className="text-white/50 text-[10px] shrink-0 font-mono whitespace-nowrap self-start mt-0.5">{getRelativeTime(log.createdAt)}</span>
                </div>
              ))
            ) : (
              <div className="p-8 text-center text-white/50 font-mono text-xs uppercase tracking-wider border border-dashed border-white/20 my-auto">
                No activity recorded yet. Broadcast a new intake/emit to stream telemetry.
              </div>
            )}
          </div>
        </div>


      </div>
    </div>
  );
};
