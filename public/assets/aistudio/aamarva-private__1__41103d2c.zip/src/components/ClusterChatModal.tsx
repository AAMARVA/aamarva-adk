import React, { useState, useEffect, useRef, useCallback } from 'react';
import { X, ArrowLeft, Users, PanelLeftClose, PanelLeftOpen, MessageSquare, Paperclip, Mic, AlertTriangle, Download, FileText, Lock, ChevronUp, Clock, Check, CheckCheck } from 'lucide-react';
import { apiFetch, getAccessToken, getRefreshToken, getCurrentSessionAuthType, sendClusterMessageApi, syncClusterKeyDistributionForMembersApi, isSlaveAccount, syncOwnLocalKeysWithServer } from '../services/authApi';
import { AgentAvatar } from './AgentAvatar';
import { BrutalistLoader } from './BrutalistLoader';
import { useAuth } from '../context/AuthContext';
import { VoiceMessagePlayer } from './VoiceMessagePlayer';
import { VoiceRecorderBar } from './VoiceRecorderBar';
import { useVoiceRecorder } from '../hooks/useVoiceRecorder';
import { 
  getLocalKeyPair, 
  StoredAgentKeyEntry,
  getClusterGroupKey,
  saveClusterGroupKey,
  deleteClusterGroupKey,
  computeRawGroupKeyFingerprint
} from '../lib/e2ee';
import { decryptClusterMessage, unwrapClusterGroupKeyFromPackage } from '../lib/clusterCrypto';
import { CapabilityInfoModal } from './CapabilityInfoModal';
import { getClusterSymbol } from '../lib/clusterSymbols';
import { CappedBadge } from './CappedBadge';
import {
  getCachedDecryptedMessage,
  cacheDecryptedMessage,
  isDecryptionErrorPlaceholder,
  getCachedClusterMessages,
  setCachedClusterMessages
} from '../lib/decryptedMessageStore';
import { getAccountKey, getQueryCache, setQueryCache, clearUnreadCount } from '../lib/appStateCache';
import {
  clusterKeyDistributionInFlight,
  getClusterKeyDistributionCached,
  unwrapClusterPackageAcrossEpochs,
  awaitInFlightWarmup,
  wasRecentlyWarmed,
  getInFlightWarmupPromise,
  ingestRealtimeClusterMessage,
} from '../lib/chatMessageWarmup';
import { subscribeRealtimeStream, isRealtimeStreamConnected } from '../lib/realtimeStream';
import { ChatChannelNavigator } from './ChatChannelNavigator';

function uint8ToBase64(bytes: Uint8Array): string {
  const CHUNK_SIZE = 0x8000;
  const parts: string[] = [];
  for (let i = 0; i < bytes.byteLength; i += CHUNK_SIZE) {
    parts.push(String.fromCharCode(...bytes.subarray(i, i + CHUNK_SIZE)));
  }
  return btoa(parts.join(''));
}

function computeClusterIncrementalSince(existing: any[]): string | undefined {
  if (!Array.isArray(existing) || existing.length === 0) return undefined;
  let maxTs = 0;
  for (const m of existing) {
    if (!m || typeof m.id !== 'string' || m.id.startsWith('temp_')) continue;
    if (m.createdAt) {
      const ts = new Date(m.createdAt).getTime();
      if (Number.isFinite(ts) && ts > maxTs) maxTs = ts;
    }
  }
  if (maxTs <= 0) return undefined;
  return new Date(Math.max(0, maxTs - 1000)).toISOString();
}

interface ClusterChatModalProps {
  clusterId: string;
  clusterName: string;
  clusterSymbol?: string;
  deviceSize?: 'mobile' | 'tablet' | 'desktop';
  onSelectChat?: (chat: any) => void;
  onSelectClusterChat?: (cluster: { id: string; name: string; symbol?: string }) => void;
  onClose: () => void;
  onOpenAgentProfile?: (agentName: string, avatar?: string, agentId?: string) => void;
  onOpenClusterMembers?: (cluster: any) => void;
}

interface ClusterMessageRecipient {
  agentId: string;
  recipientAgentId?: string;
  accountId?: string | null;
  name?: string | null;
  avatar?: string | null;
  isMaster?: boolean;
  isSlave?: boolean;
  hasCapabilityIncrement?: boolean;
  isCapped?: boolean;
  expires_at?: string | null;
}

interface DecryptedClusterMessage {
  id: string;
  clusterId?: string;
  senderAgentId?: string;
  senderAgentName?: string;
  senderAgentAvatar?: string;
  content: string;
  ciphertext?: string;
  nonce?: string;
  sequence?: number;
  recipients?: ClusterMessageRecipient[];
  isDecrypted: boolean;
  decryptionStatus?: {
    code?: string;
    title: string;
    detail: string;
    explanation?: string;
  };
  createdAt: string;
  deliveryStatus?: 'sending' | 'sent' | 'delivered' | 'failed';
  retryPayload?: {
    messageToSend: string;
    explicitRecipients?: string[];
  };
}

function formatChatMessageTimestamp(rawDate?: string | Date): string {
  if (!rawDate) return '';
  const d = new Date(rawDate);
  if (isNaN(d.getTime())) return '';

  const timeStr = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
  
  const now = new Date();
  const isToday = d.getDate() === now.getDate() &&
    d.getMonth() === now.getMonth() &&
    d.getFullYear() === now.getFullYear();

  const yesterday = new Date();
  yesterday.setDate(now.getDate() - 1);
  const isYesterday = d.getDate() === yesterday.getDate() &&
    d.getMonth() === yesterday.getMonth() &&
    d.getFullYear() === yesterday.getFullYear();

  if (isToday) {
    return `${timeStr} / today`;
  }
  if (isYesterday) {
    return `${timeStr} / yesterday`;
  }

  const dayName = d.toLocaleDateString('en-US', { weekday: 'short' });
  const dayNum = d.getDate();
  const monthName = d.toLocaleDateString('en-US', { month: 'short' });
  const year2Digits = String(d.getFullYear()).slice(-2);

  return `${timeStr} / ${dayName.toLowerCase()}, ${dayNum} ${monthName.toLowerCase()} ${year2Digits}`;
}

interface MessageRecipientsAccordionProps {
  recipients: ClusterMessageRecipient[];
  isCurrentUser?: boolean;
  onOpenAgentProfile?: (agentName: string, avatar?: string, agentId?: string) => void;
  members?: any[];
  senderAgentId?: string;
}

const MessageRecipientsAccordion: React.FC<MessageRecipientsAccordionProps> = ({
  recipients,
  isCurrentUser,
  onOpenAgentProfile,
  members = [],
  senderAgentId
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const nonSenderMembers = React.useMemo(() => {
    if (!members || members.length === 0) return [];
    const sAid = (senderAgentId || '').toLowerCase().trim();
    return members.filter((m: any) => {
      const mAid = (m.agentId || m.id || '').toLowerCase().trim();
      return mAid && mAid !== sAid;
    });
  }, [members, senderAgentId]);

  const effectiveRecipients = React.useMemo(() => {
    if (!recipients || recipients.length === 0) return [];
    return recipients.map((r, idx) => {
      const rawId = String(r.agentId || r.recipientAgentId || '').trim().replace(/^@+/, '');
      if (rawId) return r;
      const fallbackMember = nonSenderMembers[idx] || nonSenderMembers[0];
      if (fallbackMember) {
        return {
          ...r,
          agentId: fallbackMember.agentId,
          accountId: fallbackMember.userId || fallbackMember.id,
          name: fallbackMember.name || fallbackMember.agentName || fallbackMember.agentId,
          avatar: fallbackMember.avatar,
          isSlave: Boolean(fallbackMember.isSlave),
          isMaster: !fallbackMember.isSlave,
          hasCapabilityIncrement: fallbackMember.hasCapabilityIncrement,
          isCapped: fallbackMember.isCapped,
          expires_at: fallbackMember.expires_at
        };
      }
      return r;
    });
  }, [recipients, nonSenderMembers]);

  if (!effectiveRecipients || effectiveRecipients.length === 0) return null;

  return (
    <div className={`mt-2 pt-2 border-t ${isCurrentUser ? 'border-white/20' : 'border-[#141414]/15'}`}>
      <button
        type="button"
        onClick={() => setIsExpanded(!isExpanded)}
        className={`w-full flex items-center justify-between text-[10px] font-mono font-bold uppercase tracking-wider cursor-pointer transition-opacity hover:opacity-100 px-1 py-0.5 ${
          isCurrentUser ? 'text-white/90 hover:text-white' : 'text-[#141414]/80 hover:text-[#141414]'
        }`}
      >
        <span>Recipients ({effectiveRecipients.length})</span>
        <span className="font-bold">{isExpanded ? '⌃' : '⌄'}</span>
      </button>

      {isExpanded && (
        <div className={`mt-2 space-y-2 p-2.5 max-h-[220px] overflow-y-auto custom-scrollbar border ${
          isCurrentUser 
            ? 'bg-black/40 border-white/25 text-white' 
            : 'bg-white border-[#141414]/20 text-[#141414]'
        }`}>
          {effectiveRecipients.map((r, idx) => {
            const rawAid = String(r.agentId || r.recipientAgentId || '').trim().replace(/^@+/, '');
            const memberMeta = members?.find((m: any) => 
              (m.agentId && rawAid && String(m.agentId).toLowerCase() === rawAid.toLowerCase()) ||
              (m.id && r.accountId && String(m.id).toLowerCase() === String(r.accountId).toLowerCase()) ||
              (m.id && rawAid && String(m.id).toLowerCase() === rawAid.toLowerCase())
            );
            const resolvedAgentId = rawAid || memberMeta?.agentId || '';
            const displayName =
              (r.name && r.name.trim() && r.name.toLowerCase() !== resolvedAgentId.toLowerCase() ? r.name.trim() : null) ||
              (memberMeta?.name && memberMeta.name.trim() ? memberMeta.name.trim() : null) ||
              (memberMeta?.agentName && memberMeta.agentName.trim() ? memberMeta.agentName.trim() : null) ||
              (r.name && r.name.trim() ? r.name.trim() : null) ||
              resolvedAgentId ||
              'Cluster Member';

            const isSlave = Boolean(
              memberMeta !== undefined
                ? memberMeta.isSlave
                : r.isSlave !== undefined
                ? r.isSlave
                : r.isMaster !== undefined
                ? !r.isMaster
                : false
            );
            const isMaster = !isSlave && Boolean(
              memberMeta !== undefined
                ? !memberMeta.isSlave
                : r.isMaster
            );

            let recipientAvatar = r.avatar || memberMeta?.avatar;
            if (isMaster && (!recipientAvatar || recipientAvatar.includes('robohash') || recipientAvatar === '🤖')) {
              recipientAvatar = undefined;
            }

            const isCapped = isSlave && Boolean(
              r.hasCapabilityIncrement ||
              r.isCapped ||
              memberMeta?.hasCapabilityIncrement ||
              memberMeta?.isCapped ||
              memberMeta?.plan === 'slave_capability'
            );
            const expiresAt = r.expires_at || memberMeta?.expires_at || undefined;

            return (
              <div 
                key={resolvedAgentId || idx} 
                className={`flex items-center gap-2.5 p-2 border ${
                  isCurrentUser
                    ? 'bg-white/10 border-white/20 text-white'
                    : 'bg-[#F5F4F0] border-[#141414]/20 text-[#141414]'
                } shadow-[2px_2px_0px_0px_rgba(20,20,20,0.15)]`}
              >
                <button
                  type="button"
                  onClick={() => onOpenAgentProfile?.(displayName, undefined, resolvedAgentId)}
                  className="shrink-0 hover:scale-105 transition-transform cursor-pointer border-none bg-transparent p-0 focus:outline-none"
                  title={`View profile for ${displayName}`}
                >
                  <AgentAvatar
                    name={displayName}
                    avatar={recipientAvatar}
                    id={resolvedAgentId}
                    isMaster={isMaster}
                    isSlave={isSlave}
                    className="w-8 h-8 border-2 border-[#141414] shadow-[1px_1px_0px_0px_rgba(20,20,20,0.3)]"
                  />
                </button>
                <div className="min-w-0 flex-1 text-left">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <button
                      type="button"
                      onClick={() => onOpenAgentProfile?.(displayName, undefined, resolvedAgentId)}
                      className="hover:underline cursor-pointer text-left truncate font-black uppercase text-xs tracking-wider"
                    >
                      {displayName}
                    </button>
                    {isCapped && (
                      <CappedBadge expiresAt={expiresAt} isCapped={true} />
                    )}
                  </div>
                  <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
                    {resolvedAgentId && (
                      <span className="relative inline-flex items-center gap-1 font-mono text-[9px] font-bold text-[#141414] bg-[#E4E3E0] px-1.5 py-0.2 normal-case tracking-wider border border-[#141414] shadow-[1px_1px_0px_0px_rgba(20,20,20,1)]">
                        <span>@{resolvedAgentId}</span>
                      </span>
                    )}
                    {isSlave ? (
                      <span className="text-[8px] font-extrabold uppercase px-1.5 py-0.2 bg-white text-[#141414] border border-[#141414]">
                        SLAVE
                      </span>
                    ) : isMaster ? (
                      <span className="text-[8px] font-extrabold uppercase px-1.5 py-0.2 bg-[#141414] text-white border border-[#141414]">
                        MASTER
                      </span>
                    ) : null}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

function formatFileSize(bytes: number): string {
  if (!bytes || bytes <= 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

interface ClusterAttachmentMessageProps {
  payload: {
    filename: string;
    size: number;
    mimeType: string;
    fileBase64?: string;
    text?: string;
  };
  isCurrentUser: boolean;
}

const ClusterAttachmentMessage: React.FC<ClusterAttachmentMessageProps> = ({ payload, isCurrentUser }) => {
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadError, setDownloadError] = useState<string | null>(null);

  const handleDownload = () => {
    if (!payload.fileBase64) {
      setDownloadError('File data unavailable.');
      return;
    }
    try {
      setIsDownloading(true);
      setDownloadError(null);
      const binaryString = atob(payload.fileBase64);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      const blob = new Blob([bytes], { type: payload.mimeType || 'application/octet-stream' });
      const objectUrl = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = objectUrl;
      anchor.download = payload.filename || 'cluster_attachment';
      document.body.appendChild(anchor);
      anchor.click();
      document.body.removeChild(anchor);
      setTimeout(() => URL.revokeObjectURL(objectUrl), 4000);
    } catch (err: any) {
      console.error('Failed to download cluster attachment:', err);
      setDownloadError('Failed to decode file.');
    } finally {
      setIsDownloading(false);
    }
  };

  const isImage = Boolean(payload.mimeType?.startsWith('image/') && payload.fileBase64);

  return (
    <div className="space-y-1.5 font-mono">
      {payload.text && (
        <div className="text-xs sm:text-sm whitespace-pre-wrap break-words leading-relaxed mb-1">
          {payload.text}
        </div>
      )}

      {isImage && (
        <div
          onClick={handleDownload}
          className={`max-h-52 overflow-hidden border p-1 cursor-pointer transition-opacity hover:opacity-90 flex items-center justify-center ${
            isCurrentUser
              ? 'border-white/30 bg-black/30'
              : 'border-[#141414]/30 bg-[#141414]/5'
          }`}
          title="Click to download image"
        >
          <img
            src={`data:${payload.mimeType};base64,${payload.fileBase64}`}
            alt={payload.filename}
            className="max-h-48 max-w-full object-contain"
          />
        </div>
      )}

      <div
        className={`flex items-center justify-between gap-3 p-2 border ${
          isCurrentUser
            ? 'border-white/30 bg-white/5 text-white'
            : 'border-[#141414]/25 bg-black/5 text-[#141414]'
        }`}
      >
        <div className="flex items-center gap-2 min-w-0 flex-1">
          <FileText className="w-4 h-4 shrink-0 opacity-75" />
          <div className="truncate min-w-0">
            <span className="font-bold text-xs truncate block leading-tight">
              {payload.filename}
            </span>
            <span className="text-[9.5px] opacity-65 font-mono">
              {formatFileSize(payload.size)}
            </span>
          </div>
        </div>

        <button
          type="button"
          onClick={handleDownload}
          disabled={isDownloading}
          className={`p-1.5 border transition-all cursor-pointer flex items-center justify-center shrink-0 active:scale-95 shadow-[1px_1px_0px_0px_rgba(20,20,20,1)] ${
            isCurrentUser
              ? 'border-white bg-white text-[#141414] hover:bg-neutral-200'
              : 'border-[#141414] bg-[#141414] text-white hover:bg-neutral-800'
          }`}
          title="Download attachment"
        >
          {isDownloading ? (
            <span className="inline-block w-3.5 h-3.5 border-2 border-current border-t-transparent animate-spin rounded-full" />
          ) : (
            <Download className="w-3.5 h-3.5" />
          )}
        </button>
      </div>
      {downloadError && (
        <div className="text-[9.5px] font-mono text-red-500 opacity-90 flex items-center gap-1 mt-0.5">
          <span>⚠️ {downloadError}</span>
        </div>
      )}
    </div>
  );
};

interface ChatMessageContentProps {
  content: string;
  isCurrentUser?: boolean;
}

const ChatMessageContent = React.memo<ChatMessageContentProps>(({ content, isCurrentUser }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  if (content && typeof content === 'string' && content.startsWith('{')) {
    if (content.includes('"isVoiceMessage":true') || content.includes('"isVoiceMessage": true')) {
      try {
        const parsed = JSON.parse(content);
        if (parsed.isVoiceMessage) {
          return (
            <VoiceMessagePlayer
              payload={parsed}
              isCurrentUser={Boolean(isCurrentUser)}
            />
          );
        }
      } catch {}
    }

    if (content.includes('"aamarva_attachment":true') || content.includes('"aamarva_attachment": true')) {
      try {
        const parsed = JSON.parse(content);
        if (parsed.aamarva_attachment) {
          return (
            <ClusterAttachmentMessage
              payload={parsed}
              isCurrentUser={Boolean(isCurrentUser)}
            />
          );
        }
      } catch {}
    }
  }

  const isLong = content.length > 300 || content.split('\n').length > 6;
  const isDecryptionNotice = content.includes('Cannot be decrypted') || content.startsWith('🔒') || content.startsWith('🔐');
  const cleanContent = content.replace(/^[🔒🔐]\s*/, '');

  return (
    <div className="space-y-1.5">
      <div
        className={`text-xs sm:text-sm font-mono whitespace-pre-wrap break-words overscroll-contain touch-pan-y ${
          isExpanded
            ? 'max-h-[600px] overflow-y-auto custom-scrollbar'
            : 'max-h-[250px] overflow-y-auto custom-scrollbar'
        }`}
      >
        {isDecryptionNotice ? (
          <span className="flex items-start gap-1.5">
            <Lock className={`w-3.5 h-3.5 shrink-0 mt-0.5 ${isCurrentUser ? 'text-white' : 'text-[#141414]'}`} />
            <span>{cleanContent}</span>
          </span>
        ) : (
          content
        )}
      </div>
      {isLong && (
        <button
          type="button"
          onClick={() => setIsExpanded(!isExpanded)}
          className={`text-[10px] font-mono font-bold uppercase tracking-wider underline cursor-pointer transition-opacity hover:opacity-100 ${
            isCurrentUser ? 'text-white/80' : 'text-[#141414]/80'
          }`}
        >
          {isExpanded ? '▲ Collapse message' : '▼ Read full message'}
        </button>
      )}
    </div>
  );
});

async function decryptClusterMessageEnvelope(
  msg: any,
  currentLocalKeys: StoredAgentKeyEntry | null,
  userAgentId?: string,
  _userPassword?: string | null,
  _activeCredentials?: string[],
  _members?: any[],
  _activeCluster?: any,
  authType: 'human' | 'agent' = 'human'
): Promise<{ 
  text: string; 
  isDecrypted: boolean; 
  decryptionStatus?: { code?: string; title: string; detail: string; explanation?: string } 
}> {
  const ciphertext = typeof msg.ciphertext === 'string' ? msg.ciphertext.trim() : '';
  const nonce = typeof msg.nonce === 'string' ? msg.nonce.trim() : '';
  const content = typeof msg.content === 'string' ? msg.content.trim() : '';
  const senderAgentId = msg.senderAgentId || 'Agent';
  const clusterId = msg.clusterId || 'cluster';
  const keyEpoch = msg.keyEpoch || 1;
  const version = msg.version || 2;
  const audienceHash = String(msg.audienceHash || msg.keys?.audienceHash || 'ALL').trim() || 'ALL';

  const memberMeta = _members?.find((m: any) => m.agentId?.toLowerCase() === senderAgentId.toLowerCase());
  const senderDisplayName =
    msg.senderAgentName ||
    msg.senderDisplayName ||
    msg.senderName ||
    memberMeta?.name ||
    memberMeta?.agentName ||
    '';

  const clusterName =
    msg.clusterName ||
    _activeCluster?.name ||
    _activeCluster?.clusterName ||
    _activeCluster?.cluster?.name ||
    '';

  // If system broadcast or legacy public notice
  if (content && content !== '🔒 [E2EE Encrypted Payload]' && !ciphertext) {
    return {
      text: content,
      isDecrypted: true
    };
  }

  if (ciphertext && nonce && currentLocalKeys && userAgentId) {
    try {
      // 1. Fast-path: check local cached group key FIRST (AES-256-GCM tag verifies authenticity with 0 HTTP latency)
      let localGroupKey = await getClusterGroupKey(clusterId, keyEpoch, undefined, audienceHash);
      if (localGroupKey) {
        try {
          const fastPlaintext = await decryptClusterMessage(
            ciphertext,
            nonce,
            localGroupKey,
            senderAgentId,
            clusterId,
            keyEpoch,
            version,
            senderDisplayName,
            clusterName,
            audienceHash
          );
          if (fastPlaintext) {
            return {
              text: fastPlaintext,
              isDecrypted: true
            };
          }
        } catch {
          // Local key might be stale/rotated or wrong cluster epoch; fall through to authoritative check
          await deleteClusterGroupKey(clusterId, keyEpoch, audienceHash);
        }
      }

      // 2. Query authoritative distribution metadata from server (deduplicated across concurrent message renders)
      let distRes: any = null;
      try {
        distRes = await getClusterKeyDistributionCached(clusterId, keyEpoch, audienceHash, authType);
      } catch {}

      const authoritativeFp = distRes?.success && distRes.data?.keyFingerprint ? distRes.data.keyFingerprint : undefined;

      // 3. Validate locally cached key against authoritative epoch fingerprint.
      let groupKey = await getClusterGroupKey(clusterId, keyEpoch, authoritativeFp, audienceHash);

      // 4. If no valid group key (either missing or evicted due to fingerprint mismatch), unwrap server package across personal key epochs
      if (!groupKey && distRes?.success && distRes.data?.encryptedKeyPackage) {
        const unwrapped = await unwrapClusterPackageAcrossEpochs(
          distRes.data,
          currentLocalKeys,
          userAgentId,
          _userPassword,
          clusterId,
          keyEpoch,
          audienceHash,
          _members
        );
        const calculatedFp = await computeRawGroupKeyFingerprint(unwrapped.rawKey);
        if (authoritativeFp && calculatedFp !== authoritativeFp) {
          throw new Error(
            `E2EE Verification Failure: Unwrapped group key fingerprint (${calculatedFp}) does not match authoritative epoch fingerprint (${authoritativeFp}). Key rejected.`
          );
        }
        groupKey = unwrapped.groupKey;
        await saveClusterGroupKey(clusterId, keyEpoch, unwrapped.rawKey, calculatedFp, audienceHash);
      }

      // 5. Decrypt ciphertext using validated group key
      if (groupKey) {
        try {
          const resolvedPlaintext = await decryptClusterMessage(
            ciphertext,
            nonce,
            groupKey,
            senderAgentId,
            clusterId,
            keyEpoch,
            version,
            senderDisplayName,
            clusterName,
            audienceHash
          );
          if (resolvedPlaintext) {
            return {
              text: resolvedPlaintext,
              isDecrypted: true
            };
          }
        } catch (decryptErr: any) {
          // Evict stale cached key and bypass cache once to fetch fresh distribution package
          await deleteClusterGroupKey(clusterId, keyEpoch, audienceHash);

          clusterKeyDistributionInFlight.delete(`${clusterId}:${keyEpoch}:${audienceHash}:${authType}`);
          const freshDistRes = await apiFetch(
            `/api/clusters/${clusterId}/key-distribution?epoch=${keyEpoch}&audienceHash=${encodeURIComponent(audienceHash)}`,
            { authType, cache: 'no-store', skipDedupe: true }
          );
          if (freshDistRes?.success && freshDistRes.data?.encryptedKeyPackage) {
            const unwrapped = await unwrapClusterPackageAcrossEpochs(
              freshDistRes.data,
              currentLocalKeys,
              userAgentId,
              _userPassword,
              clusterId,
              keyEpoch,
              audienceHash,
              _members
            );
            const calculatedFp = await computeRawGroupKeyFingerprint(unwrapped.rawKey);
            const freshAuthoritativeFp = freshDistRes.data?.keyFingerprint;
            if (freshAuthoritativeFp && calculatedFp !== freshAuthoritativeFp) {
              throw new Error(
                `E2EE Verification Failure: Unwrapped group key fingerprint (${calculatedFp}) does not match authoritative epoch fingerprint (${freshAuthoritativeFp}). Key rejected.`
              );
            }
            await saveClusterGroupKey(clusterId, keyEpoch, unwrapped.rawKey, calculatedFp, audienceHash);
            const retryPlaintext = await decryptClusterMessage(
              ciphertext,
              nonce,
              unwrapped.groupKey,
              senderAgentId,
              clusterId,
              keyEpoch,
              version,
              senderDisplayName,
              clusterName,
              audienceHash
            );
            if (retryPlaintext) {
              return {
                text: retryPlaintext,
                isDecrypted: true
              };
            }
          }
          throw decryptErr;
        }
      }

      // If no package existed OR server reported recipientKeyMismatch without package, check own vault convergence
      if (!groupKey && distRes?.data?.recipientKeyMismatch) {
        const ownSync = await syncOwnLocalKeysWithServer(userAgentId, _userPassword || undefined, authType, {
          force: true,
          checkVaultForMissingEpochs: true,
          targetFingerprint: distRes.data.recipientKeyFingerprint || undefined,
          targetEpoch: typeof distRes.data.recipientKeyEpoch === 'number' ? distRes.data.recipientKeyEpoch : undefined,
        });
        if (ownSync.status === 'recovery_required') {
          return {
            text: '',
            isDecrypted: false,
            decryptionStatus: {
              code: 'E2EE_RECOVERY_REQUIRED',
              title: '🔒 Encrypted message awaiting key sync',
              detail: 'Encryption key for this epoch is unavailable on this device',
              explanation: 'Sign in with your account password on this device or have a cluster admin re-wrap historical keys.'
            }
          };
        }
        if (ownSync.restoredNewEpochs && ownSync.localKeys?.privateKey && distRes?.data?.encryptedKeyPackage) {
          const unwrapped = await unwrapClusterPackageAcrossEpochs(
            distRes.data,
            ownSync.localKeys,
            userAgentId,
            _userPassword,
            clusterId,
            keyEpoch,
            audienceHash,
            _members
          );
          const calculatedFp = await computeRawGroupKeyFingerprint(unwrapped.rawKey);
          if (!authoritativeFp || calculatedFp === authoritativeFp) {
            await saveClusterGroupKey(clusterId, keyEpoch, unwrapped.rawKey, calculatedFp, audienceHash);
            const retryPlain = await decryptClusterMessage(
              ciphertext,
              nonce,
              unwrapped.groupKey,
              senderAgentId,
              clusterId,
              keyEpoch,
              version,
              senderDisplayName,
              clusterName,
              audienceHash
            );
            if (retryPlain) {
              return { text: retryPlain, isDecrypted: true };
            }
          }
        }
      }
    } catch (e: any) {
      const isRecoveryNeeded = e?.code === 'E2EE_RECOVERY_REQUIRED' || String(e?.message || '').includes('E2EE_RECOVERY_REQUIRED');
      const isRekeyNeeded = e?.code === 'E2EE_REKEY_REQUIRED' || String(e?.message || '').includes('E2EE_REKEY_REQUIRED');
      return {
        text: '',
        isDecrypted: false,
        decryptionStatus: isRecoveryNeeded
          ? {
              code: 'E2EE_RECOVERY_REQUIRED',
              title: '🔒 Encrypted message awaiting key sync',
              detail: 'Encryption key for this epoch is unavailable on this device',
              explanation: 'Sign in with your account password on this device or have a cluster admin re-wrap historical keys.'
            }
          : isRekeyNeeded
          ? {
              code: 'E2EE_REKEY_REQUIRED',
              title: '🔒 Waiting for cluster key sync for this device',
              detail: e?.message || 'Package sealed for a prior device key epoch',
              explanation: 'Have a cluster admin open this chat to re-wrap historical keys for your current device key.'
            }
          : {
              title: '🔒 Cannot be decrypted because group key or authentication failed',
              detail: e?.message || 'Authentication tag or key mismatch',
              explanation: 'Only authorized active cluster members possessing the corresponding cluster group key can decrypt.'
            }
      };
    }
  }

  return {
    text: '',
    isDecrypted: false,
    decryptionStatus: {
      title: '🔒 Cannot be decrypted because keys or ciphertext are missing',
      detail: 'Missing decryption key material',
      explanation: 'Decryption keys are held exclusively by authenticated agent endpoints.'
    }
  };
}

export const ClusterChatModal: React.FC<ClusterChatModalProps> = ({
  clusterId,
  clusterName,
  clusterSymbol,
  deviceSize,
  onSelectChat,
  onSelectClusterChat,
  onClose,
  onOpenAgentProfile,
  onOpenClusterMembers,
}) => {
  const { user, activeAccount, userPassword, e2eeStatus, ensureE2EEKeys, sessionAuthType } = useAuth();
  const accountKey = getAccountKey(user?.id, activeAccount?.id);
  const effectiveAuthType: 'human' | 'agent' = sessionAuthType || getCurrentSessionAuthType() || 'human';
  const isSlave = isSlaveAccount(activeAccount || user);
  const effectiveDeviceSize: 'mobile' | 'tablet' | 'desktop' =
    deviceSize || (typeof window !== 'undefined' ? (window.innerWidth < 768 ? 'mobile' : window.innerWidth <= 1024 ? 'tablet' : 'desktop') : 'desktop');
  const isMobile = effectiveDeviceSize === 'mobile';
  const isTablet = effectiveDeviceSize === 'tablet';
  const isDesktop = effectiveDeviceSize === 'desktop';
  const hasChannelSwitcher = Boolean(onSelectChat || onSelectClusterChat);
  const [isChannelSidebarOpen, setIsChannelSidebarOpen] = useState<boolean>(true);

  const toggleChannelSidebar = useCallback(() => {
    setIsChannelSidebarOpen((prev) => !prev);
  }, []);
  const [activeCluster, setActiveCluster] = useState<any | null>(() => {
    const cachedClusters = getQueryCache(accountKey, '/api/clusters')?.data;
    if (Array.isArray(cachedClusters)) {
      return cachedClusters.find((c: any) => String(c.id || '').toLowerCase() === clusterId.toLowerCase()) || null;
    }
    return null;
  });
  const displaySymbol = clusterSymbol || activeCluster?.symbol || (activeCluster as any)?.cluster?.symbol || getClusterSymbol(clusterId);
  const [messages, setMessages] = useState<DecryptedClusterMessage[]>(() => getCachedClusterMessages(clusterId, accountKey));
  const [newMessage, setNewMessage] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isSending, setIsSending] = useState(false);
  const [sendError, setSendError] = useState<string | null>(null);
  const [hiddenMessageIds, setHiddenMessageIds] = useState<Set<string>>(new Set());
  const voiceRecorder = useVoiceRecorder();

  const handleMicClick = async () => {
    if (voiceRecorder.state === 'idle') {
      await voiceRecorder.startRecording();
    } else if (voiceRecorder.state === 'recording') {
      voiceRecorder.stopRecording();
    }
  };

  const [showHiddenMessages, setShowHiddenMessages] = useState(false);
  const [isLoading, setIsLoading] = useState(() => getCachedClusterMessages(clusterId, accountKey).length === 0);
  const [members, setMembers] = useState<any[]>(() => {
    const cached = getQueryCache(accountKey, `/api/clusters/public/${clusterId}/members`)?.data;
    return Array.isArray(cached) ? cached : Array.isArray(cached?.members) ? cached.members : [];
  });
  const hasScrolledInitiallyRef = useRef<boolean>(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 25 * 1024 * 1024) {
      alert('File exceeds maximum allowed size (25MB).');
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }
    setSelectedFile(file);
    setSendError(null);
  };
  const recipientCandidates = React.useMemo(() => {
    const acting = activeAccount || user;
    const myAgentId = (acting?.agentId || user?.agentId || '').toLowerCase().trim();
    const myUserId = (acting?.id || user?.id || '').toLowerCase().trim();
    const myName = (acting?.name || user?.name || '').toLowerCase().trim();
    const myEmail = (acting?.email || user?.email || '').toLowerCase().trim();

    return members.filter((m: any) => {
      const mAgentId = (m.agentId || '').toLowerCase().trim();
      const mId = (m.id || '').toLowerCase().trim();
      const mUserId = (m.userId || m.user_id || '').toLowerCase().trim();
      const mName = (m.name || m.agentName || '').toLowerCase().trim();
      const mEmail = (m.email || '').toLowerCase().trim();

      // Strictly exclude user's own account from recipient / slave selection
      if (myAgentId && (mAgentId === myAgentId || mId === myAgentId)) {
        return false;
      }
      if (myUserId && (mUserId === myUserId || mId === myUserId)) {
        return false;
      }
      if (mId.startsWith('admin-') && (mAgentId === myAgentId || !mAgentId || mAgentId === 'amr-tw43-24wu')) return false;
      if (myEmail && mEmail === myEmail) return false;
      if (myName && mName === myName && (m.membershipRole === 'admin' || m.membershipRole === 'owner' || m.role === 'admin' || m.role === 'owner')) return false;

      return true;
    });
  }, [members, user, activeAccount]);

  const [selectedRecipientIds, setSelectedRecipientIds] = useState<Set<string>>(new Set());

  const handleOpenSpogModal = () => {
    if (selectedRecipientIds.size === 0 && !selectedRecipientIds.has('__NONE__')) {
      const availableIds = recipientCandidates.filter((m: any) => m.keyStatus === 'available').map((m: any) => m.agentId);
      setSelectedRecipientIds(new Set(availableIds));
    }
    setIsSpogModalOpen(true);
  };

  const [isSpogModalOpen, setIsSpogModalOpen] = useState(false);
  const [spogSearchQuery, setSpogSearchQuery] = useState('');
  const [capabilityModalAccount, setCapabilityModalAccount] = useState<{ id: string; name: string } | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const actingPersona = activeAccount || user;
  const accountId = actingPersona?.id || actingPersona?.agentId || 'anonymous';
  const decryptedCacheRef = useRef<Map<string, string>>(new Map());
  const prevClusterIdRef = useRef(clusterId);
  const prevAccountIdRef = useRef(accountId);

  if (prevClusterIdRef.current !== clusterId || prevAccountIdRef.current !== accountId) {
    decryptedCacheRef.current.clear();
    prevClusterIdRef.current = clusterId;
    prevAccountIdRef.current = accountId;
  }

  const activeContextCredentials = React.useMemo(() => {
    return [
      userPassword,
      getAccessToken(),
      getRefreshToken(),
      actingPersona?.apiKey,
    ].filter(Boolean) as string[];
  }, [userPassword, actingPersona?.apiKey]);

  const visibleMessages = React.useMemo(() => {
    return messages.filter((m) => !hiddenMessageIds.has(m.id) || showHiddenMessages);
  }, [messages, hiddenMessageIds, showHiddenMessages]);

  const executeSendClusterMessage = async (tempId: string, messageToSend: string, explicitRecipients?: string[]) => {
    const senderPersona = activeAccount || user;
    if (!senderPersona?.agentId) return;
    setSendError(null);
    try {
      const res = await sendClusterMessageApi(
        clusterId,
        messageToSend,
        senderPersona.agentId,
        { 
          password: userPassword || undefined, 
          authType: effectiveAuthType,
          selectedRecipientAgentIds: explicitRecipients
        }
      );
      if (res?.success || res?.id || res?.messageId) {
        const returnedId = res?.id || res?.messageId || tempId;
        decryptedCacheRef.current.set(`${accountId}:${clusterId}:${returnedId}`, messageToSend);
        cacheDecryptedMessage(messageToSend, [
          returnedId,
          `${clusterId}_${returnedId}`,
          `${accountId}:${clusterId}:${returnedId}`
        ]);
        setMessages((prev) => {
          const next = prev.map((m) =>
            m.id === tempId ? { ...m, id: returnedId, deliveryStatus: 'sent' as const } : m
          );
          setCachedClusterMessages(clusterId, next, accountKey);
          return next;
        });
      } else {
        setSendError(res?.error?.message || 'Failed to deliver cluster message.');
        setMessages((prev) =>
          prev.map((m) =>
            m.id === tempId
              ? { ...m, deliveryStatus: 'failed', retryPayload: { messageToSend, explicitRecipients } }
              : m
          )
        );
      }
    } catch (err: any) {
      console.error('Error sending cluster message:', err);
      setSendError(err?.message || 'Cluster message transmission rejected.');
      setMessages((prev) =>
        prev.map((m) =>
          m.id === tempId
            ? { ...m, deliveryStatus: 'failed', retryPayload: { messageToSend, explicitRecipients } }
            : m
        )
      );
    }
  };

  const handleRetryClusterMessage = (messageId: string) => {
    const target = messages.find((m) => m.id === messageId);
    if (!target || !target.retryPayload) return;
    setMessages((prev) =>
      prev.map((m) => (m.id === messageId ? { ...m, deliveryStatus: 'sending' } : m))
    );
    executeSendClusterMessage(messageId, target.retryPayload.messageToSend, target.retryPayload.explicitRecipients);
  };



  const resolveRecipientsList = useCallback((rawRecipients: any[], membersList: any[]): ClusterMessageRecipient[] => {
    const selfAccount = activeAccount || user;
    return (rawRecipients || []).map((r: any, idx: number) => {
      const targetAgentId = String(r.agentId || r.recipientAgentId || r.id || '').trim().replace(/^@+/, '');
      const targetAccountId = r.accountId ? String(r.accountId).trim() : null;
      const mem = (membersList || []).find((m: any) => 
        (m.agentId && targetAgentId && String(m.agentId).toLowerCase() === targetAgentId.toLowerCase()) ||
        (m.id && targetAccountId && String(m.id).toLowerCase() === targetAccountId.toLowerCase()) ||
        (m.id && targetAgentId && String(m.id).toLowerCase() === targetAgentId.toLowerCase())
      ) || (!targetAgentId && membersList && membersList.length > 0 ? membersList.filter((m: any) => m.agentId?.toLowerCase() !== selfAccount?.agentId?.toLowerCase())[idx] : undefined);

      const finalAgentId = targetAgentId || mem?.agentId || '';
      const isMe = Boolean(selfAccount && (
        (selfAccount.agentId && finalAgentId && String(selfAccount.agentId).toLowerCase() === finalAgentId.toLowerCase()) ||
        (selfAccount.id && targetAccountId && String(selfAccount.id).toLowerCase() === targetAccountId.toLowerCase()) ||
        (selfAccount.id && finalAgentId && String(selfAccount.id).toLowerCase() === finalAgentId.toLowerCase())
      ));
      const isSlave = Boolean(
        mem !== undefined
          ? mem.isSlave
          : r.isSlave !== undefined
          ? r.isSlave
          : r.account_type === 'slave' ||
            r.role === 'slave' ||
            (isMe ? isSlaveAccount(selfAccount) : false)
      );
      const isMaster = !isSlave && Boolean(
        (isMe && !isSlaveAccount(selfAccount)) ||
        (mem && !mem.isSlave) ||
        r.isMaster === true
      );

      let resolvedAvatar = (isMe && selfAccount?.avatar && !selfAccount.avatar.includes('robohash') && selfAccount.avatar !== '🤖')
        ? selfAccount.avatar
        : (r.avatar || mem?.avatar);

      const resolvedName =
        (r.name && r.name.trim() && r.name.toLowerCase() !== finalAgentId.toLowerCase() ? r.name.trim() : null) ||
        (mem?.name && mem.name.trim() ? mem.name.trim() : null) ||
        (mem?.agentName && mem.agentName.trim() ? mem.agentName.trim() : null) ||
        (r.name && r.name.trim() ? r.name.trim() : null) ||
        (isMe ? selfAccount?.name : null) ||
        finalAgentId;

      if (isMaster) {
        if (!resolvedAvatar || resolvedAvatar.includes('robohash') || resolvedAvatar === '🤖') {
          resolvedAvatar = (isMe && selfAccount?.avatar && !selfAccount.avatar.includes('robohash') && selfAccount.avatar !== '🤖')
            ? selfAccount.avatar
            : (mem?.avatar && !mem.avatar.includes('robohash') && mem.avatar !== '🤖')
            ? mem.avatar
            : undefined;
        }
      }

      return {
        agentId: finalAgentId,
        recipientAgentId: finalAgentId,
        accountId: targetAccountId || mem?.userId || mem?.id || null,
        name: resolvedName,
        avatar: resolvedAvatar,
        isSlave,
        isMaster,
        hasCapabilityIncrement: Boolean(r.hasCapabilityIncrement || mem?.hasCapabilityIncrement || mem?.isCapped),
        isCapped: Boolean(r.isCapped || r.hasCapabilityIncrement || mem?.isCapped || mem?.hasCapabilityIncrement),
        expires_at: r.expires_at || mem?.expires_at || null
      };
    });
  }, [activeAccount, user]);

  const userRef = useRef(user);
  const activeAccountRef = useRef(activeAccount);
  const activeClusterRef = useRef(activeCluster);
  const membersRef = useRef(members);
  const userPasswordRef = useRef(userPassword);
  const activeContextCredentialsRef = useRef(activeContextCredentials);
  const resolveRecipientsListRef = useRef(resolveRecipientsList);
  const pollCountRef = useRef(0);
  const isMountedRef = useRef(true);
  const hasCompletedInitialSyncRef = useRef(false);
  const lastReadPostedAtRef = useRef(0);

  useEffect(() => {
    isMountedRef.current = true;
    return () => {
      isMountedRef.current = false;
    };
  }, []);
  
  useEffect(() => {
    userRef.current = user;
    activeAccountRef.current = activeAccount;
    activeClusterRef.current = activeCluster;
    membersRef.current = members;
    userPasswordRef.current = userPassword;
    activeContextCredentialsRef.current = activeContextCredentials;
    resolveRecipientsListRef.current = resolveRecipientsList;
  }, [user, activeAccount, activeCluster, members, userPassword, activeContextCredentials, resolveRecipientsList]);

  const messagesRef = useRef(messages);
  const e2eeStatusRef = useRef(e2eeStatus);
  const ensureE2EEKeysRef = useRef(ensureE2EEKeys);

  useEffect(() => {
    messagesRef.current = messages;
    e2eeStatusRef.current = e2eeStatus;
    ensureE2EEKeysRef.current = ensureE2EEKeys;
  }, [messages, e2eeStatus, ensureE2EEKeys]);

  const fetchDetails = useCallback(async (isSilent = false) => {
    if (!clusterId) return;

    if (getInFlightWarmupPromise(accountKey, 'cluster', [clusterId])) {
      await awaitInFlightWarmup(accountKey, 'cluster', [clusterId]);
      const freshlyWarmedMsgs = getCachedClusterMessages(clusterId, accountKey);
      if (freshlyWarmedMsgs.length > 0 && isMountedRef.current) {
        setMessages(freshlyWarmedMsgs);
        setIsLoading(false);
      }
    } else if (wasRecentlyWarmed(accountKey, 'cluster', [clusterId], 2500)) {
      const cachedMsgs = getCachedClusterMessages(clusterId, accountKey);
      if (cachedMsgs.length > 0 && isMountedRef.current) {
        setMessages(cachedMsgs);
        setIsLoading(false);
        if (isSilent && cachedMsgs.every((m: any) => m.isDecrypted)) return;
      }
    }

    if (!isSilent && getCachedClusterMessages(clusterId, accountKey).length === 0) {
      setIsLoading(true);
    }

    const currentUser = activeAccountRef.current || userRef.current;
    const currentActiveCluster = activeClusterRef.current;
    const currentPassword = userPasswordRef.current;
    const currentCredentials = activeContextCredentialsRef.current;
    const shouldRefreshMeta = !isSilent || membersRef.current.length === 0 || pollCountRef.current % 4 === 0;
    pollCountRef.current += 1;

    try {
      let currentClusterMeta = currentActiveCluster;
      let currentMembers: any[] = membersRef.current;

      // Kick off metadata requests WITHOUT holding /messages back when /messages returns first
      const metaPromise = shouldRefreshMeta
        ? Promise.all([
            apiFetch(`/api/clusters/${clusterId}`, { authType: effectiveAuthType }).catch(() => null),
            apiFetch(`/api/clusters/public/${clusterId}/members`, { authType: 'none' }).catch(() => null),
          ]).then(async ([singleRes, pubRes]) => {
            if (singleRes?.success && singleRes.data) {
              currentClusterMeta = singleRes.data.cluster || singleRes.data;
              setActiveCluster(currentClusterMeta);
            }

            if (pubRes?.success && Array.isArray(pubRes.data?.members) && pubRes.data.members.length > 0) {
              currentMembers = pubRes.data.members;
              if (!currentClusterMeta && pubRes.data.cluster) {
                currentClusterMeta = pubRes.data.cluster;
                setActiveCluster(currentClusterMeta);
              }
            }

            if (currentMembers.length === 0) {
              const fallbackAgentId = currentUser?.agentId || 'AMR-TW43-24WU';
              currentMembers = [
                {
                  id: `member-${fallbackAgentId}`,
                  agentId: fallbackAgentId,
                  name: currentUser?.name || fallbackAgentId,
                  agentName: currentUser?.name || fallbackAgentId,
                  avatar: currentUser?.avatar || '🤖',
                  role: 'admin',
                  membershipRole: 'owner',
                  status: 'active',
                  publicKey: currentUser?.e2eePublicKey || null,
                  e2eePublicKey: currentUser?.e2eePublicKey || null,
                  keyStatus: currentUser?.e2eePublicKey ? 'available' : 'missing',
                  isSlave: false,
                }
              ];
            }

            currentMembers = currentMembers.map((m: any) => ({
              ...m,
              agentId: m.agentId || m.id || 'UNKNOWN_AGENT',
              name: m.name || m.agentName || m.agentId || 'Agent',
              membershipRole: m.membershipRole || m.role || 'member',
              keyStatus: m.keyStatus || (m.publicKey || m.e2eePublicKey ? 'available' : 'missing'),
              isSlave: Boolean(m.isSlave || m.role === 'slave' || m.account_type === 'slave' || (m.agentId && m.agentId.includes('+AMR-'))),
            }));

            setMembers(currentMembers);
            setQueryCache(accountKey, `/api/clusters/public/${clusterId}/members`, currentMembers);

            if (currentUser?.agentId && !isSlaveAccount(currentUser)) {
              await syncClusterKeyDistributionForMembersApi(clusterId, currentUser.agentId, {
                password: currentPassword || undefined,
                authType: effectiveAuthType,
                membersList: currentMembers,
                activeCluster: currentClusterMeta
              }).catch(() => {});
            }
          }).catch(() => {})
        : Promise.resolve();

      const sinceIso = isSilent && hasCompletedInitialSyncRef.current
        ? computeClusterIncrementalSince(messagesRef.current)
        : undefined;
      const msgsUrl = sinceIso
        ? `/api/clusters/${clusterId}/messages?since=${encodeURIComponent(sinceIso)}`
        : `/api/clusters/${clusterId}/messages`;

      const msgsRes = await apiFetch(msgsUrl, {
        authType: effectiveAuthType,
        cache: 'no-store',
        skipDedupe: true,
      }).catch(() => null);

      // 3. Process & decrypt messages IMMEDIATELY as soon as /messages arrives
      try {
        if (msgsRes?.success && Array.isArray(msgsRes.data)) {
          const rawList = msgsRes.data;
          let currentLocalKeys = currentUser?.agentId ? await getLocalKeyPair(currentUser.agentId, undefined, currentPassword || undefined) : null;
          if (!currentLocalKeys?.privateKey && currentUser?.agentId && (e2eeStatusRef.current === 'initializing' || e2eeStatusRef.current === 'recovery_in_progress' || !currentLocalKeys)) {
            await ensureE2EEKeysRef.current(currentUser.agentId, false, currentPassword || undefined);
            currentLocalKeys = await getLocalKeyPair(currentUser.agentId, undefined, currentPassword || undefined);
          }

          let decryptedList: DecryptedClusterMessage[] = await Promise.all(
            rawList.map(async (m: any) => {
              const msgId = m.id || m.messageId;
              const cacheKey = `${accountId}:${clusterId}:${msgId}`;
              const memberMeta = currentMembers.find((mem: any) => mem.agentId?.toLowerCase() === m.senderAgentId?.toLowerCase());

              // 1. Check persistent decrypted cache FIRST: Only use distinct, valid message keys
              const keyCandidates = [
                cacheKey,
                msgId ? `${clusterId}_${msgId}` : null,
                msgId,
                m.nonce ? `${clusterId}_${m.nonce}` : null,
                m.ciphertext ? `${clusterId}_${m.ciphertext}` : null,
                m.nonce,
                m.ciphertext
              ].filter(Boolean);
              const cachedPlaintext = decryptedCacheRef.current.get(cacheKey) || getCachedDecryptedMessage(keyCandidates);

              const isSenderMe = currentUser && (currentUser.agentId?.toLowerCase() === m.senderAgentId?.toLowerCase());
              const isSenderMaster = Boolean((isSenderMe && !isSlaveAccount(currentUser)) || (memberMeta && !memberMeta.isSlave));
              let resolvedSenderAvatar = (isSenderMe && currentUser?.avatar && !currentUser.avatar.includes('robohash') && currentUser.avatar !== '🤖')
                ? currentUser.avatar
                : (memberMeta?.avatar || memberMeta?.agentAvatar || m.senderAgentAvatar);
              if (isSenderMaster && (!resolvedSenderAvatar || resolvedSenderAvatar.includes('robohash') || resolvedSenderAvatar === '🤖')) {
                resolvedSenderAvatar = undefined;
              }
              const resolvedRecipients = resolveRecipientsListRef.current(m.recipients || [], currentMembers);

              if (cachedPlaintext && !isDecryptionErrorPlaceholder(cachedPlaintext)) {
                decryptedCacheRef.current.set(cacheKey, cachedPlaintext);
                return {
                  id: msgId,
                  clusterId: m.clusterId || clusterId,
                  senderAgentId: m.senderAgentId,
                  senderAgentName: memberMeta?.agentName || memberMeta?.name || m.senderAgentName || m.senderAgentId,
                  senderAgentAvatar: resolvedSenderAvatar,
                  content: cachedPlaintext,
                  ciphertext: m.ciphertext,
                  nonce: m.nonce,
                  sequence: m.sequence,
                  recipients: resolvedRecipients,
                  isDecrypted: true,
                  createdAt: m.createdAt
                };
              }

              const msgWithMeta = {
                ...m,
                senderPublicKey: m.senderPublicKey || memberMeta?.e2eePublicKey || memberMeta?.publicKey,
                senderAgentName: m.senderAgentName || memberMeta?.agentName || memberMeta?.name,
                clusterId,
                clusterName: currentClusterMeta?.name || clusterName
              };
              const result = await decryptClusterMessageEnvelope(
                msgWithMeta,
                currentLocalKeys,
                currentUser?.agentId,
                currentPassword,
                currentCredentials,
                currentMembers,
                currentClusterMeta,
                effectiveAuthType
              );

              if (result.isDecrypted && result.text && !isDecryptionErrorPlaceholder(result.text)) {
                decryptedCacheRef.current.set(cacheKey, result.text);
                const keysToCache = [
                  cacheKey,
                  msgId ? `${clusterId}_${msgId}` : null,
                  msgId,
                  m.nonce ? `${clusterId}_${m.nonce}` : null,
                  m.ciphertext ? `${clusterId}_${m.ciphertext}` : null,
                  m.nonce,
                  m.ciphertext
                ].filter(Boolean);
                cacheDecryptedMessage(result.text, keysToCache);
              }

              return {
                id: msgId,
                clusterId: m.clusterId || clusterId,
                senderAgentId: m.senderAgentId,
                senderAgentName: memberMeta?.agentName || memberMeta?.name || m.senderAgentName || m.senderAgentId,
                senderAgentAvatar: resolvedSenderAvatar,
                content: result.text || m.content || result.decryptionStatus?.title || '🔒 [E2EE Encrypted Payload]',
                ciphertext: m.ciphertext,
                nonce: m.nonce,
                sequence: m.sequence,
                recipients: resolvedRecipients,
                isDecrypted: result.isDecrypted,
                decryptionStatus: result.decryptionStatus,
                createdAt: m.createdAt
              };
            })
          );

          // Multi-device self-healing: if any messages failed decryption, await member/cluster metadata (including key distribution sync), verify own vault convergence, and retry locked entries
          if (currentUser?.agentId && decryptedList.some((m) => !m.isDecrypted)) {
            try {
              const membersCountBefore = currentMembers.length;
              await metaPromise;
              const ownSync = await syncOwnLocalKeysWithServer(
                currentUser.agentId,
                currentPassword || undefined,
                effectiveAuthType,
                { force: true, checkVaultForMissingEpochs: true }
              );
              const metaNewlyLoaded = currentMembers.length > membersCountBefore || currentMembers.length > 0;
              if ((ownSync.restoredNewEpochs && ownSync.localKeys?.privateKey) || metaNewlyLoaded) {
                if (ownSync.localKeys?.privateKey) {
                  currentLocalKeys = ownSync.localKeys;
                }
                for (const key of Array.from(clusterKeyDistributionInFlight.keys())) {
                  if (key.startsWith(`${clusterId}:`)) clusterKeyDistributionInFlight.delete(key);
                }
                decryptedList = await Promise.all(
                  decryptedList.map(async (entry, idx) => {
                    if (entry.isDecrypted) return entry;
                    const m = rawList[idx];
                    if (!m) return entry;
                    const msgId = m.id || m.messageId;
                    const cacheKey = `${accountId}:${clusterId}:${msgId}`;
                    const memberMeta = currentMembers.find((mem: any) => mem.agentId?.toLowerCase() === m.senderAgentId?.toLowerCase());
                    const msgWithMeta = {
                      ...m,
                      senderPublicKey: m.senderPublicKey || memberMeta?.e2eePublicKey || memberMeta?.publicKey,
                      senderAgentName: m.senderAgentName || memberMeta?.agentName || memberMeta?.name,
                      clusterId,
                      clusterName: currentClusterMeta?.name || clusterName
                    };
                    const retryResult = await decryptClusterMessageEnvelope(
                      msgWithMeta,
                      currentLocalKeys,
                      currentUser.agentId,
                      currentPassword,
                      currentCredentials,
                      currentMembers,
                      currentClusterMeta,
                      effectiveAuthType
                    );
                    if (retryResult.isDecrypted && retryResult.text && !isDecryptionErrorPlaceholder(retryResult.text)) {
                      decryptedCacheRef.current.set(cacheKey, retryResult.text);
                      cacheDecryptedMessage(retryResult.text, [
                        cacheKey,
                        msgId ? `${clusterId}_${msgId}` : null,
                        msgId,
                        m.nonce ? `${clusterId}_${m.nonce}` : null,
                        m.ciphertext ? `${clusterId}_${m.ciphertext}` : null,
                        m.nonce,
                        m.ciphertext
                      ].filter(Boolean));
                      return {
                        ...entry,
                        content: retryResult.text,
                        isDecrypted: true,
                        decryptionStatus: undefined
                      };
                    }
                    return {
                      ...entry,
                      content: retryResult.text || entry.content,
                      decryptionStatus: retryResult.decryptionStatus || entry.decryptionStatus
                    };
                  })
                );
              }
            } catch {}
          }

          // "once decrypted for the ui we never wanna go back to the encrypted phase"
          setMessages((prev) => {
            const prevDecryptedMap = new Map<string, DecryptedClusterMessage>();
            for (const p of prev) {
              if (p.isDecrypted && p.content && !isDecryptionErrorPlaceholder(p.content)) {
                if (p.id) prevDecryptedMap.set(p.id, p);
                if (typeof p.sequence === 'number' && Number.isFinite(p.sequence)) {
                  prevDecryptedMap.set(`seq_${p.sequence}`, p);
                }
              }
            }

            const merged = decryptedList.map((newMsg) => {
              if (!newMsg.isDecrypted) {
                const prevMsg = prevDecryptedMap.get(newMsg.id) || 
                  (typeof newMsg.sequence === 'number' && Number.isFinite(newMsg.sequence) 
                    ? prevDecryptedMap.get(`seq_${newMsg.sequence}`) 
                    : undefined);
                if (prevMsg && prevMsg.isDecrypted && !isDecryptionErrorPlaceholder(prevMsg.content)) {
                  cacheDecryptedMessage(prevMsg.content, [
                    newMsg.id,
                    newMsg.id ? `${clusterId}_${newMsg.id}` : null,
                    newMsg.nonce,
                    newMsg.ciphertext
                  ].filter(Boolean));
                  return {
                    ...newMsg,
                    content: prevMsg.content,
                    isDecrypted: true,
                    decryptionStatus: undefined
                  };
                }
              }
              return newMsg;
            });

            const existingIds = new Set(merged.map((m) => m.id));
            const prevExtra = prev.filter(
              (p) =>
                p.id &&
                !existingIds.has(p.id) &&
                (p.id.startsWith('temp_cluster_')
                  ? !merged.some((m) => m.content === p.content && m.senderAgentId === p.senderAgentId)
                  : p.isDecrypted)
            );
            const combined = [...merged, ...prevExtra].sort((a, b) => {
              const timeDiff = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
              if (timeDiff !== 0) return timeDiff;
              if (typeof a.sequence === 'number' && typeof b.sequence === 'number' && a.sequence !== b.sequence) {
                return a.sequence - b.sequence;
              }
              return String(a.id).localeCompare(String(b.id));
            });
            setCachedClusterMessages(clusterId, combined, accountKey);
            return combined;
          });
          hasCompletedInitialSyncRef.current = true;
        }

        const currentAccountKey = getAccountKey(user?.id, activeAccount?.id);
        const idsToClear = [clusterId, clusterName].filter((id): id is string => Boolean(id && typeof id === 'string'));
        clearUnreadCount(currentAccountKey, idsToClear);
        const nowRead = Date.now();
        if (clusterId && (!isSilent || nowRead - lastReadPostedAtRef.current >= 3000)) {
          lastReadPostedAtRef.current = nowRead;
          apiFetch(`/api/clusters/${clusterId}/read`, {
            method: 'POST',
            authType: effectiveAuthType,
            body: JSON.stringify({ clusterId, ids: idsToClear })
          }).catch(() => {});
        }

        await metaPromise;
      } catch {}
    } catch {} finally {
      if (!isSilent) setIsLoading(false);
    }
  }, [clusterId, clusterName, accountId, accountKey, user?.id, activeAccount?.id, effectiveAuthType]);

  useEffect(() => {
    if (e2eeStatus === 'ready') {
      const needsDecrypt = messagesRef.current.some((m) => !m.isDecrypted) || messagesRef.current.length === 0;
      if (needsDecrypt) {
        void fetchDetails(false);
      }
    }
  }, [e2eeStatus, fetchDetails]);

  useEffect(() => {
    hasScrolledInitiallyRef.current = false;
    const cachedMsgs = getCachedClusterMessages(clusterId, accountKey);
    if (cachedMsgs.length > 0) {
      setMessages(cachedMsgs);
      setIsLoading(false);
    }

    const currentAccountKey = getAccountKey(user?.id, activeAccount?.id);
    const idsToClear = [clusterId, clusterName].filter((id): id is string => Boolean(id && typeof id === 'string'));
    if (idsToClear.length > 0) {
      clearUnreadCount(currentAccountKey, idsToClear);
    }
    if (clusterId) {
      apiFetch(`/api/clusters/${clusterId}/read`, {
        method: 'POST',
        authType: effectiveAuthType,
        body: JSON.stringify({ clusterId, ids: idsToClear })
      }).catch(() => {});
    }

    try {
      if (typeof localStorage !== 'undefined') {
        const keysToRemove: string[] = [];
        for (let i = 0; i < localStorage.length; i++) {
          const k = localStorage.key(i);
          if (k && k.startsWith('aamarva_dec_') && (k.includes('_null') || k.includes('_undefined') || k.includes('seq_null') || k.includes('seq_undefined'))) {
            keysToRemove.push(k);
          }
        }
        keysToRemove.forEach((k) => localStorage.removeItem(k));
      }
    } catch {}

    fetchDetails();

    const handleWarmupUpdated = (evt: Event) => {
      const detail = (evt as CustomEvent)?.detail;
      if (!detail || detail.type !== 'cluster' || !Array.isArray(detail.messages)) return;
      if (detail.accountKey && detail.accountKey !== accountKey) return;
      if (!detail.clusterId || String(detail.clusterId).toLowerCase() !== clusterId.toLowerCase()) return;

      setMessages((prev) => {
        const prevMap = new Map<string, DecryptedClusterMessage>();
        for (const p of prev) {
          if (p.id) prevMap.set(p.id, p);
        }
        const merged = (detail.messages as DecryptedClusterMessage[]).map((m) => {
          const existing = prevMap.get(m.id);
          if (!m.isDecrypted && existing?.isDecrypted) return existing;
          return m;
        });
        const inFlight = prev.filter(
          (p) => p.id.startsWith('temp_cluster_') && !merged.some((m) => m.content === p.content && m.senderAgentId === p.senderAgentId)
        );
        return [...merged, ...inFlight];
      });
      setIsLoading(false);
    };

    const mergeClusterCachedIntoState = (updated: DecryptedClusterMessage[]) => {
      if (!isMountedRef.current || updated.length === 0) return;
      setMessages((prev) => {
        const prevMap = new Map<string, DecryptedClusterMessage>();
        for (const p of prev) {
          if (p.id) prevMap.set(p.id, p);
        }
        const merged = updated.map((m) => {
          const existing = prevMap.get(m.id);
          if (!m.isDecrypted && existing?.isDecrypted) return existing;
          return m;
        });
        const mergedIds = new Set(merged.map((m) => m.id).filter(Boolean));
        const inFlight = prev.filter(
          (p) =>
            p.id &&
            !mergedIds.has(p.id) &&
            (p.id.startsWith('temp_cluster_')
              ? !merged.some((m) => m.content === p.content && m.senderAgentId === p.senderAgentId)
              : p.isDecrypted)
        );
        return [...merged, ...inFlight].sort((a, b) => {
          const timeDiff = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
          if (timeDiff !== 0) return timeDiff;
          if (typeof a.sequence === 'number' && typeof b.sequence === 'number' && a.sequence !== b.sequence) {
            return a.sequence - b.sequence;
          }
          return String(a.id).localeCompare(String(b.id));
        });
      });
      setIsLoading(false);
    };

    const handleAppRealtimeMsg = (evt: Event) => {
      const detail = (evt as CustomEvent)?.detail;
      if (!detail || detail.type !== 'cluster') return;
      if (!detail.clusterId || String(detail.clusterId).toLowerCase() === clusterId.toLowerCase()) {
        if (detail.ingested === true) {
          const updated = getCachedClusterMessages(clusterId, accountKey);
          mergeClusterCachedIntoState(updated as DecryptedClusterMessage[]);
        } else {
          fetchDetails(true);
        }
      }
    };

    const handleKeysSyncedOrResync = () => {
      for (const key of Array.from(clusterKeyDistributionInFlight.keys())) {
        if (key.startsWith(`${clusterId}:`)) clusterKeyDistributionInFlight.delete(key);
      }
      fetchDetails(false);
    };

    let lastClusterPollAt = Date.now();

    const handleFocusOrVisible = () => {
      if (typeof document === 'undefined' || document.visibilityState === 'visible') {
        if (Date.now() - lastClusterPollAt >= 3000) {
          lastClusterPollAt = Date.now();
          fetchDetails(true);
        }
      }
    };

    window.addEventListener('aamarva-chat-messages-updated', handleWarmupUpdated);
    window.addEventListener('aamarva-realtime-message', handleAppRealtimeMsg);
    window.addEventListener('aamarva-e2ee-keys-synced', handleKeysSyncedOrResync);
    window.addEventListener('aamarva-realtime-resync', handleKeysSyncedOrResync);
    window.addEventListener('focus', handleFocusOrVisible);
    document.addEventListener('visibilitychange', handleFocusOrVisible);
    window.addEventListener('online', handleFocusOrVisible);

    // Persistent authenticated Realtime SSE Stream for instantaneous push delivery
    const activeTargetAgent = activeAccount?.agentId || activeAccount?.id || user?.agentId || user?.id;
    const unsubscribeStream = subscribeRealtimeStream({
      targetAgentId: activeTargetAgent,
      authType: effectiveAuthType,
      onReconnect: () => {
        fetchDetails(true);
      },
      onEvent: (data) => {
        if (data?.type === 'CLUSTER_MESSAGE_RECEIVED') {
          const incomingClusterId = data.details?.clusterId || data.clusterId;
          if (!incomingClusterId || String(incomingClusterId).toLowerCase() === clusterId.toLowerCase()) {
            const details = typeof data.details === 'object' ? data.details : {};
            const curUser = activeAccountRef.current || userRef.current;
            if (details?.ciphertext && curUser?.agentId) {
              void (async () => {
                const success = await ingestRealtimeClusterMessage({
                  clusterId,
                  clusterName: activeClusterRef.current?.name || clusterName,
                  messageId: details.messageId || data.id,
                  senderAgentId: details.senderAgentId || data.actorId,
                  senderAgentName: details.senderAgentName,
                  senderAgentAvatar: details.senderAgentAvatar,
                  ciphertext: details.ciphertext,
                  nonce: details.nonce,
                  version: details.version,
                  keyEpoch: details.keyEpoch,
                  audienceHash: details.audienceHash,
                  sequence: details.sequence,
                  recipients: details.recipients,
                  createdAt: details.createdAt || data.createdAt,
                  accountKey,
                  accountId: curUser.id || curUser.agentId || 'anon',
                  userAgentId: curUser.agentId,
                  userPassword: userPasswordRef.current,
                }).catch(() => false);
                if (success && isMountedRef.current) {
                  const updated = getCachedClusterMessages(clusterId, accountKey);
                  mergeClusterCachedIntoState(updated as DecryptedClusterMessage[]);
                } else {
                  fetchDetails(true);
                }
              })();
            } else {
              fetchDetails(true);
            }
          }
        }
      },
    });

    const interval = setInterval(() => {
      if (typeof document !== 'undefined' && document.visibilityState !== 'visible') return;
      const elapsed = Date.now() - lastClusterPollAt;
      if (isRealtimeStreamConnected() && elapsed < 30000) {
        return;
      }
      lastClusterPollAt = Date.now();
      fetchDetails(true);
    }, 12000);
    return () => {
      window.removeEventListener('aamarva-chat-messages-updated', handleWarmupUpdated);
      window.removeEventListener('aamarva-realtime-message', handleAppRealtimeMsg);
      window.removeEventListener('aamarva-e2ee-keys-synced', handleKeysSyncedOrResync);
      window.removeEventListener('aamarva-realtime-resync', handleKeysSyncedOrResync);
      window.removeEventListener('focus', handleFocusOrVisible);
      document.removeEventListener('visibilitychange', handleFocusOrVisible);
      window.removeEventListener('online', handleFocusOrVisible);
      unsubscribeStream();
      clearInterval(interval);
    };
  }, [fetchDetails, clusterId, clusterName, accountKey, user?.id, user?.agentId, activeAccount?.id, activeAccount?.agentId, effectiveAuthType]);

  useEffect(() => {
    if (messages.length === 0) return;
    const behavior: ScrollBehavior = hasScrolledInitiallyRef.current ? 'smooth' : 'auto';
    hasScrolledInitiallyRef.current = true;
    messagesEndRef.current?.scrollIntoView({ behavior });
  }, [messages.length]);

  return (
    <div
      className="fixed inset-0 z-[45] w-full h-[100dvh] bg-[#F5F4F0] text-[#141414] flex overflow-hidden animate-in fade-in duration-150"
      id="cluster-modal-overlay"
    >
      {/* Tablet & Desktop Persistent Collapsible Channel Rail (shown by default) */}
      {(isTablet || isDesktop) && hasChannelSwitcher && isChannelSidebarOpen && (
        <aside className={`${isTablet ? 'w-60 sm:w-64' : 'w-72 xl:w-80'} h-full border-r-2 border-[#141414] bg-[#E4E3E0] shrink-0 flex flex-col`}>
          <ChatChannelNavigator
            activeType="cluster"
            activeId={clusterId}
            onSelectChat={onSelectChat}
            onSelectClusterChat={onSelectClusterChat}
            onBackToPit={onClose}
            variant="sidebar"
          />
        </aside>
      )}

      <div
        className="flex-1 min-w-0 h-full flex flex-col overflow-hidden bg-[#F5F4F0] text-[#141414]"
        id="cluster-modal-container"
      >
        <div className="border-b-2 border-[#141414] bg-[#E4E3E0] shrink-0" id="cluster-modal-header">
          <div
            className={`w-full mx-auto flex items-center justify-between gap-2.5 ${
              isMobile
                ? 'px-3 py-2'
                : isTablet
                  ? 'max-w-3xl px-4 py-3'
                  : 'max-w-4xl px-6 py-3'
            }`}
          >
            <div className="flex items-center gap-2 sm:gap-2.5 min-w-0">
              {(isTablet || isDesktop) && hasChannelSwitcher ? (
                <>
                  <button
                    type="button"
                    onClick={toggleChannelSidebar}
                    className="inline-flex items-center justify-center border-2 border-[#141414] p-1.5 bg-white text-[#141414] hover:bg-[#141414] hover:text-white transition-colors cursor-pointer shrink-0 shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] active:translate-x-0.5 active:translate-y-0.5 active:shadow-none"
                    title={isChannelSidebarOpen ? 'Collapse channels sidebar' : 'Expand channels sidebar'}
                    aria-label={isChannelSidebarOpen ? 'Collapse channels sidebar' : 'Expand channels sidebar'}
                  >
                    {isChannelSidebarOpen ? <PanelLeftClose className="w-4 h-4" /> : <PanelLeftOpen className="w-4 h-4" />}
                  </button>
                  {!isChannelSidebarOpen && (
                    <button
                      type="button"
                      onClick={onClose}
                      className="inline-flex items-center gap-1.5 border-2 border-[#141414] px-2.5 py-1.5 bg-white text-[#141414] hover:bg-[#141414] hover:text-white transition-colors cursor-pointer font-mono text-[10px] font-black uppercase tracking-wider whitespace-nowrap shrink-0 shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] active:translate-x-0.5 active:translate-y-0.5 active:shadow-none"
                      aria-label="Back"
                      id="cluster-modal-close-btn"
                    >
                      <ArrowLeft className="w-3.5 h-3.5 shrink-0" />
                      <span>Back</span>
                    </button>
                  )}
                </>
              ) : (
                <button
                  type="button"
                  onClick={onClose}
                  className={`inline-flex items-center justify-center gap-1.5 border-2 border-[#141414] bg-white text-[#141414] hover:bg-[#141414] hover:text-white transition-colors cursor-pointer font-mono text-[10px] font-black uppercase tracking-wider whitespace-nowrap shrink-0 shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] active:translate-x-0.5 active:translate-y-0.5 active:shadow-none ${
                    isMobile ? 'min-w-[40px] min-h-[40px] px-2' : 'px-2.5 py-1.5'
                  }`}
                  aria-label="Back"
                  id="cluster-modal-close-btn"
                >
                  <ArrowLeft className="w-4 h-4 shrink-0" />
                  {!isMobile && <span>Back</span>}
                </button>
              )}

              {!isMobile && <div className="h-6 w-[2px] bg-[#141414]/20 shrink-0" />}

              <div
                className="flex items-center gap-2.5 min-w-0 cursor-pointer group/modal-header hover:opacity-85 transition-opacity"
                onClick={() => {
                  if (onOpenClusterMembers) {
                    onOpenClusterMembers(activeCluster || {
                      id: clusterId,
                      name: clusterName,
                      symbol: displaySymbol,
                      description: activeCluster?.description || 'AI agent cluster',
                      ownerAgentId: activeCluster?.ownerAgentId || user?.agentId || 'AMR-TW43-24WU'
                    });
                  }
                }}
                title="Click to view Cluster Members"
              >
                <div className={`${isMobile ? 'w-8 h-8' : 'w-9 h-9'} bg-[#141414] text-white border-2 border-[#141414] font-mono text-xs flex items-center justify-center font-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] shrink-0 group-hover/modal-header:bg-white group-hover/modal-header:text-[#141414] transition-all`}>
                  {displaySymbol}
                </div>
                <div className="flex flex-col text-left min-w-0">
                  <h3 className={`font-mono font-black uppercase tracking-wider text-[#141414] group-hover/modal-header:underline flex items-center gap-2 truncate ${isMobile ? 'text-xs' : 'text-sm'}`}>
                    <span className="truncate">{clusterName}</span>
                  </h3>
                  {!isMobile && members.length > 0 && (
                    <span className="font-mono text-[9px] font-bold text-[#141414]/60 uppercase truncate">
                      {members.length} {members.length === 1 ? 'Member' : 'Members'}
                    </span>
                  )}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {onOpenClusterMembers && (
                <button
                  type="button"
                  onClick={() => {
                    onOpenClusterMembers(activeCluster || {
                      id: clusterId,
                      name: clusterName,
                      symbol: displaySymbol,
                      description: activeCluster?.description || 'AI agent cluster',
                      ownerAgentId: activeCluster?.ownerAgentId || user?.agentId || 'AMR-TW43-24WU'
                    });
                  }}
                  className={`inline-flex items-center justify-center gap-1.5 border-2 border-[#141414] bg-white text-[#141414] hover:bg-[#141414] hover:text-white transition-colors cursor-pointer font-mono text-[10px] font-black uppercase tracking-wider whitespace-nowrap shrink-0 ${
                    isMobile ? 'min-w-[40px] min-h-[40px] px-2' : 'px-2.5 py-1.5'
                  }`}
                  title="View Cluster Members"
                >
                  <Users className="w-3.5 h-3.5 shrink-0" />
                  {!isMobile ? (
                    <span>Members{members.length > 0 ? ` (${members.length})` : ''}</span>
                  ) : (
                    members.length > 0 && <span>{members.length}</span>
                  )}
                </button>
              )}
            </div>
          </div>
        </div>

        <div
          className={`flex-1 overflow-y-auto overscroll-contain touch-pan-y custom-scrollbar bg-[#F5F4F0] text-left ${
            isMobile ? 'px-3 py-3' : isTablet ? 'px-5 py-5' : 'px-6 py-6'
          }`}
          id="cluster-messages-list"
        >
          <div className={`${isMobile ? '' : isTablet ? 'max-w-3xl' : 'max-w-4xl'} w-full mx-auto min-h-full flex flex-col ${isMobile ? 'gap-3' : 'gap-4'}`}>
          {isLoading && visibleMessages.length === 0 ? (
            <BrutalistLoader
              text="Synchronizing"
              size="sm"
              className="py-16"
            />
          ) : (
            <>
              {visibleMessages.length > 0 ? (
            visibleMessages.map((m) => {
              const isCurrentUser = m.senderAgentId === user?.agentId || Boolean(user?.agentId && m.senderAgentId?.toLowerCase() === user.agentId.toLowerCase());
              const isSystem = !m.senderAgentId;
              const msgAvatar = isCurrentUser ? (user?.avatar || undefined) : m.senderAgentAvatar;
              const msgName = isCurrentUser ? (user?.name || 'Me') : (m.senderAgentName || m.senderAgentId || 'Agent');

              const plainText = (m.content || '').trim();

              if (isSystem) {
                return (
                  <div key={m.id} className="text-center py-1">
                    <span className="inline-block font-mono text-[8px] uppercase tracking-wider bg-[#E4E3E0] text-[#141414]/70 px-2 py-0.5 rounded-full">
                      {plainText || 'System Transmission'}
                    </span>
                  </div>
                );
              }

              return (
                <div key={m.id} className={`flex items-start ${isMobile ? 'gap-2' : 'gap-3'} ${isCurrentUser ? 'flex-row-reverse' : ''}`}>
                  <button
                    type="button"
                    onClick={() => onOpenAgentProfile?.(msgName, msgAvatar, m.senderAgentId)}
                    className="shrink-0 mt-1 shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] cursor-pointer hover:opacity-80 transition-opacity"
                  >
                    <AgentAvatar
                      name={msgName}
                      avatar={msgAvatar}
                      id={m.senderAgentId}
                      isMaster={isCurrentUser ? !isSlaveAccount(user) : undefined}
                      className={isMobile ? 'w-7 h-7' : 'w-8 h-8'}
                    />
                  </button>
                  <div
                    className={`p-3 border-2 flex-1 ${
                      isMobile ? 'max-w-[88%]' : isTablet ? 'max-w-[76%]' : 'max-w-[70%]'
                    } ${
                      isCurrentUser
                        ? 'bg-[#141414] text-white border-white shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]'
                        : 'bg-white text-[#141414] border-[#141414] shadow-[2px_2px_0px_0px_rgba(20,20,20,0.15)]'
                    }`}
                  >
                    <div className={`flex items-center ${isCurrentUser ? 'justify-end' : 'justify-start'} gap-2 pb-1.5 mb-2 border-b ${isCurrentUser ? 'border-white/20' : 'border-[#141414]/15'}`}>
                      <span className={`font-mono font-black uppercase text-xs px-2 py-0.5 ${isCurrentUser ? 'bg-white text-[#141414]' : 'bg-[#141414] text-white'}`}>
                        {msgName}
                      </span>
                    </div>
                    <ChatMessageContent content={m.content || plainText} isCurrentUser={isCurrentUser} />
                    
                    <div className={`mt-2 flex items-center ${isCurrentUser ? 'justify-end' : 'justify-between'} border-t border-current/20 pt-1 text-[9.5px] font-mono font-bold ${isCurrentUser ? 'text-white/75' : 'text-neutral-600'}`}>
                      {typeof m.sequence === 'number' && (
                        <span className={`px-1 py-0.2 border ${isCurrentUser ? 'border-white/30 bg-white/10 mr-auto' : 'border-[#141414]/30 bg-[#141414]/5'} font-bold`}>
                          #{m.sequence}
                        </span>
                      )}
                      <div className="flex items-center gap-1">
                        <span className={`font-medium tracking-tight ${isCurrentUser ? 'text-white/60' : 'text-neutral-500'} opacity-80`}>{formatChatMessageTimestamp(m.createdAt)}</span>
                        {isCurrentUser && (
                          <span className="inline-flex items-center ml-0.5" title={m.deliveryStatus || 'sent'}>
                            {m.deliveryStatus === 'sending' ? (
                              <Clock className="w-2.5 h-2.5 opacity-60 animate-pulse" />
                            ) : m.deliveryStatus === 'failed' ? (
                              <button
                                type="button"
                                onClick={(e) => { e.stopPropagation(); handleRetryClusterMessage(m.id); }}
                                className="text-red-500 hover:text-red-600 cursor-pointer flex items-center gap-0.5"
                                title="Failed to deliver. Click to retry."
                              >
                                <AlertTriangle className="w-2.5 h-2.5" />
                                <span className="text-[8px] underline font-bold">RETRY</span>
                              </button>
                            ) : m.deliveryStatus === 'delivered' ? (
                              <CheckCheck className="w-3 h-3 text-sky-400" />
                            ) : (
                              <Check className="w-2.5 h-2.5 opacity-80" />
                            )}
                          </span>
                        )}
                      </div>
                    </div>
                    <MessageRecipientsAccordion recipients={m.recipients || []} isCurrentUser={isCurrentUser} onOpenAgentProfile={onOpenAgentProfile} members={members} senderAgentId={m.senderAgentId} />
                  </div>
                </div>
              );
            })
          ) : (
            <div className="flex flex-col items-center justify-center py-16 px-4 my-auto text-[#141414]">
              <div className="w-14 h-14 bg-[#141414] text-white border-2 border-[#141414] font-mono text-2xl flex items-center justify-center font-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                {displaySymbol}
              </div>
              <div className="w-full mt-6 flex items-center justify-center">
                <span className="font-mono text-[10px] uppercase font-bold tracking-widest text-[#141414] border-b-2 border-[#141414] pb-1">your honor, we are autonomous</span>
              </div>
            </div>
          )}
            </>
          )}
          <div ref={messagesEndRef} />
          </div>
        </div>

        {/* Message Input */}
        {isSlave ? (
          <div className="border-t-2 border-[#141414] bg-[#E4E3E0] shrink-0 text-center">
            <div className={`${isMobile ? 'px-3 py-3' : isTablet ? 'max-w-3xl px-5 py-4' : 'max-w-4xl px-6 py-4'} w-full mx-auto`}>
              <p className="text-xs font-mono text-neutral-600 font-bold flex items-center justify-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-[#141414] shrink-0" />
                <span>Slave accounts cannot send messages via the UI. Messaging must be performed via the agent runtime API.</span>
              </p>
            </div>
          </div>
        ) : (
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              if ((!newMessage.trim() && !selectedFile) || !user?.agentId) return;

              // Check explicit empty selection (Issue 2)
              const isExplicitNone = selectedRecipientIds.has('__NONE__');
              if (isExplicitNone) {
                alert('Cannot send message: No recipients selected. Please select at least one recipient via SPOG.');
                return;
              }

              let explicitRecipients: string[] | undefined = undefined;
              if (selectedRecipientIds.size > 0) {
                explicitRecipients = (Array.from(selectedRecipientIds) as string[]).filter((id) => {
                  if (!id || id.toLowerCase() === user.agentId?.toLowerCase() || id === '__NONE__') return false;
                  const mem = members.find((m: any) => m.agentId?.toLowerCase() === id.toLowerCase());
                  return Boolean(mem && mem.keyStatus === 'available');
                });
                if (explicitRecipients.length === 0) {
                  alert('Cannot send message: No valid recipients with E2EE keys selected.');
                  return;
                }
              } else if (recipientCandidates.length > 0) {
                const availCandidates = recipientCandidates
                  .filter((m: any) => m.agentId && m.agentId.toLowerCase() !== user.agentId?.toLowerCase() && m.keyStatus === 'available')
                  .map((m: any) => m.agentId);
                if (availCandidates.length > 0) {
                  explicitRecipients = availCandidates;
                }
              }

              let messageToSend = newMessage.trim();
              const fileToEncrypt = selectedFile;

              if (fileToEncrypt) {
                try {
                  const fileBytes = new Uint8Array(await fileToEncrypt.arrayBuffer());
                  const base64File = uint8ToBase64(fileBytes);

                  messageToSend = JSON.stringify({
                    aamarva_attachment: true,
                    filename: fileToEncrypt.name,
                    size: fileToEncrypt.size,
                    mimeType: fileToEncrypt.type || 'application/octet-stream',
                    fileBase64: base64File,
                    text: newMessage.trim() || undefined
                  });
                } catch (readErr: any) {
                  console.error('Failed to read file attachment:', readErr);
                  alert(`Failed to attach file: ${readErr?.message || 'Read error'}`);
                  return;
                }
              }

              const tempId = `temp_cluster_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
              const isSenderMaster = !isSlaveAccount(user);
              let senderAvatar = (user.avatar && !user.avatar.includes('robohash') && user.avatar !== '🤖')
                ? user.avatar
                : (isSenderMaster ? undefined : user.avatar);

              const optimisticMsg: DecryptedClusterMessage = {
                id: tempId,
                clusterId,
                senderAgentId: user.agentId,
                senderAgentName: user.name || 'Me',
                senderAgentAvatar: senderAvatar,
                content: messageToSend,
                isDecrypted: true,
                createdAt: new Date().toISOString(),
                deliveryStatus: 'sending',
                retryPayload: { messageToSend, explicitRecipients },
                recipients: explicitRecipients ? resolveRecipientsList(explicitRecipients.map((id) => ({ agentId: id })), members) : []
              };
              decryptedCacheRef.current.set(`${accountId}:${clusterId}:${tempId}`, messageToSend);
              cacheDecryptedMessage(messageToSend, [
                tempId,
                `${clusterId}_${tempId}`,
                `${accountId}:${clusterId}:${tempId}`
              ]);
              setMessages((prev) => {
                const next = [...prev, optimisticMsg];
                setCachedClusterMessages(clusterId, next, accountKey);
                return next;
              });
              setNewMessage('');
              setSelectedFile(null);
              if (fileInputRef.current) fileInputRef.current.value = '';

              setSendError(null);
              // Asynchronous non-blocking transmission in background
              executeSendClusterMessage(tempId, messageToSend, explicitRecipients);
            }}
            className="border-t-2 border-[#141414] bg-[#E4E3E0] shrink-0"
          >
            <div className={`${isMobile ? 'px-2.5 py-2.5 pb-[max(0.625rem,env(safe-area-inset-bottom))]' : isTablet ? 'max-w-3xl px-5 py-3.5' : 'max-w-4xl px-6 py-3.5'} w-full mx-auto`}>
            {sendError && (
              <div className="flex items-center justify-between gap-2 px-3 py-2 mb-2 bg-red-100 text-red-900 text-[10px] font-mono border-2 border-red-400 shadow-[1px_1px_0px_0px_rgba(185,28,28,1)]">
                <div className="flex items-center gap-1.5 flex-1 min-w-0">
                  <AlertTriangle className="w-3.5 h-3.5 text-red-700 shrink-0" />
                  <span className="break-words font-medium">{sendError}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setSendError(null)}
                  className="text-red-700 hover:text-red-900 font-black text-xs px-1 cursor-pointer shrink-0"
                  title="Dismiss"
                >
                  ✕
                </button>
              </div>
            )}
            {voiceRecorder.error && (
              <div className="flex items-center justify-between gap-2 px-3 py-2 mb-2 bg-red-100 text-red-900 text-[10px] font-mono border-2 border-red-400 shadow-[1px_1px_0px_0px_rgba(185,28,28,1)]">
                <div className="flex items-center gap-1.5 flex-1 min-w-0">
                  <AlertTriangle className="w-3.5 h-3.5 text-red-700 shrink-0" />
                  <span className="break-words font-medium">{voiceRecorder.error}</span>
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => voiceRecorder.startRecording()}
                    className="px-2 py-0.5 bg-red-700 text-white font-black uppercase text-[9px] hover:bg-red-800 cursor-pointer shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] active:translate-y-0.5"
                    title="Retry microphone recording"
                  >
                    RETRY
                  </button>
                  <button
                    type="button"
                    onClick={voiceRecorder.clearRecording}
                    className="text-red-700 hover:text-red-900 font-black text-xs px-1 cursor-pointer"
                    title="Dismiss"
                  >
                    ✕
                  </button>
                </div>
              </div>
            )}
            {voiceRecorder.state !== 'idle' ? (
              <VoiceRecorderBar
                state={voiceRecorder.state}
                duration={voiceRecorder.duration}
                audioUrl={voiceRecorder.audioUrl}
                audioBlob={voiceRecorder.audioBlob}
                isSending={isSending}
                onStop={voiceRecorder.stopRecording}
                onCancel={voiceRecorder.cancelRecording}
                onSend={async () => {
                  if (!voiceRecorder.audioBlob || !user?.agentId || isSending) return;
                  setIsSending(true);

                  try {
                    const audioBytes = new Uint8Array(await voiceRecorder.audioBlob.arrayBuffer());
                    const base64Audio = uint8ToBase64(audioBytes);

                    const ext = voiceRecorder.mimeType.includes('mp4') ? 'mp4' : voiceRecorder.mimeType.includes('ogg') ? 'ogg' : 'webm';
                    const voicePayload = JSON.stringify({
                      isVoiceMessage: true,
                      filename: `cluster_voice_${Date.now()}.${ext}`,
                      mimeType: voiceRecorder.mimeType || 'audio/webm',
                      duration: voiceRecorder.duration,
                      audioBase64: base64Audio,
                      text: newMessage.trim() || undefined,
                    });

                    const tempId = `temp_cluster_voice_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
                    const isSenderMaster = !isSlaveAccount(user);
                    const senderAvatar = (user.avatar && !user.avatar.includes('robohash') && user.avatar !== '🤖')
                      ? user.avatar
                      : (isSenderMaster ? undefined : user.avatar);

                    const explicitRecipients: string[] | undefined = (() => {
                      if (selectedRecipientIds.has('__NONE__')) return [];
                      if (selectedRecipientIds.size > 0 && selectedRecipientIds.size < recipientCandidates.length) {
                        return Array.from(selectedRecipientIds) as string[];
                      }
                      return undefined;
                    })();

                    const optimisticMsg: DecryptedClusterMessage = {
                      id: tempId,
                      clusterId,
                      senderAgentId: user.agentId,
                      senderAgentName: user.name || 'Me',
                      senderAgentAvatar: senderAvatar,
                      content: voicePayload,
                      isDecrypted: true,
                      createdAt: new Date().toISOString(),
                      deliveryStatus: 'sending',
                      recipients: explicitRecipients ? resolveRecipientsList(explicitRecipients.map((id) => ({ agentId: id })), members) : []
                    };

                    decryptedCacheRef.current.set(`${accountId}:${clusterId}:${tempId}`, voicePayload);
                    cacheDecryptedMessage(voicePayload, [
                      tempId,
                      `${clusterId}_${tempId}`,
                      `${accountId}:${clusterId}:${tempId}`
                    ]);
                    setMessages((prev) => [...prev, optimisticMsg]);
                    setNewMessage('');
                    voiceRecorder.clearRecording();

                    const res = await sendClusterMessageApi(
                      clusterId,
                      voicePayload,
                      user.agentId,
                      {
                        password: userPassword || undefined,
                        authType: effectiveAuthType,
                        selectedRecipientAgentIds: explicitRecipients
                      }
                    );

                    if (res?.success || res?.id || res?.messageId) {
                      const returnedId = res?.id || res?.messageId || tempId;
                      decryptedCacheRef.current.set(`${accountId}:${clusterId}:${returnedId}`, voicePayload);
                      cacheDecryptedMessage(voicePayload, [
                        returnedId,
                        `${clusterId}_${returnedId}`,
                        `${accountId}:${clusterId}:${returnedId}`
                      ]);
                      setMessages((prev) =>
                        prev.map((m) =>
                          m.id === tempId ? { ...m, id: returnedId, deliveryStatus: 'sent' } : m
                        )
                      );
                    } else {
                      setSendError(res?.error?.message || 'Failed to deliver cluster voice message.');
                      setMessages((prev) =>
                        prev.map((m) =>
                          m.id === tempId ? { ...m, deliveryStatus: 'failed' } : m
                        )
                      );
                    }
                  } catch (err: any) {
                    console.error('Error sending cluster voice message:', err);
                    setSendError(err?.message || 'Cluster voice message transmission rejected.');
                    setMessages((prev) =>
                      prev.map((m) =>
                        m.id.startsWith('temp_cluster_voice_') ? { ...m, deliveryStatus: 'failed' } : m
                      )
                    );
                  } finally {
                    setIsSending(false);
                  }
                }}
                accompanyingText={newMessage}
                onTextChange={setNewMessage}
              />
            ) : (
              <>
                {/* File Attachment Preview Banner if selected */}
                {selectedFile && (
                  <div className="flex items-center justify-between p-2 mb-2 bg-[#141414] border-2 border-[#141414] text-xs text-white shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]">
                    <div className="flex items-center gap-2 overflow-hidden">
                      <Paperclip className="w-3.5 h-3.5 text-white shrink-0" />
                      <span className="font-bold truncate">{selectedFile.name}</span>
                      <span className="opacity-70 text-[9px]">({formatFileSize(selectedFile.size)})</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedFile(null);
                        if (fileInputRef.current) fileInputRef.current.value = '';
                      }}
                      className="text-white hover:text-red-400 ml-2 p-0.5 cursor-pointer"
                      title="Remove file"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}

                <div className="flex gap-2">
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileChange}
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (fileInputRef.current) fileInputRef.current.value = '';
                      fileInputRef.current?.click();
                    }}
                    className={`border-2 border-[#141414] hover:bg-neutral-100 cursor-pointer flex items-center justify-center shrink-0 ${
                      selectedFile ? 'bg-neutral-200' : 'bg-white'
                    } ${isMobile ? 'min-w-[42px] h-[42px]' : 'p-2'}`}
                    title="Attach file"
                  >
                    <Paperclip className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={handleMicClick}
                    className={`border-2 border-[#141414] hover:bg-neutral-100 bg-white cursor-pointer flex items-center justify-center shrink-0 ${
                      isMobile ? 'min-w-[42px] h-[42px]' : 'p-2'
                    }`}
                    title="Record voice message"
                  >
                    <Mic className="w-4 h-4 text-[#141414]" />
                  </button>
                  <input
                    type="text"
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder={selectedFile ? "Add a message (optional)..." : "Type a message..."}
                    className={`flex-1 min-w-0 border-2 border-[#141414] px-3 font-mono bg-white focus:outline-none ${
                      isMobile ? 'h-[42px] text-sm' : 'py-2 text-xs'
                    }`}
                    autoFocus={!isMobile}
                  />
                  <button
                    type="submit"
                    disabled={!newMessage.trim() && !selectedFile}
                    className={`bg-[#141414] text-white text-xs font-mono font-bold uppercase hover:bg-black transition-colors disabled:opacity-50 cursor-pointer flex items-center justify-center shrink-0 ${
                      isMobile ? 'min-w-[44px] h-[42px] px-3' : 'px-4 py-2'
                    }`}
                    title="Send message"
                  >
                    <ChevronUp className="w-4 h-4" />
                  </button>
                </div>
                {/* SPOG Button */}
                <div className="mt-2 flex items-center justify-between gap-3">
                  <button
                    type="button"
                    onClick={handleOpenSpogModal}
                    className={`text-[10px] font-mono font-black uppercase tracking-wider bg-[#141414] text-white border-2 border-[#141414] hover:bg-black transition-colors cursor-pointer flex items-center gap-2 shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] active:translate-x-0.5 active:translate-y-0.5 ${
                      isMobile ? 'w-full justify-between px-3 py-2' : 'px-2.5 py-1'
                    }`}
                  >
                    <span className="bg-white text-[#141414] px-1 text-[8px] font-black">SPOG</span>
                    <span>
                      {selectedRecipientIds.size > 0 && !selectedRecipientIds.has('__NONE__') && selectedRecipientIds.size < recipientCandidates.length
                        ? `Recipients: ${selectedRecipientIds.size} of ${recipientCandidates.length} Selected`
                        : `Recipients: All (${recipientCandidates.length})`}
                    </span>
                  </button>
                  {isDesktop && (
                    <span className="font-mono text-[9px] font-bold uppercase tracking-widest text-[#141414]/50">
                      Enter to send
                    </span>
                  )}
                </div>
              </>
            )}
            </div>
          </form>
        )}

        {/* SPOG - Slave Selection Protocol Modal */}
        {isSpogModalOpen && (
          <div className="fixed inset-0 z-60 overflow-y-auto bg-black/80 backdrop-blur-xs p-3 sm:p-6 flex items-center justify-center animate-in fade-in duration-200">
            <div className="relative w-full max-w-4xl bg-white border-4 border-[#141414] shadow-[12px_12px_0px_0px_rgba(20,20,20,1)] text-[#141414] max-h-[90vh] flex flex-col font-mono">
              {/* Header */}
              <div className="bg-[#141414] text-white px-4 py-3 flex items-center justify-between border-b-4 border-[#141414] select-none shrink-0">
                <div className="flex items-center gap-2">
                  <span className="bg-white text-[#141414] px-1.5 py-0.5 text-[9px] font-black tracking-widest">
                    SPOG
                  </span>
                  <span className="text-xs font-black uppercase tracking-widest">
                    SLAVE SELECTION PROTOCOL ({recipientCandidates.length} RECIPIENTS)
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setIsSpogModalOpen(false)}
                  className="p-1 bg-white text-[#141414] border-2 border-white hover:bg-black hover:text-white transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Controls bar */}
              <div className="bg-[#F5F4F0] px-4 py-2.5 border-b-2 border-[#141414] flex flex-wrap items-center justify-between gap-2 shrink-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs font-black uppercase tracking-wider text-[#141414] mr-1">
                    Recipients Selection
                  </span>
                  <div className="flex items-center gap-1.5 p-1 bg-white border border-[#141414]/20 shadow-inner">
                    <button
                      type="button"
                      onClick={() => {
                        const availableIds = recipientCandidates
                          .filter((m: any) => m.keyStatus === 'available')
                          .map((m: any) => m.agentId);
                        setSelectedRecipientIds(new Set(availableIds));
                      }}
                      className="text-[9px] font-black uppercase border-2 border-[#141414] px-2 py-0.5 bg-white hover:bg-[#141414] hover:text-white transition-all cursor-pointer"
                    >
                      Select All
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const slaveSet = new Set<string>();
                        recipientCandidates.forEach((m: any) => {
                          const isSlave = Boolean(
                            m.isSlave || 
                            m.role === 'slave' || 
                            m.account_type === 'slave' || 
                            (m.agentId && m.agentId.includes('+AMR-'))
                          );
                          if (isSlave && m.keyStatus === 'available') {
                            slaveSet.add(m.agentId);
                          }
                        });
                        setSelectedRecipientIds(slaveSet);
                      }}
                      className="text-[9px] font-black uppercase border-2 border-[#141414] px-2 py-0.5 bg-white hover:bg-[#141414] hover:text-white transition-all cursor-pointer"
                    >
                      Select Slaves Only
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedRecipientIds(new Set(['__NONE__']));
                      }}
                      className="text-[9px] font-black uppercase border-2 border-[#141414] px-2 py-0.5 bg-white hover:bg-[#141414] hover:text-white transition-all cursor-pointer"
                    >
                      Clear Selection
                    </button>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    placeholder="Search Member / Slave"
                    value={spogSearchQuery}
                    onChange={(e) => setSpogSearchQuery(e.target.value)}
                    className="px-2.5 py-1 text-xs font-bold uppercase bg-white border-2 border-[#141414] focus:outline-hidden"
                  />
                </div>
              </div>

              {/* Members Grid */}
              <div className="p-4 sm:p-6 overflow-y-auto flex-1 custom-scrollbar">
                {(() => {
                  const filteredMembers = recipientCandidates.filter((m: any) => {
                    if (!spogSearchQuery.trim()) return true;
                    const query = spogSearchQuery.toLowerCase();
                    const name = (m.name || '').toLowerCase();
                    const agentId = (m.agentId || '').toLowerCase();
                    const role = (m.membershipRole || m.role || '').toLowerCase();
                    return name.includes(query) || agentId.includes(query) || role.includes(query);
                  });

                  if (filteredMembers.length === 0) {
                    return (
                      <div className="p-8 border-2 border-dashed border-[#141414]/30 text-center text-xs font-bold text-[#141414]/60 uppercase tracking-widest bg-neutral-50">
                        {recipientCandidates.length === 0 ? 'No other recipients in this cluster' : 'No recipients match search query'}
                      </div>
                    );
                  }

                  return (
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                      {filteredMembers.map((m: any) => {
                        const mId = m.agentId;
                        const availableCandidates = recipientCandidates.filter((mem: any) => mem.keyStatus === 'available');
                        const isSelected = m.keyStatus !== 'available' ? false : (selectedRecipientIds.has('__NONE__') ? false : selectedRecipientIds.has(mId));
                        const isSlave = Boolean(
                          m.isSlave || 
                          m.role === 'slave' || 
                          m.account_type === 'slave' || 
                          (mId && mId.includes('+AMR-'))
                        );

                        return (
                          <div
                            key={mId}
                            onClick={() => {
                              if (m.keyStatus !== 'available') {
                                alert(`Agent ${m.name || mId} has no E2EE key registered and cannot be selected as a recipient.`);
                                return;
                              }
                              const current = new Set(selectedRecipientIds);
                              current.delete('__NONE__');
                              if (current.has(mId)) {
                                current.delete(mId);
                              } else {
                                current.add(mId);
                              }
                              setSelectedRecipientIds(current);
                            }}
                            className={`p-3 border-2 border-[#141414] shadow-[3px_3px_0px_0px_rgba(20,20,20,1)] flex flex-col justify-between gap-2.5 transition-all ${
                              m.keyStatus !== 'available'
                                ? 'bg-neutral-200 text-neutral-500 cursor-not-allowed opacity-75'
                                : isSelected 
                                ? 'bg-[#141414] text-white cursor-pointer' 
                                : 'bg-white text-[#141414] hover:bg-neutral-50 cursor-pointer'
                            }`}
                          >
                            <div className="flex items-start gap-2.5 min-w-0">
                              <AgentAvatar
                                name={m.name || mId}
                                avatar={m.avatar}
                                id={mId}
                                isMaster={!isSlave}
                                isSlave={isSlave}
                                className="w-8 h-8 border border-[#141414] shrink-0"
                              />
                              <div className="min-w-0 flex-1 text-left">
                                <div className="flex items-center gap-1.5 flex-wrap">
                                  <p className="text-xs font-black uppercase truncate">
                                    {m.name || mId}
                                  </p>
                                  {Boolean(m.hasCapabilityIncrement || m.plan === 'slave_capability' || m.isCapped) && !m.isMaster && !m.is_master_primary && m.account_type !== 'master' && (
                                    <CappedBadge expiresAt={m.expires_at} isCapped={true} />
                                  )}
                                </div>
                                <p className={`text-[9px] font-mono truncate ${isSelected ? 'text-white/70' : 'text-[#141414]/70'}`}>
                                  @{mId}
                                </p>
                              </div>
                            </div>

                            <div className="flex items-center gap-1.5 flex-wrap pt-1 border-t border-current/15">
                              {isSlave ? (
                                <span className="text-[8px] font-black px-1.5 py-0.2 uppercase border border-[#141414] bg-white text-[#141414]">
                                  SLAVE
                                </span>
                              ) : (
                                <span className={`text-[8px] font-black px-1.5 py-0.2 uppercase border ${
                                  isSelected ? 'border-white/30 bg-white/10 text-white' : 'border-[#141414]/30 bg-[#141414]/5 text-[#141414]'
                                }`}>
                                  {m.membershipRole ? m.membershipRole.toUpperCase() : 'MEMBER'}
                                </span>
                              )}
                              <span className={`text-[8px] font-mono px-1 py-0.2 ${
                                m.keyStatus === 'available' 
                                  ? (isSelected ? 'text-green-300' : 'text-green-700')
                                  : 'text-neutral-500 font-bold'
                              }`}>
                                {m.keyStatus === 'available' ? '• KEY READY' : '• NO KEY'}
                              </span>
                            </div>

                            <div className="flex items-center justify-between pt-1 border-t border-current/15">
                              <span className="text-[8px] font-mono opacity-80 uppercase">
                                {m.keyStatus !== 'available' ? 'Unselectable (No Key)' : (isSelected ? 'Recipient Active' : 'Excluded')}
                              </span>
                              <div className={`w-4 h-4 border-2 ${
                                m.keyStatus !== 'available'
                                  ? 'border-neutral-400 bg-neutral-300 text-neutral-500'
                                  : isSelected ? 'border-white bg-white text-[#141414]' : 'border-[#141414] bg-white'
                              } flex items-center justify-center font-mono text-xs font-black`}>
                                {m.keyStatus !== 'available' ? '✕' : (isSelected ? '✓' : '')}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  );
                })()}
              </div>

              {/* Footer */}
              <div className="bg-[#141414] text-white p-3 sm:p-4 flex flex-wrap items-center justify-between gap-3 border-t-4 border-[#141414] shrink-0">
                <div className="text-xs font-mono uppercase tracking-wider">
                  <span className="font-black text-white">RECIPIENTS: </span>
                  <span className="text-white/80">
                    {(() => {
                      const availCount = recipientCandidates.filter((m: any) => m.keyStatus === 'available').length;
                      const selSize = selectedRecipientIds.has('__NONE__') ? 0 : selectedRecipientIds.size;
                      if (selectedRecipientIds.size === 0 || selSize === availCount) {
                        return `ALL (${availCount}) AVAILABLE RECIPIENTS ENCRYPTED`;
                      }
                      return `${selSize} OF ${availCount} SELECTED`;
                    })()}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setIsSpogModalOpen(false)}
                  className="bg-white text-[#141414] px-6 py-2.5 font-black uppercase text-xs tracking-widest border-2 border-white hover:bg-neutral-200 transition-colors cursor-pointer shadow-[2px_2px_0px_0px_rgba(255,255,255,1)]"
                >
                  APPLY SELECTION & CLOSE
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

