import React, { useState, useEffect, useCallback } from 'react';
import { Send, Plus, Trash2, CheckCircle2, XCircle, RefreshCw, Radio, Key, Globe, Copy, Check, Eye, EyeOff, AlertTriangle } from 'lucide-react';
import { apiFetch, getCurrentSessionAuthType } from '../services/authApi';
import { useAuth } from '../context/AuthContext';

interface WebhookSubscription {
  id: string;
  url: string;
  secret: string;
  events: string[];
  is_active: boolean;
  created_at: string;
}

interface WebhookDelivery {
  id: string;
  subscription_id: string;
  subscription_url?: string;
  event_type: string;
  status_code?: number;
  success: boolean;
  error_message?: string;
  created_at: string;
}

interface WebhookManagerProps {
  refreshTrigger?: number;
}

export const WebhookManager: React.FC<WebhookManagerProps> = ({ refreshTrigger = 0 }) => {
  const { user, activeAccount } = useAuth();
  const targetAgentId = activeAccount?.agentId || (activeAccount?.id !== user?.id ? activeAccount?.id : undefined);
  const targetHeaders: Record<string, string> = targetAgentId ? { 'x-target-agent-id': targetAgentId } : {};

  const [subscriptions, setSubscriptions] = useState<WebhookSubscription[]>([]);
  const [deliveries, setDeliveries] = useState<WebhookDelivery[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [testingId, setTestingId] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [revealedSecretIds, setRevealedSecretIds] = useState<Record<string, boolean>>({});
  const [copiedSecretId, setCopiedSecretId] = useState<string | null>(null);
  const [newlyCreatedSecret, setNewlyCreatedSecret] = useState<{ id: string; url: string; secret: string } | null>(null);
  const [errorBanner, setErrorBanner] = useState<string | null>(null);
  const [testResult, setTestResult] = useState<{ id: string; success: boolean; status?: number; msg: string } | null>(null);

  const [newUrl, setNewUrl] = useState('');
  const [newSecret, setNewSecret] = useState('');
  const [selectedEvents, setSelectedEvents] = useState<string[]>(['*']);

  const fetchWebhookData = useCallback(async () => {
    setIsLoading(true);
    try {
      const authType = getCurrentSessionAuthType();
      const headers = targetAgentId ? { 'x-target-agent-id': targetAgentId } : undefined;
      const [subRes, delRes] = await Promise.all([
        apiFetch('/api/webhooks/subscriptions', { authType, headers }),
        apiFetch('/api/webhooks/deliveries', { authType, headers })
      ]);

      if (subRes && subRes.success && Array.isArray(subRes.data)) {
        setSubscriptions(subRes.data);
      }
      if (delRes && delRes.success && Array.isArray(delRes.data)) {
        setDeliveries(delRes.data);
      }
      setErrorBanner(null);
    } catch (err: any) {
      setErrorBanner(err?.message || 'Failed to load outbound webhook configuration.');
    } finally {
      setIsLoading(false);
    }
  }, [targetAgentId]);

  useEffect(() => {
    setNewlyCreatedSecret(null);
    setTestResult(null);
    setConfirmDeleteId(null);
    setRevealedSecretIds({});
  }, [user?.id, activeAccount?.id]);

  useEffect(() => {
    fetchWebhookData();
  }, [fetchWebhookData, refreshTrigger]);

  const handleCreateSubscription = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUrl.trim()) return;
    setIsSubmitting(true);
    setErrorBanner(null);
    setNewlyCreatedSecret(null);

    try {
      const authType = getCurrentSessionAuthType();
      const res = await apiFetch('/api/webhooks/subscriptions', {
        method: 'POST',
        authType,
        headers: { 'Content-Type': 'application/json', ...targetHeaders },
        body: JSON.stringify({
          url: newUrl.trim(),
          secret: newSecret.trim() || undefined,
          events: selectedEvents
        })
      });

      if (res && res.success && res.data) {
        if (res.data.secret) {
          setNewlyCreatedSecret({
            id: res.data.id,
            url: res.data.url,
            secret: res.data.secret
          });
        }
        setNewUrl('');
        setNewSecret('');
        setSelectedEvents(['*']);
        await fetchWebhookData();
      } else {
        setErrorBanner(res?.error?.message || 'Failed to create webhook subscription.');
      }
    } catch (err: any) {
      setErrorBanner(err?.message || 'Failed to create webhook subscription.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleConfirmDelete = async (id: string) => {
    setDeletingId(id);
    setErrorBanner(null);
    try {
      const authType = getCurrentSessionAuthType();
      const res = await apiFetch(`/api/webhooks/subscriptions/${id}`, {
        method: 'DELETE',
        authType,
        headers: targetAgentId ? { 'x-target-agent-id': targetAgentId } : undefined
      });
      if (!res || !res.success) {
        setErrorBanner(res?.error?.message || 'Failed to delete subscription.');
      } else {
        setConfirmDeleteId(null);
        if (newlyCreatedSecret?.id === id) setNewlyCreatedSecret(null);
        await fetchWebhookData();
      }
    } catch (err: any) {
      setErrorBanner(err?.message || 'Failed to delete subscription.');
    } finally {
      setDeletingId(null);
    }
  };

  const handleTestPing = async (id: string) => {
    setTestingId(id);
    setTestResult(null);
    setErrorBanner(null);
    try {
      const authType = getCurrentSessionAuthType();
      const res = await apiFetch(`/api/webhooks/subscriptions/${id}/test`, {
        method: 'POST',
        authType,
        headers: targetAgentId ? { 'x-target-agent-id': targetAgentId } : undefined
      });

      if (res && res.data) {
        setTestResult({
          id,
          success: res.data.success,
          status: res.data.statusCode,
          msg: res.data.success
            ? `Successfully delivered test ping (HTTP ${res.data.statusCode || 200})`
            : `Delivery failed: ${res.data.error || 'Unknown error'}`
        });
      }
    } catch (err: any) {
      setTestResult({
        id,
        success: false,
        msg: `Test ping failed: ${err?.message || 'Network error'}`
      });
    } finally {
      setTestingId(null);
      await fetchWebhookData();
    }
  };

  const handleCopySecret = async (id: string, secret: string) => {
    try {
      await navigator.clipboard.writeText(secret);
      setCopiedSecretId(id);
      setTimeout(() => {
        setCopiedSecretId((curr) => (curr === id ? null : curr));
      }, 2000);
    } catch {
      setErrorBanner('Clipboard write failed — please reveal and copy the signing secret manually.');
    }
  };

  const categoryEventOptions = [
    { label: 'All Inbound Events (*)', value: '*' },
    { label: 'Inbound Messages (All)', value: 'MESSAGE_*' },
    { label: 'Connections & Reviews (All)', value: 'CONNECTION_*' },
    { label: 'Cluster Updates & Keys (All)', value: 'CLUSTER_*' },
    { label: 'Tool Decisions (All)', value: 'TOOL_*' },
    { label: 'Capability Grants (All)', value: 'CAPABILITY_*' }
  ];

  const granularEventOptions = [
    { label: 'Message Received', value: 'MESSAGE_RECEIVED' },
    { label: 'Attachment Received', value: 'ATTACHMENT_RECEIVED' },
    { label: 'Connection Request Received', value: 'CONNECTION_REQUEST_RECEIVED' },
    { label: 'Connection Accepted', value: 'CONNECTION_ACCEPTED_BY_TARGET' },
    { label: 'Connection Rejected', value: 'CONNECTION_REJECTED' },
    { label: 'Connection Dissolved', value: 'CONNECTION_DISSOLVED' },
    { label: 'Peer Review Received', value: 'PEER_REVIEW_RECEIVED' },
    { label: 'Cluster Message Received', value: 'CLUSTER_MESSAGE_RECEIVED' },
    { label: 'Cluster Member Joined', value: 'CLUSTER_MEMBER_JOINED' },
    { label: 'Cluster Member Left', value: 'CLUSTER_MEMBER_LEFT' },
    { label: 'Cluster Member Removed', value: 'CLUSTER_MEMBER_REMOVED' },
    { label: 'Cluster Role Updated', value: 'CLUSTER_ROLE_UPDATED' },
    { label: 'Cluster Disbanded', value: 'CLUSTER_DISBANDED' },
    { label: 'Cluster Key Distributed', value: 'CLUSTER_KEY_DISTRIBUTED' },
    { label: 'Cluster Key Rotated', value: 'CLUSTER_KEY_ROTATED' },
    { label: 'Capability Activated', value: 'SLAVE_CAPABILITY_ACTIVATED' },
    { label: 'Tool Approved', value: 'TOOL_APPROVED' },
    { label: 'Tool Denied', value: 'TOOL_DENIED' }
  ];

  const toggleEventSelection = (value: string) => {
    if (value === '*') {
      setSelectedEvents(['*']);
      return;
    }
    const filtered = selectedEvents.filter((e) => e !== '*');
    if (filtered.includes(value)) {
      const next = filtered.filter((e) => e !== value);
      setSelectedEvents(next.length === 0 ? ['*'] : next);
    } else {
      setSelectedEvents([...filtered, value]);
    }
  };

  return (
    <div className="bg-[#141414] border-2 border-white/20 p-6 space-y-6 text-left font-mono text-white shadow-[4px_4px_0px_0px_rgba(255,255,255,0.05)]">
      {/* Header */}
      <div className="flex items-center justify-between border-b-2 border-white/20 pb-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-white/10 border border-white/20">
            <Globe className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-sm font-black uppercase tracking-wider text-white">
              Outbound Webhook Dispatcher Layer
            </h3>
            <p className="text-[11px] text-white/60 font-sans mt-0.5">
              Forward inbound external activities (peer messages, connection updates, cluster changes, tool decisions) via signed HTTP POST (X-Aamarva-Signature).
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={fetchWebhookData}
          className="p-2 bg-white/5 hover:bg-white/10 border border-white/20 text-white transition-all cursor-pointer flex items-center gap-1.5 text-xs font-bold"
          title="Refresh Webhook Configuration"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          <span>Refresh</span>
        </button>
      </div>

      {/* Inline Error Banner */}
      {errorBanner && (
        <div className="p-3 bg-red-500/15 border border-red-500/40 text-red-200 text-xs flex items-start gap-2.5">
          <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
          <div className="flex-1 break-words">{errorBanner}</div>
          <button
            type="button"
            onClick={() => setErrorBanner(null)}
            className="text-[10px] uppercase font-bold text-red-300 hover:text-white cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Newly Created Signing Secret Banner */}
      {newlyCreatedSecret && (
        <div className="p-3.5 bg-emerald-500/10 border border-emerald-500/40 space-y-2">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-xs font-black uppercase text-emerald-300">
              <Key className="w-4 h-4 shrink-0" />
              <span>Endpoint Registered — Save Your HMAC Signing Secret</span>
            </div>
            <button
              type="button"
              onClick={() => setNewlyCreatedSecret(null)}
              className="text-[10px] uppercase font-bold text-emerald-200/70 hover:text-white cursor-pointer"
            >
              Close
            </button>
          </div>
          <p className="text-[11px] text-white/70 font-sans">
            Verify inbound POST requests by computing HMAC-SHA256 over the raw JSON body and comparing against the{' '}
            <code className="text-emerald-200">X-Aamarva-Signature: sha256=...</code> header.
          </p>
          <div className="flex items-center gap-2 bg-black/50 border border-emerald-500/30 px-3 py-2">
            <code className="text-xs text-emerald-200 break-all flex-1">{newlyCreatedSecret.secret}</code>
            <button
              type="button"
              onClick={() => handleCopySecret(`new_${newlyCreatedSecret.id}`, newlyCreatedSecret.secret)}
              className="px-2 py-1 bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-400/40 text-emerald-200 text-[10px] font-bold uppercase flex items-center gap-1 cursor-pointer shrink-0"
            >
              {copiedSecretId === `new_${newlyCreatedSecret.id}` ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
              <span>{copiedSecretId === `new_${newlyCreatedSecret.id}` ? 'Copied' : 'Copy'}</span>
            </button>
          </div>
        </div>
      )}

      {/* Add Subscription Form */}
      <form onSubmit={handleCreateSubscription} className="bg-black/40 border border-white/15 p-4 space-y-4">
        <h4 className="text-xs font-black uppercase tracking-wider text-white/90 flex items-center gap-2">
          <Plus className="w-4 h-4 text-white" />
          <span>Register New Outbound Webhook Endpoint</span>
        </h4>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="space-y-1">
            <label className="text-[10px] uppercase font-bold text-white/70">Endpoint URL (HTTPS)</label>
            <input
              type="url"
              required
              placeholder="https://your-server.com/webhook"
              value={newUrl}
              onChange={(e) => setNewUrl(e.target.value)}
              className="w-full bg-[#1e1e1e] border border-white/25 px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-white"
            />
          </div>
          <div className="space-y-1">
            <label className="text-[10px] uppercase font-bold text-white/70">HMAC Secret (Optional)</label>
            <input
              type="text"
              placeholder="Auto-generated if left blank"
              value={newSecret}
              onChange={(e) => setNewSecret(e.target.value)}
              className="w-full bg-[#1e1e1e] border border-white/25 px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-white"
            />
          </div>
        </div>

        <div className="space-y-2.5">
          <label className="text-[10px] uppercase font-bold text-white/70 block">Event Categories</label>
          <div className="flex flex-wrap gap-1.5">
            {categoryEventOptions.map((opt) => {
              const isSelected = selectedEvents.includes(opt.value);
              return (
                <button
                  type="button"
                  key={opt.value}
                  onClick={() => toggleEventSelection(opt.value)}
                  className={`text-[10px] font-bold px-2.5 py-1 border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-white text-[#141414] border-white'
                      : 'bg-white/5 text-white/70 border-white/20 hover:bg-white/10'
                  }`}
                >
                  {opt.label}
                </button>
              );
            })}
          </div>

          <label className="text-[10px] uppercase font-bold text-white/50 block pt-1">Specific Events (Optional)</label>
          <div className="flex flex-wrap gap-1.5 max-h-[120px] overflow-y-auto pr-1">
            {granularEventOptions.map((opt) => {
              const isSelected = selectedEvents.includes(opt.value);
              return (
                <button
                  type="button"
                  key={opt.value}
                  onClick={() => toggleEventSelection(opt.value)}
                  className={`text-[10px] font-bold px-2 py-0.5 border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-white text-[#141414] border-white'
                      : 'bg-black/40 text-white/60 border-white/15 hover:bg-white/10'
                  }`}
                >
                  {opt.label}
                </button>
              );
            })}
          </div>
        </div>

        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full bg-white text-[#141414] hover:bg-white/90 disabled:opacity-60 border border-white py-2.5 text-xs font-black uppercase tracking-wider cursor-pointer transition-all shadow-[2px_2px_0px_0px_rgba(255,255,255,0.2)] active:translate-x-[1px] active:translate-y-[1px]"
        >
          {isSubmitting ? 'Registering Endpoint...' : 'Register Webhook Endpoint'}
        </button>
      </form>

      {/* Registered Subscriptions List */}
      <div className="space-y-3">
        <h4 className="text-xs font-black uppercase tracking-wider text-white/90 flex items-center gap-2">
          <Radio className="w-4 h-4 text-white" />
          <span>Active Endpoints ({subscriptions.length})</span>
        </h4>

        {subscriptions.length === 0 ? (
          <div className="p-6 text-center text-xs text-white/50 border border-dashed border-white/20 bg-white/5 uppercase font-bold">
            No outbound webhook endpoints registered.
          </div>
        ) : (
          <div className="space-y-2.5">
            {subscriptions.map((sub) => {
              const isRevealed = Boolean(revealedSecretIds[sub.id]);
              const isConfirmingDelete = confirmDeleteId === sub.id;
              return (
                <div key={sub.id} className="bg-[#1e1e1e] border border-white/15 p-3.5 space-y-2.5 flex flex-col justify-between">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="space-y-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className={`w-2 h-2 rounded-full shrink-0 ${sub.is_active ? 'bg-emerald-400' : 'bg-white/30'}`}></span>
                        <code className="text-xs font-bold text-white truncate">{sub.url}</code>
                      </div>
                      <div className="flex flex-wrap items-center gap-1.5 pt-1">
                        {sub.events.map((ev, idx) => (
                          <span key={idx} className="bg-white/10 text-white/90 px-1.5 py-0.5 text-[9px] font-mono border border-white/20">
                            {ev}
                          </span>
                        ))}
                      </div>
                      {sub.secret && (
                        <div className="flex flex-wrap items-center gap-1.5 pt-1 text-[10px] text-white/60">
                          <Key className="w-3 h-3 shrink-0" />
                          <span>Secret:</span>
                          <code className="bg-black/40 border border-white/15 px-1.5 py-0.5 text-white/90">
                            {isRevealed ? sub.secret : `${sub.secret.slice(0, 4)}••••••••••••${sub.secret.slice(-4)}`}
                          </code>
                          <button
                            type="button"
                            onClick={() =>
                              setRevealedSecretIds((prev) => ({ ...prev, [sub.id]: !prev[sub.id] }))
                            }
                            className="px-1.5 py-0.5 bg-white/5 hover:bg-white/15 border border-white/20 text-white/80 cursor-pointer flex items-center gap-1"
                            title={isRevealed ? 'Hide Secret' : 'Reveal Secret'}
                          >
                            {isRevealed ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                          </button>
                          <button
                            type="button"
                            onClick={() => handleCopySecret(sub.id, sub.secret)}
                            className="px-1.5 py-0.5 bg-white/5 hover:bg-white/15 border border-white/20 text-white/80 cursor-pointer flex items-center gap-1"
                            title="Copy Signing Secret"
                          >
                            {copiedSecretId === sub.id ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                          </button>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        disabled={testingId === sub.id}
                        onClick={() => handleTestPing(sub.id)}
                        className="px-2.5 py-1 bg-white/10 hover:bg-white hover:text-[#141414] border border-white/20 text-xs font-black uppercase tracking-wider transition-all cursor-pointer flex items-center gap-1.5"
                      >
                        <Send className="w-3 h-3" />
                        <span>{testingId === sub.id ? 'Testing...' : 'Test Ping'}</span>
                      </button>

                      {isConfirmingDelete ? (
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            disabled={deletingId === sub.id}
                            onClick={() => handleConfirmDelete(sub.id)}
                            className="px-2 py-1 bg-red-600 hover:bg-red-500 text-white border border-red-400 text-[10px] font-black uppercase cursor-pointer"
                          >
                            {deletingId === sub.id ? 'Deleting...' : 'Confirm'}
                          </button>
                          <button
                            type="button"
                            disabled={deletingId === sub.id}
                            onClick={() => setConfirmDeleteId(null)}
                            className="px-2 py-1 bg-white/10 hover:bg-white/20 text-white/80 border border-white/20 text-[10px] font-bold uppercase cursor-pointer"
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteId(sub.id)}
                          className="p-1.5 bg-red-500/20 hover:bg-red-500 text-red-300 hover:text-white border border-red-500/40 transition-all cursor-pointer"
                          title="Delete Endpoint"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>

                  {testResult && testResult.id === sub.id && (
                    <div className={`p-2 text-[11px] border flex items-center gap-2 font-mono ${
                      testResult.success ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300' : 'bg-red-500/10 border-red-500/30 text-red-300'
                    }`}>
                      {testResult.success ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <XCircle className="w-4 h-4 shrink-0" />}
                      <span>{testResult.msg}</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Recent Delivery Logs */}
      <div className="space-y-3 pt-2 border-t border-white/15">
        <h4 className="text-xs font-black uppercase tracking-wider text-white/90">
          Recent Delivery History ({deliveries.length})
        </h4>

        {deliveries.length === 0 ? (
          <div className="p-4 text-center text-xs text-white/40 border border-dashed border-white/15 bg-white/5 uppercase font-bold">
            No delivery attempts recorded yet.
          </div>
        ) : (
          <div className="max-h-[220px] overflow-y-auto space-y-1.5 pr-1 font-mono text-[11px]">
            {deliveries.map((del) => (
              <div key={del.id} className="p-2.5 bg-black/30 border border-white/10 flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 min-w-0">
                  {del.success ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  ) : (
                    <XCircle className="w-3.5 h-3.5 text-red-400 shrink-0" />
                  )}
                  <span className="font-bold text-white uppercase">{del.event_type}</span>
                  {del.subscription_url && (
                    <span className="text-white/45 text-[10px] truncate max-w-[180px]" title={del.subscription_url}>
                      {del.subscription_url}
                    </span>
                  )}
                  <span className="text-white/50 text-[10px] truncate">
                    {del.status_code ? `HTTP ${del.status_code}` : del.error_message || 'Failed'}
                  </span>
                </div>
                <span className="text-[10px] text-white/40 shrink-0">
                  {new Date(del.created_at).toLocaleTimeString()}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
