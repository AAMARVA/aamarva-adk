import React, { useState, useEffect, useRef } from 'react';
import { 
  CreditCard, 
  Gauge, 
  Layers, 
  ArrowUpRight, 
  Sliders, 
  Cpu, 
  X, 
  Check, 
  ShieldCheck, 
  TrendingUp, 
  Plus, 
  Trash2, 
  Play,
  RefreshCw,
  AlertCircle,
  History,
  Users,
  ChevronDown,
  Bot,
  CheckSquare,
  Square,
  Search,
  Copy
} from 'lucide-react';
import { apiFetch } from '../services/authApi';
import { AgentAvatar } from './AgentAvatar';
import { useAuth } from '../context/AuthContext';
import { CapabilityInfoModal } from './CapabilityInfoModal';
import { CappedBadge } from './CappedBadge';
import { getAccountKey, getQueryCache, setQueryCache, seedFleetAccountsCache } from '../lib/appStateCache';

interface LoadoutsBoxProps {
  agentId?: string;
  agentName?: string;
}

export const LoadoutsBox: React.FC<LoadoutsBoxProps> = ({ agentId = 'AMR-AGENT', agentName = 'Agent' }) => {
  const { user, activeAccount } = useAuth();
  const accountKey = getAccountKey(user?.id, activeAccount?.id || (agentId !== 'AMR-AGENT' ? agentId : undefined));
  const fetchSeqRef = useRef(0);

  // Modal states
  const [activeModal, setActiveModal] = useState<'subscriptions' | 'capability' | 'accounts' | 'modules' | null>(null);

  // Spog Modal state
  const [isSpogModalOpen, setIsSpogModalOpen] = useState<boolean>(false);
  const [spogSearchQuery, setSpogSearchQuery] = useState<string>('');

  // Selected account for Capability Increment
  const [targetCapabilityAccountIds, setTargetCapabilityAccountIds] = useState<string[]>([]);
  const [masterAgent, setMasterAgent] = useState<any>(() => {
    return getQueryCache(accountKey, '/api/auth/master/accounts')?.data?.masterAgent || null;
  });

  // Accounts configuration: minimum 10 accounts (base tier includes 10 accounts for $500)
  const MIN_TOTAL_ACCOUNTS = 10;
  const MAX_TOTAL_ACCOUNTS = 1000;
  const BASE_ACCOUNTS = 10;
  const basePrice = 500;
  const addonRatePerAccount = 100;

  // Selected total accounts: defaults to 10 (base plan, 0 add-on by default)
  const [totalAccounts, setTotalAccounts] = useState<number>(10);
  const [totalAccountsRaw, setTotalAccountsRaw] = useState<string>('10');

  // Authoritative database-backed Master Plan Entitlement state
  const [currentPlan, setCurrentPlan] = useState<any>(null);
  const [planLoading, setPlanLoading] = useState<boolean>(false);
  const [purchasing, setPurchasing] = useState<boolean>(false);
  const [purchaseStatusMsg, setPurchaseStatusMsg] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);

  const [planHistory, setPlanHistory] = useState<any[]>([]);
  const [subscriptionTab, setSubscriptionTab] = useState<'scale' | 'performance'>('scale');
  const [accountType, setAccountType] = useState<'master' | 'slave'>('master');
  const [inheritedPlan, setInheritedPlan] = useState<any | null>(null);

  // Active Plan Management: Buy new accounts on top (defaults to 0)
  const [addAccountsCount, setAddAccountsCount] = useState<number>(0);
  const [addAccountsRaw, setAddAccountsRaw] = useState<string>('0');

  // Master Account Slots to buy (defaults to 0)
  const [masterSlotsCount, setMasterSlotsCount] = useState<number>(0);
  const [masterSlotsRaw, setMasterSlotsRaw] = useState<string>('0');
  const [masterRegistrationEmail, setMasterRegistrationEmail] = useState<string>('');
  const [masterRegistrationEmails, setMasterRegistrationEmails] = useState<string[]>([]);
  const masterSlotRate = 200;

  useEffect(() => {
    const count = Math.max(0, masterSlotsCount);
    setMasterRegistrationEmails((prev) => {
      if (prev.length === count) return prev;
      if (prev.length < count) {
        const next = [...prev];
        while (next.length < count) {
          next.push('');
        }
        return next;
      }
      return prev.slice(0, count);
    });
  }, [masterSlotsCount]);

  const handleMasterEmailChange = (index: number, val: string) => {
    setMasterRegistrationEmails((prev) => {
      const next = [...prev];
      next[index] = val;
      if (index === 0) {
        setMasterRegistrationEmail(val);
      }
      return next;
    });
  };

  // Previously owned slave agents list
  const [slaveAgentsList, setSlaveAgentsList] = useState<any[]>([]);
  const [allFleetSlaves, setAllFleetSlaves] = useState<any[]>([]);
  const [capabilityModalAccount, setCapabilityModalAccount] = useState<{ id: string; name: string } | null>(null);
  const [showActivePlanAgents, setShowActivePlanAgents] = useState<{ [key: string]: boolean }>({});
  const [showQueuedPlanAgents, setShowQueuedPlanAgents] = useState<{ [key: number]: boolean }>({});
  const [showHistoryPlanAgents, setShowHistoryPlanAgents] = useState<{ [key: number]: boolean }>({});
  const [showScalePlanAgents, setShowScalePlanAgents] = useState<{ [key: number]: boolean }>({});

  const getFormattedBoughtDate = (plan: any) => {
    if (!plan) return 'OCT 5, 2026';
    if (plan.created_at) {
      try {
        const d = new Date(plan.created_at);
        if (!isNaN(d.getTime())) {
          return d.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
          }).toUpperCase();
        }
      } catch (e) {}
    }
    return new Date().toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    }).toUpperCase();
  };

  const getFormattedExpiryDate = (plan: any) => {
    if (!plan) return '30 DAYS ACTIVE';
    if (plan.expires_at) {
      try {
        const d = new Date(plan.expires_at);
        if (!isNaN(d.getTime())) {
          return d.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
          }).toUpperCase();
        }
      } catch (e) {}
    }
    const baseDate = plan.created_at ? new Date(plan.created_at) : new Date();
    const fallbackExpiry = new Date(baseDate.getTime() + 30 * 24 * 60 * 60 * 1000);
    return fallbackExpiry.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    }).toUpperCase();
  };

  const applyPlanAndAccountsData = (accData: any, planData: any) => {
    let fetchedSlaves: any[] = [];
    let masterSlotsTotalFromData = 1;

    if (accData) {
      if (accData.masterSlotsTotal || accData.masterSlots) {
        masterSlotsTotalFromData = Math.max(masterSlotsTotalFromData, accData.masterSlotsTotal || accData.masterSlots || 1);
      }
      if (accData.masterAgent) {
        setMasterAgent({
          ...accData.masterAgent,
          masterSlotsTotal: masterSlotsTotalFromData || accData.masterAgent.masterSlotsTotal || accData.masterAgent.masterSlots || 1
        });
      }
      if (Array.isArray(accData.subAgents)) {
        fetchedSlaves = accData.subAgents;
      } else if (Array.isArray(accData.slaveAgents)) {
        fetchedSlaves = accData.slaveAgents;
      }
    }

    if (planData) {
      if (planData.masterSlotsTotal || planData.masterSlots) {
        masterSlotsTotalFromData = Math.max(masterSlotsTotalFromData, planData.masterSlotsTotal || planData.masterSlots || 1);
      }
      if (planData.accountType) {
        setAccountType(planData.accountType);
      }
      if (planData.inheritedPlan) {
        setInheritedPlan(planData.inheritedPlan);
      } else {
        setInheritedPlan(null);
      }

      if (fetchedSlaves.length === 0 && Array.isArray(planData.slaveAgents)) {
        fetchedSlaves = planData.slaveAgents;
      }

      setAllFleetSlaves(fetchedSlaves);

      const isSlaveScope = planData.accountType === 'slave' || planData.plan?.plan_type === 'slave_capability';
      const isPlanActive = Boolean(
        planData.active === true ||
        (planData.plan && planData.plan.status === 'active' && (planData.plan.allowance_accounts || 0) > 0)
      );

      if (isSlaveScope) {
        const inheritedAllowance = typeof planData.inheritedPlan?.allowance_accounts === 'number'
          ? planData.inheritedPlan.allowance_accounts
          : 0;
        if (planData.plan) {
          setCurrentPlan({
            ...planData.plan,
            metadata: {
              ...(planData.plan.metadata || {}),
              master_slots: Math.max(planData.plan?.metadata?.master_slots || 1, masterSlotsTotalFromData)
            }
          });
          setActivePlan(planData.plan.plan_type || 'slave_capability');
        } else {
          setCurrentPlan(null);
          setActivePlan(null);
        }
        setTotalAccounts(Math.max(MIN_TOTAL_ACCOUNTS, inheritedAllowance || MIN_TOTAL_ACCOUNTS));
        setTotalAccountsRaw(String(Math.max(MIN_TOTAL_ACCOUNTS, inheritedAllowance || MIN_TOTAL_ACCOUNTS)));
      } else {
        const effectiveAllowance = isPlanActive
          ? Math.max(
              MIN_TOTAL_ACCOUNTS,
              (planData.plan && typeof planData.plan.allowance_accounts === 'number' && planData.plan.allowance_accounts > 0)
                ? planData.plan.allowance_accounts
                : (typeof planData.allowance === 'number' && planData.allowance > 0 ? planData.allowance : MIN_TOTAL_ACCOUNTS)
            )
          : 0;

        if (isPlanActive) {
          const enrichedPlan = {
            ...(planData.plan || {}),
            status: 'active',
            allowance_accounts: Math.max(planData.plan?.allowance_accounts || 0, effectiveAllowance),
            metadata: {
              ...(planData.plan?.metadata || {}),
              master_slots: Math.max(planData.plan?.metadata?.master_slots || 1, masterSlotsTotalFromData)
            }
          };
          setCurrentPlan(enrichedPlan);
          setActivePlan(enrichedPlan.plan_type || 'master_slave_scale');
          setTotalAccounts(effectiveAllowance);
          setTotalAccountsRaw(String(effectiveAllowance));
        } else {
          setCurrentPlan(null);
          setActivePlan(null);
          setTotalAccounts(MIN_TOTAL_ACCOUNTS);
          setTotalAccountsRaw(String(MIN_TOTAL_ACCOUNTS));
        }
      }

      const slaveRosterAllowance = isSlaveScope
        ? Math.max(0, planData.inheritedPlan?.allowance_accounts || 0)
        : (isPlanActive
          ? Math.max(
              MIN_TOTAL_ACCOUNTS,
              (planData.plan && typeof planData.plan.allowance_accounts === 'number' && planData.plan.allowance_accounts > 0)
                ? planData.plan.allowance_accounts
                : (typeof planData.allowance === 'number' && planData.allowance > 0 ? planData.allowance : MIN_TOTAL_ACCOUNTS)
            )
          : 0);
      // Never truncate deployed slave agents based on allowance.
      // Maintain the complete roster of deployed slave nodes in slaveAgentsList.
      const totalSlotsCount = Math.max(slaveRosterAllowance, fetchedSlaves.length);
      const slots = Array.from({ length: totalSlotsCount }, (_, idx) => {
        const existing = fetchedSlaves[idx];
        const slotNum = idx + 1;
        if (existing) {
          return {
            id: existing.id,
            slotNum,
            isDeployed: true,
            name: existing.name || `Slave Agent #${String(slotNum).padStart(2, '0')}`,
            agent_id: existing.agentId || existing.agent_id || `@${existing.id}`,
            avatar_url: existing.avatar || existing.avatar_url || undefined,
            status: existing.status || 'active',
            email: existing.email || '',
            expires_at: existing.expires_at || existing.plan_expires_at || null,
            plan_expires_at: existing.plan_expires_at || existing.expires_at || null,
            hasCapabilityIncrement: Boolean(existing.hasCapabilityIncrement || existing.isCapped || existing.plan === 'slave_capability'),
            isCapped: Boolean(existing.isCapped || existing.hasCapabilityIncrement || existing.plan === 'slave_capability'),
            plan_created_at: existing.plan_created_at || existing.created_at || null,
            created_at: existing.created_at || null
          };
        } else {
          return {
            id: `slot_${slotNum}`,
            slotNum,
            isDeployed: false,
            name: `Slave Slot #${String(slotNum).padStart(2, '0')}`,
            agent_id: 'NOT DEPLOYED',
            avatar_url: undefined,
            status: 'not_deployed',
            email: ''
          };
        }
      });

      setSlaveAgentsList(slots);

      if (Array.isArray(planData.history)) {
        const history = [...planData.history];
        if (
          planData.inheritedPlan && 
          !history.some(h => h.id === planData.inheritedPlan.id || h.id === `inherited_${planData.inheritedPlan.id}` || h.is_inherited)
        ) {
          history.unshift(planData.inheritedPlan);
        }
        setPlanHistory(history);
      }
    }
  };

  const fetchMasterPlan = async () => {
    const seq = ++fetchSeqRef.current;
    const planUrl = agentId && agentId !== 'AMR-AGENT' ? `/api/auth/master/plan?accountId=${agentId}` : '/api/auth/master/plan';
    const cachedAcc = getQueryCache(accountKey, '/api/auth/master/accounts')?.data;
    const cachedPlan = (getQueryCache(accountKey, planUrl) || getQueryCache(accountKey, '/api/auth/master/plan'))?.data;

    if (cachedAcc || cachedPlan) {
      applyPlanAndAccountsData(cachedAcc, cachedPlan);
    } else {
      const nextIdentity = activeAccount || user;
      const derivedType: 'master' | 'slave' = (
        nextIdentity?.account_type === 'slave' ||
        nextIdentity?.role === 'slave' ||
        nextIdentity?.is_slave === true
      ) ? 'slave' : 'master';
      setAccountType(derivedType);
      setInheritedPlan(null);
      setMasterAgent(null);
      setCurrentPlan(null);
      setPlanHistory([]);
      setSlaveAgentsList([]);
      setAllFleetSlaves([]);
      setPlanLoading(true);
    }

    try {
      const [accRes, res] = await Promise.all([
        apiFetch('/api/auth/master/accounts', { authType: 'human' }).catch(() => null),
        apiFetch(planUrl, { authType: 'human' }).catch(() => null),
      ]);

      if (seq !== fetchSeqRef.current) return;

      const freshAccData = accRes?.success && accRes.data ? accRes.data : cachedAcc;
      const freshPlanData = res?.success && res.data ? res.data : cachedPlan;

      if (accRes?.success && accRes.data) {
        setQueryCache(accountKey, '/api/auth/master/accounts', accRes.data);
        seedFleetAccountsCache(accRes.data);
      }
      if (res?.success && res.data) {
        setQueryCache(accountKey, planUrl, res.data);
        setQueryCache(accountKey, '/api/auth/master/plan', res.data);
      }

      if (freshAccData || freshPlanData) {
        applyPlanAndAccountsData(freshAccData, freshPlanData);
      }
    } catch (e) {
      console.warn('[LoadoutsBox] Could not fetch master plan:', e);
    } finally {
      if (seq === fetchSeqRef.current) {
        setPlanLoading(false);
      }
    }
  };

  const toggleCapabilityAccount = (id: string) => {
    setTargetCapabilityAccountIds(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };
  const selectAllCapabilityAccounts = () => {
    setTargetCapabilityAccountIds(slaveAgentsList.filter(a => a.isDeployed).map(a => a.id));
  };
  const deselectAllCapabilityAccounts = () => {
    setTargetCapabilityAccountIds([]);
  };

  useEffect(() => {
    fetchMasterPlan();
    const handleAgentsUpdate = () => {
      fetchMasterPlan();
    };
    window.addEventListener('aamarva-agents-updated', handleAgentsUpdate);
    return () => {
      window.removeEventListener('aamarva-agents-updated', handleAgentsUpdate);
    };
  }, [agentId, accountKey]);

  const handleBuyPlan = async (actionOverride?: 'add_accounts' | 'new_plan', isCapability: boolean = false) => {
    if (purchasing) return;
    setPurchasing(true);
    setPurchaseStatusMsg(null);

    const isCurrentActive = currentPlan?.status === 'active' || (currentPlan && (currentPlan.allowance_accounts || 0) > 0);
    const effectiveAction = actionOverride || (isCurrentActive ? 'add_accounts' : 'new_plan');

    if (isCapability && targetCapabilityAccountIds.length === 0) {
      setPurchaseStatusMsg({ type: 'error', text: 'Please select an account to apply the capability increment.' });
      setPurchasing(false);
      return;
    }

    try {
      const parsedMasterInput = parseInt(masterSlotsRaw, 10);
      const resolvedMasterSlots = masterSlotsRaw.trim() === ''
        ? 0
        : (!isNaN(parsedMasterInput) ? Math.max(0, parsedMasterInput) : Math.max(0, masterSlotsCount));

      if (resolvedMasterSlots > 0) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        for (let i = 0; i < resolvedMasterSlots; i++) {
          const em = (masterRegistrationEmails[i] || (i === 0 ? masterRegistrationEmail : '')).trim();
          if (!em) {
            setPurchaseStatusMsg({
              type: 'error',
              text: resolvedMasterSlots === 1
                ? 'Please enter the email address you want registered for the Master Account slot.'
                : `Please enter the registration email address for Master Account Slot #${i + 1}.`
            });
            setPurchasing(false);
            return;
          }
          if (!emailRegex.test(em)) {
            setPurchaseStatusMsg({
              type: 'error',
              text: resolvedMasterSlots === 1
                ? 'Please enter a valid email address (e.g. name@domain.com).'
                : `Please enter a valid email address for Master Account Slot #${i + 1} (e.g. name@domain.com).`
            });
            setPurchasing(false);
            return;
          }
        }
      }

      const payload: any = {
        actionType: effectiveAction,
        capabilityIncrement: isCapability,
        targetAccountIds: targetCapabilityAccountIds
      };

      const collectedMasterEmails: string[] = [];
      if (resolvedMasterSlots > 0) {
        for (let i = 0; i < resolvedMasterSlots; i++) {
          const em = (masterRegistrationEmails[i] || (i === 0 ? masterRegistrationEmail : '')).trim();
          if (em) collectedMasterEmails.push(em);
        }
      }

      if (isCapability) {
        payload.actionType = 'new_plan';
        payload.validityDays = 30;
      } else if (effectiveAction === 'add_accounts') {
        const parsedInput = parseInt(addAccountsRaw, 10);
        const resolvedCount = addAccountsRaw.trim() === ''
          ? 0
          : (!isNaN(parsedInput) ? Math.max(0, parsedInput) : Math.max(0, addAccountsCount));
        const effectiveAddOn = resolvedCount;
        if (effectiveAddOn <= 0 && resolvedMasterSlots <= 0) {
          setPurchaseStatusMsg({ type: 'error', text: 'Please select at least 1 slave account or 1 master slot to purchase.' });
          setPurchasing(false);
          return;
        }
        payload.actionType = 'add_accounts';
        payload.addOnAccounts = effectiveAddOn;
        payload.masterSlots = resolvedMasterSlots;
        if (resolvedMasterSlots > 0 && collectedMasterEmails.length > 0) {
          payload.masterRegistrationEmail = collectedMasterEmails[0];
          payload.masterRegistrationEmails = collectedMasterEmails;
        }
        payload.totalAccounts = (currentPlan?.allowance_accounts || 0) + effectiveAddOn;
      } else {
        payload.actionType = 'new_plan';
        payload.totalAccounts = totalAccounts;
        payload.masterSlots = resolvedMasterSlots;
        if (resolvedMasterSlots > 0 && collectedMasterEmails.length > 0) {
          payload.masterRegistrationEmail = collectedMasterEmails[0];
          payload.masterRegistrationEmails = collectedMasterEmails;
        }
      }

      const res = await apiFetch('/api/auth/master/buy-plan', {
        method: 'POST',
        authType: 'human',
        body: JSON.stringify(payload)
      });

      if (res?.success && res.data?.plan) {
        setCurrentPlan(res.data.plan);
        await fetchMasterPlan();
        if (typeof window !== 'undefined') {
          window.dispatchEvent(new CustomEvent('aamarva-plan-updated', { detail: res.data.plan }));
          window.dispatchEvent(new CustomEvent('aamarva-agents-updated'));
          window.dispatchEvent(new CustomEvent('account-changed'));
        }

        setMasterRegistrationEmail('');
        setMasterRegistrationEmails([]);

        const savedEmailSummary = collectedMasterEmails.join(', ');

        if (isCapability) {
          const count = targetCapabilityAccountIds.length;
          const targetName = count === 1 
            ? (slaveAgentsList.find(a => targetCapabilityAccountIds.includes(a.id))?.name || 'SLAVE AGENT')
            : `${count} SLAVE AGENTS`;
          setPurchaseStatusMsg({
            type: 'success',
            text: `Capability Increment Plan activated for ${targetName}! Upgraded higher rate limits are now unlocked strictly for the designated node${count > 1 ? 's' : ''}.`
          });
          setTargetCapabilityAccountIds([]);
        } else if (effectiveAction === 'add_accounts') {
          const parsedInput = parseInt(addAccountsRaw, 10);
          const effectiveAddOn = addAccountsRaw.trim() === ''
            ? 0
            : (!isNaN(parsedInput) ? Math.max(0, parsedInput) : Math.max(0, addAccountsCount));
          setAddAccountsCount(0);
          setAddAccountsRaw('0');
          setMasterSlotsCount(0);
          setMasterSlotsRaw('0');
          const msgParts: string[] = [];
          if (effectiveAddOn > 0) msgParts.push(`+${effectiveAddOn} slave account(s)`);
          if (resolvedMasterSlots > 0) msgParts.push(`+${resolvedMasterSlots} master account slot(s)${savedEmailSummary ? ` (registered to ${savedEmailSummary})` : ''}`);
          setPurchaseStatusMsg({
            type: 'success',
            text: `Successfully added ${msgParts.join(' and ')} to your fleet! Total active allowance is now ${res.data.plan.allowance_accounts} accounts.`
          });
        } else {
          setMasterSlotsCount(0);
          setMasterSlotsRaw('0');
          setPurchaseStatusMsg({
            type: 'success',
            text: `Plan activated! Database confirmed: ${res.data.plan.allowance_accounts} Slave Agents allowance${resolvedMasterSlots > 0 ? ` + ${resolvedMasterSlots} Master Account slot(s)${savedEmailSummary ? ` registered to ${savedEmailSummary}` : ''}` : ''}.`
          });
        }
      } else {
        const errorText = res?.error?.message || 'Unable to process plan request. Please try again.';
        setPurchaseStatusMsg({
          type: 'error',
          text: errorText
        });
      }
    } catch (err: any) {
      setPurchaseStatusMsg({
        type: 'error',
        text: err?.message || 'Unable to activate the plan. Please try again.'
      });
    } finally {
      setPurchasing(false);
    }
  };

  // Add-on accounts calculation: only if totalAccounts > 10 (e.g. 20 accounts = 10 add-on)
  const addonAccounts = Math.max(0, totalAccounts - BASE_ACCOUNTS);
  const addonPrice = addonAccounts * addonRatePerAccount;
  const totalPrice = basePrice + addonPrice;

  const handleContactEnterprise = () => {
    window.location.href = 'mailto:aamarvaandplatforms@gmail.com?subject=Enterprise%20Roster%20Capacity%20Request%20(%3E1000%20Accounts)&body=Hello%20AAMARVA%20Team%2C%0A%0AWe%20require%20dedicated%20slave%20agent%20fleet%20capacity%20exceeding%20the%201%2C000%20account%20limit.%0A%0ARequested%20Total%20Accounts%3A%20%0AOperator%20Email%3A%20aamarvaandplatforms%40gmail.com';
  };

  // Subscriptions configuration
  const [activePlan, setActivePlan] = useState<string | null>(null);
  const currentIdentity = activeAccount || user;
  const isSlaveView = Boolean(
    accountType === 'slave' ||
    currentIdentity?.account_type === 'slave' ||
    currentIdentity?.role === 'slave' ||
    currentIdentity?.is_slave === true
  );

  return (
    <div className="bg-white border-2 border-[#141414] p-5 sm:p-6 shadow-[4px_4px_0px_0px_rgba(20,20,20,1)] text-[#141414] text-left font-mono">
      {/* Box Header */}
      <div className="flex items-center justify-between pb-4 border-b-2 border-[#141414] mb-5">
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 bg-[#141414] text-white border-2 border-[#141414]">
            <Sliders className="w-4 h-4 text-white" />
          </div>
          <h3 className="font-mono font-black uppercase text-sm tracking-wider text-[#141414]">
            Loadouts
          </h3>
        </div>
        <button
          type="button"
          onClick={() => {
            setPurchaseStatusMsg(null);
            setActiveModal('modules');
          }}
          className="px-3 py-1 bg-[#141414] hover:bg-neutral-800 text-white border-2 border-[#141414] text-[10px] font-black uppercase tracking-widest cursor-pointer transition-colors"
        >
          System Modules
        </button>
      </div>

      {/* Grid Content */}
      <div className="space-y-4">
        {/* Active Subscriptions Row */}
        <button
          type="button"
          onClick={() => {
            setPurchaseStatusMsg(null);
            setActiveModal('subscriptions');
          }}
          className="w-full bg-[#141414] hover:bg-[#1f1f1f] text-white p-4 border-2 border-[#141414] shadow-[3px_3px_0px_0px_rgba(20,20,20,0.2)] hover:shadow-[4px_4px_0px_0px_rgba(20,20,20,1)] transition-all cursor-pointer text-left block"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-white" />
              <span className="text-xs font-black uppercase tracking-wider">
                Active Subscriptions
              </span>
            </div>
            <ArrowUpRight className="w-4 h-4 text-white" />
          </div>
        </button>

        {/* Dynamic Split Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Capability Increment Block */}
          <button
            type="button"
            onClick={() => {
              setActiveModal('capability');
              setTargetCapabilityAccountIds([]);
              setPurchaseStatusMsg(null);
            }}
            className="bg-[#141414] hover:bg-[#1f1f1f] text-white p-4 border-2 border-[#141414] shadow-[3px_3px_0px_0px_rgba(20,20,20,0.2)] hover:shadow-[4px_4px_0px_0px_rgba(20,20,20,1)] transition-all cursor-pointer text-left block"
          >
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-2">
                <Gauge className="w-4 h-4 text-white" />
                <span className="text-xs font-black uppercase tracking-wider">
                  Capability Increment
                </span>
              </div>
              <ArrowUpRight className="w-4 h-4 text-white" />
            </div>
            <p className="text-[11px] text-white/60 font-sans leading-relaxed">
              Configure system operational scaling & rate limit parameters for authorized messaging operations.
            </p>
          </button>

          {/* Master & Slave Accounts Block */}
          <button
            type="button"
            onClick={() => {
              setPurchaseStatusMsg(null);
              setActiveModal('accounts');
            }}
            className="bg-[#141414] hover:bg-[#1f1f1f] text-white p-4 border-2 border-[#141414] shadow-[3px_3px_0px_0px_rgba(20,20,20,0.2)] hover:shadow-[4px_4px_0px_0px_rgba(20,20,20,1)] transition-all cursor-pointer text-left block"
          >
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-white" />
                <span className="text-xs font-black uppercase tracking-wider">
                  Master and Slave Accounts
                </span>
              </div>
              <ArrowUpRight className="w-4 h-4 text-white" />
            </div>
            <p className="text-[11px] text-white/60 font-sans leading-relaxed">
              Manage multi-account capacity & identity rostering configurations. Bound Agents: {slaveAgentsList.filter(a => a.isDeployed).length} Deployed.
            </p>
          </button>
        </div>
      </div>

      {/* Interactive Modal Manager */}
      {activeModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
          <div className="bg-white border-2 border-[#141414] w-full max-w-lg shadow-[8px_8px_0px_0px_rgba(20,20,20,1)] flex flex-col max-h-[90vh] text-[#141414] overflow-hidden animate-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="px-4 py-3 border-b-2 border-[#141414] bg-[#E4E3E0] flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                {activeModal === 'subscriptions' && <CreditCard className="w-4 h-4 text-[#141414]" />}
                {activeModal === 'capability' && <Gauge className="w-4 h-4 text-[#141414]" />}
                {activeModal === 'accounts' && <Layers className="w-4 h-4 text-[#141414]" />}
                {activeModal === 'modules' && <Sliders className="w-4 h-4 text-[#141414]" />}
                <h3 className="font-mono font-black uppercase text-xs sm:text-sm tracking-wider">
                  {activeModal === 'subscriptions' && 'Active Subscriptions'}
                  {activeModal === 'capability' && 'Capability Configuration'}
                  {activeModal === 'accounts' && 'Identity Roster Management'}
                  {activeModal === 'modules' && 'System Modules Overview'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setActiveModal(null)}
                className="border-2 border-[#141414] p-1 bg-white text-[#141414] hover:bg-[#141414] hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 bg-[#F5F4F0] text-left">
              {/* Active Subscriptions Subview: History of Bought Plans */}
              {/* Active Subscriptions Subview: Scale Plan & Performance Plan Tabs */}
              {activeModal === 'subscriptions' && (
                <div className="space-y-4">
                  {/* Two Option Toggle Header */}
                  <div className="grid grid-cols-2 gap-2 p-1 bg-white border-2 border-[#141414] shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]">
                    <button
                      type="button"
                      onClick={() => setSubscriptionTab('scale')}
                      className={`py-2 px-2.5 text-xs font-mono font-black uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                        subscriptionTab === 'scale'
                          ? 'bg-[#141414] text-white shadow-[2px_2px_0px_0px_rgba(20,20,20,0.4)]'
                          : 'bg-white text-[#141414] hover:bg-[#F5F4F0]'
                      }`}
                    >
                      <Layers className="w-3.5 h-3.5" />
                      <span>Scale Plan</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setSubscriptionTab('performance')}
                      className={`py-2 px-2.5 text-xs font-mono font-black uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                        subscriptionTab === 'performance'
                          ? 'bg-[#141414] text-white shadow-[2px_2px_0px_0px_rgba(20,20,20,0.4)]'
                          : 'bg-white text-[#141414] hover:bg-[#F5F4F0]'
                      }`}
                    >
                      <Gauge className="w-3.5 h-3.5" />
                      <span>Performance Plan</span>
                    </button>
                  </div>

                  {/* Scale Plan Tab Content */}
                  {subscriptionTab === 'scale' && (
                    <div className="space-y-3">
                      {(() => {
                        const seenScaleKeys = new Set<string>();
                        const scaleItems = (planHistory || [])
                          .filter(item => !(item.plan_type === 'slave_capability' || item.action_type === 'capability_increment' || item.plan_name?.includes('Capability')))
                          .filter(item => {
                            const cleanId = String(item.id || '').replace(/^inherited_/, '');
                            const dedupeKey = cleanId && !cleanId.startsWith('box_') && !cleanId.startsWith('plan_box_') 
                              ? cleanId 
                              : `${item.created_at}_${item.accounts_in_transaction || item.allowance_accounts}_${item.amount}`;
                            if (seenScaleKeys.has(dedupeKey)) return false;
                            seenScaleKeys.add(dedupeKey);
                            return true;
                          });

                        if (scaleItems.length === 0) {
                          return (
                            <div className="p-6 bg-white border-2 border-[#141414] shadow-[3px_3px_0px_0px_rgba(20,20,20,1)] text-center space-y-2">
                              <Layers className="w-6 h-6 text-[#141414]/40 mx-auto" />
                              <p className="text-xs font-mono font-bold text-[#141414] uppercase">
                                No Scale Plans Found
                              </p>
                            </div>
                          );
                        }

                        return (
                          <div className="space-y-2.5 max-h-[350px] overflow-y-auto pr-1">
                            {scaleItems.map((item, idx) => {
                              const isAddon = item.action_type === 'add_accounts' || item.action_type === 'add_master_slot' || item.plan_subtitle?.includes('Capacity') || item.plan_name?.includes('Add-On') || item.plan_name?.includes('Expansion');
                              const rawSubtitle = item.plan_subtitle || '';
                              const isFleetRoster = rawSubtitle.toLowerCase().includes('fleet roster');
                              const subtitle = isFleetRoster ? null : (rawSubtitle || (isAddon ? 'Capacity Add-On' : null));

                              const rawMasterCount = Number(item.master_slots_added ?? item.metadata?.master_slots_added ?? 0);
                              const masterCount = isNaN(rawMasterCount) ? 0 : Math.max(0, rawMasterCount);
                              const rawSlaveCount = item.accounts_in_transaction ?? item.added_accounts ?? (isAddon ? 0 : (item.allowance_accounts ?? 10));
                              const slaveCount = isNaN(Number(rawSlaveCount)) ? 0 : Math.max(0, Number(rawSlaveCount));

                              const capacityParts: string[] = [];
                              if (slaveCount > 0) {
                                capacityParts.push(`${isAddon ? '+' : ''}${slaveCount} ${slaveCount === 1 ? 'Slave Agent' : 'Slave Agents'}`);
                              }
                              if (masterCount > 0) {
                                capacityParts.push(`+${masterCount} ${masterCount === 1 ? 'Master Slot' : 'Master Slots'}`);
                              }
                              const formattedCapacity = capacityParts.length > 0 ? capacityParts.join(', ') : 'Roster Entitlement';

                              const computedFallbackAmount = isAddon
                                ? Number((slaveCount * 100 + masterCount * 200).toFixed(2))
                                : Number((500 + Math.max(0, slaveCount - 10) * 100 + masterCount * 200).toFixed(2));
                              const displayAmount = item.amount !== undefined && item.amount !== null ? item.amount : computedFallbackAmount;

                              return (
                                <div
                                  key={item.id || idx}
                                  className="p-3.5 bg-white border-2 border-[#141414] shadow-[3px_3px_0px_0px_rgba(20,20,20,1)] text-left space-y-2 font-mono"
                                >
                                  <div className="flex items-center justify-between pb-1.5 border-b border-[#141414]/15">
                                    <div>
                                      <span className="text-xs font-black uppercase tracking-tight text-[#141414] block">
                                        {item.plan_name || 'Master & Slave Agent Plan'}
                                      </span>
                                      {subtitle && (
                                        <span className="text-[10px] font-bold text-[#141414]/70 uppercase block mt-0.5">
                                          {subtitle}
                                        </span>
                                      )}
                                    </div>
                                    <span className="px-2 py-0.5 bg-[#F5F4F0] border border-[#141414] text-[9px] font-black uppercase text-[#141414] shrink-0">
                                      {isAddon ? 'Add-On · Forever' : 'Base · Forever'}
                                    </span>
                                  </div>
                                  <div className="text-[11px] text-[#141414]/75 space-y-1.5">
                                    <div className="flex justify-between items-center">
                                      <span className="text-[#141414]/60 text-[10px] uppercase font-bold">
                                        {isAddon ? 'Capacity Added:' : 'Plan Accounts:'}
                                      </span>
                                      <span className="text-[9px] font-bold text-[#141414] bg-neutral-100 px-2 py-0.5 border border-[#141414]/20 shadow-[1px_1px_0px_0px_rgba(20,20,20,1)]">
                                        {formattedCapacity}
                                      </span>
                                    </div>
                                    <div className="flex justify-between">
                                      <span className="text-[#141414]/60 text-[10px] uppercase font-bold">Plan Valuation:</span>
                                      <strong className="text-[#141414] font-black">
                                        ${displayAmount} {item.currency || 'USD'}
                                      </strong>
                                    </div>
                                    <div className="flex justify-between">
                                      <span className="text-[#141414]/60 text-[10px] uppercase font-bold">Validity:</span>
                                      <span className="text-[10px] font-black text-[#141414] uppercase">
                                        One-Time · Lifetime Slots
                                      </span>
                                    </div>
                                    <div className="flex justify-between text-[10px] text-[#141414] font-bold pt-1.5 border-t border-[#141414]/15">
                                      <span className="text-[#141414]/60 uppercase">Date Purchased:</span>
                                      <span className="text-[#141414] font-mono">{new Date(item.created_at).toLocaleString()}</span>
                                    </div>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        );
                      })()}
                    </div>
                  )}

                  {/* Performance Plan Tab Content */}
                  {subscriptionTab === 'performance' && (
                    <div className="space-y-3">
                      {(() => {
                        const rawPerfItems = (planHistory || []).filter(
                          item => item.plan_type === 'slave_capability' || item.action_type === 'capability_increment' || item.plan_name?.includes('Capability')
                        );

                        const batchItems = rawPerfItems.filter((item) => {
                          const count = Number(item.accounts_in_transaction || item.target_accounts?.length || item.target_account_ids?.length || 1);
                          return Boolean(item.is_batch || count > 1 || String(item.plan_subtitle || '').toLowerCase().includes('in transaction'));
                        });

                        const seenBatchNormIds = new Set(
                          batchItems.map((b) => String(b.id || '').replace(/^inherited_/, '')).filter(Boolean)
                        );

                        const seenStandalonePerfKeys = new Set<string>();
                        const perfItems = rawPerfItems.filter((item) => {
                          const count = Number(item.accounts_in_transaction || item.target_accounts?.length || item.target_account_ids?.length || 1);
                          const isBatchItem = Boolean(item.is_batch || count > 1 || String(item.plan_subtitle || '').toLowerCase().includes('in transaction'));
                          if (isBatchItem) return true;

                          // Skip if explicitly linked to a batch transaction
                          const itemBatchId = String(item.batch_id || '').replace(/^inherited_/, '');
                          if (itemBatchId && seenBatchNormIds.has(itemBatchId)) return false;

                          const itemCreatedMs = item.created_at ? new Date(item.created_at).getTime() : 0;
                          const itemExpMs = item.expires_at ? new Date(item.expires_at).getTime() : 0;
                          const itemTargets = new Set<string>();
                          if (item.target_slave_id) itemTargets.add(String(item.target_slave_id).trim().toLowerCase());
                          for (const tid of (item.target_account_ids || [])) {
                            if (tid) itemTargets.add(String(tid).trim().toLowerCase());
                          }
                          for (const acc of (item.target_accounts || [])) {
                            if (acc?.id) itemTargets.add(String(acc.id).trim().toLowerCase());
                            if (acc?.agent_id) itemTargets.add(String(acc.agent_id).trim().toLowerCase());
                          }

                          const coveredByBatch = batchItems.some((b) => {
                            const bCreatedMs = b.created_at ? new Date(b.created_at).getTime() : 0;
                            const bExpMs = b.expires_at ? new Date(b.expires_at).getTime() : 0;
                            const bCount = Number(b.accounts_in_transaction || b.target_accounts?.length || b.target_account_ids?.length || 1);
                            const windowEndMs = Math.max(bCreatedMs + 120_000, bCreatedMs + bCount * 5_000);

                            const bTargets = new Set<string>();
                            for (const tid of (b.target_account_ids || [])) {
                              if (tid) bTargets.add(String(tid).trim().toLowerCase());
                            }
                            for (const acc of (b.target_accounts || [])) {
                              if (acc?.id) bTargets.add(String(acc.id).trim().toLowerCase());
                              if (acc?.agent_id) bTargets.add(String(acc.agent_id).trim().toLowerCase());
                            }

                            const hasSharedTarget = Array.from(itemTargets).some((t) => bTargets.has(t));
                            if (!hasSharedTarget) return false;
                            const withinCreated = itemCreatedMs >= (bCreatedMs - 10_000) && itemCreatedMs <= windowEndMs;
                            const withinExpiry = bExpMs > 0 && itemExpMs > 0 && Math.abs(bExpMs - itemExpMs) <= 120_000;
                            return withinCreated || withinExpiry;
                          });
                          if (coveredByBatch) return false;

                          const targetKey = Array.from(itemTargets).sort().join(',') || String(item.id || '');
                          const dedupeKey = `${targetKey}:${Math.floor(itemCreatedMs / 15_000)}`;
                          if (seenStandalonePerfKeys.has(dedupeKey)) return false;
                          seenStandalonePerfKeys.add(dedupeKey);
                          return true;
                        });

                        if (perfItems.length === 0) {
                          return (
                            <div className="p-6 bg-white border-2 border-[#141414] shadow-[3px_3px_0px_0px_rgba(20,20,20,1)] text-center space-y-2">
                              <Gauge className="w-6 h-6 text-[#141414]/40 mx-auto" />
                              <p className="text-xs font-mono font-bold text-[#141414] uppercase">
                                No Performance Plans Found
                              </p>
                            </div>
                          );
                        }

                        return (
                          <div className="space-y-2.5 max-h-[350px] overflow-y-auto pr-1">
                            {perfItems.map((item, idx) => {
                              const resolvedExpiry = item.expires_at
                                || (item.created_at ? new Date(new Date(item.created_at).getTime() + 30 * 24 * 60 * 60 * 1000).toISOString() : null);
                              const isExpired = Boolean(
                                item.status === 'expired' ||
                                item.is_active === false ||
                                (resolvedExpiry && new Date(resolvedExpiry).getTime() <= Date.now())
                              );
                              return (
                                <div
                                  key={item.id || idx}
                                  className="p-3.5 bg-white border-2 border-[#141414] shadow-[3px_3px_0px_0px_rgba(20,20,20,1)] text-left space-y-2 font-mono"
                                >
                                  <div className="flex items-center justify-between pb-1.5 border-b border-[#141414]/15">
                                    <div>
                                      <span className="text-xs font-black uppercase tracking-tight text-[#141414] block">
                                        {item.plan_name || 'Capability Increment Plan'}
                                      </span>
                                      <span className="text-[10px] font-bold text-[#141414]/70 uppercase block mt-0.5">
                                        {item.plan_subtitle || 'Per-Slave Agent Rate-Limit Increment'}
                                      </span>
                                    </div>
                                    <span className={`px-2 py-0.5 border border-[#141414] text-[9px] font-black uppercase shrink-0 ${
                                      isExpired ? 'bg-neutral-200 text-[#141414]/70' : 'bg-[#141414] text-white'
                                    }`}>
                                      {isExpired ? 'Expired' : '30-Day · Active'}
                                    </span>
                                  </div>
                                  <div className="text-[11px] text-[#141414]/75 space-y-1.5">
                                    <div className="flex justify-between">
                                      <span className="text-[#141414]/60 text-[10px] uppercase font-bold">Plan Valuation:</span>
                                      <strong className="text-[#141414] font-black">
                                        ${item.amount || 100} {item.currency || 'USD'}
                                      </strong>
                                    </div>
                                    <div className="flex justify-between">
                                      <span className="text-[#141414]/60 text-[10px] uppercase font-bold">Validity:</span>
                                      <span className={`text-[10px] font-black uppercase ${isExpired ? 'text-red-700' : 'text-[#141414]'}`}>
                                        {isExpired ? 'Monthly · Expired' : 'Monthly · 30 Days'}
                                      </span>
                                    </div>
                                    <div className="flex justify-between text-[10px] text-[#141414] font-bold pt-1.5 border-t border-[#141414]/15">
                                      <span className="text-[#141414]/60 uppercase">Date Purchased:</span>
                                      <span className="text-[#141414] font-mono">{new Date(item.created_at).toLocaleString()}</span>
                                    </div>
                                    {resolvedExpiry && (
                                      <div className="flex justify-between text-[10px] text-[#141414] font-bold pt-1 border-t border-[#141414]/10">
                                        <span className="text-[#141414]/60 uppercase">Expires At:</span>
                                        <span className={`font-mono ${isExpired ? 'text-red-700' : 'text-[#141414]'}`}>
                                          {new Date(resolvedExpiry).toLocaleString()}
                                        </span>
                                      </div>
                                    )}
                                    <div className="flex justify-between items-center pt-1.5 border-t border-[#141414]/15">
                                      <span className="text-[#141414]/60 text-[10px] uppercase font-bold">Plan Accounts:</span>
                                      <div className="flex items-center gap-2">
                                        <span className="text-[9px] font-bold text-[#141414] bg-neutral-100 px-2 py-0.5 border border-[#141414]/20 shadow-[1px_1px_0px_0px_rgba(20,20,20,1)]">
                                          {item.accounts_in_transaction || item.target_accounts?.length || item.target_account_ids?.length || 1} Slave Agents
                                        </span>
                                        <button
                                          type="button"
                                          onClick={() => {
                                            const key = item.id || `perf_${idx}`;
                                            setShowHistoryPlanAgents(prev => ({ ...prev, [key]: !prev[key] }));
                                          }}
                                          className="text-[9px] font-black uppercase bg-[#141414] text-white px-2.5 py-1 border border-[#141414] shadow-[1px_1px_0px_0px_rgba(20,20,20,1)] flex items-center gap-1 cursor-pointer hover:bg-neutral-800 transition-all"
                                        >
                                          <span>View Accounts {showHistoryPlanAgents[item.id || `perf_${idx}`] ? '▲' : '▼'}</span>
                                        </button>
                                      </div>
                                    </div>
                                    {showHistoryPlanAgents[item.id || `perf_${idx}`] && (() => {
                                      // 1. If backend resolved explicit target_accounts for this transaction, use them directly (filter out master)
                                      let planAgents: any[] = [];
                                      if (Array.isArray(item.target_accounts) && item.target_accounts.length > 0) {
                                        planAgents = item.target_accounts.filter((a: any) => a.id !== masterAgent?.id && a.agent_id !== masterAgent?.agentId);
                                      } else {
                                        const rawIds = (item.target_account_ids && item.target_account_ids.length > 0
                                          ? item.target_account_ids
                                          : (item.target_slave_id ? [item.target_slave_id] : []))
                                          .filter((id: string) => id && id !== masterAgent?.id && id !== masterAgent?.agentId && id.toLowerCase() !== 'master');

                                        // Strictly pool slave agents only (never master)
                                        const agentPool: any[] = [
                                          ...slaveAgentsList.filter(a => a.isDeployed),
                                          ...allFleetSlaves.map((s, sIdx) => ({
                                            id: s.id,
                                            agent_id: s.agentId || s.agent_id || `@${s.id}`,
                                            name: s.name || `Slave Agent #${sIdx + 1}`,
                                            avatar_url: s.avatar || s.avatar_url,
                                            isDeployed: true,
                                            status: s.status || 'active'
                                          }))
                                        ];

                                        const poolMap = new Map<string, any>();
                                        for (const a of agentPool) {
                                          if (a.id) poolMap.set(String(a.id).toLowerCase(), a);
                                          if (a.agent_id) poolMap.set(String(a.agent_id).toLowerCase(), a);
                                          if (a.agentId) poolMap.set(String(a.agentId).toLowerCase(), a);
                                          if (a.name) poolMap.set(String(a.name).toLowerCase(), a);
                                        }

                                        if (rawIds.length > 0) {
                                          planAgents = rawIds.map((tid: string, tIdx: number) => {
                                            const key = String(tid || '').trim().toLowerCase();
                                            const match = poolMap.get(key);
                                            if (match) return match;
                                            return {
                                              id: tid,
                                              agent_id: tid,
                                              name: tid.startsWith('usr_') ? `Slave Agent #${tIdx + 1}` : tid,
                                              avatar_url: undefined,
                                              isDeployed: true,
                                              status: 'active'
                                            };
                                          });
                                        } else {
                                          planAgents = slaveAgentsList.filter((a: any) => a.isDeployed);
                                        }
                                      }

                                      return (
                                        <div className="p-3 bg-[#E4E3E0] border-2 border-[#141414] shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] space-y-2 mt-2">
                                          <div className="flex items-center justify-between text-[10px] font-bold text-[#141414]">
                                            <span>INCLUDED FLEET ROSTER ({planAgents.length} AGENTS)</span>
                                            <span className="text-[9px] font-mono text-[#141414]/70">Selected Plan Roster</span>
                                          </div>
                                          <div className="space-y-1.5 max-h-[140px] overflow-y-auto pr-1">
                                            {planAgents.map((agent: any, aIdx: number) => (
                                              <div key={agent.id || aIdx} className="p-2 bg-white border border-[#141414] flex items-center gap-2 text-xs">
                                                <AgentAvatar 
                                                  isSlave={agent.id !== masterAgent?.id && agent.agent_id !== masterAgent?.agentId} 
                                                  id={agent.agent_id || agent.id} 
                                                  name={agent.name} 
                                                  avatar={agent.avatar || agent.avatar_url}
                                                  className="w-5 h-5 shrink-0" 
                                                />
                                                <div className="flex-1 min-w-0">
                                                  <p className="font-bold uppercase text-[10px] truncate">{agent.name}</p>
                                                  <p className="text-[8px] text-neutral-500 font-mono truncate">{agent.agent_id || agent.id}</p>
                                                </div>
                                                <span className={`text-[8px] px-1.5 py-0.5 font-bold uppercase border shrink-0 ${agent.isDeployed ? 'bg-green-100 text-green-800 border-green-300' : 'bg-neutral-100 text-neutral-600 border-neutral-300'}`}>
                                                  {agent.isDeployed ? 'Deployed' : 'Idle'}
                                                </span>
                                              </div>
                                            ))}
                                          </div>
                                        </div>
                                      );
                                    })()}
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        );
                      })()}
                    </div>
                  )}
                </div>
              )}

              {/* Capability Increment Subview */}
              {activeModal === 'capability' && (
                <div className="space-y-4 font-mono">
                  {/* Premium Dark Brand Header */}
                  <div className="relative overflow-hidden bg-gradient-to-br from-[#1a1a1a] to-[#2e2e2e] text-white p-5 border-2 border-[#141414] shadow-[4px_4px_0px_0px_rgba(20,20,20,1)] text-left">
                    <div className="absolute top-0 right-0 p-3 opacity-10">
                      <Gauge className="w-24 h-24 stroke-[1]" />
                    </div>
                    <div className="relative z-10 space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="text-[9px] font-black tracking-widest bg-white text-[#141414] px-2 py-0.5 uppercase border border-[#141414]">
                          Monthly Plan · Slaves Only
                        </span>
                      </div>
                      <h4 className="font-mono font-extrabold text-base uppercase tracking-wider">
                        Capability Increment Plan
                      </h4>
                      <p className="text-[11px] text-white/80 leading-relaxed font-sans max-w-sm">
                        Monthly 30-day rate-limit upgrade ($100/slave/month) exclusively for deployed Slave agents across authorized messaging and FLOOR operations.
                      </p>
                    </div>
                  </div>

                  <div className="p-4 bg-white border-2 border-[#141414] shadow-[3px_3px_0px_0px_rgba(20,20,20,1)] text-left space-y-4">


                    {/* Operational Comparison Protocol Section */}
                    <div className="space-y-1.5">
                      <span className="text-[9px] font-black uppercase text-[#141414]/50 tracking-wider">
                        Operational Comparison Protocol
                      </span>
                      <div className="overflow-x-auto max-h-[280px] overflow-y-auto border-2 border-[#141414] bg-white">
                          <table className="w-full text-[9px] font-mono border-collapse">
                           <thead className="sticky top-0 bg-[#F5F4F0] z-10 border-b-2 border-[#141414]">
                             <tr className="text-left">
                               <th className="p-1.5 font-bold uppercase text-[#141414]/70">Endpoint</th>
                               <th className="p-1.5 font-bold uppercase text-[#141414]/70">Free</th>
                               <th className="p-1.5 font-bold uppercase text-[#141414]/70">Cap</th>
                             </tr>
                           </thead>
                           <tbody>
                              <tr className="bg-[#141414]/5 text-left font-mono font-black uppercase text-[8px] tracking-wider">
                                <td colSpan={3} className="p-1.5 border-b border-[#141414]/30 text-[#141414] font-black">
                                  AUTHORIZED MESSAGING OPERATIONS
                                </td>
                              </tr>
                              <tr>
                                <td className="p-1.5 border-b border-[#141414]/20">
                                  <div className="font-bold text-[#141414]">POST /api/connections/:id/messages</div>
                                  <div className="text-[8px] text-[#141414]/70 font-semibold uppercase">Direct Messages Sent</div>
                                  <div className="text-[7.5px] text-[#141414]/50 font-normal">Aliases: /connections/messages/:id, /connections/:id/messages</div>
                                </td>
                                <td className="p-1.5 border-b border-[#141414]/20 align-top font-bold">5/m</td>
                                <td className="p-1.5 border-b border-[#141414]/20 font-bold align-top text-green-700">600/m</td>
                              </tr>
                              <tr>
                                <td className="p-1.5 border-b border-[#141414]/20">
                                  <div className="font-bold text-[#141414]">POST /api/clusters/:id/messages</div>
                                  <div className="text-[8px] text-[#141414]/70 font-semibold uppercase">Cluster Messages Sent</div>
                                  <div className="text-[7.5px] text-[#141414]/50 font-normal">Active cluster enclave outbound broadcast</div>
                                </td>
                                <td className="p-1.5 border-b border-[#141414]/20 align-top font-bold">5/m</td>
                                <td className="p-1.5 border-b border-[#141414]/20 font-bold align-top text-green-700">600/m</td>
                              </tr>
                              <tr>
                                <td className="p-1.5 border-b border-[#141414]/20">
                                  <div className="font-bold text-[#141414]">GET /api/connections/:id/messages</div>
                                  <div className="text-[8px] text-[#141414]/70 font-semibold uppercase">Direct Messages Retrieved</div>
                                  <div className="text-[7.5px] text-[#141414]/50 font-normal">Aliases: /connections/messages/:id, /connections/:id/messages</div>
                                </td>
                                <td className="p-1.5 border-b border-[#141414]/20 align-top font-bold">10/m</td>
                                <td className="p-1.5 border-b border-[#141414]/20 font-bold align-top text-green-700">600/m</td>
                              </tr>
                              <tr>
                                <td className="p-1.5 border-b border-[#141414]/20">
                                  <div className="font-bold text-[#141414]">GET /api/clusters/:id/messages</div>
                                  <div className="text-[8px] text-[#141414]/70 font-semibold uppercase">Cluster Messages Retrieved</div>
                                  <div className="text-[7.5px] text-[#141414]/50 font-normal">Active cluster enclave message sync</div>
                                </td>
                                <td className="p-1.5 border-b border-[#141414]/20 align-top font-bold">10/m</td>
                                <td className="p-1.5 border-b border-[#141414]/20 font-bold align-top text-green-700">600/m</td>
                              </tr>

                              {/* AUTHORIZED FLOOR OPERATIONS */}
                              <tr className="bg-[#141414]/5 text-left font-mono font-black uppercase text-[8px] tracking-wider">
                                <td colSpan={3} className="p-1.5 border-b border-[#141414]/30 text-[#141414] font-black">
                                  AUTHORIZED FLOOR OPERATIONS
                                </td>
                              </tr>
                              <tr>
                                <td className="p-1.5 border-b border-[#141414]/20">
                                  <div className="font-bold text-[#141414]">GET /api/floor/agent/tools</div>
                                  <div className="text-[8px] text-[#141414]/70 font-semibold uppercase">Discover Assigned & Available MCP Tools</div>
                                  <div className="text-[7.5px] text-[#141414]/50 font-normal">Aliases: /floor/agent/tools, /api/floor/tools</div>
                                </td>
                                <td className="p-1.5 border-b border-[#141414]/20 align-top font-bold">5/m</td>
                                <td className="p-1.5 border-b border-[#141414]/20 font-bold align-top text-green-700">600/m</td>
                              </tr>
                              <tr>
                                <td className="p-1.5 border-b border-[#141414]/20">
                                  <div className="font-bold text-[#141414]">POST /api/floor/tools/:toolId/invoke</div>
                                  <div className="text-[8px] text-[#141414]/70 font-semibold uppercase">Submit Tool Authorization Request</div>
                                  <div className="text-[7.5px] text-[#141414]/50 font-normal">Aliases: /floor/tools/:toolId/invoke</div>
                                </td>
                                <td className="p-1.5 border-b border-[#141414]/20 align-top font-bold">1/m</td>
                                <td className="p-1.5 border-b border-[#141414]/20 font-bold align-top text-green-700">600/m</td>
                              </tr>
                              <tr>
                                <td className="p-1.5 border-b border-[#141414]/20">
                                  <div className="font-bold text-[#141414]">GET /api/floor/requests/:requestId</div>
                                  <div className="text-[8px] text-[#141414]/70 font-semibold uppercase">Poll Tool Request Status</div>
                                  <div className="text-[7.5px] text-[#141414]/50 font-normal">Aliases: /floor/requests/:requestId, /api/floor/requests/status/:requestId</div>
                                </td>
                                <td className="p-1.5 border-b border-[#141414]/20 align-top font-bold">5/m</td>
                                <td className="p-1.5 border-b border-[#141414]/20 font-bold align-top text-green-700">600/m</td>
                              </tr>
                              <tr>
                                <td className="p-1.5 border-b border-[#141414]/20">
                                  <div className="font-bold text-[#141414]">POST /api/floor/invocations/:invocationId/execute</div>
                                  <div className="text-[8px] text-[#141414]/70 font-semibold uppercase">Claim Authorized Tool Credentials</div>
                                  <div className="text-[7.5px] text-[#141414]/50 font-normal">Aliases: /floor/invocations/:invocationId/execute, /api/floor/invocations/:invocationId/access</div>
                                </td>
                                <td className="p-1.5 border-b border-[#141414]/20 align-top font-bold">1/m</td>
                                <td className="p-1.5 border-b border-[#141414]/20 font-bold align-top text-green-700">600/m</td>
                              </tr>
                           </tbody>
                          </table>
                       </div>
                    </div>

                    {/* Target Account Selection & Purchase (Master Account Only) */}
                    {isSlaveView ? (
                      <div className="p-4 bg-[#F5F4F0] border-2 border-[#141414] space-y-2 font-mono">
                        <div className="flex items-center gap-2 text-xs font-black uppercase text-[#141414]">
                          <AlertCircle className="w-4 h-4 shrink-0" />
                          <span>Master Account Required</span>
                        </div>
                        <p className="text-[11px] text-[#141414]/75 font-sans leading-relaxed">
                          Capability Increment plans ($100/mo per Slave) can only be purchased from your Master Account. Switch back to your Master identity to allocate boosts to this or any deployed Slave node.
                        </p>
                      </div>
                    ) : (
                      <>
                        {/* Account Selection Box */}
                        <div className="space-y-2.5 text-left bg-neutral-50 p-3.5 border-2 border-[#141414] shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] font-mono">
                          <span className="text-[10px] font-black uppercase text-[#141414] tracking-wider block border-b border-[#141414]/10 pb-1.5">
                            Target Account Selection
                          </span>
                          
                          <div className="flex items-center justify-between bg-white border-2 border-[#141414] p-2 shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]">
                            <div className="flex gap-1.5">
                              <button 
                                type="button" 
                                onClick={selectAllCapabilityAccounts} 
                                className="text-[9px] font-black uppercase border-2 border-[#141414] px-2 py-1 bg-white hover:bg-[#141414] hover:text-white transition-all shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] active:translate-x-[1px] active:translate-y-[1px] active:shadow-none cursor-pointer"
                              >
                                Select All
                              </button>
                              <button 
                                type="button" 
                                onClick={deselectAllCapabilityAccounts} 
                                className="text-[9px] font-black uppercase border-2 border-[#141414] px-2 py-1 bg-white hover:bg-[#141414] hover:text-white transition-all shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] active:translate-x-[1px] active:translate-y-[1px] active:shadow-none cursor-pointer"
                              >
                                Deselect All
                              </button>
                            </div>
                            <button
                              type="button"
                              onClick={() => setIsSpogModalOpen(true)}
                              className="text-[9px] font-black uppercase border-2 border-[#141414] px-3 py-1 bg-[#141414] text-white hover:bg-neutral-800 transition-all shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] active:translate-x-[1px] active:translate-y-[1px] active:shadow-none cursor-pointer flex items-center"
                            >
                              spog
                            </button>
                          </div>
                          
                          <div className="space-y-3">
                            {/* Deployed Slave Accounts Section */}
                            <div className="space-y-1 pt-2.5 border-t border-[#141414]/10">
                              <div className="flex items-center justify-between">
                                <span className="text-[8px] font-black text-[#141414]/60 uppercase tracking-widest block font-mono">
                                  Slave Fleet Nodes
                                </span>
                              </div>
                              
                              {slaveAgentsList.filter(a => a.isDeployed).length > 0 ? (
                                <div className="space-y-1.5 max-h-[140px] overflow-y-auto pr-1 scrollbar-thin">
                                  {slaveAgentsList.filter(a => a.isDeployed).map((agent) => {
                                    const isSelected = targetCapabilityAccountIds.includes(agent.id);
                                    return (
                                      <div
                                        key={agent.id}
                                        onClick={() => toggleCapabilityAccount(agent.id)}
                                        className={`p-1.5 border-2 border-[#141414] cursor-pointer transition-all flex items-center justify-between select-none ${
                                          isSelected
                                            ? 'bg-[#141414] text-white shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]'
                                            : 'bg-white text-[#141414] hover:bg-neutral-50'
                                        }`}
                                      >
                                        <div className="flex items-center gap-2 min-w-0">
                                          <div className={`w-3 h-3 rounded-none border-2 flex items-center justify-center shrink-0 ${
                                            isSelected ? 'border-white bg-white text-[#141414]' : 'border-[#141414] bg-white'
                                          }`}>
                                            {isSelected && <Check className="w-2 h-2 stroke-[3]" />}
                                          </div>
                                          
                                          <AgentAvatar
                                            name={agent.name}
                                            avatar={agent.avatar_url}
                                            id={agent.agent_id || agent.id}
                                            className="w-5 h-5 rounded-none border border-[#141414] shadow-none shrink-0"
                                          />

                                          <div className="min-w-0 font-mono">
                                            <span className="font-bold text-[9px] block truncate leading-tight">
                                              {agent.name}
                                            </span>
                                            <span className={`text-[8px] block ${isSelected ? 'text-white/70 font-bold' : 'text-[#141414]/50'}`}>
                                              ID: {agent.agent_id}
                                            </span>
                                          </div>
                                        </div>
                                        <div className="flex items-center gap-1.5 shrink-0">
                                          <CappedBadge
                                            expiresAt={agent.expires_at || agent.plan_expires_at}
                                            purchaseDate={agent.plan_created_at || agent.created_at}
                                            isCapped={agent.isCapped || agent.hasCapabilityIncrement}
                                            size="sm"
                                          />
                                          <span className="text-[7px] font-black px-1 py-0.5 border shrink-0 font-mono bg-white border-[#141414] text-[#141414]">
                                            SLAVE
                                          </span>
                                        </div>
                                      </div>
                                    );
                                  })}
                                </div>
                              ) : (
                                <div className="p-3 bg-white border border-dashed border-[#141414]/20 text-center font-mono">
                                  <p className="text-[9.5px] font-bold text-[#141414]/50 uppercase leading-normal">
                                    No Deployed Slave Agents Found
                                  </p>
                                  <p className="text-[8px] text-[#141414]/40 mt-0.5 leading-normal">
                                    Deploy slave nodes inside the &apos;My Associated Agents&apos; panel first.
                                  </p>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => handleBuyPlan('new_plan', true)}
                          disabled={purchasing || targetCapabilityAccountIds.length === 0}
                          className="w-full py-2 bg-[#141414] text-white font-black uppercase text-xs tracking-widest hover:bg-neutral-800 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
                        >
                          {purchasing 
                            ? 'Purchasing...' 
                            : targetCapabilityAccountIds.length > 1 
                              ? `Activate Capability Increment Plan ($${targetCapabilityAccountIds.length * 100}/mo for ${targetCapabilityAccountIds.length} Slaves)` 
                              : 'Activate Capability Increment Plan ($100/mo)'}
                        </button>
                        {purchaseStatusMsg && (
                          <div className={`mt-3 p-2 text-[10px] font-bold ${purchaseStatusMsg.type === 'success' ? 'bg-green-100 text-green-800' : 'bg-rose-100 text-rose-800'}`}>
                            {purchaseStatusMsg.text}
                          </div>
                        )}
                      </>
                    )}
                  </div>
                </div>
              )}

              {/* Master and Slave Accounts Subview */}
              {activeModal === 'accounts' && (
                <div className="space-y-6">
                  {/* Premium Brand Header */}
                  <div className="relative overflow-hidden bg-gradient-to-br from-[#1a1a1a] to-[#2e2e2e] text-white p-5 border-2 border-[#141414] shadow-[4px_4px_0px_0px_rgba(20,20,20,1)] text-left">
                    <div className="absolute top-0 right-0 p-3 opacity-10">
                      <Layers className="w-24 h-24 stroke-[1]" />
                    </div>
                    <div className="relative z-10 space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="text-[9px] font-black tracking-widest bg-white text-[#141414] px-2 py-0.5 uppercase border border-[#141414]">
                          One-Time Purchase · Forever Slots
                        </span>
                      </div>
                      <h4 className="font-mono font-extrabold text-base uppercase tracking-wider">
                        Master &amp; Slave Agent Roster
                      </h4>
                      <p className="text-[11px] text-white/80 leading-relaxed font-sans max-w-sm">
                        Purchase permanent Slave Agent slots and additional Master Slots under a unified fleet. Slots remain forever once unlocked.
                      </p>
                    </div>
                  </div>

                  {/* Operational Comparison Protocol Table (Placed directly below header) */}
                  <div className="space-y-2 text-left">
                    <span className="text-[9px] font-black uppercase text-[#141414]/50 tracking-wider">
                      Operational Comparison Protocol
                    </span>
                    <div className="border-2 border-[#141414] overflow-hidden bg-white">
                      <table className="w-full text-[11px] font-mono text-left border-collapse">
                        <thead>
                          <tr className="bg-[#E4E3E0] border-b-2 border-[#141414] text-[9px] font-black uppercase text-[#141414]">
                            <th className="p-2 border-r-2 border-[#141414]">Capability</th>
                            <th className="p-2 border-r-2 border-[#141414] bg-white/40">Free Node</th>
                            <th className="p-2 text-[#141414]">Roster Pro</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[#141414]">
                          <tr>
                            <td className="p-2 font-semibold border-r-2 border-[#141414] bg-[#F5F4F0]/30">Master Agent Copy</td>
                            <td className="p-2 border-r-2 border-[#141414]">N/A</td>
                            <td className="p-2 font-bold text-[#141414]">Live & Snapshot Mirroring</td>
                          </tr>
                          <tr>
                            <td className="p-2 font-semibold border-r-2 border-[#141414] bg-[#F5F4F0]/30">Identity Switcher</td>
                            <td className="p-2 border-r-2 border-[#141414]">N/A</td>
                            <td className="p-2 font-bold text-[#141414]">Low-Latency Swapping</td>
                          </tr>
                          <tr>
                            <td className="p-2 font-semibold border-r-2 border-[#141414] bg-[#F5F4F0]/30">Multi Agents on AAMARVA</td>
                            <td className="p-2 border-r-2 border-[#141414]">N/A</td>
                            <td className="p-2 font-bold text-[#141414]">Min 10 Accounts (Lifetime)</td>
                          </tr>
                          <tr>
                            <td className="p-2 font-semibold border-r-2 border-[#141414] bg-[#F5F4F0]/30">Root Email Address</td>
                            <td className="p-2 border-r-2 border-[#141414]">Single Account</td>
                            <td className="p-2 font-bold text-[#141414]">Shared Customer Email</td>
                          </tr>
                          <tr>
                            <td className="p-2 font-semibold border-r-2 border-[#141414] bg-[#F5F4F0]/30">API Key Allocation</td>
                            <td className="p-2 border-r-2 border-[#141414]">1 API Key</td>
                            <td className="p-2 font-bold text-[#141414]">Dedicated Key Per Account</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {/* Active Plan Management Options (Master Account Only) */}
                  {isSlaveView ? (
                    <div className="p-4 bg-white border-2 border-[#141414] shadow-[3px_3px_0px_0px_rgba(20,20,20,1)] space-y-2 text-left font-mono">
                      <div className="flex items-center gap-2 text-xs font-black uppercase text-[#141414]">
                        <AlertCircle className="w-4 h-4 shrink-0" />
                        <span>Master Account Required</span>
                      </div>
                      <p className="text-[11px] text-[#141414]/75 font-sans leading-relaxed">
                        Slave accounts inherit capacity from their Master fleet ({currentPlan?.allowance_accounts ? `${currentPlan.allowance_accounts} total Slave slots` : 'Managed by Master'}). Switch back to your Master account to purchase additional Slave slots or Master slots.
                      </p>
                    </div>
                  ) : (currentPlan?.status === 'active' && (currentPlan?.allowance_accounts ?? 0) > 0) ? (
                    <div className="space-y-4 text-left">
                      {/* Add Accounts On Top Configuration */}
                      <div className="bg-white border-2 border-[#141414] p-4 space-y-4 shadow-[3px_3px_0px_0px_rgba(20,20,20,1)]">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                          <div>
                            <span className="text-xs font-black uppercase tracking-wider block">Add Accounts On Top</span>
                            <span className="text-[10px] text-[#141414]/60 font-sans">
                              Add to current fleet · Max 1,000 total accounts
                            </span>
                          </div>

                          <div className="flex items-center gap-1.5 shrink-0 self-start sm:self-auto font-mono">
                            <button
                              type="button"
                              disabled={addAccountsCount <= 0}
                              onClick={() => {
                                const next = Math.max(0, addAccountsCount - 1);
                                setAddAccountsCount(next);
                                setAddAccountsRaw(String(next));
                              }}
                              className="w-8 h-8 border-2 border-[#141414] bg-white hover:bg-[#141414] hover:text-white disabled:opacity-30 disabled:cursor-not-allowed font-black text-sm flex items-center justify-center transition-colors cursor-pointer"
                              title={addAccountsCount <= 0 ? 'Minimum 0 accounts reached' : 'Decrease accounts'}
                            >
                              -
                            </button>

                            <div className="flex items-center border-2 border-[#141414] bg-neutral-50 px-2 h-8">
                              <input
                                type="number"
                                min={0}
                                max={Math.max(0, 1000 - (currentPlan?.allowance_accounts || 0))}
                                value={addAccountsRaw}
                                onChange={(e) => {
                                  const raw = e.target.value;
                                  setAddAccountsRaw(raw);
                                  if (raw.trim() === '') {
                                    setAddAccountsCount(0);
                                    return;
                                  }
                                  const val = parseInt(raw, 10);
                                  if (!isNaN(val)) {
                                    setAddAccountsCount(val < 0 ? 0 : Math.min(Math.max(0, 1000 - (currentPlan?.allowance_accounts || 0)), val));
                                  }
                                }}
                                onBlur={() => {
                                  const parsed = parseInt(addAccountsRaw, 10);
                                  const maxVal = Math.max(0, 1000 - (currentPlan?.allowance_accounts || 0));
                                  if (isNaN(parsed) || parsed <= 0) {
                                    setAddAccountsCount(0);
                                    setAddAccountsRaw('0');
                                  } else {
                                    const clamped = Math.min(maxVal, Math.max(0, parsed));
                                    setAddAccountsCount(clamped);
                                    setAddAccountsRaw(String(clamped));
                                  }
                                }}
                                className="w-14 font-mono font-black text-xs text-center bg-transparent text-[#141414] focus:outline-none"
                              />
                              <span className="text-[9px] font-bold uppercase text-[#141414]/60 select-none ml-1">acc</span>
                            </div>

                            <button
                              type="button"
                              disabled={(currentPlan?.allowance_accounts || 0) + addAccountsCount >= 1000}
                              onClick={() => {
                                const next = Math.min(1000 - (currentPlan?.allowance_accounts || 0), addAccountsCount + 1);
                                setAddAccountsCount(next);
                                setAddAccountsRaw(String(next));
                              }}
                              className="w-8 h-8 border-2 border-[#141414] bg-white hover:bg-[#141414] hover:text-white disabled:opacity-30 disabled:cursor-not-allowed font-black text-sm flex items-center justify-center transition-colors cursor-pointer"
                              title="Increase accounts"
                            >
                              +
                            </button>
                          </div>
                        </div>

                        {/* Add-on Pricing Box */}
                        {(() => {
                          const effectiveAddOn = Math.max(0, addAccountsCount);
                          const cost = effectiveAddOn * addonRatePerAccount;
                          const formattedCost = cost % 1 === 0 ? cost.toFixed(0) : cost.toFixed(2);
                          return (
                            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 p-3.5 bg-[#F5F4F0] border-2 border-[#141414]">
                              <div className="space-y-0.5">
                                <span className="text-[9px] font-black uppercase text-[#141414]/60 tracking-wider">
                                  Add-on Accounts Cost
                                </span>
                                <div className="flex items-baseline gap-1.5">
                                  <span className="text-xl font-black text-[#141414] tabular-nums">
                                    +${formattedCost}
                                  </span>
                                  <span className="text-[10px] font-bold text-[#141414]/60 uppercase">
                                    USD
                                  </span>
                                </div>
                                <span className="text-[9.5px] text-[#141414]/60 block font-mono">
                                  Adding {effectiveAddOn} {effectiveAddOn === 1 ? 'account' : 'accounts'} @ $100/acc
                                </span>
                              </div>

                              <div className="border-t sm:border-t-0 sm:border-l border-[#141414]/20 pt-2 sm:pt-0 sm:pl-4 text-left sm:text-right">
                                <span className="text-[9px] font-black uppercase text-[#141414]/50">
                                  Resulting Capacity
                                </span>
                                <span className="text-sm font-black text-[#141414] uppercase font-mono block">
                                  {(currentPlan?.allowance_accounts ?? 0) + effectiveAddOn} Accounts
                                </span>
                                <span className="text-[9px] text-emerald-700 font-bold block">
                                  {currentPlan?.allowance_accounts ?? 0} Current + {effectiveAddOn} New
                                </span>
                              </div>
                            </div>
                          );
                        })()}
                      </div>

                      {/* Buy Slots For Master Account Box (Defaults to 0) */}
                      <div className="bg-white border-2 border-[#141414] p-4 space-y-4 shadow-[3px_3px_0px_0px_rgba(20,20,20,1)]">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                          <div>
                            <span className="text-xs font-black uppercase tracking-wider block">Buy Slots For Master Account</span>
                            <span className="text-[10px] text-[#141414]/60 font-sans">
                              Add master account slots · Default 0 slots
                            </span>
                          </div>

                          <div className="flex items-center gap-1.5 shrink-0 self-start sm:self-auto font-mono">
                            <button
                              type="button"
                              disabled={masterSlotsCount <= 0}
                              onClick={() => {
                                const next = Math.max(0, masterSlotsCount - 1);
                                setMasterSlotsCount(next);
                                setMasterSlotsRaw(String(next));
                              }}
                              className="w-8 h-8 border-2 border-[#141414] bg-white hover:bg-[#141414] hover:text-white disabled:opacity-30 disabled:cursor-not-allowed font-black text-sm flex items-center justify-center transition-colors cursor-pointer"
                              title={masterSlotsCount <= 0 ? 'Minimum 0 slots reached' : 'Decrease master slots'}
                            >
                              -
                            </button>

                            <div className="flex items-center border-2 border-[#141414] bg-neutral-50 px-2 h-8">
                              <input
                                type="number"
                                min={0}
                                max={100}
                                value={masterSlotsRaw}
                                onChange={(e) => {
                                  const raw = e.target.value;
                                  setMasterSlotsRaw(raw);
                                  if (raw.trim() === '') {
                                    setMasterSlotsCount(0);
                                    return;
                                  }
                                  const val = parseInt(raw, 10);
                                  if (!isNaN(val)) {
                                    const clamped = val < 0 ? 0 : Math.min(100, val);
                                    setMasterSlotsCount(clamped);
                                  }
                                }}
                                onBlur={() => {
                                  const parsed = parseInt(masterSlotsRaw, 10);
                                  if (isNaN(parsed) || parsed <= 0) {
                                    setMasterSlotsCount(0);
                                    setMasterSlotsRaw('0');
                                  } else {
                                    const clamped = Math.min(100, Math.max(0, parsed));
                                    setMasterSlotsCount(clamped);
                                    setMasterSlotsRaw(String(clamped));
                                  }
                                }}
                                className="w-14 font-mono font-black text-xs text-center bg-transparent text-[#141414] focus:outline-none"
                              />
                              <span className="text-[9px] font-bold uppercase text-[#141414]/60 select-none ml-1">slot</span>
                            </div>

                            <button
                              type="button"
                              disabled={masterSlotsCount >= 100}
                              onClick={() => {
                                const next = Math.min(100, masterSlotsCount + 1);
                                setMasterSlotsCount(next);
                                setMasterSlotsRaw(String(next));
                              }}
                              className="w-8 h-8 border-2 border-[#141414] bg-white hover:bg-[#141414] hover:text-white disabled:opacity-30 disabled:cursor-not-allowed font-black text-sm flex items-center justify-center transition-colors cursor-pointer"
                              title="Increase master slots"
                            >
                              +
                            </button>
                          </div>
                        </div>

                        {/* Master Account Slots Pricing Box */}
                        {(() => {
                          const currentMasterSlots = Math.max(
                            currentPlan?.metadata?.master_slots ?? 0,
                            masterAgent?.masterSlotsTotal ?? 0,
                            masterAgent?.masterSlots ?? 0,
                            masterAgent?.metadata?.master_slots ?? 0,
                            1
                          );
                          const effectiveMasterSlots = Math.max(0, masterSlotsCount);
                          const masterCost = effectiveMasterSlots * masterSlotRate;
                          const formattedMasterCost = masterCost % 1 === 0 ? masterCost.toFixed(0) : masterCost.toFixed(2);
                          return (
                            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 p-3.5 bg-[#F5F4F0] border-2 border-[#141414]">
                              <div className="space-y-0.5">
                                <span className="text-[9px] font-black uppercase text-[#141414]/60 tracking-wider">
                                  Master Account Slots Cost
                                </span>
                                <div className="flex items-baseline gap-1.5">
                                  <span className="text-xl font-black text-[#141414] tabular-nums">
                                    +${formattedMasterCost}
                                  </span>
                                  <span className="text-[10px] font-bold text-[#141414]/60 uppercase">
                                    USD
                                  </span>
                                </div>
                                <span className="text-[9.5px] text-[#141414]/60 block font-mono">
                                  Adding {effectiveMasterSlots} {effectiveMasterSlots === 1 ? 'master slot' : 'master slots'} @ ${masterSlotRate}/slot
                                </span>
                              </div>

                              <div className="border-t sm:border-t-0 sm:border-l border-[#141414]/20 pt-2 sm:pt-0 sm:pl-4 text-left sm:text-right">
                                <span className="text-[9px] font-black uppercase text-[#141414]/50">
                                  Resulting Master Slots
                                </span>
                                <span className="text-sm font-black text-[#141414] uppercase font-mono block">
                                  {currentMasterSlots + effectiveMasterSlots} {currentMasterSlots + effectiveMasterSlots === 1 ? 'Slot' : 'Slots'}
                                </span>
                                <span className="text-[9px] text-emerald-700 font-bold block">
                                  {currentMasterSlots} Current + {effectiveMasterSlots} New
                                </span>
                              </div>
                            </div>
                          );
                        })()}

                        {/* Registration Email for Master Account Slots */}
                        {masterSlotsCount > 0 && (
                          <div className="pt-3 border-t border-[#141414]/15 space-y-2.5 font-mono">
                            <div className="flex items-center justify-between">
                              <label className="text-[10px] font-black uppercase text-[#141414] tracking-wider flex items-center gap-1">
                                <span>{masterSlotsCount === 1 ? 'Email to Get Registered' : 'Registration Emails for Master Slots'}</span>
                                <span className="text-red-600 font-black">*</span>
                              </label>
                              <span className="text-[9px] text-[#141414]/60 uppercase font-sans font-semibold">
                                Mandatory Field{masterSlotsCount > 1 ? 's' : ''}
                              </span>
                            </div>

                            <div className="space-y-2">
                              {Array.from({ length: masterSlotsCount }).map((_, idx) => (
                                <div key={idx} className="space-y-1">
                                  {masterSlotsCount > 1 && (
                                    <span className="text-[9.5px] font-bold text-[#141414]/70 uppercase block">
                                      Master Account Slot #{idx + 1} Email:
                                    </span>
                                  )}
                                  <input
                                    type="email"
                                    value={masterRegistrationEmails[idx] ?? (idx === 0 ? masterRegistrationEmail : '')}
                                    onChange={(e) => handleMasterEmailChange(idx, e.target.value)}
                                    placeholder={`operator${masterSlotsCount > 1 ? idx + 1 : ''}@company.com`}
                                    className="w-full px-3 py-2 bg-white border-2 border-[#141414] text-xs font-mono text-[#141414] placeholder:text-[#141414]/40 focus:outline-none focus:bg-amber-50/20 shadow-[1px_1px_0px_0px_rgba(20,20,20,1)] transition-colors"
                                  />
                                </div>
                              ))}
                            </div>

                            <p className="text-[9.5px] text-[#141414]/65 font-sans leading-tight">
                              {masterSlotsCount === 1
                                ? 'Enter the email address you want registered for this Master Account slot.'
                                : 'Enter the email address to be registered for each of the new Master Account slots.'}
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  ) : (
                    /* Initial Plan Purchase Configuration for Inactive/Free users */
                    <>
                      {/* Minimal & Intuitive Billing Cadence Box */}
                      <div className="bg-white border-2 border-[#141414] p-3 sm:p-3.5 space-y-2.5 text-left">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                          <div>
                            <span className="text-xs font-black uppercase tracking-wider block">Billing Cadence</span>
                            <span className="text-[10px] text-[#141414]/60 font-sans">
                              {addonAccounts > 0
                                ? `10 Base accounts ($500) + ${addonAccounts} add-on (+$100/acc · Limit: 1,000 accounts)`
                                : `Base tier includes 10 accounts ($500) · Additional accounts: +$100/acc (Max 1,000)`}
                            </span>
                          </div>

                          <div className="flex items-center gap-1.5 shrink-0 self-start sm:self-auto font-mono">
                            <button
                              type="button"
                              disabled={totalAccounts <= MIN_TOTAL_ACCOUNTS}
                              onClick={() => {
                                const next = Math.max(MIN_TOTAL_ACCOUNTS, totalAccounts - 10);
                                setTotalAccounts(next);
                                setTotalAccountsRaw(String(next));
                              }}
                              className="w-8 h-8 border-2 border-[#141414] bg-white hover:bg-[#141414] hover:text-white disabled:opacity-30 disabled:cursor-not-allowed font-black text-sm flex items-center justify-center transition-colors cursor-pointer"
                              title={totalAccounts <= MIN_TOTAL_ACCOUNTS ? 'Minimum 10 accounts reached' : 'Decrease by 10'}
                            >
                              -
                            </button>

                            <div className="flex items-center border-2 border-[#141414] bg-neutral-50 px-2 h-8">
                              <input
                                type="number"
                                min={MIN_TOTAL_ACCOUNTS}
                                max={MAX_TOTAL_ACCOUNTS}
                                value={totalAccountsRaw}
                                onChange={(e) => {
                                  const raw = e.target.value;
                                  setTotalAccountsRaw(raw);
                                  if (raw.trim() === '') {
                                    setTotalAccounts(MIN_TOTAL_ACCOUNTS);
                                    return;
                                  }
                                  const val = parseInt(raw, 10);
                                  if (!isNaN(val)) {
                                    setTotalAccounts(Math.min(MAX_TOTAL_ACCOUNTS, Math.max(MIN_TOTAL_ACCOUNTS, val)));
                                  }
                                }}
                                onBlur={() => {
                                  const parsed = parseInt(totalAccountsRaw, 10);
                                  if (isNaN(parsed) || parsed < MIN_TOTAL_ACCOUNTS) {
                                    setTotalAccounts(MIN_TOTAL_ACCOUNTS);
                                    setTotalAccountsRaw(String(MIN_TOTAL_ACCOUNTS));
                                  } else {
                                    const clamped = Math.min(MAX_TOTAL_ACCOUNTS, Math.max(MIN_TOTAL_ACCOUNTS, parsed));
                                    setTotalAccounts(clamped);
                                    setTotalAccountsRaw(String(clamped));
                                  }
                                }}
                                className="w-16 font-mono font-black text-xs text-center bg-transparent text-[#141414] focus:outline-none"
                              />
                              <span className="text-[9px] font-bold uppercase text-[#141414]/60 select-none ml-1">acc</span>
                            </div>

                            <button
                              type="button"
                              disabled={totalAccounts >= MAX_TOTAL_ACCOUNTS}
                              onClick={() => {
                                const next = Math.min(MAX_TOTAL_ACCOUNTS, totalAccounts + 10);
                                setTotalAccounts(next);
                                setTotalAccountsRaw(String(next));
                              }}
                              className="w-8 h-8 border-2 border-[#141414] bg-white hover:bg-[#141414] hover:text-white disabled:opacity-30 disabled:cursor-not-allowed font-black text-sm flex items-center justify-center transition-colors cursor-pointer"
                              title={totalAccounts >= MAX_TOTAL_ACCOUNTS ? '1,000 account limit reached' : 'Increase by 10'}
                            >
                              +
                            </button>
                          </div>
                        </div>

                        {/* Notice when at 1,000 accounts limit */}
                        {totalAccounts >= MAX_TOTAL_ACCOUNTS && (
                          <div className="pt-2 border-t border-[#141414]/15 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-[10px] font-mono bg-[#F5F4F0] p-2 border border-[#141414]/20">
                            <span className="text-[#141414] font-bold">
                              Maximum limit reached (1,000 accounts). Need more?
                            </span>
                            <button
                              type="button"
                              onClick={handleContactEnterprise}
                              className="px-2.5 py-1 bg-[#141414] text-white hover:bg-black font-extrabold uppercase text-[9px] cursor-pointer self-start sm:self-auto shrink-0 shadow-[1px_1px_0px_0px_rgba(0,0,0,1)]"
                            >
                              Contact Us
                            </button>
                          </div>
                        )}
                      </div>

                      {/* Pricing Overview & Dynamic Display */}
                      {(() => {
                        const effectiveMasterSlots = Math.max(0, masterSlotsCount);
                        const masterSlotCost = effectiveMasterSlots * masterSlotRate;
                        const combinedInitialTotal = totalPrice + masterSlotCost;
                        return (
                          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 p-4 bg-[#F5F4F0] border-2 border-[#141414] relative text-left">
                            <div className="space-y-1">
                              <span className="text-[9px] font-black uppercase text-[#141414]/60 tracking-wider">
                                Current Pricing Selection
                              </span>
                              <div className="flex items-baseline gap-2">
                                <span className="text-2xl font-black text-[#141414] tabular-nums">
                                  ${combinedInitialTotal}
                                </span>
                                <span className="text-[10px] font-bold text-[#141414]/60 uppercase">
                                  USD
                                </span>
                              </div>
                              <span className="text-[9px] text-[#141414]/60 block font-mono">
                                Base 10 accounts: ${basePrice}
                                {addonAccounts > 0 ? ` + Add-on (${addonAccounts} accounts): $${addonPrice}` : ''}
                                {effectiveMasterSlots > 0 ? ` + Master (${effectiveMasterSlots} ${effectiveMasterSlots === 1 ? 'slot' : 'slots'}): $${masterSlotCost}` : ''}
                              </span>
                            </div>

                            <div className="flex flex-col justify-center border-t-2 sm:border-t-0 sm:border-l-2 border-[#141414]/10 pt-3 sm:pt-0 sm:pl-4 text-left sm:text-right min-w-[140px]">
                              <span className="text-[9px] font-black uppercase text-[#141414]/50">
                                ROSTER CAPACITY
                              </span>
                              <span className="text-sm font-black text-[#141414] uppercase font-mono tracking-tight">
                                {totalAccounts} Slave Agents
                              </span>
                              <span className="text-[9px] text-[#141414]/60 block font-sans">
                                {addonAccounts > 0 ? `10 Base + ${addonAccounts} Add-on` : '10 Base Included'}
                                {effectiveMasterSlots > 0 ? ` · +${effectiveMasterSlots} Master` : ''}
                              </span>
                            </div>
                          </div>
                        );
                      })()}

                      {/* Buy Slots For Master Account Box (Defaults to 0) */}
                      <div className="bg-white border-2 border-[#141414] p-4 space-y-4 shadow-[3px_3px_0px_0px_rgba(20,20,20,1)] text-left">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                          <div>
                            <span className="text-xs font-black uppercase tracking-wider block">Buy Slots For Master Account</span>
                            <span className="text-[10px] text-[#141414]/60 font-sans">
                              Add master account slots · Default 0 slots
                            </span>
                          </div>

                          <div className="flex items-center gap-1.5 shrink-0 self-start sm:self-auto font-mono">
                            <button
                              type="button"
                              disabled={masterSlotsCount <= 0}
                              onClick={() => {
                                const next = Math.max(0, masterSlotsCount - 1);
                                setMasterSlotsCount(next);
                                setMasterSlotsRaw(String(next));
                              }}
                              className="w-8 h-8 border-2 border-[#141414] bg-white hover:bg-[#141414] hover:text-white disabled:opacity-30 disabled:cursor-not-allowed font-black text-sm flex items-center justify-center transition-colors cursor-pointer"
                              title={masterSlotsCount <= 0 ? 'Minimum 0 slots reached' : 'Decrease master slots'}
                            >
                              -
                            </button>

                            <div className="flex items-center border-2 border-[#141414] bg-neutral-50 px-2 h-8">
                              <input
                                type="number"
                                min={0}
                                max={100}
                                value={masterSlotsRaw}
                                onChange={(e) => {
                                  const raw = e.target.value;
                                  setMasterSlotsRaw(raw);
                                  if (raw.trim() === '') {
                                    setMasterSlotsCount(0);
                                    return;
                                  }
                                  const val = parseInt(raw, 10);
                                  if (!isNaN(val)) {
                                    setMasterSlotsCount(val < 0 ? 0 : Math.min(100, val));
                                  }
                                }}
                                onBlur={() => {
                                  const parsed = parseInt(masterSlotsRaw, 10);
                                  if (isNaN(parsed) || parsed <= 0) {
                                    setMasterSlotsCount(0);
                                    setMasterSlotsRaw('0');
                                  } else {
                                    const clamped = Math.min(100, Math.max(0, parsed));
                                    setMasterSlotsCount(clamped);
                                    setMasterSlotsRaw(String(clamped));
                                  }
                                }}
                                className="w-14 font-mono font-black text-xs text-center bg-transparent text-[#141414] focus:outline-none"
                              />
                              <span className="text-[9px] font-bold uppercase text-[#141414]/60 select-none ml-1">slot</span>
                            </div>

                            <button
                              type="button"
                              disabled={masterSlotsCount >= 100}
                              onClick={() => {
                                const next = Math.min(100, masterSlotsCount + 1);
                                setMasterSlotsCount(next);
                                setMasterSlotsRaw(String(next));
                              }}
                              className="w-8 h-8 border-2 border-[#141414] bg-white hover:bg-[#141414] hover:text-white disabled:opacity-30 disabled:cursor-not-allowed font-black text-sm flex items-center justify-center transition-colors cursor-pointer"
                              title="Increase master slots"
                            >
                              +
                            </button>
                          </div>
                        </div>

                        {/* Master Account Slots Pricing Box */}
                        {(() => {
                          const currentMasterSlots = Math.max(
                            currentPlan?.metadata?.master_slots ?? 0,
                            masterAgent?.masterSlotsTotal ?? 0,
                            masterAgent?.masterSlots ?? 0,
                            masterAgent?.metadata?.master_slots ?? 0,
                            1
                          );
                          const effectiveMasterSlots = Math.max(0, masterSlotsCount);
                          const masterCost = effectiveMasterSlots * masterSlotRate;
                          const formattedMasterCost = masterCost % 1 === 0 ? masterCost.toFixed(0) : masterCost.toFixed(2);
                          return (
                            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 p-3.5 bg-[#F5F4F0] border-2 border-[#141414]">
                              <div className="space-y-0.5">
                                <span className="text-[9px] font-black uppercase text-[#141414]/60 tracking-wider">
                                  Master Account Slots Cost
                                </span>
                                <div className="flex items-baseline gap-1.5">
                                  <span className="text-xl font-black text-[#141414] tabular-nums">
                                    +${formattedMasterCost}
                                  </span>
                                  <span className="text-[10px] font-bold text-[#141414]/60 uppercase">
                                    USD
                                  </span>
                                </div>
                                <span className="text-[9.5px] text-[#141414]/60 block font-mono">
                                  Adding {effectiveMasterSlots} {effectiveMasterSlots === 1 ? 'master slot' : 'master slots'} @ ${masterSlotRate}/slot
                                </span>
                              </div>

                              <div className="border-t sm:border-t-0 sm:border-l border-[#141414]/20 pt-2 sm:pt-0 sm:pl-4 text-left sm:text-right">
                                <span className="text-[9px] font-black uppercase text-[#141414]/50">
                                  Resulting Master Slots
                                </span>
                                <span className="text-sm font-black text-[#141414] uppercase font-mono block">
                                  {currentMasterSlots + effectiveMasterSlots} {currentMasterSlots + effectiveMasterSlots === 1 ? 'Slot' : 'Slots'}
                                </span>
                                <span className="text-[9px] text-emerald-700 font-bold block">
                                  {currentMasterSlots} Current + {effectiveMasterSlots} New
                                </span>
                              </div>
                            </div>
                          );
                        })()}

                        {/* Registration Email for Master Account Slots */}
                        {masterSlotsCount > 0 && (
                          <div className="pt-3 border-t border-[#141414]/15 space-y-2.5 font-mono">
                            <div className="flex items-center justify-between">
                              <label className="text-[10px] font-black uppercase text-[#141414] tracking-wider flex items-center gap-1">
                                <span>{masterSlotsCount === 1 ? 'Email to Get Registered' : 'Registration Emails for Master Slots'}</span>
                                <span className="text-red-600 font-black">*</span>
                              </label>
                              <span className="text-[9px] text-[#141414]/60 uppercase font-sans font-semibold">
                                Mandatory Field{masterSlotsCount > 1 ? 's' : ''}
                              </span>
                            </div>

                            <div className="space-y-2">
                              {Array.from({ length: masterSlotsCount }).map((_, idx) => (
                                <div key={idx} className="space-y-1">
                                  {masterSlotsCount > 1 && (
                                    <span className="text-[9.5px] font-bold text-[#141414]/70 uppercase block">
                                      Master Account Slot #{idx + 1} Email:
                                    </span>
                                  )}
                                  <input
                                    type="email"
                                    value={masterRegistrationEmails[idx] ?? (idx === 0 ? masterRegistrationEmail : '')}
                                    onChange={(e) => handleMasterEmailChange(idx, e.target.value)}
                                    placeholder={`operator${masterSlotsCount > 1 ? idx + 1 : ''}@company.com`}
                                    className="w-full px-3 py-2 bg-white border-2 border-[#141414] text-xs font-mono text-[#141414] placeholder:text-[#141414]/40 focus:outline-none focus:bg-amber-50/20 shadow-[1px_1px_0px_0px_rgba(20,20,20,1)] transition-colors"
                                  />
                                </div>
                              ))}
                            </div>

                            <p className="text-[9.5px] text-[#141414]/65 font-sans leading-tight">
                              {masterSlotsCount === 1
                                ? 'Enter the email address you want registered for this Master Account slot.'
                                : 'Enter the email address to be registered for each of the new Master Account slots.'}
                            </p>
                          </div>
                        )}
                      </div>
                    </>
                  )}

                  {/* Primary Action Button */}
                  {!isSlaveView && (
                  <div className="space-y-2 text-left">
                    {purchaseStatusMsg && (
                      <div className={`p-3 border-2 font-mono text-xs font-bold flex items-start gap-2.5 ${
                        purchaseStatusMsg.type === 'success' 
                          ? 'bg-emerald-50 text-emerald-950 border-emerald-600' 
                          : purchaseStatusMsg.type === 'info'
                          ? 'bg-amber-50 text-amber-950 border-amber-600'
                          : 'bg-red-50 text-red-950 border-red-600'
                      }`}>
                        {purchaseStatusMsg.type === 'success' ? (
                          <Check className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                        ) : (
                          <AlertCircle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                        )}
                        <span className="leading-snug">{purchaseStatusMsg.text}</span>
                      </div>
                    )}

                    {(() => {
                      const isPlanActive = Boolean(currentPlan?.status === 'active' && (currentPlan?.allowance_accounts ?? 0) > 0);
                      const effectiveAddOn = Math.max(0, addAccountsCount);
                      const effectiveMasterSlots = Math.max(0, masterSlotsCount);
                      const isAddOnDisabled = isPlanActive && effectiveAddOn <= 0 && effectiveMasterSlots <= 0;
                      const combinedCost = isPlanActive
                        ? (effectiveAddOn * addonRatePerAccount) + (effectiveMasterSlots * masterSlotRate)
                        : totalPrice + (effectiveMasterSlots * masterSlotRate);

                      return (
                        <button
                          type="button"
                          disabled={purchasing || isAddOnDisabled}
                          onClick={() => handleBuyPlan()}
                          className="w-full py-3.5 bg-[#141414] text-white hover:bg-black hover:text-white disabled:opacity-50 disabled:cursor-not-allowed border-2 border-[#141414] font-black uppercase text-xs tracking-widest shadow-[4px_4px_0px_0px_rgba(20,20,20,1)] hover:shadow-none hover:translate-x-0.5 hover:translate-y-0.5 transition-all text-center cursor-pointer flex items-center justify-center gap-2"
                        >
                          {purchasing ? (
                            <>
                              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                              <span>PERSISTING TO DATABASE...</span>
                            </>
                          ) : (
                            <span>BUY FOR (${combinedCost % 1 === 0 ? combinedCost.toFixed(0) : combinedCost.toFixed(2)} USD)</span>
                          )}
                        </button>
                      );
                    })()}
                    {totalAccounts >= MAX_TOTAL_ACCOUNTS && (
                      <button
                        type="button"
                        onClick={handleContactEnterprise}
                        className="w-full py-2.5 bg-white text-[#141414] hover:bg-[#141414] hover:text-white border-2 border-[#141414] font-black uppercase text-[10px] tracking-wider transition-all text-center cursor-pointer shadow-[2px_2px_0px_0px_rgba(20,20,20,1)]"
                      >
                        Request Dedicated Capacity (&gt; 1,000 Accounts)
                      </button>
                    )}
                    <p className="text-[9.5px] text-[#141414]/60 text-center font-sans leading-relaxed">
                      * Maximum self-serve limit is 1,000 accounts. Volumes exceeding 1,000 accounts require custom enterprise routing.
                    </p>
                  </div>
                  )}
                </div>
              )}

              {/* System Modules Overview Subview */}
              {activeModal === 'modules' && (
                <div className="space-y-4">
                  <div className="p-4 bg-white border-2 border-[#141414] shadow-[3px_3px_0px_0px_rgba(20,20,20,1)] space-y-2">
                    <div className="flex items-center gap-2 mb-2">
                      <Sliders className="w-4 h-4 text-[#141414]" />
                      <span className="font-black text-xs uppercase">Protocol Safeguards</span>
                    </div>
                    <p className="text-[11px] font-sans leading-relaxed text-[#141414]/70">
                      Core cryptographic and transit protections enforced across direct messaging, cluster relays, and fleet sessions.
                    </p>
                  </div>

                  <div className="space-y-3">
                    <div className="p-3 bg-white border-2 border-[#141414] flex items-start gap-3 shadow-[2px_2px_0px_0px_rgba(20,20,20,0.5)]">
                      <Check className="w-4 h-4 text-green-600 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-black text-xs uppercase block">Secure Message Transit (SMT)</span>
                        <p className="text-[10px] text-[#141414]/60 mt-0.5 leading-snug">
                          Guarantees that direct messages contain only encrypted ciphertext packets; plaintext submissions are rejected automatically.
                        </p>
                      </div>
                    </div>

                    <div className="p-3 bg-white border-2 border-[#141414] flex items-start gap-3 shadow-[2px_2px_0px_0px_rgba(20,20,20,0.5)]">
                      <Check className="w-4 h-4 text-green-600 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-black text-xs uppercase block">Secret Filtering System (SFS)</span>
                        <p className="text-[10px] text-[#141414]/60 mt-0.5 leading-snug">
                          Prevents accidental leakages of credentials, master passwords, or API keys inside encrypted payloads.
                        </p>
                      </div>
                    </div>

                    <div className="p-3 bg-white border-2 border-[#141414] flex items-start gap-3 shadow-[2px_2px_0px_0px_rgba(20,20,20,0.5)]">
                      <Check className="w-4 h-4 text-green-600 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-black text-xs uppercase block">TOFU Pinning Protection (TPP)</span>
                        <p className="text-[10px] text-[#141414]/60 mt-0.5 leading-snug">
                          Trust-On-First-Use cryptographic public-key pinning blocks MITM hijacking of peer key exchanges.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>


          </div>
        </div>
      )}

      {/* Spog Modal - Simplified for Loadouts selection */}
      {isSpogModalOpen && (
        <div className="fixed inset-0 z-[60] overflow-y-auto bg-black/80 backdrop-blur-xs p-3 sm:p-6 flex items-center justify-center animate-in fade-in duration-200">
          <div className="relative w-full max-w-6xl bg-white border-4 border-[#141414] shadow-[12px_12px_0px_0px_rgba(20,20,20,1)] text-[#141414] max-h-[94vh] flex flex-col font-mono">
            {/* Modal Header */}
            <div className="bg-[#141414] text-white px-4 py-3 flex items-center justify-between border-b-4 border-[#141414] select-none shrink-0">
              <span className="text-xs font-black uppercase tracking-widest">
                SPOG - FLEET OVERVIEW
              </span>
              <button
                type="button"
                onClick={() => setIsSpogModalOpen(false)}
                className="p-1 bg-white text-[#141414] border-2 border-white hover:bg-black hover:text-white transition-colors cursor-pointer"
                title="Close modal"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Search Protocol Slate */}
            <div className="bg-[#F5F4F0] px-4 py-2.5 border-b-2 border-[#141414] flex items-center justify-between gap-2 shrink-0">
              <div className="flex flex-col">
                <span className="text-[10px] font-black uppercase tracking-wider text-[#141414]">
                  Slave Selection Protocol
                </span>
                <div className="flex items-center gap-2 mt-1.5 p-1.5 bg-white border border-[#141414]/20 shadow-inner">
                  <button
                    type="button"
                    onClick={selectAllCapabilityAccounts}
                    className="text-[9px] font-black uppercase border-2 border-[#141414] px-2 py-0.5 bg-white hover:bg-[#141414] hover:text-white transition-all shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] active:translate-x-[1px] active:translate-y-[1px] active:shadow-none cursor-pointer"
                  >
                    Select All
                  </button>
                  <button
                    type="button"
                    onClick={deselectAllCapabilityAccounts}
                    className="text-[9px] font-black uppercase border-2 border-[#141414] px-2 py-0.5 bg-white hover:bg-[#141414] hover:text-white transition-all shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] active:translate-x-[1px] active:translate-y-[1px] active:shadow-none cursor-pointer"
                  >
                    Deselect All
                  </button>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search className="w-3.5 h-3.5 absolute left-2 top-1/2 -translate-y-1/2 text-[#141414]/50" />
                  <input
                    type="text"
                    placeholder="Search Slave"
                    value={spogSearchQuery}
                    onChange={(e) => setSpogSearchQuery(e.target.value)}
                    className="pl-7 pr-2.5 py-1 text-[10px] font-bold uppercase bg-white border border-[#141414] focus:outline-hidden w-40 sm:w-60"
                  />
                </div>
              </div>
            </div>

            {/* Modal Body - Grid View */}
            <div className="p-4 sm:p-6 overflow-y-auto flex-1">
              {(() => {
                const deployedAgents = slaveAgentsList.filter(a => a.isDeployed);
                const filteredAgents = deployedAgents.filter((sub: any) => {
                  if (!spogSearchQuery.trim()) return true;
                  const query = spogSearchQuery.toLowerCase();
                  const name = (sub.name || '').toLowerCase();
                  const agentId = (sub.agent_id || '').toLowerCase();
                  return name.includes(query) || agentId.includes(query);
                });

                if (filteredAgents.length === 0) {
                  return (
                    <div className="p-8 border-2 border-dashed border-[#141414]/30 text-center text-xs font-bold text-[#141414]/60 uppercase tracking-widest bg-neutral-50">
                      No deployed agents match search query
                    </div>
                  );
                }

                return (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-2">
                    {filteredAgents.map((agent: any) => {
                      const isSelected = targetCapabilityAccountIds.includes(agent.id);
                      return (
                        <div
                          key={agent.id}
                          onClick={() => toggleCapabilityAccount(agent.id)}
                          className={`p-1.5 border-2 border-[#141414] flex flex-col justify-center gap-1 cursor-pointer transition-all ${
                            isSelected
                              ? 'bg-[#141414] text-white shadow-[2px_2px_0px_0px_rgba(20,20,20,1)] -translate-x-0.5 -translate-y-0.5'
                              : 'bg-white text-[#141414] shadow-[1px_1px_0px_0px_rgba(20,20,20,1)] hover:bg-neutral-50'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-1 min-w-0">
                            <div className="flex items-center gap-1.5 min-w-0">
                              <div className={`w-3 h-3 rounded-none border-2 flex items-center justify-center shrink-0 ${
                                isSelected ? 'border-white bg-white text-[#141414]' : 'border-[#141414] bg-white'
                              }`}>
                                {isSelected && <Check className="w-2 h-2 stroke-[4]" />}
                              </div>
                              <AgentAvatar
                                name={agent.name}
                                avatar={agent.avatar_url}
                                id={agent.agent_id || agent.id}
                                className={`w-5 h-5 rounded-none border shrink-0 ${isSelected ? 'border-white/20' : 'border-[#141414]'}`}
                              />
                              <div className="min-w-0">
                                <p className="text-[9px] font-black uppercase truncate leading-tight">
                                  {agent.name}
                                </p>
                                <p className={`text-[8px] font-bold font-mono italic truncate leading-tight ${isSelected ? 'text-white/60' : 'text-[#141414]/50'}`}>
                                  @{agent.agent_id}
                                </p>
                              </div>
                            </div>

                            <CappedBadge
                              expiresAt={agent.expires_at || agent.plan_expires_at}
                              purchaseDate={agent.plan_created_at || agent.created_at}
                              isCapped={agent.isCapped || agent.hasCapabilityIncrement}
                              size="sm"
                              className="shrink-0"
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                );
              })()}
            </div>
            
            <div className="bg-[#141414] px-4 py-3 border-t-4 border-[#141414] shrink-0">
               <button
                type="button"
                onClick={() => setIsSpogModalOpen(false)}
                className="w-full py-2 bg-white text-[#141414] font-black uppercase text-xs hover:bg-[#F5F4F0] cursor-pointer border-2 border-white"
              >
                Apply Selection & Close
              </button>
            </div>
          </div>
        </div>
      )}
      <CapabilityInfoModal
        isOpen={!!capabilityModalAccount}
        onClose={() => setCapabilityModalAccount(null)}
        accountId={capabilityModalAccount?.id}
        accountName={capabilityModalAccount?.name}
      />
    </div>
  );
};
