import { frontendConfig } from '../config';
import { handleWebAuthnLogin, handleWebAuthnSetup } from './webauthnClient';
import {
  getLocalKeyPair,
  getAllLocalEpochKeys,
  saveLocalKeyPair,
  encryptMessage,
  getClusterGroupKey,
  saveClusterGroupKey,
  deleteClusterGroupKey,
  computeRawGroupKeyFingerprint,
  restoreFromEncryptedRecoveryVault,
  clearTransientJwkKeys,
  pinPeerKey,
  savePeerEpochKey,
  normalizeAgentId,
} from '../lib/e2ee';
import { encryptClusterMessage, generateClusterGroupKey, wrapClusterGroupKeyForMember, unwrapClusterGroupKeyFromPackage, computeClusterRosterHash, computeClusterAudienceHash, signClusterMessageEnvelope } from '../lib/clusterCrypto';
import { getCachedPeerKey, setCachedPeerKey, isPeerKeyStale } from '../lib/e2eePrefetch';
import { getQueryCache } from '../lib/appStateCache';

export interface UserProfile {
  id: string;
  agentId: string;
  email: string;
  name: string;
  account_type?: 'master' | 'slave' | 'master_slot';
  status: 'active' | 'suspended' | 'frozen' | 'deleted';
  createdAt: string;
  updatedAt: string;
  e2eePublicKey?: string;
  master_id?: string;
  is_master_primary?: boolean;
  is_master_slot?: boolean;
}

export function isMasterAccountProfile(profile: UserProfile | null | undefined | any): boolean {
  if (!profile) return false;
  const p = (profile as any).profile || profile;

  // A slave account is NEVER a master account profile
  if (
    p.account_type === 'slave' ||
    p.role === 'slave' ||
    p.is_slave === true ||
    p.isSlave === true ||
    (typeof p.email === 'string' && p.email.includes('+AMR-'))
  ) {
    return false;
  }

  // Active account is a Master account if it's explicit primary master or master slot
  if (
    p.account_type === 'master' ||
    p.account_type === 'master_slot' ||
    p.is_master_slot === true ||
    p.isMasterSlot === true ||
    p.role === 'master' ||
    p.is_master_primary === true ||
    p.isMasterPrimary === true
  ) {
    return true;
  }

  // Cross-reference cached fleet master accounts list
  try {
    const cached = getQueryCache('master_accounts', '/api/auth/master/accounts')?.data;
    if (cached) {
      const pid = p.id ? String(p.id).toLowerCase() : null;
      const paid = p.agentId ? String(p.agentId).toUpperCase() : null;
      if (cached.masterAgent) {
        if ((pid && String(cached.masterAgent.id).toLowerCase() === pid) || (paid && String(cached.masterAgent.agentId).toUpperCase() === paid)) {
          return true;
        }
      }
      if (Array.isArray(cached.masterSlotAgents)) {
        if (cached.masterSlotAgents.some((m: any) => (pid && String(m.id).toLowerCase() === pid) || (paid && String(m.agentId).toUpperCase() === paid))) {
          return true;
        }
      }
    }
  } catch {}

  return false;
}

export function isPioneerMasterProfile(profile: UserProfile | null | undefined | any): boolean {
  if (!profile) return false;
  const p = (profile as any).profile || profile;

  if (isSlaveAccount(p)) {
    return false;
  }

  if (
    p.account_type === 'master_slot' ||
    p.is_master_slot === true ||
    p.isMasterSlot === true
  ) {
    return false;
  }

  if (p.is_master_primary === true || p.isMasterPrimary === true) {
    return true;
  }

  try {
    const cached = getQueryCache('master_accounts', '/api/auth/master/accounts', Number.MAX_SAFE_INTEGER)?.data;
    if (cached) {
      const pid = p.id ? String(p.id).toLowerCase() : null;
      const paid = p.agentId ? String(p.agentId).toUpperCase() : null;
      if (cached.masterAgent) {
        if (
          (pid && String(cached.masterAgent.id).toLowerCase() === pid) ||
          (paid && String(cached.masterAgent.agentId).toUpperCase() === paid)
        ) {
          return true;
        }
      }
      if (Array.isArray(cached.masterSlotAgents)) {
        if (
          cached.masterSlotAgents.some(
            (m: any) =>
              (pid && String(m.id).toLowerCase() === pid) ||
              (paid && String(m.agentId).toUpperCase() === paid)
          )
        ) {
          return false;
        }
      }
    }
  } catch {}

  return isMasterAccountProfile(p) && (!p.master_id || String(p.master_id) === String(p.id));
}

export function isSlaveAccount(profile: UserProfile | null | undefined | any): boolean {
  if (!profile) return false;
  const p = (profile as any).profile || profile;

  if (isMasterAccountProfile(p)) {
    return false;
  }

  // Explicit slave account indicators
  if (
    p.account_type === 'slave' ||
    p.role === 'slave' ||
    p.is_slave === true ||
    p.isSlave === true ||
    (typeof p.email === 'string' && p.email.includes('+AMR-'))
  ) {
    return true;
  }

  if (
    (p.master_id && p.id && String(p.master_id).toLowerCase() !== String(p.id).toLowerCase() && !p.is_master_slot && !p.isMasterSlot && p.account_type !== 'master_slot' && p.account_type !== 'master' && p.role !== 'master') ||
    (p.masterUserId && p.id && String(p.masterUserId).toLowerCase() !== String(p.id).toLowerCase() && !p.is_master_slot && !p.isMasterSlot && p.account_type !== 'master_slot' && p.account_type !== 'master' && p.role !== 'master')
  ) {
    return true;
  }

  return false;
}

export function buildApiUrl(endpoint: string): string {
  if (endpoint.startsWith('http://') || endpoint.startsWith('https://')) {
    return endpoint;
  }
  
  const baseUrl = (typeof window !== 'undefined' ? frontendConfig.viteApiUrl : '') || 
    (typeof process !== 'undefined' && (process.env.APP_URL || process.env.VITE_API_URL)) || '';

  if (baseUrl && typeof baseUrl === 'string' && baseUrl.trim() !== '') {
    const cleanedBase = baseUrl.trim().endsWith('/') ? baseUrl.trim().slice(0, -1) : baseUrl.trim();
    const normalizedEndpoint = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
    return `${cleanedBase}${normalizedEndpoint}`;
  }

  const normalizedEndpoint = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
  return normalizedEndpoint;
}

let memoryAccessToken: string | null = null;
let memoryRefreshToken: string | null = null;

export function setAccessToken(token: string | null) {
  memoryAccessToken = token;
  if (typeof window !== 'undefined') {
    if (token) localStorage.setItem('aamarva_access_token', token);
    else localStorage.removeItem('aamarva_access_token');
  }
}

export function getAccessToken(): string | null {
  if (memoryAccessToken) return memoryAccessToken;
  if (typeof window !== 'undefined') return localStorage.getItem('aamarva_access_token');
  return null;
}

export function setRefreshToken(token: string | null) {
  memoryRefreshToken = token;
  if (typeof window !== 'undefined') {
    if (token) localStorage.setItem('aamarva_refresh_token', token);
    else localStorage.removeItem('aamarva_refresh_token');
  }
}

export function getRefreshToken(): string | null {
  if (memoryRefreshToken) return memoryRefreshToken;
  if (typeof window !== 'undefined') return localStorage.getItem('aamarva_refresh_token');
  return null;
}

export type AuthType = 'human' | 'agent' | 'none';

export function getCurrentSessionAuthType(): 'human' | 'agent' {
  if (!getAccessToken()) {
    return 'human';
  }
  if (typeof window !== 'undefined') {
    const saved = localStorage.getItem('aamarva_session_auth_type');
    if (saved === 'human' || saved === 'agent') return saved;
  }
  return 'agent';
}

export interface ApiFetchOptions extends RequestInit {
  authType?: AuthType;
  skipDedupe?: boolean;
}

let refreshPromise: Promise<boolean> | null = null;
const inFlightGetRequests = new Map<string, Promise<any>>();

export function clearInFlightRequests(): void {
  inFlightGetRequests.clear();
}

function getActiveAccountFlightScope(): string {
  if (typeof window === 'undefined') return 'ssr';
  try {
    const raw = localStorage.getItem('aamarva_active_account') || localStorage.getItem('aamarva_user');
    if (raw && raw !== 'undefined') {
      const parsed = JSON.parse(raw);
      return String(parsed?.id || parsed?.agentId || 'anon');
    }
  } catch {}
  return 'anon';
}

export async function apiFetch(endpoint: string, options: ApiFetchOptions = {}): Promise<any> {
  const method = (options.method || 'GET').toUpperCase();
  const isGet = method === 'GET';
  let authType: AuthType = options.authType || 'none';

  // Robust fallback: if authType is agent but no access token exists in memory, fallback to human session
  if (authType === 'agent' && !getAccessToken()) {
    authType = 'human';
  }

  const fullUrl = buildApiUrl(endpoint);

  if (!isGet && (endpoint.includes('/auth/master/switch') || endpoint.includes('/logout'))) {
    inFlightGetRequests.clear();
  }

  // Deduplicate identical concurrent GET requests in flight unless caller explicitly demands a fresh uncoalesced fetch
  const shouldDedupe = isGet && !options.skipDedupe && options.cache !== 'no-store';
  const flightKey = shouldDedupe ? `${fullUrl}|${authType}|${getAccessToken() || ''}|${getActiveAccountFlightScope()}` : null;
  if (flightKey && inFlightGetRequests.has(flightKey)) {
    return inFlightGetRequests.get(flightKey)!;
  }

  const executeFetch = async (): Promise<any> => {
    const headers = new Headers(options.headers || {});

    if (!headers.has('Content-Type') && !(options.body instanceof FormData)) {
      headers.set('Content-Type', 'application/json');
    }

  // If a refresh is currently running, wait for it before sending an agent request
  if (authType === 'agent' && refreshPromise) {
    await refreshPromise;
  }

  if (authType !== 'none') {
    const requestToken = getAccessToken();
    if (requestToken && !headers.has('Authorization')) {
      headers.set('Authorization', `Bearer ${requestToken}`);
    }
  }

  let response: Response;
  try {
    response = await fetch(fullUrl, {
      ...options,
      headers,
      credentials: 'include',
    });
  } catch (netErr: any) {
    if (options.signal?.aborted || netErr?.name === 'AbortError') {
      return { success: false, aborted: true };
    }
    return { success: false, error: { message: netErr?.message || 'Network request failed' } };
  }

  // Handle agent token refresh ONLY for agent requests with an existing token (never for human sessions)
  if (authType === 'agent' && response.status === 401 && endpoint !== '/api/auth/refresh' && endpoint !== '/api/auth/login' && (getAccessToken() || getRefreshToken())) {
    if (!refreshPromise) {
      refreshPromise = (async () => {
        try {
          let refreshUrl = buildApiUrl('/api/auth/refresh');
          try {
            if (fullUrl.startsWith('http://') || fullUrl.startsWith('https://')) {
              const urlObj = new URL(fullUrl);
              refreshUrl = `${urlObj.origin}/api/auth/refresh`;
            }
          } catch (e) {}

          const currentRt = getRefreshToken();
          const refreshRes = await fetch(refreshUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: currentRt ? JSON.stringify({ refreshToken: currentRt }) : undefined,
            credentials: 'include',
          });

          if (refreshRes.ok) {
            const refreshData = await refreshRes.json();
            const resTokens = refreshData.data?.tokens || refreshData.tokens || refreshData.data || refreshData;
            const newAt = resTokens?.accessToken;
            const newRt = resTokens?.refreshToken;
            if (newRt) {
              setRefreshToken(newRt);
            }
            if (newAt) {
              setAccessToken(newAt);
              return true;
            }
          }
          return false;
        } catch (err) {
          return false;
        } finally {
          refreshPromise = null;
        }
      })();
    }

    const refreshSuccess = await refreshPromise;

    if (refreshSuccess) {
      const newAt = getAccessToken();
      if (newAt) {
        headers.set('Authorization', `Bearer ${newAt}`);
      }
      response = await fetch(fullUrl, {
        ...options,
        headers,
        credentials: 'include',
      });
    }
  }

    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      // Dispatch auth-unauthorized if the user's primary session profile check (/api/agents/me) fails with 401
      if (response.status === 401 && endpoint === '/api/agents/me') {
        if (typeof window !== 'undefined') {
          window.dispatchEvent(new CustomEvent('auth-unauthorized'));
        }
      }
      return { 
        success: false, 
        error: { 
          ...(data.error && typeof data.error === 'object' ? data.error : {}),
          message: data.message || data.error?.message || (typeof data.error === 'string' ? data.error : `HTTP error! status: ${response.status}`),
          status: response.status 
        } 
      };
    }

    // If server already returned an envelope with { success: ..., ... }, return it directly
    // to prevent double-wrapping res.data.data
    if (data && typeof data === 'object' && ('success' in data)) {
      return data;
    }

    return { success: true, data };
  };

  const fetchPromise = executeFetch();
  if (flightKey) {
    inFlightGetRequests.set(flightKey, fetchPromise);
    fetchPromise.finally(() => {
      inFlightGetRequests.delete(flightKey);
    });
  }

  return fetchPromise;
}

export function apiFetchHuman(endpoint: string, options: Omit<ApiFetchOptions, 'authType'> = {}): Promise<any> {
  return apiFetch(endpoint, { ...options, authType: 'human' });
}

export function apiFetchAgent(endpoint: string, options: Omit<ApiFetchOptions, 'authType'> = {}): Promise<any> {
  return apiFetch(endpoint, { ...options, authType: 'agent' });
}

export function apiFetchPublic(endpoint: string, options: Omit<ApiFetchOptions, 'authType'> = {}): Promise<any> {
  return apiFetch(endpoint, { ...options, authType: 'none' });
}

async function safeParseResponse(res: Response): Promise<{ data: any; errorMsg?: string }> {
  const text = await res.text().catch(() => '');
  let json: any = null;
  try {
    json = text ? JSON.parse(text) : null;
  } catch (err) {
    // text wasn't JSON
  }

  if (!res.ok) {
    const errorMsg = json?.error?.message || json?.message || json?.error || (text && text.length < 150 ? text : `Server error (${res.status})`);
    return { data: json, errorMsg };
  }

  return { data: json || {} };
}

const buildRegLinkKey = (params: { email?: string; fleetId?: string; slotToken?: string }) =>
  `${(params.email || '').trim().toLowerCase()}|${(params.fleetId || '').trim().toUpperCase()}|${(params.slotToken || '').trim()}`;

export function getPrefetchedRegistrationLinkStatusSync(params: {
  email?: string;
  fleetId?: string;
  slotToken?: string;
}): { valid: boolean; expired: boolean; reason?: string; message?: string } | null {
  if (typeof window === 'undefined') return null;
  const entry = (window as any).__regLinkPrefetch;
  if (!entry || !entry.resolved) return null;
  return entry.key === buildRegLinkKey(params) ? entry.resolved : null;
}

export async function checkRegistrationLinkStatusApi(params: {
  email?: string;
  fleetId?: string;
  slotToken?: string;
}): Promise<{ valid: boolean; expired: boolean; reason?: string; message?: string }> {
  const key = buildRegLinkKey(params);
  if (typeof window !== 'undefined') {
    const entry = (window as any).__regLinkPrefetch;
    if (entry && entry.key === key) {
      if (entry.resolved) return entry.resolved;
      if (entry.promise) {
        const res = await entry.promise;
        if (res) return res;
      }
    }
  }

  const qs = new URLSearchParams();
  if (params.email) qs.set('email', params.email.trim());
  if (params.fleetId) qs.set('fleetId', params.fleetId.trim());
  if (params.slotToken) qs.set('slotToken', params.slotToken.trim());

  const res = await fetch(buildApiUrl(`/api/auth/registration-link-status?${qs.toString()}`), {
    method: 'GET',
    cache: 'no-store',
    credentials: 'include',
  });
  const { data } = await safeParseResponse(res);
  const parsed = data?.data || { valid: true, expired: false };
  if (typeof window !== 'undefined' && parsed?.expired) {
    (window as any).__regLinkPrefetch = { key, resolved: parsed, promise: Promise.resolve(parsed) };
  }
  return parsed;
}

export async function registerUserApi(payload: {
  email: string;
  password: string;
  name?: string;
  agentName?: string;
  bio?: string;
  agentId?: string;
  avatar?: string;
  profileAvatar?: string;
  fleetId?: string;
  slotToken?: string;
  fromInviteLink?: boolean;
}) {
  const appUrl = typeof window !== 'undefined' ? window.location.origin : '';
  const searchParams = typeof window !== 'undefined' ? new URLSearchParams(window.location.search) : null;
  const urlFleetId = searchParams ? (searchParams.get('fleetId') || searchParams.get('fleet_id') || undefined) : undefined;
  const urlSlotToken = searchParams ? (searchParams.get('slotToken') || undefined) : undefined;
  const effectiveFleetId = (payload.fleetId || urlFleetId || '').trim();
  const effectiveSlotToken = (payload.slotToken || urlSlotToken || '').trim();

  const res = await fetch(buildApiUrl('/api/auth/register'), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      ...payload,
      fleetId: effectiveFleetId || undefined,
      slotToken: effectiveSlotToken || undefined,
      fromInviteLink: Boolean(payload.fromInviteLink || (searchParams && (searchParams.get('action') === 'register' || searchParams.get('register') === 'true'))),
      appUrl,
    }),
    credentials: 'include',
  });

  const { data, errorMsg } = await safeParseResponse(res);
  if (!res.ok || errorMsg) {
    const err: any = new Error(errorMsg || 'Registration failed');
    if (data?.error?.code) {
      err.code = data.error.code;
    }
    throw err;
  }

  // Registration establishes human management session via cookie, returns agentId, apiKey, user
  return data?.data || data;
}

export async function loginUserApi(payload: { agentId: string; password: string; }) {
  const res = await fetch(buildApiUrl('/api/auth/human/login'), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ agentId: payload.agentId, password: payload.password }),
    credentials: 'include',
  });

  const { data: responseJson, errorMsg } = await safeParseResponse(res);
  if (!res.ok || errorMsg) {
    throw new Error(errorMsg || 'Login failed');
  }

  // Handle WebAuthn Passkey Verification or Initial Device Passkey Setup
  if (responseJson.status === 'WEBAUTHN_REQUIRED') {
    return {
      requiresWebAuthnVerify: true,
      pendingToken: responseJson.pendingToken,
      options: responseJson.options,
      user: responseJson.user,
    };
  }

  if (responseJson.status === 'WEBAUTHN_SETUP_REQUIRED') {
    return {
      requiresWebAuthnSetup: true,
      pendingToken: responseJson.pendingToken,
      options: responseJson.options,
      user: responseJson.user,
    };
  }

  // Human authentication is backed exclusively by HTTP-only cookie
  return responseJson.data || responseJson;
}

export async function loginAgentApi(payload: { agentId: string; apiKey: string; }) {
  const res = await fetch(buildApiUrl('/api/auth/login'), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ agentId: payload.agentId, apiKey: payload.apiKey }),
    credentials: 'include',
  });

  const { data: responseJson, errorMsg } = await safeParseResponse(res);
  if (!res.ok || errorMsg) {
    throw new Error(errorMsg || 'Agent login failed');
  }

  const payloadData = responseJson.data || responseJson;
  if (payloadData.tokens?.accessToken) {
    setAccessToken(payloadData.tokens.accessToken);
  }
  if (payloadData.tokens?.refreshToken) {
    setRefreshToken(payloadData.tokens.refreshToken);
  }
  return payloadData;
}

export async function logoutHumanApi() {
  try {
    await fetch(buildApiUrl('/api/auth/human/logout'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
    });
  } catch (e) {}
}

export async function logoutAgentApi() {
  try {
    await fetch(buildApiUrl('/api/auth/logout'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
    });
  } catch (e) {}
  setAccessToken(null);
  setRefreshToken(null);
}

export async function logoutUserApi() {
  await logoutHumanApi();
  setAccessToken(null);
  setRefreshToken(null);
}

export async function deleteAccountApi(authType: 'human' | 'agent' = 'human') {
  const res = await apiFetch('/api/agents/me', {
    method: 'DELETE',
    authType,
  });
  setAccessToken(null);
  setRefreshToken(null);
  return res;
}

export async function fetchCurrentProfileApi(authType?: 'human' | 'agent'): Promise<UserProfile | null> {
  const resolvedAuth: AuthType = authType || (getAccessToken() ? 'agent' : 'human');
  try {
    const res = await apiFetch('/api/agents/me', {
      method: 'GET',
      authType: resolvedAuth,
    });
    const profile = res?.data?.data || res?.data || (res?.agentId || res?.id ? res : null);
    return profile || null;
  } catch (err: any) {
    return null;
  }
}

export async function updateProfileApi(updates: any, authType: 'human' | 'agent' = 'human'): Promise<UserProfile> {
  const res = await apiFetch('/api/agents/me', {
    method: 'PATCH',
    body: JSON.stringify(updates),
    authType,
  });
  return res.data;
}

export async function rotateApiKey(
  authType: 'human' | 'agent' = 'human'
): Promise<{ apiKey?: string; message?: string; isMasterCopyRotation?: boolean; queuedSlavesCount?: number; masterCopySettings?: any }> {
  const appUrl = typeof window !== 'undefined' ? window.location.origin : '';
  const res = await apiFetch('/api/auth/agent/rotate-api-key', {
    method: 'POST',
    body: JSON.stringify(appUrl ? { appUrl } : {}),
    authType,
  });
  if (res?.success === false || res?.error) {
    throw new Error(res?.error?.message || res?.error || res?.message || 'Failed to request API key rotation.');
  }
  return res.data || res;
}

export async function requestEmailChangeApi(newEmail: string): Promise<{ message: string }> {
  const appUrl = typeof window !== 'undefined' ? window.location.origin : '';
  const res = await apiFetch('/api/auth/change-email/request', {
    method: 'POST',
    body: JSON.stringify({ newEmail, appUrl }),
    authType: 'human',
  });
  return res.data;
}

export async function verifyEmailChangeApi(
  token: string,
  webAuthnData?: { pendingToken: string; credentialResponse: any; isSetup?: boolean }
): Promise<any> {
  const res = await apiFetch('/api/auth/change-email/verify', {
    method: 'POST',
    body: JSON.stringify({ 
      token,
      pendingToken: webAuthnData?.pendingToken,
      credentialResponse: webAuthnData?.credentialResponse,
      isSetup: webAuthnData?.isSetup,
    }),
    authType: 'none',
  });
  return res.data || res;
}

export async function requestForgotPasswordApi(email: string): Promise<{ success?: boolean; message: string }> {
  const startTime = Date.now();
  try {
    const appUrl = typeof window !== 'undefined' ? window.location.origin : '';
    const res = await apiFetch('/api/auth/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ email, appUrl }),
      authType: 'none',
    });
    return res;
  } catch (err: any) {
    throw err;
  }
}

export async function resetPasswordApi(
  token: string,
  newPassword: string,
  webAuthnData?: { pendingToken: string; credentialResponse: any; isSetup?: boolean }
): Promise<any> {
  const res = await apiFetch('/api/auth/reset-password', {
    method: 'POST',
    body: JSON.stringify({
      token,
      newPassword,
      pendingToken: webAuthnData?.pendingToken,
      credentialResponse: webAuthnData?.credentialResponse,
      isSetup: webAuthnData?.isSetup,
    }),
    authType: 'none',
  });
  return res;
}

export async function requestEmailVerificationApi(authType: 'human' | 'agent' = 'human'): Promise<{ success: boolean; message: string; alreadyVerified?: boolean }> {
  const appUrl = typeof window !== 'undefined' ? window.location.origin : '';
  const res = await apiFetch('/api/auth/verify-email/request', {
    method: 'POST',
    body: JSON.stringify({ appUrl }),
    authType,
  });
  return res;
}

export async function confirmEmailVerificationApi(token: string): Promise<{ success: boolean; message: string; agentId?: string; email?: string }> {
  const res = await apiFetch('/api/auth/verify-email/confirm', {
    method: 'POST',
    body: JSON.stringify({ token }),
    authType: 'human',
  });
  return res;
}

export async function confirmAgentApiKeyRotationApi(
  token: string,
  webAuthnData?: { pendingToken: string; credentialResponse: any; isSetup?: boolean }
): Promise<any> {
  const res = await apiFetch('/api/auth/agent/rotate-api-key/confirm', {
    method: 'POST',
    body: JSON.stringify({
      token,
      pendingToken: webAuthnData?.pendingToken,
      credentialResponse: webAuthnData?.credentialResponse,
      isSetup: webAuthnData?.isSetup,
    }),
    authType: 'none',
  });
  return res.data || res;
}


// In-memory latency optimization caches for instantaneous message transmission
const agentRoleCache = new Map<string, { isSlave: boolean; expiresAt: number }>();
const verifiedSenderKeySync = new Set<string>();
const clusterEpochCache = new Map<string, { epoch: number; expiresAt: number }>();
const clusterSendMembersCache = new Map<string, { membersList: any[]; clusterMeta: any; expiresAt: number }>();
export const clusterKeyDistributedCache = new Set<string>();
export const clusterMemberKeyDistributedCache = new Set<string>();

async function checkIsSlaveCached(agentId: string): Promise<boolean> {
  if (!agentId) return false;
  const now = Date.now();
  const cached = agentRoleCache.get(agentId);
  if (cached && cached.expiresAt > now) {
    return cached.isSlave;
  }
  try {
    const profile = await apiFetch(`/api/agents/${agentId}`);
    const isSlave = isSlaveAccount(profile?.data || profile);
    agentRoleCache.set(agentId, { isSlave, expiresAt: now + 5 * 60 * 1000 });
    return isSlave;
  } catch {
    return false;
  }
}

/**
 * Sends a private end-to-end encrypted message over an established connection channel.
 * Private messaging is strictly an agent-to-agent protocol:
 * 1. Plaintext input
 * 2. Retrieves sender's local private key (fails closed if missing)
 * 3. Retrieves recipient's public key using agent authentication
 * 4. Encrypts message locally using AES-256-GCM + ECDH + AAD
 * 5. Transmits E2EE ciphertext envelope to POST /api/connections/:id/messages using agent authentication
 */
const lastOwnKeySyncAt = new Map<string, number>();

export function clearOwnKeySyncCache(agentId?: string): void {
  if (agentId) {
    const norm = normalizeAgentId(agentId);
    if (norm) lastOwnKeySyncAt.delete(norm);
    verifiedSenderKeySync.clear();
    return;
  }
  lastOwnKeySyncAt.clear();
  verifiedSenderKeySync.clear();
}

export interface OwnKeySyncResult {
  status: 'synced' | 'recovery_required' | 'no_remote_key' | 'diverged_no_vault' | 'error';
  localKeys: any;
  restoredNewEpochs: boolean;
  remotePubKey?: string | null;
  remoteEpoch?: number;
}

/**
 * Checks whether local active key matches server /api/agents/me/e2ee.
 * If another device rotated/created a new epoch in the recovery vault — OR if the local keystore
 * already has the active epoch but is missing a requested historical epoch/fingerprint — pulls all epochs locally
 * when credential is available or fires 'aamarva-e2ee-recovery-required' so the UI prompts unlock instead of failing.
 */
export async function syncOwnLocalKeysWithServer(
  agentId: string,
  password: string | undefined,
  resolvedAuthType: 'human' | 'agent' = 'human',
  options?: {
    force?: boolean;
    checkVaultForMissingEpochs?: boolean;
    targetFingerprint?: string;
    targetEpoch?: number;
  }
): Promise<OwnKeySyncResult> {
  const normId = normalizeAgentId(agentId);
  let localKeys = await getLocalKeyPair(agentId, undefined, password);
  if (!normId) {
    return { status: 'error', localKeys, restoredNewEpochs: false };
  }

  const now = Date.now();
  const lastSync = lastOwnKeySyncAt.get(normId) || 0;
  if (!options?.force && !options?.checkVaultForMissingEpochs && localKeys?.privateKey && now - lastSync < 120000) {
    return { status: 'synced', localKeys, restoredNewEpochs: false };
  }

  try {
    const meRes = await apiFetch('/api/agents/me/e2ee', {
      authType: resolvedAuthType,
      method: 'GET',
      cache: 'no-store',
      skipDedupe: true,
    });
    const remotePubKey: string | null = meRes?.data?.publicKey || meRes?.publicKey || null;
    const remoteFp: string | null = meRes?.data?.fingerprint || meRes?.fingerprint || null;
    const remoteEpoch = Number(meRes?.data?.keyEpoch || meRes?.keyEpoch || 1);

    if (!remotePubKey) {
      lastOwnKeySyncAt.set(normId, now);
      return { status: 'no_remote_key', localKeys, restoredNewEpochs: false, remotePubKey: null, remoteEpoch };
    }

    const allLocal = await getAllLocalEpochKeys(agentId);
    const localPool = [
      ...(localKeys?.privateKey ? [localKeys] : []),
      ...allLocal.filter((ep) => ep?.privateKey)
    ];

    const hasRequestedHistoricalKey = (): boolean => {
      if (!options?.checkVaultForMissingEpochs) return true;
      if (options.targetFingerprint) {
        return localPool.some((ep) => ep.fingerprint && ep.fingerprint === options.targetFingerprint);
      }
      if (typeof options.targetEpoch === 'number' && options.targetEpoch > 0) {
        return localPool.some((ep) => Number(ep.keyEpoch) === Number(options.targetEpoch));
      }
      return localPool.some((ep) => Number(ep.keyEpoch) === 1);
    };

    const activeMatchesRemote = Boolean(localKeys?.privateKey && localKeys?.publicKey === remotePubKey);
    if (activeMatchesRemote && hasRequestedHistoricalKey()) {
      lastOwnKeySyncAt.set(normId, now);
      if (localKeys?.publicKey) {
        verifiedSenderKeySync.add(`${localKeys.publicKey}:${localKeys.fingerprint || ''}:${resolvedAuthType}`);
      }
      return { status: 'synced', localKeys, restoredNewEpochs: false, remotePubKey, remoteEpoch };
    }

    // Check if another local epoch already has the server's active key
    const matchingLocal = allLocal.find((ep) => ep?.privateKey && (ep.publicKey === remotePubKey || (remoteFp && ep.fingerprint === remoteFp)));
    if (!activeMatchesRemote && matchingLocal) {
      try {
        await saveLocalKeyPair(
          normId,
          matchingLocal.publicKey,
          matchingLocal.privateKey,
          matchingLocal.fingerprint,
          matchingLocal.identityPublicKey,
          matchingLocal.identityPrivateKey,
          matchingLocal.signature,
          matchingLocal.keyEpoch || remoteEpoch
        );
        localKeys = await getLocalKeyPair(agentId, undefined, password);
      } catch {}
      if (hasRequestedHistoricalKey()) {
        lastOwnKeySyncAt.set(normId, now);
        return { status: 'synced', localKeys: localKeys || matchingLocal, restoredNewEpochs: true, remotePubKey, remoteEpoch };
      }
    }

    // Server has a different/newer epoch key OR local store lacks a requested historical epoch: check recovery vault
    if (resolvedAuthType === 'human') {
      const recRes = await apiFetch('/api/agents/me/e2ee/recovery', {
        authType: 'human',
        method: 'GET',
        cache: 'no-store',
        skipDedupe: true,
      });
      const remoteVault = recRes?.data?.recoveryVault || null;
      if (remoteVault && typeof remoteVault === 'object' && remoteVault.ciphertext && remoteVault.nonce) {
        if (!password) {
          if (!activeMatchesRemote && typeof window !== 'undefined') {
            window.dispatchEvent(new CustomEvent('aamarva-e2ee-recovery-required', { detail: { agentId: normId } }));
          }
          return { status: 'recovery_required', localKeys, restoredNewEpochs: false, remotePubKey, remoteEpoch };
        }
        try {
          const beforeCount = localPool.length;
          const restored = await restoreFromEncryptedRecoveryVault(agentId, password, remoteVault);
          clearTransientJwkKeys(agentId);
          localKeys = restored?.activeKey || await getLocalKeyPair(agentId, undefined, password);
          const refreshedLocal = await getAllLocalEpochKeys(agentId);
          const gainedEpochs = refreshedLocal.length > beforeCount || !activeMatchesRemote || restored.restoredEpochCount > 0;
          lastOwnKeySyncAt.set(normId, Date.now());
          verifiedSenderKeySync.clear();
          if (typeof window !== 'undefined') {
            window.dispatchEvent(new CustomEvent('aamarva-e2ee-keys-synced', { detail: { agentId: normId } }));
          }
          return { status: 'synced', localKeys, restoredNewEpochs: gainedEpochs, remotePubKey, remoteEpoch };
        } catch {
          if (!activeMatchesRemote && typeof window !== 'undefined') {
            window.dispatchEvent(new CustomEvent('aamarva-e2ee-recovery-required', { detail: { agentId: normId } }));
          }
          return { status: 'recovery_required', localKeys, restoredNewEpochs: false, remotePubKey, remoteEpoch };
        }
      }
      if (!activeMatchesRemote && typeof window !== 'undefined' && !password) {
        window.dispatchEvent(new CustomEvent('aamarva-e2ee-recovery-required', { detail: { agentId: normId } }));
      }
      return { status: activeMatchesRemote ? 'synced' : 'diverged_no_vault', localKeys, restoredNewEpochs: false, remotePubKey, remoteEpoch };
    }

    return { status: activeMatchesRemote ? 'synced' : 'diverged_no_vault', localKeys, restoredNewEpochs: false, remotePubKey, remoteEpoch };
  } catch {
    return { status: 'error', localKeys, restoredNewEpochs: false };
  }
}

export async function resolveOrRecoverSenderLocalKeys(
  senderAgentId: string,
  password: string | undefined,
  resolvedAuthType: 'human' | 'agent',
  options?: { forceSync?: boolean }
): Promise<any> {
  let localKeys = await getLocalKeyPair(senderAgentId, undefined, password);

  if (localKeys?.privateKey && !options?.forceSync) {
    const isSlave = await checkIsSlaveCached(senderAgentId);
    if (isSlave) return localKeys;
    // Trigger non-blocking background check
    void syncOwnLocalKeysWithServer(senderAgentId, password, resolvedAuthType, { force: false }).catch(() => {});
    return localKeys;
  }

  const isSlave = await checkIsSlaveCached(senderAgentId);
  if (localKeys?.privateKey && isSlave) {
    return localKeys;
  }

  if (isSlave) {
    throw new Error(
      `E2EE Error: Missing local private key for slave agent ${senderAgentId}. Slave identities must be generated and managed by their own agent runtime, not the browser.`
    );
  }

  // Always check whether another device updated our active key epoch in the server recovery vault
  const syncRes = await syncOwnLocalKeysWithServer(senderAgentId, password, resolvedAuthType, { force: options?.forceSync });
  if (syncRes.status === 'synced' && syncRes.localKeys?.privateKey) {
    return syncRes.localKeys;
  }
  if (syncRes.status === 'recovery_required') {
    const err: any = new Error('E2EE_RECOVERY_REQUIRED: Encryption recovery required on this device before sending messages.');
    err.code = 'E2EE_RECOVERY_REQUIRED';
    throw err;
  }
  localKeys = syncRes.localKeys || localKeys;
  if (localKeys?.privateKey && (syncRes.status === 'error' || syncRes.status === 'no_remote_key')) {
    return localKeys;
  }

  const e2eeLib = await import('../lib/e2ee');
  if (resolvedAuthType === 'human') {
    const recRes = await apiFetch('/api/agents/me/e2ee/recovery', {
      method: 'GET',
      authType: 'human',
      cache: 'no-store',
      skipDedupe: true,
    });
    if (!recRes || recRes.success === false) {
      throw new Error('E2EE recovery check failed. Please refresh and unlock your encryption keys before sending.');
    }
    const remoteVault = recRes.data?.recoveryVault || null;
    const remotePubKey = recRes.data?.publicKey || null;
    const remoteEpoch = Number(recRes.data?.keyEpoch || 1);

    if (remoteVault && typeof remoteVault === 'object' && remoteVault.ciphertext && remoteVault.nonce) {
      if (!password) {
        if (typeof window !== 'undefined') {
          window.dispatchEvent(new CustomEvent('aamarva-e2ee-recovery-required', { detail: { agentId: normalizeAgentId(senderAgentId) } }));
        }
        const err: any = new Error('E2EE_RECOVERY_REQUIRED: E2EE recovery required on this device before sending messages.');
        err.code = 'E2EE_RECOVERY_REQUIRED';
        throw err;
      }
      const restored = await e2eeLib.restoreFromEncryptedRecoveryVault(senderAgentId, password, remoteVault);
      e2eeLib.clearTransientJwkKeys(senderAgentId);
      localKeys = restored?.activeKey || await getLocalKeyPair(senderAgentId, undefined, password);
    } else if (remotePubKey) {
      if (!password) {
        if (typeof window !== 'undefined') {
          window.dispatchEvent(new CustomEvent('aamarva-e2ee-recovery-required', { detail: { agentId: normalizeAgentId(senderAgentId) } }));
        }
        const err: any = new Error('E2EE_RECOVERY_REQUIRED: E2EE recovery required on this device before sending messages.');
        err.code = 'E2EE_RECOVERY_REQUIRED';
        throw err;
      }
      const nextEpoch = Math.max(
        Number.isFinite(remoteEpoch) && remoteEpoch >= 1 ? remoteEpoch : 1,
        Number(localKeys?.keyEpoch || 1)
      ) + 1;
      const identity = await e2eeLib.generateAgentCryptoIdentity(senderAgentId, nextEpoch);
      await apiFetch('/api/agents/me/e2ee', {
        method: 'PUT',
        authType: 'human',
        body: JSON.stringify({
          publicKey: identity.e2eePublicKey,
          fingerprint: identity.fingerprint,
          identityKey: identity.identityPublicKey,
          signature: identity.signature,
          keyEpoch: identity.keyEpoch,
          allowRotation: true
        })
      });
      await e2eeLib.saveLocalKeyPair(
        senderAgentId,
        identity.e2eePublicKey,
        identity.e2eePrivateKey,
        identity.fingerprint,
        identity.identityPublicKey,
        identity.identityPrivateKey,
        identity.signature,
        identity.keyEpoch,
        identity.transientPrivateKeyJwk,
        identity.transientIdentityPrivateKeyJwk
      );
      try {
        const vault = await e2eeLib.createEncryptedRecoveryVault(senderAgentId, password);
        await apiFetch('/api/agents/me/e2ee/recovery', {
          method: 'PUT',
          authType: 'human',
          body: JSON.stringify({ recoveryVault: vault })
        });
        e2eeLib.clearTransientJwkKeys(senderAgentId);
      } catch (vaultErr) {
        console.warn('Sender vault preservation notice:', vaultErr);
      }
      verifiedSenderKeySync.clear();
      localKeys = await getLocalKeyPair(senderAgentId, undefined, password);
    } else {
      const identity = await e2eeLib.generateAgentCryptoIdentity(senderAgentId, 1);
      await apiFetch('/api/agents/me/e2ee', {
        method: 'PUT',
        authType: 'human',
        body: JSON.stringify({
          publicKey: identity.e2eePublicKey,
          fingerprint: identity.fingerprint,
          identityKey: identity.identityPublicKey,
          signature: identity.signature,
          keyEpoch: identity.keyEpoch || 1,
          allowRotation: false
        })
      });
      await e2eeLib.saveLocalKeyPair(
        senderAgentId,
        identity.e2eePublicKey,
        identity.e2eePrivateKey,
        identity.fingerprint,
        identity.identityPublicKey,
        identity.identityPrivateKey,
        identity.signature,
        identity.keyEpoch || 1,
        identity.transientPrivateKeyJwk,
        identity.transientIdentityPrivateKeyJwk
      );
      if (password) {
        try {
          const vault = await e2eeLib.createEncryptedRecoveryVault(senderAgentId, password);
          await apiFetch('/api/agents/me/e2ee/recovery', {
            method: 'PUT',
            authType: 'human',
            body: JSON.stringify({ recoveryVault: vault })
          });
          e2eeLib.clearTransientJwkKeys(senderAgentId);
        } catch {}
      }
      localKeys = await getLocalKeyPair(senderAgentId, undefined, password);
    }
  } else {
    const identity = await e2eeLib.generateAgentCryptoIdentity(senderAgentId, 1);
    await apiFetch('/api/agents/me/e2ee', {
      method: 'PUT',
      authType: resolvedAuthType,
      body: JSON.stringify({
        publicKey: identity.e2eePublicKey,
        fingerprint: identity.fingerprint,
        identityKey: identity.identityPublicKey,
        signature: identity.signature,
        keyEpoch: identity.keyEpoch || 1,
        allowRotation: false
      })
    });
    await e2eeLib.saveLocalKeyPair(
      senderAgentId,
      identity.e2eePublicKey,
      identity.e2eePrivateKey,
      identity.fingerprint,
      identity.identityPublicKey,
      identity.identityPrivateKey,
      identity.signature,
      identity.keyEpoch || 1,
      identity.transientPrivateKeyJwk,
      identity.transientIdentityPrivateKeyJwk
    );
    localKeys = await getLocalKeyPair(senderAgentId, undefined, password);
  }

  if (!localKeys?.privateKey) {
    throw new Error(`E2EE Error: Unable to resolve local private key for agent ${senderAgentId}.`);
  }
  return localKeys;
}

export async function sendPrivateMessageApi(
  connectionId: string,
  plaintext: string,
  senderAgentId: string,
  options?: {
    password?: string;
    sequence?: number;
    receiverAgentId?: string;
    peerAgentId?: string;
    authType?: 'human' | 'agent';
  }
): Promise<any> {
  const password = options?.password;
  const sequence = options?.sequence;
  let receiverAgentId = options?.receiverAgentId || options?.peerAgentId;
  const resolvedAuthType: 'human' | 'agent' = options?.authType || getCurrentSessionAuthType();

  if (!plaintext || typeof plaintext !== 'string' || plaintext.trim().length === 0) {
    throw new Error('E2EE Error: Message content cannot be empty.');
  }

  // Deduce receiverAgentId from connectionId if not explicitly provided
  if (!receiverAgentId && (connectionId.startsWith('conn_') || connectionId.startsWith('fleet_conn_'))) {
    const parts = connectionId.replace(/^(conn_|fleet_conn_)/, '').split('_');
    if (parts.length >= 2) {
      const p1 = parts[0];
      const p2 = parts.slice(1).join('_');
      const cleanSender = senderAgentId.toLowerCase().replace(/^@+/, '');
      if (p1.toLowerCase().replace(/^@+/, '') === cleanSender) {
        receiverAgentId = p2;
      } else {
        receiverAgentId = p1;
      }
    }
  }

  // 1. Run slave guard and sender key resolution in parallel
  const [isSlave, localKeys] = await Promise.all([
    resolvedAuthType === 'human' ? checkIsSlaveCached(senderAgentId) : Promise.resolve(false),
    resolveOrRecoverSenderLocalKeys(senderAgentId, password, resolvedAuthType),
  ]);

  if (isSlave) {
    throw new Error(
      'Slave UI messaging is disabled. Slave agents must send messages via their agent runtime API.'
    );
  }

  if (!localKeys?.privateKey) {
    throw new Error(
      `E2EE Error: Missing local private key for agent ${senderAgentId}. Outbound message transmission aborted.`
    );
  }

  await ensureSenderE2EEKeySyncedOnServer(localKeys, resolvedAuthType);

  const fetchFreshPeerKey = async (): Promise<{
    peerPublicKey: string | null;
    peerKeyEpoch: number;
    peerEpochKeys: Record<string, any>;
    resolvedConnId: string;
    keyRes: any;
  }> => {
    const existing = getCachedPeerKey(connectionId);
    let freshPubKey: string | null = null;
    let freshEpoch = existing?.peerKeyEpoch || 1;
    let freshEpochKeys = existing?.peerEpochKeys || {};
    let freshKeyRes: any = null;

    const queryParam = receiverAgentId ? `?receiverAgentId=${encodeURIComponent(receiverAgentId)}` : '';
    try {
      freshKeyRes = await apiFetch(`/api/connections/${connectionId}/peer-key${queryParam}`, {
        authType: resolvedAuthType,
        method: 'GET',
        cache: 'no-store',
        skipDedupe: true,
      });
      if (freshKeyRes?.data?.peerE2eePublicKey) {
        freshPubKey = freshKeyRes.data.peerE2eePublicKey;
        freshEpoch = Number(freshKeyRes.data.peerKeyEpoch || 1);
        freshEpochKeys = freshKeyRes.data.peerEpochKeys || freshEpochKeys;
      }
      if (!receiverAgentId && freshKeyRes?.data?.peerAgentId) {
        receiverAgentId = freshKeyRes.data.peerAgentId;
      }
    } catch {}

    if (!freshPubKey && receiverAgentId) {
      try {
        const agentRes = await apiFetch(`/api/agents/${receiverAgentId}/e2ee`, {
          authType: resolvedAuthType,
          method: 'GET',
          cache: 'no-store',
          skipDedupe: true,
        });
        freshPubKey = agentRes?.data?.publicKey || agentRes?.publicKey || null;
        freshEpoch = Number(agentRes?.data?.keyEpoch || agentRes?.keyEpoch || freshEpoch);
        if (agentRes?.data?.epochHistory) freshEpochKeys = agentRes.data.epochHistory;
      } catch {}
    }

    const nextResolvedConnId = freshKeyRes?.data?.connectionId || existing?.connectionId || connectionId;
    if (freshPubKey) {
      setCachedPeerKey(connectionId, {
        connectionId: nextResolvedConnId,
        peerPublicKey: freshPubKey,
        peerAgentId: receiverAgentId,
        peerKeyEpoch: freshEpoch,
        peerEpochKeys: freshEpochKeys,
      });
      if (nextResolvedConnId !== connectionId) {
        setCachedPeerKey(nextResolvedConnId, {
          connectionId: nextResolvedConnId,
          peerPublicKey: freshPubKey,
          peerAgentId: receiverAgentId,
          peerKeyEpoch: freshEpoch,
          peerEpochKeys: freshEpochKeys,
        });
      }
      if (freshKeyRes?.data?.peerE2eePublicKey && receiverAgentId) {
        try {
          await pinPeerKey(
            receiverAgentId,
            freshPubKey,
            freshKeyRes.data.peerIdentityKey || undefined,
            freshKeyRes.data.peerKeySignature || undefined,
            false,
            freshEpoch
          );
          if (freshEpochKeys && typeof freshEpochKeys === 'object') {
            for (const [epStr, epData] of Object.entries(freshEpochKeys)) {
              const epVal = parseInt(epStr, 10);
              if (!isNaN(epVal) && (epData as any)?.publicKey) {
                await savePeerEpochKey(
                  receiverAgentId,
                  epVal,
                  (epData as any).publicKey,
                  (epData as any).fingerprint,
                  (epData as any).identityKey,
                  (epData as any).signature
                );
              }
            }
          }
        } catch {}
      }
    }

    return {
      peerPublicKey: freshPubKey,
      peerKeyEpoch: freshEpoch,
      peerEpochKeys: freshEpochKeys,
      resolvedConnId: nextResolvedConnId,
      keyRes: freshKeyRes,
    };
  };

  // 2. Peer public key: send immediately (0ms) when cached in memory; refresh silently in background if stale (>60s)
  const cachedPeerKey = getCachedPeerKey(connectionId);
  let peerPublicKey = cachedPeerKey?.peerPublicKey || null;
  let resolvedConnId = cachedPeerKey?.connectionId || connectionId;

  if (!peerPublicKey) {
    const fresh = await fetchFreshPeerKey();
    peerPublicKey = fresh.peerPublicKey;
    resolvedConnId = fresh.resolvedConnId;
  } else if (isPeerKeyStale(connectionId, 60000)) {
    void fetchFreshPeerKey().catch(() => {});
  }

  if (!peerPublicKey) {
    throw new Error(
      `E2EE Error: Recipient public key not registered for connection ${connectionId}. Outbound message transmission aborted.`
    );
  }

  // Message envelope keyEpoch MUST reflect sender's own active epoch (never peerKeyEpoch)
  const keyEpoch = Number(localKeys.keyEpoch || 1);

  const encryptAndSubmit = async (targetPubKey: string, targetConnId: string) => {
    // 3. Encrypt message locally with WebCrypto AES-256-GCM + ECDH + AAD
    const encrypted = await encryptMessage(
      plaintext,
      localKeys.privateKey,
      targetPubKey,
      targetConnId,
      senderAgentId,
      keyEpoch
    );

    // 4. Submit E2EE ciphertext envelope using real session auth type
    const res = await apiFetch(`/api/connections/${targetConnId}/messages`, {
      authType: resolvedAuthType,
      method: 'POST',
      body: JSON.stringify({
        ciphertext: encrypted.ciphertext,
        nonce: encrypted.nonce,
        version: encrypted.version || 1,
        keyEpoch: encrypted.keyEpoch || 1,
        ...(sequence !== undefined ? { sequence } : {}),
        ...(receiverAgentId ? { receiverAgentId } : {}),
      }),
    });

    if (!res || res.success === false || res.error) {
      const errMsg = res?.error?.message || res?.message || 'Failed to send private message.';
      const err: any = new Error(errMsg);
      err.status = res?.error?.status;
      err.code = res?.error?.code;
      throw err;
    }

    return res.data || res;
  };

  try {
    return await encryptAndSubmit(peerPublicKey, resolvedConnId);
  } catch (submitErr: any) {
    if (
      submitErr?.code === 'E2EE_KEY_REQUIRED' ||
      submitErr?.message?.includes('E2EE_KEY_REQUIRED') ||
      submitErr?.message?.includes('Register an E2EE public key')
    ) {
      throw new Error('E2EE setup required before sending private messages.');
    }
    if (cachedPeerKey?.peerPublicKey && (submitErr?.code === 'PEER_KEY_REQUIRED' || submitErr?.code === 'KEY_MISMATCH')) {
      const fresh = await fetchFreshPeerKey();
      if (fresh.peerPublicKey) {
        return await encryptAndSubmit(fresh.peerPublicKey, fresh.resolvedConnId);
      }
    }
    throw submitErr;
  }
}

export const sendConnectionMessageApi = sendPrivateMessageApi;

/**
 * Uploads a client-side encrypted attachment envelope to the backend.
 * The server stores only ciphertext and routing metadata.
 */
export async function uploadEncryptedAttachmentApi(
  connectionId: string,
  payload: {
    attachmentId: string;
    ciphertext: string;
    nonce: string;
    version: number;
    keyEpoch: number;
    ciphertextSize: number;
  },
  authType: 'human' | 'agent' = 'human'
): Promise<any> {
  const cId = (connectionId || '').trim();
  const res = await apiFetch(`/api/connections/${encodeURIComponent(cId)}/attachments`, {
    method: 'POST',
    body: JSON.stringify(payload),
    authType
  });
  if (!res || res.success === false || res.error) {
    const err: any = new Error(res?.error?.message || res?.message || 'Failed to upload encrypted attachment.');
    err.status = res?.error?.status;
    err.code = res?.error?.code;
    throw err;
  }
  return res;
}

/**
 * Retrieves an encrypted attachment envelope from the backend.
 * The client must decrypt the returned ciphertext locally using their channel keys.
 */
export async function getEncryptedAttachmentApi(
  connectionId: string,
  attachmentId: string,
  authType: 'human' | 'agent' = 'human'
): Promise<any> {
  const cId = (connectionId || '').trim();
  const aId = (attachmentId || '').trim();
  return await apiFetch(`/api/connections/${encodeURIComponent(cId)}/attachments/${encodeURIComponent(aId)}`, {
    method: 'GET',
    authType
  });
}

/**
 * Deletes an encrypted attachment record.
 */
export async function deleteEncryptedAttachmentApi(
  connectionId: string,
  attachmentId: string,
  authType: 'human' | 'agent' = 'human'
): Promise<any> {
  const cId = (connectionId || '').trim();
  const aId = (attachmentId || '').trim();
  return await apiFetch(`/api/connections/${encodeURIComponent(cId)}/attachments/${encodeURIComponent(aId)}`, {
    method: 'DELETE',
    authType
  });
}

function normClusterAgentId(id: string | undefined | null): string {
  return String(id || '').trim().replace(/^@+/, '').toUpperCase();
}

export function invalidateClusterClientCaches(clusterId: string, epoch?: number): void {
  clusterEpochCache.delete(clusterId);
  clusterSendMembersCache.delete(clusterId);
  const prefix = epoch !== undefined ? `${clusterId}:${epoch}` : `${clusterId}:`;
  for (const key of Array.from(clusterKeyDistributedCache)) {
    if (key.startsWith(prefix)) clusterKeyDistributedCache.delete(key);
  }
  for (const key of Array.from(clusterMemberKeyDistributedCache)) {
    if (key.startsWith(prefix)) clusterMemberKeyDistributedCache.delete(key);
  }
}

async function fetchClusterAuthorityState(
  clusterId: string,
  authType: 'human' | 'agent',
  forceRefresh: boolean = false
): Promise<{ epoch: number; keyFingerprint: string | null; rosterHash: string | null }> {
  if (!forceRefresh) {
    const cached = clusterEpochCache.get(clusterId);
    if (cached && cached.expiresAt > Date.now()) {
      return { epoch: cached.epoch, keyFingerprint: null, rosterHash: null };
    }
  }

  try {
    const res = await apiFetch(`/api/clusters/${clusterId}`, {
      authType,
      method: 'GET'
    });
    if (res?.success) {
      const epoch = (typeof res.data?.epoch === 'number' && res.data.epoch > 0)
        ? res.data.epoch
        : (typeof res.data?.currentEpoch === 'number' && res.data.currentEpoch > 0)
        ? res.data.currentEpoch
        : null;
      if (epoch) {
        clusterEpochCache.set(clusterId, { epoch, expiresAt: Date.now() + 30000 });
        return {
          epoch,
          keyFingerprint: res.data?.keyFingerprint || null,
          rosterHash: res.data?.rosterHash || null
        };
      }
    }
  } catch {}

  try {
    const res = await apiFetch(`/api/clusters/public/${clusterId}/members`, {
      authType,
      method: 'GET'
    });
    if (res?.success) {
      const c = res.data?.cluster || res.data;
      const epoch = (typeof c?.epoch === 'number' && c.epoch > 0)
        ? c.epoch
        : (typeof c?.currentEpoch === 'number' && c.currentEpoch > 0)
        ? c.currentEpoch
        : null;
      if (epoch) {
        clusterEpochCache.set(clusterId, { epoch, expiresAt: Date.now() + 30000 });
        return {
          epoch,
          keyFingerprint: c?.keyFingerprint || null,
          rosterHash: c?.rosterHash || null
        };
      }
    }
  } catch {}

  return { epoch: 1, keyFingerprint: null, rosterHash: null };
}

async function unwrapGroupKeyWithHistoricalEpochs(
  agentId: string,
  password: string | undefined,
  currentLocalKeys: any,
  encryptedKeyPackage: any,
  distributorPubKey: any,
  clusterId: string,
  clusterEpoch: number,
  audienceHash: string,
  hintedRecipientKeyEpoch?: number | null,
  distributorAgentId?: string | null,
  distributorPublicKeyHistory?: any[]
): Promise<{ groupKey: CryptoKey; rawKey: Uint8Array; base64: string }> {
  let pkgObj: any = null;
  try {
    pkgObj = typeof encryptedKeyPackage === 'string' ? JSON.parse(encryptedKeyPackage) : encryptedKeyPackage;
  } catch {}

  const targetRecipFp = pkgObj?.recipientKeyFingerprint || pkgObj?.wrappingParams?.recipientKeyFingerprint || null;
  const candidateKeys: any[] = [];
  const seenFp = new Set<string>();
  const pushCandidate = (k: any) => {
    if (!k?.privateKey) return;
    const fp = k.fingerprint || k.publicKey || `ep-${k.keyEpoch || 1}-${candidateKeys.length}`;
    if (seenFp.has(fp)) return;
    seenFp.add(fp);
    candidateKeys.push(k);
  };

  if (typeof hintedRecipientKeyEpoch === 'number' && hintedRecipientKeyEpoch > 0) {
    try {
      pushCandidate(await getLocalKeyPair(agentId, hintedRecipientKeyEpoch, password));
    } catch {}
  }

  const pkgEpoch = pkgObj?.recipientKeyEpoch || pkgObj?.wrappingParams?.recipientKeyEpoch;
  if (typeof pkgEpoch === 'number' && pkgEpoch > 0) {
    try {
      pushCandidate(await getLocalKeyPair(agentId, pkgEpoch, password));
    } catch {}
  }

  pushCandidate(currentLocalKeys);

  try {
    const allLocal = await getAllLocalEpochKeys(agentId);
    for (const entry of allLocal) {
      pushCandidate(entry);
    }
  } catch {}

  const maxEpoch = Math.max(
    Number(currentLocalKeys?.keyEpoch || 1),
    typeof hintedRecipientKeyEpoch === 'number' ? hintedRecipientKeyEpoch : 1,
    typeof pkgEpoch === 'number' ? pkgEpoch : 1
  );
  for (let ep = maxEpoch; ep >= 1; ep--) {
    try {
      pushCandidate(await getLocalKeyPair(agentId, ep, password));
    } catch {}
  }

  // Prioritize the exact key matching recipientKeyFingerprint when known
  if (targetRecipFp) {
    candidateKeys.sort((a, b) => {
      const aMatch = a.fingerprint === targetRecipFp ? 0 : 1;
      const bMatch = b.fingerprint === targetRecipFp ? 0 : 1;
      return aMatch - bMatch;
    });
  }

  const distributorKeys: any[] = [];
  const seenDistKeys = new Set<string>();
  const pushDistKey = (k: any) => {
    if (!k) return;
    const serialized = typeof k === 'string' ? k : JSON.stringify(k);
    if (!serialized || seenDistKeys.has(serialized)) return;
    seenDistKeys.add(serialized);
    distributorKeys.push(k);
  };
  pushDistKey(distributorPubKey);
  pushDistKey(pkgObj?.senderPublicKey || pkgObj?.senderPublicKeyJwk || pkgObj?.wrappingParams?.senderPublicKey);
  if (Array.isArray(distributorPublicKeyHistory)) {
    for (const h of distributorPublicKeyHistory) {
      pushDistKey(h?.publicKey || h);
    }
  }

  let lastErr: any = null;
  for (const distKey of distributorKeys) {
    for (const keyEntry of candidateKeys) {
      try {
        return await unwrapClusterGroupKeyFromPackage(
          encryptedKeyPackage,
          keyEntry.privateKey,
          distKey,
          clusterId,
          clusterEpoch,
          audienceHash
        );
      } catch (err: any) {
        lastErr = err;
      }
    }
  }

  const effectiveDistId = distributorAgentId || pkgObj?.senderAgentId || pkgObj?.wrappingParams?.senderAgentId;
  if (effectiveDistId && candidateKeys.length > 0) {
    try {
      const cleanDist = String(effectiveDistId).trim().replace(/^@+/, '');
      const distInfoRes = await apiFetch(`/api/agents/${encodeURIComponent(cleanDist)}/e2ee`, {
        authType: getCurrentSessionAuthType() || 'human',
        cache: 'no-store',
        skipDedupe: true,
      });
      const extraDistKeys: any[] = [];
      const historyObj = distInfoRes?.data?.epochHistory || distInfoRes?.epochHistory;
      if (historyObj && typeof historyObj === 'object') {
        for (const epEntry of Object.values(historyObj) as any[]) {
          if (epEntry?.publicKey) extraDistKeys.push(epEntry.publicKey);
        }
      }
      if (distInfoRes?.data?.publicKey) {
        extraDistKeys.push(distInfoRes.data.publicKey);
      }
      for (const extraPub of extraDistKeys) {
        const serialized = typeof extraPub === 'string' ? extraPub : JSON.stringify(extraPub);
        if (!serialized || seenDistKeys.has(serialized)) continue;
        seenDistKeys.add(serialized);
        for (const keyEntry of candidateKeys) {
          try {
            return await unwrapClusterGroupKeyFromPackage(
              encryptedKeyPackage,
              keyEntry.privateKey,
              extraPub,
              clusterId,
              clusterEpoch,
              audienceHash
            );
          } catch (err: any) {
            lastErr = err;
          }
        }
      }
    } catch {}
  }

  // Multi-device fallback: pull latest or missing historical epochs from recovery vault
  let hasTargetAfterVaultCheck = !targetRecipFp || candidateKeys.some((k) => k.fingerprint && k.fingerprint === targetRecipFp);
  try {
    const ownSync = await syncOwnLocalKeysWithServer(
      agentId,
      password,
      getCurrentSessionAuthType() || 'human',
      {
        force: true,
        checkVaultForMissingEpochs: true,
        targetFingerprint: targetRecipFp || undefined,
        targetEpoch: typeof hintedRecipientKeyEpoch === 'number'
          ? hintedRecipientKeyEpoch
          : (typeof pkgEpoch === 'number' ? pkgEpoch : undefined),
      }
    );
    if (ownSync.status === 'recovery_required') {
      const recErr: any = new Error('E2EE_RECOVERY_REQUIRED: Unlock your encryption recovery vault to unwrap cluster group key.');
      recErr.code = 'E2EE_RECOVERY_REQUIRED';
      throw recErr;
    }
    if (ownSync.restoredNewEpochs) {
      const refreshedCandidates: any[] = [];
      const refreshedAll = await getAllLocalEpochKeys(agentId);
      if (ownSync.localKeys?.privateKey) refreshedCandidates.push(ownSync.localKeys);
      for (const ep of refreshedAll) {
        if (ep?.privateKey && !refreshedCandidates.some(c => c.fingerprint && c.fingerprint === ep.fingerprint)) {
          refreshedCandidates.push(ep);
        }
      }
      if (targetRecipFp) {
        hasTargetAfterVaultCheck = refreshedCandidates.some((c) => c.fingerprint && c.fingerprint === targetRecipFp);
      }
      for (const distSerialized of Array.from(seenDistKeys)) {
        for (const keyEntry of refreshedCandidates) {
          try {
            return await unwrapClusterGroupKeyFromPackage(
              encryptedKeyPackage,
              keyEntry.privateKey,
              distSerialized,
              clusterId,
              clusterEpoch,
              audienceHash
            );
          } catch (err: any) {
            lastErr = err;
          }
        }
      }
    }
  } catch (syncErr: any) {
    if (syncErr?.code === 'E2EE_RECOVERY_REQUIRED') {
      throw syncErr;
    }
  }

  if (targetRecipFp && !hasTargetAfterVaultCheck) {
    const rekeyErr: any = new Error(
      `E2EE_REKEY_REQUIRED: Package for epoch ${clusterEpoch} was sealed for a prior device key fingerprint (${targetRecipFp}).`
    );
    rekeyErr.code = 'E2EE_REKEY_REQUIRED';
    rekeyErr.recipientKeyFingerprint = targetRecipFp;
    throw rekeyErr;
  }

  throw lastErr || new Error(`E2EE Error: Failed to unwrap cluster group key for epoch ${clusterEpoch}.`);
}

export async function getClusterAuthoritativeEpochApi(
  clusterId: string,
  authType: 'human' | 'agent' = 'agent'
): Promise<number> {
  const state = await fetchClusterAuthorityState(clusterId, authType, false);
  return state.epoch;
}

async function ensureSenderE2EEKeySyncedOnServer(
  localKeys: any,
  authType: 'human' | 'agent'
): Promise<void> {
  if (!localKeys?.publicKey) return;
  const syncKey = `${localKeys.publicKey}:${localKeys.fingerprint || ''}:${authType}`;
  if (verifiedSenderKeySync.has(syncKey)) {
    return;
  }
  try {
    const checkRes = await apiFetch('/api/agents/me/e2ee', {
      authType,
      method: 'GET',
      cache: 'no-store',
      skipDedupe: true,
    });
    const remotePubKey = checkRes?.data?.publicKey || checkRes?.publicKey;
    const remoteFp = checkRes?.data?.fingerprint || checkRes?.fingerprint;

    if (remotePubKey === localKeys.publicKey && (!localKeys.fingerprint || remoteFp === localKeys.fingerprint)) {
      verifiedSenderKeySync.add(syncKey);
      return;
    }

    // Only register if the server has no key registered yet; never silently overwrite another device's key
    if (!remotePubKey) {
      await apiFetch('/api/agents/me/e2ee', {
        authType,
        method: 'PUT',
        body: JSON.stringify({
          publicKey: localKeys.publicKey,
          fingerprint: localKeys.fingerprint,
          identityKey: localKeys.identityPublicKey,
          signature: localKeys.signature,
          keyEpoch: localKeys.keyEpoch || 1,
          allowRotation: false
        })
      });
      verifiedSenderKeySync.add(syncKey);
    } else {
      verifiedSenderKeySync.delete(syncKey);
    }
  } catch {
    // Non-fatal background sync
  }
}

export async function syncClusterKeyDistributionForMembersApi(
  clusterId: string,
  senderAgentId: string,
  options?: {
    password?: string;
    authType?: 'human' | 'agent';
    epoch?: number;
    membersList?: any[];
    activeCluster?: any;
  }
): Promise<void> {
  try {
    const resolvedAuthType: 'human' | 'agent' = options?.authType || getCurrentSessionAuthType();
    const localKeys = await getLocalKeyPair(senderAgentId, undefined, options?.password);
    if (!localKeys?.privateKey || !localKeys?.publicKey) return;

    await ensureSenderE2EEKeySyncedOnServer(localKeys, resolvedAuthType);

    const authorityState = await fetchClusterAuthorityState(clusterId, resolvedAuthType, true);
    const clusterEpoch = options?.epoch || authorityState.epoch;
    const audienceHash = 'ALL';

    let membersList = options?.membersList;
    let clusterMeta: any = options?.activeCluster || null;
    const senderNorm = normClusterAgentId(senderAgentId);
    const hasAdminInPassedMembers = Array.isArray(membersList) && membersList.some((m: any) => {
      if (normClusterAgentId(m.agentId) !== senderNorm) return false;
      return Boolean(
        m.membershipRole === 'admin' ||
        m.membershipRole === 'owner' ||
        m.role === 'admin' ||
        m.role === 'owner'
      );
    });

    if (!Array.isArray(membersList) || membersList.length === 0 || (!clusterMeta?.ownerAgentId && !hasAdminInPassedMembers)) {
      const membersRes = await apiFetch(`/api/clusters/public/${clusterId}/members`, {
        authType: resolvedAuthType,
        method: 'GET',
        cache: 'no-store',
        skipDedupe: true,
      });
      if (!Array.isArray(membersList) || membersList.length === 0) {
        membersList = membersRes?.data?.members || membersRes?.members || [];
      }
      clusterMeta = clusterMeta || membersRes?.data?.cluster || membersRes?.cluster;
    }

    const senderMember = (membersList || []).find((m: any) => normClusterAgentId(m.agentId) === senderNorm);
    const isSenderAdmin = Boolean(
      (clusterMeta?.ownerAgentId && normClusterAgentId(clusterMeta.ownerAgentId) === senderNorm) ||
      senderMember?.membershipRole === 'admin' ||
      senderMember?.membershipRole === 'owner' ||
      senderMember?.role === 'admin' ||
      senderMember?.role === 'owner'
    );
    if (!isSenderAdmin) return;

    const activeMembers = (membersList || []).filter((m: any) => {
      const mNorm = normClusterAgentId(m.agentId);
      return mNorm && m.status !== 'dissolved' && m.status !== 'inactive' && m.status !== 'removed';
    });
    const activeIds = activeMembers.map((m: any) => m.agentId).filter(Boolean);
    if (clusterMeta?.ownerAgentId) activeIds.push(clusterMeta.ownerAgentId);
    const rosterHash = await computeClusterRosterHash(activeIds);

    const syncEpoch = async (targetEpoch: number, isLatestEpoch: boolean): Promise<void> => {
      let distRes: any = null;
      try {
        distRes = await apiFetch(`/api/clusters/${clusterId}/key-distribution?epoch=${targetEpoch}&audienceHash=ALL`, {
          authType: resolvedAuthType,
          method: 'GET',
          cache: 'no-store',
          skipDedupe: true,
        });
      } catch {}

      const serverFp = isLatestEpoch ? authorityState.keyFingerprint : (distRes?.data?.keyFingerprint || null);
      const serverNeedsRotation = Boolean(isLatestEpoch && typeof serverFp === 'string' && serverFp.startsWith('ROTATION_REQUIRED_'));
      const serverIsSealed = Boolean(
        typeof serverFp === 'string' &&
        serverFp.trim().length > 0 &&
        serverFp !== 'PENDING' &&
        serverFp !== 'PENDING_INIT' &&
        !serverNeedsRotation
      );
      const authoritativeFp = (distRes?.success && distRes.data?.keyFingerprint)
        ? distRes.data.keyFingerprint
        : (serverIsSealed ? serverFp : undefined);

      const staleRecipSet = new Set<string>(
        Array.isArray(distRes?.data?.staleRecipients)
          ? distRes.data.staleRecipients.map((r: string) => normClusterAgentId(r))
          : []
      );

      // For historical epochs (< clusterEpoch), only intervene if there are stale recipients to re-wrap
      if (!isLatestEpoch && staleRecipSet.size === 0) {
        return;
      }

      if (distRes?.success && Array.isArray(distRes.data?.persistedRecipients)) {
        distRes.data.persistedRecipients.forEach((r: string) => {
          const normR = normClusterAgentId(r);
          if (staleRecipSet.has(normR)) {
            clusterMemberKeyDistributedCache.delete(`${clusterId}:${targetEpoch}:ALL:${normR}`);
          } else {
            clusterMemberKeyDistributedCache.add(`${clusterId}:${targetEpoch}:ALL:${normR}`);
          }
        });
      }

      let groupKey = serverNeedsRotation ? null : await getClusterGroupKey(clusterId, targetEpoch, authoritativeFp || undefined, audienceHash);
      let rawGroupKeyBytes: Uint8Array | undefined;
      let groupKeyFingerprint: string | undefined = authoritativeFp || undefined;

      if (!groupKey && !serverNeedsRotation && distRes?.success && distRes.data?.encryptedKeyPackage) {
        try {
          const distributorPubKey = distRes.data.senderPublicKey || distRes.data.senderPublicKeyJwk;
          const unwrapped = await unwrapGroupKeyWithHistoricalEpochs(
            senderAgentId,
            options?.password,
            localKeys,
            distRes.data.encryptedKeyPackage,
            distributorPubKey,
            clusterId,
            targetEpoch,
            audienceHash,
            distRes.data.recipientKeyEpoch,
            distRes.data.senderAgentId || clusterMeta?.ownerAgentId,
            distRes.data.senderPublicKeyHistory
          );
          const calculatedFp = await computeRawGroupKeyFingerprint(unwrapped.rawKey);
          if (!authoritativeFp || calculatedFp === authoritativeFp) {
            groupKey = unwrapped.groupKey;
            rawGroupKeyBytes = unwrapped.rawKey;
            groupKeyFingerprint = calculatedFp;
            await saveClusterGroupKey(clusterId, targetEpoch, rawGroupKeyBytes, calculatedFp, audienceHash);
          }
        } catch {}
      } else if (groupKey) {
        const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;
        const exportedBuf = await cryptoObj.subtle.exportKey('raw', groupKey);
        rawGroupKeyBytes = new Uint8Array(exportedBuf);
        groupKeyFingerprint = await computeRawGroupKeyFingerprint(rawGroupKeyBytes);
      }

      // If rotation is required after member leave/removal, rotate cleanly with a brand new group key
      if (isLatestEpoch && serverNeedsRotation) {
        const gen = await generateClusterGroupKey();
        const rotEligible = activeMembers
          .map((m: any) => ({ m, mPubKey: m.publicKey || m.e2eePublicKey, mNorm: normClusterAgentId(m.agentId) }))
          .filter((entry: any) => Boolean(entry.mNorm && entry.mPubKey));
        const rotResults = await Promise.all(
          rotEligible.map(async ({ m, mPubKey, mNorm }: any) => {
            const wrapped = await wrapClusterGroupKeyForMember(
              gen.rawKey,
              localKeys.privateKey,
              mPubKey,
              clusterId,
              targetEpoch,
              {
                audienceHash: 'ALL',
                keyFingerprint: gen.fingerprint,
                rosterHash,
                senderPublicKey: localKeys.publicKey,
                senderAgentId,
                recipientAgentId: m.agentId,
                recipientKeyFingerprint: m.e2eePublicKeyFingerprint || m.fingerprint,
                recipientKeyEpoch: m.e2eeKeyEpoch || 1
              }
            );
            return {
              dist: {
                recipientAgentId: m.agentId,
                senderAgentId,
                senderPublicKey: localKeys.publicKey,
                recipientKeyEpoch: m.e2eeKeyEpoch || 1,
                encryptedKeyPackage: wrapped
              },
              norm: mNorm
            };
          })
        );
        const rotDistributions = rotResults.map((r) => r.dist);
        const rotRecipients = rotResults.map((r) => r.norm);

        if (rotDistributions.length > 0) {
          const rotRes = await apiFetch(`/api/clusters/${clusterId}/rotate-key`, {
            authType: 'human',
            method: 'POST',
            body: JSON.stringify({
              nextEpoch: targetEpoch,
              keyFingerprint: gen.fingerprint,
              rosterHash,
              senderAgentId,
              senderPublicKey: localKeys.publicKey,
              distributions: rotDistributions
            })
          });
          if (rotRes?.success) {
            const confirmedEpoch = rotRes.data?.epoch || targetEpoch;
            await saveClusterGroupKey(clusterId, confirmedEpoch, gen.rawKey, gen.fingerprint, 'ALL');
            const confirmed = Array.isArray(rotRes.data?.persistedRecipients) ? rotRes.data.persistedRecipients : rotRecipients;
            confirmed.forEach((r: string) => {
              clusterMemberKeyDistributedCache.add(`${clusterId}:${confirmedEpoch}:ALL:${normClusterAgentId(r)}`);
            });
            clusterEpochCache.set(clusterId, { epoch: confirmedEpoch, expiresAt: Date.now() + 30000 });
          }
        }
        return;
      }

      // Never overwrite an already-sealed epoch with a new random key
      if (!groupKey || !rawGroupKeyBytes) {
        if (!isLatestEpoch || serverIsSealed || authoritativeFp) {
          return;
        }
        const gen = await generateClusterGroupKey();
        rawGroupKeyBytes = gen.rawKey;
        groupKeyFingerprint = gen.fingerprint;
        groupKey = gen.key;
      }

      const wrapTargets = activeMembers.filter((m: any) => {
        const mPubKey = m.publicKey || m.e2eePublicKey;
        const mNorm = normClusterAgentId(m.agentId);
        return isLatestEpoch
          ? Boolean(mNorm && mPubKey && !clusterMemberKeyDistributedCache.has(`${clusterId}:${targetEpoch}:ALL:${mNorm}`))
          : Boolean(mNorm && mPubKey && staleRecipSet.has(mNorm));
      });
      const wrappedEntries = await Promise.all(
        wrapTargets.map(async (m: any) => {
          const mPubKey = m.publicKey || m.e2eePublicKey;
          const mNorm = normClusterAgentId(m.agentId);
          const wrapped = await wrapClusterGroupKeyForMember(
            rawGroupKeyBytes!,
            localKeys.privateKey,
            mPubKey,
            clusterId,
            targetEpoch,
            {
              audienceHash: 'ALL',
              keyFingerprint: groupKeyFingerprint,
              rosterHash,
              senderPublicKey: localKeys.publicKey,
              senderAgentId,
              recipientAgentId: m.agentId,
              recipientKeyFingerprint: m.e2eePublicKeyFingerprint || m.fingerprint,
              recipientKeyEpoch: m.e2eeKeyEpoch || 1
            }
          );
          return {
            dist: {
              recipientAgentId: m.agentId,
              senderAgentId,
              senderPublicKey: localKeys.publicKey,
              recipientKeyEpoch: m.e2eeKeyEpoch || 1,
              encryptedKeyPackage: wrapped
            },
            norm: mNorm
          };
        })
      );
      const distributions = wrappedEntries.map((e) => e.dist);
      const pendingRecipients = wrappedEntries.map((e) => e.norm);

      if (distributions.length > 0) {
        const distPostRes = await apiFetch(`/api/clusters/${clusterId}/key-distribution`, {
          authType: resolvedAuthType,
          method: 'POST',
          body: JSON.stringify({
            epoch: targetEpoch,
            audienceHash: 'ALL',
            rosterHash,
            keyFingerprint: groupKeyFingerprint,
            senderAgentId,
            senderPublicKey: localKeys.publicKey,
            distributions
          })
        });

        if (distPostRes?.success) {
          await saveClusterGroupKey(clusterId, targetEpoch, rawGroupKeyBytes, groupKeyFingerprint, 'ALL');
          const rawPersisted = distPostRes.data?.persistedRecipients;
          const persistedRecipients: string[] | null = Array.isArray(rawPersisted)
            ? rawPersisted.map((r: string) => normClusterAgentId(r))
            : null;

          if (persistedRecipients) {
            pendingRecipients.forEach((r) => {
              if (persistedRecipients.includes(r)) {
                clusterMemberKeyDistributedCache.add(`${clusterId}:${targetEpoch}:ALL:${r}`);
              }
            });
          }

          const allProvisioned = activeMembers.every((m: any) =>
            clusterMemberKeyDistributedCache.has(`${clusterId}:${targetEpoch}:ALL:${normClusterAgentId(m.agentId)}`)
          );

          if (allProvisioned) {
            clusterKeyDistributedCache.add(`${clusterId}:${targetEpoch}:ALL`);
          }
        }
      }
    };

    await syncEpoch(clusterEpoch, true);

    // Also repair any stale member key packages on historical sealed epochs when admin holds those epoch keys
    for (let histEp = clusterEpoch - 1; histEp >= 1; histEp--) {
      await syncEpoch(histEp, false).catch(() => {});
    }
  } catch {
    // Non-fatal background sync
  }
}

export async function sendClusterMessageApi(
  clusterId: string,
  plaintext: string,
  senderAgentId: string,
  options?: {
    password?: string;
    authType?: 'human' | 'agent';
    selectedRecipientAgentIds?: string[];
  }
): Promise<any> {
  const password = options?.password;
  const resolvedAuthType: 'human' | 'agent' = options?.authType || getCurrentSessionAuthType();

  if (!plaintext || typeof plaintext !== 'string' || plaintext.trim().length === 0) {
    throw new Error('E2EE Error: Message content cannot be empty.');
  }

  // 1. Run slave guard and sender key resolution in parallel
  const [isSlave, localKeys] = await Promise.all([
    resolvedAuthType === 'human' ? checkIsSlaveCached(senderAgentId) : Promise.resolve(false),
    resolveOrRecoverSenderLocalKeys(senderAgentId, password, resolvedAuthType),
  ]);

  if (isSlave) {
    throw new Error(
      'Slave UI messaging is disabled. Slave agents must send messages via their agent runtime API.'
    );
  }

  // Ensure sender's local E2EE public key matches server registration (cached)
  await ensureSenderE2EEKeySyncedOnServer(localKeys, resolvedAuthType);

  const executeAttempt = async (attempt: number, prevServerError?: any): Promise<any> => {
    const forceRefresh = attempt > 0;
    const nowTs = Date.now();
    const cachedMembers = !forceRefresh ? clusterSendMembersCache.get(clusterId) : undefined;
    let membersList: any[] = [];
    let clusterMeta: any = null;

    if (cachedMembers && cachedMembers.expiresAt > nowTs) {
      membersList = cachedMembers.membersList;
      clusterMeta = cachedMembers.clusterMeta;
    } else {
      // 2. Fetch authoritative cluster members & epoch metadata
      const membersRes = await apiFetch(`/api/clusters/public/${clusterId}/members`, {
        authType: resolvedAuthType,
        method: 'GET',
        cache: 'no-store',
        skipDedupe: forceRefresh,
      });
      membersList = membersRes?.data?.members || membersRes?.members || [];
      clusterMeta = membersRes?.data?.cluster || membersRes?.cluster || null;
      if (membersList.length > 0 || clusterMeta) {
        clusterSendMembersCache.set(clusterId, {
          membersList,
          clusterMeta,
          expiresAt: Date.now() + 120000,
        });
      }
    }

    const needAuthorityFetch = forceRefresh || Boolean(prevServerError) || !(typeof clusterMeta?.epoch === 'number' && clusterMeta.epoch > 0);
    const authorityState = needAuthorityFetch
      ? await fetchClusterAuthorityState(clusterId, resolvedAuthType, true)
      : { epoch: clusterMeta.epoch, keyFingerprint: clusterMeta.keyFingerprint || null, rosterHash: clusterMeta.rosterHash || null };
    let clusterEpoch = (typeof clusterMeta?.epoch === 'number' && clusterMeta.epoch > 0)
      ? clusterMeta.epoch
      : authorityState.epoch;
    let serverFp = clusterMeta?.keyFingerprint || authorityState.keyFingerprint;

    const senderNorm = normClusterAgentId(senderAgentId);
    const senderMember = membersList.find((m: any) => normClusterAgentId(m.agentId) === senderNorm);
    const isSenderAdmin = Boolean(
      (clusterMeta?.ownerAgentId && normClusterAgentId(clusterMeta.ownerAgentId) === senderNorm) ||
      senderMember?.membershipRole === 'admin' ||
      senderMember?.membershipRole === 'owner' ||
      senderMember?.role === 'admin' ||
      senderMember?.role === 'owner'
    );

    const activeMembers = membersList.filter((m: any) => {
      const mNorm = normClusterAgentId(m.agentId);
      return mNorm && m.status !== 'dissolved' && m.status !== 'inactive' && m.status !== 'removed';
    });
    const activeMemberIds = activeMembers.map((m: any) => m.agentId).filter(Boolean);
    if (clusterMeta?.ownerAgentId) activeMemberIds.push(clusterMeta.ownerAgentId);

    const activeNormSet = new Set(activeMemberIds.map((id: string) => normClusterAgentId(id)).filter(Boolean));
    const rosterHash = await computeClusterRosterHash(activeMemberIds);

    // Mirror exact server recipient rules so audienceHash matches server pre-flight validation
    const effectiveRecipientNormSet = new Set<string>();
    const hasExplicitSelection = Array.isArray(options?.selectedRecipientAgentIds) && options!.selectedRecipientAgentIds!.length > 0;
    if (hasExplicitSelection) {
      for (const rId of options!.selectedRecipientAgentIds!) {
        const rn = normClusterAgentId(rId);
        if (rn && activeNormSet.has(rn)) effectiveRecipientNormSet.add(rn);
      }
      if (clusterMeta?.ownerAgentId) {
        const on = normClusterAgentId(clusterMeta.ownerAgentId);
        if (on) effectiveRecipientNormSet.add(on);
      }
      if (senderNorm) effectiveRecipientNormSet.add(senderNorm);
    } else {
      activeNormSet.forEach((id) => effectiveRecipientNormSet.add(id));
    }

    const effectiveRecipientIds = Array.from(effectiveRecipientNormSet);
    const audienceHash = await computeClusterAudienceHash(effectiveRecipientIds, activeMemberIds);

    // Handle pending epoch rotation required (after member kick / leave)
    const serverNeedsRotation = Boolean(typeof serverFp === 'string' && serverFp.startsWith('ROTATION_REQUIRED_'));
    if (serverNeedsRotation) {
      if (!isSenderAdmin) {
        throw new Error(
          `E2EE Error: Cluster epoch ${clusterEpoch} requires key rotation by an administrator after a membership change before messages can be sent.`
        );
      }
      const unkeyedAll = activeMembers.filter((m: any) => !m.publicKey && !m.e2eePublicKey);
      if (unkeyedAll.length > 0) {
        const unkeyedNames = unkeyedAll.map((m: any) => `@${m.agentId}`).join(', ');
        throw new Error(
          `E2EE Error: Cannot rotate cluster group key: Active cluster member(s) [${unkeyedNames}] lack registered E2EE public keys.`
        );
      }
      const gen = await generateClusterGroupKey();
      const rotWrapped = await Promise.all(
        activeMembers.map(async (m: any) => {
          const mPubKey = m.publicKey || m.e2eePublicKey;
          const mNorm = normClusterAgentId(m.agentId);
          const wrapped = await wrapClusterGroupKeyForMember(
            gen.rawKey,
            localKeys.privateKey,
            mPubKey,
            clusterId,
            clusterEpoch,
            {
              audienceHash: 'ALL',
              keyFingerprint: gen.fingerprint,
              rosterHash,
              senderPublicKey: localKeys.publicKey,
              senderAgentId,
              recipientAgentId: m.agentId,
              recipientKeyFingerprint: m.e2eePublicKeyFingerprint || m.fingerprint,
              recipientKeyEpoch: m.e2eeKeyEpoch || 1
            }
          );
          return {
            dist: {
              recipientAgentId: m.agentId,
              senderAgentId,
              senderPublicKey: localKeys.publicKey,
              recipientKeyEpoch: m.e2eeKeyEpoch || 1,
              encryptedKeyPackage: wrapped
            },
            norm: mNorm
          };
        })
      );
      const rotDists = rotWrapped.map((r) => r.dist);
      const rotRecips = rotWrapped.map((r) => r.norm);
      const rotRes = await apiFetch(`/api/clusters/${clusterId}/rotate-key`, {
        authType: resolvedAuthType,
        method: 'POST',
        body: JSON.stringify({
          nextEpoch: clusterEpoch,
          keyFingerprint: gen.fingerprint,
          rosterHash,
          senderAgentId,
          senderPublicKey: localKeys.publicKey,
          distributions: rotDists
        })
      });
      if (!rotRes?.success) {
        throw new Error(
          `E2EE Error: Cluster key rotation failed: ${rotRes?.error?.message || 'Unable to seal rotated epoch.'}`
        );
      }
      clusterEpoch = rotRes.data?.epoch || clusterEpoch;
      serverFp = gen.fingerprint;
      await saveClusterGroupKey(clusterId, clusterEpoch, gen.rawKey, gen.fingerprint, 'ALL');
      rotRecips.forEach((r) => {
        clusterMemberKeyDistributedCache.add(`${clusterId}:${clusterEpoch}:ALL:${r}`);
      });
      clusterEpochCache.set(clusterId, { epoch: clusterEpoch, expiresAt: Date.now() + 30000 });
    }

    // Determine exact target members for this (epoch, audienceHash)
    const targetMembers = audienceHash === 'ALL'
      ? activeMembers
      : activeMembers.filter((m: any) => effectiveRecipientNormSet.has(normClusterAgentId(m.agentId)));

    const serverIsSealedForAll = Boolean(
      typeof serverFp === 'string' &&
      serverFp.trim().length > 0 &&
      serverFp !== 'PENDING' &&
      serverFp !== 'PENDING_INIT' &&
      !serverFp.startsWith('ROTATION_REQUIRED_')
    );

    // Fast-path: when not forced to refresh, check local group key + client distribution cache BEFORE hitting GET /key-distribution
    const hintFp = audienceHash === 'ALL' && serverIsSealedForAll ? serverFp : undefined;
    let groupKey = !forceRefresh
      ? await getClusterGroupKey(clusterId, clusterEpoch, hintFp, audienceHash)
      : null;
    const allTargetsProvisionedInCache = targetMembers.length > 0 && targetMembers.every((m: any) =>
      clusterMemberKeyDistributedCache.has(`${clusterId}:${clusterEpoch}:${audienceHash}:${normClusterAgentId(m.agentId)}`)
    );
    const skipDistGet = Boolean(!forceRefresh && groupKey && (allTargetsProvisionedInCache || clusterKeyDistributedCache.has(`${clusterId}:${clusterEpoch}:${audienceHash}`)));

    // 3. Query server for authoritative key distribution package only when fast-path cannot satisfy locally
    let distRes: any = null;
    if (!skipDistGet) {
      try {
        distRes = await apiFetch(
          `/api/clusters/${clusterId}/key-distribution?epoch=${clusterEpoch}&audienceHash=${encodeURIComponent(audienceHash)}`,
          { authType: resolvedAuthType, method: 'GET', cache: 'no-store', skipDedupe: forceRefresh }
        );
      } catch {}
    }

    const authoritativeFp = (distRes?.success && distRes.data?.keyFingerprint)
      ? distRes.data.keyFingerprint
      : (audienceHash === 'ALL' && serverIsSealedForAll ? serverFp : null);

    const staleRecipSet = new Set<string>(
      Array.isArray(distRes?.data?.staleRecipients)
        ? distRes.data.staleRecipients.map((r: string) => normClusterAgentId(r))
        : []
    );

    // Populate persisted recipient cache from server response, clearing any entries whose personal key rotated
    if (distRes?.success && Array.isArray(distRes.data?.persistedRecipients)) {
      distRes.data.persistedRecipients.forEach((r: string) => {
        const normR = normClusterAgentId(r);
        if (staleRecipSet.has(normR)) {
          clusterMemberKeyDistributedCache.delete(`${clusterId}:${clusterEpoch}:${audienceHash}:${normR}`);
        } else {
          clusterMemberKeyDistributedCache.add(`${clusterId}:${clusterEpoch}:${audienceHash}:${normR}`);
        }
      });
    }

    // Retrieve or validate locally cached group/subgroup key against authoritative fingerprint
    if (!skipDistGet) {
      groupKey = await getClusterGroupKey(clusterId, clusterEpoch, authoritativeFp || undefined, audienceHash);
    }
    let rawGroupKeyBytes: Uint8Array | undefined;
    let groupKeyFingerprint: string | undefined = authoritativeFp || undefined;

    // If local key is absent or evicted due to fingerprint mismatch, unwrap server package (with historical personal key epoch fallback)
    if (!groupKey && distRes?.success && distRes.data?.encryptedKeyPackage) {
      const distributorPubKey = distRes.data.senderPublicKey || distRes.data.senderPublicKeyJwk;
      const unwrapped = await unwrapGroupKeyWithHistoricalEpochs(
        senderAgentId,
        password,
        localKeys,
        distRes.data.encryptedKeyPackage,
        distributorPubKey,
        clusterId,
        clusterEpoch,
        audienceHash,
        distRes.data.recipientKeyEpoch,
        distRes.data.senderAgentId || clusterMeta?.ownerAgentId,
        distRes.data.senderPublicKeyHistory
      );
      const calculatedFp = await computeRawGroupKeyFingerprint(unwrapped.rawKey);
      if (authoritativeFp && calculatedFp !== authoritativeFp) {
        throw new Error(
          `E2EE Verification Failure: Unwrapped group key fingerprint (${calculatedFp}) does not match authoritative epoch fingerprint (${authoritativeFp}). Key rejected.`
        );
      }
      groupKey = unwrapped.groupKey;
      rawGroupKeyBytes = unwrapped.rawKey;
      groupKeyFingerprint = calculatedFp;
      await saveClusterGroupKey(clusterId, clusterEpoch, rawGroupKeyBytes, calculatedFp, audienceHash);
      clusterMemberKeyDistributedCache.add(`${clusterId}:${clusterEpoch}:${audienceHash}:${senderNorm}`);
    }

    // 4. Establish key if missing OR repair missing/rotated member wrappings
    if (!groupKey) {
      if (audienceHash === 'ALL' && !isSenderAdmin) {
        throw new Error(
          `E2EE Error: Cluster group key for epoch ${clusterEpoch} has not been distributed by a cluster administrator. Message submission aborted.`
        );
      }

      if (audienceHash === 'ALL' && serverIsSealedForAll) {
        // Epoch is already sealed on server with an unrecoverable legacy key (e.g., admin logged into new device before vault existed) — NEVER overwrite sealed epoch; advance cleanly to next epoch
        const unkeyedAll = activeMembers.filter((m: any) => !m.publicKey && !m.e2eePublicKey);
        if (resolvedAuthType !== 'human' || unkeyedAll.length > 0) {
          throw new Error(
            `E2EE Error: Cluster epoch ${clusterEpoch} is already sealed with fingerprint ${serverFp}, and no matching key is available locally. Rotate cluster key to send.`
          );
        }

        const nextEpochTarget = clusterEpoch + 1;
        const gen = await generateClusterGroupKey();
        const rotEntries = await Promise.all(
          activeMembers.map(async (m: any) => {
            const mPubKey = m.publicKey || m.e2eePublicKey;
            const mNorm = normClusterAgentId(m.agentId);
            const wrapped = await wrapClusterGroupKeyForMember(
              gen.rawKey,
              localKeys.privateKey,
              mPubKey,
              clusterId,
              nextEpochTarget,
              {
                audienceHash: 'ALL',
                keyFingerprint: gen.fingerprint,
                rosterHash,
                senderPublicKey: localKeys.publicKey,
                senderAgentId,
                recipientAgentId: m.agentId,
                recipientKeyFingerprint: m.e2eePublicKeyFingerprint || m.fingerprint,
                recipientKeyEpoch: m.e2eeKeyEpoch || 1
              }
            );
            return {
              dist: {
                recipientAgentId: m.agentId,
                senderAgentId,
                senderPublicKey: localKeys.publicKey,
                recipientKeyEpoch: m.e2eeKeyEpoch || 1,
                encryptedKeyPackage: wrapped
              },
              norm: mNorm
            };
          })
        );
        const rotDists = rotEntries.map((r) => r.dist);
        const rotRecips = rotEntries.map((r) => r.norm);

        const rotRes = await apiFetch(`/api/clusters/${clusterId}/rotate-key`, {
          authType: 'human',
          method: 'POST',
          body: JSON.stringify({
            nextEpoch: nextEpochTarget,
            keyFingerprint: gen.fingerprint,
            rosterHash,
            senderAgentId,
            senderPublicKey: localKeys.publicKey,
            distributions: rotDists
          })
        });
        if (!rotRes?.success) {
          throw new Error(
            `E2EE Error: Cluster epoch ${clusterEpoch} is sealed and automatic key advancement failed: ${rotRes?.error?.message || 'Unable to rotate cluster key.'}`
          );
        }
        clusterEpoch = rotRes.data?.epoch || nextEpochTarget;
        groupKey = gen.key;
        rawGroupKeyBytes = gen.rawKey;
        groupKeyFingerprint = gen.fingerprint;
        await saveClusterGroupKey(clusterId, clusterEpoch, gen.rawKey, gen.fingerprint, 'ALL');
        rotRecips.forEach((r) => {
          clusterMemberKeyDistributedCache.add(`${clusterId}:${clusterEpoch}:ALL:${r}`);
        });
        clusterKeyDistributedCache.add(`${clusterId}:${clusterEpoch}:ALL`);
        clusterEpochCache.set(clusterId, { epoch: clusterEpoch, expiresAt: Date.now() + 30000 });
      } else {

      const unkeyedMembers = targetMembers.filter((m: any) => !m.publicKey && !m.e2eePublicKey);
      if (unkeyedMembers.length > 0) {
        const unkeyedNames = unkeyedMembers.map((m: any) => `@${m.agentId}`).join(', ');
        throw new Error(
          `E2EE Error: Incomplete key distribution: Target cluster member(s) [${unkeyedNames}] lack registered E2EE public keys. Message submission aborted.`
        );
      }

      const gen = await generateClusterGroupKey();
      rawGroupKeyBytes = gen.rawKey;
      groupKeyFingerprint = gen.fingerprint;
      groupKey = gen.key;

      const wrappedEntries = await Promise.all(
        targetMembers.map(async (m: any) => {
          const mPubKey = m.publicKey || m.e2eePublicKey;
          const mNorm = normClusterAgentId(m.agentId);
          const wrapped = await wrapClusterGroupKeyForMember(
            rawGroupKeyBytes!,
            localKeys.privateKey,
            mPubKey,
            clusterId,
            clusterEpoch,
            {
              audienceHash,
              keyFingerprint: groupKeyFingerprint,
              rosterHash,
              senderPublicKey: localKeys.publicKey,
              senderAgentId,
              recipientAgentId: m.agentId,
              recipientKeyFingerprint: m.e2eePublicKeyFingerprint || m.fingerprint,
              recipientKeyEpoch: m.e2eeKeyEpoch || 1
            }
          );
          return {
            dist: {
              recipientAgentId: m.agentId,
              senderAgentId,
              senderPublicKey: localKeys.publicKey,
              recipientKeyEpoch: m.e2eeKeyEpoch || 1,
              encryptedKeyPackage: wrapped
            },
            norm: mNorm
          };
        })
      );
      const distributions = wrappedEntries.map((e) => e.dist);
      const pendingRecipients = wrappedEntries.map((e) => e.norm);

      if (distributions.length === 0) {
        throw new Error(
          'E2EE Error: Key distribution failed: No eligible recipient cluster members available to receive key packages. Message submission aborted.'
        );
      }

      const distPostRes = await apiFetch(`/api/clusters/${clusterId}/key-distribution`, {
        authType: resolvedAuthType,
        method: 'POST',
        body: JSON.stringify({
          epoch: clusterEpoch,
          audienceHash,
          rosterHash,
          keyFingerprint: groupKeyFingerprint,
          senderAgentId,
          senderPublicKey: localKeys.publicKey,
          distributions
        })
      });

      if (!distPostRes?.success) {
        if (distPostRes?.error?.code === 'EPOCH_KEY_ALREADY_SEALED' && attempt === 0) {
          await deleteClusterGroupKey(clusterId, clusterEpoch, audienceHash);
          invalidateClusterClientCaches(clusterId, clusterEpoch);
          return executeAttempt(1, distPostRes.error);
        }
        throw new Error(
          `E2EE Error: Failed to distribute cluster group key: ${distPostRes?.error?.message || 'Server rejected key distribution'}. Message submission aborted.`
        );
      }

      const rawPersisted = distPostRes.data?.persistedRecipients;
      const persistedRecipients: string[] | null = Array.isArray(rawPersisted)
        ? rawPersisted.map((r: string) => normClusterAgentId(r))
        : null;

      if (persistedRecipients) {
        pendingRecipients.forEach((r) => {
          if (persistedRecipients.includes(r)) {
            clusterMemberKeyDistributedCache.add(`${clusterId}:${clusterEpoch}:${audienceHash}:${r}`);
          }
        });
      }

      const hasCompleteConfirmedIdentities = Boolean(
        persistedRecipients &&
        persistedRecipients.length >= pendingRecipients.length &&
        pendingRecipients.every((r) => persistedRecipients.includes(r))
      );

      if (!hasCompleteConfirmedIdentities) {
        const confirmedCount = persistedRecipients ? persistedRecipients.length : 0;
        throw new Error(
          `E2EE Error: Recipient persistence confirmation missing or incomplete: Server confirmed ${confirmedCount} of ${pendingRecipients.length} intended recipient key packages. Message submission aborted.`
        );
      }

      await saveClusterGroupKey(clusterId, clusterEpoch, rawGroupKeyBytes, groupKeyFingerprint, audienceHash);
      clusterKeyDistributedCache.add(`${clusterId}:${clusterEpoch}:${audienceHash}`);
      }
    } else {
      if (!rawGroupKeyBytes) {
        try {
          const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;
          const exportedBuf = await cryptoObj.subtle.exportKey('raw', groupKey);
          rawGroupKeyBytes = new Uint8Array(exportedBuf);
          groupKeyFingerprint = await computeRawGroupKeyFingerprint(rawGroupKeyBytes);
        } catch {}
      }

      const forcedMissingSet = new Set<string>(
        Array.isArray(prevServerError?.missingRecipients)
          ? prevServerError.missingRecipients.map((r: string) => normClusterAgentId(r))
          : []
      );
      if (Array.isArray(prevServerError?.staleKeyRecipients)) {
        prevServerError.staleKeyRecipients.forEach((r: string) => forcedMissingSet.add(normClusterAgentId(r)));
      }

      const unprovisionedMembers = targetMembers.filter((m: any) => {
        const mNorm = normClusterAgentId(m.agentId);
        return (
          forcedMissingSet.has(mNorm) ||
          !clusterMemberKeyDistributedCache.has(`${clusterId}:${clusterEpoch}:${audienceHash}:${mNorm}`)
        );
      });

      if (unprovisionedMembers.length > 0) {
        if (audienceHash === 'ALL' && !isSenderAdmin) {
          const unprovisionedNames = unprovisionedMembers.map((m: any) => `@${m.agentId}`).join(', ');
          throw new Error(
            `E2EE Error: Unprovisioned active cluster member(s) [${unprovisionedNames}] detected for epoch ${clusterEpoch}. Non-admin senders cannot distribute cluster-wide epoch keys.`
          );
        }

        const unkeyed = unprovisionedMembers.filter((m: any) => !m.publicKey && !m.e2eePublicKey);
        if (unkeyed.length > 0) {
          const unkeyedNames = unkeyed.map((m: any) => `@${m.agentId}`).join(', ');
          throw new Error(
            `E2EE Error: Incomplete key distribution: Active target member(s) [${unkeyedNames}] lack registered public keys. Message submission aborted.`
          );
        }

        if (!rawGroupKeyBytes) {
          throw new Error(
            'E2EE Error: Cannot distribute group key to unprovisioned members: raw group key bytes unavailable.'
          );
        }

        const wrappedPending = await Promise.all(
          unprovisionedMembers.map(async (m: any) => {
            const mPubKey = m.publicKey || m.e2eePublicKey;
            const mNorm = normClusterAgentId(m.agentId);
            const wrapped = await wrapClusterGroupKeyForMember(
              rawGroupKeyBytes!,
              localKeys.privateKey,
              mPubKey,
              clusterId,
              clusterEpoch,
              {
                audienceHash,
                keyFingerprint: groupKeyFingerprint,
                rosterHash,
                senderPublicKey: localKeys.publicKey,
                senderAgentId,
                recipientAgentId: m.agentId,
                recipientKeyFingerprint: m.e2eePublicKeyFingerprint || m.fingerprint,
                recipientKeyEpoch: m.e2eeKeyEpoch || 1
              }
            );
            return {
              dist: {
                recipientAgentId: m.agentId,
                senderAgentId,
                senderPublicKey: localKeys.publicKey,
                recipientKeyEpoch: m.e2eeKeyEpoch || 1,
                encryptedKeyPackage: wrapped
              },
              norm: mNorm
            };
          })
        );
        const pendingDistributions = wrappedPending.map((e) => e.dist);
        const pendingRecipients = wrappedPending.map((e) => e.norm);

        const distPostRes = await apiFetch(`/api/clusters/${clusterId}/key-distribution`, {
          authType: resolvedAuthType,
          method: 'POST',
          body: JSON.stringify({
            epoch: clusterEpoch,
            audienceHash,
            rosterHash,
            keyFingerprint: groupKeyFingerprint,
            senderAgentId,
            senderPublicKey: localKeys.publicKey,
            distributions: pendingDistributions
          })
        });

        if (!distPostRes?.success) {
          throw new Error(
            `E2EE Error: Failed to distribute group key to unprovisioned members: ${distPostRes?.error?.message || 'Server rejected key distribution'}. Message submission aborted.`
          );
        }

        const rawPersisted = distPostRes.data?.persistedRecipients;
        const persistedRecipients: string[] | null = Array.isArray(rawPersisted)
          ? rawPersisted.map((r: string) => normClusterAgentId(r))
          : null;

        if (persistedRecipients) {
          pendingRecipients.forEach((r) => {
            if (persistedRecipients.includes(r)) {
              clusterMemberKeyDistributedCache.add(`${clusterId}:${clusterEpoch}:${audienceHash}:${r}`);
            }
          });
        }

        const hasCompleteConfirmedIdentities = Boolean(
          persistedRecipients &&
          persistedRecipients.length >= pendingRecipients.length &&
          pendingRecipients.every((r) => persistedRecipients.includes(r))
        );

        if (!hasCompleteConfirmedIdentities) {
          const confirmedCount = persistedRecipients ? persistedRecipients.length : 0;
          throw new Error(
            `E2EE Error: Recipient persistence confirmation missing or incomplete: Server confirmed ${confirmedCount} of ${pendingRecipients.length} member key packages. Message submission aborted.`
          );
        }

        clusterKeyDistributedCache.add(`${clusterId}:${clusterEpoch}:${audienceHash}`);
      }
    }

    // 5. Encrypt message ONCE using shared group / subgroup key (O(1) scaling)
    const encrypted = await encryptClusterMessage(
      plaintext,
      groupKey,
      senderAgentId,
      clusterId,
      clusterEpoch,
      audienceHash
    );

    // 6. Sign canonical envelope with sender's identity key (if present locally)
    let signature: string | undefined;
    if (localKeys.identityPrivateKey) {
      try {
        signature = await signClusterMessageEnvelope(localKeys.identityPrivateKey, {
          clusterId,
          keyEpoch: encrypted.keyEpoch,
          senderAgentId,
          audienceHash,
          rosterHash,
          sequence: null,
          keyFingerprint: groupKeyFingerprint,
          nonce: encrypted.nonce,
          ciphertext: encrypted.ciphertext
        });
      } catch {}
    }

    // 7. Submit single ciphertext envelope to server Pre-Flight Reject Gate
    const res = await apiFetch(`/api/clusters/${clusterId}/messages`, {
      authType: resolvedAuthType,
      method: 'POST',
      body: JSON.stringify({
        ciphertext: encrypted.ciphertext,
        nonce: encrypted.nonce,
        version: encrypted.version,
        keyEpoch: encrypted.keyEpoch,
        audienceHash,
        rosterHash,
        keyFingerprint: groupKeyFingerprint,
        ...(signature ? { signature } : {}),
        strictPreflight: true,
        ...(options?.selectedRecipientAgentIds ? { recipientAgentIds: options.selectedRecipientAgentIds } : {})
      })
    });

    if (!res?.success) {
      const errCode = res?.error?.code;
      const isRetryablePreflight = Boolean(
        errCode === 'EPOCH_STALE' ||
        errCode === 'EPOCH_ROTATION_REQUIRED' ||
        errCode === 'ROSTER_STALE' ||
        errCode === 'MISSING_RECIPIENT_KEYS' ||
        errCode === 'KEY_MISMATCH' ||
        errCode === 'EPOCH_KEY_ALREADY_SEALED'
      );

      if (isRetryablePreflight && attempt === 0) {
        invalidateClusterClientCaches(clusterId);
        verifiedSenderKeySync.clear();
        if (errCode === 'KEY_MISMATCH' || errCode === 'EPOCH_KEY_ALREADY_SEALED') {
          await deleteClusterGroupKey(clusterId, clusterEpoch, audienceHash);
        }
        return executeAttempt(1, res.error);
      }

      throw new Error(res?.error?.message || `Cluster message rejected (${errCode || 'PREFLIGHT_REJECTED'}).`);
    }

    return res.data || res;
  };

  return executeAttempt(0);
}

export async function establishDirectConnectionApi(targetAgentId: string, authType: 'human' | 'agent' = 'human'): Promise<any> {
  const res = await apiFetch('/api/connections/establish', {
    method: 'POST',
    authType,
    body: JSON.stringify({ targetAgentId })
  });
  return res.data || res;
}

/**
 * Register or update the authenticated agent's E2EE public key and identity binding
 * PUT /api/agents/me/e2ee
 */
export async function registerAgentE2eeKeyApi(params: {
  publicKey: string | object;
  fingerprint?: string;
  identityKey?: string | object;
  signature?: string;
  keyEpoch?: number;
  allowRotation?: boolean;
}): Promise<{ fingerprint: string; keyEpoch: number; hasIdentityBinding: boolean }> {
  const res = await apiFetch('/api/agents/me/e2ee', {
    authType: 'agent',
    method: 'PUT',
    body: JSON.stringify(params),
  });
  return res.data || res;
}

/**
 * Retrieve the authenticated agent's registered E2EE public key and fingerprint
 * GET /api/agents/me/e2ee
 */
export async function getAgentE2eeKeyApi(): Promise<{
  publicKey: string | null;
  fingerprint: string | null;
  identityKey: string | null;
  keyEpoch: number;
}> {
  const res = await apiFetch('/api/agents/me/e2ee', {
    authType: 'agent',
    method: 'GET',
  });
  return res.data || res;
}


