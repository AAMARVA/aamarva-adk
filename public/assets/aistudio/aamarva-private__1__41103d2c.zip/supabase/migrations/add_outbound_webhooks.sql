-- ==============================================================================
-- Migration: Outbound Webhook Subscriptions & Delivery History Tables
-- ==============================================================================

CREATE TABLE IF NOT EXISTS webhook_subscriptions (
  id TEXT PRIMARY KEY DEFAULT ('wh_sub_' || gen_random_uuid()::TEXT),
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  agent_id TEXT,
  url TEXT NOT NULL,
  secret TEXT NOT NULL,
  events JSONB NOT NULL DEFAULT '["*"]'::jsonb,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS webhook_deliveries (
  id TEXT PRIMARY KEY DEFAULT ('wh_del_' || gen_random_uuid()::TEXT),
  subscription_id TEXT NOT NULL REFERENCES webhook_subscriptions(id) ON DELETE CASCADE,
  event_type TEXT NOT NULL,
  payload JSONB,
  status_code INTEGER,
  response_body TEXT,
  success BOOLEAN NOT NULL DEFAULT FALSE,
  error_message TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_webhook_subscriptions_user_active
  ON webhook_subscriptions (user_id, is_active, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_webhook_deliveries_sub_created
  ON webhook_deliveries (subscription_id, created_at DESC);

ALTER TABLE webhook_subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE webhook_deliveries ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE tablename = 'webhook_subscriptions' AND policyname = 'Allow service_role full access to webhook_subscriptions'
  ) THEN
    CREATE POLICY "Allow service_role full access to webhook_subscriptions"
    ON webhook_subscriptions
    FOR ALL
    TO service_role
    USING (true)
    WITH CHECK (true);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE tablename = 'webhook_deliveries' AND policyname = 'Allow service_role full access to webhook_deliveries'
  ) THEN
    CREATE POLICY "Allow service_role full access to webhook_deliveries"
    ON webhook_deliveries
    FOR ALL
    TO service_role
    USING (true)
    WITH CHECK (true);
  END IF;
END $$;

NOTIFY pgrst, 'reload schema';
