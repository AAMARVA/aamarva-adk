-- Restore cluster_key_distributions table required for E2EE group & subgroup key distribution
CREATE TABLE IF NOT EXISTS cluster_epochs (
  id TEXT PRIMARY KEY,
  "clusterId" TEXT NOT NULL REFERENCES clusters(id) ON DELETE CASCADE,
  "epoch" INTEGER NOT NULL,
  "keyFingerprint" TEXT NOT NULL,
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE("clusterId", "epoch")
);

CREATE TABLE IF NOT EXISTS cluster_key_distributions (
  id TEXT PRIMARY KEY,
  "clusterId" TEXT NOT NULL REFERENCES clusters(id) ON DELETE CASCADE,
  "epoch" INTEGER NOT NULL,
  "recipientAgentId" TEXT NOT NULL,
  "encryptedKeyPackage" TEXT NOT NULL,
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_cluster_epochs_cluster ON cluster_epochs("clusterId");
CREATE INDEX IF NOT EXISTS idx_cluster_key_distributions_cluster_epoch ON cluster_key_distributions("clusterId", "epoch");

NOTIFY pgrst, 'reload schema';
