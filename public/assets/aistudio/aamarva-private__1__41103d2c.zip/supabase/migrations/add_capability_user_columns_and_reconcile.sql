-- AAMARVA Migration: Add missing Capability Increment columns on users & reconcile capability_entitlements schema
ALTER TABLE users ADD COLUMN IF NOT EXISTS plan_expires_at TIMESTAMPTZ;
ALTER TABLE users ADD COLUMN IF NOT EXISTS plan_created_at TIMESTAMPTZ;
ALTER TABLE users ADD COLUMN IF NOT EXISTS "hasCapabilityIncrement" BOOLEAN DEFAULT FALSE;

-- Reconcile legacy capability_entitlements schema if it was initially created without agent_id / user_id / master_id
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'capability_entitlements') THEN
    ALTER TABLE capability_entitlements ADD COLUMN IF NOT EXISTS agent_id TEXT;
    ALTER TABLE capability_entitlements ADD COLUMN IF NOT EXISTS user_id TEXT;
    ALTER TABLE capability_entitlements ADD COLUMN IF NOT EXISTS master_id TEXT;
    ALTER TABLE capability_entitlements ADD COLUMN IF NOT EXISTS capability_level INTEGER NOT NULL DEFAULT 1;
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'capability_entitlements' AND column_name = 'master_account_id') THEN
      ALTER TABLE capability_entitlements ALTER COLUMN master_account_id DROP NOT NULL;
    END IF;
    IF NOT EXISTS (
      SELECT 1 FROM pg_constraint WHERE conrelid = 'capability_entitlements'::regclass AND conname = 'unique_active_agent_capability'
    ) THEN
      IF NOT EXISTS (
        SELECT agent_id FROM capability_entitlements WHERE agent_id IS NOT NULL GROUP BY agent_id HAVING COUNT(*) > 1
      ) THEN
        ALTER TABLE capability_entitlements ADD CONSTRAINT unique_active_agent_capability UNIQUE (agent_id);
      END IF;
    END IF;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_capability_entitlements_lookup
  ON capability_entitlements(agent_id, status);
CREATE INDEX IF NOT EXISTS idx_capability_entitlements_user
  ON capability_entitlements(user_id, status);
CREATE INDEX IF NOT EXISTS idx_capability_entitlements_master
  ON capability_entitlements(master_id);
