-- ==============================================================================
-- MIGRATION: CREATE PUBLIC.MESSAGES & CONNECTION_MESSAGES TABLES
-- ==============================================================================
-- Run this in your Supabase SQL Editor if your database is missing public.messages
-- (fixes: "Could not find the table 'public.messages' in the schema cache").

CREATE TABLE IF NOT EXISTS public.messages (
  id TEXT PRIMARY KEY DEFAULT ('msg_' || gen_random_uuid()::TEXT),
  "connectionId" TEXT NOT NULL REFERENCES connections(id) ON DELETE CASCADE,
  "senderUserId" TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  "senderAgentId" TEXT NOT NULL,
  content TEXT,
  ciphertext TEXT,
  nonce TEXT,
  version INTEGER DEFAULT 1,
  "keyEpoch" INTEGER DEFAULT 1,
  sequence BIGINT,
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS content TEXT;
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS ciphertext TEXT;
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS nonce TEXT;
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS version INTEGER DEFAULT 1;
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS "keyEpoch" INTEGER DEFAULT 1;
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS sequence BIGINT;
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW();

ALTER TABLE public.messages ALTER COLUMN content DROP NOT NULL;
ALTER TABLE public.messages ALTER COLUMN ciphertext DROP NOT NULL;
ALTER TABLE public.messages ALTER COLUMN nonce DROP NOT NULL;
ALTER TABLE public.messages ALTER COLUMN "keyEpoch" DROP NOT NULL;

CREATE INDEX IF NOT EXISTS idx_messages_connection_created ON public.messages("connectionId", "createdAt" ASC);
CREATE INDEX IF NOT EXISTS idx_messages_sender_user ON public.messages("senderUserId");
CREATE INDEX IF NOT EXISTS idx_messages_sender_agent ON public.messages("senderAgentId");
CREATE INDEX IF NOT EXISTS idx_messages_created_at ON public.messages("createdAt" DESC);

ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE tablename = 'messages' AND policyname = 'Allow service_role full access to messages'
  ) THEN
    CREATE POLICY "Allow service_role full access to messages"
    ON public.messages
    FOR ALL
    TO service_role
    USING (true)
    WITH CHECK (true);
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS public.connection_messages (
  id TEXT PRIMARY KEY DEFAULT ('msg_' || gen_random_uuid()::TEXT),
  connection_id TEXT NOT NULL,
  sender_agent_id TEXT NOT NULL,
  ciphertext TEXT NOT NULL,
  nonce TEXT NOT NULL,
  version INTEGER DEFAULT 1,
  key_epoch INTEGER DEFAULT 1,
  sequence BIGINT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_connection_messages_conn_created ON public.connection_messages(connection_id, created_at ASC);

ALTER TABLE public.connection_messages ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE tablename = 'connection_messages' AND policyname = 'Allow service_role full access to connection_messages'
  ) THEN
    CREATE POLICY "Allow service_role full access to connection_messages"
    ON public.connection_messages
    FOR ALL
    TO service_role
    USING (true)
    WITH CHECK (true);
  END IF;
END $$;

NOTIFY pgrst, 'reload schema';
