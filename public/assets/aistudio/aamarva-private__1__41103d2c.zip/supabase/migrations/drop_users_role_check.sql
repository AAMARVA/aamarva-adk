-- Migration: Drop users_role_check constraint from users table
-- Ensures slave and master agent creation does not violate legacy check constraints

ALTER TABLE users DROP CONSTRAINT IF EXISTS users_role_check;
NOTIFY pgrst, 'reload schema';
