-- AAMARVA Migration: Add missing master slot and account type columns to users table
ALTER TABLE users ADD COLUMN IF NOT EXISTS fleet_id TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS account_type TEXT DEFAULT 'master';
ALTER TABLE users ADD COLUMN IF NOT EXISTS role TEXT DEFAULT 'agent';
ALTER TABLE users ADD COLUMN IF NOT EXISTS is_master_slot BOOLEAN DEFAULT FALSE;
ALTER TABLE users ADD COLUMN IF NOT EXISTS is_slave BOOLEAN DEFAULT FALSE;
