-- Migration: Add human_sessions table for WebAuthn and human session authentication
CREATE TABLE IF NOT EXISTS human_sessions (
  id TEXT PRIMARY KEY,
  "userId" TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  "sessionHash" TEXT NOT NULL UNIQUE,
  "expiresAt" TIMESTAMPTZ NOT NULL,
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_human_sessions_user_id ON human_sessions("userId");
CREATE INDEX IF NOT EXISTS idx_human_sessions_session_hash ON human_sessions("sessionHash");
CREATE INDEX IF NOT EXISTS idx_human_sessions_expires_at ON human_sessions("expiresAt");
