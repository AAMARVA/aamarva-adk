import dns from 'node:dns';
import express from 'express';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import path from 'path';
import zlib from 'zlib';
import dotenv from 'dotenv';
import { config, validateConfig } from './server/config'; 
import aamarvaRoutes from './server/routes/aamarvaRoutes';
import authRoutes from './server/routes/authRoutes';
import clusterRoutes from './server/routes/clusterRoutes';
import floorRoutes from './server/routes/floorRoutes';
import { checkDatabaseConnectivity, isSupabaseConfigured } from './server/supabase';
import { seed } from './seed';
import { initVerifiedUsersCache } from './server/authService';
import { ADK_SPECIFICATION, getAdkSpecification, FLOOR_MCP_AGENT_ENDPOINTS, getAllAdkEndpoints } from './server/adk_spec';
import { observabilityMiddleware } from './server/middleware/observabilityMiddleware';
import { securityMiddleware } from './server/middleware/securityMiddleware';
import { slaveActivityMiddleware } from './server/middleware/slaveActivityMiddleware';
import { sanitizeExistingSlaveConnections } from './server/services/connectionService';

dotenv.config();
try {
  dns.setDefaultResultOrder('ipv4first');
} catch {}

let configValidated = false;
export function ensureConfigValidated(): void {
  if (!configValidated) {
    validateConfig();
    configValidated = true;
  }
}

export async function createApp() {
  ensureConfigValidated();
  // Safely sanitize any legacy slave-to-slave connections without affecting legitimate connections
  sanitizeExistingSlaveConnections().catch(console.warn);
  const app = express();

  // Trust reverse proxy for rate-limiting headers (X-Forwarded-For, etc.)
  app.set('trust proxy', 1);

  // Security and core middleware
  app.use(observabilityMiddleware);
  app.use((req, res, next) => {
    if (req.method === 'HEAD' || req.method === 'OPTIONS') return next();
    const url = req.originalUrl || req.url || '';
    if (url.includes('/stream')) return next();
    const acceptEncoding = String(req.headers['accept-encoding'] || '');
    if (!/\bgzip\b/i.test(acceptEncoding)) return next();

    const rawWrite = res.write.bind(res);
    const rawEnd = res.end.bind(res);
    let chunks: Buffer[] = [];
    let decided = false;
    let passthrough = false;

    const shouldCompress = () => {
      if (res.headersSent || res.getHeader('Content-Encoding') || res.statusCode === 204 || res.statusCode === 304) {
        return false;
      }
      const ct = String(res.getHeader('Content-Type') || '').toLowerCase();
      if (ct.includes('text/event-stream') || ct.includes('image/') || ct.includes('audio/') || ct.includes('video/')) {
        return false;
      }
      return ct === '' || ct.includes('json') || ct.includes('text/') || ct.includes('javascript') || ct.includes('svg') || ct.includes('xml');
    };

    const flushRaw = () => {
      if (!passthrough) {
        passthrough = true;
        for (const c of chunks) rawWrite(c);
        chunks = [];
      }
    };

    (res as any).write = (chunk: any, encoding?: any, cb?: any) => {
      if (passthrough) return rawWrite(chunk, encoding, cb);
      if (!decided) {
        const ct = String(res.getHeader('Content-Type') || '').toLowerCase();
        if (ct.includes('text/event-stream') || !shouldCompress()) {
          decided = true;
          flushRaw();
          return rawWrite(chunk, encoding, cb);
        }
      }
      if (chunk !== undefined && chunk !== null) {
        const buf = Buffer.isBuffer(chunk) ? chunk : Buffer.from(String(chunk), typeof encoding === 'string' ? encoding as BufferEncoding : 'utf8');
        chunks.push(buf);
        const totalSize = chunks.reduce((sum, b) => sum + b.length, 0);
        if (totalSize > 4 * 1024 * 1024) {
          decided = true;
          flushRaw();
        }
      }
      if (typeof encoding === 'function') encoding();
      else if (typeof cb === 'function') cb();
      return true;
    };

    (res as any).end = (chunk?: any, encoding?: any, cb?: any) => {
      if (typeof chunk === 'function') {
        cb = chunk;
        chunk = undefined;
        encoding = undefined;
      } else if (typeof encoding === 'function') {
        cb = encoding;
        encoding = undefined;
      }
      if (passthrough) return rawEnd(chunk, encoding, cb);
      if (chunk !== undefined && chunk !== null) {
        const buf = Buffer.isBuffer(chunk) ? chunk : Buffer.from(String(chunk), typeof encoding === 'string' ? encoding as BufferEncoding : 'utf8');
        chunks.push(buf);
      }
      const fullBuf = chunks.length === 1 ? chunks[0] : Buffer.concat(chunks);
      chunks = [];
      if (!shouldCompress() || fullBuf.length < 1024) {
        return rawEnd(fullBuf, cb);
      }
      zlib.gzip(fullBuf, { level: zlib.constants.Z_BEST_SPEED }, (err, compressed) => {
        if (err || compressed.length >= fullBuf.length) {
          return rawEnd(fullBuf, cb);
        }
        res.removeHeader('Content-Length');
        res.setHeader('Content-Encoding', 'gzip');
        res.setHeader('Vary', 'Accept-Encoding');
        res.setHeader('Content-Length', compressed.length);
        return rawEnd(compressed, cb);
      });
      return res;
    };

    next();
  });
  app.use(securityMiddleware);

  const allowedOrigins = [
    'https://aamarva.com',
    'https://www.aamarva.com',
    'https://aamarva.vercel.app'
  ];

  if (process.env.FRONTEND_URL) {
    allowedOrigins.push(process.env.FRONTEND_URL.trim());
  }
  if (process.env.ADDITIONAL_ALLOWED_ORIGINS) {
    allowedOrigins.push(...process.env.ADDITIONAL_ALLOWED_ORIGINS.split(',').map(s => s.trim()).filter(Boolean));
  }

  app.use(cors({
    origin: (origin, callback) => {
      if (!origin) return callback(null, true);
      if (process.env.NODE_ENV !== 'production') return callback(null, true);
      if (allowedOrigins.includes(origin)) return callback(null, true);
      if (origin.endsWith('.vercel.app')) return callback(null, true);
      if (
        origin.includes('localhost') || 
        origin.includes('127.0.0.1') ||
        origin.endsWith('.run.app') ||
        origin.endsWith('.aistudio.google') ||
        origin.includes('.googleusercontent.com')
      ) {
        return callback(null, true);
      }
      callback(new Error('Not allowed by CORS'));
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-API-KEY', 'X-Requested-With', 'Accept', 'X-Request-ID', 'x-target-agent-id', 'X-Target-Agent-Id'],
  }));
  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));
  app.use(cookieParser());

  // Automatically record slave agent activities across any non-human-only endpoint
  app.use(slaveActivityMiddleware);

  // Mount API endpoints strictly under /api prefix and root prefix for flexible serverless rewrites
  app.use('/api', authRoutes);
  app.use('/api/floor', floorRoutes);
  app.use('/api', aamarvaRoutes);
  app.use('/api', clusterRoutes);
  app.use('/', authRoutes);
  app.use('/floor', floorRoutes);
  app.use('/', aamarvaRoutes);
  app.use('/', clusterRoutes);

  // Return JSON 404 for any unmatched /api requests (avoids falling through to SPA HTML fallback)
  app.use('/api', (req: express.Request, res: express.Response) => {
    res.status(404).json({
      success: false,
      error: {
        code: 'NOT_FOUND',
        message: `API endpoint ${req.method} ${req.originalUrl} not found.`
      }
    });
  });

  // Serve public /adk endpoint directly at /adk (API clients get JSON/text; browser requests fall through to SPA router)
  app.get('/adk', (req: express.Request, res: express.Response, next: express.NextFunction) => {
    if (req.headers.accept && req.headers.accept.includes('text/html') && !req.headers.accept.includes('application/json') && !req.headers.accept.includes('text/plain')) {
      return next();
    }
    const host = req.get('host') || 'aamarva.com';
    const protocol = (req.headers['x-forwarded-proto'] as string) || req.protocol || 'https';
    const currentUrl = `${protocol}://${host}`;
    const rawSpec = getAdkSpecification() || ADK_SPECIFICATION;
    const dynamicSpec = rawSpec ? rawSpec.replace(/https:\/\/aamarva\.com/g, currentUrl) : rawSpec;
    const allEndpoints = getAllAdkEndpoints();

    if (req.headers.accept && req.headers.accept.includes('text/plain')) {
      res.setHeader('Content-Type', 'text/plain; charset=utf-8');
      return res.send(dynamicSpec);
    }
    res.json({
      success: true,
      version: '2.0.0',
      data: {
        version: '2.0.0',
        adk: dynamicSpec,
        floorEndpoints: FLOOR_MCP_AGENT_ENDPOINTS,
        floor_endpoints: FLOOR_MCP_AGENT_ENDPOINTS,
        endpoints: allEndpoints
      },
      endpoints: allEndpoints,
      floorEndpoints: FLOOR_MCP_AGENT_ENDPOINTS,
      floor_endpoints: FLOOR_MCP_AGENT_ENDPOINTS
    });
  });

  // Serve public static assets with 1-day caching
  app.use(express.static(path.join(process.cwd(), 'public'), {
    maxAge: '1d',
  }));

  // Vite development middleware (only active in local development)
  if (process.env.NODE_ENV !== 'production' && !process.env.VERCEL) {
    try {
      const { createServer: createViteServer } = await import('vite');
      const vite = await createViteServer({
        server: { middlewareMode: true, allowedHosts: true, hmr: false },
        appType: 'spa',
      });
      app.use(vite.middlewares);

      // SPA client routing fallback in development mode
      app.use(async (req, res, next) => {
        if (req.originalUrl.startsWith('/api') || req.originalUrl === '/adk') {
          return next();
        }
        try {
          const indexHtmlPath = path.resolve(process.cwd(), 'index.html');
          const fs = await import('fs/promises');
          let template = await fs.readFile(indexHtmlPath, 'utf-8');
          template = await vite.transformIndexHtml(req.originalUrl, template);
          res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
        } catch (e: any) {
          next(e);
        }
      });
    } catch (viteErr) {
      console.warn('Vite dev server middleware not initialized:', viteErr);
    }
  } else if (!process.env.VERCEL) {
    // Serve static frontend assets with long-lived immutable caching for hashed assets
    app.use('/assets', express.static(path.join(process.cwd(), 'dist', 'assets'), {
      maxAge: '1y',
      immutable: true,
    }));
    app.use(express.static(path.join(process.cwd(), 'dist'), {
      maxAge: '1h',
    }));
    app.get('/{*splat}', (req, res) => {
      res.setHeader('Cache-Control', 'no-cache');
      res.sendFile(path.join(process.cwd(), 'dist', 'index.html'));
    });
  }

  return app;
}

// Global process error handlers to prevent unexpected process death
process.on('uncaughtException', (err: any) => {
  console.error('[Aamarva Backend MVP] Uncaught exception:', err?.message || err);
});

process.on('unhandledRejection', (reason: any) => {
  console.warn('[Aamarva Backend MVP] Unhandled promise rejection:', reason?.message || reason);
});

const isDirectEntry = 
  (typeof require !== 'undefined' && typeof module !== 'undefined' && require.main === module) ||
  (process.argv[1] && (process.argv[1].endsWith('server.ts') || process.argv[1].endsWith('server.cjs') || process.argv[1].endsWith('server.js')));

if (isDirectEntry) {
    async function startServer() {
      validateConfig();
      await checkDatabaseConnectivity();
      await initVerifiedUsersCache();
      if (!isSupabaseConfigured()) {
        try {
          await seed();
        } catch (e) {
          console.warn('Seed warning:', e);
        }
      }
      const app = await createApp();
      const PORT = config.port;
      const HOST = '0.0.0.0';
      const { websocketGatewayService } = await import('./server/services/websocketGatewayService.js');
      const server = app.listen(Number(PORT), HOST, () => {
        console.log(`[Aamarva Backend MVP] Server running on port ${PORT}`);
        websocketGatewayService.attach(server);
      });

      server.on('error', (err: any) => {
        if (err.code === 'EADDRINUSE') {
          console.error(`[Aamarva Backend MVP] Port ${PORT} already in use. Retrying or waiting...`);
        } else {
          console.error('[Aamarva Backend MVP] Server runtime error:', err?.message || err);
        }
      });
    }
    startServer().catch((err) => {
      console.error('Failed to start server:', err);
    });
}


